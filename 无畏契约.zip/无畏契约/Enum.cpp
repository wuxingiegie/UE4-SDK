																/* Create by 无心 */
																/* B站ID: 无心geigei  */
																/* telegram群@wuxingeigei */
// Enum  /Script/CoreUObject.EInterpCurveMode
enum class EInterpCurveMode : uint8_t
{
    CIM_Linear                                     = 0,
    CIM_CurveAuto                                  = 1,
    CIM_Constant                                   = 2,
    CIM_CurveUser                                  = 3,
    CIM_CurveBreak                                 = 4,
    CIM_CurveAutoClamped                           = 5,
    CIM_MAX                                        = 6

};


// Enum  /Script/CoreUObject.Default__Enum
enum class Default__Enum : uint8_t
{

};


// Enum  /Script/CoreUObject.ERangeBoundTypes
enum class ERangeBoundTypes : uint8_t
{
    Exclusive                                      = 0,
    Inclusive                                      = 1,
    Open                                           = 2,
    ERangeBoundTypes_MAX                           = 3

};


// Enum  /Script/CoreUObject.ELocalizedTextSourceCategory
enum class ELocalizedTextSourceCategory : uint8_t
{
    Game                                           = 0,
    Engine                                         = 1,
    Editor                                         = 2,
    ELocalizedTextSourceCategory_MAX               = 3

};


// Enum  /Script/CoreUObject.EAutomationEventType
enum class EAutomationEventType : uint8_t
{
    Info                                           = 0,
    Warning                                        = 1,
    Error                                          = 2,
    EAutomationEventType_MAX                       = 3

};


// Enum  /Script/AndroidDeviceProfileSelector.ECompareType
enum class ECompareType : uint8_t
{
    CMP_Equal                                      = 0,
    CMP_Less                                       = 1,
    CMP_LessEqual                                  = 2,
    CMP_Greater                                    = 3,
    CMP_GreaterEqual                               = 4,
    CMP_NotEqual                                   = 5,
    CMP_Regex                                      = 6,
    CMP_EqualIgnore                                = 7,
    CMP_LessIgnore                                 = 8,
    CMP_LessEqualIgnore                            = 9,
    CMP_GreaterIgnore                              = 10,
    CMP_GreaterEqualIgnore                         = 11,
    CMP_NotEqualIgnore                             = 12,
    CMP_Hash                                       = 13,
    CMP_MAX                                        = 14

};


// Enum  /Script/AndroidDeviceProfileSelector.ESourceType
enum class ESourceType : uint8_t
{
    SRC_PreviousRegexMatch                         = 0,
    SRC_GpuFamily                                  = 1,
    SRC_GlVersion                                  = 2,
    SRC_AndroidVersion                             = 3,
    SRC_DeviceMake                                 = 4,
    SRC_DeviceModel                                = 5,
    SRC_DeviceBuildNumber                          = 6,
    SRC_VulkanVersion                              = 7,
    SRC_UsingHoudini                               = 8,
    SRC_VulkanAvailable                            = 9,
    SRC_CommandLine                                = 10,
    SRC_Hardware                                   = 11,
    SRC_Chipset                                    = 12,
    SRC_MemorySizeInGB                             = 13,
    SRC_CPUCoreNum                                 = 14,
    SRC_CPUMaxFreq                                 = 15,
    SRC_GLExtensions                               = 16,
    SRC_BrandROMVersion                            = 17,
    SRC_VulkanVendorID                             = 18,
    SRC_VulkanDriverVersion                        = 19,
    SRC_VulkanApiVersion                           = 20,
    SRC_MainBroadInfo                              = 21,
    SRC_MaxRefreshRate                             = 22,
    SRC_MAX                                        = 23

};


// Enum  /Script/Engine.ETextGender
enum class ETextGender : uint8_t
{
    Masculine                                      = 0,
    Feminine                                       = 1,
    Neuter                                         = 2,
    ETextGender_MAX                                = 3

};


// Enum  /Script/Engine.EFormatArgumentType
enum class EFormatArgumentType : uint8_t
{
    Int                                            = 0,
    UInt                                           = 1,
    Float                                          = 2,
    Double                                         = 3,
    Text                                           = 4,
    Gender                                         = 5,
    EFormatArgumentType_MAX                        = 6

};


// Enum  /Script/InputCore.ETouchIndex
enum class ETouchIndex : uint8_t
{
    Touch1                                         = 0,
    Touch2                                         = 1,
    Touch3                                         = 2,
    Touch4                                         = 3,
    Touch5                                         = 4,
    Touch6                                         = 5,
    Touch7                                         = 6,
    Touch8                                         = 7,
    Touch9                                         = 8,
    Touch10                                        = 9,
    CursorPointerIndex                             = 10,
    MAX_TOUCHES                                    = 11,
    ETouchIndex_MAX                                = 12

};


// Enum  /Script/Engine.EEndPlayReason
enum class EEndPlayReason : uint8_t
{
    Destroyed                                      = 0,
    LevelTransition                                = 1,
    EndPlayInEditor                                = 2,
    RemovedFromWorld                               = 3,
    Quit                                           = 4,
    EEndPlayReason_MAX                             = 5

};


// Enum  /Script/Engine.ENetRole
enum class ENetRole : uint8_t
{
    ROLE_None                                      = 0,
    ROLE_SimulatedProxy                            = 1,
    ROLE_AutonomousProxy                           = 2,
    ROLE_Authority                                 = 3,
    ROLE_MAX                                       = 4

};


// Enum  /Script/Engine.EAttachLocation
enum class EAttachLocation : uint8_t
{
    KeepRelativeOffset                             = 0,
    KeepWorldPosition                              = 1,
    SnapToTarget                                   = 2,
    SnapToTargetIncludingScale                     = 3,
    EAttachLocation_MAX                            = 4

};


// Enum  /Script/Engine.EAttachmentRule
enum class EAttachmentRule : uint8_t
{
    KeepRelative                                   = 0,
    KeepWorld                                      = 1,
    SnapToTarget                                   = 2,
    EAttachmentRule_MAX                            = 3

};


// Enum  /Script/Engine.EDetachmentRule
enum class EDetachmentRule : uint8_t
{
    KeepRelative                                   = 0,
    KeepWorld                                      = 1,
    EDetachmentRule_MAX                            = 2

};


// Enum  /Script/Engine.ETickPartialGroup
enum class ETickPartialGroup : uint8_t
{
    GROUP                                          = 1,
    GROUP                                          = 2,
    GROUP                                          = 4,
    GROUP                                          = 8,
    GROUP                                          = 16,
    GROUP                                          = 32,
    GROUP                                          = 64,
    GROUP                                          = 128,
    GROUP                                          = 5,
    GROUP                                          = 17,
    GROUP                                          = 85,
    AllFlags                                       = 255,
    ETickPartialGroup_MAX                          = 256

};


// Enum  /Script/Engine.ENetDormancy
enum class ENetDormancy : uint8_t
{
    DORM_Never                                     = 0,
    DORM_Awake                                     = 1,
    DORM_DormantAll                                = 2,
    DORM_DormantPartial                            = 3,
    DORM_Initial                                   = 4,
    DORM_MAX                                       = 5

};


// Enum  /Script/Engine.ETickingGroup
enum class ETickingGroup : uint8_t
{
    TG_PrePhysics                                  = 0,
    TG_StartPhysics                                = 1,
    TG_DuringPhysics                               = 2,
    TG_EndPhysics                                  = 3,
    TG_PostPhysics                                 = 4,
    TG_PostUpdateWork                              = 5,
    TG_LastDemotable                               = 6,
    TG_NewlySpawned                                = 7,
    TG_MAX                                         = 8

};


// Enum  /Script/Engine.EAutoReceiveInput
enum class EAutoReceiveInput : uint8_t
{
    Disabled                                       = 0,
    Player0                                        = 1,
    Player1                                        = 2,
    Player2                                        = 3,
    Player3                                        = 4,
    Player4                                        = 5,
    Player5                                        = 6,
    Player6                                        = 7,
    Player7                                        = 8,
    EAutoReceiveInput_MAX                          = 9

};


// Enum  /Script/Engine.ESpawnActorCollisionHandlingMethod
enum class ESpawnActorCollisionHandlingMethod : uint8_t
{
    Undefined                                      = 0,
    AlwaysSpawn                                    = 1,
    AdjustIfPossibleButAlwaysSpawn                 = 2,
    AdjustIfPossibleButDontSpawnIfColliding        = 3,
    DontSpawnIfColliding                           = 4,
    ESpawnActorCollisionHandlingMethod_MAX         = 5

};


// Enum  /Script/Engine.ERotatorQuantization
enum class ERotatorQuantization : uint8_t
{
    ByteComponents                                 = 0,
    ShortComponents                                = 1,
    IgnoreSerialize                                = 2,
    ERotatorQuantization_MAX                       = 3

};


// Enum  /Script/Engine.EVectorQuantization
enum class EVectorQuantization : uint8_t
{
    RoundWholeNumber                               = 0,
    RoundOneDecimal                                = 1,
    RoundTwoDecimals                               = 2,
    SimplifySerialize                              = 3,
    EVectorQuantization_MAX                        = 4

};


// Enum  /Script/Engine.EActorUpdateOverlapsMethod
enum class EActorUpdateOverlapsMethod : uint8_t
{
    UseConfigDefault                               = 0,
    AlwaysUpdate                                   = 1,
    OnlyUpdateMovable                              = 2,
    NeverUpdate                                    = 3,
    EActorUpdateOverlapsMethod_MAX                 = 4

};


// Enum  /Script/Engine.EComponentCreationMethod
enum class EComponentCreationMethod : uint8_t
{
    Native                                         = 0,
    SimpleConstructionScript                       = 1,
    UserConstructionScript                         = 2,
    Instance                                       = 3,
    EComponentCreationMethod_MAX                   = 4

};


// Enum  /Script/Engine.ETemperatureSeverityType
enum class ETemperatureSeverityType : uint8_t
{
    Unknown                                        = 0,
    Good                                           = 1,
    Bad                                            = 2,
    Serious                                        = 3,
    Critical                                       = 4,
    NumSeverities                                  = 5,
    ETemperatureSeverityType_MAX                   = 6

};


// Enum  /Script/Engine.EQuartzCommandQuantization
enum class EQuartzCommandQuantization : uint8_t
{
    Bar                                            = 0,
    Beat                                           = 1,
    ThirtySecondNote                               = 2,
    SixteenthNote                                  = 3,
    EighthNote                                     = 4,
    QuarterNote                                    = 5,
    HalfNote                                       = 6,
    WholeNote                                      = 7,
    DottedSixteenthNote                            = 8,
    DottedEighthNote                               = 9,
    DottedQuarterNote                              = 10,
    DottedHalfNote                                 = 11,
    DottedWholeNote                                = 12,
    SixteenthNoteTriplet                           = 13,
    EighthNoteTriplet                              = 14,
    QuarterNoteTriplet                             = 15,
    HalfNoteTriplet                                = 16,
    Tick                                           = 17,
    Count                                          = 18,
    EQuartzCommandQuantization_MAX                 = 19

};


// Enum  /Script/Engine.EQuartzCommandDelegateSubType
enum class EQuartzCommandDelegateSubType : uint8_t
{
    CommandOnFailedToQueue                         = 0,
    CommandOnQueued                                = 1,
    CommandOnCanceled                              = 2,
    CommandOnAboutToStart                          = 3,
    CommandOnStarted                               = 4,
    Count                                          = 5,
    EQuartzCommandDelegateSubType_MAX              = 6

};


// Enum  /Script/Engine.EAudioComponentPlayState
enum class EAudioComponentPlayState : uint8_t
{
    Playing                                        = 0,
    Stopped                                        = 1,
    Paused                                         = 2,
    FadingIn                                       = 3,
    FadingOut                                      = 4,
    Count                                          = 5,
    EAudioComponentPlayState_MAX                   = 6

};


// Enum  /Script/Engine.EPlaneConstraintAxisSetting
enum class EPlaneConstraintAxisSetting : uint8_t
{
    Custom                                         = 0,
    X                                              = 1,
    Y                                              = 2,
    Z                                              = 3,
    UseGlobalPhysicsSetting                        = 4,
    EPlaneConstraintAxisSetting_MAX                = 5

};


// Enum  /Script/Engine.EInterpToBehaviourType
enum class EInterpToBehaviourType : uint8_t
{
    OneShot                                        = 0,
    OneShot_Reverse                                = 1,
    Loop_Reset                                     = 2,
    PingPong                                       = 3,
    EInterpToBehaviourType_MAX                     = 4

};


// Enum  /Script/Engine.ETeleportType
enum class ETeleportType : uint8_t
{
    None                                           = 0,
    TeleportPhysics                                = 1,
    ResetPhysics                                   = 2,
    ETeleportType_MAX                              = 3

};


// Enum  /Script/Engine.EPlatformInterfaceDataType
enum class EPlatformInterfaceDataType : uint8_t
{
    PIDT_None                                      = 0,
    PIDT_Int                                       = 1,
    PIDT_Float                                     = 2,
    PIDT_String                                    = 3,
    PIDT_Object                                    = 4,
    PIDT_Custom                                    = 5,
    PIDT_MAX                                       = 6

};


// Enum  /Script/Engine.EMovementMode
enum class EMovementMode : uint8_t
{
    MOVE_None                                      = 0,
    MOVE_Walking                                   = 1,
    MOVE_NavWalking                                = 2,
    MOVE_Falling                                   = 3,
    MOVE_Swimming                                  = 4,
    MOVE_Flying                                    = 5,
    MOVE_Custom                                    = 6,
    MOVE_MAX                                       = 7

};


// Enum  /Script/Engine.ENetworkFailure
enum class ENetworkFailure : uint8_t
{
    NetDriverAlreadyExists                         = 0,
    NetDriverCreateFailure                         = 1,
    NetDriverListenFailure                         = 2,
    ConnectionLost                                 = 3,
    ConnectionTimeout                              = 4,
    FailureReceived                                = 5,
    OutdatedClient                                 = 6,
    OutdatedServer                                 = 7,
    PendingConnectionFailure                       = 8,
    NetGuidMismatch                                = 9,
    NetChecksumMismatch                            = 10,
    ENetworkFailure_MAX                            = 11

};


// Enum  /Script/Engine.ETravelFailure
enum class ETravelFailure : uint8_t
{
    NoLevel                                        = 0,
    LoadMapFailure                                 = 1,
    InvalidURL                                     = 2,
    PackageMissing                                 = 3,
    PackageVersion                                 = 4,
    NoDownload                                     = 5,
    TravelFailure                                  = 6,
    CheatCommands                                  = 7,
    PendingNetGameCreateFailure                    = 8,
    CloudSaveFailure                               = 9,
    ServerTravelFailure                            = 10,
    ClientTravelFailure                            = 11,
    ETravelFailure_MAX                             = 12

};


// Enum  /Script/Engine.EScreenOrientation
enum class EScreenOrientation : uint8_t
{
    Unknown                                        = 0,
    Portrait                                       = 1,
    PortraitUpsideDown                             = 2,
    LandscapeLeft                                  = 3,
    LandscapeRight                                 = 4,
    FaceUp                                         = 5,
    FaceDown                                       = 6,
    EScreenOrientation_MAX                         = 7

};


// Enum  /Script/Engine.EApplicationState
enum class EApplicationState : uint8_t
{
    Unknown                                        = 0,
    Inactive                                       = 1,
    Background                                     = 2,
    Active                                         = 3,
    EApplicationState_MAX                          = 4

};


// Enum  /Script/Engine.EObjectTypeQuery
enum class EObjectTypeQuery : uint8_t
{
    ObjectTypeQuery1                               = 0,
    ObjectTypeQuery2                               = 1,
    ObjectTypeQuery3                               = 2,
    ObjectTypeQuery4                               = 3,
    ObjectTypeQuery5                               = 4,
    ObjectTypeQuery6                               = 5,
    ObjectTypeQuery7                               = 6,
    ObjectTypeQuery8                               = 7,
    ObjectTypeQuery9                               = 8,
    ObjectTypeQuery10                              = 9,
    ObjectTypeQuery11                              = 10,
    ObjectTypeQuery12                              = 11,
    ObjectTypeQuery13                              = 12,
    ObjectTypeQuery14                              = 13,
    ObjectTypeQuery15                              = 14,
    ObjectTypeQuery16                              = 15,
    ObjectTypeQuery17                              = 16,
    ObjectTypeQuery18                              = 17,
    ObjectTypeQuery19                              = 18,
    ObjectTypeQuery20                              = 19,
    ObjectTypeQuery21                              = 20,
    ObjectTypeQuery22                              = 21,
    ObjectTypeQuery23                              = 22,
    ObjectTypeQuery24                              = 23,
    ObjectTypeQuery25                              = 24,
    ObjectTypeQuery26                              = 25,
    ObjectTypeQuery27                              = 26,
    ObjectTypeQuery28                              = 27,
    ObjectTypeQuery29                              = 28,
    ObjectTypeQuery30                              = 29,
    ObjectTypeQuery31                              = 30,
    ObjectTypeQuery32                              = 31,
    ObjectTypeQuery_MAX                            = 32,
    EObjectTypeQuery_MAX                           = 33

};


// Enum  /Script/Engine.EDrawDebugTrace
enum class EDrawDebugTrace : uint8_t
{
    None                                           = 0,
    ForOneFrame                                    = 1,
    ForDuration                                    = 2,
    Persistent                                     = 3,
    EDrawDebugTrace_MAX                            = 4

};


// Enum  /Script/Engine.ETraceTypeQuery
enum class ETraceTypeQuery : uint8_t
{
    TraceTypeQuery1                                = 0,
    TraceTypeQuery2                                = 1,
    TraceTypeQuery3                                = 2,
    TraceTypeQuery4                                = 3,
    TraceTypeQuery5                                = 4,
    TraceTypeQuery6                                = 5,
    TraceTypeQuery7                                = 6,
    TraceTypeQuery8                                = 7,
    TraceTypeQuery9                                = 8,
    TraceTypeQuery10                               = 9,
    TraceTypeQuery11                               = 10,
    TraceTypeQuery12                               = 11,
    TraceTypeQuery13                               = 12,
    TraceTypeQuery14                               = 13,
    TraceTypeQuery15                               = 14,
    TraceTypeQuery16                               = 15,
    TraceTypeQuery17                               = 16,
    TraceTypeQuery18                               = 17,
    TraceTypeQuery19                               = 18,
    TraceTypeQuery20                               = 19,
    TraceTypeQuery21                               = 20,
    TraceTypeQuery22                               = 21,
    TraceTypeQuery23                               = 22,
    TraceTypeQuery24                               = 23,
    TraceTypeQuery25                               = 24,
    TraceTypeQuery26                               = 25,
    TraceTypeQuery27                               = 26,
    TraceTypeQuery28                               = 27,
    TraceTypeQuery29                               = 28,
    TraceTypeQuery30                               = 29,
    TraceTypeQuery31                               = 30,
    TraceTypeQuery32                               = 31,
    TraceTypeQuery_MAX                             = 32,
    ETraceTypeQuery_MAX                            = 33

};


// Enum  /Script/Engine.EMoveComponentAction
enum class EMoveComponentAction : uint8_t
{
    Move                                           = 0,
    Stop                                           = 1,
    Return                                         = 2,
    EMoveComponentAction_MAX                       = 3

};


// Enum  /Script/Engine.EQuitPreference
enum class EQuitPreference : uint8_t
{
    Quit                                           = 0,
    Background                                     = 1,
    EQuitPreference_MAX                            = 2

};


// Enum  /Script/GameplayAbilities.EGameplayEffectGrantedAbilityRemovePolicy
enum class EGameplayEffectGrantedAbilityRemovePolicy : uint8_t
{
    CancelAbilityImmediately                       = 0,
    RemoveAbilityOnEnd                             = 1,
    DoNothing                                      = 2,
    EGameplayEffectGrantedAbilityRemovePolicy_MAX  = 3

};


// Enum  /Script/GameplayAbilities.EGameplayEffectAttributeCaptureSource
enum class EGameplayEffectAttributeCaptureSource : uint8_t
{
    Source                                         = 0,
    Target                                         = 1,
    EGameplayEffectAttributeCaptureSource_MAX      = 2

};


// Enum  /Script/GameplayAbilities.EGameplayAbilityTargetingLocationType
enum class EGameplayAbilityTargetingLocationType : uint8_t
{
    LiteralTransform                               = 0,
    ActorTransform                                 = 1,
    SocketTransform                                = 2,
    EGameplayAbilityTargetingLocationType_MAX      = 3

};


// Enum  /Script/GameplayAbilities.EGameplayCueEvent
enum class EGameplayCueEvent : uint8_t
{
    OnActive                                       = 0,
    WhileActive                                    = 1,
    Executed                                       = 2,
    Removed                                        = 3,
    Refresh                                        = 4,
    OnEvent                                        = 5,
    EGameplayCueEvent_MAX                          = 6

};


// Enum  /Script/GameplayAbilities.ETargetDataFilterSelf
enum class ETargetDataFilterSelf : uint8_t
{
    TDFS_Any                                       = 0,
    TDFS_NoSelf                                    = 1,
    TDFS_NoOthers                                  = 2,
    TDFS_MAX                                       = 3

};


// Enum  /Script/GameplayTasks.ETaskResourceOverlapPolicy
enum class ETaskResourceOverlapPolicy : uint8_t
{
    StartOnTop                                     = 0,
    StartAtEnd                                     = 1,
    ETaskResourceOverlapPolicy_MAX                 = 2

};


// Enum  /Script/GameplayTasks.EGameplayTaskRunResult
enum class EGameplayTaskRunResult : uint8_t
{
    Error                                          = 0,
    Failed                                         = 1,
    Success_Paused                                 = 2,
    Success_Active                                 = 3,
    Success_Finished                               = 4,
    EGameplayTaskRunResult_MAX                     = 5

};


// Enum  /Script/GameplayAbilities.EGameplayAbilityActivationMode
enum class EGameplayAbilityActivationMode : uint8_t
{
    Authority                                      = 0,
    NonAuthority                                   = 1,
    Predicting                                     = 2,
    Confirmed                                      = 3,
    Rejected                                       = 4,
    EGameplayAbilityActivationMode_MAX             = 5

};


// Enum  /Script/GameplayAbilities.EAbilityGenericReplicatedEvent
enum class EAbilityGenericReplicatedEvent : uint8_t
{
    GenericConfirm                                 = 0,
    GenericCancel                                  = 1,
    InputPressed                                   = 2,
    InputReleased                                  = 3,
    GenericSignalFromClient                        = 4,
    GenericSignalFromServer                        = 5,
    GameCustom1                                    = 6,
    GameCustom2                                    = 7,
    GameCustom3                                    = 8,
    GameCustom4                                    = 9,
    GameCustom5                                    = 10,
    GameCustom6                                    = 11,
    MAX                                            = 12

};


// Enum  /Script/Engine.EFastArraySerializerDeltaFlags
enum class EFastArraySerializerDeltaFlags : uint8_t
{
    None                                           = 0,
    HasBeenSerialized                              = 1,
    HasDeltaBeenRequested                          = 2,
    IsUsingDeltaSerialization                      = 4,
    EFastArraySerializerDeltaFlags_MAX             = 5

};


// Enum  /Script/GameplayAbilities.EGameplayEffectReplicationMode
enum class EGameplayEffectReplicationMode : uint8_t
{
    Minimal                                        = 0,
    Mixed                                          = 1,
    Full                                           = 2,
    EGameplayEffectReplicationMode_MAX             = 3

};


// Enum  /Script/GameplayAbilities.EAbilityLogLevel
enum class EAbilityLogLevel : uint8_t
{
    VeryVerbose                                    = 0,
    Verbose                                        = 1,
    Debug                                          = 2,
    Warning                                        = 3,
    Error                                          = 4,
    EAbilityLogLevel_MAX                           = 5

};


// Enum  /Script/GameplayAbilities.EAbilityTaskWaitState
enum class EAbilityTaskWaitState : uint8_t
{
    WaitingOnGame                                  = 1,
    WaitingOnUser                                  = 2,
    WaitingOnAvatar                                = 4,
    EAbilityTaskWaitState_MAX                      = 5

};


// Enum  /Script/GameplayAbilities.ERootMotionMoveToActorTargetOffsetType
enum class ERootMotionMoveToActorTargetOffsetType : uint8_t
{
    AlignFromTargetToSource                        = 0,
    AlignToTargetForward                           = 1,
    AlignToWorldSpace                              = 2,
    ERootMotionMoveToActorTargetOffsetType_MAX     = 3

};


// Enum  /Script/GameplayAbilities.EAbilityTaskNetSyncType
enum class EAbilityTaskNetSyncType : uint8_t
{
    BothWait                                       = 0,
    OnlyServerWait                                 = 1,
    OnlyClientWait                                 = 2,
    EAbilityTaskNetSyncType_MAX                    = 3

};


// Enum  /Script/GameplayAbilities.EWaitAttributeChangeComparison
enum class EWaitAttributeChangeComparison : uint8_t
{
    None                                           = 0,
    GreaterThan                                    = 1,
    LessThan                                       = 2,
    GreaterThanOrEqualTo                           = 3,
    LessThanOrEqualTo                              = 4,
    NotEqualTo                                     = 5,
    ExactlyEqualTo                                 = 6,
    MAX                                            = 7

};


// Enum  /Script/GameplayAbilities.EGameplayAbilityInputBinds
enum class EGameplayAbilityInputBinds : uint8_t
{
    Ability1                                       = 0,
    Ability2                                       = 1,
    Ability3                                       = 2,
    Ability4                                       = 3,
    Ability5                                       = 4,
    Ability6                                       = 5,
    Ability7                                       = 6,
    Ability8                                       = 7,
    Ability9                                       = 8,
    EGameplayAbilityInputBinds_MAX                 = 9

};


// Enum  /Script/GameplayAbilities.EGameplayTargetingConfirmation
enum class EGameplayTargetingConfirmation : uint8_t
{
    Instant                                        = 0,
    UserConfirmed                                  = 1,
    ClientConfirmed                                = 2,
    InstantSafe                                    = 3,
    ServerReceive                                  = 4,
    Custom                                         = 5,
    CustomMulti                                    = 6,
    ServerReceiveValidNotEndTask                   = 7,
    EGameplayTargetingConfirmation_MAX             = 8

};


// Enum  /Script/GameplayAbilities.ERepAnimPositionMethod
enum class ERepAnimPositionMethod : uint8_t
{
    Position                                       = 0,
    CurrentSectionId                               = 1,
    ERepAnimPositionMethod_MAX                     = 2

};


// Enum  /Script/GameplayAbilities.EGameplayAbilityTriggerSource
enum class EGameplayAbilityTriggerSource : uint8_t
{
    GameplayEvent                                  = 0,
    OwnedTagAdded                                  = 1,
    OwnedTagPresent                                = 2,
    EGameplayAbilityTriggerSource_MAX              = 3

};


// Enum  /Script/GameplayAbilities.EGameplayAbilityReplicationPolicy
enum class EGameplayAbilityReplicationPolicy : uint8_t
{
    ReplicateNo                                    = 0,
    ReplicateYes                                   = 1,
    EGameplayAbilityReplicationPolicy_MAX          = 2

};


// Enum  /Script/GameplayAbilities.EGameplayAbilityNetSecurityPolicy
enum class EGameplayAbilityNetSecurityPolicy : uint8_t
{
    ClientOrServer                                 = 0,
    ServerOnlyExecution                            = 1,
    ServerOnlyTermination                          = 2,
    ServerOnly                                     = 3,
    EGameplayAbilityNetSecurityPolicy_MAX          = 4

};


// Enum  /Script/GameplayAbilities.EGameplayAbilityNetExecutionPolicy
enum class EGameplayAbilityNetExecutionPolicy : uint8_t
{
    LocalPredicted                                 = 0,
    LocalOnly                                      = 1,
    ServerInitiated                                = 2,
    ServerOnly                                     = 3,
    EGameplayAbilityNetExecutionPolicy_MAX         = 4

};


// Enum  /Script/GameplayAbilities.EGameplayAbilityInstancingPolicy
enum class EGameplayAbilityInstancingPolicy : uint8_t
{
    NonInstanced                                   = 0,
    InstancedPerActor                              = 1,
    InstancedPerExecution                          = 2,
    EGameplayAbilityInstancingPolicy_MAX           = 3

};


// Enum  /Script/GameplayAbilities.EGameplayCuePayloadType
enum class EGameplayCuePayloadType : uint8_t
{
    CueParameters                                  = 0,
    FromSpec                                       = 1,
    EGameplayCuePayloadType_MAX                    = 2

};


// Enum  /Script/GameplayAbilities.EAsyncGameplayCuePredictFlag
enum class EAsyncGameplayCuePredictFlag : uint8_t
{
    RepCueAdd                                      = 0,
    RepCueRemoved                                  = 1,
    RepAsyncKey                                    = 2,
    EAsyncGameplayCuePredictFlag_MAX               = 3

};


// Enum  /Script/GameplayAbilities.EBuffStateEvent
enum class EBuffStateEvent : uint8_t
{
    Awake                                          = 0,
    Dormancy                                       = 1,
    Reinit                                         = 2,
    EBuffStateEvent_MAX                            = 3

};


// Enum  /Script/GameplayAbilities.EGameplayEffectPeriodInhibitionRemovedPolicy
enum class EGameplayEffectPeriodInhibitionRemovedPolicy : uint8_t
{
    NeverReset                                     = 0,
    ResetPeriod                                    = 1,
    ExecuteAndResetPeriod                          = 2,
    EGameplayEffectPeriodInhibitionRemovedPolicy_MAX = 3

};


// Enum  /Script/GameplayAbilities.EGameplayEffectStackingExpirationPolicy
enum class EGameplayEffectStackingExpirationPolicy : uint8_t
{
    ClearEntireStack                               = 0,
    RemoveSingleStackAndRefreshDuration            = 1,
    RefreshDuration                                = 2,
    EGameplayEffectStackingExpirationPolicy_MAX    = 3

};


// Enum  /Script/GameplayAbilities.EGameplayEffectStackingPeriodPolicy
enum class EGameplayEffectStackingPeriodPolicy : uint8_t
{
    ResetOnSuccessfulApplication                   = 0,
    NeverReset                                     = 1,
    EGameplayEffectStackingPeriodPolicy_MAX        = 2

};


// Enum  /Script/GameplayAbilities.EGameplayEffectStackingDurationPolicy
enum class EGameplayEffectStackingDurationPolicy : uint8_t
{
    RefreshOnSuccessfulApplication                 = 0,
    NeverRefresh                                   = 1,
    EGameplayEffectStackingDurationPolicy_MAX      = 2

};


// Enum  /Script/GameplayAbilities.EGameplayEffectDurationType
enum class EGameplayEffectDurationType : uint8_t
{
    Instant                                        = 0,
    Infinite                                       = 1,
    HasDuration                                    = 2,
    EGameplayEffectDurationType_MAX                = 3

};


// Enum  /Script/GameplayAbilities.EGameplayEffectScopedModifierAggregatorType
enum class EGameplayEffectScopedModifierAggregatorType : uint8_t
{
    CapturedAttributeBacked                        = 0,
    Transient                                      = 1,
    EGameplayEffectScopedModifierAggregatorType_MAX = 2

};


// Enum  /Script/GameplayAbilities.EAttributeBasedFloatCalculationType
enum class EAttributeBasedFloatCalculationType : uint8_t
{
    AttributeMagnitude                             = 0,
    AttributeBaseValue                             = 1,
    AttributeBonusMagnitude                        = 2,
    AttributeMagnitudeEvaluatedUpToChannel         = 3,
    EAttributeBasedFloatCalculationType_MAX        = 4

};


// Enum  /Script/GameplayAbilities.EGameplayEffectMagnitudeCalculation
enum class EGameplayEffectMagnitudeCalculation : uint8_t
{
    ScalableFloat                                  = 0,
    AttributeBased                                 = 1,
    CustomCalculationClass                         = 2,
    SetByCaller                                    = 3,
    SampleCurve                                    = 4,
    EGameplayEffectMagnitudeCalculation_MAX        = 5

};


// Enum  /Script/GameplayAbilities.EGameplayTagEventType
enum class EGameplayTagEventType : uint8_t
{
    NewOrRemoved                                   = 0,
    AnyCountChange                                 = 1,
    EGameplayTagEventType_MAX                      = 2

};


// Enum  /Script/GameplayAbilities.EGameplayEffectStackingType
enum class EGameplayEffectStackingType : uint8_t
{
    None                                           = 0,
    AggregateBySource                              = 1,
    AggregateByTarget                              = 2,
    EGameplayEffectStackingType_MAX                = 3

};


// Enum  /Script/GameplayAbilities.EGameplayModOp
enum class EGameplayModOp : uint8_t
{
    Additive                                       = 0,
    Multiplicitive                                 = 1,
    Productive                                     = 2,
    Division                                       = 3,
    Override                                       = 4,
    Max                                            = 5

};


// Enum  /Script/GameplayAbilities.EGameplayModEvaluationChannel
enum class EGameplayModEvaluationChannel : uint8_t
{
    Channel0                                       = 0,
    Channel1                                       = 1,
    Channel2                                       = 2,
    Channel3                                       = 3,
    Channel4                                       = 4,
    Channel5                                       = 5,
    Channel6                                       = 6,
    Channel7                                       = 7,
    Channel8                                       = 8,
    Channel9                                       = 9,
    Channel_MAX                                    = 10,
    EGameplayModEvaluationChannel_MAX              = 11

};


// Enum  /Script/GameplayAbilities.EAsyncPredictionType
enum class EAsyncPredictionType : uint8_t
{
    LocalPredict                                   = 0,
    ServerOnly                                     = 1,
    UseAsyncKeyPredict                             = 2,
    EAsyncPredictionType_MAX                       = 3

};


// Enum  /Script/Niagara.ENiagaraSystemSpawnSectionEndBehavior
enum class ENiagaraSystemSpawnSectionEndBehavior : uint8_t
{
    SetSystemInactive                              = 0,
    Deactivate                                     = 1,
    None                                           = 2,
    ENiagaraSystemSpawnSectionEndBehavior_MAX      = 3

};


// Enum  /Script/Niagara.ENiagaraSystemSpawnSectionEvaluateBehavior
enum class ENiagaraSystemSpawnSectionEvaluateBehavior : uint8_t
{
    ActivateIfInactive                             = 0,
    None                                           = 1,
    ENiagaraSystemSpawnSectionEvaluateBehavior_MAX = 2

};


// Enum  /Script/Niagara.ENiagaraSystemSpawnSectionStartBehavior
enum class ENiagaraSystemSpawnSectionStartBehavior : uint8_t
{
    Activate                                       = 0,
    ENiagaraSystemSpawnSectionStartBehavior_MAX    = 1

};


// Enum  /Script/Niagara.ENiagaraCollisionMode
enum class ENiagaraCollisionMode : uint8_t
{
    None                                           = 0,
    SceneGeometry                                  = 1,
    DepthBuffer                                    = 2,
    DistanceField                                  = 3,
    ENiagaraCollisionMode_MAX                      = 4

};


// Enum  /Script/Niagara.ENiagaraLegacyTrailWidthMode
enum class ENiagaraLegacyTrailWidthMode : uint8_t
{
    FromCentre                                     = 0,
    FromFirst                                      = 1,
    FromSecond                                     = 2,
    ENiagaraLegacyTrailWidthMode_MAX               = 3

};


// Enum  /Script/Niagara.ENiagaraRendererSourceDataMode
enum class ENiagaraRendererSourceDataMode : uint8_t
{
    Particles                                      = 0,
    Emitter                                        = 1,
    ENiagaraRendererSourceDataMode_MAX             = 2

};


// Enum  /Script/Niagara.ENiagaraBindingSource
enum class ENiagaraBindingSource : uint8_t
{
    ImplicitFromSource                             = 0,
    ExplicitParticles                              = 1,
    ExplicitEmitter                                = 2,
    ExplicitSystem                                 = 3,
    ExplicitUser                                   = 4,
    MaxBindingSource                               = 5,
    ENiagaraBindingSource_MAX                      = 6

};


// Enum  /Script/Niagara.ENiagaraIterationSource
enum class ENiagaraIterationSource : uint8_t
{
    Particles                                      = 0,
    DataInterface                                  = 1,
    ENiagaraIterationSource_MAX                    = 2

};


// Enum  /Script/Niagara.ENiagaraScriptGroup
enum class ENiagaraScriptGroup : uint8_t
{
    Particle                                       = 0,
    Emitter                                        = 1,
    System                                         = 2,
    Max                                            = 3

};


// Enum  /Script/Niagara.ENiagaraScriptContextStaticSwitch
enum class ENiagaraScriptContextStaticSwitch : uint8_t
{
    System                                         = 0,
    Emitter                                        = 1,
    Particle                                       = 2,
    ENiagaraScriptContextStaticSwitch_MAX          = 3

};


// Enum  /Script/Niagara.ENiagaraCompileUsageStaticSwitch
enum class ENiagaraCompileUsageStaticSwitch : uint8_t
{
    Spawn                                          = 0,
    Update                                         = 1,
    Event                                          = 2,
    SimulationStage                                = 3,
    Default                                        = 4,
    ENiagaraCompileUsageStaticSwitch_MAX           = 5

};


// Enum  /Script/Niagara.ENiagaraScriptUsage
enum class ENiagaraScriptUsage : uint8_t
{
    Function                                       = 0,
    Module                                         = 1,
    DynamicInput                                   = 2,
    ParticleSpawnScript                            = 3,
    ParticleSpawnScriptInterpolated                = 4,
    ParticleUpdateScript                           = 5,
    ParticleEventScript                            = 6,
    ParticleSimulationStageScript                  = 7,
    ParticleGPUComputeScript                       = 8,
    EmitterSpawnScript                             = 9,
    EmitterUpdateScript                            = 10,
    SystemSpawnScript                              = 11,
    SystemUpdateScript                             = 12,
    ENiagaraScriptUsage_MAX                        = 13

};


// Enum  /Script/Niagara.ENiagaraScriptCompileStatus
enum class ENiagaraScriptCompileStatus : uint8_t
{
    NCS_Unknown                                    = 0,
    NCS_Dirty                                      = 1,
    NCS_Error                                      = 2,
    NCS_UpToDate                                   = 3,
    NCS_BeingCreated                               = 4,
    NCS_UpToDateWithWarnings                       = 5,
    NCS_ComputeUpToDateWithWarnings                = 6,
    NCS_MAX                                        = 7

};


// Enum  /Script/Niagara.ENiagaraInputNodeUsage
enum class ENiagaraInputNodeUsage : uint8_t
{
    Undefined                                      = 0,
    Parameter                                      = 1,
    Attribute                                      = 2,
    SystemConstant                                 = 3,
    TranslatorConstant                             = 4,
    RapidIterationParameter                        = 5,
    ENiagaraInputNodeUsage_MAX                     = 6

};


// Enum  /Script/Niagara.ENiagaraDataSetType
enum class ENiagaraDataSetType : uint8_t
{
    ParticleData                                   = 0,
    Shared                                         = 1,
    Event                                          = 2,
    ENiagaraDataSetType_MAX                        = 3

};


// Enum  /Script/Niagara.ENiagaraStatDisplayMode
enum class ENiagaraStatDisplayMode : uint8_t
{
    Percent                                        = 0,
    Absolute                                       = 1,
    ENiagaraStatDisplayMode_MAX                    = 2

};


// Enum  /Script/Niagara.ENiagaraStatEvaluationType
enum class ENiagaraStatEvaluationType : uint8_t
{
    Average                                        = 0,
    Maximum                                        = 1,
    ENiagaraStatEvaluationType_MAX                 = 2

};


// Enum  /Script/Niagara.ENiagaraAgeUpdateMode
enum class ENiagaraAgeUpdateMode : uint8_t
{
    TickDeltaTime                                  = 0,
    DesiredAge                                     = 1,
    DesiredAgeNoSeek                               = 2,
    ENiagaraAgeUpdateMode_MAX                      = 3

};


// Enum  /Script/Niagara.ENiagaraSimTarget
enum class ENiagaraSimTarget : uint8_t
{
    CPUSim                                         = 0,
    GPUComputeSim                                  = 1,
    ENiagaraSimTarget_MAX                          = 2

};


// Enum  /Script/Niagara.ENiagaraDefaultMode
enum class ENiagaraDefaultMode : uint8_t
{
    Value                                          = 0,
    Binding                                        = 1,
    Custom                                         = 2,
    ENiagaraDefaultMode_MAX                        = 3

};


// Enum  /Script/Niagara.ENiagaraGpuBufferFormat
enum class ENiagaraGpuBufferFormat : uint8_t
{
    Float                                          = 0,
    HalfFloat                                      = 1,
    UnsignedNormalizedByte                         = 2,
    Max                                            = 3

};


// Enum  /Script/Niagara.ENiagaraTickBehavior
enum class ENiagaraTickBehavior : uint8_t
{
    UsePrereqs                                     = 0,
    UseComponentTickGroup                          = 1,
    ForceTickFirst                                 = 2,
    ForceTickLast                                  = 3,
    ENiagaraTickBehavior_MAX                       = 4

};


// Enum  /Script/Niagara.ENCPoolMethod
enum class ENCPoolMethod : uint8_t
{
    None                                           = 0,
    AutoRelease                                    = 1,
    ManualRelease                                  = 2,
    ManualRelease_OnComplete                       = 3,
    FreeInPool                                     = 4,
    ENCPoolMethod_MAX                              = 5

};


// Enum  /Script/Niagara.ENDIExport_GPUAllocationMode
enum class ENDIExport_GPUAllocationMode : uint8_t
{
    FixedSize                                      = 0,
    PerParticle                                    = 1,
    ENDIExport_MAX                                 = 2

};


// Enum  /Script/Niagara.ESetResolutionMethod
enum class ESetResolutionMethod : uint8_t
{
    Independent                                    = 0,
    MaxAxis                                        = 1,
    CellSize                                       = 2,
    ESetResolutionMethod_MAX                       = 3

};


// Enum  /Script/Niagara.ENDISkeletalMesh_SkinningMode
enum class ENDISkeletalMesh_SkinningMode : uint8_t
{
    Invalid                                        = 255,
    None                                           = 0,
    SkinOnTheFly                                   = 1,
    PreSkin                                        = 2,
    ENDISkeletalMesh_MAX                           = 256

};


// Enum  /Script/Niagara.ENDISkeletalMesh_SourceMode
enum class ENDISkeletalMesh_SourceMode : uint8_t
{
    Default                                        = 0,
    Source                                         = 1,
    AttachParent                                   = 2,
    ENDISkeletalMesh_MAX                           = 3

};


// Enum  /Script/Niagara.ENDIStaticMesh_SourceMode
enum class ENDIStaticMesh_SourceMode : uint8_t
{
    Default                                        = 0,
    Source                                         = 1,
    AttachParent                                   = 2,
    DefaultMeshOnly                                = 3,
    ENDIStaticMesh_MAX                             = 4

};


// Enum  /Script/Niagara.ENiagaraScalabilityUpdateFrequency
enum class ENiagaraScalabilityUpdateFrequency : uint8_t
{
    SpawnOnly                                      = 0,
    Low                                            = 1,
    Medium                                         = 2,
    High                                           = 3,
    Continuous                                     = 4,
    ENiagaraScalabilityUpdateFrequency_MAX         = 5

};


// Enum  /Script/Niagara.ENiagaraCullReaction
enum class ENiagaraCullReaction : uint8_t
{
    Deactivate                                     = 0,
    DeactivateImmediate                            = 1,
    DeactivateResume                               = 2,
    DeactivateImmediateResume                      = 3,
    PauseResume                                    = 4,
    ENiagaraCullReaction_MAX                       = 5

};


// Enum  /Script/Niagara.EParticleAllocationMode
enum class EParticleAllocationMode : uint8_t
{
    AutomaticEstimate                              = 0,
    ManualEstimate                                 = 1,
    EParticleAllocationMode_MAX                    = 2

};


// Enum  /Script/Niagara.EScriptExecutionMode
enum class EScriptExecutionMode : uint8_t
{
    EveryParticle                                  = 0,
    SpawnedParticles                               = 1,
    SingleParticle                                 = 2,
    EScriptExecutionMode_MAX                       = 3

};


// Enum  /Script/Niagara.ENiagaraSortMode
enum class ENiagaraSortMode : uint8_t
{
    None                                           = 0,
    ViewDepth                                      = 1,
    ViewDistance                                   = 2,
    CustomAscending                                = 3,
    CustomDecending                                = 4,
    ENiagaraSortMode_MAX                           = 5

};


// Enum  /Script/Niagara.ENiagaraMeshLockedAxisSpace
enum class ENiagaraMeshLockedAxisSpace : uint8_t
{
    Simulation                                     = 0,
    World                                          = 1,
    Local                                          = 2,
    ENiagaraMeshLockedAxisSpace_MAX                = 3

};


// Enum  /Script/Niagara.ENiagaraMeshPivotOffsetSpace
enum class ENiagaraMeshPivotOffsetSpace : uint8_t
{
    Mesh                                           = 0,
    Simulation                                     = 1,
    World                                          = 2,
    Local                                          = 3,
    ENiagaraMeshPivotOffsetSpace_MAX               = 4

};


// Enum  /Script/Niagara.ENiagaraMeshFacingMode
enum class ENiagaraMeshFacingMode : uint8_t
{
    Default                                        = 0,
    Velocity                                       = 1,
    CameraPosition                                 = 2,
    CameraPlane                                    = 3,
    ENiagaraMeshFacingMode_MAX                     = 4

};


// Enum  /Script/Niagara.ENiagaraPlatformSetState
enum class ENiagaraPlatformSetState : uint8_t
{
    Disabled                                       = 0,
    Enabled                                        = 1,
    Active                                         = 2,
    Unknown                                        = 3,
    ENiagaraPlatformSetState_MAX                   = 4

};


// Enum  /Script/Niagara.ENiagaraPlatformSelectionState
enum class ENiagaraPlatformSelectionState : uint8_t
{
    Default                                        = 0,
    Enabled                                        = 1,
    Disabled                                       = 2,
    ENiagaraPlatformSelectionState_MAX             = 3

};


// Enum  /Script/Niagara.ENiagaraPreviewGridResetMode
enum class ENiagaraPreviewGridResetMode : uint8_t
{
    Never                                          = 0,
    Individual                                     = 1,
    All                                            = 2,
    ENiagaraPreviewGridResetMode_MAX               = 3

};


// Enum  /Script/Niagara.ENiagaraRibbonUVDistributionMode
enum class ENiagaraRibbonUVDistributionMode : uint8_t
{
    ScaledUniformly                                = 0,
    ScaledUsingRibbonSegmentLength                 = 1,
    TiledOverRibbonLength                          = 2,
    ENiagaraRibbonUVDistributionMode_MAX           = 3

};


// Enum  /Script/Niagara.ENiagaraRibbonUVEdgeMode
enum class ENiagaraRibbonUVEdgeMode : uint8_t
{
    SmoothTransition                               = 0,
    Locked                                         = 1,
    ENiagaraRibbonUVEdgeMode_MAX                   = 2

};


// Enum  /Script/Niagara.ENiagaraRibbonTessellationMode
enum class ENiagaraRibbonTessellationMode : uint8_t
{
    Automatic                                      = 0,
    Custom                                         = 1,
    Disabled                                       = 2,
    ENiagaraRibbonTessellationMode_MAX             = 3

};


// Enum  /Script/Niagara.ENiagaraRibbonDrawDirection
enum class ENiagaraRibbonDrawDirection : uint8_t
{
    FrontToBack                                    = 0,
    BackToFront                                    = 1,
    ENiagaraRibbonDrawDirection_MAX                = 2

};


// Enum  /Script/Niagara.ENiagaraRibbonAgeOffsetMode
enum class ENiagaraRibbonAgeOffsetMode : uint8_t
{
    Scale                                          = 0,
    Clip                                           = 1,
    ENiagaraRibbonAgeOffsetMode_MAX                = 2

};


// Enum  /Script/Niagara.ENiagaraRibbonFacingMode
enum class ENiagaraRibbonFacingMode : uint8_t
{
    Screen                                         = 0,
    Custom                                         = 1,
    CustomSideVector                               = 2,
    CustomScreen                                   = 3,
    ENiagaraRibbonFacingMode_MAX                   = 4

};


// Enum  /Script/Niagara.ENiagaraScriptLibraryVisibility
enum class ENiagaraScriptLibraryVisibility : uint8_t
{
    Invalid                                        = 0,
    Unexposed                                      = 1,
    Library                                        = 2,
    Hidden                                         = 3,
    ENiagaraScriptLibraryVisibility_MAX            = 4

};


// Enum  /Script/Niagara.ENiagaraModuleDependencyScriptConstraint
enum class ENiagaraModuleDependencyScriptConstraint : uint8_t
{
    SameScript                                     = 0,
    AllScripts                                     = 1,
    ENiagaraModuleDependencyScriptConstraint_MAX   = 2

};


// Enum  /Script/Niagara.ENiagaraModuleDependencyType
enum class ENiagaraModuleDependencyType : uint8_t
{
    PreDependency                                  = 0,
    PostDependency                                 = 1,
    ENiagaraModuleDependencyType_MAX               = 2

};


// Enum  /Script/Niagara.EUnusedAttributeBehaviour
enum class EUnusedAttributeBehaviour : uint8_t
{
    Copy                                           = 0,
    Zero                                           = 1,
    None                                           = 2,
    MarkInvalid                                    = 3,
    PassThrough                                    = 4,
    EUnusedAttributeBehaviour_MAX                  = 5

};


// Enum  /Script/Niagara.ENiagaraSpriteFacingMode
enum class ENiagaraSpriteFacingMode : uint8_t
{
    FaceCamera                                     = 0,
    FaceCameraPlane                                = 1,
    CustomFacingVector                             = 2,
    FaceCameraPosition                             = 3,
    FaceCameraDistanceBlend                        = 4,
    ENiagaraSpriteFacingMode_MAX                   = 5

};


// Enum  /Script/Niagara.ENiagaraSpriteAlignment
enum class ENiagaraSpriteAlignment : uint8_t
{
    Unaligned                                      = 0,
    VelocityAligned                                = 1,
    CustomAlignment                                = 2,
    ENiagaraSpriteAlignment_MAX                    = 3

};


// Enum  /Script/Niagara.ENiagaraParameterPanelCategory
enum class ENiagaraParameterPanelCategory : uint8_t
{
    Input                                          = 0,
    Attributes                                     = 1,
    Output                                         = 2,
    Local                                          = 3,
    User                                           = 4,
    Engine                                         = 5,
    Owner                                          = 6,
    System                                         = 7,
    Emitter                                        = 8,
    Particles                                      = 9,
    ScriptTransient                                = 10,
    StaticSwitch                                   = 11,
    None                                           = 12,
    Num                                            = 13,
    ENiagaraParameterPanelCategory_MAX             = 14

};


// Enum  /Script/Niagara.ENiagaraScriptParameterUsage
enum class ENiagaraScriptParameterUsage : uint8_t
{
    Input                                          = 0,
    Output                                         = 1,
    Local                                          = 2,
    InputOutput                                    = 3,
    InitialValueInput                              = 4,
    None                                           = 5,
    Num                                            = 6,
    ENiagaraScriptParameterUsage_MAX               = 7

};


// Enum  /Script/Niagara.ENiagaraParameterScope
enum class ENiagaraParameterScope : uint8_t
{
    Input                                          = 0,
    User                                           = 1,
    Engine                                         = 2,
    Owner                                          = 3,
    System                                         = 4,
    Emitter                                        = 5,
    Particles                                      = 6,
    ScriptPersistent                               = 7,
    ScriptTransient                                = 8,
    Local                                          = 9,
    Custom                                         = 10,
    DISPLAY_ONLY_StaticSwitch                      = 11,
    Output                                         = 12,
    None                                           = 13,
    Num                                            = 14,
    ENiagaraParameterScope_MAX                     = 15

};


// Enum  /Script/Niagara.ENiagaraExecutionState
enum class ENiagaraExecutionState : uint8_t
{
    Active                                         = 0,
    Inactive                                       = 1,
    InactiveClear                                  = 2,
    Complete                                       = 3,
    Disabled                                       = 4,
    Num                                            = 5,
    ENiagaraExecutionState_MAX                     = 6

};


// Enum  /Script/Niagara.ENiagaraExecutionStateSource
enum class ENiagaraExecutionStateSource : uint8_t
{
    Scalability                                    = 0,
    Internal                                       = 1,
    Owner                                          = 2,
    InternalCompletion                             = 3,
    ENiagaraExecutionStateSource_MAX               = 4

};


// Enum  /Script/Niagara.ENiagaraNumericOutputTypeSelectionMode
enum class ENiagaraNumericOutputTypeSelectionMode : uint8_t
{
    None                                           = 0,
    Largest                                        = 1,
    Smallest                                       = 2,
    Scalar                                         = 3,
    ENiagaraNumericOutputTypeSelectionMode_MAX     = 4

};


// Enum  /Script/Niagara.ENiagaraVariantMode
enum class ENiagaraVariantMode : uint8_t
{
    None                                           = 0,
    Object                                         = 1,
    DataInterface                                  = 2,
    Bytes                                          = 3,
    ENiagaraVariantMode_MAX                        = 4

};


// Enum  /Script/NiagaraShader.FNiagaraCompileEventSeverity
enum class FNiagaraCompileEventSeverity : uint8_t
{
    Log                                            = 0,
    Warning                                        = 1,
    Error                                          = 2,
    FNiagaraCompileEventSeverity_MAX               = 3

};


// Enum  /Script/PatrolActionSystem.EEnemyActionFinishResult
enum class EEnemyActionFinishResult : uint8_t
{
    Success                                        = 0,
    Aborted                                        = 1,
    ConditionFailed                                = 2,
    EEnemyActionFinishResult_MAX                   = 3

};


// Enum  /Script/AIModule.EPathFollowingResult
enum class EPathFollowingResult : uint8_t
{
    Success                                        = 0,
    Blocked                                        = 1,
    OffPath                                        = 2,
    Aborted                                        = 3,
    Skipped_DEPRECATED                             = 4,
    Invalid                                        = 5,
    EPathFollowingResult_MAX                       = 6

};


// Enum  /Script/AIModule.EEnvQueryStatus
enum class EEnvQueryStatus : uint8_t
{
    Processing                                     = 0,
    Success                                        = 1,
    Failed                                         = 2,
    Aborted                                        = 3,
    OwnerLost                                      = 4,
    MissingParam                                   = 5,
    EEnvQueryStatus_MAX                            = 6

};


// Enum  /Script/PatrolActionSystem.EEnemyActionState
enum class EEnemyActionState : uint8_t
{
    ReadyForActivation                             = 0,
    Active                                         = 1,
    Aborting                                       = 2,
    EEnemyActionState_MAX                          = 3

};


// Enum  /Script/PatrolActionSystem.EPatrolMovementType
enum class EPatrolMovementType : uint8_t
{
    Clockwise                                      = 0,
    CounterClockwise                               = 1,
    EPatrolMovementType_MAX                        = 2

};


// Enum  /Script/PatrolActionSystem.EEnemyActionsExecutionType
enum class EEnemyActionsExecutionType : uint8_t
{
    RandomAction                                   = 0,
    AllInTurn                                      = 1,
    EEnemyActionsExecutionType_MAX                 = 2

};


// Enum  /Script/ControlRig.EControlRigComponentMapDirection
enum class EControlRigComponentMapDirection : uint8_t
{
    Input                                          = 0,
    Output                                         = 1,
    EControlRigComponentMapDirection_MAX           = 2

};


// Enum  /Script/ControlRig.EControlRigComponentSpace
enum class EControlRigComponentSpace : uint8_t
{
    WorldSpace                                     = 0,
    ActorSpace                                     = 1,
    ComponentSpace                                 = 2,
    RigSpace                                       = 3,
    LocalSpace                                     = 4,
    Max                                            = 5

};


// Enum  /Script/ControlRig.ERigExecutionType
enum class ERigExecutionType : uint8_t
{
    Runtime                                        = 0,
    Editing                                        = 1,
    Max                                            = 2

};


// Enum  /Script/ControlRig.EBoneGetterSetterMode
enum class EBoneGetterSetterMode : uint8_t
{
    LocalSpace                                     = 0,
    GlobalSpace                                    = 1,
    Max                                            = 2

};


// Enum  /Script/ControlRig.ETransformGetterType
enum class ETransformGetterType : uint8_t
{
    Initial                                        = 0,
    Current                                        = 1,
    Max                                            = 2

};


// Enum  /Script/ControlRig.EControlRigClampSpatialMode
enum class EControlRigClampSpatialMode : uint8_t
{
    Plane                                          = 0,
    Cylinder                                       = 1,
    Sphere                                         = 2,
    EControlRigClampSpatialMode_MAX                = 3

};


// Enum  /Script/ControlRig.ETransformSpaceMode
enum class ETransformSpaceMode : uint8_t
{
    LocalSpace                                     = 0,
    GlobalSpace                                    = 1,
    BaseSpace                                      = 2,
    BaseJoint                                      = 3,
    Max                                            = 4

};


// Enum  /Script/ControlRig.EControlRigDrawSettings
enum class EControlRigDrawSettings : uint8_t
{
    Points                                         = 0,
    Lines                                          = 1,
    LineStrip                                      = 2,
    DynamicMesh                                    = 3,
    EControlRigDrawSettings_MAX                    = 4

};


// Enum  /Script/ControlRig.EControlRigDrawHierarchyMode
enum class EControlRigDrawHierarchyMode : uint8_t
{
    Axes                                           = 0,
    Max                                            = 1

};


// Enum  /Script/ControlRig.EControlRigAnimEasingType
enum class EControlRigAnimEasingType : uint8_t
{
    Linear                                         = 0,
    QuadraticEaseIn                                = 1,
    QuadraticEaseOut                               = 2,
    QuadraticEaseInOut                             = 3,
    CubicEaseIn                                    = 4,
    CubicEaseOut                                   = 5,
    CubicEaseInOut                                 = 6,
    QuarticEaseIn                                  = 7,
    QuarticEaseOut                                 = 8,
    QuarticEaseInOut                               = 9,
    QuinticEaseIn                                  = 10,
    QuinticEaseOut                                 = 11,
    QuinticEaseInOut                               = 12,
    SineEaseIn                                     = 13,
    SineEaseOut                                    = 14,
    SineEaseInOut                                  = 15,
    CircularEaseIn                                 = 16,
    CircularEaseOut                                = 17,
    CircularEaseInOut                              = 18,
    ExponentialEaseIn                              = 19,
    ExponentialEaseOut                             = 20,
    ExponentialEaseInOut                           = 21,
    ElasticEaseIn                                  = 22,
    ElasticEaseOut                                 = 23,
    ElasticEaseInOut                               = 24,
    BackEaseIn                                     = 25,
    BackEaseOut                                    = 26,
    BackEaseInOut                                  = 27,
    BounceEaseIn                                   = 28,
    BounceEaseOut                                  = 29,
    BounceEaseInOut                                = 30,
    EControlRigAnimEasingType_MAX                  = 31

};


// Enum  /Script/ControlRig.EControlRigRotationOrder
enum class EControlRigRotationOrder : uint8_t
{
    XYZ                                            = 0,
    XZY                                            = 1,
    YXZ                                            = 2,
    YZX                                            = 3,
    ZXY                                            = 4,
    ZYX                                            = 5,
    EControlRigRotationOrder_MAX                   = 6

};


// Enum  /Script/ControlRig.ECRSimPointIntegrateType
enum class ECRSimPointIntegrateType : uint8_t
{
    Verlet                                         = 0,
    SemiExplicitEuler                              = 1,
    ECRSimPointIntegrateType_MAX                   = 2

};


// Enum  /Script/ControlRig.ECRSimConstraintType
enum class ECRSimConstraintType : uint8_t
{
    Distance                                       = 0,
    DistanceFromA                                  = 1,
    DistanceFromB                                  = 2,
    Plane                                          = 3,
    ECRSimConstraintType_MAX                       = 4

};


// Enum  /Script/ControlRig.ECRSimPointForceType
enum class ECRSimPointForceType : uint8_t
{
    Direction                                      = 0,
    ECRSimPointForceType_MAX                       = 1

};


// Enum  /Script/ControlRig.ECRSimSoftCollisionType
enum class ECRSimSoftCollisionType : uint8_t
{
    Plane                                          = 0,
    Sphere                                         = 1,
    Cone                                           = 2,
    ECRSimSoftCollisionType_MAX                    = 3

};


// Enum  /Script/ControlRig.EControlRigFKRigExecuteMode
enum class EControlRigFKRigExecuteMode : uint8_t
{
    Replace                                        = 0,
    Additive                                       = 1,
    Max                                            = 2

};


// Enum  /Script/ControlRig.ERigBoneType
enum class ERigBoneType : uint8_t
{
    Imported                                       = 0,
    User                                           = 1,
    ERigBoneType_MAX                               = 2

};


// Enum  /Script/ControlRig.ERigControlAxis
enum class ERigControlAxis : uint8_t
{
    X                                              = 0,
    Y                                              = 1,
    Z                                              = 2,
    ERigControlAxis_MAX                            = 3

};


// Enum  /Script/ControlRig.ERigControlValueType
enum class ERigControlValueType : uint8_t
{
    Initial                                        = 0,
    Current                                        = 1,
    Minimum                                        = 2,
    Maximum                                        = 3,
    ERigControlValueType_MAX                       = 4

};


// Enum  /Script/ControlRig.ERigControlType
enum class ERigControlType : uint8_t
{
    Bool                                           = 0,
    Float                                          = 1,
    Integer                                        = 2,
    Vector2D                                       = 3,
    Position                                       = 4,
    Scale                                          = 5,
    Rotator                                        = 6,
    Transform                                      = 7,
    TransformNoScale                               = 8,
    EulerTransform                                 = 9,
    ERigControlType_MAX                            = 10

};


// Enum  /Script/ControlRig.ERigHierarchyImportMode
enum class ERigHierarchyImportMode : uint8_t
{
    Append                                         = 0,
    Replace                                        = 1,
    ReplaceLocalTransform                          = 2,
    ReplaceGlobalTransform                         = 3,
    Max                                            = 4

};


// Enum  /Script/ControlRig.EControlRigSetKey
enum class EControlRigSetKey : uint8_t
{
    DoNotCare                                      = 0,
    Always                                         = 1,
    Never                                          = 2,
    EControlRigSetKey_MAX                          = 3

};


// Enum  /Script/ControlRig.ERigEvent
enum class ERigEvent : uint8_t
{
    None                                           = 0,
    RequestAutoKey                                 = 1,
    Max                                            = 2

};


// Enum  /Script/ControlRig.ERigElementType
enum class ERigElementType : uint8_t
{
    None                                           = 0,
    Bone                                           = 1,
    Space                                          = 2,
    Control                                        = 4,
    Curve                                          = 8,
    All                                            = 15,
    ERigElementType_MAX                            = 16

};


// Enum  /Script/ControlRig.ERigSpaceType
enum class ERigSpaceType : uint8_t
{
    Global                                         = 0,
    Bone                                           = 1,
    Control                                        = 2,
    Space                                          = 3,
    ERigSpaceType_MAX                              = 4

};


// Enum  /Script/ControlRig.EAimMode
enum class EAimMode : uint8_t
{
    AimAtTarget                                    = 0,
    OrientToTarget                                 = 1,
    MAX                                            = 2

};


// Enum  /Script/ControlRig.EApplyTransformMode
enum class EApplyTransformMode : uint8_t
{
    Override                                       = 0,
    Additive                                       = 1,
    Max                                            = 2

};


// Enum  /Script/ControlRig.ERigUnitDebugPointMode
enum class ERigUnitDebugPointMode : uint8_t
{
    Point                                          = 0,
    Vector                                         = 1,
    Max                                            = 2

};


// Enum  /Script/ControlRig.ERigUnitDebugTransformMode
enum class ERigUnitDebugTransformMode : uint8_t
{
    Point                                          = 0,
    Axes                                           = 1,
    Box                                            = 2,
    Max                                            = 3

};


// Enum  /Script/ControlRig.EControlRigCurveAlignment
enum class EControlRigCurveAlignment : uint8_t
{
    Front                                          = 0,
    Stretched                                      = 1,
    EControlRigCurveAlignment_MAX                  = 2

};


// Enum  /Script/ControlRig.EControlRigVectorKind
enum class EControlRigVectorKind : uint8_t
{
    Direction                                      = 0,
    Location                                       = 1,
    EControlRigVectorKind_MAX                      = 2

};


// Enum  /Script/ControlRig.ERBFVectorDistanceType
enum class ERBFVectorDistanceType : uint8_t
{
    Euclidean                                      = 0,
    Manhattan                                      = 1,
    ArcLength                                      = 2,
    ERBFVectorDistanceType_MAX                     = 3

};


// Enum  /Script/ControlRig.ERBFQuatDistanceType
enum class ERBFQuatDistanceType : uint8_t
{
    Euclidean                                      = 0,
    ArcLength                                      = 1,
    SwingAngle                                     = 2,
    TwistAngle                                     = 3,
    ERBFQuatDistanceType_MAX                       = 4

};


// Enum  /Script/ControlRig.ERBFKernelType
enum class ERBFKernelType : uint8_t
{
    Gaussian                                       = 0,
    Exponential                                    = 1,
    Linear                                         = 2,
    Cubic                                          = 3,
    Quintic                                        = 4,
    ERBFKernelType_MAX                             = 5

};


// Enum  /Script/ControlRig.EControlRigModifyBoneMode
enum class EControlRigModifyBoneMode : uint8_t
{
    OverrideLocal                                  = 0,
    OverrideGlobal                                 = 1,
    AdditiveLocal                                  = 2,
    AdditiveGlobal                                 = 3,
    Max                                            = 4

};


// Enum  /Script/ControlRig.ERigUnitVisualDebugPointMode
enum class ERigUnitVisualDebugPointMode : uint8_t
{
    Point                                          = 0,
    Vector                                         = 1,
    Max                                            = 2

};


// Enum  /Script/ControlRig.EControlRigState
enum class EControlRigState : uint8_t
{
    Init                                           = 0,
    Update                                         = 1,
    Invalid                                        = 2,
    EControlRigState_MAX                           = 3

};


// Enum  /Script/OodleNetworkHandlerComponent.EOodleEnableMode
enum class EOodleEnableMode : uint8_t
{
    AlwaysEnabled                                  = 0,
    WhenCompressedPacketReceived                   = 1,
    EOodleEnableMode_MAX                           = 2

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniStaticMeshMethod
enum class EHoudiniStaticMeshMethod : uint8_t
{
    RawMesh                                        = 0,
    FMeshDescription                               = 1,
    UHoudiniStaticMesh                             = 2,
    EHoudiniStaticMeshMethod_MAX                   = 3

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniAssetStateResult
enum class EHoudiniAssetStateResult : uint8_t
{
    None                                           = 0,
    Working                                        = 1,
    Success                                        = 2,
    FinishedWithError                              = 3,
    FinishedWithFatalError                         = 4,
    Aborted                                        = 5,
    EHoudiniAssetStateResult_MAX                   = 6

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniAssetState
enum class EHoudiniAssetState : uint8_t
{
    NeedInstantiation                              = 0,
    NewHDA                                         = 1,
    PreInstantiation                               = 2,
    Instantiating                                  = 3,
    PreCook                                        = 4,
    Cooking                                        = 5,
    PostCook                                       = 6,
    PreProcess                                     = 7,
    Processing                                     = 8,
    None                                           = 9,
    NeedRebuild                                    = 10,
    NeedDelete                                     = 11,
    Deleting                                       = 12,
    ProcessTemplate                                = 13,
    EHoudiniAssetState_MAX                         = 14

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniProxyRefineRequestResult
enum class EHoudiniProxyRefineRequestResult : uint8_t
{
    Invalid                                        = 0,
    None                                           = 1,
    PendingCooks                                   = 2,
    Refined                                        = 3,
    EHoudiniProxyRefineRequestResult_MAX           = 4

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniProxyRefineResult
enum class EHoudiniProxyRefineResult : uint8_t
{
    Invalid                                        = 0,
    Failed                                         = 1,
    Success                                        = 2,
    Skipped                                        = 3,
    EHoudiniProxyRefineResult_MAX                  = 4

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniLandscapeExportType
enum class EHoudiniLandscapeExportType : uint8_t
{
    Heightfield                                    = 0,
    Mesh                                           = 1,
    Points                                         = 2,
    EHoudiniLandscapeExportType_MAX                = 3

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniCurveBreakpointParameterization
enum class EHoudiniCurveBreakpointParameterization : uint32_t
{
    Invalid                                        = 4294967295,
    Uniform                                        = 0,
    Chord                                          = 1,
    Centripetal                                    = 2,
    EHoudiniCurveBreakpointParameterization_MAX    = 3

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniCurveMethod
enum class EHoudiniCurveMethod : uint32_t
{
    Invalid                                        = 4294967295,
    CVs                                            = 0,
    Breakpoints                                    = 1,
    Freehand                                       = 2,
    EHoudiniCurveMethod_MAX                        = 3

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniCurveType
enum class EHoudiniCurveType : uint32_t
{
    Invalid                                        = 4294967295,
    Polygon                                        = 0,
    Nurbs                                          = 1,
    Bezier                                         = 2,
    Points                                         = 3,
    EHoudiniCurveType_MAX                          = 4

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniOutputType
enum class EHoudiniOutputType : uint8_t
{
    Invalid                                        = 0,
    Mesh                                           = 1,
    Instancer                                      = 2,
    Landscape                                      = 3,
    Curve                                          = 4,
    Skeletal                                       = 5,
    GeometryCollection                             = 6,
    EHoudiniOutputType_MAX                         = 7

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniInputType
enum class EHoudiniInputType : uint8_t
{
    Invalid                                        = 0,
    Geometry                                       = 1,
    Curve                                          = 2,
    Asset                                          = 3,
    Landscape                                      = 4,
    World                                          = 5,
    Skeletal                                       = 6,
    GeometryCollection                             = 7,
    EHoudiniInputType_MAX                          = 8

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniLandscapeOutputBakeType
enum class EHoudiniLandscapeOutputBakeType : uint8_t
{
    Detachment                                     = 0,
    BakeToImage                                    = 1,
    BakeToWorld                                    = 2,
    InValid                                        = 3,
    EHoudiniLandscapeOutputBakeType_MAX            = 4

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniRampInterpolationType
enum class EHoudiniRampInterpolationType : uint32_t
{
    InValid                                        = 4294967295,
    CONSTANT                                       = 0,
    LINEAR                                         = 1,
    CATMULL_ROM                                    = 2,
    MONOTONE_CUBIC                                 = 3,
    BEZIER                                         = 4,
    BSPLINE                                        = 5,
    HERMITE                                        = 6,
    EHoudiniRampInterpolationType_MAX              = 7

};


// Enum  /Script/HoudiniEngineRuntime.EAttribOwner
enum class EAttribOwner : uint32_t
{
    Invalid                                        = 4294967295,
    Vertex                                         = 0,
    Point                                          = 1,
    Prim                                           = 2,
    Detail                                         = 3,
    EAttribOwner_MAX                               = 4

};


// Enum  /Script/HoudiniEngineRuntime.EAttribStorageType
enum class EAttribStorageType : uint32_t
{
    Invalid                                        = 4294967295,
    INT                                            = 0,
    INT64                                          = 1,
    FLOAT                                          = 2,
    FLOAT64                                        = 3,
    STRING                                         = 4,
    EAttribStorageType_MAX                         = 5

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniInstancerType
enum class EHoudiniInstancerType : uint8_t
{
    Invalid                                        = 0,
    ObjectInstancer                                = 1,
    PackedPrimitive                                = 2,
    AttributeInstancer                             = 3,
    OldSchoolAttributeInstancer                    = 4,
    GeometryCollection                             = 5,
    EHoudiniInstancerType_MAX                      = 6

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniPartType
enum class EHoudiniPartType : uint8_t
{
    Invalid                                        = 0,
    Mesh                                           = 1,
    Instancer                                      = 2,
    Curve                                          = 3,
    Volume                                         = 4,
    EHoudiniPartType_MAX                           = 5

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniGeoType
enum class EHoudiniGeoType : uint8_t
{
    Invalid                                        = 0,
    Default                                        = 1,
    Intermediate                                   = 2,
    Input                                          = 3,
    Curve                                          = 4,
    EHoudiniGeoType_MAX                            = 5

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniHandleType
enum class EHoudiniHandleType : uint8_t
{
    Xform                                          = 0,
    Bounder                                        = 1,
    Unsupported                                    = 2,
    EHoudiniHandleType_MAX                         = 3

};


// Enum  /Script/HoudiniEngineRuntime.EXformParameter
enum class EXformParameter : uint8_t
{
    TX                                             = 0,
    TY                                             = 1,
    TZ                                             = 2,
    RX                                             = 3,
    RY                                             = 4,
    RZ                                             = 5,
    SX                                             = 6,
    SY                                             = 7,
    SZ                                             = 8,
    COUNT                                          = 9,
    EXformParameter_MAX                            = 10

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniInputObjectType
enum class EHoudiniInputObjectType : uint8_t
{
    Invalid                                        = 0,
    Object                                         = 1,
    StaticMesh                                     = 2,
    SkeletalMesh                                   = 3,
    SceneComponent                                 = 4,
    StaticMeshComponent                            = 5,
    InstancedStaticMeshComponent                   = 6,
    SplineComponent                                = 7,
    HoudiniSplineComponent                         = 8,
    HoudiniAssetComponent                          = 9,
    Actor                                          = 10,
    Landscape                                      = 11,
    Brush                                          = 12,
    CameraComponent                                = 13,
    DataTable                                      = 14,
    HoudiniAssetActor                              = 15,
    FoliageType_InstancedStaticMesh                = 16,
    GeometryCollection                             = 17,
    GeometryCollectionComponent                    = 18,
    GeometryCollectionActor_Deprecated             = 19,
    SkeletalMeshComponent                          = 20,
    Blueprint                                      = 21,
    EHoudiniInputObjectType_MAX                    = 22

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniXformType
enum class EHoudiniXformType : uint8_t
{
    None                                           = 0,
    IntoThisObject                                 = 1,
    Auto                                           = 2,
    EHoudiniXformType_MAX                          = 3

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniCurveOutputType
enum class EHoudiniCurveOutputType : uint8_t
{
    UnrealSpline                                   = 0,
    HoudiniSpline                                  = 1,
    EHoudiniCurveOutputType_MAX                    = 2

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniParameterType
enum class EHoudiniParameterType : uint8_t
{
    Invalid                                        = 0,
    Button                                         = 1,
    ButtonStrip                                    = 2,
    Color                                          = 3,
    ColorRamp                                      = 4,
    File                                           = 5,
    FileDir                                        = 6,
    FileGeo                                        = 7,
    FileImage                                      = 8,
    Float                                          = 9,
    FloatRamp                                      = 10,
    Folder                                         = 11,
    FolderList                                     = 12,
    Input                                          = 13,
    Int                                            = 14,
    IntChoice                                      = 15,
    Label                                          = 16,
    MultiParm                                      = 17,
    Separator                                      = 18,
    String                                         = 19,
    StringChoice                                   = 20,
    StringAssetRef                                 = 21,
    Toggle                                         = 22,
    EHoudiniParameterType_MAX                      = 23

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniFolderParameterType
enum class EHoudiniFolderParameterType : uint8_t
{
    Invalid                                        = 0,
    Collapsible                                    = 1,
    Simple                                         = 2,
    Tabs                                           = 3,
    Radio                                          = 4,
    Other                                          = 5,
    EHoudiniFolderParameterType_MAX                = 6

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniMultiParmModificationType
enum class EHoudiniMultiParmModificationType : uint8_t
{
    None                                           = 0,
    Inserted                                       = 1,
    Removed                                        = 2,
    Modified                                       = 3,
    EHoudiniMultiParmModificationType_MAX          = 4

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniRampPointConstructStatus
enum class EHoudiniRampPointConstructStatus : uint8_t
{
    None                                           = 0,
    INITIALIZED                                    = 1,
    POSITION_INSERTED                              = 2,
    VALUE_INSERTED                                 = 3,
    INTERPTYPE_INSERTED                            = 4,
    EHoudiniRampPointConstructStatus_MAX           = 5

};


// Enum  /Script/HoudiniEngineRuntime.EPDGWorkResultState
enum class EPDGWorkResultState : uint8_t
{
    None                                           = 0,
    ToLoad                                         = 1,
    Loading                                        = 2,
    Loaded                                         = 3,
    ToDelete                                       = 4,
    Deleting                                       = 5,
    Deleted                                        = 6,
    NotLoaded                                      = 7,
    EPDGWorkResultState_MAX                        = 8

};


// Enum  /Script/HoudiniEngineRuntime.EPDGNodeState
enum class EPDGNodeState : uint8_t
{
    None                                           = 0,
    Dirtied                                        = 1,
    Dirtying                                       = 2,
    Cooking                                        = 3,
    Cook_Complete                                  = 4,
    Cook_Failed                                    = 5,
    EPDGNodeState_MAX                              = 6

};


// Enum  /Script/HoudiniEngineRuntime.EPDGLinkState
enum class EPDGLinkState : uint8_t
{
    Inactive                                       = 0,
    Linking                                        = 1,
    Linked                                         = 2,
    Error_Not_Linked                               = 3,
    EPDGLinkState_MAX                              = 4

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniExecutableType
enum class EHoudiniExecutableType : uint8_t
{
    HRSHE_Houdini                                  = 0,
    HRSHE_HoudiniFX                                = 1,
    HRSHE_HoudiniCore                              = 2,
    HRSHE_HoudiniIndie                             = 3,
    HRSHE_MAX                                      = 4

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniRuntimeSettingsRecomputeFlag
enum class EHoudiniRuntimeSettingsRecomputeFlag : uint8_t
{
    HRSRF_Always                                   = 0,
    HRSRF_OnlyIfMissing                            = 1,
    HRSRF_Never                                    = 2,
    HRSRF_MAX                                      = 3

};


// Enum  /Script/HoudiniEngineRuntime.EHoudiniRuntimeSettingsSessionType
enum class EHoudiniRuntimeSettingsSessionType : uint8_t
{
    HRSST_InProcess                                = 0,
    HRSST_Socket                                   = 1,
    HRSST_NamedPipe                                = 2,
    HRSST_None                                     = 3,
    HRSST_MAX                                      = 4

};


// Enum  /Script/ACLPlugin.ACLCompressionLevel
enum class ACLCompressionLevel : uint8_t
{
    ACLCL_Lowest                                   = 0,
    ACLCL_Low                                      = 1,
    ACLCL_Medium                                   = 2,
    ACLCL_High                                     = 3,
    ACLCL_Highest                                  = 4,
    ACLCL_MAX                                      = 5

};


// Enum  /Script/ACLPlugin.ACLVectorFormat
enum class ACLVectorFormat : uint8_t
{
    ACLVF_Vector3                                  = 0,
    ACLVF_Vector3_Variable                         = 1,
    ACLVF_Vector3_MAX                              = 2

};


// Enum  /Script/ACLPlugin.ACLRotationFormat
enum class ACLRotationFormat : uint8_t
{
    ACLRF_Quat                                     = 0,
    ACLRF_QuatDropW                                = 1,
    ACLRF_QuatDropW_Variable                       = 2,
    ACLRF_MAX                                      = 3

};


// Enum  /Script/ACLPlugin.ACLVisualFidelityChangeResult
enum class ACLVisualFidelityChangeResult : uint8_t
{
    Dispatched                                     = 0,
    Completed                                      = 1,
    Failed                                         = 2,
    ACLVisualFidelityChangeResult_MAX              = 3

};


// Enum  /Script/ACLPlugin.ACLVisualFidelity
enum class ACLVisualFidelity : uint8_t
{
    Highest                                        = 0,
    Medium                                         = 1,
    Lowest                                         = 2,
    ACLVisualFidelity_MAX                          = 3

};


// Enum  /Script/CoverBase.EAICoverLeanPose
enum class EAICoverLeanPose : uint8_t
{
    ECoverLeanPose_None                            = 0,
    ECoverLeanPose_Left                            = 1,
    ECoverLeanPose_Right                           = 2,
    ECoverLeanPose_MAX                             = 3

};


// Enum  /Script/CoverBase.EAICoverType
enum class EAICoverType : uint8_t
{
    ECoverType_None                                = 0,
    ECoverType_Standard                            = 1,
    ECoverType_Low                                 = 2,
    ECoverType_MAX                                 = 3

};


// Enum  /Script/CoverBase.EAICoverActionDirection
enum class EAICoverActionDirection : uint8_t
{
    ECoverAD_None                                  = 0,
    ECoverAD_Up                                    = 1,
    ECoverAD_Right                                 = 2,
    ECoverAD_Left                                  = 3,
    ECoverAD_MAX                                   = 4

};


// Enum  /Script/CoverBase.EAICoverActionType
enum class EAICoverActionType : uint8_t
{
    ECoverAction_None                              = 0,
    ECoverAction_EnterCover_Start                  = 1,
    ECoverAction_Cover_Idle                        = 2,
    ECoverAction_ExitCover                         = 3,
    ECoverAction_EnterCoverPeek                    = 4,
    ECoverAction_Cover_PeekIdle                    = 5,
    ECoverAction_ExitCoverPeek                     = 6,
    ECoverAction_EnterCoverFire                    = 7,
    ECoverAction_Cover_FireIdle                    = 8,
    ECoverAction_ExitCoverFire                     = 9,
    ECoverAction_EnterCoverBlind                   = 10,
    ECoverAction_Cover_BlindIdle                   = 11,
    ECoverAction_ExitCoverBlind                    = 12,
    ECoverAction_Cover_SwitchIdle                  = 13,
    ECoverAction_MAX                               = 14

};


// Enum  /Script/CoverBase.ECoverLerpMoveType
enum class ECoverLerpMoveType : uint8_t
{
    ECMLT_None                                     = 0,
    ECMLT_Forward                                  = 1,
    ECMLT_Lean                                     = 2,
    ECMLT_MAX                                      = 3

};


// Enum  /Script/CoverBase.ECoverFlags
enum class ECoverFlags : uint32_t
{
    None                                           = 0,
    ECF_Crounching                                 = 1,
    ECF_Standing                                   = 2,
    ECF_Crounch_LeftShoot                          = 4,
    ECF_Crounch_RightShoot                         = 8,
    ECF_Crounch_FrontShoot                         = 16,
    ECF_Stand_LeftShoot                            = 32,
    ECF_Stand_RightShoot                           = 64,
    ECF_Attack_Point                               = 128,
    ECF_Turn_Point                                 = 256,
    ECF_Custom                                     = 512,
    ECF_Secondary_Jump                             = 1024,
    ECF_PostProcess_Point                          = 2048,
    ECoverFlags_MAX                                = 2049

};


// Enum  /Script/CoverBase.ECoverShootType
enum class ECoverShootType : uint8_t
{
    ECST_None                                      = 0,
    ECST_StandingLeft                              = 1,
    ECST_StandingRight                             = 2,
    ECST_CrouchingRight                            = 3,
    ECST_CrouchingLeft                             = 4,
    ECST_CrouchingFront                            = 5,
    ECST_MAX                                       = 6

};


// Enum  /Script/CoverBase.ECVFlg
enum class ECVFlg : uint8_t
{
    Include                                        = 0,
    Exclude                                        = 1,
    Debug                                          = 2,
    Disabled                                       = 3,
    ECVFlg_MAX                                     = 4

};


// Enum  /Script/CoverBase.ECoverScorerType
enum class ECoverScorerType : uint8_t
{
    None                                           = 0,
    Distance                                       = 1,
    Hide                                           = 2,
    Composite                                      = 3,
    ECoverScorerType_MAX                           = 4

};


// Enum  /Script/Formation.EMemberState
enum class EMemberState : uint8_t
{
    Free                                           = 0,
    Follow                                         = 1,
    Leader                                         = 2,
    EMemberState_MAX                               = 3

};


// Enum  /Script/AkAudio.EAkCallbackType
enum class EAkCallbackType : uint8_t
{
    EndOfEvent                                     = 0,
    Marker                                         = 2,
    Duration                                       = 3,
    Starvation                                     = 5,
    MusicPlayStarted                               = 7,
    MusicSyncBeat                                  = 8,
    MusicSyncBar                                   = 9,
    MusicSyncEntry                                 = 10,
    MusicSyncExit                                  = 11,
    MusicSyncGrid                                  = 12,
    MusicSyncUserCue                               = 13,
    MusicSyncPoint                                 = 14,
    MIDIEvent                                      = 16,
    EAkCallbackType_MAX                            = 17

};


// Enum  /Script/AkAudio.EAkResult
enum class EAkResult : uint8_t
{
    NotImplemented                                 = 0,
    Success                                        = 1,
    Fail                                           = 2,
    PartialSuccess                                 = 3,
    NotCompatible                                  = 4,
    AlreadyConnected                               = 5,
    InvalidFile                                    = 7,
    AudioFileHeaderTooLarge                        = 8,
    MaxReached                                     = 9,
    InvalidID                                      = 14,
    IDNotFound                                     = 15,
    InvalidInstanceID                              = 16,
    NoMoreData                                     = 17,
    InvalidStateGroup                              = 20,
    ChildAlreadyHasAParent                         = 21,
    InvalidLanguage                                = 22,
    CannotAddItseflAsAChild                        = 23,
    InvalidParameter                               = 31,
    ElementAlreadyInList                           = 35,
    PathNotFound                                   = 36,
    PathNoVertices                                 = 37,
    PathNotRunning                                 = 38,
    PathNotPaused                                  = 39,
    PathNodeAlreadyInList                          = 40,
    PathNodeNotInList                              = 41,
    DataNeeded                                     = 43,
    NoDataNeeded                                   = 44,
    DataReady                                      = 45,
    NoDataReady                                    = 46,
    InsufficientMemory                             = 52,
    Cancelled                                      = 53,
    UnknownBankID                                  = 54,
    BankReadError                                  = 56,
    InvalidSwitchType                              = 57,
    FormatNotReady                                 = 63,
    WrongBankVersion                               = 64,
    FileNotFound                                   = 66,
    DeviceNotReady                                 = 67,
    BankAlreadyLoaded                              = 69,
    RenderedFX                                     = 71,
    ProcessNeeded                                  = 72,
    ProcessDone                                    = 73,
    MemManagerNotInitialized                       = 74,
    StreamMgrNotInitialized                        = 75,
    SSEInstructionsNotSupported                    = 76,
    Busy                                           = 77,
    UnsupportedChannelConfig                       = 78,
    PluginMediaNotAvailable                        = 79,
    MustBeVirtualized                              = 80,
    CommandTooLarge                                = 81,
    RejectedByFilter                               = 82,
    InvalidCustomPlatformName                      = 83,
    DLLCannotLoad                                  = 84,
    DLLPathNotFound                                = 85,
    NoJavaVM                                       = 86,
    OpenSLError                                    = 87,
    PluginNotRegistered                            = 88,
    DataAlignmentError                             = 89,
    EAkResult_MAX                                  = 90

};


// Enum  /Script/AkAudio.EAkAndroidAudioAPI
enum class EAkAndroidAudioAPI : uint8_t
{
    AAudio                                         = 0,
    OpenSL_ES                                      = 1,
    EAkAndroidAudioAPI_MAX                         = 2

};


// Enum  /Script/AkAudio.EAkAudioSessionMode
enum class EAkAudioSessionMode : uint8_t
{
    Default                                        = 0,
    VoiceChat                                      = 1,
    GameChat                                       = 2,
    VideoRecording                                 = 3,
    Measurement                                    = 4,
    MoviePlayback                                  = 5,
    VideoChat                                      = 6,
    EAkAudioSessionMode_MAX                        = 7

};


// Enum  /Script/AkAudio.EAkAudioSessionCategoryOptions
enum class EAkAudioSessionCategoryOptions : uint8_t
{
    MixWithOthers                                  = 0,
    DuckOthers                                     = 1,
    AllowBluetooth                                 = 2,
    DefaultToSpeaker                               = 3,
    EAkAudioSessionCategoryOptions_MAX             = 4

};


// Enum  /Script/AkAudio.EAkAudioSessionCategory
enum class EAkAudioSessionCategory : uint8_t
{
    Ambient                                        = 0,
    SoloAmbient                                    = 1,
    PlayAndRecord                                  = 2,
    EAkAudioSessionCategory_MAX                    = 3

};


// Enum  /Script/AkAudio.EAkShape
enum class EAkShape : uint8_t
{
    EAkShape_Point                                 = 0,
    EAkShape_Box                                   = 1,
    EAkShape_Sphere                                = 2,
    EAkShape_MultiPoint                            = 3,
    EAkShape_MAX                                   = 4

};


// Enum  /Script/AkAudio.EReflectionFilterBits
enum class EReflectionFilterBits : uint8_t
{
    Wall                                           = 0,
    Ceiling                                        = 1,
    Floor                                          = 2,
    EReflectionFilterBits_MAX                      = 3

};


// Enum  /Script/AkAudio.AkCodecId
enum class AkCodecId : uint8_t
{
    None                                           = 0,
    PCM                                            = 1,
    ADPCM                                          = 2,
    XMA                                            = 3,
    Vorbis                                         = 4,
    AAC                                            = 10,
    ATRAC9                                         = 12,
    OpusNX                                         = 17,
    AkOpus                                         = 19,
    AkOpusWEM                                      = 20,
    AkCodecId_MAX                                  = 21

};


// Enum  /Script/AkAudio.EAkMidiCcValues
enum class EAkMidiCcValues : uint8_t
{
    AkMidiCcBankSelectCoarse                       = 0,
    AkMidiCcModWheelCoarse                         = 1,
    AkMidiCcBreathCtrlCoarse                       = 2,
    AkMidiCcCtrl3Coarse                            = 3,
    AkMidiCcFootPedalCoarse                        = 4,
    AkMidiCcPortamentoCoarse                       = 5,
    AkMidiCcDataEntryCoarse                        = 6,
    AkMidiCcVolumeCoarse                           = 7,
    AkMidiCcBalanceCoarse                          = 8,
    AkMidiCcCtrl9Coarse                            = 9,
    AkMidiCcPanPositionCoarse                      = 10,
    AkMidiCcExpressionCoarse                       = 11,
    AkMidiCcEffectCtrl1Coarse                      = 12,
    AkMidiCcEffectCtrl2Coarse                      = 13,
    AkMidiCcCtrl14Coarse                           = 14,
    AkMidiCcCtrl15Coarse                           = 15,
    AkMidiCcGenSlider1                             = 16,
    AkMidiCcGenSlider2                             = 17,
    AkMidiCcGenSlider3                             = 18,
    AkMidiCcGenSlider4                             = 19,
    AkMidiCcCtrl20Coarse                           = 20,
    AkMidiCcCtrl21Coarse                           = 21,
    AkMidiCcCtrl22Coarse                           = 22,
    AkMidiCcCtrl23Coarse                           = 23,
    AkMidiCcCtrl24Coarse                           = 24,
    AkMidiCcCtrl25Coarse                           = 25,
    AkMidiCcCtrl26Coarse                           = 26,
    AkMidiCcCtrl27Coarse                           = 27,
    AkMidiCcCtrl28Coarse                           = 28,
    AkMidiCcCtrl29Coarse                           = 29,
    AkMidiCcCtrl30Coarse                           = 30,
    AkMidiCcCtrl31Coarse                           = 31,
    AkMidiCcBankSelectFine                         = 32,
    AkMidiCcModWheelFine                           = 33,
    AkMidiCcBreathCtrlFine                         = 34,
    AkMidiCcCtrl3Fine                              = 35,
    AkMidiCcFootPedalFine                          = 36,
    AkMidiCcPortamentoFine                         = 37,
    AkMidiCcDataEntryFine                          = 38,
    AkMidiCcVolumeFine                             = 39,
    AkMidiCcBalanceFine                            = 40,
    AkMidiCcCtrl9Fine                              = 41,
    AkMidiCcPanPositionFine                        = 42,
    AkMidiCcExpressionFine                         = 43,
    AkMidiCcEffectCtrl1Fine                        = 44,
    AkMidiCcEffectCtrl2Fine                        = 45,
    AkMidiCcCtrl14Fine                             = 46,
    AkMidiCcCtrl15Fine                             = 47,
    AkMidiCcCtrl20Fine                             = 52,
    AkMidiCcCtrl21Fine                             = 53,
    AkMidiCcCtrl22Fine                             = 54,
    AkMidiCcCtrl23Fine                             = 55,
    AkMidiCcCtrl24Fine                             = 56,
    AkMidiCcCtrl25Fine                             = 57,
    AkMidiCcCtrl26Fine                             = 58,
    AkMidiCcCtrl27Fine                             = 59,
    AkMidiCcCtrl28Fine                             = 60,
    AkMidiCcCtrl29Fine                             = 61,
    AkMidiCcCtrl30Fine                             = 62,
    AkMidiCcCtrl31Fine                             = 63,
    AkMidiCcHoldPedal                              = 64,
    AkMidiCcPortamentoOnOff                        = 65,
    AkMidiCcSustenutoPedal                         = 66,
    AkMidiCcSoftPedal                              = 67,
    AkMidiCcLegatoPedal                            = 68,
    AkMidiCcHoldPedal2                             = 69,
    AkMidiCcSoundVariation                         = 70,
    AkMidiCcSoundTimbre                            = 71,
    AkMidiCcSoundReleaseTime                       = 72,
    AkMidiCcSoundAttackTime                        = 73,
    AkMidiCcSoundBrightness                        = 74,
    AkMidiCcSoundCtrl6                             = 75,
    AkMidiCcSoundCtrl7                             = 76,
    AkMidiCcSoundCtrl8                             = 77,
    AkMidiCcSoundCtrl9                             = 78,
    AkMidiCcSoundCtrl10                            = 79,
    AkMidiCcGeneralButton1                         = 80,
    AkMidiCcGeneralButton2                         = 81,
    AkMidiCcGeneralButton3                         = 82,
    AkMidiCcGeneralButton4                         = 83,
    AkMidiCcReverbLevel                            = 91,
    AkMidiCcTremoloLevel                           = 92,
    AkMidiCcChorusLevel                            = 93,
    AkMidiCcCelesteLevel                           = 94,
    AkMidiCcPhaserLevel                            = 95,
    AkMidiCcDataButtonP1                           = 96,
    AkMidiCcDataButtonM1                           = 97,
    AkMidiCcNonRegisterCoarse                      = 98,
    AkMidiCcNonRegisterFine                        = 99,
    AkMidiCcAllSoundOff                            = 120,
    AkMidiCcAllControllersOff                      = 121,
    AkMidiCcLocalKeyboard                          = 122,
    AkMidiCcAllNotesOff                            = 123,
    AkMidiCcOmniModeOff                            = 124,
    AkMidiCcOmniModeOn                             = 125,
    AkMidiCcOmniMonophonicOn                       = 126,
    AkMidiCcOmniPolyphonicOn                       = 127,
    EAkMidiCcValues_MAX                            = 128

};


// Enum  /Script/AkAudio.EAkMidiEventType
enum class EAkMidiEventType : uint8_t
{
    AkMidiEventTypeInvalid                         = 0,
    AkMidiEventTypeNoteOff                         = 128,
    AkMidiEventTypeNoteOn                          = 144,
    AkMidiEventTypeNoteAftertouch                  = 160,
    AkMidiEventTypeController                      = 176,
    AkMidiEventTypeProgramChange                   = 192,
    AkMidiEventTypeChannelAftertouch               = 208,
    AkMidiEventTypePitchBend                       = 224,
    AkMidiEventTypeSysex                           = 240,
    AkMidiEventTypeEscape                          = 247,
    AkMidiEventTypeMeta                            = 255,
    EAkMidiEventType_MAX                           = 256

};


// Enum  /Script/AkAudio.ERTPCValueType
enum class ERTPCValueType : uint8_t
{
    Default                                        = 0,
    Global                                         = 1,
    GameObject                                     = 2,
    PlayingID                                      = 3,
    Unavailable                                    = 4,
    ERTPCValueType_MAX                             = 5

};


// Enum  /Script/AkAudio.EAkCurveInterpolation
enum class EAkCurveInterpolation : uint8_t
{
    Log3                                           = 0,
    Sine                                           = 1,
    Log1                                           = 2,
    InvSCurve                                      = 3,
    Linear                                         = 4,
    SCurve                                         = 5,
    Exp1                                           = 6,
    SineRecip                                      = 7,
    Exp3                                           = 8,
    LastFadeCurve                                  = 8,
    Constant                                       = 9,
    EAkCurveInterpolation_MAX                      = 10

};


// Enum  /Script/AkAudio.AkActionOnEventType
enum class AkActionOnEventType : uint8_t
{
    Stop                                           = 0,
    Pause                                          = 1,
    Resume                                         = 2,
    Break                                          = 3,
    ReleaseEnvelope                                = 4,
    AkActionOnEventType_MAX                        = 5

};


// Enum  /Script/AkAudio.AkMultiPositionType
enum class AkMultiPositionType : uint8_t
{
    SingleSource                                   = 0,
    MultiSources                                   = 1,
    MultiDirections                                = 2,
    AkMultiPositionType_MAX                        = 3

};


// Enum  /Script/AkAudio.AkSpeakerConfiguration
enum class AkSpeakerConfiguration : uint32_t
{
    Ak_Speaker_Front_Left                          = 1,
    Ak_Speaker_Front_Right                         = 2,
    Ak_Speaker_Front_Center                        = 4,
    Ak_Speaker_Low_Frequency                       = 8,
    Ak_Speaker_Back_Left                           = 16,
    Ak_Speaker_Back_Right                          = 32,
    Ak_Speaker_Back_Center                         = 256,
    Ak_Speaker_Side_Left                           = 512,
    Ak_Speaker_Side_Right                          = 1024,
    Ak_Speaker_Top                                 = 2048,
    Ak_Speaker_Height_Front_Left                   = 4096,
    Ak_Speaker_Height_Front_Center                 = 8192,
    Ak_Speaker_Height_Front_Right                  = 16384,
    Ak_Speaker_Height_Back_Left                    = 32768,
    Ak_Speaker_Height_Back_Center                  = 65536,
    Ak_Speaker_Height_Back_Right                   = 131072,
    Ak_Speaker_MAX                                 = 131073

};


// Enum  /Script/AkAudio.AkChannelConfiguration
enum class AkChannelConfiguration : uint8_t
{
    Ak_Parent                                      = 0,
    Ak_LFE                                         = 1,
    Ak_1                                           = 2,
    Ak_2                                           = 3,
    Ak_2                                           = 4,
    Ak_3                                           = 5,
    Ak_3                                           = 6,
    Ak_4                                           = 7,
    Ak_4                                           = 8,
    Ak_5                                           = 9,
    Ak_5                                           = 10,
    Ak_7                                           = 11,
    Ak_5_1                                         = 12,
    Ak_7_1                                         = 13,
    Ak_7_1                                         = 14,
    Ak_Auro_9                                      = 15,
    Ak_Auro_10                                     = 16,
    Ak_Auro_11                                     = 17,
    Ak_Auro_13                                     = 18,
    Ak_Ambisonics_1st_order                        = 19,
    Ak_Ambisonics_2nd_order                        = 20,
    Ak_Ambisonics_3rd_order                        = 21,
    Ak_MAX                                         = 22

};


// Enum  /Script/AkAudio.AkOcclusionPortalType
enum class AkOcclusionPortalType : uint8_t
{
    Vertical                                       = 0,
    Horizontal                                     = 1,
    AkOcclusionPortalType_MAX                      = 2

};


// Enum  /Script/AkAudio.AkAcousticPortalState
enum class AkAcousticPortalState : uint8_t
{
    Closed                                         = 0,
    Open                                           = 1,
    AkAcousticPortalState_MAX                      = 2

};


// Enum  /Script/AkAudio.PanningRule
enum class PanningRule : uint8_t
{
    PanningRule_Speakers                           = 0,
    PanningRule_Headphones                         = 1,
    PanningRule_MAX                                = 2

};


// Enum  /Script/AkAudio.AkMeshType
enum class AkMeshType : uint8_t
{
    StaticMesh                                     = 0,
    CollisionMesh                                  = 1,
    AkMeshType_MAX                                 = 2

};


// Enum  /Script/AkAudio.EAkHololensAudioAPI
enum class EAkHololensAudioAPI : uint8_t
{
    Wasapi                                         = 0,
    XAudio2                                        = 1,
    DirectSound                                    = 2,
    EAkHololensAudioAPI_MAX                        = 3

};


// Enum  /Script/AkAudio.EAkCommSystem
enum class EAkCommSystem : uint8_t
{
    Socket                                         = 0,
    HTCS                                           = 1,
    EAkCommSystem_MAX                              = 2

};


// Enum  /Script/AkAudio.EAkChannelMask
enum class EAkChannelMask : uint8_t
{
    FrontLeft                                      = 0,
    FrontRight                                     = 1,
    FrontCenter                                    = 2,
    LowFrequency                                   = 3,
    BackLeft                                       = 4,
    BackRight                                      = 5,
    BackCenter                                     = 8,
    SideLeft                                       = 9,
    SideRight                                      = 10,
    Top                                            = 11,
    HeightFrontLeft                                = 12,
    HeightFrontCenter                              = 13,
    HeightFrontRight                               = 14,
    HeightBackLeft                                 = 15,
    HeightBackCenter                               = 16,
    HeightBackRight                                = 17,
    EAkChannelMask_MAX                             = 18

};


// Enum  /Script/AkAudio.EAkChannelConfigType
enum class EAkChannelConfigType : uint8_t
{
    Anonymous                                      = 0,
    Standard                                       = 1,
    Ambisonic                                      = 2,
    EAkChannelConfigType_MAX                       = 3

};


// Enum  /Script/AkAudio.EAkDiffractionFlags
enum class EAkDiffractionFlags : uint8_t
{
    UseBuiltInParam                                = 0,
    UseObstruction                                 = 1,
    CalcEmitterVirtualPosition                     = 3,
    EAkDiffractionFlags_MAX                        = 4

};


// Enum  /Script/AkAudio.EAkPanningRule
enum class EAkPanningRule : uint8_t
{
    Speakers                                       = 0,
    Headphones                                     = 1,
    EAkPanningRule_MAX                             = 2

};


// Enum  /Script/AkAudio.EObstructionFace
enum class EObstructionFace : uint8_t
{
    Face0                                          = 1,
    Face1                                          = 2,
    Face2                                          = 4,
    Face3                                          = 8,
    Face4                                          = 16,
    Face5                                          = 32,
    EObstructionFace_MAX                           = 33

};


// Enum  /Script/AkAudio.EAkWindowsAudioAPI
enum class EAkWindowsAudioAPI : uint8_t
{
    Wasapi                                         = 0,
    XAudio2                                        = 1,
    DirectSound                                    = 2,
    EAkWindowsAudioAPI_MAX                         = 3

};


// Enum  /Script/slua_unreal.EPropertyClass
enum class EPropertyClass : uint8_t
{
    Byte                                           = 0,
    Int8                                           = 1,
    Int16                                          = 2,
    Int                                            = 3,
    Int64                                          = 4,
    UInt16                                         = 5,
    UInt32                                         = 6,
    UInt64                                         = 7,
    UnsizedInt                                     = 8,
    UnsizedUInt                                    = 9,
    Float                                          = 10,
    Double                                         = 11,
    Bool                                           = 12,
    SoftClass                                      = 13,
    WeakObject                                     = 14,
    LazyObject                                     = 15,
    SoftObject                                     = 16,
    Class                                          = 17,
    Object                                         = 18,
    Interface                                      = 19,
    Name                                           = 20,
    Str                                            = 21,
    Array                                          = 22,
    Map                                            = 23,
    Set                                            = 24,
    Struct                                         = 25,
    Delegate                                       = 26,
    MulticastDelegate                              = 27,
    Text                                           = 28,
    Enum                                           = 29,
    MAX                                            = 30

};


// Enum  /Script/DecisionAI.EAIActorPhaseType
enum class EAIActorPhaseType : uint8_t
{
    None                                           = 0,
    Hold                                           = 1,
    Release                                        = 2,
    Active                                         = 3,
    EAIActorPhaseType_MAX                          = 4

};


// Enum  /Script/DecisionAI.EAIAbilityReleaseTargetType
enum class EAIAbilityReleaseTargetType : uint8_t
{
    None                                           = 0,
    TeammateCharacter                              = 1,
    EnemyCharacter                                 = 2,
    TeammateTombstone                              = 3,
    EnemyTombstone                                 = 4,
    TargetActorWithTag                             = 5,
    EAIAbilityReleaseTargetType_MAX                = 6

};


// Enum  /Script/DecisionAI.EAIAbilityMoveType
enum class EAIAbilityMoveType : uint8_t
{
    None                                           = 0,
    MoveToDodge                                    = 1,
    MoveToCoverPoint                               = 2,
    MoveToCastAttackEnemyLocation                  = 3,
    MoveToSpikePlantLocation                       = 4,
    MoveToZoomConnectLocation                      = 5,
    MoveToNearestAirDoor                           = 6,
    MoveToAllyTombstone                            = 7,
    MoveToTargetActor                              = 8,
    EAIAbilityMoveType_MAX                         = 9

};


// Enum  /Script/DecisionAI.EAIAbilitySecondActivationType
enum class EAIAbilitySecondActivationType : uint8_t
{
    None                                           = 0,
    SpikePlantEnemy                                = 1,
    SpikePlantBothSide                             = 2,
    MarkEnemy                                      = 3,
    EnemyAround                                    = 4,
    EAIAbilitySecondActivationType_MAX             = 5

};


// Enum  /Script/DecisionAI.EAIAbilityBehaviorType
enum class EAIAbilityBehaviorType : uint8_t
{
    None                                           = 0,
    AttackEnemy                                    = 1,
    OutOfCoverWithAbility                          = 2,
    PathObstruction                                = 3,
    Blinding                                       = 4,
    HealingSelf                                    = 5,
    SpikePlant                                     = 6,
    SmokeEnemyProbableDangerZone                   = 7,
    DetectEnemy                                    = 8,
    ObstructionEnemyProbableDangerZone             = 9,
    RemoteDetectEnemy                              = 10,
    ObstructionAirDoorInFightStart                 = 11,
    AirDoorSetInBuyPhase                           = 12,
    Resurrection                                   = 13,
    SprintToEnemy                                  = 14,
    AddBuff                                        = 15,
    BanishmentSpikeArea                            = 16,
    HealingOther                                   = 17,
    EAIAbilityBehaviorType_MAX                     = 18

};


// Enum  /Script/DecisionAI.EBPAIAbilityEffectType
enum class EBPAIAbilityEffectType : uint8_t
{
    None                                           = 0,
    Damage                                         = 1,
    Heal                                           = 2,
    Revive                                         = 3,
    Block                                          = 4,
    SightLimit                                     = 5,
    Buff                                           = 6,
    Debuff                                         = 7,
    Move                                           = 8,
    Sense                                          = 9,
    Scout                                          = 10,
    Avatar                                         = 11,
    Fake                                           = 12,
    Invisible                                      = 13,
    Berserk                                        = 14,
    Trap                                           = 15,
    SlowDown                                       = 16,
    EBPAIAbilityEffectType_MAX                     = 17

};


// Enum  /Script/DecisionAI.EAIAbilityTargetType
enum class EAIAbilityTargetType : uint8_t
{
    Enemy                                          = 0,
    Friend                                         = 1,
    Me                                             = 2,
    Max                                            = 3

};


// Enum  /Script/DecisionAI.EAICmdType
enum class EAICmdType : uint8_t
{
    None                                           = 0,
    Turn                                           = 1,
    MoveTo                                         = 2,
    MoveRight                                      = 3,
    MoveForward                                    = 4,
    MoveUp                                         = 5,
    PauseMove                                      = 6,
    Posture                                        = 7,
    FireWeapon                                     = 8,
    EquipWeapon                                    = 9,
    ScopeInWeapon                                  = 10,
    ReloadWeapon                                   = 11,
    Buy                                            = 12,
    FetchBomb                                      = 13,
    PlantBomb                                      = 14,
    DefuseBomb                                     = 15,
    OccupyCover                                    = 16,
    OccupyAirDoor                                  = 17,
    Crouch                                         = 18,
    UnCrouch                                       = 19,
    AbilityInput                                   = 20,
    PickUp                                         = 21,
    OperateInteractItem                            = 22,
    HitDamage                                      = 23,
    MoveJoyStickCmd                                = 24,
    EAICmdType_MAX                                 = 25

};


// Enum  /Script/DecisionAI.EAIOpType
enum class EAIOpType : uint8_t
{
    None                                           = 0,
    On                                             = 1,
    Off                                            = 2,
    ReOn                                           = 3,
    EAIOpType_MAX                                  = 4

};


// Enum  /Script/DecisionAI.EPauseMoveType
enum class EPauseMoveType : uint8_t
{
    Pause                                          = 0,
    Resume                                         = 1,
    Stop                                           = 2,
    EPauseMoveType_MAX                             = 3

};


// Enum  /Script/DecisionAI.EAICmdResult
enum class EAICmdResult : uint8_t
{
    Failed                                         = 0,
    Success                                        = 1,
    InProgress                                     = 2,
    EAICmdResult_MAX                               = 3

};


// Enum  /Script/DecisionAI.EAIConfigAssetType
enum class EAIConfigAssetType : uint8_t
{
    DecisionAIConfig                               = 0,
    AISenseConfig                                  = 1,
    EAIConfigAssetType_MAX                         = 2

};


// Enum  /Script/DecisionAI.EAITestPathType
enum class EAITestPathType : uint8_t
{
    NavmeshRaycast2D                               = 0,
    HierarchicalQuery                              = 1,
    RegularPathFinding                             = 2,
    EAITestPathType_MAX                            = 3

};


// Enum  /Script/DecisionAI.EShootPart
enum class EShootPart : uint8_t
{
    None                                           = 0,
    HEAD                                           = 1,
    UPPER                                          = 2,
    LOWER                                          = 3,
    EShootPart_MAX                                 = 4

};


// Enum  /Script/DecisionAI.ESmartObjType
enum class ESmartObjType : uint8_t
{
    None                                           = 0,
    SmartLink                                      = 1,
    SmartLink_ObstacleArea                         = 2,
    ESmartObjType_MAX                              = 3

};


// Enum  /Script/DecisionAI.ECustomerRouteType
enum class ECustomerRouteType : uint8_t
{
    None                                           = 0,
    BombSiteA                                      = 1,
    BombSiteB                                      = 2,
    BombSiteC                                      = 3,
    Mid                                            = 4,
    Max                                            = 5

};


// Enum  /Script/DecisionAI.EAIPeekBehaviourAction
enum class EAIPeekBehaviourAction : uint8_t
{
    None                                           = 0,
    Check                                          = 1,
    MoveToPeekLocation                             = 2,
    PeekInCover                                    = 3,
    PeekOutCover                                   = 4,
    EAIPeekBehaviourAction_MAX                     = 5

};


// Enum  /Script/DecisionAI.EAIBehaviourType
enum class EAIBehaviourType : uint8_t
{
    None                                           = 0,
    Peek                                           = 1,
    Max                                            = 2

};


// Enum  /Script/DecisionAI.EAITacticRouteAction
enum class EAITacticRouteAction : uint8_t
{
    None                                           = 0,
    Check                                          = 1,
    Detect                                         = 2,
    Camping                                        = 3,
    Ability                                        = 4,
    MoveAlongRoute                                 = 5,
    EAITacticRouteAction_MAX                       = 6

};


// Enum  /Script/DecisionAI.EAIGeneralPeekAction
enum class EAIGeneralPeekAction : uint8_t
{
    None                                           = 0,
    MoveToCover                                    = 1,
    HideInCover                                    = 2,
    MoveOutCover                                   = 3,
    EAIGeneralPeekAction_MAX                       = 4

};


// Enum  /Script/DecisionAI.EAIPeekStatusType
enum class EAIPeekStatusType : uint8_t
{
    None                                           = 0,
    MoveToCover                                    = 1,
    PeekFromCover                                  = 2,
    PeekToCover                                    = 3,
    AttackPhase                                    = 4,
    WaitInCover                                    = 5,
    EndPeek                                        = 6,
    EAIPeekStatusType_MAX                          = 7

};


// Enum  /Script/DecisionAI.EPushAction
enum class EPushAction : uint8_t
{
    None                                           = 0,
    MoveToAirDoor                                  = 1,
    SearchHoldLocations                            = 2,
    MoveToDefend                                   = 4,
    Aim                                            = 8,
    MoveToTargetZone                               = 16,
    EPushAction_MAX                                = 17

};


// Enum  /Script/DecisionAI.EHoldSiteAction
enum class EHoldSiteAction : uint8_t
{
    None                                           = 0,
    MoveToHold                                     = 1,
    Hold                                           = 2,
    MoveToAim                                      = 4,
    Aim                                            = 8,
    EHoldSiteAction_MAX                            = 9

};


// Enum  /Script/DecisionAI.EAIHangoutType
enum class EAIHangoutType : uint8_t
{
    None                                           = 0,
    Walk                                           = 1,
    Stop                                           = 2,
    EAIHangoutType_MAX                             = 3

};


// Enum  /Script/DecisionAI.EAIPracticeWeaponType
enum class EAIPracticeWeaponType : uint8_t
{
    None                                           = 0,
    ContinuousShoot                                = 1,
    TriggerShoot                                   = 2,
    LongTimeShoot                                  = 4,
    EAIPracticeWeaponType_MAX                      = 5

};


// Enum  /Script/DecisionAI.EAIAttackNearbyType
enum class EAIAttackNearbyType : uint8_t
{
    None                                           = 0,
    LocalAttack                                    = 1,
    ChaseToAttack                                  = 2,
    WalkToAttack                                   = 4,
    EAIAttackNearbyType_MAX                        = 5

};


// Enum  /Script/DecisionAI.EAILookAtType
enum class EAILookAtType : uint8_t
{
    None                                           = 0,
    LookAround                                     = 1,
    Crouch                                         = 2,
    EAILookAtType_MAX                              = 3

};


// Enum  /Script/DecisionAI.EAIInterActAction
enum class EAIInterActAction : uint8_t
{
    None                                           = 0,
    LookAtTeamate                                  = 1,
    AttackTeamate                                  = 2,
    AttackNearby                                   = 4,
    EAIInterActAction_MAX                          = 5

};


// Enum  /Script/DecisionAI.EAIPerformAction
enum class EAIPerformAction : uint8_t
{
    None                                           = 0,
    InterActWithTeamate                            = 1,
    PracticeWeapon                                 = 2,
    AttackGate                                     = 4,
    Hangout                                        = 8,
    Daze                                           = 16,
    EAIPerformAction_MAX                           = 17

};


// Enum  /Script/DecisionAI.EAIDodgeByCoverAction
enum class EAIDodgeByCoverAction : uint8_t
{
    None                                           = 0,
    SearchDodgeCover                               = 1,
    MoveToHide                                     = 2,
    HideForAWhile                                  = 4,
    MoveOut                                        = 8,
    Attack                                         = 16,
    EAIDodgeByCoverAction_MAX                      = 17

};


// Enum  /Script/DecisionAI.EAIAmbushGoal
enum class EAIAmbushGoal : uint8_t
{
    None                                           = 0,
    ProtectBomb                                    = 1,
    ProtectPickUpBomb                              = 2,
    ProtectBombArea                                = 3,
    AmbushInnerExtendAbility                       = 4,
    EAIAmbushGoal_MAX                              = 5

};


// Enum  /Script/DecisionAI.EAIAmbushAction
enum class EAIAmbushAction : uint8_t
{
    None                                           = 0,
    MoveToAmbush                                   = 10,
    Ambush                                         = 11,
    HeadForAmbushCover                             = 1,
    HideInAmbushCover                              = 2,
    MoveOutAmbushCover                             = 4,
    Aim                                            = 8,
    EAIAmbushAction_MAX                            = 12

};


// Enum  /Script/DecisionAI.EZoneGraphMapName
enum class EZoneGraphMapName : uint8_t
{
    None                                           = 0,
    Ascent_A                                       = 1,
    Ascent                                         = 2,
    Ascent_RE                                      = 3,
    Bind_A                                         = 4,
    Bind                                           = 5,
    IceBox                                         = 6,
    Haven                                          = 7,
    Split                                          = 8,
    Breeze                                         = 9,
    Fracture                                       = 10,
    UnitTest                                       = 11,
    Lotus                                          = 12,
    Pearl                                          = 13,
    EZoneGraphMapName_MAX                          = 14

};


// Enum  /Script/DecisionAI.EConnectorType
enum class EConnectorType : uint8_t
{
    None                                           = 0,
    NeutralToDefuseBombSide                        = 1,
    PlantBombSideToNeutral                         = 2,
    ToBombSite                                     = 3,
    All                                            = 4,
    EConnectorType_MAX                             = 5

};


// Enum  /Script/DecisionAI.EDangerZoneType
enum class EDangerZoneType : uint8_t
{
    None                                           = 0,
    Neutral                                        = 1,
    PlantBombSide                                  = 2,
    DefuseBombSide                                 = 3,
    EDangerZoneType_MAX                            = 4

};


// Enum  /Script/DecisionAI.ECaptainType
enum class ECaptainType : uint8_t
{
    None                                           = 0,
    Default                                        = 1,
    Fast                                           = 2,
    Feint                                          = 3,
    AttackerPlentyKill                             = 4,
    ECaptainType_MAX                               = 5

};


// Enum  /Script/DecisionAI.EAvoidShootPart
enum class EAvoidShootPart : uint8_t
{
    None                                           = 0,
    Left                                           = 1,
    Right                                          = 2,
    Up                                             = 3,
    EAvoidShootPart_MAX                            = 4

};


// Enum  /Script/DecisionAI.ECommandPhase
enum class ECommandPhase : uint8_t
{
    CommandPhase_None                              = 0,
    CommandPhase_Diverge                           = 1,
    CommandPhase_Assemble                          = 2,
    CommandPhase_Rush                              = 3,
    CommandPhase_Ambush                            = 4,
    CommandPhase_DefuseBomb                        = 5,
    CommandPhase_Defender_HoldSite                 = 6,
    CommandPhase_Defender_FindEnemyToSuicide       = 7,
    CommandPhase_MAX                               = 8

};


// Enum  /Script/DecisionAI.EHoldSiteRouteType
enum class EHoldSiteRouteType : uint8_t
{
    None                                           = 0,
    ExtendProtect                                  = 1,
    NormalProtect                                  = 2,
    ShrinkProtect                                  = 3,
    EHoldSiteRouteType_MAX                         = 4

};


// Enum  /Script/DecisionAI.EAbilityTacticDest
enum class EAbilityTacticDest : uint8_t
{
    None                                           = 0,
    Center                                         = 1,
    Source                                         = 2,
    Dest                                           = 3,
    EAbilityTacticDest_MAX                         = 4

};


// Enum  /Script/DecisionAI.EAIPeekType
enum class EAIPeekType : uint8_t
{
    None                                           = 0,
    AttackPeek                                     = 1,
    DangerPeek                                     = 2,
    JumpPeek                                       = 3,
    Max                                            = 4

};


// Enum  /Script/DecisionAI.ETacticPhase
enum class ETacticPhase : uint8_t
{
    None                                           = 0,
    Prepare                                        = 1,
    ReleaseAbility                                 = 2,
    Monitor                                        = 3,
    FollowUp                                       = 4,
    ETacticPhase_MAX                               = 5

};


// Enum  /Script/DecisionAI.EAIFetchBombTypeInReadyPhase
enum class EAIFetchBombTypeInReadyPhase : uint8_t
{
    None                                           = 0,
    StandAlone                                     = 1,
    RandomMove                                     = 2,
    GoToAirDoor                                    = 3,
    Max                                            = 4

};


// Enum  /Script/DecisionAI.EAIBoolType
enum class EAIBoolType : uint8_t
{
    None                                           = 0,
    OverrideTrue                                   = 1,
    OverrideFalse                                  = 2,
    EAIBoolType_MAX                                = 3

};


// Enum  /Script/DecisionAI.ESmartTransitionReEstimateEventType
enum class ESmartTransitionReEstimateEventType : uint8_t
{
    None                                           = 0,
    ReadyPhaseStart                                = 1,
    FightPhaseStart                                = 2,
    EnemySpotByMySelf                              = 3,
    StoppedFightingWithEnemy                       = 4,
    AllTeamMateDied                                = 5,
    SpikePlantedByMyTeam                           = 6,
    SpikePlantedByEnemyTeam                        = 7,
    StartDefusingSpikeByMyTeam                     = 8,
    StartDefusingSpikeByEnemyTeam                  = 9,
    ESmartTransitionReEstimateEventType_MAX        = 10

};


// Enum  /Script/DecisionAI.EAIPlayStyle
enum class EAIPlayStyle : uint8_t
{
    None                                           = 0,
    Duel                                           = 1,
    ControlField                                   = 2,
    Ranger                                         = 3,
    EAIPlayStyle_MAX                               = 4

};


// Enum  /Script/DecisionAI.EAIPersonalStyle
enum class EAIPersonalStyle : uint8_t
{
    None                                           = 0,
    Star                                           = 1,
    Warrior                                        = 2,
    Partner                                        = 3,
    EAIPersonalStyle_MAX                           = 4

};


// Enum  /Script/DecisionAI.EStateFactorType
enum class EStateFactorType : uint8_t
{
    None                                           = 0,
    ONE_HOT                                        = 1,
    BOOLEAN                                        = 2,
    REAL                                           = 3,
    EStateFactorType_MAX                           = 4

};


// Enum  /Script/DecisionAI.EStateFactorRouteType
enum class EStateFactorRouteType : uint8_t
{
    InValid                                        = 0,
    AttackerAttack                                 = 1,
    AttackerRotate                                 = 2,
    AttackerPickUp                                 = 3,
    DefenderRetake                                 = 4,
    DefenderFLank                                  = 5,
    Max                                            = 6

};


// Enum  /Script/DecisionAI.EStateFactorInteractIForTDM
enum class EStateFactorInteractIForTDM : uint8_t
{
    ID                                             = 0,
    ID                                             = 1,
    ID                                             = 2,
    ID                                             = 3,
    ID                                             = 4,
    ID                                             = 5,
    ID                                             = 6,
    ID                                             = 7,
    ID                                             = 8,
    ID                                             = 9,
    ID                                             = 10,
    ID                                             = 11,
    ID                                             = 12,
    ID                                             = 13,
    ID                                             = 14,
    ID                                             = 15,
    ID                                             = 16,
    ID                                             = 17,
    ID                                             = 18,
    ID                                             = 19,
    ID                                             = 20,
    ID                                             = 21,
    ID                                             = 22,
    ID                                             = 23,
    Max                                            = 24

};


// Enum  /Script/DecisionAI.EStateFactorInteractID
enum class EStateFactorInteractID : uint8_t
{
    ID                                             = 0,
    ID                                             = 1,
    ID                                             = 2,
    ID                                             = 3,
    ID                                             = 4,
    ID                                             = 5,
    ID                                             = 6,
    ID                                             = 7,
    ID                                             = 8,
    ID                                             = 9,
    ID                                             = 10,
    ID                                             = 11,
    ID                                             = 12,
    Max                                            = 13

};


// Enum  /Script/DecisionAI.EStateFactorInteractActorState
enum class EStateFactorInteractActorState : uint8_t
{
    InValid                                        = 0,
    Open                                           = 1,
    Closed                                         = 2,
    Destroyed                                      = 3,
    Max                                            = 4

};


// Enum  /Script/DecisionAI.EStateFactorRadioType
enum class EStateFactorRadioType : uint8_t
{
    Invalid                                        = 0,
    NeedHelp                                       = 1,
    NeedHelpForPlantBomb                           = 2,
    NeedHelpForDefuseBomb                          = 3,
    SwitchAim                                      = 4,
    NeedHelpForHoldSite                            = 5,
    GuardingLostBomb                               = 6,
    Max                                            = 7

};


// Enum  /Script/DecisionAI.EStateFactorMatchPhase
enum class EStateFactorMatchPhase : uint8_t
{
    ReadyPhase                                     = 0,
    FightPhase                                     = 1,
    EndPhase                                       = 2,
    Max                                            = 3

};


// Enum  /Script/DecisionAI.EStateFactorCamp
enum class EStateFactorCamp : uint8_t
{
    PlantBomb                                      = 0,
    DefuseBomb                                     = 1,
    Max                                            = 2

};


// Enum  /Script/DecisionAI.EStateFactorBombState
enum class EStateFactorBombState : uint8_t
{
    BePickedUp                                     = 0,
    Dropped                                        = 1,
    Planted                                        = 2,
    BeingPlanted                                   = 3,
    BeingDefused                                   = 4,
    BombExplodeFinish                              = 5,
    Max                                            = 6

};


// Enum  /Script/DecisionAI.EAIWeaponID
enum class EAIWeaponID : uint8_t
{
    None                                           = 0,
    CLA                                            = 1,
    SHO                                            = 2,
    FRE                                            = 3,
    GHO                                            = 4,
    SHE                                            = 5,
    STI                                            = 6,
    SPE                                            = 7,
    BUC                                            = 8,
    JUD                                            = 9,
    BLU                                            = 10,
    GUA                                            = 11,
    PHA                                            = 12,
    VAN                                            = 13,
    MAR                                            = 14,
    OPE                                            = 15,
    ARE                                            = 16,
    OD                                             = 17,
    MAX                                            = 18

};


// Enum  /Script/DecisionAI.EAISlingType
enum class EAISlingType : uint8_t
{
    None                                           = 0,
    NormalRope                                     = 1,
    AutoRope                                       = 2,
    EAISlingType_MAX                               = 3

};


// Enum  /Script/DecisionAI.EAIExposedType
enum class EAIExposedType : uint8_t
{
    None                                           = 0,
    Visible                                        = 1,
    Exposed                                        = 2,
    UnExposed                                      = 3,
    EAIExposedType_MAX                             = 4

};


// Enum  /Script/DecisionAI.EAISmartLinkType
enum class EAISmartLinkType : uint8_t
{
    None                                           = 0,
    DoorSwitch                                     = 1,
    Sling                                          = 2,
    EAISmartLinkType_MAX                           = 3

};


// Enum  /Script/DecisionAI.EStateSelectorMlpType
enum class EStateSelectorMlpType : uint8_t
{
    None                                           = 0,
    PersonalAndTargetEnemyInfo                     = 1,
    PersonalAndTargetEnemyInfoForDeathMatch        = 2,
    PersonalAndTargetEnemyInfoForTDM               = 3,
    EStateSelectorMlpType_MAX                      = 4

};


// Enum  /Script/DecisionAI.EStateSelectorGraph
enum class EStateSelectorGraph : uint8_t
{
    None                                           = 0,
    PersonalAndTargetEnemyInfo                     = 1,
    PersonalAndTargetEnemyInfoForDeathMatch        = 2,
    PersonalAndTargetEnemyInfoForTDM               = 3,
    EStateSelectorGraph_MAX                        = 4

};


// Enum  /Script/DecisionAI.EDecisionTargetActorType
enum class EDecisionTargetActorType : uint8_t
{
    None                                           = 0,
    EnemyAgent                                     = 1,
    Summon                                         = 2,
    Destructible                                   = 3,
    Max                                            = 3

};


// Enum  /Script/DecisionAI.EAIFollowTaskType
enum class EAIFollowTaskType : uint8_t
{
    None                                           = 0,
    MoveToPlayer                                   = 1,
    Guard                                          = 2,
    Peek                                           = 3,
    PrepareToSearch                                = 4,
    Search                                         = 5,
    PrepareToAmbush                                = 6,
    Ambush                                         = 7,
    Max                                            = 8

};


// Enum  /Script/DecisionAI.EAICoverSearcherType
enum class EAICoverSearcherType : uint8_t
{
    None                                           = 0,
    Flee                                           = 1,
    PreAim                                         = 2,
    Approach                                       = 3,
    Reload                                         = 4,
    Peek                                           = 5,
    EnemyHide                                      = 6,
    Dodge                                          = 7,
    Max                                            = 8

};


// Enum  /Script/DecisionAI.EAIActorSenseType
enum class EAIActorSenseType : uint8_t
{
    None                                           = 0,
    Always                                         = 1,
    Sight                                          = 2,
    EAIActorSenseType_MAX                          = 3

};


// Enum  /Script/DecisionAI.EAIActorCampType
enum class EAIActorCampType : uint8_t
{
    None                                           = 0,
    AttackCamp                                     = 1,
    DefendCamp                                     = 2,
    EAIActorCampType_MAX                           = 3

};


// Enum  /Script/DecisionAI.EAIActorShapeType
enum class EAIActorShapeType : uint8_t
{
    None                                           = 0,
    Box                                            = 1,
    Cylinder                                       = 2,
    Sphere                                         = 3,
    MultiBox                                       = 4,
    CustomSphere                                   = 5,
    CustomCylinder                                 = 6,
    EAIActorShapeType_MAX                          = 7

};


// Enum  /Script/DecisionAI.EAIActorType
enum class EAIActorType : uint8_t
{
    None                                           = 0,
    Pickup                                         = 1,
    ModGoal                                        = 2,
    Door                                           = 3,
    AbilitySummon                                  = 4,
    AbilityArea                                    = 5,
    Destructible                                   = 6,
    Interact                                       = 7,
    Block                                          = 8,
    OneWayDoor                                     = 9,
    Max                                            = 10

};


// Enum  /Script/DecisionAI.EEconemyPreference
enum class EEconemyPreference : uint8_t
{
    None                                           = 0,
    SubWeapon                                      = 1,
    Weapon                                         = 2,
    Shield                                         = 3,
    Skill                                          = 4,
    Melee                                          = 5,
    ECO                                            = 6,
    EEconemyPreference_MAX                         = 7

};


// Enum  /Script/DecisionAI.EAITimerType
enum class EAITimerType : uint8_t
{
    LookRandom                                     = 0,
    LookAround                                     = 1,
    Hurry                                          = 2,
    Safe                                           = 3,
    RoundSafe                                      = 4,
    Rogues                                         = 5,
    Alert                                          = 6,
    NotifyNoise                                    = 7,
    DodgeCD                                        = 8,
    DodgeState                                     = 9,
    FireWeapon                                     = 10,
    RetreatCheck                                   = 11,
    FleeRepath                                     = 12,
    PinnedDown                                     = 13,
    NotifyTeamTime                                 = 14,
    AttackToAmbushCheck                            = 15,
    IgnoreEnemy                                    = 16,
    MeleeRepath                                    = 17,
    FetchBomb                                      = 18,
    ScopeInCheck                                   = 19,
    ScopeInDuration                                = 20,
    StayAttackWithoutEnemy                         = 21,
    AmbushHideInCover                              = 22,
    AmbushKeepPreAiming                            = 23,
    AmbushExceptionRetryCooldown                   = 24,
    AmbushLookAround                               = 25,
    AmbushChangeCover                              = 26,
    AmbushUpdateProtectGoal                        = 27,
    AmbushAimOutside                               = 28,
    HoldSiteHide                                   = 29,
    HoldSiteForCampHide                            = 30,
    HoldSiteAimOutside                             = 31,
    HoldSiteExceptionRetryCooldown                 = 32,
    HoldSiteChangePeekTime                         = 33,
    HoldSiteLookAround                             = 34,
    HoldSiteTakeCover                              = 35,
    PushExceptionRetryCooldown                     = 36,
    PushAimTargetCover                             = 37,
    PushLookAround                                 = 38,
    CampingPriorPanic                              = 39,
    CampingStandCamp                               = 40,
    CampingMoveCamp                                = 41,
    CampingCoverCamp                               = 42,
    BreakStuck                                     = 43,
    ReloadWeapon                                   = 44,
    Perform                                        = 45,
    TotalCrouch                                    = 46,
    Crouch                                         = 47,
    CrouchFire                                     = 48,
    MeleePerform                                   = 49,
    PerformCommon                                  = 50,
    PerformRandomMove                              = 51,
    Jump                                           = 52,
    Wait                                           = 53,
    FireByRatio                                    = 54,
    DodgeByCoverHide                               = 55,
    DodgeByCoverAttack                             = 56,
    FollowOut                                      = 57,
    EnterAbilityState                              = 58,
    ResponseToSlowWalk                             = 59,
    ClearUpNegativeState                           = 60,
    SendRadio                                      = 61,
    RspRadio                                       = 62,
    ReceiveRadio                                   = 63,
    PickUp                                         = 64,
    InteractDoorDelay                              = 65,
    PeekOut                                        = 66,
    PeekHide                                       = 67,
    JumpForward                                    = 68,
    JumpBackward                                   = 69,
    EquipMeleeForLongDist                          = 70,
    UpdateEnemyVisible                             = 71,
    RandomShootThroughSmoke                        = 72,
    EliminateEnemyShootThroughSmoke                = 73,
    EnterDefendAreaDelayTime                       = 74,
    PlantingBombPreAim                             = 75,
    BuyWait                                        = 76,
    CheckDoorState                                 = 77,
    GeneralPeekHide                                = 78,
    AttackRouteCamp                                = 79,
    AttackRoutePeek                                = 80,
    AttackRoutePeekMove                            = 81,
    AttackRouteShoot                               = 82,
    BuffAssistCamping                              = 83,
    JigglePeekTrigger                              = 84,
    AimResetTrigger                                = 85,
    AttackChangeTarget                             = 86,
    Max                                            = 87

};


// Enum  /Script/DecisionAI.ECaptainRequestDemandName
enum class ECaptainRequestDemandName : uint8_t
{
    None                                           = 0,
    ProtectBombSite                                = 1,
    RushSite                                       = 2,
    DetectEnemies                                  = 3,
    CaptureZones                                   = 4,
    SeizeZone                                      = 5,
    HoldSite                                       = 6,
    DefenderInvestigate                            = 7,
    DefuseBomb                                     = 8,
    ECaptainRequestDemandName_MAX                  = 9

};


// Enum  /Script/DecisionAI.ECaptainCommission
enum class ECaptainCommission : uint8_t
{
    None                                           = 0,
    InformationDetection                           = 1,
    HuntEnemy                                      = 2,
    PickUp                                         = 3,
    ECaptainCommission_MAX                         = 4

};


// Enum  /Script/DecisionAI.ECaptainRequestType
enum class ECaptainRequestType : uint8_t
{
    None                                           = 0,
    AttackerAttack                                 = 1,
    AttackerRotate                                 = 2,
    AttackerPickUp                                 = 3,
    DefenderDefend                                 = 4,
    DefenderRetake                                 = 5,
    DefenderFlank                                  = 6,
    ECaptainRequestType_MAX                        = 7

};


// Enum  /Script/DecisionAI.EDefendType
enum class EDefendType : uint8_t
{
    None                                           = 0,
    DefendA                                        = 1,
    DefendB                                        = 2,
    DefendC                                        = 3,
    Mid                                            = 4,
    Max                                            = 5

};


// Enum  /Script/DecisionAI.EAIAttackStrategy
enum class EAIAttackStrategy : uint8_t
{
    None                                           = 0,
    RushA                                          = 1,
    RushB                                          = 2,
    RushC                                          = 3,
    Random                                         = 4,
    Max                                            = 5

};


// Enum  /Script/DecisionAI.EAIAttackType
enum class EAIAttackType : uint8_t
{
    None                                           = 0,
    DispersedAttack                                = 1,
    AGroupAttack                                   = 2,
    FeintAttack                                    = 3,
    Max                                            = 4

};


// Enum  /Script/DecisionAI.EAIInteractActorState
enum class EAIInteractActorState : uint8_t
{
    None                                           = 0,
    Open                                           = 1,
    Closed                                         = 2,
    Destroyed                                      = 3,
    Max                                            = 4

};


// Enum  /Script/DecisionAI.EAIInteractType
enum class EAIInteractType : uint8_t
{
    None                                           = 0,
    SoulBall                                       = 1,
    InteractDoor                                   = 2,
    Rope                                           = 3,
    Max                                            = 4

};


// Enum  /Script/DecisionAI.EAIInteractDoorState
enum class EAIInteractDoorState : uint8_t
{
    None                                           = 0,
    Open                                           = 1,
    Closed                                         = 2,
    Destroyed                                      = 3,
    Max                                            = 4

};


// Enum  /Script/DecisionAI.EAIPickUpType
enum class EAIPickUpType : uint8_t
{
    None                                           = 0,
    Weapon                                         = 1,
    HealthSupply                                   = 2,
    Max                                            = 3

};


// Enum  /Script/DecisionAI.EAIRadioEventType
enum class EAIRadioEventType : uint8_t
{
    None                                           = 0,
    NeedHelpForPlantingBomb                        = 1,
    NeedHelpForDefusingBomb                        = 2,
    NeedHelpForHoldSite                            = 3,
    GuardingLostBomb                               = 4,
    GuardPlantedBomb                               = 5,
    HeardNoise                                     = 6,
    PinnedDown                                     = 7,
    DefusePlantedBomb                              = 8,
    OccupyMid                                      = 9,
    ThrowBomb                                      = 10,
    EnsureGunOnhand                                = 11,
    PickUpBomb                                     = 12,
    OccupyA                                        = 13,
    OccupyB                                        = 14,
    OccupyC                                        = 15,
    NeedHelp                                       = 16,
    SlowWalk                                       = 17,
    SwitchAim                                      = 18,
    PlantBomb                                      = 19,
    NeedHealing                                    = 20,
    Attack                                         = 21,
    Max                                            = 22

};


// Enum  /Script/DecisionAI.EAIDodgeState
enum class EAIDodgeState : uint8_t
{
    Steady                                         = 0,
    MoveLeft                                       = 1,
    MoveRight                                      = 2,
    MoveForward                                    = 3,
    MoveBack                                       = 4,
    Jump                                           = 5,
    EAIDodgeState_MAX                              = 6

};


// Enum  /Script/DecisionAI.EAIDamageType
enum class EAIDamageType : uint8_t
{
    None                                           = 0,
    Weapon                                         = 1,
    Ability                                        = 2,
    Falling                                        = 3,
    Bomb                                           = 4,
    EAIDamageType_MAX                              = 5

};


// Enum  /Script/DecisionAI.EAITurnType
enum class EAITurnType : uint8_t
{
    GamePlay                                       = 0,
    Move                                           = 1,
    EAITurnType_MAX                                = 2

};


// Enum  /Script/DecisionAI.EAITurnMode
enum class EAITurnMode : uint8_t
{
    Default                                        = 0,
    ShootSpeed                                     = 1,
    PreAim                                         = 2,
    Immediate                                      = 3,
    Forward                                        = 4,
    SustainFocus                                   = 5,
    EAITurnMode_MAX                                = 6

};


// Enum  /Script/DecisionAI.EAIMoveType
enum class EAIMoveType : uint8_t
{
    Default                                        = 0,
    Fastest                                        = 1,
    Safest                                         = 2,
    Flee                                           = 3,
    PreAim                                         = 4,
    AttackPreAim                                   = 5,
    AssemblePreAim                                 = 6,
    MostDangerous                                  = 7,
    LimitedInterestInFightingPreAim                = 8,
    MAX                                            = 9

};


// Enum  /Script/DecisionAI.EAIVisiblePart
enum class EAIVisiblePart : uint8_t
{
    None                                           = 0,
    Body                                           = 1,
    Head                                           = 2,
    EAIVisiblePart_MAX                             = 3

};


// Enum  /Script/DecisionAI.EAIDamagePart
enum class EAIDamagePart : uint8_t
{
    None                                           = 0,
    Head                                           = 1,
    Chest                                          = 2,
    Shoulder                                       = 3,
    Elbow                                          = 4,
    Hip                                            = 5,
    Leg                                            = 6,
    Body                                           = 7,
    EAIDamagePart_MAX                              = 8

};


// Enum  /Script/DecisionAI.EAIEnemyType
enum class EAIEnemyType : uint8_t
{
    None                                           = 0,
    Agent                                          = 1,
    AttackableSummon                               = 2,
    FuncSummon                                     = 3,
    Destructiable                                  = 4,
    Human                                          = 128,
    EAIEnemyType_MAX                               = 129

};


// Enum  /Script/DecisionAI.EAIFireType
enum class EAIFireType : uint8_t
{
    None                                           = 0,
    Melee                                          = 1,
    Gun                                            = 2,
    Ability                                        = 3,
    EAIFireType_MAX                                = 4

};


// Enum  /Script/DecisionAI.EAIWeaponType
enum class EAIWeaponType : uint8_t
{
    None                                           = 0,
    Melee                                          = 1,
    Pistol                                         = 2,
    Rifle                                          = 3,
    ShotGun                                        = 4,
    MachineGun                                     = 5,
    SubMachineGun                                  = 6,
    Sniper                                         = 7,
    Max                                            = 8

};


// Enum  /Script/DecisionAI.EAIModType
enum class EAIModType : uint8_t
{
    None                                           = 0,
    Standard                                       = 1,
    DeathMatch                                     = 2,
    Escalation                                     = 3,
    TDM                                            = 4,
    Ultimate                                       = 5,
    Max                                            = 5

};


// Enum  /Script/DecisionAI.EAINoiseType
enum class EAINoiseType : uint8_t
{
    None                                           = 0,
    Fire                                           = 1,
    Walk                                           = 2,
    PlantBomb                                      = 3,
    DefuseBomb                                     = 4,
    Ability                                        = 5,
    Door                                           = 6,
    Break                                          = 7,
    Portal                                         = 8,
    Sling                                          = 9,
    EAINoiseType_MAX                               = 10

};


// Enum  /Script/DecisionAI.EAIPriorityType
enum class EAIPriorityType : uint8_t
{
    None                                           = 0,
    Low                                            = 1,
    Medium                                         = 2,
    High                                           = 3,
    Ultimate                                       = 4,
    Max                                            = 4

};


// Enum  /Script/DecisionAI.EDispositionType
enum class EDispositionType : uint8_t
{
    EngageAndInvest                                = 0,
    OpportunityFire                                = 1,
    SelfDefense                                    = 2,
    IgnoreEnemy                                    = 3,
    SelfDefenseForBombTask                         = 4,
    OnTheWayToDoTask                               = 5,
    EDispositionType_MAX                           = 6

};


// Enum  /Script/DecisionAI.EAITaskType
enum class EAITaskType : uint8_t
{
    None                                           = 0,
    SeeAndDestroy                                  = 1,
    PlantBomb                                      = 2,
    DefuseBomb                                     = 3,
    GuardTickingBomb                               = 4,
    GuardLooseBomb                                 = 5,
    GuardDefuseBomb                                = 6,
    GuardBombZone                                  = 7,
    EscapeBombSide                                 = 8,
    MakeTrap                                       = 9,
    HoldPosition                                   = 10,
    Follow                                         = 11,
    ToSniperSpot                                   = 12,
    Sniping                                        = 13,
    Buy                                            = 14,
    FetchBomb                                      = 15,
    SearchEnemy                                    = 16,
    Flee                                           = 17,
    ApproachObject                                 = 18,
    HoldPositionWait                               = 19,
    AttackPeek                                     = 20,
    JumpPeek                                       = 21,
    FollowAmbush                                   = 22,
    FollowSearch                                   = 23,
    FollowGuard                                    = 24,
    FollowUp                                       = 25,
    EAITaskType_MAX                                = 26

};


// Enum  /Script/DecisionAI.EAIStateType
enum class EAIStateType : uint8_t
{
    None                                           = 0,
    Idle                                           = 1,
    Hunt                                           = 2,
    Buy                                            = 3,
    Follow                                         = 4,
    Attack                                         = 5,
    Flee                                           = 6,
    Ambush                                         = 7,
    Investigate                                    = 8,
    MoveTo                                         = 9,
    PlantBomb                                      = 10,
    DefuseBomb                                     = 11,
    EscapeFromBomb                                 = 12,
    ScapeAbility                                   = 13,
    MakeTrap                                       = 14,
    FetchBomb                                      = 15,
    Perform                                        = 16,
    PickUp                                         = 17,
    ResponseToRadio                                = 18,
    Ability                                        = 19,
    Interact                                       = 20,
    HoldSite                                       = 21,
    Pause                                          = 22,
    AbilityExtend                                  = 23,
    Push                                           = 24,
    Camping                                        = 25,
    ChaseEnemy                                     = 26,
    AttackThroughSmoke                             = 27,
    GoRear                                         = 28,
    Reload                                         = 29,
    HoldSiteForCamp                                = 30,
    AttackerAttack                                 = 31,
    AttackerRotate                                 = 32,
    AttackerPickUp                                 = 33,
    DefenderRetake                                 = 34,
    DefenderFLank                                  = 35,
    MAX                                            = 29

};


// Enum  /Script/DecisionAI.EAIModuleType
enum class EAIModuleType : uint8_t
{
    World                                          = 0,
    Noise                                          = 1,
    Sight                                          = 2,
    Radio                                          = 3,
    Sensor                                         = 4,
    Nav                                            = 5,
    RouteMap                                       = 6,
    PathFind                                       = 7,
    Exception                                      = 8,
    Round                                          = 9,
    Camp                                           = 10,
    Threat                                         = 11,
    Battle                                         = 12,
    Zone                                           = 13,
    Ambush                                         = 14,
    Weapon                                         = 15,
    Ability                                        = 16,
    Turn                                           = 17,
    Status                                         = 18,
    Buy                                            = 19,
    Ready                                          = 20,
    ShootControl                                   = 21,
    StateTransitionControl                         = 22,
    PickUp                                         = 23,
    Negative                                       = 24,
    Follow                                         = 25,
    Interact                                       = 26,
    Peek                                           = 27,
    Cover                                          = 28,
    TacticalStrategy                               = 29,
    Captain                                        = 30,
    DifficultyModifier                             = 31,
    Behaviour                                      = 32,
    Max                                            = 33

};


// Enum  /Script/DecisionAI.EFloatValueNormalizationType
enum class EFloatValueNormalizationType : uint8_t
{
    None                                           = 0,
    Normal                                         = 1,
    Scaling                                        = 2,
    EFloatValueNormalizationType_MAX               = 3

};


// Enum  /Script/DecisionAI.EDecisionTargetFactorType
enum class EDecisionTargetFactorType : uint8_t
{
    Numerical                                      = 0,
    OneHot                                         = 1,
    EDecisionTargetFactorType_MAX                  = 2

};


// Enum  /Script/DecisionAI.EDecisionTargetFactorName
enum class EDecisionTargetFactorName : uint8_t
{
    None                                           = 0,
    Distance                                       = 1,
    IsInSight                                      = 2,
    SenseAge                                       = 3,
    SensePeriod                                    = 4,
    IsBlocked                                      = 5,
    OrientationDegrees                             = 6,
    Hp                                             = 7,
    Weapon                                         = 8,
    WeaponPrice                                    = 9,
    Velocity                                       = 10,
    Kda                                            = 11,
    IsReloading                                    = 12,
    TargetActorType                                = 13,
    Agent                                          = 14,
    IsWorkingOnLevelTask                           = 15,
    SkillPreparation                               = 16,
    Summon                                         = 17,
    Damage                                         = 18,
    IsAttackingMe                                  = 19,
    IsPreviousTarget                               = 20,
    OffsetToPreviousTarget                         = 21,
    AttackPeriod                                   = 22,
    IsLookingAtMe                                  = 23,
    MaxFactor                                      = 24,
    EDecisionTargetFactorName_MAX                  = 25

};


// Enum  /Script/DecisionAI.ESmartLinkRotateMode
enum class ESmartLinkRotateMode : uint8_t
{
    None                                           = 0,
    FromPath                                       = 1,
    FocusStartPoint                                = 2,
    FocusEndPoint                                  = 3,
    CustomPoint                                    = 4,
    ESmartLinkRotateMode_MAX                       = 5

};


// Enum  /Script/DecisionAI.EAttackerRotateEntryConditionItemName
enum class EAttackerRotateEntryConditionItemName : uint8_t
{
    None                                           = 0,
    PreDeterminedEntry                             = 1,
    Distance                                       = 2,
    DangerScore                                    = 3,
    SightBlockedEntry                              = 4,
    EAttackerRotateEntryConditionItemName_MAX      = 5

};


// Enum  /Script/DecisionAI.EActivationType
enum class EActivationType : uint8_t
{
    None                                           = 0,
    Relu                                           = 1,
    Sigmoid                                        = 2,
    Softmax                                        = 3,
    Linear                                         = 4,
    EActivationType_MAX                            = 5

};


// Enum  /Script/DecisionAI.EPreAimType
enum class EPreAimType : uint8_t
{
    None                                           = 0,
    MoveThrough                                    = 1,
    PassBy                                         = 2,
    OffPath                                        = 3,
    HighLand                                       = 4,
    PeekEnemy                                      = 5,
    Strife                                         = 6,
    DirectAimEnemy                                 = 7,
    Default                                        = 8,
    Jiggle                                         = 9,
    FocalTest                                      = 10,
    EPreAimType_MAX                                = 11

};


// Enum  /Script/DecisionAI.EPreAimState
enum class EPreAimState : uint8_t
{
    Start                                          = 0,
    Mid                                            = 1,
    End                                            = 2,
    EPreAimState_MAX                               = 3

};


// Enum  /Script/DecisionAI.EPreAimCoverSelectionType
enum class EPreAimCoverSelectionType : uint8_t
{
    Random                                         = 0,
    Nearest                                        = 1,
    EPreAimCoverSelectionType_MAX                  = 2

};


// Enum  /Script/DecisionAI.EPreAimFocalPointControlType
enum class EPreAimFocalPointControlType : uint8_t
{
    Fixed                                          = 0,
    Strife                                         = 1,
    FixedToAnother                                 = 2,
    JiggleStrife                                   = 3,
    FixStrife                                      = 4,
    SimulateHumanFix                               = 5,
    EPreAimFocalPointControlType_MAX               = 6

};


// Enum  /Script/DecisionAI.EAttackEntryType
enum class EAttackEntryType : uint8_t
{
    None                                           = 0,
    Main                                           = 1,
    Minor                                          = 2,
    Undefined                                      = 3,
    EAttackEntryType_MAX                           = 4

};


// Enum  /Script/DecisionAI.EZoneRouteType
enum class EZoneRouteType : uint8_t
{
    None                                           = 0,
    AttackerAttack                                 = 1,
    AttackerRotate                                 = 2,
    DefenderDefend                                 = 3,
    DefenderRetake                                 = 4,
    DefenderFlank                                  = 5,
    EZoneRouteType_MAX                             = 6

};


// Enum  /Script/DecisionAI.EStateFactorInteractActorType
enum class EStateFactorInteractActorType : uint8_t
{
    InValid                                        = 0,
    SoulBall                                       = 1,
    InteractDoor                                   = 2,
    Rope                                           = 3,
    Max                                            = 4

};


// Enum  /Script/DecisionAI.EStateFactorWeaponType
enum class EStateFactorWeaponType : uint8_t
{
    Melee                                          = 0,
    Pistol                                         = 1,
    Rifle                                          = 2,
    ShotGun                                        = 3,
    MachineGun                                     = 4,
    SubMachineGun                                  = 5,
    Sniper                                         = 6,
    Max                                            = 7

};


// Enum  /Script/DecisionAI.EBombState
enum class EBombState : uint8_t
{
    Dropped                                        = 0,
    BeingPlanted                                   = 1,
    Planted                                        = 2,
    BeingDefused                                   = 3,
    Max                                            = 4

};


// Enum  /Script/DecisionAI.EStateFactorStateForTDM
enum class EStateFactorStateForTDM : uint8_t
{
    Investigate                                    = 0,
    Attack                                         = 1,
    Buy                                            = 2,
    Idle                                           = 3,
    Hunt                                           = 4,
    PickUp                                         = 5,
    Interact                                       = 6,
    Ability                                        = 7,
    Pause                                          = 8,
    Reload                                         = 9,
    Max                                            = 10

};


// Enum  /Script/DecisionAI.EStateFactorStateForDeathMatch
enum class EStateFactorStateForDeathMatch : uint8_t
{
    Investigate                                    = 0,
    Attack                                         = 1,
    Buy                                            = 2,
    Idle                                           = 3,
    Hunt                                           = 4,
    Ability                                        = 5,
    Pause                                          = 6,
    Reload                                         = 7,
    Max                                            = 8

};


// Enum  /Script/DecisionAI.EStateFactorState
enum class EStateFactorState : uint8_t
{
    PlantBomb                                      = 0,
    Perform                                        = 1,
    DefuseBomb                                     = 2,
    Investigate                                    = 3,
    HoldSite                                       = 4,
    Attack                                         = 5,
    Buy                                            = 6,
    Idle                                           = 7,
    Ambush                                         = 8,
    EscapeFromBomb                                 = 9,
    Hunt                                           = 10,
    Flee                                           = 11,
    FetchBomb                                      = 12,
    PickUp                                         = 13,
    Interact                                       = 14,
    Follow                                         = 15,
    ResponseToRadio                                = 16,
    Ability                                        = 17,
    Pause                                          = 18,
    AbilityExtend                                  = 19,
    Push                                           = 20,
    Camping                                        = 21,
    AttackThroughSmoke                             = 22,
    ChaseEnemy                                     = 23,
    GoRear                                         = 24,
    Reload                                         = 25,
    HoldSiteForCamp                                = 26,
    AttackerAttack                                 = 27,
    AttackerRotate                                 = 28,
    AttackerPickUp                                 = 29,
    DefenderRetake                                 = 30,
    DefenderFLank                                  = 31,
    Max                                            = 32

};


// Enum  /Script/DecisionAI.EStateFactor
enum class EStateFactor : uint8_t
{
    None                                           = 0,
    CurrentState                                   = 1,
    CurrentStateForDeathMatch                      = 2,
    CurrentStateForTDM                             = 3,
    Camp                                           = 4,
    Hp                                             = 5,
    Weapon                                         = 6,
    AbilityPoints                                  = 7,
    XAbility                                       = 8,
    IsCarryingBomb                                 = 9,
    IsPlantingOrDefuseBomb                         = 10,
    DistanceToBomb                                 = 11,
    LeftTime                                       = 12,
    BombState                                      = 13,
    NearestDistanceToBombArea                      = 14,
    MatchPhase                                     = 15,
    StateDuration                                  = 16,
    EnemyNumAround                                 = 17,
    AllyNumAround                                  = 18,
    IsBeingAttacked                                = 19,
    PickUpWeaponFound                              = 20,
    CurBulletRatioOfSecondaryWeapon                = 21,
    IsEndPickUpWeapon                              = 22,
    NearestInteractActorType                       = 23,
    InteractActorID                                = 24,
    InteractActorIDForTDM                          = 25,
    DistanceToNearestInteractActor                 = 26,
    NearestInteractActorState                      = 27,
    IsFullPointOfXAbility                          = 28,
    HasRealTeammateAlive                           = 29,
    DistanceToNearestRealTeammate                  = 30,
    FollowNumOfNearestRealTeammate                 = 31,
    HasRadioToRsp                                  = 32,
    IsRealPlayerRadio                              = 33,
    CurRadioType                                   = 34,
    IsEndRspToRadio                                = 35,
    IsSuitableToUseAbility                         = 36,
    HasItemToBuy                                   = 37,
    HasEnoughTimeToDefuseBomb                      = 38,
    HasExtendAbilityActorNearby                    = 39,
    IsBlockedBySmoke                               = 40,
    TimeAfterFightStart                            = 41,
    IsReloading                                    = 42,
    RouteType                                      = 43,
    EnemyIsVisible                                 = 44,
    EnemyIsEnterCover                              = 45,
    EnemyHp                                        = 46,
    EnemyDistance                                  = 47,
    EnemyWeaponPrice                               = 48,
    EnemySensePeriod                               = 49,
    EnemySenseAge_Sight                            = 50,
    EnemySenseAge_LastNotice                       = 51,
    EnemyAttackPeriod                              = 52,
    EnemyIsLookingAtMe                             = 53,
    HasSensedEnemy                                 = 54,
    AllyDistance                                   = 16,
    AllyHp                                         = 17,
    AllyWeaponPrice                                = 18,
    EStateFactor_MAX                               = 55

};


// Enum  /Script/DecisionAI.ETacticAgentType
enum class ETacticAgentType : uint8_t
{
    None                                           = 0,
    Duelist                                        = 1,
    Controller                                     = 2,
    Initiator                                      = 3,
    Sentinel                                       = 4,
    ETacticAgentType_MAX                           = 5

};


// Enum  /Script/DecisionAI.ETacticPhaseDependencyType
enum class ETacticPhaseDependencyType : uint8_t
{
    None                                           = 0,
    Weak                                           = 1,
    Strong                                         = 2,
    VeryWeak                                       = 3,
    ETacticPhaseDependencyType_MAX                 = 4

};


// Enum  /Script/DecisionAI.EAITacticalStrategyGameMod
enum class EAITacticalStrategyGameMod : uint8_t
{
    None                                           = 0,
    Bomb                                           = 1,
    TDM                                            = 2,
    DeathMatch                                     = 3,
    Escalation                                     = 4,
    FirstGame                                      = 5,
    Replication                                    = 6,
    EAITacticalStrategyGameMod_MAX                 = 7

};


// Enum  /Script/DecisionAI.ETacticAbilityType
enum class ETacticAbilityType : uint8_t
{
    None                                           = 0,
    InformationDetection                           = 1,
    VisionDisturbance                              = 2,
    SiteSplitting                                  = 3,
    BuffAssistance                                 = 4,
    BuffAssistance_Heal                            = 5,
    BuffAssiatance_God                             = 6,
    ForcingMove                                    = 7,
    ActionDisturbance                              = 8,
    BlockingRoute                                  = 9,
    FastMove                                       = 10,
    SiteSplittingShort                             = 11,
    Healing                                        = 12,
    ETacticAbilityType_MAX                         = 13

};


// Enum  /Script/DecisionAI.EAITacticalStrategyEvaluationMethod
enum class EAITacticalStrategyEvaluationMethod : uint8_t
{
    None                                           = 0,
    SecondWaveMoveInSite_GroupRush                 = 1,
    SecondWaveMoveInSite_CaptainRequest            = 2,
    ProtectBombSite_DefenderHoldSite               = 3,
    Healing                                        = 4,
    AmbushBombSite                                 = 5,
    AssistDefusingBomb                             = 6,
    StopEnemyDefusingBomb                          = 7,
    MoveIn_FollowSecondWaveMoveIn                  = 8,
    Assemble_DuelistAssembleInSecondWaveMoveIn     = 9,
    EnterDangerousZone_EnemyNoiseHeard             = 10,
    ReynaQ                                         = 11,
    PhoenixX                                       = 12,
    RazeC                                          = 13,
    BrimStoneC                                     = 14,
    CypherX                                        = 15,
    PersonalDetect                                 = 16,
    EAITacticalStrategyEvaluationMethod_MAX        = 17

};


// Enum  /Script/DecisionAI.EStrategyGoal
enum class EStrategyGoal : uint8_t
{
    None                                           = 0,
    Assemble                                       = 1,
    MoveIn                                         = 2,
    SecondWaveMoveInSite                           = 3,
    FastMove                                       = 4,
    ProtectBombSite                                = 5,
    ContinueProtect                                = 6,
    MoveToGoal                                     = 7,
    PersonalAddhp                                  = 8,
    HoldBombSite                                   = 9,
    AssistDefusingBomb                             = 10,
    StopEnemyDefusingBomb                          = 11,
    PhoneixX                                       = 12,
    ReynaQ                                         = 13,
    RazeC                                          = 14,
    BrimStoneC                                     = 15,
    CypherX                                        = 16,
    PersonalDetect                                 = 17,
    EnterDangerousZone                             = 18,
    EStrategyGoal_MAX                              = 19

};


// Enum  /Script/KawaiiPhysics.ECollisionLimitType
enum class ECollisionLimitType : uint8_t
{
    None                                           = 0,
    Spherical                                      = 1,
    Capsule                                        = 2,
    Planar                                         = 3,
    ECollisionLimitType_MAX                        = 4

};


// Enum  /Script/KawaiiPhysics.EBoneForwardAxis
enum class EBoneForwardAxis : uint8_t
{
    X_Positive                                     = 0,
    X_Negative                                     = 1,
    Y_Positive                                     = 2,
    Y_Negative                                     = 3,
    Z_Positive                                     = 4,
    Z_Negative                                     = 5,
    EBoneForwardAxis_MAX                           = 6

};


// Enum  /Script/KawaiiPhysics.EPlanarConstraint
enum class EPlanarConstraint : uint8_t
{
    None                                           = 0,
    X                                              = 1,
    Y                                              = 2,
    Z                                              = 3,
    EPlanarConstraint_MAX                          = 4

};


// Enum  /Script/Paper2D.EFlipbookCollisionMode
enum class EFlipbookCollisionMode : uint8_t
{
    NoCollision                                    = 0,
    FirstFrameCollision                            = 1,
    EachFrameCollision                             = 2,
    EFlipbookCollisionMode_MAX                     = 3

};


// Enum  /Script/Paper2D.EPaperSpriteAtlasPadding
enum class EPaperSpriteAtlasPadding : uint8_t
{
    DilateBorder                                   = 0,
    PadWithZero                                    = 1,
    EPaperSpriteAtlasPadding_MAX                   = 2

};


// Enum  /Script/Paper2D.ETileMapProjectionMode
enum class ETileMapProjectionMode : uint8_t
{
    Orthogonal                                     = 0,
    IsometricDiamond                               = 1,
    IsometricStaggered                             = 2,
    HexagonalStaggered                             = 3,
    ETileMapProjectionMode_MAX                     = 4

};


// Enum  /Script/Paper2D.ESpritePivotMode
enum class ESpritePivotMode : uint8_t
{
    Top_Left                                       = 0,
    Top_Center                                     = 1,
    Top_Right                                      = 2,
    Center_Left                                    = 3,
    Center_Center                                  = 4,
    Center_Right                                   = 5,
    Bottom_Left                                    = 6,
    Bottom_Center                                  = 7,
    Bottom_Right                                   = 8,
    Custom                                         = 9,
    ESpritePivotMode_MAX                           = 10

};


// Enum  /Script/Paper2D.ESpritePolygonMode
enum class ESpritePolygonMode : uint8_t
{
    SourceBoundingBox                              = 0,
    TightBoundingBox                               = 1,
    ShrinkWrapped                                  = 2,
    FullyCustom                                    = 3,
    Diced                                          = 4,
    ESpritePolygonMode_MAX                         = 5

};


// Enum  /Script/Paper2D.ESpriteShapeType
enum class ESpriteShapeType : uint8_t
{
    Box                                            = 0,
    Circle                                         = 1,
    Polygon                                        = 2,
    ESpriteShapeType_MAX                           = 3

};


// Enum  /Script/Paper2D.ESpriteCollisionMode
enum class ESpriteCollisionMode : uint8_t
{
    None                                           = 0,
    Use2DPhysics                                   = 1,
    Use3DPhysics                                   = 2,
    ESpriteCollisionMode_MAX                       = 3

};


// Enum  /Script/SGTable.ESGTableCategory
enum class ESGTableCategory : uint8_t
{
    None                                           = 0,
    Lobby                                          = 1,
    GamePlay                                       = 2,
    ExcelCommon                                    = 3,
    Localization                                   = 4,
    ESGTableCategory_MAX                           = 5

};


// Enum  /Script/SGBase.ESGPawnViewMode
enum class ESGPawnViewMode : uint8_t
{
    ENone                                          = 0,
    EFPP                                           = 1,
    ETPP                                           = 2,
    ESGPawnViewMode_MAX                            = 3

};


// Enum  /Script/SGBase.ESGDamageRole
enum class ESGDamageRole : uint8_t
{
    Enemy                                          = 0,
    All                                            = 1,
    ExceptSelf                                     = 2,
    ESGDamageRole_MAX                              = 3

};


// Enum  /Script/SGBase.ESGDamagePart
enum class ESGDamagePart : uint8_t
{
    None                                           = 0,
    Head                                           = 1,
    Body                                           = 2,
    Leg                                            = 3,
    ESGDamagePart_MAX                              = 4

};


// Enum  /Script/SGBase.ESGDamageType
enum class ESGDamageType : uint8_t
{
    None                                           = 0,
    Weapon                                         = 1,
    Ability                                        = 2,
    AbilityNoDir                                   = 3,
    AbilityNoEffect                                = 4,
    Falling                                        = 5,
    Spike                                          = 6,
    Punish                                         = 7,
    Pending                                        = 8,
    Interact                                       = 9,
    ESGDamageType_MAX                              = 10

};


// Enum  /Script/SGBase.ESGCampRelation
enum class ESGCampRelation : uint8_t
{
    EUnkown                                        = 0,
    EEnemy                                         = 1,
    ENeutral                                       = 2,
    ETeammate                                      = 3,
    ESelf                                          = 4,
    ESGCampRelation_MAX                            = 5

};


// Enum  /Script/SGBase.ESGNetworkMode
enum class ESGNetworkMode : uint8_t
{
    DedicatedServer                                = 0,
    NetworkClient                                  = 1,
    Standalone                                     = 2,
    ListenServer                                   = 3,
    None                                           = 4,
    ESGNetworkMode_MAX                             = 5

};


// Enum  /Script/SGBase.ERewindType
enum class ERewindType : uint8_t
{
    None                                           = 0,
    Bounds                                         = 1,
    Anim                                           = 2,
    Num                                            = 3,
    ERewindType_MAX                                = 4

};


// Enum  /Script/SGBase.ESGHitRegVerifyResult
enum class ESGHitRegVerifyResult : uint8_t
{
    Success                                        = 0,
    NoBindingTraceDel                              = 1,
    CauserLifeTimeFailed                           = 2,
    CauserPositionFailed                           = 3,
    CauserRewindFailed                             = 4,
    CauserTickFailed                               = 5,
    CauserDataInvalid                              = 6,
    TargetLifeTimeFailed                           = 7,
    TargetInvalid                                  = 8,
    TargetRewindFailed                             = 9,
    TargetRewindParamsInvalid                      = 10,
    TargetRewindAnimFailed                         = 11,
    TargetBoxTestFailed                            = 12,
    TargetTraceFailed                              = 13,
    CauserDirectionError                           = 14,
    SoftPunish                                     = 15,
    ESGHitRegVerifyResult_MAX                      = 16

};


// Enum  /Script/SGBase.ESGOverrideRet
enum class ESGOverrideRet : uint8_t
{
    OverrideNone                                   = 0,
    OverrideAll                                    = 1,
    OverrideDecal                                  = 2,
    ESGOverrideRet_MAX                             = 3

};


// Enum  /Script/SGBase.ESGImpactVisibility
enum class ESGImpactVisibility : uint8_t
{
    Hidden                                         = 0,
    VisibleInRange                                 = 1,
    VisibleAlways                                  = 2,
    ESGImpactVisibility_MAX                        = 3

};


// Enum  /Script/SGBase.ESGDoorState
enum class ESGDoorState : uint8_t
{
    None                                           = 0,
    Closing                                        = 1,
    Closed                                         = 2,
    Openning                                       = 3,
    Open                                           = 4,
    Broken                                         = 5,
    ESGDoorState_MAX                               = 6

};


// Enum  /Script/SGBase.EAIBrainType
enum class EAIBrainType : uint8_t
{
    None                                           = 0,
    BTAI                                           = 1,
    DecisAI                                        = 2,
    MLAI                                           = 3,
    EAIBrainType_MAX                               = 4

};


// Enum  /Script/SGBase.EAvatarActorType
enum class EAvatarActorType : uint8_t
{
    None                                           = 0,
    WeaponActor                                    = 1,
    BulletActor                                    = 2,
    CustomActor1                                   = 3,
    CustomActor2                                   = 4,
    CustomActor3                                   = 5,
    CustomActor4                                   = 6,
    EAvatarActorType_MAX                           = 7

};


// Enum  /Script/SGBase.ESGFPPHandedness
enum class ESGFPPHandedness : uint8_t
{
    ERightHand                                     = 0,
    ELeftHand                                      = 1,
    ESGFPPHandedness_MAX                           = 2

};


// Enum  /Script/SGBase.ESGInGamePlayerRole
enum class ESGInGamePlayerRole : uint8_t
{
    None                                           = 0,
    Player                                         = 1,
    Observer                                       = 2,
    Couch                                          = 3,
    Judge                                          = 4,
    ESGInGamePlayerRole_MAX                        = 5

};


// Enum  /Script/SGBase.ESGReplayBattleType
enum class ESGReplayBattleType : uint8_t
{
    ENone                                          = 0,
    EFriendOB                                      = 1,
    ECustomRoomOB                                  = 2,
    EWonderfulReplay                               = 3,
    ELocalFileReplay                               = 4,
    EDeathReplay                                   = 5,
    Normal                                         = 0,
    OB_Friend                                      = 1,
    OB_CustomRoom                                  = 2,
    RP_Wonderful                                   = 3,
    RP_Replay                                      = 4,
    RP_DeathReplay                                 = 5,
    ESGReplayBattleType_MAX                        = 6

};


// Enum  /Script/SGBase.ESGBooleanOverride
enum class ESGBooleanOverride : uint8_t
{
    EOverrideNone                                  = 0,
    EOverrideTrue                                  = 1,
    EOverrideFalse                                 = 2,
    ESGBooleanOverride_MAX                         = 3

};


// Enum  /Script/SGBase.ESGBoneModifySource
enum class ESGBoneModifySource : uint8_t
{
    ENone                                          = 0,
    EJumpLand                                      = 1,
    EHeadShot                                      = 2,
    ESGBoneModifySource_MAX                        = 3

};


// Enum  /Script/SGBase.ESGNetEventType
enum class ESGNetEventType : uint8_t
{
    Lost                                           = 0,
    Recovered                                      = 1,
    Closed                                         = 2,
    PreReconnect                                   = 3,
    Reconnected                                    = 4,
    LostInHttpReplay                               = 5,
    AppHasReactivate                               = 6,
    ClosedInHttpReplay                             = 10,
    PostLoginInit                                  = 11,
    ESGNetEventType_MAX                            = 12

};


// Enum  /Script/SGBase.ESGDeathMontageType
enum class ESGDeathMontageType : uint8_t
{
    EDefaultMontage                                = 0,
    ETerminatorMontage                             = 1,
    EAbilityMontage                                = 2,
    ESGDeathMontageType_MAX                        = 3

};


// Enum  /Script/SGBase.ESGGameObserveConfig
enum class ESGGameObserveConfig : uint8_t
{
    EDisabled                                      = 0,
    ETeammateOnly                                  = 1,
    EEnemyOnly                                     = 2,
    EAnyOne                                        = 3,
    ESGGameObserveConfig_MAX                       = 4

};


// Enum  /Script/SGBase.ESGObserveType
enum class ESGObserveType : uint8_t
{
    EOBNone                                        = 0,
    EOBDeath                                       = 1,
    EOBFriend                                      = 2,
    EOBReplay                                      = 3,
    EOBSpectator                                   = 4,
    ESGObserveType_MAX                             = 5

};


// Enum  /Script/SGBase.ESGCharacterAirSoundType
enum class ESGCharacterAirSoundType : uint8_t
{
    ENone                                          = 0,
    AirSoundType1_PlayEvent                        = 1,
    AirSoundType1_StopEvent                        = 2,
    AirSoundType2_PlayEvent                        = 3,
    AirSoundType2_StopEvent                        = 4,
    ESGCharacterAirSoundType_MAX                   = 5

};


// Enum  /Script/SGBase.ESGCharacterSoundType
enum class ESGCharacterSoundType : uint8_t
{
    ENone                                          = 0,
    ELeftFoot                                      = 1,
    ERightFoot                                     = 2,
    EJump                                          = 3,
    ELand                                          = 4,
    EHitReact                                      = 5,
    EHitReact_Med                                  = 6,
    EHitReact_Heavy                                = 7,
    EFallDmg                                       = 8,
    ERelief                                        = 9,
    EDead                                          = 10,
    EDeadLand                                      = 11,
    ESkateJump                                     = 12,
    ESkateLand                                     = 13,
    EMeleeAttack                                   = 14,
    EMeleeInspectMed                               = 15,
    EMeleeInspectShort                             = 16,
    EMeleeInspectDownSmall                         = 17,
    EMeleeEquip                                    = 18,
    EArmLongRamp                                   = 19,
    EArmMedGunDown                                 = 20,
    EArmMedShort                                   = 21,
    EArmFastShort                                  = 22,
    EGunInspectMed                                 = 23,
    EArmMedGunUp                                   = 24,
    EArmRShortFast                                 = 25,
    ESGCharacterSoundType_MAX                      = 26

};


// Enum  /Script/SGBase.ESGOctaDirection
enum class ESGOctaDirection : uint8_t
{
    ECenter                                        = 0,
    EForward                                       = 1,
    EBackward                                      = 2,
    ELeft                                          = 3,
    ERight                                         = 4,
    ELeftForward                                   = 5,
    ERightForward                                  = 6,
    ELeftBackward                                  = 7,
    ERightBackward                                 = 8,
    EMax                                           = 9,
    ESGOctaDirection_MAX                           = 10

};


// Enum  /Script/SGBase.ESGQuatDirection
enum class ESGQuatDirection : uint8_t
{
    ECenter                                        = 0,
    EForward                                       = 1,
    EBackward                                      = 2,
    ELeft                                          = 3,
    ERight                                         = 4,
    EMax                                           = 5,
    ESGQuatDirection_MAX                           = 6

};


// Enum  /Script/SGBase.ESGCampSettingOptions
enum class ESGCampSettingOptions : uint8_t
{
    ENone                                          = 0,
    ETeammateOnly                                  = 1,
    EEnemyOnly                                     = 2,
    ETeammateAndEnemy                              = 3,
    ESelfOnly                                      = 4,
    ETeammateAndSelf                               = 5,
    EAnyCamp                                       = 7,
    ESGCampSettingOptions_MAX                      = 8

};


// Enum  /Script/SGBase.ESGCameraScopeState
enum class ESGCameraScopeState : uint8_t
{
    EScopeOut                                      = 0,
    EScopeIn                                       = 1,
    ESGCameraScopeState_MAX                        = 2

};


// Enum  /Script/SGBase.ESGCameraViewMode
enum class ESGCameraViewMode : uint8_t
{
    EFPPCamera                                     = 0,
    ETPPCamera                                     = 1,
    ESGCameraViewMode_MAX                          = 2

};


// Enum  /Script/SGBase.ESGPawnHealthState
enum class ESGPawnHealthState : uint8_t
{
    EAlive                                         = 0,
    EDying                                         = 1,
    EDead                                          = 2,
    ESGPawnHealthState_MAX                         = 3

};


// Enum  /Script/SGBase.ESGPawnPoseState
enum class ESGPawnPoseState : uint8_t
{
    EStand                                         = 0,
    ECrouch                                        = 1,
    EProne                                         = 2,
    ESGPawnPoseState_MAX                           = 3

};


// Enum  /Script/SGBase.ESGVarImplicitType
enum class ESGVarImplicitType : uint8_t
{
    None                                           = 0,
    Number                                         = 1,
    String                                         = 2,
    MAX                                            = 3

};


// Enum  /Script/SGBase.ESGVarType
enum class ESGVarType : uint8_t
{
    None                                           = 0,
    Bool                                           = 1,
    Byte                                           = 2,
    Int                                            = 3,
    Int64                                          = 4,
    Float                                          = 5,
    Double                                         = 6,
    Name                                           = 7,
    String                                         = 8,
    Text                                           = 9,
    ActorGuid                                      = 10,
    Guid                                           = 11,
    Vector                                         = 12,
    Rotator                                        = 13,
    Transform                                      = 14,
    Color                                          = 15,
    LinearColor                                    = 16,
    SoftObjectPath                                 = 17,
    SoftClassPath                                  = 18,
    Object                                         = 19,
    MAX                                            = 20

};


// Enum  /Script/SGBase.EVarLevel
enum class EVarLevel : uint8_t
{
    Local                                          = 0,
    Actor                                          = 1,
    Scene                                          = 2,
    Global                                         = 3,
    Event                                          = 4,
    AutoLevel                                      = 5,
    MAX                                            = 6

};


// Enum  /Script/SGAS.EAbilityDataType
enum class EAbilityDataType : uint8_t
{
    None                                           = 0,
    Circle                                         = 1,
    Arrow                                          = 2,
    Box                                            = 3,
    Wall                                           = 4,
    Point                                          = 5,
    Sec                                            = 6,
    EAbilityDataType_MAX                           = 7

};


// Enum  /Script/SGAS.ESGAbilityResetReason
enum class ESGAbilityResetReason : uint8_t
{
    ForceCancel                                    = 0,
    ResetPlayer                                    = 1,
    SwitchRound                                    = 2,
    PlayerDead                                     = 3,
    RespawnPlayer                                  = 4,
    ESGAbilityResetReason_MAX                      = 5

};


// Enum  /Script/SGAS.EExInputActionType
enum class EExInputActionType : uint8_t
{
    Pressed                                        = 0,
    Released                                       = 1,
    EExInputActionType_MAX                         = 2

};


// Enum  /Script/SGAS.ESGAbilityResetResponse
enum class ESGAbilityResetResponse : uint8_t
{
    None                                           = 0,
    Cancel                                         = 1,
    Activate                                       = 2,
    Reactivate                                     = 3,
    ESGAbilityResetResponse_MAX                    = 4

};


// Enum  /Script/SGAS.ESGAbilityActiveType
enum class ESGAbilityActiveType : uint8_t
{
    None                                           = 0,
    OnSlotEquiped                                  = 1,
    OnAvatarChanged                                = 2,
    ESGAbilityActiveType_MAX                       = 3

};


// Enum  /Script/SGAS.ESGRepAnimPositionMethod
enum class ESGRepAnimPositionMethod : uint8_t
{
    Position                                       = 0,
    CurrentSectionId                               = 1,
    ESGRepAnimPositionMethod_MAX                   = 2

};


// Enum  /Script/SGAS.EAbilityActorStage
enum class EAbilityActorStage : uint8_t
{
    ActiveStart                                    = 0,
    Activating                                     = 1,
    ActiveEnd                                      = 2,
    MultiSwitch_PreActivate                        = 3,
    MultiSwitch_Activate                           = 4,
    MultiSwitch_PreDeactivate                      = 5,
    MultiSwitch_Deactivate                         = 6,
    Recall                                         = 7,
    EAbilityActorStage_MAX                         = 8

};


// Enum  /Script/SGAS.ESGPhantomType
enum class ESGPhantomType : uint8_t
{
    None                                           = 0,
    PhantomCharacter                               = 1,
    PhantomAgent                                   = 2,
    PhantomBot                                     = 3,
    ESGPhantomType_MAX                             = 4

};


// Enum  /Script/SGAS.ESGCharacterType
enum class ESGCharacterType : uint8_t
{
    None                                           = 0,
    PlayerPawn                                     = 1,
    AbilityMonster                                 = 2,
    ESGCharacterType_MAX                           = 3

};


// Enum  /Script/SGAS.EAbilityDamageTargetType
enum class EAbilityDamageTargetType : uint8_t
{
    None                                           = 0,
    Machine                                        = 1,
    Organism                                       = 2,
    EAbilityDamageTargetType_MAX                   = 3

};


// Enum  /Script/SGAS.ESGAbilityTargetActor_Overlap_Type
enum class ESGAbilityTargetActor_Overlap_Type : uint8_t
{
    SourceActor                                    = 0,
    TargetActor                                    = 1,
    Box                                            = 2,
    Sphere                                         = 3,
    Capsule                                        = 4,
    ESGAbilityTargetActor_Overlap_MAX              = 5

};


// Enum  /Script/SGAS.ELineTraceHitType
enum class ELineTraceHitType : uint8_t
{
    HitFirstValidTarget                            = 0,
    SingleLineTrace                                = 1,
    SingleLineTraceByChannel                       = 2,
    ELineTraceHitType_MAX                          = 3

};


// Enum  /Script/SGAS.ESGWaitGameplayTagType
enum class ESGWaitGameplayTagType : uint8_t
{
    WaitTagsRemoveOnly                             = 0,
    WaitTagsRemoveOrAdd                            = 1,
    WaitTagsAdditiveOnly                           = 2,
    ESGWaitGameplayTagType_MAX                     = 3

};


// Enum  /Script/SGAS.ESGASLogLevel
enum class ESGASLogLevel : uint8_t
{
    Log                                            = 0,
    Warning                                        = 1,
    Error                                          = 2,
    ESGASLogLevel_MAX                              = 3

};


// Enum  /Script/SGAS.EAbilityTaskCacheState
enum class EAbilityTaskCacheState : uint8_t
{
    Pending_Free                                   = 0,
    Free                                           = 1,
    Using                                          = 2,
    EAbilityTaskCacheState_MAX                     = 3

};


// Enum  /Script/SGAS.EBuffStateRelation
enum class EBuffStateRelation : uint8_t
{
    Coexist                                        = 0,
    Suspend                                        = 1,
    Interrupt                                      = 2,
    Forbid                                         = 3,
    MAX                                            = 4

};


// Enum  /Script/SGAS.ESGWaitAttributeChangeComparison
enum class ESGWaitAttributeChangeComparison : uint8_t
{
    None                                           = 0,
    GreaterThan                                    = 1,
    LessThan                                       = 2,
    GreaterThanOrEqualTo                           = 3,
    LessThanOrEqualTo                              = 4,
    NotEqualTo                                     = 5,
    ExactlyEqualTo                                 = 6,
    MAX                                            = 7

};


// Enum  /Script/TimeLineAbilityCore.EInputInfo
enum class EInputInfo : uint8_t
{
    LeftMouseButton                                = 0,
    RightMouseButton                               = 1,
    BackSpace                                      = 2,
    Enter                                          = 3,
    One                                            = 4,
    Two                                            = 5,
    Three                                          = 6,
    A                                              = 7,
    Q                                              = 8,
    E                                              = 9,
    Z                                              = 10,
    C                                              = 11,
    X                                              = 12,
    R                                              = 13,
    T                                              = 14,
    N                                              = 15,
    M                                              = 16,
    EInputInfo_MAX                                 = 17

};


// Enum  /Script/TimeLineAbilityCore.EGANotifyEndReasion
enum class EGANotifyEndReasion : uint8_t
{
    Default                                        = 0,
    OwnerEnded                                     = 1,
    EGANotifyEndReasion_MAX                        = 2

};


// Enum  /Script/TimeLineAbilityCore.EGANotifyType
enum class EGANotifyType : uint8_t
{
    Empty                                          = 0,
    Function                                       = 1,
    Task                                           = 2,
    EGANotifyType_MAX                              = 3

};


// Enum  /Script/TimeLineAbilityCore.ETimeLineGATaskDuration
enum class ETimeLineGATaskDuration : uint8_t
{
    Instant                                        = 0,
    DefaultDuration                                = 1,
    CustomDuration                                 = 2,
    ETimeLineGATaskDuration_MAX                    = 3

};


// Enum  /Script/SMSystem.ESMNetworkConfigurationType
enum class ESMNetworkConfigurationType : uint8_t
{
    SM_Client                                      = 0,
    SM_Server                                      = 1,
    SM_ClientAndServer                             = 2,
    SM_MAX                                         = 3

};


// Enum  /Script/SMSystem.ESMTransactionType
enum class ESMTransactionType : uint8_t
{
    SM_Transition                                  = 0,
    SM_State                                       = 1,
    SM_MAX                                         = 2

};


// Enum  /Script/SMSystem.ESMConditionalEvaluationType
enum class ESMConditionalEvaluationType : uint8_t
{
    SM_Graph                                       = 0,
    SM_NodeInstance                                = 1,
    SM_AlwaysFalse                                 = 2,
    SM_AlwaysTrue                                  = 3,
    SM_MAX                                         = 4

};


// Enum  /Script/PixUI.EPxKeyboardTypes
enum class EPxKeyboardTypes : uint8_t
{
    Default                                        = 0,
    Number                                         = 1,
    Password                                       = 2,
    MultiLine                                      = 3,
    EPxKeyboardTypes_MAX                           = 4

};


// Enum  /Script/PixUI.EPxWidgetTransformType
enum class EPxWidgetTransformType : uint8_t
{
    MoveBy                                         = 0,
    MoveTo                                         = 1,
    ResizeBy                                       = 2,
    ResizeTo                                       = 3,
    ScrollBy                                       = 4,
    ScrollTo                                       = 5,
    Count                                          = 6,
    EPxWidgetTransformType_MAX                     = 7

};


// Enum  /Script/PixUI.EPxFontFaceType
enum class EPxFontFaceType : uint8_t
{
    FaceType100                                    = 0,
    FaceType200                                    = 1,
    FaceType300                                    = 2,
    FaceType350                                    = 3,
    FaceType400                                    = 4,
    FaceType500                                    = 5,
    FaceType600                                    = 6,
    FaceType700                                    = 7,
    FaceType800                                    = 8,
    FaceType900                                    = 9,
    FaceType950                                    = 10,
    EPxFontFaceType_MAX                            = 11

};


// Enum  /Script/PixUI.EPxDynamicTextureUpdateMode
enum class EPxDynamicTextureUpdateMode : uint8_t
{
    UpdateRegion                                   = 0,
    UpdateBulkData                                 = 1,
    EPxDynamicTextureUpdateMode_MAX                = 2

};


// Enum  /Script/PixUI.EPxKeyEventType
enum class EPxKeyEventType : uint8_t
{
    KeyDown                                        = 0,
    KeyUp                                          = 1,
    EPxKeyEventType_MAX                            = 2

};


// Enum  /Script/PixUI.EPxMouseType
enum class EPxMouseType : uint8_t
{
    MouseLeft                                      = 0,
    MouseRight                                     = 1,
    MouseMiddle                                    = 2,
    MouseThumb                                     = 3,
    MouseThumb2                                    = 4,
    EPxMouseType_MAX                               = 5

};


// Enum  /Script/PixUI.EPxTouchType
enum class EPxTouchType : uint8_t
{
    TouchStart                                     = 0,
    TouchMoved                                     = 1,
    TouchEnd                                       = 2,
    TouchCanceled                                  = 3,
    EPxTouchType_MAX                               = 4

};


// Enum  /Script/PixUI.EPxDebugInfo
enum class EPxDebugInfo : uint8_t
{
    ShowMouse                                      = 0,
    Count                                          = 1,
    EPxDebugInfo_MAX                               = 2

};


// Enum  /Script/PixUI.EPxWidgetBatchType
enum class EPxWidgetBatchType : uint8_t
{
    Default                                        = 0,
    Auto                                           = 1,
    NoBatch                                        = 2,
    EPxWidgetBatchType_MAX                         = 3

};


// Enum  /Script/PixUILog.EPxLogLevels
enum class EPxLogLevels : uint8_t
{
    Log                                            = 0,
    Warning                                        = 1,
    Error                                          = 2,
    Debug                                          = 3,
    Count                                          = 4,
    EPxLogLevels_MAX                               = 5

};


// Enum  /Script/PixUILog.EPxLogGroups
enum class EPxLogGroups : uint8_t
{
    Core                                           = 0,
    Plugin                                         = 1,
    Script                                         = 2,
    Profiler                                       = 3,
    Count                                          = 4,
    EPxLogGroups_MAX                               = 5

};


// Enum  /Script/Gamelet.EGameletEnvironment
enum class EGameletEnvironment : uint8_t
{
    Gamelet_Test                                   = 0,
    Gamelet_Product                                = 1,
    Gamelet_SingaporeTest                          = 2,
    Gamelet_SingaporeProduct                       = 3,
    Gamelet_MAX                                    = 4

};


// Enum  /Script/Gamelet.ECmd
enum class ECmd : uint32_t
{
    ECmdGSendMessageToApp                          = 10001,
    ECmdS2ESDKInitialized                          = 40001,
    ECmdS2EOnCgiProcessComplete                    = 40002,
    ECmdS2EStartPuertsVM                           = 40003,
    ECmdS2EPrepareGcrpRes                          = 40004,
    ECmdS2PMin                                     = 60000,
    ECmdS2PMax                                     = 69999,
    ECmd_MAX                                       = 70000

};


// Enum  /Script/QRCodeUtility.EZXingFormat
enum class EZXingFormat : uint8_t
{
    NONE                                           = 0,
    AZTEC                                          = 1,
    CODABAR                                        = 2,
    CODE                                           = 3,
    CODE                                           = 4,
    CODE                                           = 5,
    DATA_MATRIX                                    = 6,
    EAN                                            = 7,
    EAN                                            = 8,
    ITF                                            = 9,
    MAXICODE                                       = 10,
    PDF                                            = 11,
    QR_CODE                                        = 12,
    RSS                                            = 13,
    RSS_EXPANDED                                   = 14,
    UPC_A                                          = 15,
    UPC_E                                          = 16,
    UPC_EAN_EXTENSION                              = 17,
    EZXingFormat_MAX                               = 18

};


// Enum  /Script/CommonLib.DownloadResult
enum class DownloadResult : uint8_t
{
    SuccessDownloading                             = 0,
    DownloadFailed                                 = 1,
    SaveFailed                                     = 2,
    DirectoryCreationFailed                        = 3,
    DownloadResult_MAX                             = 4

};


// Enum  /Script/ReAutomatic.EUIType
enum class EUIType : uint8_t
{
    Any                                            = 0,
    Clickable                                      = 1,
    TextInput                                      = 2,
    Scrollable                                     = 3,
    Text                                           = 4,
    Checkable                                      = 5,
    EUIType_MAX                                    = 6

};


// Enum  /Script/ReAutomatic.ERouteProtoID
enum class ERouteProtoID : uint8_t
{
    Regist                                         = 0,
    NormalMessage                                  = 1,
    Close                                          = 2,
    HeartBeat                                      = 3,
    Log                                            = 4,
    ListDevice                                     = 5,
    Max                                            = 5

};


// Enum  /Script/ReAutomatic.ERouteType
enum class ERouteType : uint8_t
{
    RouteServer                                    = 0,
    LocalController                                = 1,
    MobileDevice                                   = 2,
    UnrealEngine                                   = 3,
    WebService                                     = 4,
    Max                                            = 4

};


// Enum  /Script/ProceduralMeshComponent.EProcMeshSliceCapOption
enum class EProcMeshSliceCapOption : uint8_t
{
    NoCap                                          = 0,
    CreateNewSectionForCap                         = 1,
    UseLastSectionForCap                           = 2,
    EProcMeshSliceCapOption_MAX                    = 3

};


// Enum  /Script/UEDebugger.EUEDebuggerTickType
enum class EUEDebuggerTickType : uint8_t
{
    TickInEditorOnly                               = 0,
    TickInEditorAndGameplay                        = 1,
    TickInGameplayOnly                             = 2,
    EUEDebuggerTickType_MAX                        = 3

};


// Enum  /Script/DatasmithContent.EDatasmithAreaLightActorType
enum class EDatasmithAreaLightActorType : uint8_t
{
    Point                                          = 0,
    Spot                                           = 1,
    Rect                                           = 2,
    EDatasmithAreaLightActorType_MAX               = 3

};


// Enum  /Script/DatasmithContent.EDatasmithAreaLightActorShape
enum class EDatasmithAreaLightActorShape : uint8_t
{
    Rectangle                                      = 0,
    Disc                                           = 1,
    Sphere                                         = 2,
    Cylinder                                       = 3,
    None                                           = 4,
    EDatasmithAreaLightActorShape_MAX              = 5

};


// Enum  /Script/DatasmithContent.EDatasmithCADRetessellationRule
enum class EDatasmithCADRetessellationRule : uint8_t
{
    All                                            = 0,
    SkipDeletedSurfaces                            = 1,
    EDatasmithCADRetessellationRule_MAX            = 2

};


// Enum  /Script/DatasmithContent.EDatasmithCADStitchingTechnique
enum class EDatasmithCADStitchingTechnique : uint8_t
{
    StitchingNone                                  = 0,
    StitchingHeal                                  = 1,
    StitchingSew                                   = 2,
    EDatasmithCADStitchingTechnique_MAX            = 3

};


// Enum  /Script/DatasmithContent.EDatasmithImportHierarchy
enum class EDatasmithImportHierarchy : uint8_t
{
    UseMultipleActors                              = 0,
    UseSingleActor                                 = 1,
    UseOneBlueprint                                = 2,
    EDatasmithImportHierarchy_MAX                  = 3

};


// Enum  /Script/DatasmithContent.EDatasmithImportScene
enum class EDatasmithImportScene : uint8_t
{
    NewLevel                                       = 0,
    CurrentLevel                                   = 1,
    AssetsOnly                                     = 2,
    EDatasmithImportScene_MAX                      = 3

};


// Enum  /Script/DatasmithContent.EDatasmithImportLightmapMax
enum class EDatasmithImportLightmapMax : uint8_t
{
    LIGHTMAP                                       = 0,
    LIGHTMAP                                       = 1,
    LIGHTMAP                                       = 2,
    LIGHTMAP                                       = 3,
    LIGHTMAP                                       = 4,
    LIGHTMAP                                       = 5,
    LIGHTMAP                                       = 6,
    LIGHTMAP_MAX                                   = 7

};


// Enum  /Script/DatasmithContent.EDatasmithImportLightmapMin
enum class EDatasmithImportLightmapMin : uint8_t
{
    LIGHTMAP                                       = 0,
    LIGHTMAP                                       = 1,
    LIGHTMAP                                       = 2,
    LIGHTMAP                                       = 3,
    LIGHTMAP                                       = 4,
    LIGHTMAP                                       = 5,
    LIGHTMAP_MAX                                   = 6

};


// Enum  /Script/DatasmithContent.EDatasmithImportMaterialQuality
enum class EDatasmithImportMaterialQuality : uint8_t
{
    UseNoFresnelCurves                             = 0,
    UseSimplifierFresnelCurves                     = 1,
    UseRealFresnelCurves                           = 2,
    EDatasmithImportMaterialQuality_MAX            = 3

};


// Enum  /Script/DatasmithContent.EDatasmithImportActorPolicy
enum class EDatasmithImportActorPolicy : uint8_t
{
    Update                                         = 0,
    Full                                           = 1,
    Ignore                                         = 2,
    EDatasmithImportActorPolicy_MAX                = 3

};


// Enum  /Script/DatasmithContent.EDatasmithImportAssetConflictPolicy
enum class EDatasmithImportAssetConflictPolicy : uint8_t
{
    Replace                                        = 0,
    Update                                         = 1,
    Use                                            = 2,
    Ignore                                         = 3,
    EDatasmithImportAssetConflictPolicy_MAX        = 4

};


// Enum  /Script/DatasmithContent.EDatasmithImportSearchPackagePolicy
enum class EDatasmithImportSearchPackagePolicy : uint8_t
{
    Current                                        = 0,
    All                                            = 1,
    EDatasmithImportSearchPackagePolicy_MAX        = 2

};


// Enum  /Script/VariantManagerContent.EPropertyValueCategory
enum class EPropertyValueCategory : uint8_t
{
    Undefined                                      = 0,
    Generic                                        = 1,
    RelativeLocation                               = 2,
    RelativeRotation                               = 4,
    RelativeScale3D                                = 8,
    Visibility                                     = 16,
    Material                                       = 32,
    Color                                          = 64,
    Option                                         = 128,
    EPropertyValueCategory_MAX                     = 129

};


// Enum  /Script/ChaosCloth.EChaosClothTetherMode
enum class EChaosClothTetherMode : uint8_t
{
    FastTetherFastLength                           = 0,
    AccurateTetherFastLength                       = 1,
    AccurateTetherAccurateLength                   = 2,
    MaxChaosClothTetherMode                        = 3,
    EChaosClothTetherMode_MAX                      = 4

};


// Enum  /Script/ChaosCloth.EChaosWeightMapTarget
enum class EChaosWeightMapTarget : uint8_t
{
    None                                           = 0,
    MaxDistance                                    = 1,
    BackstopDistance                               = 2,
    BackstopRadius                                 = 3,
    AnimDriveMultiplier                            = 4,
    EChaosWeightMapTarget_MAX                      = 5

};


// Enum  /Script/EditableMesh.ETriangleTessellationMode
enum class ETriangleTessellationMode : uint8_t
{
    ThreeTriangles                                 = 0,
    FourTriangles                                  = 1,
    ETriangleTessellationMode_MAX                  = 2

};


// Enum  /Script/EditableMesh.EInsetPolygonsMode
enum class EInsetPolygonsMode : uint8_t
{
    All                                            = 0,
    CenterPolygonOnly                              = 1,
    SidePolygonsOnly                               = 2,
    EInsetPolygonsMode_MAX                         = 3

};


// Enum  /Script/EditableMesh.EPolygonEdgeHardness
enum class EPolygonEdgeHardness : uint8_t
{
    NewEdgesSoft                                   = 0,
    NewEdgesHard                                   = 1,
    AllEdgesSoft                                   = 2,
    AllEdgesHard                                   = 3,
    EPolygonEdgeHardness_MAX                       = 4

};


// Enum  /Script/EditableMesh.EMeshElementAttributeType
enum class EMeshElementAttributeType : uint8_t
{
    None                                           = 0,
    FVector4                                       = 1,
    FVector                                        = 2,
    FVector2D                                      = 3,
    Float                                          = 4,
    Int                                            = 5,
    Bool                                           = 6,
    FName                                          = 7,
    EMeshElementAttributeType_MAX                  = 8

};


// Enum  /Script/EditableMesh.EMeshTopologyChange
enum class EMeshTopologyChange : uint8_t
{
    NoTopologyChange                               = 0,
    TopologyChange                                 = 1,
    EMeshTopologyChange_MAX                        = 2

};


// Enum  /Script/EditableMesh.EMeshModificationType
enum class EMeshModificationType : uint8_t
{
    FirstInterim                                   = 0,
    Interim                                        = 1,
    Final                                          = 2,
    EMeshModificationType_MAX                      = 3

};


// Enum  /Script/MergeEverything.EMergeMaterialTextureType
enum class EMergeMaterialTextureType : uint8_t
{
    EmissiveColor                                  = 0,
    Opacity                                        = 1,
    OpacityMask                                    = 2,
    BaseColor                                      = 5,
    Metallic                                       = 6,
    Specular                                       = 7,
    Roughness                                      = 8,
    Anisotropy                                     = 9,
    Normal                                         = 10,
    Tangent                                        = 11,
    AmbientOcclusion                               = 18,
    EMergeMaterialTextureType_MAX                  = 19

};


// Enum  /Script/MergeEverything.EMergeMaterialTextureResolution
enum class EMergeMaterialTextureResolution : uint8_t
{
    Res                                            = 0,
    Res                                            = 1,
    Res                                            = 2,
    Res                                            = 3,
    Res                                            = 4,
    Res_MAX                                        = 5

};


// Enum  /Script/UdpMessaging.EUdpMessageFormat
enum class EUdpMessageFormat : uint8_t
{
    None                                           = 0,
    Json                                           = 1,
    TaggedProperty                                 = 2,
    CborPlatformEndianness                         = 3,
    CborStandardEndianness                         = 4,
    EUdpMessageFormat_MAX                          = 5

};


// Enum  /Script/ActorSequence.EActorSequenceObjectReferenceType
enum class EActorSequenceObjectReferenceType : uint8_t
{
    ContextActor                                   = 0,
    ExternalActor                                  = 1,
    Component                                      = 2,
    EActorSequenceObjectReferenceType_MAX          = 3

};


// Enum  /Script/OnlineSubsystem.EInAppPurchaseState
enum class EInAppPurchaseState : uint8_t
{
    Unknown                                        = 0,
    Success                                        = 1,
    Failed                                         = 2,
    Cancelled                                      = 3,
    Invalid                                        = 4,
    NotAllowed                                     = 5,
    Restored                                       = 6,
    AlreadyOwned                                   = 7,
    EInAppPurchaseState_MAX                        = 8

};


// Enum  /Script/OnlineSubsystem.EMPMatchOutcome
enum class EMPMatchOutcome : uint8_t
{
    None                                           = 0,
    Quit                                           = 1,
    Won                                            = 2,
    Lost                                           = 3,
    Tied                                           = 4,
    TimeExpired                                    = 5,
    First                                          = 6,
    Second                                         = 7,
    Third                                          = 8,
    Fourth                                         = 9,
    EMPMatchOutcome_MAX                            = 10

};


// Enum  /Script/OnlineSubsystemUtils.EInAppPurchaseStatus
enum class EInAppPurchaseStatus : uint8_t
{
    Invalid                                        = 0,
    Failed                                         = 1,
    Deferred                                       = 2,
    Canceled                                       = 3,
    Purchased                                      = 4,
    Restored                                       = 5,
    EInAppPurchaseStatus_MAX                       = 6

};


// Enum  /Script/OnlineSubsystemUtils.EOnlineProxyStoreOfferDiscountType
enum class EOnlineProxyStoreOfferDiscountType : uint8_t
{
    NotOnSale                                      = 0,
    Percentage                                     = 1,
    DiscountAmount                                 = 2,
    PayAmount                                      = 3,
    EOnlineProxyStoreOfferDiscountType_MAX         = 4

};


// Enum  /Script/OnlineSubsystemUtils.EBeaconConnectionState
enum class EBeaconConnectionState : uint8_t
{
    Invalid                                        = 0,
    Closed                                         = 1,
    Pending                                        = 2,
    Open                                           = 3,
    EBeaconConnectionState_MAX                     = 4

};


// Enum  /Script/OnlineSubsystemUtils.EClientRequestType
enum class EClientRequestType : uint8_t
{
    NonePending                                    = 0,
    ExistingSessionReservation                     = 1,
    ReservationUpdate                              = 2,
    EmptyServerReservation                         = 3,
    Reconnect                                      = 4,
    Abandon                                        = 5,
    ReservationRemoveMembers                       = 6,
    EClientRequestType_MAX                         = 7

};


// Enum  /Script/OnlineSubsystemUtils.EPartyReservationResult
enum class EPartyReservationResult : uint8_t
{
    NoResult                                       = 0,
    RequestPending                                 = 1,
    GeneralError                                   = 2,
    PartyLimitReached                              = 3,
    IncorrectPlayerCount                           = 4,
    RequestTimedOut                                = 5,
    ReservationDuplicate                           = 6,
    ReservationNotFound                            = 7,
    ReservationAccepted                            = 8,
    ReservationDenied                              = 9,
    ReservationDenied_CrossPlayRestriction         = 10,
    ReservationDenied_Banned                       = 11,
    ReservationRequestCanceled                     = 12,
    ReservationInvalid                             = 13,
    BadSessionId                                   = 14,
    ReservationDenied_ContainsExistingPlayers      = 15,
    EPartyReservationResult_MAX                    = 16

};


// Enum  /Script/OnlineSubsystemUtils.ESpectatorClientRequestType
enum class ESpectatorClientRequestType : uint8_t
{
    NonePending                                    = 0,
    ExistingSessionReservation                     = 1,
    ReservationUpdate                              = 2,
    EmptyServerReservation                         = 3,
    Reconnect                                      = 4,
    Abandon                                        = 5,
    ESpectatorClientRequestType_MAX                = 6

};


// Enum  /Script/OnlineSubsystemUtils.ESpectatorReservationResult
enum class ESpectatorReservationResult : uint8_t
{
    NoResult                                       = 0,
    RequestPending                                 = 1,
    GeneralError                                   = 2,
    SpectatorLimitReached                          = 3,
    IncorrectPlayerCount                           = 4,
    RequestTimedOut                                = 5,
    ReservationDuplicate                           = 6,
    ReservationNotFound                            = 7,
    ReservationAccepted                            = 8,
    ReservationDenied                              = 9,
    ReservationDenied_CrossPlayRestriction         = 10,
    ReservationDenied_Banned                       = 11,
    ReservationRequestCanceled                     = 12,
    ReservationInvalid                             = 13,
    BadSessionId                                   = 14,
    ReservationDenied_ContainsExistingPlayers      = 15,
    ESpectatorReservationResult_MAX                = 16

};


// Enum  /Script/AppleImageUtils.EAppleTextureType
enum class EAppleTextureType : uint8_t
{
    Unknown                                        = 0,
    Image                                          = 1,
    PixelBuffer                                    = 2,
    Surface                                        = 3,
    MetalTexture                                   = 4,
    EAppleTextureType_MAX                          = 5

};


// Enum  /Script/AppleImageUtils.ETextureRotationDirection
enum class ETextureRotationDirection : uint8_t
{
    None                                           = 0,
    Left                                           = 1,
    Right                                          = 2,
    Down                                           = 3,
    LeftMirrored                                   = 4,
    RightMirrored                                  = 5,
    DownMirrored                                   = 6,
    UpMirrored                                     = 7,
    ETextureRotationDirection_MAX                  = 8

};


// Enum  /Script/AssetTags.ECollectionScriptingShareType
enum class ECollectionScriptingShareType : uint8_t
{
    Local                                          = 0,
    Private                                        = 1,
    Shared                                         = 2,
    ECollectionScriptingShareType_MAX              = 3

};


// Enum  /Script/LocationServicesBPLibrary.ELocationAccuracy
enum class ELocationAccuracy : uint8_t
{
    LA_ThreeKilometers                             = 0,
    LA_OneKilometer                                = 1,
    LA_HundredMeters                               = 2,
    LA_TenMeters                                   = 3,
    LA_Best                                        = 4,
    LA_Navigation                                  = 5,
    LA_MAX                                         = 6

};


// Enum  /Script/PhysXVehicles.EWheelSweepType
enum class EWheelSweepType : uint8_t
{
    SimpleAndComplex                               = 0,
    Simple                                         = 1,
    Complex                                        = 2,
    EWheelSweepType_MAX                            = 3

};


// Enum  /Script/PhysXVehicles.EVehicleDifferential4W
enum class EVehicleDifferential4W : uint8_t
{
    LimitedSlip_4W                                 = 0,
    LimitedSlip_FrontDrive                         = 1,
    LimitedSlip_RearDrive                          = 2,
    Open_4W                                        = 3,
    Open_FrontDrive                                = 4,
    Open_RearDrive                                 = 5,
    EVehicleDifferential4W_MAX                     = 6

};


// Enum  /Script/Synthesis.ESynth1PatchDestination
enum class ESynth1PatchDestination : uint8_t
{
    Osc1Gain                                       = 0,
    Osc1Frequency                                  = 1,
    Osc1Pulsewidth                                 = 2,
    Osc2Gain                                       = 3,
    Osc2Frequency                                  = 4,
    Osc2Pulsewidth                                 = 5,
    FilterFrequency                                = 6,
    FilterQ                                        = 7,
    Gain                                           = 8,
    Pan                                            = 9,
    LFO1Frequency                                  = 10,
    LFO1Gain                                       = 11,
    LFO2Frequency                                  = 12,
    LFO2Gain                                       = 13,
    Count                                          = 14,
    ESynth1PatchDestination_MAX                    = 15

};


// Enum  /Script/Synthesis.ESynth1PatchSource
enum class ESynth1PatchSource : uint8_t
{
    LFO1                                           = 0,
    LFO2                                           = 1,
    Envelope                                       = 2,
    BiasEnvelope                                   = 3,
    Count                                          = 4,
    ESynth1PatchSource_MAX                         = 5

};


// Enum  /Script/Synthesis.ESynthStereoDelayMode
enum class ESynthStereoDelayMode : uint8_t
{
    Normal                                         = 0,
    Cross                                          = 1,
    PingPong                                       = 2,
    Count                                          = 3,
    ESynthStereoDelayMode_MAX                      = 4

};


// Enum  /Script/Synthesis.ESynthFilterAlgorithm
enum class ESynthFilterAlgorithm : uint8_t
{
    OnePole                                        = 0,
    StateVariable                                  = 1,
    Ladder                                         = 2,
    Count                                          = 3,
    ESynthFilterAlgorithm_MAX                      = 4

};


// Enum  /Script/Synthesis.ESynthFilterType
enum class ESynthFilterType : uint8_t
{
    LowPass                                        = 0,
    HighPass                                       = 1,
    BandPass                                       = 2,
    BandStop                                       = 3,
    Count                                          = 4,
    ESynthFilterType_MAX                           = 5

};


// Enum  /Script/Synthesis.ESynthModEnvBiasPatch
enum class ESynthModEnvBiasPatch : uint8_t
{
    PatchToNone                                    = 0,
    PatchToOscFreq                                 = 1,
    PatchToFilterFreq                              = 2,
    PatchToFilterQ                                 = 3,
    PatchToLFO1Gain                                = 4,
    PatchToLFO2Gain                                = 5,
    PatchToLFO1Freq                                = 6,
    PatchToLFO2Freq                                = 7,
    Count                                          = 8,
    ESynthModEnvBiasPatch_MAX                      = 9

};


// Enum  /Script/Synthesis.ESynthModEnvPatch
enum class ESynthModEnvPatch : uint8_t
{
    PatchToNone                                    = 0,
    PatchToOscFreq                                 = 1,
    PatchToFilterFreq                              = 2,
    PatchToFilterQ                                 = 3,
    PatchToLFO1Gain                                = 4,
    PatchToLFO2Gain                                = 5,
    PatchToLFO1Freq                                = 6,
    PatchToLFO2Freq                                = 7,
    Count                                          = 8,
    ESynthModEnvPatch_MAX                          = 9

};


// Enum  /Script/Synthesis.ESynthLFOPatchType
enum class ESynthLFOPatchType : uint8_t
{
    PatchToNone                                    = 0,
    PatchToGain                                    = 1,
    PatchToOscFreq                                 = 2,
    PatchToFilterFreq                              = 3,
    PatchToFilterQ                                 = 4,
    PatchToOscPulseWidth                           = 5,
    PatchToOscPan                                  = 6,
    PatchLFO1ToLFO2Frequency                       = 7,
    PatchLFO1ToLFO2Gain                            = 8,
    Count                                          = 9,
    ESynthLFOPatchType_MAX                         = 10

};


// Enum  /Script/Synthesis.ESynthLFOMode
enum class ESynthLFOMode : uint8_t
{
    Sync                                           = 0,
    OneShot                                        = 1,
    Free                                           = 2,
    Count                                          = 3,
    ESynthLFOMode_MAX                              = 4

};


// Enum  /Script/Synthesis.ESynthLFOType
enum class ESynthLFOType : uint8_t
{
    Sine                                           = 0,
    UpSaw                                          = 1,
    DownSaw                                        = 2,
    Square                                         = 3,
    Triangle                                       = 4,
    Exponential                                    = 5,
    RandomSampleHold                               = 6,
    Count                                          = 7,
    ESynthLFOType_MAX                              = 8

};


// Enum  /Script/Synthesis.ESynth1OscType
enum class ESynth1OscType : uint8_t
{
    Sine                                           = 0,
    Saw                                            = 1,
    Triangle                                       = 2,
    Square                                         = 3,
    Noise                                          = 4,
    Count                                          = 5,
    ESynth1OscType_MAX                             = 6

};


// Enum  /Script/Synthesis.ESourceEffectDynamicsPeakMode
enum class ESourceEffectDynamicsPeakMode : uint8_t
{
    MeanSquared                                    = 0,
    RootMeanSquared                                = 1,
    Peak                                           = 2,
    Count                                          = 3,
    ESourceEffectDynamicsPeakMode_MAX              = 4

};


// Enum  /Script/Synthesis.ESourceEffectDynamicsProcessorType
enum class ESourceEffectDynamicsProcessorType : uint8_t
{
    Compressor                                     = 0,
    Limiter                                        = 1,
    Expander                                       = 2,
    Gate                                           = 3,
    Count                                          = 4,
    ESourceEffectDynamicsProcessorType_MAX         = 5

};


// Enum  /Script/Synthesis.EEnvelopeFollowerPeakMode
enum class EEnvelopeFollowerPeakMode : uint8_t
{
    MeanSquared                                    = 0,
    RootMeanSquared                                = 1,
    Peak                                           = 2,
    Count                                          = 3,
    EEnvelopeFollowerPeakMode_MAX                  = 4

};


// Enum  /Script/Synthesis.ESourceEffectFilterParam
enum class ESourceEffectFilterParam : uint8_t
{
    FilterFrequency                                = 0,
    FilterResonance                                = 1,
    Count                                          = 2,
    ESourceEffectFilterParam_MAX                   = 3

};


// Enum  /Script/Synthesis.ESourceEffectFilterType
enum class ESourceEffectFilterType : uint8_t
{
    LowPass                                        = 0,
    HighPass                                       = 1,
    BandPass                                       = 2,
    BandStop                                       = 3,
    Count                                          = 4,
    ESourceEffectFilterType_MAX                    = 5

};


// Enum  /Script/Synthesis.ESourceEffectFilterCircuit
enum class ESourceEffectFilterCircuit : uint8_t
{
    OnePole                                        = 0,
    StateVariable                                  = 1,
    Ladder                                         = 2,
    Count                                          = 3,
    ESourceEffectFilterCircuit_MAX                 = 4

};


// Enum  /Script/Synthesis.EStereoChannelMode
enum class EStereoChannelMode : uint8_t
{
    MidSide                                        = 0,
    LeftRight                                      = 1,
    count                                          = 2,
    EStereoChannelMode_MAX                         = 3

};


// Enum  /Script/Synthesis.EPhaserLFOType
enum class EPhaserLFOType : uint8_t
{
    Sine                                           = 0,
    UpSaw                                          = 1,
    DownSaw                                        = 2,
    Square                                         = 3,
    Triangle                                       = 4,
    Exponential                                    = 5,
    RandomSampleHold                               = 6,
    Count                                          = 7,
    EPhaserLFOType_MAX                             = 8

};


// Enum  /Script/Synthesis.ERingModulatorTypeSourceEffect
enum class ERingModulatorTypeSourceEffect : uint8_t
{
    Sine                                           = 0,
    Saw                                            = 1,
    Triangle                                       = 2,
    Square                                         = 3,
    Count                                          = 4,
    ERingModulatorTypeSourceEffect_MAX             = 5

};


// Enum  /Script/Synthesis.EStereoDelayFiltertype
enum class EStereoDelayFiltertype : uint8_t
{
    Lowpass                                        = 0,
    Highpass                                       = 1,
    Bandpass                                       = 2,
    Notch                                          = 3,
    Count                                          = 4,
    EStereoDelayFiltertype_MAX                     = 5

};


// Enum  /Script/Synthesis.EStereoDelaySourceEffect
enum class EStereoDelaySourceEffect : uint8_t
{
    Normal                                         = 0,
    Cross                                          = 1,
    PingPong                                       = 2,
    Count                                          = 3,
    EStereoDelaySourceEffect_MAX                   = 4

};


// Enum  /Script/Synthesis.ESubmixEffectConvolutionReverbBlockSize
enum class ESubmixEffectConvolutionReverbBlockSize : uint8_t
{
    BlockSize256                                   = 0,
    BlockSize512                                   = 1,
    BlockSize1024                                  = 2,
    ESubmixEffectConvolutionReverbBlockSize_MAX    = 3

};


// Enum  /Script/Synthesis.ESubmixFilterAlgorithm
enum class ESubmixFilterAlgorithm : uint8_t
{
    OnePole                                        = 0,
    StateVariable                                  = 1,
    Ladder                                         = 2,
    Count                                          = 3,
    ESubmixFilterAlgorithm_MAX                     = 4

};


// Enum  /Script/Synthesis.ESubmixFilterType
enum class ESubmixFilterType : uint8_t
{
    LowPass                                        = 0,
    HighPass                                       = 1,
    BandPass                                       = 2,
    BandStop                                       = 3,
    Count                                          = 4,
    ESubmixFilterType_MAX                          = 5

};


// Enum  /Script/Synthesis.ETapLineMode
enum class ETapLineMode : uint8_t
{
    SendToChannel                                  = 0,
    Panning                                        = 1,
    Disabled                                       = 2,
    ETapLineMode_MAX                               = 3

};


// Enum  /Script/Synthesis.EGranularSynthSeekType
enum class EGranularSynthSeekType : uint8_t
{
    FromBeginning                                  = 0,
    FromCurrentPosition                            = 1,
    Count                                          = 2,
    EGranularSynthSeekType_MAX                     = 3

};


// Enum  /Script/Synthesis.EGranularSynthEnvelopeType
enum class EGranularSynthEnvelopeType : uint8_t
{
    Rectangular                                    = 0,
    Triangle                                       = 1,
    DownwardTriangle                               = 2,
    UpwardTriangle                                 = 3,
    ExponentialDecay                               = 4,
    ExponentialIncrease                            = 5,
    Gaussian                                       = 6,
    Hanning                                        = 7,
    Lanczos                                        = 8,
    Cosine                                         = 9,
    CosineSquared                                  = 10,
    Welch                                          = 11,
    Blackman                                       = 12,
    BlackmanHarris                                 = 13,
    Count                                          = 14,
    EGranularSynthEnvelopeType_MAX                 = 15

};


// Enum  /Script/Synthesis.CurveInterpolationType
enum class CurveInterpolationType : uint8_t
{
    AUTOINTERP                                     = 0,
    LINEAR                                         = 1,
    CONSTANT                                       = 2,
    CurveInterpolationType_MAX                     = 3

};


// Enum  /Script/Synthesis.ESamplePlayerSeekType
enum class ESamplePlayerSeekType : uint8_t
{
    FromBeginning                                  = 0,
    FromCurrentPosition                            = 1,
    FromEnd                                        = 2,
    Count                                          = 3,
    ESamplePlayerSeekType_MAX                      = 4

};


// Enum  /Script/Synthesis.ESynthKnobSize
enum class ESynthKnobSize : uint8_t
{
    Medium                                         = 0,
    Large                                          = 1,
    Count                                          = 2,
    ESynthKnobSize_MAX                             = 3

};


// Enum  /Script/Synthesis.ESynthSlateColorStyle
enum class ESynthSlateColorStyle : uint8_t
{
    Light                                          = 0,
    Dark                                           = 1,
    Count                                          = 2,
    ESynthSlateColorStyle_MAX                      = 3

};


// Enum  /Script/Synthesis.ESynthSlateSizeType
enum class ESynthSlateSizeType : uint8_t
{
    Small                                          = 0,
    Medium                                         = 1,
    Large                                          = 2,
    Count                                          = 3,
    ESynthSlateSizeType_MAX                        = 4

};


// Enum  /Script/AudioSynesthesia.EConstantQFFTSizeEnum
enum class EConstantQFFTSizeEnum : uint8_t
{
    Min                                            = 0,
    XXSmall                                        = 1,
    XSmall                                         = 2,
    Small                                          = 3,
    Medium                                         = 4,
    Large                                          = 5,
    XLarge                                         = 6,
    XXLarge                                        = 7,
    Max                                            = 8

};


// Enum  /Script/AudioSynesthesia.EConstantQNormalizationEnum
enum class EConstantQNormalizationEnum : uint8_t
{
    EqualEuclideanNorm                             = 0,
    EqualEnergy                                    = 1,
    EqualAmplitude                                 = 2,
    EConstantQNormalizationEnum_MAX                = 3

};


// Enum  /Script/AudioSynesthesia.ELoudnessNRTCurveTypeEnum
enum class ELoudnessNRTCurveTypeEnum : uint8_t
{
    A                                              = 0,
    B                                              = 1,
    C                                              = 2,
    D                                              = 3,
    None                                           = 4,
    ELoudnessNRTCurveTypeEnum_MAX                  = 5

};


// Enum  /Script/UIParticleSystem2.UIMeshProjectionMethod
enum class UIMeshProjectionMethod : uint8_t
{
    YOZOrtho                                       = 0,
    XOYOrtho                                       = 1,
    YOZPerspectiveFullScreen                       = 2,
    YOZPerspectiveLocal                            = 3,
    UIMeshProjectionMethod_MAX                     = 4

};


// Enum  /Script/Engine.ECollisionChannel
enum class ECollisionChannel : uint8_t
{
    ECC_WorldStatic                                = 0,
    ECC_WorldDynamic                               = 1,
    ECC_Pawn                                       = 2,
    ECC_Visibility                                 = 3,
    ECC_Camera                                     = 4,
    ECC_PhysicsBody                                = 5,
    ECC_Vehicle                                    = 6,
    ECC_Destructible                               = 7,
    ECC_EngineTraceChannel1                        = 8,
    ECC_EngineTraceChannel2                        = 9,
    ECC_EngineTraceChannel3                        = 10,
    ECC_EngineTraceChannel4                        = 11,
    ECC_EngineTraceChannel5                        = 12,
    ECC_EngineTraceChannel6                        = 13,
    ECC_GameTraceChannel1                          = 14,
    ECC_GameTraceChannel2                          = 15,
    ECC_GameTraceChannel3                          = 16,
    ECC_GameTraceChannel4                          = 17,
    ECC_GameTraceChannel5                          = 18,
    ECC_GameTraceChannel6                          = 19,
    ECC_GameTraceChannel7                          = 20,
    ECC_GameTraceChannel8                          = 21,
    ECC_GameTraceChannel9                          = 22,
    ECC_GameTraceChannel10                         = 23,
    ECC_GameTraceChannel11                         = 24,
    ECC_GameTraceChannel12                         = 25,
    ECC_GameTraceChannel13                         = 26,
    ECC_GameTraceChannel14                         = 27,
    ECC_GameTraceChannel15                         = 28,
    ECC_GameTraceChannel16                         = 29,
    ECC_GameTraceChannel17                         = 30,
    ECC_GameTraceChannel18                         = 31,
    ECC_OverlapAll_Deprecated                      = 32,
    ECC_MAX                                        = 33

};


// Enum  /Script/CodeV.ECVAbilityActorState
enum class ECVAbilityActorState : uint8_t
{
    None                                           = 0,
    BeginPlayState                                 = 1,
    MovingState                                    = 2,
    MoveStopState                                  = 3,
    ActiveStartState                               = 4,
    ActivatingState                                = 5,
    ActiveEndState                                 = 6,
    DestructionState                               = 7,
    EndPlayState                                   = 8,
    MaxState                                       = 9,
    Multi_PreActivateState                         = 10,
    Multi_ActivateState                            = 11,
    Multi_PreDeactivateState                       = 12,
    Multi_DeactivateState                          = 13,
    RecallState                                    = 14,
    ECVAbilityActorState_MAX                       = 15

};


// Enum  /Script/Gameplay.EPawnState
enum class EPawnState : uint8_t
{
    None                                           = 0,
    PStand                                         = 1,
    PCrouch                                        = 2,
    PProne                                         = 3,
    PSling                                         = 4,
    MIdle                                          = 9,
    MWalk                                          = 10,
    MRun                                           = 11,
    MSprint                                        = 12,
    MFalling                                       = 13,
    MSwimming                                      = 14,
    MLanding                                       = 15,
    AIdle                                          = 25,
    AFire                                          = 26,
    AReload                                        = 27,
    ABolt                                          = 28,
    ASwitch                                        = 29,
    ALock                                          = 30,
    AStun                                          = 31,
    AEmote                                         = 32,
    AInspect                                       = 33,
    HAlive                                         = 89,
    HDying                                         = 90,
    HDead                                          = 91,
    HRespawn                                       = 92,
    CFPP                                           = 97,
    CTPP                                           = 98,
    VIdle                                          = 113,
    VDriveVeh                                      = 114,
    VInVeh                                         = 115,
    VLeanoutVeh                                    = 116,
    EPawnState_MAX                                 = 117

};


// Enum  /Script/Gameplay.EPawnSyncFlag
enum class EPawnSyncFlag : uint8_t
{
    ENone                                          = 0,
    EInvincible                                    = 1,
    ESlowWalk                                      = 2,
    ERespawn                                       = 5,
    EInvisible                                     = 6,
    EDazing                                        = 7,
    EDisableCrouch                                 = 8,
    ESkate                                         = 9,
    ESlide                                         = 10,
    EFlagMax                                       = 11,
    EPawnSyncFlag_MAX                              = 12

};


// Enum  /Script/Gameplay.EPawnLocalFlag
enum class EPawnLocalFlag : uint8_t
{
    ENone                                          = 0,
    EFreeCamera                                    = 1,
    EInSelfie                                      = 2,
    EScope                                         = 3,
    EMacroFire                                     = 4,
    ELock                                          = 5,
    EInteracting                                   = 6,
    EInvincibleFlag                                = 7,
    ESlowWalkFlag                                  = 8,
    ERespawnFlag                                   = 9,
    EInvisibleFlag                                 = 10,
    EDazingFlag                                    = 11,
    EDisableCrouchFlag                             = 12,
    ESkateFlag                                     = 13,
    ESlideFlag                                     = 14,
    EForceCrouchFlag                               = 15,
    EFlagMax                                       = 16,
    EPawnLocalFlag_MAX                             = 17

};


// Enum  /Script/SGWeapon.EWeaponAssetCategory
enum class EWeaponAssetCategory : uint8_t
{
    Config                                         = 0,
    CharacterAnim                                  = 1,
    WeaponAnim                                     = 2,
    Effect                                         = 3,
    Sound                                          = 4,
    Mesh                                           = 5,
    HUD                                            = 6,
    Ability                                        = 7,
    Kill                                           = 8,
    AnimNotifies                                   = 9,
    Num                                            = 10,
    EWeaponAssetCategory_MAX                       = 11

};


// Enum  /Script/SGWeapon.EWeaponAttachment
enum class EWeaponAttachment : uint8_t
{
    Master                                         = 0,
    MainMagazine                                   = 1,
    ExtraMagazine                                  = 2,
    Scope                                          = 3,
    ScopeOverlay                                   = 4,
    Muzzle                                         = 5,
    Bullet                                         = 6,
    StaticBullet                                   = 7,
    PendentMount                                   = 8,
    PendentBuddy                                   = 9,
    Attach0                                        = 10,
    Attach1                                        = 11,
    Attach2                                        = 12,
    Attach3                                        = 13,
    Attach4                                        = 14,
    Split1                                         = 15,
    Split2                                         = 16,
    Core                                           = 17,
    None                                           = 18,
    Grip                                           = 19,
    Attach5                                        = 20,
    Attach6                                        = 21,
    Attach7                                        = 22,
    Attach8                                        = 23,
    Attach9                                        = 24,
    Attach10                                       = 25,
    Attach11                                       = 26,
    Attach12                                       = 27,
    Attach13                                       = 28,
    Attach14                                       = 29,
    Attach15                                       = 30,
    Max                                            = 31

};


// Enum  /Script/SGWeapon.EWeaponComponentType
enum class EWeaponComponentType : uint8_t
{
    Effect                                         = 0,
    StateManager                                   = 1,
    Launcher                                       = 2,
    Scope                                          = 3,
    Trajectory                                     = 4,
    Misc                                           = 5,
    Num                                            = 6,
    EWeaponComponentType_MAX                       = 7

};


// Enum  /Script/SGWeapon.EWeaponState
enum class EWeaponState : uint8_t
{
    Default                                        = 0,
    Deactivate                                     = 1,
    Active                                         = 2,
    Idle                                           = 3,
    Fire                                           = 4,
    Reload                                         = 5,
    Bolt                                           = 6,
    Inspect                                        = 7,
    EWeaponState_MAX                               = 8

};


// Enum  /Script/SGWeapon.EWeaponActiveMode
enum class EWeaponActiveMode : uint8_t
{
    Default                                        = 0,
    Fast1                                          = 1,
    Fast2                                          = 2,
    FirstEquip                                     = 3,
    EWeaponActiveMode_MAX                          = 4

};


// Enum  /Script/SGWeapon.EWeaponAction
enum class EWeaponAction : uint8_t
{
    None                                           = 0,
    Deactivate                                     = 1,
    Active                                         = 2,
    ActiveFast                                     = 3,
    ActiveFirst                                    = 4,
    PrimaryAttack                                  = 5,
    SecondaryAttack                                = 6,
    Reload                                         = 7,
    PostReload                                     = 8,
    ScopeIn                                        = 9,
    ActiveScopeFx                                  = 10,
    DeactivateScopeFx                              = 11,
    ScopeInFinish                                  = 12,
    ScopeOut                                       = 13,
    Inspect                                        = 14,
    EWeaponAction_MAX                              = 15

};


// Enum  /Script/SGWeapon.EWeaponComponentOptimize
enum class EWeaponComponentOptimize : uint8_t
{
    ClientOnly                                     = 0,
    ServerOnly                                     = 1,
    Both                                           = 2,
    EWeaponComponentOptimize_MAX                   = 3

};


// Enum  /Script/SGWeapon.EWeaponPosture
enum class EWeaponPosture : uint8_t
{
    StandIdle                                      = 0,
    StandWalk                                      = 1,
    StandRun                                       = 2,
    CrouchIdle                                     = 3,
    CrouchWalk                                     = 4,
    SlingIdle                                      = 5,
    SlingWalk                                      = 6,
    SlingRun                                       = 7,
    Falling                                        = 8,
    Landing                                        = 9,
    Max                                            = 10

};


// Enum  /Script/SGWeapon.EWeaponShootMode
enum class EWeaponShootMode : uint8_t
{
    Single                                         = 0,
    Auto                                           = 1,
    Burst                                          = 2,
    AutoBurst                                      = 3,
    Bolt                                           = 4,
    EWeaponShootMode_MAX                           = 5

};


// Enum  /Script/SGWeapon.EBulletModifyReason
enum class EBulletModifyReason : uint8_t
{
    Reset                                          = 0,
    Reload                                         = 1,
    Fire                                           = 2,
    EBulletModifyReason_MAX                        = 3

};


// Enum  /Script/SGWeapon.ESGAvatarEventOccasion
enum class ESGAvatarEventOccasion : uint8_t
{
    EO_OnPutOn                                     = 0,
    EO_BeforeApply                                 = 1,
    EO_AfterApply                                  = 2,
    EO_Tick                                        = 3,
    EO_OnEquipOn                                   = 4,
    EO_OnEquipOff                                  = 5,
    EO_Inspect                                     = 6,
    EO_OnFire                                      = 7,
    EO_OnScopeIn                                   = 8,
    EO_OnScopeOut                                  = 9,
    EO_SingleFire                                  = 10,
    EO_BurstFire                                   = 11,
    EO_ViewModeChange                              = 12,
    EO_ViewModeChangeTPP                           = 13,
    E0_RecoilIndexAccumulated                      = 14,
    EO_RecoilIndexReset                            = 15,
    EO_InspectStop                                 = 16,
    EO_None                                        = 17,
    EO_Max                                         = 18,
    ESGAvatarEventOccasion_MAX                     = 19

};


// Enum  /Script/SGWeapon.EWeaponFXSlot
enum class EWeaponFXSlot : uint8_t
{
    FX_SLOT_NONE                                   = 0,
    FX_FIRE_SLOT                                   = 1,
    FX_SMOKE_SLOT                                  = 2,
    FX_SHELL_SLOT                                  = 3,
    FX_KILL_SLOT                                   = 4,
    FX_COLLIMATOR_SLOT                             = 5,
    FX_INSPECT_SLOT                                = 6,
    FX_BURST_FIRE_SLOT                             = 7,
    FX_INACCURATE_ADDITIVE_SLOT                    = 8,
    FX_SLOT_NUM                                    = 9,
    FX_MAX                                         = 10

};


// Enum  /Script/SGWeapon.EWeaponFXAttachType
enum class EWeaponFXAttachType : uint8_t
{
    None                                           = 0,
    WeaponAuto                                     = 1,
    ManualSelect                                   = 2,
    PawnCoreMesh                                   = 10,
    EWeaponFXAttachType_MAX                        = 11

};


// Enum  /Script/Engine.EInputEvent
enum class EInputEvent : uint8_t
{
    IE_Pressed                                     = 0,
    IE_Released                                    = 1,
    IE_Repeat                                      = 2,
    IE_DoubleClick                                 = 3,
    IE_Axis                                        = 4,
    IE_MAX                                         = 5

};


// Enum  /Script/Gameplay.EFlushInputType
enum class EFlushInputType : uint8_t
{
    FIT_None                                       = 0,
    FIT_InputAxis                                  = 1,
    FIT_InputVectorAxis                            = 2,
    FIT_InputAction                                = 4,
    FIT_InputKey                                   = 8,
    FIT_InputTouch                                 = 16,
    FIT_MAX                                        = 17

};


// Enum  /Script/Gameplay.ESGInteractStatuFlag
enum class ESGInteractStatuFlag : uint8_t
{
    InteractStatuFlag_Enter                        = 0,
    InteractStatuFlag_Exit                         = 1,
    InteractStatuFlag_Activate                     = 2,
    InteractStatuFlag_Start                        = 3,
    InteractStatuFlag_Cancel                       = 4,
    InteractStatuFlag_Finish                       = 5,
    InteractStatuFlag_Destory                      = 6,
    InteractStatuFlag_MAX                          = 7

};


// Enum  /Script/Gameplay.ESGEventValueTypeOfGameEvent
enum class ESGEventValueTypeOfGameEvent : uint8_t
{
    None                                           = 0,
    Float                                          = 1,
    Int                                            = 2,
    String                                         = 3,
    GameplayTags                                   = 4,
    uint8Array                                     = 5,
    ESGEventValueTypeOfGameEvent_MAX               = 6

};


// Enum  /Script/Engine.EReflectedAndRefractedRayTracedShadows
enum class EReflectedAndRefractedRayTracedShadows : uint8_t
{
    Disabled                                       = 0,
    Hard_shadows                                   = 1,
    Area_shadows                                   = 2,
    EReflectedAndRefractedRayTracedShadows_MAX     = 3

};


// Enum  /Script/Engine.ETranslucencyType
enum class ETranslucencyType : uint8_t
{
    Raster                                         = 0,
    RayTracing                                     = 1,
    ETranslucencyType_MAX                          = 2

};


// Enum  /Script/Engine.EReflectionsType
enum class EReflectionsType : uint8_t
{
    ScreenSpace                                    = 0,
    RayTracing                                     = 1,
    EReflectionsType_MAX                           = 2

};


// Enum  /Script/Engine.ERayTracingGlobalIlluminationType
enum class ERayTracingGlobalIlluminationType : uint8_t
{
    Disabled                                       = 0,
    BruteForce                                     = 1,
    FinalGather                                    = 2,
    ERayTracingGlobalIlluminationType_MAX          = 3

};


// Enum  /Script/Engine.EAutoExposureMethod
enum class EAutoExposureMethod : uint8_t
{
    AEM_Histogram                                  = 0,
    AEM_Basic                                      = 1,
    AEM_Manual                                     = 2,
    AEM_MAX                                        = 3

};


// Enum  /Script/Engine.EBloomMethod
enum class EBloomMethod : uint8_t
{
    BM_SOG                                         = 0,
    BM_FFT                                         = 1,
    BM_MAX                                         = 2

};


// Enum  /Script/Engine.ECameraProjectionMode
enum class ECameraProjectionMode : uint8_t
{
    Perspective                                    = 0,
    Orthographic                                   = 1,
    ECameraProjectionMode_MAX                      = 2

};


// Enum  /Script/Gameplay.ESGInputType
enum class ESGInputType : uint8_t
{
    MoveForward                                    = 0,
    MoveRight                                      = 1,
    MoveUp                                         = 2,
    Turn                                           = 3,
    LookUp                                         = 4,
    ESGInputType_MAX                               = 5

};


// Enum  /Script/Gameplay.ESGItemAcquireType
enum class ESGItemAcquireType : uint8_t
{
    None                                           = 0,
    Pickup                                         = 1,
    Give                                           = 2,
    Buy                                            = 3,
    Inherit                                        = 4,
    Max                                            = 5

};


// Enum  /Script/Gameplay.ESGItemMetaCategory
enum class ESGItemMetaCategory : uint8_t
{
    None                                           = 0,
    Weapon                                         = 1,
    Ability                                        = 2,
    PickUp                                         = 3,
    ESGItemMetaCategory_MAX                        = 4

};


// Enum  /Script/Gameplay.ESGEquipmentSlotID
enum class ESGEquipmentSlotID : uint8_t
{
    None                                           = 0,
    MainHand                                       = 1,
    OffHand                                        = 2,
    Melee                                          = 3,
    Bomb                                           = 4,
    AbilityQ                                       = 5,
    AbilityE                                       = 6,
    AbilityX                                       = 7,
    AbilityC                                       = 8,
    AbilityPassiveA                                = 9,
    AbilityPassiveB                                = 10,
    AbilityPassiveMutex                            = 11,
    Ability_Max                                    = 11,
    Interact                                       = 12,
    InteractB                                      = 13,
    Empty                                          = 14,
    SpareHandA                                     = 15,
    SpareHandB                                     = 16,
    MAX                                            = 32

};


// Enum  /Script/Gameplay.ESGMainSlotActiveType
enum class ESGMainSlotActiveType : uint8_t
{
    None                                           = 0,
    CallOnClient                                   = 1,
    CallOnDS                                       = 2,
    CallOnClientAndDS                              = 3,
    CallOnRPC                                      = 4,
    ESGMainSlotActiveType_MAX                      = 5

};


// Enum  /Script/Gameplay.ESGSlotActiveType
enum class ESGSlotActiveType : uint8_t
{
    None                                           = 0,
    Force                                          = 1,
    ClientOnly                                     = 2,
    Manually                                       = 3,
    ServerManually                                 = 4,
    ServerRPC                                      = 5,
    ESGSlotActiveType_MAX                          = 6

};


// Enum  /Script/Gameplay.ESGEquipmentSlotState
enum class ESGEquipmentSlotState : uint8_t
{
    None                                           = 0,
    Equipping                                      = 1,
    Equiped                                        = 2,
    Activing                                       = 3,
    Actived                                        = 4,
    Deactiving                                     = 5,
    Unequipping                                    = 6,
    TryActive                                      = 7,
    ManuallyDeactive                               = 8,
    Dormancy                                       = 9,
    ESGEquipmentSlotState_MAX                      = 10

};


// Enum  /Script/Gameplay.ESGInputBufferType
enum class ESGInputBufferType : uint8_t
{
    None                                           = 0,
    Ability                                        = 1,
    Weapon                                         = 2,
    ESGInputBufferType_MAX                         = 3

};


// Enum  /Script/Gameplay.ESGSlotLock
enum class ESGSlotLock : uint8_t
{
    None                                           = 0,
    Common                                         = 1,
    Dead                                           = 2,
    Input                                          = 4,
    PauseMain                                      = 8,
    Silent                                         = 16,
    RespawnInput                                   = 32,
    Sling                                          = 64,
    ESGSlotLock_MAX                                = 65

};


// Enum  /Script/Gameplay.ESGPredictionStatus
enum class ESGPredictionStatus : uint8_t
{
    EInvalid                                       = 0,
    EPredicting                                    = 1,
    ERejected                                      = 2,
    ETimeOut                                       = 3,
    EConfirmed                                     = 4,
    EAuthorized                                    = 5,
    ESGPredictionStatus_MAX                        = 6

};


// Enum  /Script/Gameplay.ESGPutDownItemReason
enum class ESGPutDownItemReason : uint8_t
{
    PutDown                                        = 0,
    Replace                                        = 1,
    Die                                            = 2,
    SummonDie                                      = 3,
    ESGPutDownItemReason_MAX                       = 4

};


// Enum  /Script/Gameplay.ESGProjectilePassThroughType
enum class ESGProjectilePassThroughType : uint8_t
{
    Ignore                                         = 0,
    PassThrough                                    = 1,
    Block                                          = 2,
    ESGProjectilePassThroughType_MAX               = 3

};


// Enum  /Script/Gameplay.ESGProjectileMovementMode
enum class ESGProjectileMovementMode : uint8_t
{
    BaseMode                                       = 0,
    TargetInterpolationMode                        = 1,
    JettSmoke                                      = 2,
    ESGProjectileMovementMode_MAX                  = 3

};


// Enum  /Script/Gameplay.ESGProjectileLocalControlMoveDirType
enum class ESGProjectileLocalControlMoveDirType : uint8_t
{
    FollowPlayerViewRotation                       = 0,
    ManualSetup                                    = 1,
    ESGProjectileLocalControlMoveDirType_MAX       = 2

};


// Enum  /Script/Gameplay.ESGProjectileReplicateMovementType
enum class ESGProjectileReplicateMovementType : uint8_t
{
    Base                                           = 0,
    LocalControl                                   = 1,
    ESGProjectileReplicateMovementType_MAX         = 2

};


// Enum  /Script/Engine.EDemoPlayFailure
enum class EDemoPlayFailure : uint8_t
{
    Generic                                        = 0,
    DemoNotFound                                   = 1,
    Corrupt                                        = 2,
    InvalidVersion                                 = 3,
    InitBase                                       = 4,
    GameSpecificHeader                             = 5,
    ReplayStreamerInternal                         = 6,
    LoadMap                                        = 7,
    Serialization                                  = 8,
    EDemoPlayFailure_MAX                           = 9

};


// Enum  /Script/Gameplay.ESGReplayStreamerType
enum class ESGReplayStreamerType : uint8_t
{
    ENone                                          = 0,
    EInMemory                                      = 1,
    EHttp                                          = 2,
    ESGHttp                                        = 3,
    ELocalFile                                     = 4,
    ESaveGame                                      = 5,
    ENull                                          = 6,
    ESGReplayStreamerType_MAX                      = 7

};


// Enum  /Script/UMG.ESlateAccessibleBehavior
enum class ESlateAccessibleBehavior : uint8_t
{
    NotAccessible                                  = 0,
    Auto                                           = 1,
    Summary                                        = 2,
    Custom                                         = 3,
    ToolTip                                        = 4,
    ESlateAccessibleBehavior_MAX                   = 5

};


// Enum  /Script/SlateCore.EUINavigation
enum class EUINavigation : uint8_t
{
    Left                                           = 0,
    Right                                          = 1,
    Up                                             = 2,
    Down                                           = 3,
    Next                                           = 4,
    Previous                                       = 5,
    Num                                            = 6,
    Invalid                                        = 7,
    EUINavigation_MAX                              = 8

};


// Enum  /Script/SlateCore.ECheckBoxState
enum class ECheckBoxState : uint8_t
{
    Unchecked                                      = 0,
    Checked                                        = 1,
    Undetermined                                   = 2,
    ECheckBoxState_MAX                             = 3

};


// Enum  /Script/SlateCore.EWidgetClipping
enum class EWidgetClipping : uint8_t
{
    Inherit                                        = 0,
    ClipToBounds                                   = 1,
    ClipToBoundsWithoutIntersecting                = 2,
    ClipToBoundsAlways                             = 3,
    OnDemand                                       = 4,
    EWidgetClipping_MAX                            = 5

};


// Enum  /Script/CoreUObject.EMouseCursor
enum class EMouseCursor : uint8_t
{
    None                                           = 0,
    Default                                        = 1,
    TextEditBeam                                   = 2,
    ResizeLeftRight                                = 3,
    ResizeUpDown                                   = 4,
    ResizeSouthEast                                = 5,
    ResizeSouthWest                                = 6,
    CardinalCross                                  = 7,
    Crosshairs                                     = 8,
    Hand                                           = 9,
    GrabHand                                       = 10,
    GrabHandClosed                                 = 11,
    SlashedCircle                                  = 12,
    EyeDropper                                     = 13,
    EMouseCursor_MAX                               = 14

};


// Enum  /Script/SlateCore.ESlateBrushImageType
enum class ESlateBrushImageType : uint8_t
{
    NoImage                                        = 0,
    FullColor                                      = 1,
    Linear                                         = 2,
    ESlateBrushImageType_MAX                       = 3

};


// Enum  /Script/SlateCore.ESlateBrushMirrorType
enum class ESlateBrushMirrorType : uint8_t
{
    NoMirror                                       = 0,
    Horizontal                                     = 1,
    Vertical                                       = 2,
    Both                                           = 3,
    ESlateBrushMirrorType_MAX                      = 4

};


// Enum  /Script/SlateCore.ESlateBrushTileType
enum class ESlateBrushTileType : uint8_t
{
    NoTile                                         = 0,
    Horizontal                                     = 1,
    Vertical                                       = 2,
    Both                                           = 3,
    ESlateBrushTileType_MAX                        = 4

};


// Enum  /Script/SlateCore.ESlateBrushDrawType
enum class ESlateBrushDrawType : uint8_t
{
    NoDrawType                                     = 0,
    Box                                            = 1,
    Border                                         = 2,
    Image                                          = 3,
    ESlateBrushDrawType_MAX                        = 4

};


// Enum  /Script/SlateCore.ESlateColorStylingMode
enum class ESlateColorStylingMode : uint8_t
{
    UseColor_Specified                             = 0,
    UseColor_Specified_Link                        = 1,
    UseColor_Foreground                            = 2,
    UseColor_Foreground_Subdued                    = 3,
    UseColor_MAX                                   = 4

};


// Enum  /Script/UMG.ESlateVisibility
enum class ESlateVisibility : uint8_t
{
    Visible                                        = 0,
    Collapsed                                      = 1,
    Hidden                                         = 2,
    HitTestInvisible                               = 3,
    SelfHitTestInvisible                           = 4,
    ESlateVisibility_MAX                           = 5

};


// Enum  /Script/SlateCore.EUINavigationRule
enum class EUINavigationRule : uint8_t
{
    Escape                                         = 0,
    Explicit                                       = 1,
    Wrap                                           = 2,
    Stop                                           = 3,
    Custom                                         = 4,
    CustomBoundary                                 = 5,
    Invalid                                        = 6,
    EUINavigationRule_MAX                          = 7

};


// Enum  /Script/SlateCore.EFlowDirectionPreference
enum class EFlowDirectionPreference : uint8_t
{
    Inherit                                        = 0,
    Culture                                        = 1,
    LeftToRight                                    = 2,
    RightToLeft                                    = 3,
    EFlowDirectionPreference_MAX                   = 4

};


// Enum  /Script/SlateCore.EColorVisionDeficiency
enum class EColorVisionDeficiency : uint8_t
{
    NormalVision                                   = 0,
    Deuteranope                                    = 1,
    Protanope                                      = 2,
    Tritanope                                      = 3,
    EColorVisionDeficiency_MAX                     = 4

};


// Enum  /Script/Engine.EMouseLockMode
enum class EMouseLockMode : uint8_t
{
    DoNotLock                                      = 0,
    LockOnCapture                                  = 1,
    LockAlways                                     = 2,
    LockInFullscreen                               = 3,
    EMouseLockMode_MAX                             = 4

};


// Enum  /Script/Engine.EWindowTitleBarMode
enum class EWindowTitleBarMode : uint8_t
{
    Overlay                                        = 0,
    VerticalBox                                    = 1,
    EWindowTitleBarMode_MAX                        = 2

};


// Enum  /Script/SlateCore.EButtonClickMethod
enum class EButtonClickMethod : uint8_t
{
    DownAndUp                                      = 0,
    MouseDown                                      = 1,
    MouseUp                                        = 2,
    PreciseClick                                   = 3,
    EButtonClickMethod_MAX                         = 4

};


// Enum  /Script/SlateCore.EButtonPressMethod
enum class EButtonPressMethod : uint8_t
{
    DownAndUp                                      = 0,
    ButtonPress                                    = 1,
    ButtonRelease                                  = 2,
    EButtonPressMethod_MAX                         = 3

};


// Enum  /Script/SlateCore.EButtonTouchMethod
enum class EButtonTouchMethod : uint8_t
{
    DownAndUp                                      = 0,
    Down                                           = 1,
    PreciseTap                                     = 2,
    EButtonTouchMethod_MAX                         = 3

};


// Enum  /Script/SlateCore.ESelectInfo
enum class ESelectInfo : uint8_t
{
    OnKeyPress                                     = 0,
    OnNavigation                                   = 1,
    OnMouseClick                                   = 2,
    Direct                                         = 3,
    ESelectInfo_MAX                                = 4

};


// Enum  /Script/SlateCore.ETextCommit
enum class ETextCommit : uint8_t
{
    Default                                        = 0,
    OnEnter                                        = 1,
    OnUserMovedFocus                               = 2,
    OnCleared                                      = 3,
    ETextCommit_MAX                                = 4

};


// Enum  /Script/Slate.ETextJustify
enum class ETextJustify : uint8_t
{
    Left                                           = 0,
    Center                                         = 1,
    Right                                          = 2,
    ETextJustify_MAX                               = 3

};


// Enum  /Script/Slate.ETextFlowDirection
enum class ETextFlowDirection : uint8_t
{
    Auto                                           = 0,
    LeftToRight                                    = 1,
    RightToLeft                                    = 2,
    ETextFlowDirection_MAX                         = 3

};


// Enum  /Script/SlateCore.ETextShapingMethod
enum class ETextShapingMethod : uint8_t
{
    Auto                                           = 0,
    KerningOnly                                    = 1,
    FullShaping                                    = 2,
    ETextShapingMethod_MAX                         = 3

};


// Enum  /Script/Slate.EVirtualKeyboardDismissAction
enum class EVirtualKeyboardDismissAction : uint8_t
{
    TextChangeOnDismiss                            = 0,
    TextCommitOnAccept                             = 1,
    TextCommitOnDismiss                            = 2,
    EVirtualKeyboardDismissAction_MAX              = 3

};


// Enum  /Script/Slate.EVirtualKeyboardTrigger
enum class EVirtualKeyboardTrigger : uint8_t
{
    OnFocusByPointer                               = 0,
    OnAllFocusEvents                               = 1,
    EVirtualKeyboardTrigger_MAX                    = 2

};


// Enum  /Script/UMG.EVirtualKeyboardType
enum class EVirtualKeyboardType : uint8_t
{
    Default                                        = 0,
    Number                                         = 1,
    Web                                            = 2,
    Email                                          = 3,
    Password                                       = 4,
    AlphaNumeric                                   = 5,
    EVirtualKeyboardType_MAX                       = 6

};


// Enum  /Script/SlateCore.EHorizontalAlignment
enum class EHorizontalAlignment : uint8_t
{
    HAlign_Fill                                    = 0,
    HAlign_Left                                    = 1,
    HAlign_Center                                  = 2,
    HAlign_Right                                   = 3,
    HAlign_MAX                                     = 4

};


// Enum  /Script/SlateCore.EVerticalAlignment
enum class EVerticalAlignment : uint8_t
{
    VAlign_Fill                                    = 0,
    VAlign_Top                                     = 1,
    VAlign_Center                                  = 2,
    VAlign_Bottom                                  = 3,
    VAlign_MAX                                     = 4

};


// Enum  /Script/SlateCore.EMenuPlacement
enum class EMenuPlacement : uint8_t
{
    MenuPlacement_BelowAnchor                      = 0,
    MenuPlacement_CenteredBelowAnchor              = 1,
    MenuPlacement_BelowRightAnchor                 = 2,
    MenuPlacement_ComboBox                         = 3,
    MenuPlacement_ComboBoxRight                    = 4,
    MenuPlacement_MenuRight                        = 5,
    MenuPlacement_AboveAnchor                      = 6,
    MenuPlacement_CenteredAboveAnchor              = 7,
    MenuPlacement_AboveRightAnchor                 = 8,
    MenuPlacement_MenuLeft                         = 9,
    MenuPlacement_Center                           = 10,
    MenuPlacement_RightLeftCenter                  = 11,
    MenuPlacement_MatchBottomLeft                  = 12,
    MenuPlacement_MAX                              = 13

};


// Enum  /Script/Slate.ETextVerticalJustify
enum class ETextVerticalJustify : uint8_t
{
    BaseLine                                       = 0,
    Middle                                         = 1,
    ETextVerticalJustify_MAX                       = 2

};


// Enum  /Script/Slate.ETextWrappingPolicy
enum class ETextWrappingPolicy : uint8_t
{
    DefaultWrapping                                = 0,
    AllowPerCharacterWrapping                      = 1,
    ETextWrappingPolicy_MAX                        = 2

};


// Enum  /Script/Gameplay.ESensorType
enum class ESensorType : uint8_t
{
    Off                                            = 0,
    Trigger                                        = 1,
    Value                                          = 2,
    AxisX                                          = 1,
    AxisY                                          = 2,
    AxisXY                                         = 3,
    AxisZ                                          = 4,
    AxisXZ                                         = 5,
    AxisYZ                                         = 6,
    AxisXYZ                                        = 7,
    TriggerX                                       = 9,
    TriggerY                                       = 10,
    TriggerXY                                      = 11,
    TriggerZ                                       = 12,
    TriggerXZ                                      = 13,
    TriggerYZ                                      = 14,
    TriggerXYZ                                     = 15,
    ValueX                                         = 17,
    ValueY                                         = 18,
    ValueXY                                        = 19,
    ValueZ                                         = 20,
    ValueXZ                                        = 21,
    ValueYZ                                        = 22,
    ValueXYZ                                       = 23,
    ESensorType_MAX                                = 24

};


// Enum  /Script/Gameplay.ESGInputTouchType
enum class ESGInputTouchType : uint8_t
{
    None                                           = 0,
    Right                                          = 1,
    Left                                           = 2,
    ESGInputTouchType_MAX                          = 3

};


// Enum  /Script/Gameplay.ESGRecorderState
enum class ESGRecorderState : uint8_t
{
    ENone                                          = 0,
    ERecording                                     = 1,
    ERecordStopped                                 = 2,
    EPlayback                                      = 3,
    ESGRecorderState_MAX                           = 4

};


// Enum  /Script/CodeV.EProwlerState
enum class EProwlerState : uint8_t
{
    None                                           = 0,
    MoveForward                                    = 1,
    UnderControl                                   = 2,
    TrackTrail                                     = 3,
    LockedEnemy                                    = 4,
    BittenEnemy                                    = 5,
    EProwlerState_MAX                              = 6

};


// Enum  /Script/CodeV.EPVSConnVisibilityState
enum class EPVSConnVisibilityState : uint8_t
{
    None                                           = 0,
    Pause                                          = 1,
    Visible                                        = 2,
    InVisible                                      = 3,
    EPVSConnVisibilityState_MAX                    = 4

};


// Enum  /Script/CodeV.EPVSCampVisibilityState
enum class EPVSCampVisibilityState : uint8_t
{
    None                                           = 0,
    Pause                                          = 1,
    Visible                                        = 2,
    InVisible                                      = 3,
    NewlyAdded                                     = 4,
    UnAvailable                                    = 5,
    EPVSCampVisibilityState_MAX                    = 6

};


// Enum  /Script/PhysicsCore.EPhysicalSurface
enum class EPhysicalSurface : uint8_t
{
    SurfaceType_Default                            = 0,
    SurfaceType1                                   = 1,
    SurfaceType2                                   = 2,
    SurfaceType3                                   = 3,
    SurfaceType4                                   = 4,
    SurfaceType5                                   = 5,
    SurfaceType6                                   = 6,
    SurfaceType7                                   = 7,
    SurfaceType8                                   = 8,
    SurfaceType9                                   = 9,
    SurfaceType10                                  = 10,
    SurfaceType11                                  = 11,
    SurfaceType12                                  = 12,
    SurfaceType13                                  = 13,
    SurfaceType14                                  = 14,
    SurfaceType15                                  = 15,
    SurfaceType16                                  = 16,
    SurfaceType17                                  = 17,
    SurfaceType18                                  = 18,
    SurfaceType19                                  = 19,
    SurfaceType20                                  = 20,
    SurfaceType21                                  = 21,
    SurfaceType22                                  = 22,
    SurfaceType23                                  = 23,
    SurfaceType24                                  = 24,
    SurfaceType25                                  = 25,
    SurfaceType26                                  = 26,
    SurfaceType27                                  = 27,
    SurfaceType28                                  = 28,
    SurfaceType29                                  = 29,
    SurfaceType30                                  = 30,
    SurfaceType31                                  = 31,
    SurfaceType32                                  = 32,
    SurfaceType33                                  = 33,
    SurfaceType34                                  = 34,
    SurfaceType35                                  = 35,
    SurfaceType36                                  = 36,
    SurfaceType37                                  = 37,
    SurfaceType38                                  = 38,
    SurfaceType39                                  = 39,
    SurfaceType40                                  = 40,
    SurfaceType41                                  = 41,
    SurfaceType42                                  = 42,
    SurfaceType43                                  = 43,
    SurfaceType44                                  = 44,
    SurfaceType45                                  = 45,
    SurfaceType46                                  = 46,
    SurfaceType47                                  = 47,
    SurfaceType48                                  = 48,
    SurfaceType49                                  = 49,
    SurfaceType50                                  = 50,
    SurfaceType51                                  = 51,
    SurfaceType52                                  = 52,
    SurfaceType53                                  = 53,
    SurfaceType54                                  = 54,
    SurfaceType55                                  = 55,
    SurfaceType56                                  = 56,
    SurfaceType57                                  = 57,
    SurfaceType58                                  = 58,
    SurfaceType59                                  = 59,
    SurfaceType60                                  = 60,
    SurfaceType61                                  = 61,
    SurfaceType62                                  = 62,
    SurfaceType_Max                                = 63,
    EPhysicalSurface_MAX                           = 64

};


// Enum  /Script/Engine.EBlendMode
enum class EBlendMode : uint8_t
{
    BLEND_Opaque                                   = 0,
    BLEND_Masked                                   = 1,
    BLEND_Translucent                              = 2,
    BLEND_Additive                                 = 3,
    BLEND_Modulate                                 = 4,
    BLEND_AlphaComposite                           = 5,
    BLEND_AlphaHoldout                             = 6,
    BLEND_AlphaMaskForUI                           = 7,
    BLEND_ScaledAdditiveWithModulate               = 8,
    BLEND_MAX                                      = 9

};


// Enum  /Script/CodeV.EAbilitySystemHUDKey
enum class EAbilitySystemHUDKey : uint8_t
{
    Close                                          = 0,
    ZVelAffectingAbilityBullet                     = 1,
    AbilityBulletFireVelocity                      = 2,
    AbilityGroundTrace                             = 3,
    EAbilitySystemHUDKey_MAX                       = 4

};


// Enum  /Script/SGAvatar.EPawnAvatarMatSuitType
enum class EPawnAvatarMatSuitType : uint8_t
{
    None                                           = 0,
    Trans                                          = 1,
    MVP                                            = 2,
    EPawnAvatarMatSuitType_MAX                     = 3

};


// Enum  /Script/Engine.ECollisionEnabled
enum class ECollisionEnabled : uint8_t
{
    NoCollision                                    = 0,
    QueryOnly                                      = 1,
    PhysicsOnly                                    = 2,
    QueryAndPhysics                                = 3,
    ECollisionEnabled_MAX                          = 4

};


// Enum  /Script/SGAvatar.EAvatarSyncOperation
enum class EAvatarSyncOperation : uint8_t
{
    PutOn                                          = 0,
    PutOff                                         = 1,
    MAX                                            = 2

};


// Enum  /Script/SGAvatar.EPawnAvatarSlot
enum class EPawnAvatarSlot : uint8_t
{
    ESlotNone                                      = 0,
    ESlotCore                                      = 1,
    ESlotCosmetic                                  = 2,
    ESlotAttachment1                               = 3,
    ESlotAttachment2                               = 4,
    ESlotAttachment3                               = 5,
    ESlotAttachment4                               = 6,
    ESlotMax                                       = 7,
    ESlotAttachmentMin                             = 3,
    ESlotAttachmentMax                             = 6,
    EPawnAvatarSlot_MAX                            = 8

};


// Enum  /Script/Gameplay.EAnimViewType
enum class EAnimViewType : uint8_t
{
    EFPP                                           = 0,
    ETPP                                           = 1,
    EFPPSwap                                       = 2,
    ETPPCrouch                                     = 3,
    EMax                                           = 4,
    EAnimViewType_MAX                              = 5

};


// Enum  /Script/Engine.ETimelineLengthMode
enum class ETimelineLengthMode : uint8_t
{
    TL_TimelineLength                              = 0,
    TL_LastKeyFrame                                = 1,
    TL_MAX                                         = 2

};


// Enum  /Script/CodeV.ECVAbilityTlogFormat
enum class ECVAbilityTlogFormat : uint8_t
{
    Interger                                       = 0,
    Float                                          = 1,
    String                                         = 2,
    Max                                            = 3

};


// Enum  /Script/CodeV.ECVAbilityTlogModOp
enum class ECVAbilityTlogModOp : uint8_t
{
    Additive                                       = 0,
    Multiplicitive                                 = 1,
    Subtract                                       = 2,
    Division                                       = 3,
    Override                                       = 4,
    Max                                            = 5

};


// Enum  /Script/CodeV.EMoveStatusType
enum class EMoveStatusType : uint8_t
{
    EMDT_StartPoint                                = 0,
    EMDT_Forward                                   = 1,
    EMDT_EndPoint                                  = 2,
    EMDT_Reverse                                   = 3,
    EMDT_MAX                                       = 4

};


// Enum  /Script/CodeV.EAITargetType
enum class EAITargetType : uint8_t
{
    EAITargetType_None                             = 0,
    EAITargetType_Hate                             = 1,
    EAITargetType_Skill                            = 2,
    EAITargetType_Enemy                            = 3,
    EAITargetType_ModTarget                        = 4,
    EAITargetType_ALL                              = 255,
    EAITargetType_MAX                              = 256

};


// Enum  /Script/CodeV.EAIPersonality
enum class EAIPersonality : uint8_t
{
    None                                           = 0,
    ExtremelyAggressive                            = 1,
    Normal                                         = 2,
    ExtremelyDefensive                             = 3,
    EAIPersonality_MAX                             = 4

};


// Enum  /Script/CodeV.EPackCommandType
enum class EPackCommandType : uint8_t
{
    None                                           = 0,
    OnScopeChange                                  = 1,
    OnReloadChange                                 = 2,
    OnBulletNum                                    = 3,
    OnInventoryBulletNum                           = 4,
    OnScopeFireLegal                               = 5,
    OnIdleStateChange                              = 6,
    OnFireStateChange                              = 7,
    OnReloadStateChange                            = 8,
    OnStartFireNotify                              = 9,
    EPackCommandType_MAX                           = 10

};


// Enum  /Script/CodeV.EOverrideTextureGroupMap
enum class EOverrideTextureGroupMap : uint8_t
{
    Game                                           = 0,
    Lobby                                          = 1,
    GameResult                                     = 2,
    Update                                         = 3,
    Login                                          = 4,
    EOverrideTextureGroupMap_MAX                   = 5

};


// Enum  /Script/Basic.ERegionMeshInterpolationType
enum class ERegionMeshInterpolationType : uint8_t
{
    None                                           = 0,
    Linear                                         = 1,
    Bezier                                         = 2,
    ERegionMeshInterpolationType_MAX               = 3

};


// Enum  /Script/Basic.ESoundActionType
enum class ESoundActionType : uint8_t
{
    Default                                        = 0,
    Fire                                           = 1,
    FootStep                                       = 2,
    Spike_On                                       = 3,
    Spike_Off                                      = 4,
    Sk_SKQ                                         = 5,
    Sk_RAC                                         = 6,
    Sk_SOC                                         = 7,
    Sk_YOC                                         = 8,
    Reload                                         = 9,
    Sk_GEQ                                         = 10,
    Sk_GEX                                         = 11,
    ESoundActionType_MAX                           = 12

};


// Enum  /Script/Basic.EAssistedAimingMode
enum class EAssistedAimingMode : uint8_t
{
    Disable                                        = 0,
    FireSnap                                       = 1,
    ScopeSnap                                      = 2,
    LoseSnap                                       = 4,
    SensitiveDamping                               = 8,
    FollowMode                                     = 16,
    MagneticSnap                                   = 64,
    StepFollow                                     = 128,
    SnapMode                                       = 3,
    AllMode                                        = 219,
    EAssistedAimingMode_MAX                        = 220

};


// Enum  /Script/Basic.EAssistedScaleConfigType
enum class EAssistedScaleConfigType : uint8_t
{
    None                                           = 0,
    ScaleConfig1                                   = 1,
    ScaleConfig2                                   = 2,
    ScaleConfig3                                   = 3,
    ScaleConfig4                                   = 4,
    ScaleConfig5                                   = 5,
    ScaleConfig6                                   = 6,
    ScaleConfig7                                   = 7,
    ScaleConfig8                                   = 8,
    ScaleConfig9                                   = 9,
    ScaleConfig10                                  = 10,
    EAssistedScaleConfigType_MAX                   = 11

};


// Enum  /Script/Basic.ESGAssistedClazzType
enum class ESGAssistedClazzType : uint8_t
{
    None                                           = 0,
    ClazzCfg1                                      = 1,
    ClazzCfg2                                      = 2,
    ClazzCfg3                                      = 3,
    ClazzCfg4                                      = 4,
    ClazzCfg5                                      = 5,
    ClazzCfg6                                      = 6,
    ClazzCfg7                                      = 7,
    ClazzCfg8                                      = 8,
    ClazzCfg9                                      = 9,
    ESGAssistedClazzType_MAX                       = 10

};


// Enum  /Script/Basic.ESGAssistedBoneEnum
enum class ESGAssistedBoneEnum : uint8_t
{
    None                                           = 0,
    BoneEnum1                                      = 1,
    BoneEnum2                                      = 2,
    BoneEnum3                                      = 3,
    BoneEnum4                                      = 4,
    BoneEnum5                                      = 5,
    BoneEnum6                                      = 6,
    BoneEnum7                                      = 7,
    BoneEnum8                                      = 8,
    BoneEnum9                                      = 9,
    ESGAssistedBoneEnum_MAX                        = 10

};


// Enum  /Script/Basic.ESGAssistedBoneType
enum class ESGAssistedBoneType : uint8_t
{
    Location                                       = 0,
    BoneCircle                                     = 1,
    BoneRect                                       = 2,
    ESGAssistedBoneType_MAX                        = 3

};


// Enum  /Script/CodeV.ECVAstMode
enum class ECVAstMode : uint8_t
{
    None                                           = 0,
    AtkSnap                                        = 1,
    MagSnap                                        = 2,
    FlwSnap                                        = 4,
    StvDump                                        = 8,
    RlsSnap                                        = 16,
    All                                            = 31,
    ECVAstMode_MAX                                 = 32

};


// Enum  /Script/CodeV.EGameBBKeyFrom
enum class EGameBBKeyFrom : uint8_t
{
    None                                           = 0,
    ReplicatedProps                                = 1,
    NoReplicatedProps                              = 2,
    EGameBBKeyFrom_MAX                             = 3

};


// Enum  /Script/CodeV.EGameBBKeyType
enum class EGameBBKeyType : uint8_t
{
    None                                           = 0,
    Bool                                           = 1,
    Int                                            = 2,
    Float                                          = 3,
    String                                         = 4,
    EGameBBKeyType_MAX                             = 5

};


// Enum  /Script/CodeV.EBBKeyType
enum class EBBKeyType : uint8_t
{
    None                                           = 0,
    Bool                                           = 1,
    Int                                            = 2,
    Float                                          = 3,
    Enum                                           = 4,
    String                                         = 5,
    Name                                           = 6,
    Vector                                         = 7,
    Rotator                                        = 8,
    Object                                         = 9,
    EBBKeyType_MAX                                 = 10

};


// Enum  /Script/CodeV.EAIStateRelation
enum class EAIStateRelation : uint8_t
{
    EIgnore                                        = 0,
    ESet                                           = 1,
    EClear                                         = 2,
    EBan                                           = 3,
    EAIStateRelation_MAX                           = 4

};


// Enum  /Script/CodeV.EAIState
enum class EAIState : uint8_t
{
    None                                           = 0,
    Patrol                                         = 1,
    Alert                                          = 2,
    Search                                         = 3,
    Fight                                          = 4,
    PlantSpike                                     = 5,
    DefuseSpike                                    = 6,
    Max                                            = 6

};


// Enum  /Script/CodeV.ETextKeyOprType
enum class ETextKeyOprType : uint8_t
{
    Equal                                          = 0,
    NotEqual                                       = 1,
    Contain                                        = 2,
    NotContain                                     = 3,
    ETextKeyOprType_MAX                            = 4

};


// Enum  /Script/CodeV.EArithmeticOprType
enum class EArithmeticOprType : uint8_t
{
    Equal                                          = 0,
    NotEqual                                       = 1,
    Less                                           = 2,
    LessOrEqual                                    = 3,
    Greater                                        = 4,
    GreaterOrEqual                                 = 5,
    EArithmeticOprType_MAX                         = 6

};


// Enum  /Script/CodeV.EAITargetPriorityLevel
enum class EAITargetPriorityLevel : uint8_t
{
    Normal                                         = 0,
    Damage                                         = 1,
    DeadZone                                       = 2,
    Commander                                      = 100,
    EAITargetPriorityLevel_MAX                     = 101

};


// Enum  /Script/CodeV.EAIPerceptBit
enum class EAIPerceptBit : uint8_t
{
    EPerceptBit_None                               = 0,
    EPerceptBit_Hear                               = 1,
    EPerceptBit_Sight                              = 2,
    EPerceptBit_Damage                             = 4,
    EPerceptBit_Team                               = 8,
    EPerceptBit_DropItem                           = 16,
    EPerceptBit_Interest                           = 32,
    EPerceptBit_MAX                                = 33

};


// Enum  /Script/CodeV.EVolumnType
enum class EVolumnType : uint8_t
{
    None                                           = 0,
    Attack                                         = 1,
    Defense                                        = 2,
    EVolumnType_MAX                                = 3

};


// Enum  /Script/CodeV.EAIHotSpotType
enum class EAIHotSpotType : uint8_t
{
    None                                           = 0,
    Point                                          = 1,
    Volume                                         = 2,
    EAIHotSpotType_MAX                             = 3

};


// Enum  /Script/CodeV.EAIOrderType
enum class EAIOrderType : uint8_t
{
    Invalid                                        = 0,
    MoveTo                                         = 1,
    MoveAttack                                     = 2,
    AttackMove                                     = 3,
    MoveToTarget                                   = 4,
    AttackTarget                                   = 5,
    GuardTarget                                    = 6,
    GuardArea                                      = 7,
    CastSkillNoneTarget                            = 8,
    CastSkillOnTarget                              = 9,
    CastSkillOnLocation                            = 10,
    IdleShow                                       = 11,
    RotateTo                                       = 12,
    Stop                                           = 99,
    EAIOrderType_MAX                               = 100

};


// Enum  /Script/CodeV.EAISpawnType
enum class EAISpawnType : uint8_t
{
    Agent                                          = 0,
    Monster                                        = 1,
    EAISpawnType_MAX                               = 2

};


// Enum  /Script/CodeV.EAIMatchType
enum class EAIMatchType : uint8_t
{
    None                                           = 0,
    MLTrain                                        = 1,
    AITest                                         = 2,
    EAIMatchType_MAX                               = 3

};


// Enum  /Script/CodeV.EShootBodyPart
enum class EShootBodyPart : uint8_t
{
    Head                                           = 0,
    Chest                                          = 1,
    Shoulder                                       = 2,
    Elbow                                          = 3,
    Hip                                            = 4,
    Leg                                            = 5,
    EShootBodyPart_MAX                             = 6

};


// Enum  /Script/CodeV.EAIMovePose
enum class EAIMovePose : uint8_t
{
    Stand                                          = 0,
    Crouch                                         = 1,
    SlowWalk                                       = 2,
    KeepCurrentPose                                = 3,
    EAIMovePose_MAX                                = 4

};


// Enum  /Script/CodeV.ETestPathType
enum class ETestPathType : uint8_t
{
    NavmeshRaycast2D                               = 0,
    HierarchicalQuery                              = 1,
    RegularPathFinding                             = 2,
    ETestPathType_MAX                              = 3

};


// Enum  /Script/CodeV.EWarpingVectorMode
enum class EWarpingVectorMode : uint8_t
{
    ComponentSpaceVector                           = 0,
    ActorSpaceVector                               = 1,
    WorldSpaceVector                               = 2,
    IKFootRootLocalSpaceVector                     = 3,
    EWarpingVectorMode_MAX                         = 4

};


// Enum  /Script/CodeV.EWarpingEvaluationMode
enum class EWarpingEvaluationMode : uint8_t
{
    Manual                                         = 0,
    Graph                                          = 1,
    EWarpingEvaluationMode_MAX                     = 2

};


// Enum  /Script/CodeV.EAttributeSetValueOperator
enum class EAttributeSetValueOperator : uint8_t
{
    Equal                                          = 0,
    LessThan                                       = 1,
    GreaterThan                                    = 2,
    EAttributeSetValueOperator_MAX                 = 3

};


// Enum  /Script/CodeV.EPerceptionLimitMode
enum class EPerceptionLimitMode : uint8_t
{
    Sight                                          = 0,
    Hearing                                        = 1,
    EPerceptionLimitMode_MAX                       = 2

};


// Enum  /Script/CodeV.EDistanceValueOperator
enum class EDistanceValueOperator : uint8_t
{
    Equal                                          = 0,
    LessThan                                       = 1,
    GreaterThan                                    = 2,
    EDistanceValueOperator_MAX                     = 3

};


// Enum  /Script/CodeV.EAISeeThroughAbilityTargetType
enum class EAISeeThroughAbilityTargetType : uint8_t
{
    None                                           = 0,
    BS_Smoke                                       = 1,
    JE_Smoke                                       = 2,
    EAISeeThroughAbilityTargetType_MAX             = 3

};


// Enum  /Script/CodeV.EAISetRotateTaskCase
enum class EAISetRotateTaskCase : uint8_t
{
    Vertical                                       = 0,
    Horizontal                                     = 1,
    EAISetRotateTaskCase_MAX                       = 2

};


// Enum  /Script/CodeV.EAIInputMoveDirect
enum class EAIInputMoveDirect : uint8_t
{
    ForWard                                        = 0,
    Back                                           = 1,
    Left                                           = 2,
    Right                                          = 3,
    EAIInputMoveDirect_MAX                         = 4

};


// Enum  /Script/CodeV.EAISetFocusTaskCase
enum class EAISetFocusTaskCase : uint8_t
{
    Vertical                                       = 0,
    Horizontal                                     = 1,
    Square                                         = 2,
    ZDirection                                     = 3,
    NDirection                                     = 4,
    EAISetFocusTaskCase_MAX                        = 5

};


// Enum  /Script/CodeV.ECVArenaState
enum class ECVArenaState : uint8_t
{
    Empty                                          = 0,
    PrepareToFight                                 = 1,
    Fighting                                       = 2,
    FightEnd                                       = 3,
    ECVArenaState_MAX                              = 4

};


// Enum  /Script/CodeV.ECVAbilityActor_BlazeWall_State
enum class ECVAbilityActor_BlazeWall_State : uint8_t
{
    Standby                                        = 0,
    Cast                                           = 1,
    Lift                                           = 2,
    ECVAbilityActor_BlazeWall_MAX                  = 3

};


// Enum  /Script/CodeV.ECVAbilityActor_ToxicScreen_State
enum class ECVAbilityActor_ToxicScreen_State : uint8_t
{
    Invalid                                        = 0,
    Deploying                                      = 1,
    WaittingStandby                                = 2,
    Standby                                        = 3,
    Activing                                       = 4,
    Active                                         = 5,
    Cooldown                                       = 6,
    ECVAbilityActor_ToxicScreen_MAX                = 7

};


// Enum  /Script/CodeV.UCVStateActionType
enum class UCVStateActionType : uint8_t
{
    ClientOnly                                     = 1,
    DSOnly                                         = 2,
    ClientAndDS                                    = 3,
    UCVStateActionType_MAX                         = 4

};


// Enum  /Script/CodeV.ECVActionRepeatType
enum class ECVActionRepeatType : uint8_t
{
    Loop                                           = 0,
    Array                                          = 1,
    ECVActionRepeatType_MAX                        = 2

};


// Enum  /Script/CodeV.ECVQualityLevel
enum class ECVQualityLevel : uint8_t
{
    None                                           = 0,
    QL_Low                                         = 1,
    QL_Medium                                      = 2,
    QL_High                                        = 4,
    QL_Epic                                        = 8,
    ECVQualityLevel_MAX                            = 9

};


// Enum  /Script/CodeV.ECVDecalShowCampType
enum class ECVDecalShowCampType : uint8_t
{
    All                                            = 0,
    Teammate                                       = 1,
    Enemy                                          = 2,
    ECVDecalShowCampType_MAX                       = 3

};


// Enum  /Script/CodeV.ECVDecalEndAnimType
enum class ECVDecalEndAnimType : uint8_t
{
    Delay                                          = 0,
    OnEnterState                                   = 1,
    ECVDecalEndAnimType_MAX                        = 2

};


// Enum  /Script/CodeV.EAbilityAISenseSightType
enum class EAbilityAISenseSightType : uint8_t
{
    Normal                                         = 0,
    SightAttribute                                 = 1,
    EAbilityAISenseSightType_MAX                   = 2

};


// Enum  /Script/CodeV.ETimedCueType
enum class ETimedCueType : uint8_t
{
    None                                           = 0,
    Timed                                          = 1,
    Execute                                        = 2,
    Add                                            = 3,
    Remove                                         = 4,
    ETimedCueType_MAX                              = 5

};


// Enum  /Script/CodeV.EAbilitySlotAssetType
enum class EAbilitySlotAssetType : uint8_t
{
    None                                           = 0,
    SkeletalMesh                                   = 1,
    StaticMesh                                     = 2,
    Niagara                                        = 3,
    Decal                                          = 4,
    EAbilitySlotAssetType_MAX                      = 5

};


// Enum  /Script/CodeV.EAbilityAvatarSlot
enum class EAbilityAvatarSlot : uint8_t
{
    None                                           = 0,
    Master                                         = 1,
    Attach1                                        = 2,
    Attach2                                        = 3,
    Attach3                                        = 4,
    Attach4                                        = 5,
    Attach5                                        = 6,
    Attach6                                        = 7,
    Attach7                                        = 8,
    Attach8                                        = 9,
    Attach9                                        = 10,
    Attach10                                       = 11,
    Attach11                                       = 12,
    Attach12                                       = 13,
    Attach13                                       = 14,
    Attach14                                       = 15,
    Attach15                                       = 16,
    Attach16                                       = 17,
    Max                                            = 18

};


// Enum  /Script/CodeV.ECVAvatarLuaStr
enum class ECVAvatarLuaStr : uint8_t
{
    MutexGroup_DeathFinisher                       = 0,
    MutexGroup_TeammateReveal                      = 1,
    MutexGroup_ReplayReveal                        = 2,
    MutexGroup_SpawnDissolve                       = 3,
    MutexGroup_DeadDissolve                        = 4,
    MutexGroup_SuicideDissolve                     = 5,
    MutexGroup_PH_X_Rebirth                        = 6,
    MutexGroup_RE_E                                = 7,
    MutexGroup_OM_C                                = 8,
    MutexGroup_IS_X                                = 9,
    MutexGroup_EnemyOutlineStrong                  = 10,
    MutexGroup_GC_Invincible                       = 11,
    MutexGroup_GC_GhostInvisibleEnter              = 12,
    MutexGroup_GC_GhostInvisibleExit               = 13,
    MatSlot_SlotRevealed                           = 14,
    MatSlot_SlotOutline                            = 15,
    MatSlot_SlotAny                                = 16,
    ColorParam_NormalColor                         = 17,
    ColorParam_OutlineColor                        = 18,
    ColorParam_View_Color_Green                    = 19,
    ColorParam_View_Color_Red                      = 20,
    ECVAvatarLuaStr_MAX                            = 21

};


// Enum  /Script/CodeV.EAbilityMonsterStateType
enum class EAbilityMonsterStateType : uint8_t
{
    None                                           = 0,
    BeginPlayState                                 = 1,
    Release                                        = 2,
    ActiveStartState                               = 3,
    ActivatingState                                = 4,
    ActiveEndState                                 = 5,
    DestructionState                               = 6,
    EndPlayState                                   = 7,
    Fire                                           = 8,
    EAbilityMonsterStateType_MAX                   = 9

};


// Enum  /Script/CodeV.EAbilityWallAdjustScentType
enum class EAbilityWallAdjustScentType : uint8_t
{
    None                                           = 0,
    StickToGround                                  = 1,
    Smooth                                         = 2,
    EAbilityWallAdjustScentType_MAX                = 3

};


// Enum  /Script/CodeV.EAbilityWallCollisionType
enum class EAbilityWallCollisionType : uint8_t
{
    Origin                                         = 0,
    SynBox                                         = 1,
    AsynBox                                        = 2,
    EAbilityWallCollisionType_MAX                  = 3

};


// Enum  /Script/CodeV.EBulletActorAttachTypeWhenStop
enum class EBulletActorAttachTypeWhenStop : uint8_t
{
    KeepIncidentAngle                              = 0,
    VerticalObjectSurface                          = 1,
    EBulletActorAttachTypeWhenStop_MAX             = 2

};


// Enum  /Script/CodeV.EAbilityShowTipsType
enum class EAbilityShowTipsType : uint8_t
{
    All                                            = 0,
    SelfOnly                                       = 1,
    SelfAndTeammate                                = 2,
    EnemyOnly                                      = 3,
    EAbilityShowTipsType_MAX                       = 4

};


// Enum  /Script/CodeV.EAbilityActorBaseEffectReceiveDecal
enum class EAbilityActorBaseEffectReceiveDecal : uint8_t
{
    Default                                        = 0,
    NotReceiveDecal                                = 1,
    ReceiveDecal                                   = 2,
    EAbilityActorBaseEffectReceiveDecal_MAX        = 3

};


// Enum  /Script/CodeV.EAbilityActorCollisionActor
enum class EAbilityActorCollisionActor : uint8_t
{
    ClientAndServer                                = 0,
    Client                                         = 1,
    Server                                         = 2,
    EAbilityActorCollisionActor_MAX                = 3

};


// Enum  /Script/CodeV.EAbilityActorCollisionAction
enum class EAbilityActorCollisionAction : uint8_t
{
    Keep                                           = 0,
    DisableCollision                               = 1,
    QueryOnly                                      = 2,
    PhysicsOnly                                    = 3,
    EnableCollision                                = 4,
    EAbilityActorCollisionAction_MAX               = 5

};


// Enum  /Script/CodeV.ECVAbilityDeployControlScaleDirction
enum class ECVAbilityDeployControlScaleDirction : uint8_t
{
    Vertical                                       = 0,
    Horizontal                                     = 1,
    ECVAbilityDeployControlScaleDirction_MAX       = 2

};


// Enum  /Script/CodeV.ECVAbilityDeployBoundsShape
enum class ECVAbilityDeployBoundsShape : uint8_t
{
    Sphere                                         = 0,
    Box                                            = 1,
    FillBox                                        = 2,
    ECVAbilityDeployBoundsShape_MAX                = 3

};


// Enum  /Script/CodeV.ECVAbilityDeployAssistType
enum class ECVAbilityDeployAssistType : uint8_t
{
    Point                                          = 0,
    Range                                          = 1,
    RotationScale                                  = 2,
    ECVAbilityDeployAssistType_MAX                 = 3

};


// Enum  /Script/CodeV.ECVAbilityDeployCamp
enum class ECVAbilityDeployCamp : uint8_t
{
    None                                           = 0,
    Attack                                         = 1,
    Defense                                        = 2,
    ECVAbilityDeployCamp_MAX                       = 3

};


// Enum  /Script/CodeV.ECVAbilityDeployChannel
enum class ECVAbilityDeployChannel : uint8_t
{
    None                                           = 0,
    Channel1                                       = 1,
    Channel2                                       = 2,
    Channel3                                       = 4,
    Channel4                                       = 8,
    Channel5                                       = 16,
    Channel6                                       = 32,
    Channel7                                       = 64,
    Channel8                                       = 128,
    ECVAbilityDeployChannel_MAX                    = 129

};


// Enum  /Script/CodeV.ECameraLensScaleMode
enum class ECameraLensScaleMode : uint8_t
{
    UniformScaleToFitX                             = 0,
    UniformScaleToFitY                             = 1,
    NonUniformScaleToFitXY                         = 2,
    ECameraLensScaleMode_MAX                       = 3

};


// Enum  /Script/CodeV.ECVTeleportVerifyType
enum class ECVTeleportVerifyType : uint8_t
{
    None                                           = 0,
    LineTracePawn                                  = 1,
    SimpleNavMesh                                  = 2,
    ECVTeleportVerifyType_MAX                      = 3

};


// Enum  /Script/CodeV.ETimelineNotifyCondtionCalcType
enum class ETimelineNotifyCondtionCalcType : uint8_t
{
    EGreaterThan                                   = 0,
    EGreaterThanOrEqualTo                          = 1,
    ELessThan                                      = 2,
    ELessThanOrEqualTo                             = 3,
    ETimelineNotifyCondtionCalcType_MAX            = 4

};


// Enum  /Script/CodeV.EAbilityNotifyFireType
enum class EAbilityNotifyFireType : uint8_t
{
    FireA                                          = 0,
    FireB                                          = 1,
    EAbilityNotifyFireType_MAX                     = 2

};


// Enum  /Script/CodeV.ESGAbilityTargetActor_BackHit_State
enum class ESGAbilityTargetActor_BackHit_State : uint8_t
{
    Invalid                                        = 0,
    ValidBackHit                                   = 1,
    HitTooFarFromTraceStart                        = 2,
    WallWidthExceed                                = 3,
    ESGAbilityTargetActor_BackHit_MAX              = 4

};


// Enum  /Script/CodeV.EOmenEReticleAction
enum class EOmenEReticleAction : uint8_t
{
    Action_StartTargeting                          = 0,
    Action_SwitchSpace                             = 1,
    Action_ConfirmFire                             = 2,
    Action_CancelTargeting                         = 3,
    Action_MAX                                     = 4

};


// Enum  /Script/CodeV.ECVModeOfSelectPointByEyeDistance
enum class ECVModeOfSelectPointByEyeDistance : uint8_t
{
    Default                                        = 0,
    TraceHitPoint                                  = 1,
    ECVModeOfSelectPointByEyeDistance_MAX          = 2

};


// Enum  /Script/CodeV.ECVAbilityTaskType_LineTraceGlass
enum class ECVAbilityTaskType_LineTraceGlass : uint8_t
{
    None                                           = 0,
    IgnoreGlassNotAddResults                       = 1,
    IgnoreGlassAddResults                          = 2,
    ECVAbilityTaskType_MAX                         = 3

};


// Enum  /Script/CodeV.ECVTraceFlag
enum class ECVTraceFlag : uint8_t
{
    Flag_None                                      = 1,
    Flag_Location                                  = 2,
    Flag_Rotation                                  = 4,
    Flag_ImpactPoint                               = 8,
    Flag_ImpactNormal                              = 16,
    Flag_Actor                                     = 32,
    Flag_bBlockingHit                              = 64,
    Flag_MAX                                       = 65

};


// Enum  /Script/CodeV.ECVAbilityWallDrawDebugNetMode
enum class ECVAbilityWallDrawDebugNetMode : uint8_t
{
    All                                            = 0,
    ServerOnly                                     = 1,
    ClientOnly                                     = 2,
    ECVAbilityWallDrawDebugNetMode_MAX             = 3

};


// Enum  /Script/CodeV.ECVAbilityWallState
enum class ECVAbilityWallState : uint8_t
{
    Deactive                                       = 0,
    Active                                         = 1,
    FadeIn                                         = 2,
    FadeOut                                        = 3,
    ECVAbilityWallState_MAX                        = 4

};


// Enum  /Script/CodeV.EAIAbilityCastInputMode
enum class EAIAbilityCastInputMode : uint8_t
{
    None                                           = 0,
    SlotInput                                      = 1,
    MapSelect                                      = 2,
    EAIAbilityCastInputMode_MAX                    = 3

};


// Enum  /Script/CodeV.ESGAbilityType
enum class ESGAbilityType : uint8_t
{
    Throw                                          = 0,
    Instant                                        = 1,
    View                                           = 2,
    Buff                                           = 3,
    ESGAbilityType_MAX                             = 4

};


// Enum  /Script/CodeV.EAIEconemyPreference
enum class EAIEconemyPreference : uint8_t
{
    None                                           = 0,
    SubWeapon                                      = 1,
    Weapon                                         = 2,
    Shield                                         = 3,
    Skill                                          = 4,
    Melee                                          = 5,
    ECO                                            = 6,
    OnlyWeapon                                     = 7,
    EAIEconemyPreference_MAX                       = 8

};


// Enum  /Script/CodeV.EAIWeaponPreference
enum class EAIWeaponPreference : uint8_t
{
    None                                           = 0,
    SideArm                                        = 1,
    SMG                                            = 2,
    ShotGun                                        = 3,
    Rifle                                          = 4,
    Sniper                                         = 5,
    MG                                             = 6,
    EAIWeaponPreference_MAX                        = 7

};


// Enum  /Script/CodeV.ETrainPos
enum class ETrainPos : uint8_t
{
    S2S                                            = 0,
    S2C                                            = 1,
    C2S                                            = 2,
    C2C                                            = 3,
    ETrainPos_MAX                                  = 4

};


// Enum  /Script/CodeV.ETrainMode
enum class ETrainMode : uint8_t
{
    None                                           = 0,
    InPlane                                        = 1,
    ShootInAir                                     = 2,
    TargetInAir                                    = 3,
    ETrainMode_MAX                                 = 4

};


// Enum  /Script/CodeV.ELobbyWeaponShowAction
enum class ELobbyWeaponShowAction : uint8_t
{
    Reload                                         = 0,
    ReactiveWeapon                                 = 1,
    KillEffect                                     = 2,
    Idle                                           = 3,
    ResetWeaponAndActive                           = 4,
    BubbleDown                                     = 5,
    Max                                            = 6

};


// Enum  /Script/CodeV.ELobbyWeaponShowState
enum class ELobbyWeaponShowState : uint8_t
{
    PrimaryAttack                                  = 0,
    SecondaryAttack                                = 1,
    ScopeIn                                        = 2,
    Inspect                                        = 3,
    ActiveTarget                                   = 4,
    ActiveBot                                      = 5,
    BotDead                                        = 6,
    Finisher                                       = 7,
    RotateCharacter                                = 8,
    EnablePickup                                   = 9,
    CharacterMontage                               = 10,
    AddDeocration                                  = 11,
    AvatarEvent                                    = 12,
    Max                                            = 13

};


// Enum  /Script/CodeV.EMaterialParamType
enum class EMaterialParamType : uint8_t
{
    FloatParam                                     = 0,
    VectorParam                                    = 1,
    EMaterialParamType_MAX                         = 2

};


// Enum  /Script/CodeV.ECVForceType
enum class ECVForceType : uint8_t
{
    None                                           = 0,
    Popup                                          = 1,
    ECVForceType_MAX                               = 2

};


// Enum  /Script/CodeV.ECVForceParmType
enum class ECVForceParmType : uint8_t
{
    None                                           = 0,
    Gravity                                        = 1,
    GroundFriction                                 = 2,
    FallingLateralFriction                         = 3,
    BrakingFrictionFactor                          = 4,
    MaxAcceleration                                = 5,
    FlyingMaxAcceleration                          = 6,
    ECVForceParmType_MAX                           = 7

};


// Enum  /Script/CodeV.ECVAstChannelEnum
enum class ECVAstChannelEnum : uint8_t
{
    None                                           = 0,
    ChannelEnum1                                   = 1,
    ChannelEnum2                                   = 2,
    ChannelEnum3                                   = 3,
    ChannelEnum4                                   = 4,
    ChannelEnum5                                   = 5,
    ChannelEnum6                                   = 6,
    ChannelEnum7                                   = 7,
    ChannelEnum8                                   = 8,
    ChannelEnum9                                   = 9,
    ECVAstChannelEnum_MAX                          = 10

};


// Enum  /Script/CodeV.ECVAstBoneType
enum class ECVAstBoneType : uint8_t
{
    Location                                       = 0,
    BoneCircle                                     = 1,
    BoneRect                                       = 2,
    ECVAstBoneType_MAX                             = 3

};


// Enum  /Script/CodeV.ECVAstBoneEnum
enum class ECVAstBoneEnum : uint8_t
{
    None                                           = 0,
    BoneEnum1                                      = 1,
    BoneEnum2                                      = 2,
    BoneEnum3                                      = 3,
    BoneEnum4                                      = 4,
    BoneEnum5                                      = 5,
    BoneEnum6                                      = 6,
    BoneEnum7                                      = 7,
    BoneEnum8                                      = 8,
    BoneEnum9                                      = 9,
    ECVAstBoneEnum_MAX                             = 10

};


// Enum  /Script/CodeV.ECVAstClazzEnum
enum class ECVAstClazzEnum : uint8_t
{
    None                                           = 0,
    ClazzEnum1                                     = 1,
    ClazzEnum2                                     = 2,
    ClazzEnum3                                     = 3,
    ClazzEnum4                                     = 4,
    ClazzEnum5                                     = 5,
    ClazzEnum6                                     = 6,
    ClazzEnum7                                     = 7,
    ClazzEnum8                                     = 8,
    ClazzEnum9                                     = 9,
    ECVAstClazzEnum_MAX                            = 10

};


// Enum  /Script/CodeV.ECVFinisherParamType
enum class ECVFinisherParamType : uint8_t
{
    ENone                                          = 0,
    ENumbericMin                                   = 1,
    EBool                                          = 2,
    EInt                                           = 3,
    EFloat                                         = 4,
    EVector2                                       = 5,
    EVector3                                       = 6,
    EVector4                                       = 7,
    ELinearColor                                   = 8,
    ERotator                                       = 9,
    ENumbericMax                                   = 10,
    ECurveMin                                      = 11,
    EBoolCurve                                     = 12,
    EIntCurve                                      = 13,
    EFloatCurve                                    = 14,
    EVector2Curve                                  = 15,
    EVector3Curve                                  = 16,
    EVector4Curve                                  = 17,
    ELinearColorCurve                              = 18,
    ERotatorCurve                                  = 19,
    ECurveMax                                      = 20,
    ECVFinisherParamType_MAX                       = 21

};


// Enum  /Script/CodeV.EMonsterMoveState
enum class EMonsterMoveState : uint8_t
{
    ENone                                          = 0,
    ENavMove                                       = 1,
    EMax                                           = 2,
    EMonsterMoveState_MAX                          = 3

};


// Enum  /Script/CodeV.EBulletFireType
enum class EBulletFireType : uint8_t
{
    FireA                                          = 0,
    FireB                                          = 1,
    EBulletFireType_MAX                            = 2

};


// Enum  /Script/CodeV.ECVChangeModeResult
enum class ECVChangeModeResult : uint8_t
{
    ECVResult_Failed                               = 0,
    ECVResult_Succeed                              = 1,
    ECVResult_Waiting                              = 2,
    ECVResult_MAX                                  = 3

};


// Enum  /Script/CodeV.ECVSlingStage
enum class ECVSlingStage : uint8_t
{
    ECVSlingStage_None                             = 0,
    ECVSlingStage_Enter                            = 1,
    ECVSlingStage_Sling                            = 2,
    ECVSlingStage_MAX                              = 3

};


// Enum  /Script/CodeV.ECVCustomMode
enum class ECVCustomMode : uint8_t
{
    ECVCustomMode_None                             = 0,
    ECVCustomMode_Sling                            = 1,
    ECVCustomMode_Ghost                            = 2,
    ECVCustomMode_Max                              = 3

};


// Enum  /Script/CodeV.ECharacterTPPUpperBodyType
enum class ECharacterTPPUpperBodyType : uint8_t
{
    EStand                                         = 0,
    ECrouch                                        = 1,
    ESling                                         = 2,
    EAimStand                                      = 3,
    EAimCrouch                                     = 4,
    EAimSling                                      = 5,
    ESkateStand                                    = 6,
    ESkateCrouch                                   = 7,
    ECharacterTPPUpperBodyType_MAX                 = 8

};


// Enum  /Script/CodeV.ECharacterTPPMoveType
enum class ECharacterTPPMoveType : uint8_t
{
    EStand                                         = 0,
    ECrouch                                        = 1,
    ESling                                         = 2,
    ESkateStand                                    = 3,
    ESkateCrouch                                   = 4,
    ESlide                                         = 5,
    ECharacterTPPMoveType_MAX                      = 6

};


// Enum  /Script/CodeV.ECVEmoteStopReason
enum class ECVEmoteStopReason : uint8_t
{
    ENone                                          = 0,
    EStopped                                       = 1,
    EInterrupted                                   = 2,
    ECVEmoteStopReason_MAX                         = 3

};


// Enum  /Script/CodeV.ECVEmoteState
enum class ECVEmoteState : uint8_t
{
    ENone                                          = 0,
    EPlaying                                       = 1,
    EBlendingOut                                   = 2,
    ECVEmoteState_MAX                              = 3

};


// Enum  /Script/CodeV.ECVFirePropagationComponent_DrawDebug
enum class ECVFirePropagationComponent_DrawDebug : uint8_t
{
    None                                           = 0,
    Trace                                          = 1,
    Cell                                           = 2,
    Decal                                          = 4,
    Collision                                      = 8,
    OriginCell                                     = 16,
    CellTrace                                      = 32,
    ECVFirePropagationComponent_MAX                = 33

};


// Enum  /Script/CodeV.ESGPlayerStartMode
enum class ESGPlayerStartMode : uint8_t
{
    None                                           = 0,
    Duel                                           = 1,
    FFA                                            = 2,
    TFFA                                           = 3,
    Training                                       = 4,
    WeaponTests                                    = 5,
    ESGPlayerStartMode_MAX                         = 6

};


// Enum  /Script/CodeV.EAbilityUIProgressBarFuncType
enum class EAbilityUIProgressBarFuncType : uint8_t
{
    HideProgressBar                                = 0,
    ShowStaticProgressBar                          = 1,
    ShowAndMoveProgressBar                         = 2,
    SetProgressBarText                             = 3,
    EAbilityUIProgressBarFuncType_MAX              = 4

};


// Enum  /Script/CodeV.EAbilityUICallTiming
enum class EAbilityUICallTiming : uint8_t
{
    DuringAbility                                  = 0,
    AfterAbility                                   = 1,
    EAbilityUICallTiming_MAX                       = 2

};


// Enum  /Script/CodeV.EAbilityAssetViewModeType
enum class EAbilityAssetViewModeType : uint8_t
{
    None                                           = 0,
    All                                            = 1,
    FPP                                            = 2,
    TPP                                            = 4,
    TPP_Enemy                                      = 8,
    TPP_Teammate                                   = 16,
    EAbilityAssetViewModeType_MAX                  = 17

};


// Enum  /Script/CodeV.EResolveAssetTarget
enum class EResolveAssetTarget : uint8_t
{
    FPPAsset                                       = 0,
    TPPAsset                                       = 1,
    EnemyTPPAsset                                  = 2,
    EResolveAssetTarget_MAX                        = 3

};


// Enum  /Script/CodeV.EAbilityScreenFXType
enum class EAbilityScreenFXType : uint8_t
{
    Default                                        = 0,
    MaterialPanel                                  = 1,
    CameraLens                                     = 2,
    LowVisionFog                                   = 3,
    WallOcclude                                    = 4,
    ReynaBlind                                     = 5,
    FlashBlind                                     = 6,
    EAbilityScreenFXType_MAX                       = 7

};


// Enum  /Script/CodeV.ECalcDamageValueType
enum class ECalcDamageValueType : uint8_t
{
    Normal                                         = 0,
    Lerp                                           = 1,
    Lerp2D                                         = 2,
    Curve                                          = 3,
    Curve2D                                        = 4,
    ECalcDamageValueType_MAX                       = 5

};


// Enum  /Script/CodeV.EFilterSightDistanceType
enum class EFilterSightDistanceType : uint8_t
{
    None                                           = 0,
    InSourceSightDistance                          = 1,
    InTargetSightDistance                          = 2,
    EFilterSightDistanceType_MAX                   = 3

};


// Enum  /Script/CodeV.EApplyGameEffectTargetType
enum class EApplyGameEffectTargetType : uint8_t
{
    All                                            = 0,
    Enemy                                          = 1,
    Friend                                         = 2,
    OnlySelf                                       = 3,
    ExcludeSelf                                    = 4,
    FriendExcludeSelf                              = 5,
    EApplyGameEffectTargetType_MAX                 = 6

};


// Enum  /Script/CodeV.ECVWaitGameplayEventType
enum class ECVWaitGameplayEventType : uint8_t
{
    None                                           = 0,
    Cast                                           = 1,
    Burst                                          = 2,
    Recall                                         = 3,
    Adjust                                         = 4,
    GACharacterActivate                            = 5,
    AutoCast                                       = 6,
    ECVWaitGameplayEventType_MAX                   = 7

};


// Enum  /Script/CodeV.ECVMovementEventType
enum class ECVMovementEventType : uint8_t
{
    None                                           = 0,
    MovementStop                                   = 0,
    FallGround                                     = 0,
    TimeOut                                        = 0,
    Bounce                                         = 0,
    ECVMovementEventType_MAX                       = 1

};


// Enum  /Script/CodeV.EGAAssetSlot
enum class EGAAssetSlot : uint8_t
{
    None                                           = 0,
    GAAssetSlot1                                   = 1,
    GAAssetSlot2                                   = 2,
    GAAssetSlot3                                   = 3,
    GAAssetSlot4                                   = 4,
    GAAssetSlot5                                   = 5,
    GAAssetSlot6                                   = 6,
    GAAssetSlot7                                   = 7,
    GAAssetSlot8                                   = 8,
    GAAssetSlot9                                   = 9,
    GAAssetSlot10                                  = 10,
    GAAssetSlot11                                  = 11,
    GAAssetSlot12                                  = 12,
    GAAssetSlot13                                  = 13,
    GAAssetSlot14                                  = 14,
    GAAssetSlot15                                  = 15,
    GAAssetSlot16                                  = 16,
    EGAAssetSlot_MAX                               = 17

};


// Enum  /Script/CodeV.EMobileQuality
enum class EMobileQuality : uint8_t
{
    Low                                            = 0,
    Middle                                         = 1,
    High                                           = 2,
    EMobileQuality_MAX                             = 3

};


// Enum  /Script/CodeV.EAssetTakeEffectTarget
enum class EAssetTakeEffectTarget : uint8_t
{
    OnlySelf                                       = 0,
    SelfOrTeamateOrActor                           = 1,
    OnlyEnemy                                      = 2,
    AllPlayer                                      = 3,
    EAssetTakeEffectTarget_MAX                     = 4

};


// Enum  /Script/CodeV.ECVCueWeaponType
enum class ECVCueWeaponType : uint8_t
{
    ENone                                          = 0,
    ENiagara                                       = 1,
    EMesh                                          = 2,
    EStaticMesh                                    = 3,
    ECVCueWeaponType_MAX                           = 4

};


// Enum  /Script/CodeV.ETrajectoryUse
enum class ETrajectoryUse : uint8_t
{
    InUse                                          = 0,
    Used                                           = 1,
    ETrajectoryUse_MAX                             = 2

};


// Enum  /Script/CodeV.EMNANetworkType
enum class EMNANetworkType : uint8_t
{
    None                                           = 0,
    Cell_2G                                        = 1,
    Cell_3G                                        = 2,
    Cell_4G                                        = 3,
    WiFi                                           = 4,
    Ethernet                                       = 5,
    Bluetooth                                      = 6,
    Cell_5G_SA                                     = 7,
    Cell_5G_NAS                                    = 8,
    EMNANetworkType_MAX                            = 9

};


// Enum  /Script/CodeV.ECVPropsAnimTPPActionType
enum class ECVPropsAnimTPPActionType : uint8_t
{
    EAbPropsAnim_None                              = 0,
    EAbPropsAnim_BasePose                          = 1,
    EAbPropsAnim_MovementAdd                       = 2,
    EAbPropsAnim_IdleAdd                           = 3,
    EAbPropsAnim_Aim                               = 4,
    EAbPropsAnim_Fire                              = 5,
    EAbPropsAnim_Reload                            = 6,
    EAbPropsAnim_Equip                             = 7,
    EAbPropsAnim_UnEquip                           = 8,
    EAbPropsAnim_Turn                              = 9,
    EAbPropsAnim_JumpStart                         = 10,
    EAbPropsAnim_JumpFalling                       = 11,
    EAbPropsAnim_JumpLandLB                        = 12,
    EAbPropsAnim_Max                               = 13

};


// Enum  /Script/CodeV.ECVPropsAnimFPPActionType
enum class ECVPropsAnimFPPActionType : uint8_t
{
    EAbPropsAnim_None                              = 0,
    EAbPropsAnim_BasePose                          = 1,
    EAbPropsAnim_Movement                          = 2,
    EAbPropsAnim_IdleAdd                           = 3,
    EAbPropsAnim_WalkAdd                           = 4,
    EAbPropsAnim_RunAdd                            = 5,
    EAbPropsAnim_MovementAdd                       = 6,
    EAbPropsAnim_TurnAdd                           = 7,
    EAbPropsAnim_ToStand                           = 8,
    EAbPropsAnim_ToCrouch                          = 9,
    EAbPropsAnim_Fire                              = 10,
    EAbPropsAnim_Reload                            = 11,
    EAbPropsAnim_Equip                             = 12,
    EAbPropsAnim_UnEquip                           = 13,
    EAbPropsAnim_JumpStart                         = 14,
    EAbPropsAnim_JumpLand                          = 15,
    EAbPropsAnim_Max                               = 16

};


// Enum  /Script/CodeV.EPVSClientDebugDrawType
enum class EPVSClientDebugDrawType : uint8_t
{
    BoundingBox2D                                  = 1,
    Capsule                                        = 2,
    PredictLocation                                = 4,
    EPVSClientDebugDrawType_MAX                    = 5

};


// Enum  /Script/CodeV.EPVSCharacterVisibilityState
enum class EPVSCharacterVisibilityState : uint8_t
{
    AllVisible                                     = 0,
    SomeInvisible                                  = 1,
    EPVSCharacterVisibilityState_MAX               = 2

};


// Enum  /Script/CodeV.ESprayPaintType
enum class ESprayPaintType : uint8_t
{
    ESprayPaint_Normal                             = 0,
    ESprayPaint_SingleAnim                         = 1,
    ESprayPaint_LoopAnim                           = 2,
    ESprayPaint_RandomTexture                      = 3,
    ESprayPaint_SingleAnimAndRandom                = 4,
    ESprayPaint_UVTimeCurveLoop                    = 5,
    ESprayPaint_UVTimeCurveSingle                  = 6,
    ESprayPaint_MAX                                = 7

};


// Enum  /Script/CodeV.ETerminatorLookAtType
enum class ETerminatorLookAtType : uint8_t
{
    None                                           = 0,
    DamageCause                                    = 1,
    EveryOne                                       = 2,
    ETerminatorLookAtType_MAX                      = 3

};


// Enum  /Script/CodeV.EClientAvatarStatusType
enum class EClientAvatarStatusType : uint8_t
{
    Status_None                                    = 0,
    Status_PureEvent                               = 1,
    Status_MPC_Float                               = 2,
    Status_MPC_Color                               = 3,
    Status_Max                                     = 4

};


// Enum  /Script/CodeV.EEditorAIGenMode
enum class EEditorAIGenMode : uint8_t
{
    None                                           = 0,
    FillCustom                                     = 1,
    FillAllFix                                     = 2,
    FillAllRandom                                  = 3,
    EEditorAIGenMode_MAX                           = 4

};


// Enum  /Script/CodeV.EEQSBotStateTestType
enum class EEQSBotStateTestType : uint8_t
{
    AIState                                        = 2,
    EEQSBotStateTestType_MAX                       = 3

};


// Enum  /Script/CodeV.EAgentSummonType
enum class EAgentSummonType : uint8_t
{
    None                                           = 0,
    SAIceWall                                      = 1,
    REEye                                          = 2,
    SODrone                                        = 3,
    RARobot                                        = 4,
    CYRope                                         = 5,
    CYCamera                                       = 6,
    SKWolf                                         = 7,
    KJRobot                                        = 8,
    KJPaotai                                       = 9,
    CHTrap                                         = 10,
    CHTransfer                                     = 11,
    EAgentSummonType_MAX                           = 12

};


// Enum  /Script/CodeV.EAgentFactorType
enum class EAgentFactorType : uint8_t
{
    None                                           = 0,
    Duelist                                        = 1,
    Controller                                     = 2,
    Initiator                                      = 3,
    Sentinel                                       = 4,
    EAgentFactorType_MAX                           = 5

};


// Enum  /Script/CodeV.EFocusableTargetType
enum class EFocusableTargetType : uint8_t
{
    ENone                                          = 0,
    EScreenRect                                    = 1,
    ESightRaycast                                  = 2,
    EFocusableTargetType_MAX                       = 3

};


// Enum  /Script/CodeV.EDecisionFactorNormalizationType
enum class EDecisionFactorNormalizationType : uint8_t
{
    None                                           = 0,
    Normal                                         = 1,
    Scaling                                        = 2,
    EDecisionFactorNormalizationType_MAX           = 3

};


// Enum  /Script/CodeV.EAISoundType
enum class EAISoundType : uint8_t
{
    None                                           = 0,
    Fire                                           = 1,
    Walk                                           = 2,
    PlantBomb                                      = 3,
    DefuseBomb                                     = 4,
    Ability                                        = 5,
    Door                                           = 6,
    Break                                          = 7,
    Portal                                         = 8,
    Sling                                          = 9,
    EAISoundType_MAX                               = 10

};


// Enum  /Script/CodeV.EDecisionFactorType
enum class EDecisionFactorType : uint8_t
{
    Numerical                                      = 0,
    OneHot                                         = 1,
    EDecisionFactorType_MAX                        = 2

};


// Enum  /Script/CodeV.EDecisionFactorName
enum class EDecisionFactorName : uint8_t
{
    None                                           = 0,
    Distance                                       = 1,
    IsInSight                                      = 2,
    SenseAge                                       = 3,
    SensePeriod                                    = 4,
    IsBlocked                                      = 5,
    OrientationDegrees                             = 6,
    Hp                                             = 7,
    Weapon                                         = 8,
    WeaponPrice                                    = 9,
    Velocity                                       = 10,
    Kda                                            = 11,
    IsReloading                                    = 12,
    Agent                                          = 13,
    IsWorkingOnLevelTask                           = 14,
    SkillPreparation                               = 15,
    Summon                                         = 16,
    Damage                                         = 17,
    IsPreviousTarget                               = 18,
    AttackPeriod                                   = 19,
    HumanFirst                                     = 20,
    MaxFactor                                      = 21,
    EDecisionFactorName_MAX                        = 22

};


// Enum  /Script/Gameplay.ESGAbilitySlotInputType
enum class ESGAbilitySlotInputType : uint8_t
{
    None                                           = 0,
    Active                                         = 1,
    Deactive                                       = 2,
    DeactiveIgnoreBlocking                         = 3,
    Event                                          = 4,
    ClientEvent                                    = 5,
    QuickEvent                                     = 6,
    ServerEvent                                    = 7,
    ShowAimLine                                    = 8,
    HideAimLine                                    = 9,
    AutoTest_SO_UAV_Shoot                          = 27,
    AutoTest_CY_Smoke                              = 28,
    AutoTest_AS_Select_Star                        = 29,
    AutoTest_SelectByMap                           = 30,
    SyncInputData                                  = 31,
    ESGAbilitySlotInputType_MAX                    = 32

};


// Enum  /Script/Gameplay.EAISystemManagerInitState
enum class EAISystemManagerInitState : uint8_t
{
    None                                           = 0,
    GameInit                                       = 1,
    LuaInit                                        = 2,
    EAISystemManagerInitState_MAX                  = 3

};


// Enum  /Script/Gameplay.ECharAnimTPPActionType
enum class ECharAnimTPPActionType : uint8_t
{
    ECharAnim_None                                 = 0,
    ECharAnim_BasePoseUB                           = 1,
    ECharAnim_MovementAddUB                        = 2,
    ECharAnim_IdleAddUB                            = 3,
    ECharAnim_Aim                                  = 4,
    ECharAnim_AfterIKAim                           = 5,
    ECharAnim_Fire                                 = 6,
    ECharAnim_FirstFire                            = 7,
    ECharAnim_Reload                               = 8,
    ECharAnim_EmptyReload                          = 9,
    ECharAnim_Equip                                = 10,
    ECharAnim_EquipFast                            = 11,
    ECharAnim_EquipFirst                           = 12,
    ECharAnim_MovementAbilityCast                  = 13,
    ECharAnim_SubAttackBegin                       = 14,
    ECharAnim_Montage1                             = 15,
    ECharAnim_Montage2                             = 16,
    ECharAnim_Montage3                             = 17,
    ECharAnim_Montage4                             = 18,
    ECharAnim_Montage5                             = 19,
    ECharAnim_SubAttackEnd                         = 20,
    ECharAnim_AltBasePoseUB                        = 21,
    ECharAnim_AltAim                               = 22,
    ECharAnim_AltMovementLB                        = 23,
    ECharAnim_AltIn                                = 24,
    ECharAnim_AltOut                               = 25,
    ECharAnim_AltFire                              = 26,
    ECharAnim_AltFinalFire                         = 27,
    ECharAnim_BasePoseLB                           = 28,
    ECharAnim_MovementLB                           = 29,
    ECharAnim_IdleAddLB                            = 30,
    ECharAnim_TurnLeftLB                           = 31,
    ECharAnim_TurnRightLB                          = 32,
    ECharAnim_AimLB                                = 33,
    ECharAnim_JumpStartLB                          = 34,
    ECharAnim_JumpFallingLB                        = 35,
    ECharAnim_JumpLandLB                           = 36,
    ECharAnim_JumpLandUB                           = 37,
    ECharAnim_FallingUB                            = 38,
    ECharAnim_StartJumpUB                          = 39,
    ECharAnim_DeathHead                            = 40,
    ECharAnim_DeathBody                            = 41,
    ECharAnim_DeathLeg                             = 42,
    ECharAnim_DeathLand                            = 43,
    ECharAnim_HitHead                              = 44,
    ECharAnim_HitBody                              = 45,
    ECharAnim_HitLeg                               = 46,
    ECharAnim_SkateBasePoseUB                      = 47,
    ECharAnim_SkateMovementLB                      = 48,
    ECharAnim_SkateMovementUB                      = 49,
    ECharAnim_SkateJumpStartLB                     = 50,
    ECharAnim_SkateJumpFallingLB                   = 51,
    ECharAnim_SlideMovementLB                      = 52,
    ECharAnim_Dying                                = 53,
    ECharAnim_StopMoveRun                          = 54,
    ECharAnim_Max                                  = 55

};


// Enum  /Script/Gameplay.ECharAnimFPPActionType
enum class ECharAnimFPPActionType : uint8_t
{
    ECharAnim_None                                 = 0,
    ECharAnim_BasePose                             = 1,
    ECharAnim_Movement                             = 2,
    ECharAnim_MovementAdd                          = 3,
    ECharAnim_TurnAdd                              = 4,
    ECharAnim_ToStand                              = 5,
    ECharAnim_ToCrouch                             = 6,
    ECharAnim_Fire                                 = 7,
    ECharAnim_FirstFire                            = 8,
    ECharAnim_FinalFire                            = 9,
    ECharAnim_Reload                               = 10,
    ECharAnim_EmptyReload                          = 11,
    ECharAnim_Equip                                = 12,
    ECharAnim_EquipFast                            = 13,
    ECharAnim_EquipFirst                           = 14,
    ECharAnim_AnimScaleEquip                       = 15,
    ECharAnim_AnimScaleEquipFast                   = 16,
    ECharAnim_Inspect                              = 17,
    ECharAnim_JumpStart                            = 18,
    ECharAnim_JumpLand                             = 19,
    ECharAnim_MovementAdd2                         = 20,
    ECharAnim_TurnAdd2                             = 21,
    ECharAnim_CameraShake                          = 22,
    ECharAnim_SubAttackBegin                       = 23,
    ECharAnim_Montage1                             = 24,
    ECharAnim_Montage2                             = 25,
    ECharAnim_Montage3                             = 26,
    ECharAnim_Montage4                             = 27,
    ECharAnim_Montage5                             = 28,
    ECharAnim_SubAttackEnd                         = 29,
    ECharAnim_AltBasePose                          = 30,
    ECharAnim_AltMovement                          = 31,
    ECharAnim_AltMovementAdd                       = 32,
    ECharAnim_AltTurnAdd                           = 33,
    ECharAnim_AltToStand                           = 34,
    ECharAnim_AltToCrouch                          = 35,
    ECharAnim_AltIn                                = 36,
    ECharAnim_AltOut                               = 37,
    ECharAnim_AltFire                              = 38,
    ECharAnim_AltFinalFire                         = 39,
    ECharAnim_AltJumpStart                         = 40,
    ECharAnim_AltJumpLand                          = 41,
    ECharAnim_TurnAdd3                             = 42,
    ECharAnim_MoveBS                               = 43,
    ECharAnim_AltMoveBS                            = 44,
    ECharAnim_SkateMoveBS                          = 45,
    ECharAnim_SkateJumpStart                       = 46,
    ECharAnim_SkateJumpLand                        = 47,
    ECharAnim_Max                                  = 48

};


// Enum  /Script/Gameplay.EAnimBodyType
enum class EAnimBodyType : uint8_t
{
    EUpperBody                                     = 0,
    ELowerBody                                     = 1,
    EAnimBodyType_MAX                              = 2

};


// Enum  /Script/Gameplay.EAnimPoseType
enum class EAnimPoseType : uint8_t
{
    ENone                                          = 0,
    EStand                                         = 1,
    ECrouch                                        = 2,
    ESling                                         = 3,
    EMax                                           = 4,
    EAnimPoseType_MAX                              = 5

};


// Enum  /Script/Gameplay.EAnimGroupType
enum class EAnimGroupType : uint8_t
{
    EWeaponGroup                                   = 0,
    EExpressionGroup                               = 1,
    EAnimGroupMax                                  = 2,
    EAnimGroupType_MAX                             = 3

};


// Enum  /Script/Gameplay.EAnimMeshInstType
enum class EAnimMeshInstType : uint8_t
{
    ECoreInst                                      = 0,
    ECosmeticInst                                  = 1,
    EAnimMeshInstType_MAX                          = 2

};


// Enum  /Script/Gameplay.EAnimAvatarType
enum class EAnimAvatarType : uint8_t
{
    EDefault                                       = 0,
    EAvatar1                                       = 1,
    EAvatarMax                                     = 2,
    EAnimAvatarType_MAX                            = 3

};


// Enum  /Script/Gameplay.EAnimLayerType
enum class EAnimLayerType : uint8_t
{
    EDefaultLayer                                  = 0,
    EWeaponLayer                                   = 1,
    EVehicleLayer                                  = 2,
    EAbilityLayer                                  = 3,
    EAnimLayerMax                                  = 4,
    EAnimLayerType_MAX                             = 5

};


// Enum  /Script/Gameplay.EAIUseType
enum class EAIUseType : uint8_t
{
    None                                           = 0,
    Normal                                         = 1,
    AIHost                                         = 2,
    Checker                                        = 3,
    Switch                                         = 4,
    EAIUseType_MAX                                 = 5

};


// Enum  /Script/Gameplay.EBatchRepState
enum class EBatchRepState : uint8_t
{
    Initial                                        = 0,
    FullyMove                                      = 1,
    LightMove                                      = 2,
    SuspendMove                                    = 3,
    EBatchRepState_MAX                             = 4

};


// Enum  /Script/Gameplay.EAbilityMarkStage
enum class EAbilityMarkStage : uint8_t
{
    ETC_NONE                                       = 0,
    ETC_VISIBLE                                    = 1,
    ETC_BLINDBLACK                                 = 2,
    ETC_HIDEMAP                                    = 3,
    ETC_INVISIBLE                                  = 4,
    ETC_HIDEMAPSUMMON                              = 5,
    ETC_CLOSECONEVIEW                              = 6,
    ETC_SKIPENEMYDETECT                            = 7,
    ETC_BLINDBLACKSUMMON                           = 8,
    ETC_ASFORM                                     = 9,
    ETC_MAX                                        = 10

};


// Enum  /Script/Gameplay.EBeaconVisibilityDetectionType
enum class EBeaconVisibilityDetectionType : uint8_t
{
    ETC_NONE                                       = 0,
    ETC_ENEMY                                      = 1,
    ETC_DEFENDER                                   = 2,
    ETC_ALL                                        = 3,
    ETC_MAX                                        = 4

};


// Enum  /Script/Gameplay.EBeaconClearType
enum class EBeaconClearType : uint8_t
{
    ETC_OWNER_ONLY                                 = 0,
    ETC_TEAMMATE                                   = 1,
    ETC_Global                                     = 2,
    ETC_ALL                                        = 3,
    ETC_MAX                                        = 4

};


// Enum  /Script/Gameplay.EBeaconVisibleStage
enum class EBeaconVisibleStage : uint8_t
{
    VALID                                          = 0,
    INVISIBLE                                      = 1,
    VISIBLE                                        = 2,
    INVALID                                        = 3,
    EBeaconVisibleStage_MAX                        = 4

};


// Enum  /Script/Gameplay.EBeaconVisibleRange
enum class EBeaconVisibleRange : uint8_t
{
    EMAMDT_OWNER_ONLY                              = 0,
    EMAMDT_TEAMMATE                                = 1,
    EMAMDT_ALL                                     = 2,
    EMAMDT_MAX                                     = 3

};


// Enum  /Script/Gameplay.ESGAgentResourceLayer
enum class ESGAgentResourceLayer : uint8_t
{
    EDefault                                       = 0,
    ECosmetic                                      = 1,
    ELayerMax                                      = 2,
    ESGAgentResourceLayer_MAX                      = 3

};


// Enum  /Script/Gameplay.ESGInputFingerType
enum class ESGInputFingerType : uint8_t
{
    ViewPort                                       = 0,
    Button                                         = 1,
    Border                                         = 2,
    Block                                          = 3,
    ESGInputFingerType_MAX                         = 4

};


// Enum  /Script/Gameplay.ESGDynamicTagType
enum class ESGDynamicTagType : uint8_t
{
    ESGDynamicTagType_None                         = 0,
    ESGDynamicTagType_Recall                       = 1,
    ESGDynamicTagType_Activate                     = 2,
    ESGDynamicTagType_Revive                       = 3,
    ESGDynamicTagType_DeathMark                    = 4,
    ESGDynamicTagType_ASPoint                      = 5,
    ESGDynamicTagType_MAX                          = 6

};


// Enum  /Script/Gameplay.ESGEffectiveType
enum class ESGEffectiveType : uint8_t
{
    EffectiveType_OnlySelf                         = 0,
    EffectiveType_Teammate                         = 1,
    EffectiveType_Enemy                            = 2,
    EffectiveType_MAX                              = 3

};


// Enum  /Script/Gameplay.ESGInteractionState
enum class ESGInteractionState : uint8_t
{
    InteractionState_None                          = 0,
    InteractionState_Interacting                   = 1,
    InteractionState_InteractCanceled              = 2,
    InteractionState_InteractFinished              = 3,
    InteractionState_MAX                           = 4

};


// Enum  /Script/Gameplay.ESGInteractSlotType
enum class ESGInteractSlotType : uint8_t
{
    InteractSlotType_None                          = 0,
    InteractSlotType_Common                        = 1,
    InteractSlotType_Custom1                       = 2,
    InteractSlotType_Custom2                       = 3,
    InteractSlotType_Custom3                       = 4,
    InteractSlotType_MAX                           = 5

};


// Enum  /Script/Gameplay.ESGInteractType
enum class ESGInteractType : uint8_t
{
    InteractType_Unique                            = 0,
    InteractType_Share                             = 1,
    InteractType_MAX                               = 2

};


// Enum  /Script/Gameplay.ESGItemChangeReason
enum class ESGItemChangeReason : uint8_t
{
    None                                           = 0,
    SlotReplace                                    = 1,
    Consume                                        = 2,
    ChangeWeapon                                   = 11,
    Upgrade                                        = 12,
    Respawn                                        = 13,
    GeneratePickUp                                 = 14,
    ResetSlot                                      = 15,
    DropOnDie                                      = 16,
    DropSlotOnDie                                  = 17,
    RemoveSkill                                    = 18,
    Sell                                           = 19,
    SwitchAgent                                    = 20,
    ESGItemChangeReason_MAX                        = 21

};


// Enum  /Script/Gameplay.EIndependentSpotType
enum class EIndependentSpotType : uint8_t
{
    ItemSpot                                       = 0,
    InteractSpot                                   = 0,
    EIndependentSpotType_MAX                       = 1

};


// Enum  /Script/Gameplay.ESGLevelLoadTime
enum class ESGLevelLoadTime : uint8_t
{
    OnPlayerEnter                                  = 0,
    OnStart                                        = 1,
    OnManually                                     = 2,
    OnDSStartCNEnter                               = 3,
    ESGLevelLoadTime_MAX                           = 4

};


// Enum  /Script/Gameplay.ESGLevelLoadType
enum class ESGLevelLoadType : uint8_t
{
    CleintAndDS                                    = 0,
    OnlyOnClient                                   = 1,
    OnlyOnDS                                       = 2,
    ESGLevelLoadType_MAX                           = 3

};


// Enum  /Script/Gameplay.ESGPawnAction
enum class ESGPawnAction : uint8_t
{
    EPATNone                                       = 0,
    EPATStand                                      = 1,
    EPATCrouch                                     = 2,
    EPATMove                                       = 3,
    EPATJump                                       = 4,
    EPATRope                                       = 5,
    EPATEquip                                      = 6,
    EPATReload                                     = 7,
    EPATInspect                                    = 8,
    EPATEmote                                      = 9,
    EPATSlotBase                                   = 10,
    MainHand                                       = 11,
    OffHand                                        = 12,
    Melee                                          = 13,
    Bomb                                           = 14,
    AbilityQ                                       = 15,
    AbilityE                                       = 16,
    AbilityX                                       = 17,
    AbilityC                                       = 18,
    AbilityPassiveA                                = 19,
    AbilityPassiveB                                = 20,
    AbilityPassiveMutex                            = 21,
    Ability_Max                                    = 21,
    Interact                                       = 22,
    InteractB                                      = 23,
    Empty                                          = 24,
    SpareHandA                                     = 25,
    SpareHandB                                     = 26,
    EPATSlotMax                                    = 42,
    EPATMax                                        = 255,
    ESGPawnAction_MAX                              = 256

};


// Enum  /Script/Gameplay.EPawnStateRelation
enum class EPawnStateRelation : uint8_t
{
    EIgnore                                        = 0,
    ESet                                           = 1,
    EClear                                         = 2,
    EBan                                           = 3,
    EPawnStateRelation_MAX                         = 4

};


// Enum  /Script/Gameplay.EPawnStateLayer
enum class EPawnStateLayer : uint8_t
{
    EStateLayerNone                                = 0,
    EStateLayerPose                                = 1,
    EStateLayerMove                                = 2,
    EStateLayerAction                              = 3,
    EStateLayerHealth                              = 4,
    EStateLayerCamera                              = 5,
    EStateLayerVehicle                             = 6,
    EStateLayerMax                                 = 7,
    EPawnStateLayer_MAX                            = 8

};


// Enum  /Script/Gameplay.ESGPhantomRecordType
enum class ESGPhantomRecordType : uint8_t
{
    ENone                                          = 0,
    EActorSpawn                                    = 1,
    EActorDestroy                                  = 2,
    ECharacterSpawn                                = 3,
    ECharacterDestroy                              = 4,
    EMovementInput                                 = 16,
    EControllerInput                               = 17,
    EMovement                                      = 18,
    EMovementFlag                                  = 19,
    ESlotInput                                     = 32,
    EActiveSlot                                    = 33,
    EAbilityLocation                               = 34,
    EInteract                                      = 35,
    EHitResult                                     = 36,
    EInputAttack                                   = 37,
    EExecAttack                                    = 38,
    EDamage                                        = 39,
    EViewTarget                                    = 40,
    EPossess                                       = 41,
    ELuaAction                                     = 42,
    EAbilityHitResult                              = 43,
    EAIUseAbility                                  = 44,
    EAIUseAbilityForce                             = 45,
    EAICallAbilityEvent                            = 46,
    EShootImpactData                               = 47,
    ECancelInteractAbility                         = 48,
    ERecordMax                                     = 49,
    ESGPhantomRecordType_MAX                       = 50

};


// Enum  /Script/Gameplay.ESGRecordActionType
enum class ESGRecordActionType : uint8_t
{
    ENone                                          = 0,
    EMovementInput                                 = 1,
    ERotationInput                                 = 2,
    EEquipSlotInput                                = 3,
    ESGRecordActionType_MAX                        = 4

};


// Enum  /Script/Gameplay.ESGPhantomMoveFlag
enum class ESGPhantomMoveFlag : uint8_t
{
    ENone                                          = 0,
    EJump                                          = 1,
    ELand                                          = 2,
    ECrouchIn                                      = 4,
    ECrouchOut                                     = 8,
    EWalkIn                                        = 16,
    EWalkOut                                       = 32,
    ETeleport                                      = 64,
    ESGPhantomMoveFlag_MAX                         = 65

};


// Enum  /Script/Gameplay.ESGProjectileThrowMode
enum class ESGProjectileThrowMode : uint8_t
{
    HideMode                                       = 0,
    LowMode                                        = 1,
    ESGProjectileThrowMode_MAX                     = 2

};


// Enum  /Script/Gameplay.ESGProjectileExpType
enum class ESGProjectileExpType : uint8_t
{
    OnlyHeadAndTail                                = 0,
    HeadToTail                                     = 1,
    ESGProjectileExpType_MAX                       = 2

};


// Enum  /Script/Gameplay.EHitCharacterType
enum class EHitCharacterType : uint8_t
{
    None                                           = 0,
    Ignore                                         = 1,
    Stop                                           = 2,
    EHitCharacterType_MAX                          = 3

};


// Enum  /Script/Gameplay.ESGProjectileHitGroundType
enum class ESGProjectileHitGroundType : uint8_t
{
    ShowBounces                                    = 0,
    None                                           = 1,
    ESGProjectileHitGroundType_MAX                 = 2

};


// Enum  /Script/Gameplay.ESGProjectileHitWallType
enum class ESGProjectileHitWallType : uint8_t
{
    ShowHitPoint                                   = 0,
    ShowBounces                                    = 1,
    None                                           = 2,
    ESGProjectileHitWallType_MAX                   = 3

};


// Enum  /Script/Gameplay.ESGProjectileLaunchType
enum class ESGProjectileLaunchType : uint8_t
{
    FromActorEyesViewPoint                         = 0,
    GroundStepPath                                 = 1,
    ESGProjectileLaunchType_MAX                    = 2

};


// Enum  /Script/Gameplay.ESGProjectileShowLevel
enum class ESGProjectileShowLevel : uint8_t
{
    All                                            = 0,
    HideRadius                                     = 1,
    HideBouncesAndRadius                           = 2,
    OnlyHitPoint                                   = 3,
    ESGProjectileShowLevel_MAX                     = 4

};


// Enum  /Script/Gameplay.ESGReplayState
enum class ESGReplayState : uint8_t
{
    ENone                                          = 0,
    ERecording                                     = 1,
    EPlaying                                       = 2,
    EPaused                                        = 3,
    ESGReplayState_MAX                             = 4

};


// Enum  /Script/Gameplay.ESGReplayPayloadType
enum class ESGReplayPayloadType : uint8_t
{
    ENone                                          = 0,
    EExtraInfoPB                                   = 1,
    EMemoryStream                                  = 2,
    EWonderfulClip                                 = 3,
    ESGReplayPayloadType_MAX                       = 4

};


// Enum  /Script/Gameplay.ESGReplayCompressFormat
enum class ESGReplayCompressFormat : uint8_t
{
    ENone                                          = 0,
    EZLIB                                          = 1,
    EGZIP                                          = 2,
    ELZ4                                           = 3,
    ESGReplayCompressFormat_MAX                    = 4

};


// Enum  /Script/Gameplay.ESGWeaponSlotInputType
enum class ESGWeaponSlotInputType : uint8_t
{
    None                                           = 0,
    Active                                         = 1,
    Deactive                                       = 2,
    Attack                                         = 3,
    AttackImmediate                                = 4,
    Reload                                         = 5,
    Scope                                          = 6,
    Inspect                                        = 7,
    SwitchMain                                     = 8,
    LastMainSlot                                   = 9,
    ESGWeaponSlotInputType_MAX                     = 10

};


// Enum  /Script/SlateCore.EOrientation
enum class EOrientation : uint8_t
{
    Orient_Horizontal                              = 0,
    Orient_Vertical                                = 1,
    Orient_MAX                                     = 2

};


// Enum  /Script/Client.EAttachType
enum class EAttachType : uint8_t
{
    EAttachType_NoAttach                           = 0,
    EAttachType_AttachFirst                        = 1,
    EAttachType_AttachMiddle                       = 2,
    EAttachType_MAX                                = 3

};


// Enum  /Script/Slate.EDescendantScrollDestination
enum class EDescendantScrollDestination : uint8_t
{
    IntoView                                       = 0,
    TopOrLeft                                      = 1,
    Center                                         = 2,
    EDescendantScrollDestination_MAX               = 3

};


// Enum  /Script/SlateCore.EConsumeMouseWheel
enum class EConsumeMouseWheel : uint8_t
{
    WhenScrollingPossible                          = 0,
    Always                                         = 1,
    Never                                          = 2,
    EConsumeMouseWheel_MAX                         = 3

};


// Enum  /Script/Slate.EScrollWhenFocusChanges
enum class EScrollWhenFocusChanges : uint8_t
{
    NoScroll                                       = 0,
    InstantScroll                                  = 1,
    AnimatedScroll                                 = 2,
    EScrollWhenFocusChanges_MAX                    = 3

};


// Enum  /Script/UMG.EWidgetAnimationEvent
enum class EWidgetAnimationEvent : uint8_t
{
    Started                                        = 0,
    Finished                                       = 1,
    EWidgetAnimationEvent_MAX                      = 2

};


// Enum  /Script/UMG.EUMGSequencePlayMode
enum class EUMGSequencePlayMode : uint8_t
{
    Forward                                        = 0,
    Reverse                                        = 1,
    PingPong                                       = 2,
    EUMGSequencePlayMode_MAX                       = 3

};


// Enum  /Script/UMG.EWidgetTickFrequency
enum class EWidgetTickFrequency : uint8_t
{
    Never                                          = 0,
    Auto                                           = 1,
    EWidgetTickFrequency_MAX                       = 2

};


// Enum  /Script/Client.EBatchFetchingListType
enum class EBatchFetchingListType : uint8_t
{
    None                                           = 0,
    Upper                                          = 1,
    Lower                                          = 2,
    BothSides                                      = 3,
    EBatchFetchingListType_MAX                     = 4

};


// Enum  /Script/Client.EPreviewType
enum class EPreviewType : uint8_t
{
    Horizontal                                     = 0,
    Vertical                                       = 1,
    Cycle                                          = 2,
    EPreviewType_MAX                               = 3

};


// Enum  /Script/Slate.ESelectionMode
enum class ESelectionMode : uint8_t
{
    None                                           = 0,
    Single                                         = 1,
    SingleToggle                                   = 2,
    Multi                                          = 3,
    ESelectionMode_MAX                             = 4

};


// Enum  /Script/Slate.ETextTransformPolicy
enum class ETextTransformPolicy : uint8_t
{
    None                                           = 0,
    ToLower                                        = 1,
    ToUpper                                        = 2,
    ETextTransformPolicy_MAX                       = 3

};


// Enum  /Script/Client.ECameraCurveType
enum class ECameraCurveType : uint8_t
{
    Location                                       = 0,
    Rotation                                       = 1,
    NormalFOV                                      = 2,
    HorizontalOffsetRatio                          = 3,
    LocationCorrection                             = 4,
    ECameraCurveType_MAX                           = 5

};


// Enum  /Script/Client.ECommonAvatarEmoteType
enum class ECommonAvatarEmoteType : uint8_t
{
    None                                           = 0,
    Idle                                           = 1,
    Entry                                          = 2,
    Change                                         = 3,
    Change_BP                                      = 4,
    Switch_BP                                      = 5,
    EnterGame_BP                                   = 6,
    MVP_GR                                         = 7,
    PoseA                                          = 8,
    PoseB                                          = 9,
    PoseC                                          = 10,
    EntryPoseA                                     = 11,
    Max                                            = 12

};


// Enum  /Script/Engine.EAnimCurveType
enum class EAnimCurveType : uint8_t
{
    AttributeCurve                                 = 0,
    MaterialCurve                                  = 1,
    MorphTargetCurve                               = 2,
    MaxAnimCurveType                               = 3,
    EAnimCurveType_MAX                             = 4

};


// Enum  /Script/Engine.EMontagePlayReturnType
enum class EMontagePlayReturnType : uint8_t
{
    MontageLength                                  = 0,
    Duration                                       = 1,
    EMontagePlayReturnType_MAX                     = 2

};


// Enum  /Script/Engine.ERootMotionMode
enum class ERootMotionMode : uint8_t
{
    NoRootMotionExtraction                         = 0,
    IgnoreRootMotion                               = 1,
    RootMotionFromEverything                       = 2,
    RootMotionFromMontagesOnly                     = 3,
    ERootMotionMode_MAX                            = 4

};


// Enum  /Script/Engine.EAnimLinkMethod
enum class EAnimLinkMethod : uint8_t
{
    Absolute                                       = 0,
    Relative                                       = 1,
    Proportional                                   = 2,
    EAnimLinkMethod_MAX                            = 3

};


// Enum  /Script/Engine.ENotifyFilterType
enum class ENotifyFilterType : uint8_t
{
    NoFiltering                                    = 0,
    LOD                                            = 1,
    ENotifyFilterType_MAX                          = 2

};


// Enum  /Script/Engine.EMontageNotifyTickType
enum class EMontageNotifyTickType : uint8_t
{
    Queued                                         = 0,
    BranchingPoint                                 = 1,
    EMontageNotifyTickType_MAX                     = 2

};


// Enum  /Script/Client.EMarkLocationPart
enum class EMarkLocationPart : uint8_t
{
    None                                           = 0,
    Bottom                                         = 1,
    Mid                                            = 2,
    Head                                           = 3,
    EMarkLocationPart_MAX                          = 4

};


// Enum  /Script/Client.ESaveToPhotoAlbumStatus
enum class ESaveToPhotoAlbumStatus : uint8_t
{
    ESAS_None                                      = 0,
    ESPR_Saving                                    = 1,
    ESPR_Success                                   = 2,
    ESPR_Failed_NoAlbumPermission                  = 3,
    ESPR_Failed_NoPermissionAndNoRationale         = 4,
    ESPR_Failed_ShowPermissionRationale            = 5,
    ESPR_Failed_InternalError                      = 6,
    ESaveToPhotoAlbumStatus_MAX                    = 7

};


// Enum  /Script/Client.ELayoutType
enum class ELayoutType : uint8_t
{
    Center                                         = 0,
    Left                                           = 1,
    Right                                          = 2,
    ELayoutType_MAX                                = 3

};


// Enum  /Script/Client.EAutoScrollType
enum class EAutoScrollType : uint8_t
{
    NoScroll                                       = 0,
    ScrollLeft                                     = 1,
    ScrollLeftandRight                             = 2,
    EAutoScrollType_MAX                            = 3

};


// Enum  /Script/Client.EVoiceReqType
enum class EVoiceReqType : uint8_t
{
    None                                           = 0,
    JoinRoom                                       = 1,
    QuitRoom                                       = 2,
    ChangeRole                                     = 3,
    OperateMic                                     = 4,
    OperateSpeaker                                 = 5,
    EnableRoomMicrophone                           = 6,
    EnableRoomSpeaker                              = 7,
    EVoiceReqType_MAX                              = 8

};


// Enum  /Script/Client.UrlHashTypeEnum
enum class UrlHashTypeEnum : uint8_t
{
    HashUrl                                        = 1,
    HashPath                                       = 2,
    UrlHashTypeEnum_MAX                            = 3

};


// Enum  /Script/Client.EJoystickGestureType
enum class EJoystickGestureType : uint8_t
{
    Gesture1                                       = 0,
    Gesture2                                       = 1,
    Gesture3                                       = 2,
    Gesture4                                       = 3,
    EJoystickGestureType_MAX                       = 4

};


// Enum  /Script/Client.ESlowMoveHapticEnum
enum class ESlowMoveHapticEnum : uint8_t
{
    Close                                          = 1,
    Run                                            = 2,
    SlowDrag                                       = 3,
    ESlowMoveHapticEnum_MAX                        = 4

};


// Enum  /Script/Client.EMainJoystickPeekType
enum class EMainJoystickPeekType : uint8_t
{
    Hide                                           = 0,
    Left                                           = 1,
    Right                                          = 2,
    EMainJoystickPeekType_MAX                      = 3

};


// Enum  /Script/Client.EMapAsymptoticScaleMode
enum class EMapAsymptoticScaleMode : uint8_t
{
    None                                           = 0,
    Forward                                        = 1,
    Backward                                       = 2,
    EMapAsymptoticScaleMode_MAX                    = 3

};


// Enum  /Script/Client.EMapFollowStyle
enum class EMapFollowStyle : uint8_t
{
    Follow                                         = 1,
    FixView                                        = 2,
    CampView                                       = 3,
    EMapFollowStyle_MAX                            = 4

};


// Enum  /Script/Client.EMapRadarStyle
enum class EMapRadarStyle : uint8_t
{
    Part                                           = 1,
    Global                                         = 2,
    EMapRadarStyle_MAX                             = 3

};


// Enum  /Script/Client.EHeightInputType
enum class EHeightInputType : uint8_t
{
    EIT_None                                       = 0,
    EIT_Up                                         = 1,
    ECM_Down                                       = 2,
    EHeightInputType_MAX                           = 3

};


// Enum  /Script/Client.EFreeCameraMode
enum class EFreeCameraMode : uint8_t
{
    ECM_None                                       = 0,
    ECM_Horizon                                    = 1,
    ECM_Forward                                    = 2,
    ECM_MAX                                        = 3

};


// Enum  /Script/Client.PakValidStatus
enum class PakValidStatus : uint8_t
{
    NoValid                                        = 0,
    MayBeValid                                     = 1,
    MultValid                                      = 2,
    Valid                                          = 3,
    PakValidStatus_MAX                             = 4

};


// Enum  /Script/Client.EPreviewType2
enum class EPreviewType2 : uint8_t
{
    Horizontal                                     = 0,
    Vertical                                       = 1,
    Cycle                                          = 2,
    EPreviewType2_MAX                              = 3

};


// Enum  /Script/Client.EPeekState
enum class EPeekState : uint8_t
{
    None                                           = 0,
    PeekingOut                                     = 1,
    PeekingBack                                    = 2,
    EPeekState_MAX                                 = 3

};


// Enum  /Script/Client.EPeekType
enum class EPeekType : uint8_t
{
    None                                           = 0,
    Left                                           = 1,
    Right                                          = 2,
    EPeekType_MAX                                  = 3

};


// Enum  /Script/Client.EChildEdgeStatus
enum class EChildEdgeStatus : uint8_t
{
    None                                           = 0,
    OnEdge                                         = 1,
    NotOnEdge                                      = 2,
    EChildEdgeStatus_MAX                           = 3

};


// Enum  /Script/Client.EAdapterType
enum class EAdapterType : uint8_t
{
    None                                           = 0,
    HorizontalAdapter                              = 1,
    OffsetAdapter                                  = 2,
    FOVCorrector                                   = 3,
    EAdapterType_MAX                               = 4

};


// Enum  /Script/Client.EUploadErrCode
enum class EUploadErrCode : uint32_t
{
    ErrFileNotExist                                = 4294967295,
    ErrInvalidUrl                                  = 4294967294,
    ErrLoadFile                                    = 4294967293,
    ErrProcessRequest                              = 4294967292,
    EUploadErrCode_MAX                             = 0

};


// Enum  /Script/Client.VideoResType
enum class VideoResType : uint8_t
{
    PlayerBP                                       = 0,
    Material                                       = 1,
    VideoResType_MAX                               = 2

};


// Enum  /Script/Client.EWaterfallItemStyle
enum class EWaterfallItemStyle : uint8_t
{
    FullLength                                     = 0,
    PartialLength                                  = 1,
    EWaterfallItemStyle_MAX                        = 2

};


// Enum  /Script/SGRepGraph.ESGRepNodeMapping
enum class ESGRepNodeMapping : uint8_t
{
    NotMapped                                      = 0,
    NotRouted                                      = 1,
    RelevantAllConnections                         = 2,
    AlwaysRelevantHighRate                         = 3,
    PlayerState                                    = 4,
    TeamDependent                                  = 5,
    OwnerDependent                                 = 6,
    Spatialize_Static                              = 7,
    Spatialize_Dynamic                             = 8,
    Spatialize_Dormancy                            = 9,
    ESGRepNodeMapping_MAX                          = 10

};


// Enum  /Script/CoreUObject.ELifeRepFlags
enum class ELifeRepFlags : uint32_t
{
    REP_None                                       = 0,
    IsClosePushCompare                             = 2048,
    IsCloseShadowData                              = 4096,
    IsForceCompare                                 = 8192,
    IsRepChannel                                   = 16384,
    ELifeRepFlags_MAX                              = 16385

};


// Enum  /Script/CoreUObject.ELifetimeCondition
enum class ELifetimeCondition : uint8_t
{
    COND_None                                      = 0,
    COND_InitialOnly                               = 1,
    COND_OwnerOnly                                 = 2,
    COND_SkipOwner                                 = 3,
    COND_SimulatedOnly                             = 4,
    COND_AutonomousOnly                            = 5,
    COND_SimulatedOrPhysics                        = 6,
    COND_InitialOrOwner                            = 7,
    COND_Custom                                    = 8,
    COND_ReplayOrOwner                             = 9,
    COND_ReplayOnly                                = 10,
    COND_SimulatedOnlyNoReplay                     = 11,
    COND_SimulatedOrPhysicsNoReplay                = 12,
    COND_SkipReplay                                = 13,
    COND_InitialOrReplay                           = 14,
    COND_Never                                     = 15,
    COND_Max                                       = 16

};


// Enum  /Script/CoreUObject.EDataValidationResult
enum class EDataValidationResult : uint8_t
{
    Invalid                                        = 0,
    Valid                                          = 1,
    NotValidated                                   = 2,
    EDataValidationResult_MAX                      = 3

};


// Enum  /Script/CoreUObject.EAppMsgType
enum class EAppMsgType : uint8_t
{
    Ok                                             = 0,
    YesNo                                          = 1,
    OkCancel                                       = 2,
    YesNoCancel                                    = 3,
    CancelRetryContinue                            = 4,
    YesNoYesAllNoAll                               = 5,
    YesNoYesAllNoAllCancel                         = 6,
    YesNoYesAll                                    = 7,
    EAppMsgType_MAX                                = 8

};


// Enum  /Script/CoreUObject.EAppReturnType
enum class EAppReturnType : uint8_t
{
    No                                             = 0,
    Yes                                            = 1,
    YesAll                                         = 2,
    NoAll                                          = 3,
    Cancel                                         = 4,
    Ok                                             = 5,
    Retry                                          = 6,
    Continue                                       = 7,
    EAppReturnType_MAX                             = 8

};


// Enum  /Script/CoreUObject.EPropertyAccessChangeNotifyMode
enum class EPropertyAccessChangeNotifyMode : uint8_t
{
    Default                                        = 0,
    Never                                          = 1,
    Always                                         = 2,
    EPropertyAccessChangeNotifyMode_MAX            = 3

};


// Enum  /Script/CoreUObject.EUnit
enum class EUnit : uint8_t
{
    Micrometers                                    = 0,
    Millimeters                                    = 1,
    Centimeters                                    = 2,
    Meters                                         = 3,
    Kilometers                                     = 4,
    Inches                                         = 5,
    Feet                                           = 6,
    Yards                                          = 7,
    Miles                                          = 8,
    Lightyears                                     = 9,
    Degrees                                        = 10,
    Radians                                        = 11,
    MetersPerSecond                                = 12,
    KilometersPerHour                              = 13,
    MilesPerHour                                   = 14,
    Celsius                                        = 15,
    Farenheit                                      = 16,
    Kelvin                                         = 17,
    Micrograms                                     = 18,
    Milligrams                                     = 19,
    Grams                                          = 20,
    Kilograms                                      = 21,
    MetricTons                                     = 22,
    Ounces                                         = 23,
    Pounds                                         = 24,
    Stones                                         = 25,
    Newtons                                        = 26,
    PoundsForce                                    = 27,
    KilogramsForce                                 = 28,
    Hertz                                          = 29,
    Kilohertz                                      = 30,
    Megahertz                                      = 31,
    Gigahertz                                      = 32,
    RevolutionsPerMinute                           = 33,
    Bytes                                          = 34,
    Kilobytes                                      = 35,
    Megabytes                                      = 36,
    Gigabytes                                      = 37,
    Terabytes                                      = 38,
    Lumens                                         = 39,
    Milliseconds                                   = 43,
    Seconds                                        = 44,
    Minutes                                        = 45,
    Hours                                          = 46,
    Days                                           = 47,
    Months                                         = 48,
    Years                                          = 49,
    Multiplier                                     = 52,
    Percentage                                     = 51,
    Unspecified                                    = 53,
    EUnit_MAX                                      = 54

};


// Enum  /Script/CoreUObject.EPixelFormat
enum class EPixelFormat : uint8_t
{
    PF_Unknown                                     = 0,
    PF_A32B32G32R32F                               = 1,
    PF_B8G8R8A8                                    = 2,
    PF_G8                                          = 3,
    PF_G16                                         = 4,
    PF_DXT1                                        = 5,
    PF_DXT3                                        = 6,
    PF_DXT5                                        = 7,
    PF_UYVY                                        = 8,
    PF_FloatRGB                                    = 9,
    PF_FloatRGBA                                   = 10,
    PF_DepthStencil                                = 11,
    PF_ShadowDepth                                 = 12,
    PF_R32_FLOAT                                   = 13,
    PF_G16R16                                      = 14,
    PF_G16R16F                                     = 15,
    PF_G16R16F_FILTER                              = 16,
    PF_G32R32F                                     = 17,
    PF_A2B10G10R10                                 = 18,
    PF_A16B16G16R16                                = 19,
    PF_D24                                         = 20,
    PF_R16F                                        = 21,
    PF_R16F_FILTER                                 = 22,
    PF_BC5                                         = 23,
    PF_V8U8                                        = 24,
    PF_A1                                          = 25,
    PF_FloatR11G11B10                              = 26,
    PF_A8                                          = 27,
    PF_R32_UINT                                    = 28,
    PF_R32_SINT                                    = 29,
    PF_PVRTC2                                      = 30,
    PF_PVRTC4                                      = 31,
    PF_R16_UINT                                    = 32,
    PF_R16_SINT                                    = 33,
    PF_R16G16B16A16_UINT                           = 34,
    PF_R16G16B16A16_SINT                           = 35,
    PF_R5G6B5_UNORM                                = 36,
    PF_R8G8B8A8                                    = 37,
    PF_A8R8G8B8                                    = 38,
    PF_BC4                                         = 39,
    PF_R8G8                                        = 40,
    PF_ATC_RGB                                     = 41,
    PF_ATC_RGBA_E                                  = 42,
    PF_ATC_RGBA_I                                  = 43,
    PF_X24_G8                                      = 44,
    PF_ETC1                                        = 45,
    PF_ETC2_RGB                                    = 46,
    PF_ETC2_RGBA                                   = 47,
    PF_R32G32B32A32_UINT                           = 48,
    PF_R16G16_UINT                                 = 49,
    PF_ASTC_4x4                                    = 50,
    PF_ASTC_6x6                                    = 51,
    PF_ASTC_8x8                                    = 52,
    PF_ASTC_10x10                                  = 53,
    PF_ASTC_12x12                                  = 54,
    PF_BC6H                                        = 55,
    PF_BC7                                         = 56,
    PF_R8_UINT                                     = 57,
    PF_L8                                          = 58,
    PF_XGXR8                                       = 59,
    PF_R8G8B8A8_UINT                               = 60,
    PF_R8G8B8A8_SNORM                              = 61,
    PF_R16G16B16A16_UNORM                          = 62,
    PF_R16G16B16A16_SNORM                          = 63,
    PF_PLATFORM_HDR                                = 64,
    PF_PLATFORM_HDR                                = 65,
    PF_PLATFORM_HDR                                = 66,
    PF_NV12                                        = 67,
    PF_R32G32_UINT                                 = 68,
    PF_ETC2_R11_EAC                                = 69,
    PF_ETC2_RG11_EAC                               = 70,
    PF_MAX                                         = 72

};


// Enum  /Script/CoreUObject.EAxis
enum class EAxis : uint8_t
{
    None                                           = 0,
    X                                              = 1,
    Y                                              = 2,
    Z                                              = 3,
    EAxis_MAX                                      = 4

};


// Enum  /Script/CoreUObject.ELogTimes
enum class ELogTimes : uint8_t
{
    None                                           = 0,
    UTC                                            = 1,
    SinceGStartTime                                = 2,
    Local                                          = 3,
    ELogTimes_MAX                                  = 4

};


// Enum  /Script/CoreUObject.ESearchDir
enum class ESearchDir : uint8_t
{
    FromStart                                      = 0,
    FromEnd                                        = 1,
    ESearchDir_MAX                                 = 2

};


// Enum  /Script/CoreUObject.ESearchCase
enum class ESearchCase : uint8_t
{
    CaseSensitive                                  = 0,
    IgnoreCase                                     = 1,
    ESearchCase_MAX                                = 2

};


// Enum  /Script/InputCore.ETouchType
enum class ETouchType : uint8_t
{
    Began                                          = 0,
    Moved                                          = 1,
    Stationary                                     = 2,
    ForceChanged                                   = 3,
    FirstMove                                      = 4,
    Ended                                          = 5,
    NumTypes                                       = 6,
    ETouchType_MAX                                 = 7

};


// Enum  /Script/InputCore.EConsoleForGamepadLabels
enum class EConsoleForGamepadLabels : uint8_t
{
    None                                           = 0,
    XBoxOne                                        = 1,
    PS4                                            = 2,
    EConsoleForGamepadLabels_MAX                   = 3

};


// Enum  /Script/InputCore.EControllerHand
enum class EControllerHand : uint8_t
{
    Left                                           = 0,
    Right                                          = 1,
    AnyHand                                        = 2,
    Pad                                            = 3,
    ExternalCamera                                 = 4,
    Gun                                            = 5,
    Special                                        = 6,
    Special                                        = 7,
    Special                                        = 8,
    Special                                        = 9,
    Special                                        = 10,
    Special                                        = 11,
    Special                                        = 12,
    Special                                        = 13,
    Special                                        = 14,
    Special                                        = 15,
    Special                                        = 16,
    ControllerHand_Count                           = 17,
    EControllerHand_MAX                            = 18

};


// Enum  /Script/SlateCore.EFontLayoutMethod
enum class EFontLayoutMethod : uint8_t
{
    Metrics                                        = 0,
    BoundingBox                                    = 1,
    EFontLayoutMethod_MAX                          = 2

};


// Enum  /Script/SlateCore.EFontLoadingPolicy
enum class EFontLoadingPolicy : uint8_t
{
    LazyLoad                                       = 0,
    Stream                                         = 1,
    Inline                                         = 2,
    EFontLoadingPolicy_MAX                         = 3

};


// Enum  /Script/SlateCore.EFontHinting
enum class EFontHinting : uint8_t
{
    Default                                        = 0,
    Auto                                           = 1,
    AutoLight                                      = 2,
    Monochrome                                     = 3,
    None                                           = 4,
    EFontHinting_MAX                               = 5

};


// Enum  /Script/SlateCore.EFocusCause
enum class EFocusCause : uint8_t
{
    Mouse                                          = 0,
    Navigation                                     = 1,
    SetDirectly                                    = 2,
    Cleared                                        = 3,
    OtherWidgetLostFocus                           = 4,
    WindowActivate                                 = 5,
    EFocusCause_MAX                                = 6

};


// Enum  /Script/SlateCore.ESlateDebuggingFocusEvent
enum class ESlateDebuggingFocusEvent : uint8_t
{
    FocusChanging                                  = 0,
    FocusLost                                      = 1,
    FocusReceived                                  = 2,
    MAX                                            = 3

};


// Enum  /Script/SlateCore.ESlateDebuggingNavigationMethod
enum class ESlateDebuggingNavigationMethod : uint8_t
{
    Unknown                                        = 0,
    Explicit                                       = 1,
    CustomDelegateBound                            = 2,
    CustomDelegateUnbound                          = 3,
    NextOrPrevious                                 = 4,
    HitTestGrid                                    = 5,
    ESlateDebuggingNavigationMethod_MAX            = 6

};


// Enum  /Script/SlateCore.ESlateDebuggingStateChangeEvent
enum class ESlateDebuggingStateChangeEvent : uint8_t
{
    MouseCaptureGained                             = 0,
    MouseCaptureLost                               = 1,
    ESlateDebuggingStateChangeEvent_MAX            = 2

};


// Enum  /Script/SlateCore.ESlateDebuggingInputEvent
enum class ESlateDebuggingInputEvent : uint8_t
{
    MouseMove                                      = 0,
    MouseEnter                                     = 1,
    MouseLeave                                     = 2,
    PreviewMouseButtonDown                         = 3,
    MouseButtonDown                                = 4,
    MouseButtonUp                                  = 5,
    MouseButtonDoubleClick                         = 6,
    MouseWheel                                     = 7,
    TouchStart                                     = 8,
    TouchEnd                                       = 9,
    TouchForceChanged                              = 10,
    TouchFirstMove                                 = 11,
    TouchMoved                                     = 12,
    DragDetected                                   = 13,
    DragEnter                                      = 14,
    DragLeave                                      = 15,
    DragOver                                       = 16,
    DragDrop                                       = 17,
    DropMessage                                    = 18,
    PreviewKeyDown                                 = 19,
    KeyDown                                        = 20,
    KeyUp                                          = 21,
    KeyChar                                        = 22,
    AnalogInput                                    = 23,
    TouchGesture                                   = 24,
    MotionDetected                                 = 25,
    MAX                                            = 26

};


// Enum  /Script/SlateCore.EWidgetAudioAction
enum class EWidgetAudioAction : uint8_t
{
    OnMapping                                      = 0,
    OnHover                                        = 1,
    OnUnhover                                      = 2,
    OnClicked                                      = 3,
    OnPressed                                      = 4,
    OnReleased                                     = 5,
    OnScroll                                       = 6,
    OnStateChanged                                 = 7,
    OnSelectionChanged                             = 8,
    OnTextCommitted                                = 9,
    OnValueChanged                                 = 10,
    OnBeginSliderMove                              = 11,
    OnEndSliderMove                                = 12,
    OnTextChanged                                  = 13,
    OnTextCommittee                                = 14,
    OnDoubleClicked                                = 15,
    EWidgetAudioAction_MAX                         = 16

};


// Enum  /Script/SlateCore.EScrollDirection
enum class EScrollDirection : uint8_t
{
    Scroll_Down                                    = 0,
    Scroll_Up                                      = 1,
    Scroll_MAX                                     = 2

};


// Enum  /Script/SlateCore.ENavigationGenesis
enum class ENavigationGenesis : uint8_t
{
    Keyboard                                       = 0,
    Controller                                     = 1,
    User                                           = 2,
    ENavigationGenesis_MAX                         = 3

};


// Enum  /Script/SlateCore.ENavigationSource
enum class ENavigationSource : uint8_t
{
    FocusedWidget                                  = 0,
    WidgetUnderCursor                              = 1,
    ENavigationSource_MAX                          = 2

};


// Enum  /Script/SlateCore.EUINavigationAction
enum class EUINavigationAction : uint8_t
{
    Accept                                         = 0,
    Back                                           = 1,
    Num                                            = 2,
    Invalid                                        = 3,
    EUINavigationAction_MAX                        = 4

};


// Enum  /Script/SlateCore.ESlateCheckBoxType
enum class ESlateCheckBoxType : uint8_t
{
    CheckBox                                       = 0,
    ToggleButton                                   = 1,
    ESlateCheckBoxType_MAX                         = 2

};


// Enum  /Script/SlateCore.ESlateParentWindowSearchMethod
enum class ESlateParentWindowSearchMethod : uint8_t
{
    ActiveWindow                                   = 0,
    MainWindow                                     = 1,
    ESlateParentWindowSearchMethod_MAX             = 2

};


// Enum  /Script/ImageWrapper.EBitmapCSType
enum class EBitmapCSType : uint32_t
{
    BCST_BLCS_CALIBRATED_RGB                       = 0,
    BCST_LCS_sRGB                                  = 1934772034,
    BCST_LCS_WINDOWS_COLOR_SPACE                   = 1466527264,
    BCST_PROFILE_LINKED                            = 1279872587,
    BCST_PROFILE_EMBEDDED                          = 1296188740,
    BCST_MAX                                       = 1934772035

};


// Enum  /Script/ImageWrapper.EBitmapHeaderVersion
enum class EBitmapHeaderVersion : uint8_t
{
    BHV_BITMAPINFOHEADER                           = 0,
    BHV_BITMAPV2INFOHEADER                         = 1,
    BHV_BITMAPV3INFOHEADER                         = 2,
    BHV_BITMAPV4HEADER                             = 3,
    BHV_BITMAPV5HEADER                             = 4,
    BHV_MAX                                        = 5

};


// Enum  /Script/Slate.ETableViewMode
enum class ETableViewMode : uint8_t
{
    List                                           = 0,
    Tile                                           = 1,
    Tree                                           = 2,
    ETableViewMode_MAX                             = 3

};


// Enum  /Script/Slate.EMultiBlockType
enum class EMultiBlockType : uint8_t
{
    None                                           = 0,
    ButtonRow                                      = 1,
    EditableText                                   = 2,
    Heading                                        = 3,
    MenuEntry                                      = 4,
    Separator                                      = 5,
    ToolBarButton                                  = 6,
    ToolBarComboButton                             = 7,
    Widget                                         = 8,
    EMultiBlockType_MAX                            = 9

};


// Enum  /Script/Slate.EMultiBoxType
enum class EMultiBoxType : uint8_t
{
    MenuBar                                        = 0,
    ToolBar                                        = 1,
    VerticalToolBar                                = 2,
    UniformToolBar                                 = 3,
    Menu                                           = 4,
    ButtonRow                                      = 5,
    EMultiBoxType_MAX                              = 6

};


// Enum  /Script/Slate.EProgressBarFillType
enum class EProgressBarFillType : uint8_t
{
    LeftToRight                                    = 0,
    RightToLeft                                    = 1,
    FillFromCenter                                 = 2,
    TopToBottom                                    = 3,
    BottomToTop                                    = 4,
    EProgressBarFillType_MAX                       = 5

};


// Enum  /Script/Slate.EStretch
enum class EStretch : uint8_t
{
    None                                           = 0,
    Fill                                           = 1,
    ScaleToFit                                     = 2,
    ScaleToFitX                                    = 3,
    ScaleToFitY                                    = 4,
    ScaleToFill                                    = 5,
    ScaleBySafeZone                                = 6,
    UserSpecified                                  = 7,
    EStretch_MAX                                   = 8

};


// Enum  /Script/Slate.EStretchDirection
enum class EStretchDirection : uint8_t
{
    Both                                           = 0,
    DownOnly                                       = 1,
    UpOnly                                         = 2,
    EStretchDirection_MAX                          = 3

};


// Enum  /Script/Slate.EListItemAlignment
enum class EListItemAlignment : uint8_t
{
    EvenlyDistributed                              = 0,
    EvenlySize                                     = 1,
    EvenlyWide                                     = 2,
    LeftAligned                                    = 3,
    RightAligned                                   = 4,
    CenterAligned                                  = 5,
    Fill                                           = 6,
    EListItemAlignment_MAX                         = 7

};


// Enum  /Script/Slate.ECustomizedToolMenuVisibility
enum class ECustomizedToolMenuVisibility : uint8_t
{
    None                                           = 0,
    Visible                                        = 1,
    Hidden                                         = 2,
    ECustomizedToolMenuVisibility_MAX              = 3

};


// Enum  /Script/Slate.EMultipleKeyBindingIndex
enum class EMultipleKeyBindingIndex : uint8_t
{
    Primary                                        = 0,
    Secondary                                      = 1,
    NumChords                                      = 2,
    EMultipleKeyBindingIndex_MAX                   = 3

};


// Enum  /Script/Slate.EUserInterfaceActionType
enum class EUserInterfaceActionType : uint8_t
{
    None                                           = 0,
    Button                                         = 1,
    ToggleButton                                   = 2,
    RadioButton                                    = 3,
    Check                                          = 4,
    CollapsedButton                                = 5,
    EUserInterfaceActionType_MAX                   = 6

};


// Enum  /Script/ImageWriteQueue.EDesiredImageFormat
enum class EDesiredImageFormat : uint8_t
{
    PNG                                            = 0,
    JPG                                            = 1,
    BMP                                            = 2,
    EXR                                            = 3,
    EDesiredImageFormat_MAX                        = 4

};


// Enum  /Script/MaterialShaderQualitySettings.EMobileShadowQuality
enum class EMobileShadowQuality : uint8_t
{
    NoFiltering                                    = 0,
    PCF_1x1                                        = 1,
    PCF_2x2                                        = 2,
    PCF_3x3                                        = 3,
    EMobileShadowQuality_MAX                       = 4

};


// Enum  /Script/EngineSettings.ESubLevelStripMode
enum class ESubLevelStripMode : uint8_t
{
    ExactClass                                     = 0,
    IsChildOf                                      = 1,
    ESubLevelStripMode_MAX                         = 2

};


// Enum  /Script/EngineSettings.EFourPlayerSplitScreenType
enum class EFourPlayerSplitScreenType : uint8_t
{
    Grid                                           = 0,
    Vertical                                       = 1,
    Horizontal                                     = 2,
    EFourPlayerSplitScreenType_MAX                 = 3

};


// Enum  /Script/EngineSettings.EThreePlayerSplitScreenType
enum class EThreePlayerSplitScreenType : uint8_t
{
    FavorTop                                       = 0,
    FavorBottom                                    = 1,
    Vertical                                       = 2,
    Horizontal                                     = 3,
    EThreePlayerSplitScreenType_MAX                = 4

};


// Enum  /Script/EngineSettings.ETwoPlayerSplitScreenType
enum class ETwoPlayerSplitScreenType : uint8_t
{
    Horizontal                                     = 0,
    Vertical                                       = 1,
    ETwoPlayerSplitScreenType_MAX                  = 2

};


// Enum  /Script/Chaos.EClusterUnionMethod
enum class EClusterUnionMethod : uint8_t
{
    PointImplicit                                  = 0,
    DelaunayTriangulation                          = 1,
    MinimalSpanningSubsetDelaunayTriangulation     = 2,
    PointImplicitAugmentedWithMinimalDelaunay      = 3,
    None                                           = 4,
    EClusterUnionMethod_MAX                        = 5

};


// Enum  /Script/Chaos.EFieldPhysicsDefaultFields
enum class EFieldPhysicsDefaultFields : uint8_t
{
    Field_RadialIntMask                            = 0,
    Field_RadialFalloff                            = 1,
    Field_UniformVector                            = 2,
    Field_RadialVector                             = 3,
    Field_RadialVectorFalloff                      = 4,
    Field_EFieldPhysicsDefaultFields_Max           = 5,
    Field_MAX                                      = 6

};


// Enum  /Script/Chaos.EFieldPhysicsType
enum class EFieldPhysicsType : uint8_t
{
    Field_None                                     = 0,
    Field_DynamicState                             = 1,
    Field_LinearForce                              = 2,
    Field_ExternalClusterStrain                    = 3,
    Field_Kill                                     = 4,
    Field_LinearVelocity                           = 5,
    Field_AngularVelociy                           = 6,
    Field_AngularTorque                            = 7,
    Field_InternalClusterStrain                    = 8,
    Field_DisableThreshold                         = 9,
    Field_SleepingThreshold                        = 10,
    Field_PositionStatic                           = 11,
    Field_PositionAnimated                         = 12,
    Field_PositionTarget                           = 13,
    Field_DynamicConstraint                        = 14,
    Field_CollisionGroup                           = 15,
    Field_ActivateDisabled                         = 16,
    Field_PhysicsType_Max                          = 17

};


// Enum  /Script/Chaos.EFieldFalloffType
enum class EFieldFalloffType : uint8_t
{
    Field_FallOff_None                             = 0,
    Field_Falloff_Linear                           = 1,
    Field_Falloff_Inverse                          = 2,
    Field_Falloff_Squared                          = 3,
    Field_Falloff_Logarithmic                      = 4,
    Field_Falloff_Max                              = 5

};


// Enum  /Script/Chaos.EFieldResolutionType
enum class EFieldResolutionType : uint8_t
{
    Field_Resolution_Minimal                       = 0,
    Field_Resolution_DisabledParents               = 1,
    Field_Resolution_Maximum                       = 2,
    Field_Resolution_Max                           = 3

};


// Enum  /Script/Chaos.EFieldCullingOperationType
enum class EFieldCullingOperationType : uint8_t
{
    Field_Culling_Inside                           = 0,
    Field_Culling_Outside                          = 1,
    Field_Culling_Operation_Max                    = 2,
    Field_Culling_MAX                              = 3

};


// Enum  /Script/Chaos.EFieldOperationType
enum class EFieldOperationType : uint8_t
{
    Field_Multiply                                 = 0,
    Field_Divide                                   = 1,
    Field_Add                                      = 2,
    Field_Substract                                = 3,
    Field_Operation_Max                            = 4

};


// Enum  /Script/Chaos.ESetMaskConditionType
enum class ESetMaskConditionType : uint8_t
{
    Field_Set_Always                               = 0,
    Field_Set_IFF_NOT_Interior                     = 1,
    Field_Set_IFF_NOT_Exterior                     = 2,
    Field_MaskCondition_Max                        = 3

};


// Enum  /Script/Chaos.EEmissionPatternTypeEnum
enum class EEmissionPatternTypeEnum : uint8_t
{
    Chaos_Emission_Pattern_First_Frame             = 0,
    Chaos_Emission_Pattern_On_Demand               = 1,
    Chaos_Max                                      = 2

};


// Enum  /Script/Chaos.EInitialVelocityTypeEnum
enum class EInitialVelocityTypeEnum : uint8_t
{
    Chaos_Initial_Velocity_User_Defined            = 0,
    Chaos_Initial_Velocity_None                    = 1,
    Chaos_Max                                      = 2

};


// Enum  /Script/Chaos.EGeometryCollectionPhysicsTypeEnum
enum class EGeometryCollectionPhysicsTypeEnum : uint8_t
{
    Chaos_AngularVelocity                          = 0,
    Chaos_DynamicState                             = 1,
    Chaos_LinearVelocity                           = 2,
    Chaos_InitialAngularVelocity                   = 3,
    Chaos_InitialLinearVelocity                    = 4,
    Chaos_CollisionGroup                           = 5,
    Chaos_LinearForce                              = 6,
    Chaos_AngularTorque                            = 7,
    Chaos_Max                                      = 8

};


// Enum  /Script/Chaos.EObjectStateTypeEnum
enum class EObjectStateTypeEnum : uint8_t
{
    Chaos_NONE                                     = 0,
    Chaos_Object_Sleeping                          = 1,
    Chaos_Object_Kinematic                         = 2,
    Chaos_Object_Static                            = 3,
    Chaos_Object_Dynamic                           = 4,
    Chaos_Object_UserDefined                       = 100,
    Chaos_Max                                      = 101

};


// Enum  /Script/Chaos.EImplicitTypeEnum
enum class EImplicitTypeEnum : uint8_t
{
    Chaos_Implicit_Box                             = 0,
    Chaos_Implicit_Sphere                          = 1,
    Chaos_Implicit_Capsule                         = 2,
    Chaos_Implicit_LevelSet                        = 3,
    Chaos_Implicit_None                            = 4,
    Chaos_Max                                      = 5

};


// Enum  /Script/Chaos.ECollisionTypeEnum
enum class ECollisionTypeEnum : uint8_t
{
    Chaos_Volumetric                               = 0,
    Chaos_Surface_Volumetric                       = 1,
    Chaos_Max                                      = 2

};


// Enum  /Script/Chaos.EChaosBufferMode
enum class EChaosBufferMode : uint8_t
{
    Double                                         = 0,
    Triple                                         = 1,
    Num                                            = 2,
    Invalid                                        = 3,
    EChaosBufferMode_MAX                           = 4

};


// Enum  /Script/Chaos.EChaosThreadingMode
enum class EChaosThreadingMode : uint8_t
{
    DedicatedThread                                = 0,
    TaskGraph                                      = 1,
    SingleThread                                   = 2,
    Num                                            = 3,
    Invalid                                        = 4,
    EChaosThreadingMode_MAX                        = 5

};


// Enum  /Script/Chaos.EChaosSolverTickMode
enum class EChaosSolverTickMode : uint8_t
{
    Fixed                                          = 0,
    Variable                                       = 1,
    VariableCapped                                 = 2,
    VariableCappedWithTarget                       = 3,
    EChaosSolverTickMode_MAX                       = 4

};


// Enum  /Script/Chaos.EGeometryCollectionCacheType
enum class EGeometryCollectionCacheType : uint8_t
{
    None                                           = 0,
    Record                                         = 1,
    Play                                           = 2,
    RecordAndPlay                                  = 3,
    EGeometryCollectionCacheType_MAX               = 4

};


// Enum  /Script/PhysicsCore.EBodyCollisionResponse
enum class EBodyCollisionResponse : uint8_t
{
    BodyCollision_Enabled                          = 0,
    BodyCollision_Disabled                         = 1,
    BodyCollision_MAX                              = 2

};


// Enum  /Script/PhysicsCore.EPhysicsType
enum class EPhysicsType : uint8_t
{
    PhysType_Default                               = 0,
    PhysType_Kinematic                             = 1,
    PhysType_Simulated                             = 2,
    PhysType_MAX                                   = 3

};


// Enum  /Script/PhysicsCore.ECollisionTraceFlag
enum class ECollisionTraceFlag : uint8_t
{
    CTF_UseDefault                                 = 0,
    CTF_UseSimpleAndComplex                        = 1,
    CTF_UseSimpleAsComplex                         = 2,
    CTF_UseComplexAsSimple                         = 3,
    CTF_MAX                                        = 4

};


// Enum  /Script/PhysicsCore.ELinearConstraintMotion
enum class ELinearConstraintMotion : uint8_t
{
    LCM_Free                                       = 0,
    LCM_Limited                                    = 1,
    LCM_Locked                                     = 2,
    LCM_MAX                                        = 3

};


// Enum  /Script/PhysicsCore.EConstraintFrame
enum class EConstraintFrame : uint8_t
{
    Frame1                                         = 0,
    Frame2                                         = 1,
    EConstraintFrame_MAX                           = 2

};


// Enum  /Script/PhysicsCore.EAngularConstraintMotion
enum class EAngularConstraintMotion : uint8_t
{
    ACM_Free                                       = 0,
    ACM_Limited                                    = 1,
    ACM_Locked                                     = 2,
    ACM_MAX                                        = 3

};


// Enum  /Script/PhysicsCore.ESleepFamily
enum class ESleepFamily : uint8_t
{
    Normal                                         = 0,
    Sensitive                                      = 1,
    Custom                                         = 2,
    ESleepFamily_MAX                               = 3

};


// Enum  /Script/PhysicsCore.ERadialImpulseFalloff
enum class ERadialImpulseFalloff : uint8_t
{
    RIF_Constant                                   = 0,
    RIF_Linear                                     = 1,
    RIF_MAX                                        = 2

};


// Enum  /Script/PhysicsCore.EFrictionCombineMode
enum class EFrictionCombineMode : uint8_t
{
    Average                                        = 0,
    Min                                            = 1,
    Multiply                                       = 2,
    Max                                            = 3

};


// Enum  /Script/Engine.ERelativeTransformSpace
enum class ERelativeTransformSpace : uint8_t
{
    RTS_World                                      = 0,
    RTS_Actor                                      = 1,
    RTS_Component                                  = 2,
    RTS_ParentBoneSpace                            = 3,
    RTS_MAX                                        = 4

};


// Enum  /Script/Engine.EComponentMobility
enum class EComponentMobility : uint8_t
{
    Static                                         = 0,
    Stationary                                     = 1,
    Movable                                        = 2,
    EComponentMobility_MAX                         = 3

};


// Enum  /Script/Engine.EDetailMode
enum class EDetailMode : uint8_t
{
    DM_Low                                         = 0,
    DM_Medium                                      = 1,
    DM_High                                        = 2,
    DM_Epic                                        = 3,
    DM_MAX                                         = 4

};


// Enum  /Script/MRMesh.EMeshTrackerVertexColorMode
enum class EMeshTrackerVertexColorMode : uint8_t
{
    None                                           = 0,
    Confidence                                     = 1,
    Block                                          = 2,
    EMeshTrackerVertexColorMode_MAX                = 3

};


// Enum  /Script/AugmentedReality.EARTrackingState
enum class EARTrackingState : uint8_t
{
    Unknown                                        = 0,
    Tracking                                       = 1,
    NotTracking                                    = 2,
    StoppedTracking                                = 3,
    EARTrackingState_MAX                           = 4

};


// Enum  /Script/AugmentedReality.EGeoAnchorComponentDebugMode
enum class EGeoAnchorComponentDebugMode : uint8_t
{
    None                                           = 0,
    ShowGeoData                                    = 1,
    EGeoAnchorComponentDebugMode_MAX               = 2

};


// Enum  /Script/AugmentedReality.EPoseComponentDebugMode
enum class EPoseComponentDebugMode : uint8_t
{
    None                                           = 0,
    ShowSkeleton                                   = 1,
    EPoseComponentDebugMode_MAX                    = 2

};


// Enum  /Script/AugmentedReality.EQRCodeComponentDebugMode
enum class EQRCodeComponentDebugMode : uint8_t
{
    None                                           = 0,
    ShowQRCode                                     = 1,
    EQRCodeComponentDebugMode_MAX                  = 2

};


// Enum  /Script/AugmentedReality.EImageComponentDebugMode
enum class EImageComponentDebugMode : uint8_t
{
    None                                           = 0,
    ShowDetectedImage                              = 1,
    EImageComponentDebugMode_MAX                   = 2

};


// Enum  /Script/AugmentedReality.EARFaceTransformMixing
enum class EARFaceTransformMixing : uint8_t
{
    ComponentOnly                                  = 0,
    ComponentLocationTrackedRotation               = 1,
    ComponentWithTracked                           = 2,
    TrackingOnly                                   = 3,
    EARFaceTransformMixing_MAX                     = 4

};


// Enum  /Script/AugmentedReality.EFaceComponentDebugMode
enum class EFaceComponentDebugMode : uint8_t
{
    None                                           = 0,
    ShowEyeVectors                                 = 1,
    ShowFaceMesh                                   = 2,
    EFaceComponentDebugMode_MAX                    = 3

};


// Enum  /Script/AugmentedReality.EPlaneComponentDebugMode
enum class EPlaneComponentDebugMode : uint8_t
{
    None                                           = 0,
    ShowNetworkRole                                = 1,
    ShowClassification                             = 2,
    EPlaneComponentDebugMode_MAX                   = 3

};


// Enum  /Script/AugmentedReality.EARSessionConfigFlags
enum class EARSessionConfigFlags : uint8_t
{
    None                                           = 0,
    GenerateMeshData                               = 1,
    RenderMeshDataInWireframe                      = 2,
    GenerateCollisionForMeshData                   = 4,
    GenerateNavMeshForMeshData                     = 8,
    UseMeshDataForOcclusion                        = 16,
    EARSessionConfigFlags_MAX                      = 17

};


// Enum  /Script/AugmentedReality.EARServicePermissionRequestResult
enum class EARServicePermissionRequestResult : uint8_t
{
    Granted                                        = 0,
    Denied                                         = 1,
    EARServicePermissionRequestResult_MAX          = 2

};


// Enum  /Script/AugmentedReality.EARServiceInstallRequestResult
enum class EARServiceInstallRequestResult : uint8_t
{
    Installed                                      = 0,
    DeviceNotCompatible                            = 1,
    UserDeclinedInstallation                       = 2,
    FatalError                                     = 3,
    EARServiceInstallRequestResult_MAX             = 4

};


// Enum  /Script/AugmentedReality.EARServiceAvailability
enum class EARServiceAvailability : uint8_t
{
    UnknownError                                   = 0,
    UnknownChecking                                = 1,
    UnknownTimedOut                                = 2,
    UnsupportedDeviceNotCapable                    = 3,
    SupportedNotInstalled                          = 4,
    SupportedVersionTooOld                         = 5,
    SupportedInstalled                             = 6,
    EARServiceAvailability_MAX                     = 7

};


// Enum  /Script/AugmentedReality.EARGeoTrackingAccuracy
enum class EARGeoTrackingAccuracy : uint8_t
{
    Undetermined                                   = 0,
    Low                                            = 1,
    Medium                                         = 2,
    High                                           = 3,
    EARGeoTrackingAccuracy_MAX                     = 4

};


// Enum  /Script/AugmentedReality.EARGeoTrackingStateReason
enum class EARGeoTrackingStateReason : uint8_t
{
    None                                           = 0,
    NotAvailableAtLocation                         = 1,
    NeedLocationPermissions                        = 2,
    DevicePointedTooLow                            = 3,
    WorldTrackingUnstable                          = 4,
    WaitingForLocation                             = 5,
    GeoDataNotLoaded                               = 6,
    VisualLocalizationFailed                       = 7,
    WaitingForAvailabilityCheck                    = 8,
    EARGeoTrackingStateReason_MAX                  = 9

};


// Enum  /Script/AugmentedReality.EARGeoTrackingState
enum class EARGeoTrackingState : uint8_t
{
    Initializing                                   = 0,
    Localized                                      = 1,
    Localizing                                     = 2,
    NotAvailable                                   = 3,
    EARGeoTrackingState_MAX                        = 4

};


// Enum  /Script/AugmentedReality.EARSceneReconstruction
enum class EARSceneReconstruction : uint8_t
{
    None                                           = 0,
    MeshOnly                                       = 1,
    MeshWithClassification                         = 2,
    EARSceneReconstruction_MAX                     = 3

};


// Enum  /Script/AugmentedReality.EARSessionTrackingFeature
enum class EARSessionTrackingFeature : uint8_t
{
    None                                           = 0,
    PoseDetection2D                                = 1,
    PersonSegmentation                             = 2,
    PersonSegmentationWithDepth                    = 3,
    SceneDepth                                     = 4,
    SmoothedSceneDepth                             = 5,
    EARSessionTrackingFeature_MAX                  = 6

};


// Enum  /Script/AugmentedReality.EARFaceTrackingUpdate
enum class EARFaceTrackingUpdate : uint8_t
{
    CurvesAndGeo                                   = 0,
    CurvesOnly                                     = 1,
    EARFaceTrackingUpdate_MAX                      = 2

};


// Enum  /Script/AugmentedReality.EAREnvironmentCaptureProbeType
enum class EAREnvironmentCaptureProbeType : uint8_t
{
    None                                           = 0,
    Manual                                         = 1,
    Automatic                                      = 2,
    EAREnvironmentCaptureProbeType_MAX             = 3

};


// Enum  /Script/AugmentedReality.EARFrameSyncMode
enum class EARFrameSyncMode : uint8_t
{
    SyncTickWithCameraImage                        = 0,
    SyncTickWithoutCameraImage                     = 1,
    EARFrameSyncMode_MAX                           = 2

};


// Enum  /Script/AugmentedReality.EARLightEstimationMode
enum class EARLightEstimationMode : uint8_t
{
    None                                           = 0,
    AmbientLightEstimate                           = 1,
    DirectionalLightEstimate                       = 2,
    EARLightEstimationMode_MAX                     = 3

};


// Enum  /Script/AugmentedReality.EARPlaneDetectionMode
enum class EARPlaneDetectionMode : uint8_t
{
    None                                           = 0,
    HorizontalPlaneDetection                       = 1,
    VerticalPlaneDetection                         = 2,
    EARPlaneDetectionMode_MAX                      = 3

};


// Enum  /Script/AugmentedReality.EARSessionType
enum class EARSessionType : uint8_t
{
    None                                           = 0,
    Orientation                                    = 1,
    World                                          = 2,
    Face                                           = 3,
    Image                                          = 4,
    ObjectScanning                                 = 5,
    PoseTracking                                   = 6,
    GeoTracking                                    = 7,
    EARSessionType_MAX                             = 8

};


// Enum  /Script/AugmentedReality.EARWorldAlignment
enum class EARWorldAlignment : uint8_t
{
    Gravity                                        = 0,
    GravityAndHeading                              = 1,
    Camera                                         = 2,
    EARWorldAlignment_MAX                          = 3

};


// Enum  /Script/AugmentedReality.EARDepthAccuracy
enum class EARDepthAccuracy : uint8_t
{
    Unkown                                         = 0,
    Approximate                                    = 1,
    Accurate                                       = 2,
    EARDepthAccuracy_MAX                           = 3

};


// Enum  /Script/AugmentedReality.EARDepthQuality
enum class EARDepthQuality : uint8_t
{
    Unkown                                         = 0,
    Low                                            = 1,
    High                                           = 2,
    EARDepthQuality_MAX                            = 3

};


// Enum  /Script/AugmentedReality.EARTextureType
enum class EARTextureType : uint8_t
{
    Unknown                                        = 0,
    CameraImage                                    = 1,
    CameraDepth                                    = 2,
    EnvironmentCapture                             = 3,
    PersonSegmentationImage                        = 4,
    PersonSegmentationDepth                        = 5,
    SceneDepthMap                                  = 6,
    SceneDepthConfidenceMap                        = 7,
    EARTextureType_MAX                             = 8

};


// Enum  /Script/AugmentedReality.EAREye
enum class EAREye : uint8_t
{
    LeftEye                                        = 0,
    RightEye                                       = 1,
    EAREye_MAX                                     = 2

};


// Enum  /Script/AugmentedReality.EARFaceBlendShape
enum class EARFaceBlendShape : uint8_t
{
    EyeBlinkLeft                                   = 0,
    EyeLookDownLeft                                = 1,
    EyeLookInLeft                                  = 2,
    EyeLookOutLeft                                 = 3,
    EyeLookUpLeft                                  = 4,
    EyeSquintLeft                                  = 5,
    EyeWideLeft                                    = 6,
    EyeBlinkRight                                  = 7,
    EyeLookDownRight                               = 8,
    EyeLookInRight                                 = 9,
    EyeLookOutRight                                = 10,
    EyeLookUpRight                                 = 11,
    EyeSquintRight                                 = 12,
    EyeWideRight                                   = 13,
    JawForward                                     = 14,
    JawLeft                                        = 15,
    JawRight                                       = 16,
    JawOpen                                        = 17,
    MouthClose                                     = 18,
    MouthFunnel                                    = 19,
    MouthPucker                                    = 20,
    MouthLeft                                      = 21,
    MouthRight                                     = 22,
    MouthSmileLeft                                 = 23,
    MouthSmileRight                                = 24,
    MouthFrownLeft                                 = 25,
    MouthFrownRight                                = 26,
    MouthDimpleLeft                                = 27,
    MouthDimpleRight                               = 28,
    MouthStretchLeft                               = 29,
    MouthStretchRight                              = 30,
    MouthRollLower                                 = 31,
    MouthRollUpper                                 = 32,
    MouthShrugLower                                = 33,
    MouthShrugUpper                                = 34,
    MouthPressLeft                                 = 35,
    MouthPressRight                                = 36,
    MouthLowerDownLeft                             = 37,
    MouthLowerDownRight                            = 38,
    MouthUpperUpLeft                               = 39,
    MouthUpperUpRight                              = 40,
    BrowDownLeft                                   = 41,
    BrowDownRight                                  = 42,
    BrowInnerUp                                    = 43,
    BrowOuterUpLeft                                = 44,
    BrowOuterUpRight                               = 45,
    CheekPuff                                      = 46,
    CheekSquintLeft                                = 47,
    CheekSquintRight                               = 48,
    NoseSneerLeft                                  = 49,
    NoseSneerRight                                 = 50,
    TongueOut                                      = 51,
    HeadYaw                                        = 52,
    HeadPitch                                      = 53,
    HeadRoll                                       = 54,
    LeftEyeYaw                                     = 55,
    LeftEyePitch                                   = 56,
    LeftEyeRoll                                    = 57,
    RightEyeYaw                                    = 58,
    RightEyePitch                                  = 59,
    RightEyeRoll                                   = 60,
    MAX                                            = 61

};


// Enum  /Script/AugmentedReality.EARFaceTrackingDirection
enum class EARFaceTrackingDirection : uint8_t
{
    FaceRelative                                   = 0,
    FaceMirrored                                   = 1,
    EARFaceTrackingDirection_MAX                   = 2

};


// Enum  /Script/AugmentedReality.EARCandidateImageOrientation
enum class EARCandidateImageOrientation : uint8_t
{
    Landscape                                      = 0,
    Portrait                                       = 1,
    EARCandidateImageOrientation_MAX               = 2

};


// Enum  /Script/AugmentedReality.EARAltitudeSource
enum class EARAltitudeSource : uint8_t
{
    Precise                                        = 0,
    Coarse                                         = 1,
    UserDefined                                    = 2,
    Unknown                                        = 3,
    EARAltitudeSource_MAX                          = 4

};


// Enum  /Script/AugmentedReality.EARJointTransformSpace
enum class EARJointTransformSpace : uint8_t
{
    Model                                          = 0,
    ParentJoint                                    = 1,
    EARJointTransformSpace_MAX                     = 2

};


// Enum  /Script/AugmentedReality.EARObjectClassification
enum class EARObjectClassification : uint8_t
{
    NotApplicable                                  = 0,
    Unknown                                        = 1,
    Wall                                           = 2,
    Ceiling                                        = 3,
    Floor                                          = 4,
    Table                                          = 5,
    Seat                                           = 6,
    Face                                           = 7,
    Image                                          = 8,
    World                                          = 9,
    SceneObject                                    = 10,
    HandMesh                                       = 11,
    Door                                           = 12,
    Window                                         = 13,
    EARObjectClassification_MAX                    = 14

};


// Enum  /Script/AugmentedReality.EARPlaneOrientation
enum class EARPlaneOrientation : uint8_t
{
    Horizontal                                     = 0,
    Vertical                                       = 1,
    Diagonal                                       = 2,
    EARPlaneOrientation_MAX                        = 3

};


// Enum  /Script/AugmentedReality.EARWorldMappingState
enum class EARWorldMappingState : uint8_t
{
    NotAvailable                                   = 0,
    StillMappingNotRelocalizable                   = 1,
    StillMappingRelocalizable                      = 2,
    Mapped                                         = 3,
    EARWorldMappingState_MAX                       = 4

};


// Enum  /Script/AugmentedReality.EARSessionStatus
enum class EARSessionStatus : uint8_t
{
    NotStarted                                     = 0,
    Running                                        = 1,
    NotSupported                                   = 2,
    FatalError                                     = 3,
    PermissionNotGranted                           = 4,
    UnsupportedConfiguration                       = 5,
    Other                                          = 6,
    EARSessionStatus_MAX                           = 7

};


// Enum  /Script/AugmentedReality.EARTrackingQualityReason
enum class EARTrackingQualityReason : uint8_t
{
    None                                           = 0,
    Initializing                                   = 1,
    Relocalizing                                   = 2,
    ExcessiveMotion                                = 3,
    InsufficientFeatures                           = 4,
    InsufficientLight                              = 5,
    BadState                                       = 6,
    EARTrackingQualityReason_MAX                   = 7

};


// Enum  /Script/AugmentedReality.EARTrackingQuality
enum class EARTrackingQuality : uint8_t
{
    NotTracking                                    = 0,
    OrientationOnly                                = 1,
    OrientationAndPosition                         = 2,
    EARTrackingQuality_MAX                         = 3

};


// Enum  /Script/AugmentedReality.EARLineTraceChannels
enum class EARLineTraceChannels : uint8_t
{
    None                                           = 0,
    FeaturePoint                                   = 1,
    GroundPlane                                    = 2,
    PlaneUsingExtent                               = 4,
    PlaneUsingBoundaryPolygon                      = 8,
    EARLineTraceChannels_MAX                       = 9

};


// Enum  /Script/AugmentedReality.EARCaptureType
enum class EARCaptureType : uint8_t
{
    Camera                                         = 0,
    QRCode                                         = 1,
    SpatialMapping                                 = 2,
    SceneUnderstanding                             = 3,
    EARCaptureType_MAX                             = 4

};


// Enum  /Script/HeadMountedDisplay.EXRVisualType
enum class EXRVisualType : uint8_t
{
    Controller                                     = 0,
    Hand                                           = 1,
    EXRVisualType_MAX                              = 2

};


// Enum  /Script/HeadMountedDisplay.EHandKeypoint
enum class EHandKeypoint : uint8_t
{
    Palm                                           = 0,
    Wrist                                          = 1,
    ThumbMetacarpal                                = 2,
    ThumbProximal                                  = 3,
    ThumbDistal                                    = 4,
    ThumbTip                                       = 5,
    IndexMetacarpal                                = 6,
    IndexProximal                                  = 7,
    IndexIntermediate                              = 8,
    IndexDistal                                    = 9,
    IndexTip                                       = 10,
    MiddleMetacarpal                               = 11,
    MiddleProximal                                 = 12,
    MiddleIntermediate                             = 13,
    MiddleDistal                                   = 14,
    MiddleTip                                      = 15,
    RingMetacarpal                                 = 16,
    RingProximal                                   = 17,
    RingIntermediate                               = 18,
    RingDistal                                     = 19,
    RingTip                                        = 20,
    LittleMetacarpal                               = 21,
    LittleProximal                                 = 22,
    LittleIntermediate                             = 23,
    LittleDistal                                   = 24,
    LittleTip                                      = 25,
    EHandKeypoint_MAX                              = 26

};


// Enum  /Script/HeadMountedDisplay.EXRTrackedDeviceType
enum class EXRTrackedDeviceType : uint8_t
{
    HeadMountedDisplay                             = 0,
    Controller                                     = 1,
    TrackingReference                              = 2,
    Other                                          = 3,
    Invalid                                        = 254,
    Any                                            = 255,
    EXRTrackedDeviceType_MAX                       = 256

};


// Enum  /Script/HeadMountedDisplay.ESpectatorScreenMode
enum class ESpectatorScreenMode : uint8_t
{
    Disabled                                       = 0,
    SingleEyeLetterboxed                           = 1,
    Undistorted                                    = 2,
    Distorted                                      = 3,
    SingleEye                                      = 4,
    SingleEyeCroppedToFill                         = 5,
    Texture                                        = 6,
    TexturePlusEye                                 = 7,
    ESpectatorScreenMode_MAX                       = 8

};


// Enum  /Script/HeadMountedDisplay.EXRSystemFlags
enum class EXRSystemFlags : uint8_t
{
    NoFlags                                        = 0,
    IsAR                                           = 1,
    IsTablet                                       = 2,
    IsHeadMounted                                  = 4,
    SupportsHandTracking                           = 8,
    EXRSystemFlags_MAX                             = 9

};


// Enum  /Script/HeadMountedDisplay.EXRDeviceConnectionResult
enum class EXRDeviceConnectionResult : uint8_t
{
    NoTrackingSystem                               = 0,
    FeatureNotSupported                            = 1,
    NoValidViewport                                = 2,
    MiscFailure                                    = 3,
    Success                                        = 4,
    EXRDeviceConnectionResult_MAX                  = 5

};


// Enum  /Script/HeadMountedDisplay.EHMDWornState
enum class EHMDWornState : uint8_t
{
    Unknown                                        = 0,
    Worn                                           = 1,
    NotWorn                                        = 2,
    EHMDWornState_MAX                              = 3

};


// Enum  /Script/HeadMountedDisplay.EHMDTrackingOrigin
enum class EHMDTrackingOrigin : uint8_t
{
    Floor                                          = 0,
    Eye                                            = 1,
    Stage                                          = 2,
    Unbounded                                      = 3,
    EHMDTrackingOrigin_MAX                         = 4

};


// Enum  /Script/HeadMountedDisplay.EOrientPositionSelector
enum class EOrientPositionSelector : uint8_t
{
    Orientation                                    = 0,
    Position                                       = 1,
    OrientationAndPosition                         = 2,
    EOrientPositionSelector_MAX                    = 3

};


// Enum  /Script/HeadMountedDisplay.ETrackingStatus
enum class ETrackingStatus : uint8_t
{
    NotTracked                                     = 0,
    InertialOnly                                   = 1,
    Tracked                                        = 2,
    ETrackingStatus_MAX                            = 3

};


// Enum  /Script/HeadMountedDisplay.ESpatialInputGestureAxis
enum class ESpatialInputGestureAxis : uint8_t
{
    None                                           = 0,
    Manipulation                                   = 1,
    Navigation                                     = 2,
    NavigationRails                                = 3,
    ESpatialInputGestureAxis_MAX                   = 4

};


// Enum  /Script/Foliage.EFoliageScaling
enum class EFoliageScaling : uint8_t
{
    Uniform                                        = 0,
    Free                                           = 1,
    LockXY                                         = 2,
    LockXZ                                         = 3,
    LockYZ                                         = 4,
    EFoliageScaling_MAX                            = 5

};


// Enum  /Script/Foliage.EVertexColorMaskChannel
enum class EVertexColorMaskChannel : uint8_t
{
    Red                                            = 0,
    Green                                          = 1,
    Blue                                           = 2,
    Alpha                                          = 3,
    MAX_None                                       = 4,
    EVertexColorMaskChannel_MAX                    = 5

};


// Enum  /Script/Foliage.FoliageVertexColorMask
enum class FoliageVertexColorMask : uint8_t
{
    FOLIAGEVERTEXCOLORMASK_Disabled                = 0,
    FOLIAGEVERTEXCOLORMASK_Red                     = 1,
    FOLIAGEVERTEXCOLORMASK_Green                   = 2,
    FOLIAGEVERTEXCOLORMASK_Blue                    = 3,
    FOLIAGEVERTEXCOLORMASK_Alpha                   = 4,
    FOLIAGEVERTEXCOLORMASK_MAX                     = 5

};


// Enum  /Script/Foliage.ESimulationQuery
enum class ESimulationQuery : uint8_t
{
    None                                           = 0,
    CollisionOverlap                               = 1,
    ShadeOverlap                                   = 2,
    AnyOverlap                                     = 3,
    ESimulationQuery_MAX                           = 4

};


// Enum  /Script/Foliage.ESimulationOverlap
enum class ESimulationOverlap : uint8_t
{
    CollisionOverlap                               = 0,
    ShadeOverlap                                   = 1,
    None                                           = 2,
    ESimulationOverlap_MAX                         = 3

};


// Enum  /Script/Landscape.ELandscapeBlendMode
enum class ELandscapeBlendMode : uint8_t
{
    LSBM_AdditiveBlend                             = 0,
    LSBM_AlphaBlend                                = 1,
    LSBM_MAX                                       = 2

};


// Enum  /Script/Landscape.ELandscapeSetupErrors
enum class ELandscapeSetupErrors : uint8_t
{
    LSE_None                                       = 0,
    LSE_NoLandscapeInfo                            = 1,
    LSE_CollsionXY                                 = 2,
    LSE_NoLayerInfo                                = 3,
    LSE_MAX                                        = 4

};


// Enum  /Script/Landscape.ELandscapeClearMode
enum class ELandscapeClearMode : uint8_t
{
    Clear_Weightmap                                = 1,
    Clear_Heightmap                                = 2,
    Clear_All                                      = 3,
    Clear_MAX                                      = 4

};


// Enum  /Script/Landscape.ELandscapeGizmoType
enum class ELandscapeGizmoType : uint8_t
{
    LGT_None                                       = 0,
    LGT_Height                                     = 1,
    LGT_Weight                                     = 2,
    LGT_MAX                                        = 3

};


// Enum  /Script/Landscape.EGrassScaling
enum class EGrassScaling : uint8_t
{
    Uniform                                        = 0,
    Free                                           = 1,
    LockXY                                         = 2,
    EGrassScaling_MAX                              = 3

};


// Enum  /Script/Landscape.ESplineModulationColorMask
enum class ESplineModulationColorMask : uint8_t
{
    Red                                            = 0,
    Green                                          = 1,
    Blue                                           = 2,
    Alpha                                          = 3,
    ESplineModulationColorMask_MAX                 = 4

};


// Enum  /Script/Landscape.ELandscapeLODFalloff
enum class ELandscapeLODFalloff : uint8_t
{
    Linear                                         = 0,
    SquareRoot                                     = 1,
    ELandscapeLODFalloff_MAX                       = 2

};


// Enum  /Script/Landscape.ELandscapeLayerDisplayMode
enum class ELandscapeLayerDisplayMode : uint8_t
{
    Default                                        = 0,
    Alphabetical                                   = 1,
    UserSpecific                                   = 2,
    ELandscapeLayerDisplayMode_MAX                 = 3

};


// Enum  /Script/Landscape.ELandscapeLayerPaintingRestriction
enum class ELandscapeLayerPaintingRestriction : uint8_t
{
    None                                           = 0,
    UseMaxLayers                                   = 1,
    ExistingOnly                                   = 2,
    UseComponentWhitelist                          = 3,
    ELandscapeLayerPaintingRestriction_MAX         = 4

};


// Enum  /Script/Landscape.ELandscapeImportAlphamapType
enum class ELandscapeImportAlphamapType : uint8_t
{
    Additive                                       = 0,
    Layered                                        = 1,
    ELandscapeImportAlphamapType_MAX               = 2

};


// Enum  /Script/Landscape.LandscapeSplineMeshOrientation
enum class LandscapeSplineMeshOrientation : uint8_t
{
    LSMO_XUp                                       = 0,
    LSMO_YUp                                       = 1,
    LSMO_MAX                                       = 2

};


// Enum  /Script/Landscape.ELandscapeLayerBlendType
enum class ELandscapeLayerBlendType : uint8_t
{
    LB_WeightBlend                                 = 0,
    LB_AlphaBlend                                  = 1,
    LB_HeightBlend                                 = 2,
    LB_MAX                                         = 3

};


// Enum  /Script/Landscape.ELandscapeCustomizedCoordType
enum class ELandscapeCustomizedCoordType : uint8_t
{
    LCCT_None                                      = 0,
    LCCT_CustomUV0                                 = 1,
    LCCT_CustomUV1                                 = 2,
    LCCT_CustomUV2                                 = 3,
    LCCT_WeightMapUV                               = 4,
    LCCT_MAX                                       = 5

};


// Enum  /Script/Landscape.ETerrainCoordMappingType
enum class ETerrainCoordMappingType : uint8_t
{
    TCMT_Auto                                      = 0,
    TCMT_XY                                        = 1,
    TCMT_XZ                                        = 2,
    TCMT_YZ                                        = 3,
    TCMT_MAX                                       = 4

};


// Enum  /Script/TimeManagement.EFrameNumberDisplayFormats
enum class EFrameNumberDisplayFormats : uint8_t
{
    NonDropFrameTimecode                           = 0,
    DropFrameTimecode                              = 1,
    Seconds                                        = 2,
    Frames                                         = 3,
    MAX_Count                                      = 4,
    EFrameNumberDisplayFormats_MAX                 = 5

};


// Enum  /Script/TimeManagement.ETimedDataInputState
enum class ETimedDataInputState : uint8_t
{
    Connected                                      = 0,
    Unresponsive                                   = 1,
    Disconnected                                   = 2,
    ETimedDataInputState_MAX                       = 3

};


// Enum  /Script/TimeManagement.ETimedDataInputEvaluationType
enum class ETimedDataInputEvaluationType : uint8_t
{
    None                                           = 0,
    Timecode                                       = 1,
    PlatformTime                                   = 2,
    ETimedDataInputEvaluationType_MAX              = 3

};


// Enum  /Script/MovieScene.EMovieSceneKeyInterpolation
enum class EMovieSceneKeyInterpolation : uint8_t
{
    Auto                                           = 0,
    User                                           = 1,
    Break                                          = 2,
    Linear                                         = 3,
    Constant                                       = 4,
    EMovieSceneKeyInterpolation_MAX                = 5

};


// Enum  /Script/MovieScene.EMovieSceneBlendType
enum class EMovieSceneBlendType : uint8_t
{
    Invalid                                        = 0,
    Absolute                                       = 1,
    Additive                                       = 2,
    Relative                                       = 4,
    AdditiveFromBase                               = 8,
    EMovieSceneBlendType_MAX                       = 9

};


// Enum  /Script/MovieScene.EMovieSceneCompletionMode
enum class EMovieSceneCompletionMode : uint8_t
{
    KeepState                                      = 0,
    RestoreState                                   = 1,
    ProjectDefault                                 = 2,
    EMovieSceneCompletionMode_MAX                  = 3

};


// Enum  /Script/MovieScene.EMovieSceneBuiltInEasing
enum class EMovieSceneBuiltInEasing : uint8_t
{
    Linear                                         = 0,
    SinIn                                          = 1,
    SinOut                                         = 2,
    SinInOut                                       = 3,
    QuadIn                                         = 4,
    QuadOut                                        = 5,
    QuadInOut                                      = 6,
    CubicIn                                        = 7,
    CubicOut                                       = 8,
    CubicInOut                                     = 9,
    QuartIn                                        = 10,
    QuartOut                                       = 11,
    QuartInOut                                     = 12,
    QuintIn                                        = 13,
    QuintOut                                       = 14,
    QuintInOut                                     = 15,
    ExpoIn                                         = 16,
    ExpoOut                                        = 17,
    ExpoInOut                                      = 18,
    CircIn                                         = 19,
    CircOut                                        = 20,
    CircInOut                                      = 21,
    EMovieSceneBuiltInEasing_MAX                   = 22

};


// Enum  /Script/MovieScene.EEvaluationMethod
enum class EEvaluationMethod : uint8_t
{
    Static                                         = 0,
    Swept                                          = 1,
    EEvaluationMethod_MAX                          = 2

};


// Enum  /Script/MovieScene.EMovieSceneSequenceFlags
enum class EMovieSceneSequenceFlags : uint8_t
{
    None                                           = 0,
    Volatile                                       = 1,
    BlockingEvaluation                             = 2,
    InheritedFlags                                 = 1,
    EMovieSceneSequenceFlags_MAX                   = 3

};


// Enum  /Script/MovieScene.EUpdateClockSource
enum class EUpdateClockSource : uint8_t
{
    Tick                                           = 0,
    Platform                                       = 1,
    Audio                                          = 2,
    RelativeTimecode                               = 3,
    Timecode                                       = 4,
    Custom                                         = 5,
    EUpdateClockSource_MAX                         = 6

};


// Enum  /Script/MovieScene.EMovieSceneEvaluationType
enum class EMovieSceneEvaluationType : uint8_t
{
    FrameLocked                                    = 0,
    WithSubFrames                                  = 1,
    EMovieSceneEvaluationType_MAX                  = 2

};


// Enum  /Script/MovieScene.EMovieScenePlayerStatus
enum class EMovieScenePlayerStatus : uint8_t
{
    Stopped                                        = 0,
    Playing                                        = 1,
    Recording                                      = 2,
    Scrubbing                                      = 3,
    Jumping                                        = 4,
    Stepping                                       = 5,
    Paused                                         = 6,
    MAX                                            = 7

};


// Enum  /Script/MovieScene.EMovieSceneObjectBindingSpace
enum class EMovieSceneObjectBindingSpace : uint8_t
{
    Local                                          = 0,
    Root                                           = 1,
    EMovieSceneObjectBindingSpace_MAX              = 2

};


// Enum  /Script/MovieScene.ESectionEvaluationFlags
enum class ESectionEvaluationFlags : uint8_t
{
    None                                           = 0,
    PreRoll                                        = 1,
    PostRoll                                       = 2,
    ESectionEvaluationFlags_MAX                    = 3

};


// Enum  /Script/MovieScene.EMovieScenePositionType
enum class EMovieScenePositionType : uint8_t
{
    Frame                                          = 0,
    Time                                           = 1,
    MarkedFrame                                    = 2,
    EMovieScenePositionType_MAX                    = 3

};


// Enum  /Script/MovieScene.EUpdatePositionMethod
enum class EUpdatePositionMethod : uint8_t
{
    Play                                           = 0,
    Jump                                           = 1,
    Scrub                                          = 2,
    EUpdatePositionMethod_MAX                      = 3

};


// Enum  /Script/MovieScene.ESpawnOwnership
enum class ESpawnOwnership : uint8_t
{
    InnerSequence                                  = 0,
    MasterSequence                                 = 1,
    External                                       = 2,
    ESpawnOwnership_MAX                            = 3

};


// Enum  /Script/AnimationCore.ETransformConstraintType
enum class ETransformConstraintType : uint8_t
{
    Translation                                    = 0,
    Rotation                                       = 1,
    Scale                                          = 2,
    Parent                                         = 3,
    ETransformConstraintType_MAX                   = 4

};


// Enum  /Script/AnimationCore.EConstraintType
enum class EConstraintType : uint8_t
{
    Transform                                      = 0,
    Aim                                            = 1,
    MAX                                            = 2

};


// Enum  /Script/AnimGraphRuntime.ESphericalLimitType
enum class ESphericalLimitType : uint8_t
{
    Inner                                          = 0,
    Outer                                          = 1,
    ESphericalLimitType_MAX                        = 2

};


// Enum  /Script/AnimGraphRuntime.AnimPhysSimSpaceType
enum class AnimPhysSimSpaceType : uint8_t
{
    Component                                      = 0,
    Actor                                          = 1,
    World                                          = 2,
    RootRelative                                   = 3,
    BoneRelative                                   = 4,
    AnimPhysSimSpaceType_MAX                       = 5

};


// Enum  /Script/AnimGraphRuntime.AnimPhysLinearConstraintType
enum class AnimPhysLinearConstraintType : uint8_t
{
    Free                                           = 0,
    Limited                                        = 1,
    AnimPhysLinearConstraintType_MAX               = 2

};


// Enum  /Script/AnimGraphRuntime.AnimPhysAngularConstraintType
enum class AnimPhysAngularConstraintType : uint8_t
{
    Angular                                        = 0,
    Cone                                           = 1,
    AnimPhysAngularConstraintType_MAX              = 2

};


// Enum  /Script/AnimGraphRuntime.EBlendListTransitionType
enum class EBlendListTransitionType : uint8_t
{
    StandardBlend                                  = 0,
    Inertialization                                = 1,
    EBlendListTransitionType_MAX                   = 2

};


// Enum  /Script/AnimGraphRuntime.EDrivenDestinationMode
enum class EDrivenDestinationMode : uint8_t
{
    Bone                                           = 0,
    MorphTarget                                    = 1,
    MaterialParameter                              = 2,
    EDrivenDestinationMode_MAX                     = 3

};


// Enum  /Script/AnimGraphRuntime.EDrivenBoneModificationMode
enum class EDrivenBoneModificationMode : uint8_t
{
    AddToInput                                     = 0,
    ReplaceComponent                               = 1,
    AddToRefPose                                   = 2,
    EDrivenBoneModificationMode_MAX                = 3

};


// Enum  /Script/AnimGraphRuntime.EConstraintOffsetOption
enum class EConstraintOffsetOption : uint8_t
{
    None                                           = 0,
    Offset_RefPose                                 = 1,
    EConstraintOffsetOption_MAX                    = 2

};


// Enum  /Script/AnimGraphRuntime.CopyBoneDeltaMode
enum class CopyBoneDeltaMode : uint8_t
{
    Accumulate                                     = 0,
    Copy                                           = 1,
    CopyBoneDeltaMode_MAX                          = 2

};


// Enum  /Script/AnimGraphRuntime.EInterpolationBlend
enum class EInterpolationBlend : uint8_t
{
    Linear                                         = 0,
    Cubic                                          = 1,
    Sinusoidal                                     = 2,
    EaseInOutExponent2                             = 3,
    EaseInOutExponent3                             = 4,
    EaseInOutExponent4                             = 5,
    EaseInOutExponent5                             = 6,
    MAX                                            = 7

};


// Enum  /Script/AnimGraphRuntime.EBoneModificationMode
enum class EBoneModificationMode : uint8_t
{
    BMM_Ignore                                     = 0,
    BMM_Replace                                    = 1,
    BMM_Additive                                   = 2,
    BMM_MAX                                        = 3

};


// Enum  /Script/AnimGraphRuntime.EModifyCurveApplyMode
enum class EModifyCurveApplyMode : uint8_t
{
    Add                                            = 0,
    Scale                                          = 1,
    Blend                                          = 2,
    WeightedMovingAverage                          = 3,
    RemapCurve                                     = 4,
    EModifyCurveApplyMode_MAX                      = 5

};


// Enum  /Script/AnimGraphRuntime.EPoseDriverOutput
enum class EPoseDriverOutput : uint8_t
{
    DrivePoses                                     = 0,
    DriveCurves                                    = 1,
    EPoseDriverOutput_MAX                          = 2

};


// Enum  /Script/AnimGraphRuntime.EPoseDriverSource
enum class EPoseDriverSource : uint8_t
{
    Rotation                                       = 0,
    Translation                                    = 1,
    EPoseDriverSource_MAX                          = 2

};


// Enum  /Script/AnimGraphRuntime.EPoseDriverType
enum class EPoseDriverType : uint8_t
{
    SwingAndTwist                                  = 0,
    SwingOnly                                      = 1,
    Translation                                    = 2,
    EPoseDriverType_MAX                            = 3

};


// Enum  /Script/AnimGraphRuntime.ESnapshotSourceMode
enum class ESnapshotSourceMode : uint8_t
{
    NamedSnapshot                                  = 0,
    SnapshotPin                                    = 1,
    ESnapshotSourceMode_MAX                        = 2

};


// Enum  /Script/AnimGraphRuntime.ERefPoseType
enum class ERefPoseType : uint8_t
{
    EIT_LocalSpace                                 = 0,
    EIT_Additive                                   = 1,
    EIT_MAX                                        = 2

};


// Enum  /Script/AnimGraphRuntime.ESimulationSpace
enum class ESimulationSpace : uint8_t
{
    ComponentSpace                                 = 0,
    WorldSpace                                     = 1,
    BaseBoneSpace                                  = 2,
    ESimulationSpace_MAX                           = 3

};


// Enum  /Script/AnimGraphRuntime.EScaleChainInitialLength
enum class EScaleChainInitialLength : uint8_t
{
    FixedDefaultLengthValue                        = 0,
    Distance                                       = 1,
    ChainLength                                    = 2,
    EScaleChainInitialLength_MAX                   = 3

};


// Enum  /Script/AnimGraphRuntime.ESequenceEvalReinit
enum class ESequenceEvalReinit : uint8_t
{
    NoReset                                        = 0,
    StartPosition                                  = 1,
    ExplicitTime                                   = 2,
    ESequenceEvalReinit_MAX                        = 3

};


// Enum  /Script/AnimGraphRuntime.ESplineBoneAxis
enum class ESplineBoneAxis : uint8_t
{
    None                                           = 0,
    X                                              = 1,
    Y                                              = 2,
    Z                                              = 3,
    ESplineBoneAxis_MAX                            = 4

};


// Enum  /Script/AnimGraphRuntime.ERotationComponent
enum class ERotationComponent : uint8_t
{
    EulerX                                         = 0,
    EulerY                                         = 1,
    EulerZ                                         = 2,
    QuaternionAngle                                = 3,
    SwingAngle                                     = 4,
    TwistAngle                                     = 5,
    ERotationComponent_MAX                         = 6

};


// Enum  /Script/AnimGraphRuntime.EEasingFuncType
enum class EEasingFuncType : uint8_t
{
    Linear                                         = 0,
    Sinusoidal                                     = 1,
    Cubic                                          = 2,
    QuadraticInOut                                 = 3,
    CubicInOut                                     = 4,
    HermiteCubic                                   = 5,
    QuarticInOut                                   = 6,
    QuinticInOut                                   = 7,
    CircularIn                                     = 8,
    CircularOut                                    = 9,
    CircularInOut                                  = 10,
    ExpIn                                          = 11,
    ExpOut                                         = 12,
    ExpInOut                                       = 13,
    CustomCurve                                    = 14,
    EEasingFuncType_MAX                            = 15

};


// Enum  /Script/AnimGraphRuntime.ERBFNormalizeMethod
enum class ERBFNormalizeMethod : uint8_t
{
    OnlyNormalizeAboveOne                          = 0,
    AlwaysNormalize                                = 1,
    NormalizeWithinMedian                          = 2,
    NoNormalization                                = 3,
    ERBFNormalizeMethod_MAX                        = 4

};


// Enum  /Script/AnimGraphRuntime.ERBFDistanceMethod
enum class ERBFDistanceMethod : uint8_t
{
    Euclidean                                      = 0,
    Quaternion                                     = 1,
    SwingAngle                                     = 2,
    TwistAngle                                     = 3,
    DefaultMethod                                  = 4,
    ERBFDistanceMethod_MAX                         = 5

};


// Enum  /Script/AnimGraphRuntime.ERBFFunctionType
enum class ERBFFunctionType : uint8_t
{
    Gaussian                                       = 0,
    Exponential                                    = 1,
    Linear                                         = 2,
    Cubic                                          = 3,
    Quintic                                        = 4,
    DefaultFunction                                = 5,
    ERBFFunctionType_MAX                           = 6

};


// Enum  /Script/AnimGraphRuntime.ERBFSolverType
enum class ERBFSolverType : uint8_t
{
    Additive                                       = 0,
    Interpolative                                  = 1,
    ERBFSolverType_MAX                             = 2

};


// Enum  /Script/MovieSceneTracks.MovieScene3DPathSection_Axis
enum class MovieScene3DPathSection_Axis : uint8_t
{
    X                                              = 0,
    Y                                              = 1,
    Z                                              = 2,
    NEG_X                                          = 3,
    NEG_Y                                          = 4,
    NEG_Z                                          = 5,
    MovieScene3DPathSection_MAX                    = 6

};


// Enum  /Script/MovieSceneTracks.EFireEventsAtPosition
enum class EFireEventsAtPosition : uint8_t
{
    AtStartOfEvaluation                            = 0,
    AtEndOfEvaluation                              = 1,
    AfterSpawn                                     = 2,
    EFireEventsAtPosition_MAX                      = 3

};


// Enum  /Script/MovieSceneTracks.ELevelVisibility
enum class ELevelVisibility : uint8_t
{
    Visible                                        = 0,
    Hidden                                         = 1,
    ELevelVisibility_MAX                           = 2

};


// Enum  /Script/MovieSceneTracks.EParticleKey
enum class EParticleKey : uint8_t
{
    Activate                                       = 0,
    Deactivate                                     = 1,
    Trigger                                        = 2,
    EParticleKey_MAX                               = 3

};


// Enum  /Script/UMG.EDragPivot
enum class EDragPivot : uint8_t
{
    MouseDown                                      = 0,
    TopLeft                                        = 1,
    TopCenter                                      = 2,
    TopRight                                       = 3,
    CenterLeft                                     = 4,
    CenterCenter                                   = 5,
    CenterRight                                    = 6,
    BottomLeft                                     = 7,
    BottomCenter                                   = 8,
    BottomRight                                    = 9,
    EDragPivot_MAX                                 = 10

};


// Enum  /Script/UMG.EDynamicBoxType
enum class EDynamicBoxType : uint8_t
{
    Horizontal                                     = 0,
    Vertical                                       = 1,
    Wrap                                           = 2,
    VerticalWrap                                   = 3,
    Radial                                         = 4,
    Overlay                                        = 5,
    EDynamicBoxType_MAX                            = 6

};


// Enum  /Script/UMG.ESlateSizeRule
enum class ESlateSizeRule : uint8_t
{
    Automatic                                      = 0,
    Fill                                           = 1,
    ESlateSizeRule_MAX                             = 2

};


// Enum  /Script/UMG.EWidgetDesignFlags
enum class EWidgetDesignFlags : uint8_t
{
    None                                           = 0,
    Designing                                      = 1,
    ShowOutline                                    = 2,
    ExecutePreConstruct                            = 4,
    EWidgetDesignFlags_MAX                         = 5

};


// Enum  /Script/UMG.EBindingKind
enum class EBindingKind : uint8_t
{
    Function                                       = 0,
    Property                                       = 1,
    EBindingKind_MAX                               = 2

};


// Enum  /Script/UMG.ETickMode
enum class ETickMode : uint8_t
{
    Disabled                                       = 0,
    Enabled                                        = 1,
    Automatic                                      = 2,
    ETickMode_MAX                                  = 3

};


// Enum  /Script/UMG.EWindowVisibility
enum class EWindowVisibility : uint8_t
{
    Visible                                        = 0,
    SelfHitTestInvisible                           = 1,
    EWindowVisibility_MAX                          = 2

};


// Enum  /Script/UMG.EWidgetGeometryMode
enum class EWidgetGeometryMode : uint8_t
{
    Plane                                          = 0,
    Cylinder                                       = 1,
    EWidgetGeometryMode_MAX                        = 2

};


// Enum  /Script/UMG.EWidgetBlendMode
enum class EWidgetBlendMode : uint8_t
{
    Opaque                                         = 0,
    Masked                                         = 1,
    Transparent                                    = 2,
    EWidgetBlendMode_MAX                           = 3

};


// Enum  /Script/UMG.EWidgetTimingPolicy
enum class EWidgetTimingPolicy : uint8_t
{
    RealTime                                       = 0,
    GameTime                                       = 1,
    EWidgetTimingPolicy_MAX                        = 2

};


// Enum  /Script/UMG.EWidgetSpace
enum class EWidgetSpace : uint8_t
{
    World                                          = 0,
    Screen                                         = 1,
    EWidgetSpace_MAX                               = 2

};


// Enum  /Script/UMG.EWidgetInteractionSource
enum class EWidgetInteractionSource : uint8_t
{
    World                                          = 0,
    Mouse                                          = 1,
    CenterScreen                                   = 2,
    Custom                                         = 3,
    EWidgetInteractionSource_MAX                   = 4

};


// Enum  /Script/CinematicCamera.ECameraFocusMethod
enum class ECameraFocusMethod : uint8_t
{
    DoNotOverride                                  = 0,
    Manual                                         = 1,
    Tracking                                       = 2,
    Disable                                        = 3,
    MAX                                            = 4

};


// Enum  /Script/AudioPlatformConfiguration.ESoundwaveSampleRateSettings
enum class ESoundwaveSampleRateSettings : uint8_t
{
    Max                                            = 0,
    High                                           = 1,
    Medium                                         = 2,
    Low                                            = 3,
    Min                                            = 4,
    MatchDevice                                    = 5

};


// Enum  /Script/AudioMixer.EMusicalNoteName
enum class EMusicalNoteName : uint8_t
{
    C                                              = 0,
    Db                                             = 1,
    D                                              = 2,
    Eb                                             = 3,
    E                                              = 4,
    F                                              = 5,
    Gb                                             = 6,
    G                                              = 7,
    Ab                                             = 8,
    A                                              = 9,
    Bb                                             = 10,
    B                                              = 11,
    EMusicalNoteName_MAX                           = 12

};


// Enum  /Script/AudioMixer.ESubmixEffectDynamicsChannelLinkMode
enum class ESubmixEffectDynamicsChannelLinkMode : uint8_t
{
    Disabled                                       = 0,
    Average                                        = 1,
    Peak                                           = 2,
    Count                                          = 3,
    ESubmixEffectDynamicsChannelLinkMode_MAX       = 4

};


// Enum  /Script/AudioMixer.ESubmixEffectDynamicsPeakMode
enum class ESubmixEffectDynamicsPeakMode : uint8_t
{
    MeanSquared                                    = 0,
    RootMeanSquared                                = 1,
    Peak                                           = 2,
    Count                                          = 3,
    ESubmixEffectDynamicsPeakMode_MAX              = 4

};


// Enum  /Script/AudioMixer.ESubmixEffectDynamicsProcessorType
enum class ESubmixEffectDynamicsProcessorType : uint8_t
{
    Compressor                                     = 0,
    Limiter                                        = 1,
    Expander                                       = 2,
    Gate                                           = 3,
    Count                                          = 4,
    ESubmixEffectDynamicsProcessorType_MAX         = 5

};


// Enum  /Script/GameplayTags.EGameplayTagQueryExprType
enum class EGameplayTagQueryExprType : uint8_t
{
    Undefined                                      = 0,
    AnyTagsMatch                                   = 1,
    AllTagsMatch                                   = 2,
    NoTagsMatch                                    = 3,
    AnyExprMatch                                   = 4,
    AllExprMatch                                   = 5,
    NoExprMatch                                    = 6,
    EGameplayTagQueryExprType_MAX                  = 7

};


// Enum  /Script/GameplayTags.EGameplayContainerMatchType
enum class EGameplayContainerMatchType : uint8_t
{
    Any                                            = 0,
    All                                            = 1,
    EGameplayContainerMatchType_MAX                = 2

};


// Enum  /Script/GameplayTags.EGameplayTagMatchType
enum class EGameplayTagMatchType : uint8_t
{
    Explicit                                       = 0,
    IncludeParentTags                              = 1,
    EGameplayTagMatchType_MAX                      = 2

};


// Enum  /Script/GameplayTags.EGameplayTagSelectionType
enum class EGameplayTagSelectionType : uint8_t
{
    None                                           = 0,
    NonRestrictedOnly                              = 1,
    RestrictedOnly                                 = 2,
    All                                            = 3,
    EGameplayTagSelectionType_MAX                  = 4

};


// Enum  /Script/GameplayTags.EGameplayTagSourceType
enum class EGameplayTagSourceType : uint8_t
{
    Native                                         = 0,
    DefaultTagList                                 = 1,
    TagList                                        = 2,
    RestrictedTagList                              = 3,
    DataTable                                      = 4,
    Invalid                                        = 5,
    EGameplayTagSourceType_MAX                     = 6

};


// Enum  /Script/MeshDescription.EComputeNTBsOptions
enum class EComputeNTBsOptions : uint8_t
{
    None                                           = 0,
    Normals                                        = 1,
    Tangents                                       = 2,
    WeightedNTBs                                   = 4,
    EComputeNTBsOptions_MAX                        = 5

};


// Enum  /Script/PropertyAccess.EPropertyAccessCopyBatch
enum class EPropertyAccessCopyBatch : uint8_t
{
    InternalUnbatched                              = 0,
    ExternalUnbatched                              = 1,
    InternalBatched                                = 2,
    ExternalBatched                                = 3,
    Count                                          = 4,
    EPropertyAccessCopyBatch_MAX                   = 5

};


// Enum  /Script/PropertyAccess.EPropertyAccessCopyType
enum class EPropertyAccessCopyType : uint8_t
{
    None                                           = 0,
    Plain                                          = 1,
    Complex                                        = 2,
    Bool                                           = 3,
    Struct                                         = 4,
    Object                                         = 5,
    Name                                           = 6,
    Array                                          = 7,
    PromoteBoolToByte                              = 8,
    PromoteBoolToInt32                             = 9,
    PromoteBoolToInt64                             = 10,
    PromoteBoolToFloat                             = 11,
    PromoteByteToInt32                             = 12,
    PromoteByteToInt64                             = 13,
    PromoteByteToFloat                             = 14,
    PromoteInt32ToInt64                            = 15,
    PromoteInt32ToFloat                            = 16,
    EPropertyAccessCopyType_MAX                    = 17

};


// Enum  /Script/PropertyAccess.EPropertyAccessObjectType
enum class EPropertyAccessObjectType : uint8_t
{
    None                                           = 0,
    Object                                         = 1,
    WeakObject                                     = 2,
    SoftObject                                     = 3,
    EPropertyAccessObjectType_MAX                  = 4

};


// Enum  /Script/PropertyAccess.EPropertyAccessIndirectionType
enum class EPropertyAccessIndirectionType : uint8_t
{
    Offset                                         = 0,
    Object                                         = 1,
    Array                                          = 2,
    ScriptFunction                                 = 3,
    NativeFunction                                 = 4,
    EPropertyAccessIndirectionType_MAX             = 5

};


// Enum  /Script/EyeTracker.EEyeTrackerStatus
enum class EEyeTrackerStatus : uint8_t
{
    NotConnected                                   = 0,
    NotTracking                                    = 1,
    Tracking                                       = 2,
    EEyeTrackerStatus_MAX                          = 3

};


// Enum  /Script/MediaUtils.EMediaPlayerOptionBooleanOverride
enum class EMediaPlayerOptionBooleanOverride : uint8_t
{
    UseMediaPlayerSetting                          = 0,
    Enabled                                        = 1,
    Disabled                                       = 2,
    EMediaPlayerOptionBooleanOverride_MAX          = 3

};


// Enum  /Script/MediaAssets.EMediaWebcamCaptureDeviceFilter
enum class EMediaWebcamCaptureDeviceFilter : uint8_t
{
    None                                           = 0,
    DepthSensor                                    = 1,
    Front                                          = 2,
    Rear                                           = 4,
    Unknown                                        = 8,
    EMediaWebcamCaptureDeviceFilter_MAX            = 9

};


// Enum  /Script/MediaAssets.EMediaVideoCaptureDeviceFilter
enum class EMediaVideoCaptureDeviceFilter : uint8_t
{
    None                                           = 0,
    Card                                           = 1,
    Software                                       = 2,
    Unknown                                        = 4,
    Webcam                                         = 8,
    EMediaVideoCaptureDeviceFilter_MAX             = 9

};


// Enum  /Script/MediaAssets.EMediaAudioCaptureDeviceFilter
enum class EMediaAudioCaptureDeviceFilter : uint8_t
{
    None                                           = 0,
    Card                                           = 1,
    Microphone                                     = 2,
    Software                                       = 4,
    Unknown                                        = 8,
    EMediaAudioCaptureDeviceFilter_MAX             = 9

};


// Enum  /Script/MediaAssets.EMediaPlayerTrack
enum class EMediaPlayerTrack : uint8_t
{
    Audio                                          = 0,
    Caption                                        = 1,
    Metadata                                       = 2,
    Script                                         = 3,
    Subtitle                                       = 4,
    Text                                           = 5,
    Video                                          = 6,
    EMediaPlayerTrack_MAX                          = 7

};


// Enum  /Script/MediaAssets.EMediaSoundComponentFFTSize
enum class EMediaSoundComponentFFTSize : uint8_t
{
    Min                                            = 0,
    Small                                          = 1,
    Medium                                         = 2,
    Large                                          = 3,
    EMediaSoundComponentFFTSize_MAX                = 4

};


// Enum  /Script/MediaAssets.EMediaSoundChannels
enum class EMediaSoundChannels : uint8_t
{
    Mono                                           = 0,
    Stereo                                         = 1,
    Surround                                       = 2,
    EMediaSoundChannels_MAX                        = 3

};


// Enum  /Script/MediaAssets.MediaTextureOrientation
enum class MediaTextureOrientation : uint8_t
{
    MTORI_Original                                 = 0,
    MTORI_CW90                                     = 1,
    MTORI_CW180                                    = 2,
    MTORI_CW270                                    = 3,
    MTORI_MAX                                      = 4

};


// Enum  /Script/MediaAssets.MediaTextureOutputFormat
enum class MediaTextureOutputFormat : uint8_t
{
    MTOF_Default                                   = 0,
    MTOF_SRGB_LINOUT                               = 1,
    MTOF_MAX                                       = 2

};


// Enum  /Script/MovieSceneCapture.EHDRCaptureGamut
enum class EHDRCaptureGamut : uint8_t
{
    HCGM_Rec709                                    = 0,
    HCGM_P3DCI                                     = 1,
    HCGM_Rec2020                                   = 2,
    HCGM_ACES                                      = 3,
    HCGM_ACEScg                                    = 4,
    HCGM_Linear                                    = 5,
    HCGM_MAX                                       = 6

};


// Enum  /Script/MovieSceneCapture.EMovieSceneCaptureProtocolState
enum class EMovieSceneCaptureProtocolState : uint8_t
{
    Idle                                           = 0,
    Initialized                                    = 1,
    Capturing                                      = 2,
    Finalizing                                     = 3,
    EMovieSceneCaptureProtocolState_MAX            = 4

};


// Enum  /Script/MoviePlayer.EMoviePlaybackType
enum class EMoviePlaybackType : uint8_t
{
    MT_Normal                                      = 0,
    MT_Looped                                      = 1,
    MT_LoadingLoop                                 = 2,
    MT_MAX                                         = 3

};


// Enum  /Script/Engine.EConfigType
enum class EConfigType : uint8_t
{
    ConfigType_Bool                                = 0,
    ConfigType_Int32                               = 1,
    ConfigType_Float                               = 2,
    ConfigType_MAX                                 = 3

};


// Enum  /Script/Engine.EAlphaBlendOption
enum class EAlphaBlendOption : uint8_t
{
    Linear                                         = 0,
    Cubic                                          = 1,
    HermiteCubic                                   = 2,
    Sinusoidal                                     = 3,
    QuadraticInOut                                 = 4,
    CubicInOut                                     = 5,
    QuarticInOut                                   = 6,
    QuinticInOut                                   = 7,
    CircularIn                                     = 8,
    CircularOut                                    = 9,
    CircularInOut                                  = 10,
    ExpIn                                          = 11,
    ExpOut                                         = 12,
    ExpInOut                                       = 13,
    Custom                                         = 14,
    EAlphaBlendOption_MAX                          = 15

};


// Enum  /Script/Engine.EAnimSyncGroupScope
enum class EAnimSyncGroupScope : uint8_t
{
    Local                                          = 0,
    Component                                      = 1,
    EAnimSyncGroupScope_MAX                        = 2

};


// Enum  /Script/Engine.EAnimGroupRole
enum class EAnimGroupRole : uint8_t
{
    CanBeLeader                                    = 0,
    AlwaysFollower                                 = 1,
    AlwaysLeader                                   = 2,
    TransitionLeader                               = 3,
    TransitionFollower                             = 4,
    EAnimGroupRole_MAX                             = 5

};


// Enum  /Script/Engine.EPreviewAnimationBlueprintApplicationMethod
enum class EPreviewAnimationBlueprintApplicationMethod : uint8_t
{
    LinkedLayers                                   = 0,
    LinkedAnimGraph                                = 1,
    EPreviewAnimationBlueprintApplicationMethod_MAX = 2

};


// Enum  /Script/Engine.AnimationKeyFormat
enum class AnimationKeyFormat : uint8_t
{
    AKF_ConstantKeyLerp                            = 0,
    AKF_VariableKeyLerp                            = 1,
    AKF_PerTrackCompression                        = 2,
    AKF_MAX                                        = 3

};


// Enum  /Script/Engine.ERawCurveTrackTypes
enum class ERawCurveTrackTypes : uint8_t
{
    RCT_Float                                      = 0,
    RCT_Vector                                     = 1,
    RCT_Transform                                  = 2,
    RCT_MAX                                        = 3

};


// Enum  /Script/Engine.EAnimAssetCurveFlags
enum class EAnimAssetCurveFlags : uint8_t
{
    AACF_NONE                                      = 0,
    AACF_DriveMorphTarget_DEPRECATED               = 1,
    AACF_DriveAttribute_DEPRECATED                 = 2,
    AACF_Editable                                  = 4,
    AACF_DriveMaterial_DEPRECATED                  = 8,
    AACF_Metadata                                  = 16,
    AACF_DriveTrack                                = 32,
    AACF_Disabled                                  = 64,
    AACF_MAX                                       = 65

};


// Enum  /Script/Engine.AnimationCompressionFormat
enum class AnimationCompressionFormat : uint8_t
{
    ACF_None                                       = 0,
    ACF_Float96NoW                                 = 1,
    ACF_Fixed48NoW                                 = 2,
    ACF_IntervalFixed32NoW                         = 3,
    ACF_Fixed32NoW                                 = 4,
    ACF_Float32NoW                                 = 5,
    ACF_Identity                                   = 6,
    ACF_MAX                                        = 7

};


// Enum  /Script/Engine.EAdditiveBasePoseType
enum class EAdditiveBasePoseType : uint8_t
{
    ABPT_None                                      = 0,
    ABPT_RefPose                                   = 1,
    ABPT_AnimScaled                                = 2,
    ABPT_AnimFrame                                 = 3,
    ABPT_MAX                                       = 4

};


// Enum  /Script/Engine.ERootMotionRootLock
enum class ERootMotionRootLock : uint8_t
{
    RefPose                                        = 0,
    AnimFirstFrame                                 = 1,
    Zero                                           = 2,
    ERootMotionRootLock_MAX                        = 3

};


// Enum  /Script/Engine.EDrawDebugItemType
enum class EDrawDebugItemType : uint8_t
{
    DirectionalArrow                               = 0,
    Sphere                                         = 1,
    Line                                           = 2,
    OnScreenMessage                                = 3,
    CoordinateSystem                               = 4,
    EDrawDebugItemType_MAX                         = 5

};


// Enum  /Script/Engine.EMontageSubStepResult
enum class EMontageSubStepResult : uint8_t
{
    Moved                                          = 0,
    NotMoved                                       = 1,
    InvalidSection                                 = 2,
    InvalidMontage                                 = 3,
    EMontageSubStepResult_MAX                      = 4

};


// Enum  /Script/Engine.EAnimNotifyEventType
enum class EAnimNotifyEventType : uint8_t
{
    Begin                                          = 0,
    End                                            = 1,
    EAnimNotifyEventType_MAX                       = 2

};


// Enum  /Script/Engine.EInertializationSpace
enum class EInertializationSpace : uint8_t
{
    Default                                        = 0,
    WorldSpace                                     = 1,
    WorldRotation                                  = 2,
    EInertializationSpace_MAX                      = 3

};


// Enum  /Script/Engine.EInertializationBoneState
enum class EInertializationBoneState : uint8_t
{
    Invalid                                        = 0,
    Valid                                          = 1,
    Excluded                                       = 2,
    EInertializationBoneState_MAX                  = 3

};


// Enum  /Script/Engine.EInertializationState
enum class EInertializationState : uint8_t
{
    Inactive                                       = 0,
    Pending                                        = 1,
    Active                                         = 2,
    EInertializationState_MAX                      = 3

};


// Enum  /Script/Engine.EEvaluatorMode
enum class EEvaluatorMode : uint8_t
{
    EM_Standard                                    = 0,
    EM_Freeze                                      = 1,
    EM_DelayedFreeze                               = 2,
    EM_MAX                                         = 3

};


// Enum  /Script/Engine.EEvaluatorDataSource
enum class EEvaluatorDataSource : uint8_t
{
    EDS_SourcePose                                 = 0,
    EDS_DestinationPose                            = 1,
    EDS_MAX                                        = 2

};


// Enum  /Script/Engine.EPostCopyOperation
enum class EPostCopyOperation : uint8_t
{
    None                                           = 0,
    LogicalNegateBool                              = 1,
    EPostCopyOperation_MAX                         = 2

};


// Enum  /Script/Engine.EPinHidingMode
enum class EPinHidingMode : uint8_t
{
    NeverAsPin                                     = 0,
    PinHiddenByDefault                             = 1,
    PinShownByDefault                              = 2,
    AlwaysAsPin                                    = 3,
    EPinHidingMode_MAX                             = 4

};


// Enum  /Script/Engine.AnimPhysCollisionType
enum class AnimPhysCollisionType : uint8_t
{
    CoM                                            = 0,
    CustomSphere                                   = 1,
    InnerSphere                                    = 2,
    OuterSphere                                    = 3,
    AnimPhysCollisionType_MAX                      = 4

};


// Enum  /Script/Engine.AnimPhysTwistAxis
enum class AnimPhysTwistAxis : uint8_t
{
    AxisX                                          = 0,
    AxisY                                          = 1,
    AxisZ                                          = 2,
    AnimPhysTwistAxis_MAX                          = 3

};


// Enum  /Script/Engine.ETypeAdvanceAnim
enum class ETypeAdvanceAnim : uint8_t
{
    ETAA_Default                                   = 0,
    ETAA_Finished                                  = 1,
    ETAA_Looped                                    = 2,
    ETAA_MAX                                       = 3

};


// Enum  /Script/Engine.ETransitionLogicType
enum class ETransitionLogicType : uint8_t
{
    TLT_StandardBlend                              = 0,
    TLT_Inertialization                            = 1,
    TLT_Custom                                     = 2,
    TLT_MAX                                        = 3

};


// Enum  /Script/Engine.ETransitionBlendMode
enum class ETransitionBlendMode : uint8_t
{
    TBM_Linear                                     = 0,
    TBM_Cubic                                      = 1,
    TBM_MAX                                        = 2

};


// Enum  /Script/Engine.EComponentType
enum class EComponentType : uint8_t
{
    None                                           = 0,
    TranslationX                                   = 1,
    TranslationY                                   = 2,
    TranslationZ                                   = 3,
    RotationX                                      = 4,
    RotationY                                      = 5,
    RotationZ                                      = 6,
    Scale                                          = 7,
    ScaleX                                         = 8,
    ScaleY                                         = 9,
    ScaleZ                                         = 10,
    EComponentType_MAX                             = 11

};


// Enum  /Script/Engine.EAxisOption
enum class EAxisOption : uint8_t
{
    X                                              = 0,
    Y                                              = 1,
    Z                                              = 2,
    X_Neg                                          = 3,
    Y_Neg                                          = 4,
    Z_Neg                                          = 5,
    Custom                                         = 6,
    EAxisOption_MAX                                = 7

};


// Enum  /Script/Engine.EAnimInterpolationType
enum class EAnimInterpolationType : uint8_t
{
    Linear                                         = 0,
    Step                                           = 1,
    EAnimInterpolationType_MAX                     = 2

};


// Enum  /Script/Engine.ECurveBlendOption
enum class ECurveBlendOption : uint8_t
{
    Override                                       = 0,
    DoNotOverride                                  = 1,
    NormalizeByWeight                              = 2,
    BlendByWeight                                  = 3,
    UseBasePose                                    = 4,
    UseMaxValue                                    = 5,
    UseMinValue                                    = 6,
    ECurveBlendOption_MAX                          = 7

};


// Enum  /Script/Engine.EAdditiveAnimationType
enum class EAdditiveAnimationType : uint8_t
{
    AAT_None                                       = 0,
    AAT_LocalSpaceBase                             = 1,
    AAT_RotationOffsetMeshSpace                    = 2,
    AAT_MAX                                        = 3

};


// Enum  /Script/Engine.EBoneRotationSource
enum class EBoneRotationSource : uint8_t
{
    BRS_KeepComponentSpaceRotation                 = 0,
    BRS_KeepLocalSpaceRotation                     = 1,
    BRS_CopyFromTarget                             = 2,
    BRS_MAX                                        = 3

};


// Enum  /Script/Engine.EBoneControlSpace
enum class EBoneControlSpace : uint8_t
{
    BCS_WorldSpace                                 = 0,
    BCS_ComponentSpace                             = 1,
    BCS_ParentBoneSpace                            = 2,
    BCS_BoneSpace                                  = 3,
    BCS_MAX                                        = 4

};


// Enum  /Script/Engine.EBoneAxis
enum class EBoneAxis : uint8_t
{
    BA_X                                           = 0,
    BA_Y                                           = 1,
    BA_Z                                           = 2,
    BA_MAX                                         = 3

};


// Enum  /Script/Engine.EPrimaryAssetCookRule
enum class EPrimaryAssetCookRule : uint8_t
{
    Unknown                                        = 0,
    NeverCook                                      = 1,
    DevelopmentCook                                = 2,
    DevelopmentAlwaysCook                          = 3,
    AlwaysCook                                     = 4,
    EPrimaryAssetCookRule_MAX                      = 5

};


// Enum  /Script/Engine.ENaturalSoundFalloffMode
enum class ENaturalSoundFalloffMode : uint8_t
{
    Continues                                      = 0,
    Silent                                         = 1,
    Hold                                           = 2,
    ENaturalSoundFalloffMode_MAX                   = 3

};


// Enum  /Script/Engine.EAttenuationShape
enum class EAttenuationShape : uint8_t
{
    Sphere                                         = 0,
    Capsule                                        = 1,
    Box                                            = 2,
    Cone                                           = 3,
    EAttenuationShape_MAX                          = 4

};


// Enum  /Script/Engine.EAttenuationDistanceModel
enum class EAttenuationDistanceModel : uint8_t
{
    Linear                                         = 0,
    Logarithmic                                    = 1,
    Inverse                                        = 2,
    LogReverse                                     = 3,
    NaturalSound                                   = 4,
    Custom                                         = 5,
    EAttenuationDistanceModel_MAX                  = 6

};


// Enum  /Script/Engine.EAudioBusChannels
enum class EAudioBusChannels : uint8_t
{
    Mono                                           = 0,
    Stereo                                         = 1,
    EAudioBusChannels_MAX                          = 2

};


// Enum  /Script/Engine.EAudioFaderCurve
enum class EAudioFaderCurve : uint8_t
{
    Linear                                         = 0,
    Logarithmic                                    = 1,
    SCurve                                         = 2,
    Sin                                            = 3,
    Count                                          = 4,
    EAudioFaderCurve_MAX                           = 5

};


// Enum  /Script/Engine.EAudioOutputTarget
enum class EAudioOutputTarget : uint8_t
{
    Speaker                                        = 0,
    Controller                                     = 1,
    ControllerFallbackToSpeaker                    = 2,
    EAudioOutputTarget_MAX                         = 3

};


// Enum  /Script/Engine.EMonoChannelUpmixMethod
enum class EMonoChannelUpmixMethod : uint8_t
{
    Linear                                         = 0,
    EqualPower                                     = 1,
    FullVolume                                     = 2,
    EMonoChannelUpmixMethod_MAX                    = 3

};


// Enum  /Script/Engine.EPanningMethod
enum class EPanningMethod : uint8_t
{
    Linear                                         = 0,
    EqualPower                                     = 1,
    EPanningMethod_MAX                             = 2

};


// Enum  /Script/Engine.EVoiceSampleRate
enum class EVoiceSampleRate : uint32_t
{
    Low16000Hz                                     = 16000,
    Normal24000Hz                                  = 24000,
    EVoiceSampleRate_MAX                           = 24001

};


// Enum  /Script/Engine.EAudioVolumeLocationState
enum class EAudioVolumeLocationState : uint8_t
{
    InsideTheVolume                                = 0,
    OutsideTheVolume                               = 1,
    EAudioVolumeLocationState_MAX                  = 2

};


// Enum  /Script/Engine.EBlendableLocation
enum class EBlendableLocation : uint8_t
{
    BL_AfterTonemapping                            = 0,
    BL_BeforeTonemapping                           = 1,
    BL_BeforeTranslucency                          = 2,
    BL_ReplacingTonemapper                         = 3,
    BL_SSRInput                                    = 4,
    BL_AfterTonemappingEssentially                 = 5,
    BL_MAX                                         = 6

};


// Enum  /Script/Engine.ENotifyTriggerMode
enum class ENotifyTriggerMode : uint8_t
{
    AllAnimations                                  = 0,
    HighestWeightedAnimation                       = 1,
    None                                           = 2,
    ENotifyTriggerMode_MAX                         = 3

};


// Enum  /Script/Engine.EBlendSpaceAxis
enum class EBlendSpaceAxis : uint8_t
{
    BSA_None                                       = 0,
    BSA_X                                          = 1,
    BSA_Y                                          = 2,
    BSA_Max                                        = 3

};


// Enum  /Script/Engine.EBlueprintNativizationFlag
enum class EBlueprintNativizationFlag : uint8_t
{
    Disabled                                       = 0,
    Dependency                                     = 1,
    ExplicitlyEnabled                              = 2,
    EBlueprintNativizationFlag_MAX                 = 3

};


// Enum  /Script/Engine.EBlueprintCompileMode
enum class EBlueprintCompileMode : uint8_t
{
    Default                                        = 0,
    Development                                    = 1,
    FinalRelease                                   = 2,
    EBlueprintCompileMode_MAX                      = 3

};


// Enum  /Script/Engine.EBlueprintType
enum class EBlueprintType : uint8_t
{
    BPTYPE_Normal                                  = 0,
    BPTYPE_Const                                   = 1,
    BPTYPE_MacroLibrary                            = 2,
    BPTYPE_Interface                               = 3,
    BPTYPE_LevelScript                             = 4,
    BPTYPE_FunctionLibrary                         = 5,
    BPTYPE_MAX                                     = 6

};


// Enum  /Script/Engine.EBlueprintStatus
enum class EBlueprintStatus : uint8_t
{
    BS_Unknown                                     = 0,
    BS_Dirty                                       = 1,
    BS_Error                                       = 2,
    BS_UpToDate                                    = 3,
    BS_BeingCreated                                = 4,
    BS_UpToDateWithWarnings                        = 5,
    BS_MAX                                         = 6

};


// Enum  /Script/Engine.EDOFMode
enum class EDOFMode : uint8_t
{
    Default                                        = 0,
    SixDOF                                         = 1,
    YZPlane                                        = 2,
    XZPlane                                        = 3,
    XYPlane                                        = 4,
    CustomPlane                                    = 5,
    None                                           = 6,
    EDOFMode_MAX                                   = 7

};


// Enum  /Script/Engine.EBrushType
enum class EBrushType : uint8_t
{
    Brush_Default                                  = 0,
    Brush_Add                                      = 1,
    Brush_Subtract                                 = 2,
    Brush_MAX                                      = 3

};


// Enum  /Script/Engine.ECsgOper
enum class ECsgOper : uint8_t
{
    CSG_Active                                     = 0,
    CSG_Add                                        = 1,
    CSG_Subtract                                   = 2,
    CSG_Intersect                                  = 3,
    CSG_Deintersect                                = 4,
    CSG_None                                       = 5,
    CSG_MAX                                        = 6

};


// Enum  /Script/Engine.EInitialOscillatorOffset
enum class EInitialOscillatorOffset : uint8_t
{
    EOO_OffsetRandom                               = 0,
    EOO_OffsetZero                                 = 1,
    EOO_MAX                                        = 2

};


// Enum  /Script/Engine.EOscillatorWaveform
enum class EOscillatorWaveform : uint8_t
{
    SineWave                                       = 0,
    PerlinNoise                                    = 1,
    Constant                                       = 2,
    EOscillatorWaveform_MAX                        = 3

};


// Enum  /Script/Engine.ECameraShakeDurationType
enum class ECameraShakeDurationType : uint8_t
{
    Fixed                                          = 0,
    Infinite                                       = 1,
    Custom                                         = 2,
    ECameraShakeDurationType_MAX                   = 3

};


// Enum  /Script/Engine.ECameraShakeUpdateResultFlags
enum class ECameraShakeUpdateResultFlags : uint8_t
{
    ApplyAsAbsolute                                = 1,
    SkipAutoScale                                  = 2,
    SkipAutoPlaySpace                              = 4,
    Default                                        = 0,
    ECameraShakeUpdateResultFlags_MAX              = 5

};


// Enum  /Script/Engine.ECameraShakeAttenuation
enum class ECameraShakeAttenuation : uint8_t
{
    Linear                                         = 0,
    Quadratic                                      = 1,
    ECameraShakeAttenuation_MAX                    = 2

};


// Enum  /Script/Engine.ECameraAlphaBlendMode
enum class ECameraAlphaBlendMode : uint8_t
{
    CABM_Linear                                    = 0,
    CABM_Cubic                                     = 1,
    CABM_MAX                                       = 2

};


// Enum  /Script/Engine.ECameraShakePlaySpace
enum class ECameraShakePlaySpace : uint8_t
{
    CameraLocal                                    = 0,
    World                                          = 1,
    UserDefined                                    = 2,
    ActorLocal                                     = 3,
    ECameraShakePlaySpace_MAX                      = 4

};


// Enum  /Script/Engine.ECloudStorageDelegate
enum class ECloudStorageDelegate : uint8_t
{
    CSD_KeyValueReadComplete                       = 0,
    CSD_KeyValueWriteComplete                      = 1,
    CSD_ValueChanged                               = 2,
    CSD_DocumentQueryComplete                      = 3,
    CSD_DocumentReadComplete                       = 4,
    CSD_DocumentWriteComplete                      = 5,
    CSD_DocumentConflictDetected                   = 6,
    CSD_MAX                                        = 7

};


// Enum  /Script/Engine.EDPCompareType
enum class EDPCompareType : uint8_t
{
    DP_Equal                                       = 0,
    DP_Less                                        = 1,
    DP_LessEqual                                   = 2,
    DP_Greater                                     = 3,
    DP_GreaterEqual                                = 4,
    DP_NotEqual                                    = 5,
    DP_Regex                                       = 6,
    DP_CMP_MAX                                     = 7,
    DP_MAX                                         = 8

};


// Enum  /Script/Engine.EDPSourceType
enum class EDPSourceType : uint8_t
{
    DP_PreviousRegexMatch                          = 0,
    DP_ProfileName                                 = 1,
    DP_DeviceType                                  = 2,
    DP_GpuFamily                                   = 3,
    DP_GlVersion                                   = 4,
    DP_OsVersion                                   = 5,
    DP_DeviceMake                                  = 6,
    DP_DeviceModel                                 = 7,
    DP_VulkanVersion                               = 8,
    DP_MemorySizeInGB                              = 9,
    DP_QualityLevel                                = 10,
    DP_MaxQualityLevel                             = 11,
    DP_TCQualityGrade                              = 12,
    DP_ScreenPhysicSize                            = 13,
    DP_MainBroadInfo                               = 14,
    DP_SRC_MAX                                     = 15

};


// Enum  /Script/Engine.EAngularDriveMode
enum class EAngularDriveMode : uint8_t
{
    SLERP                                          = 0,
    TwistAndSwing                                  = 1,
    EAngularDriveMode_MAX                          = 2

};


// Enum  /Script/Engine.ECurveTableMode
enum class ECurveTableMode : uint8_t
{
    Empty                                          = 0,
    SimpleCurves                                   = 1,
    RichCurves                                     = 2,
    ECurveTableMode_MAX                            = 3

};


// Enum  /Script/Engine.ECustomAttributeBlendType
enum class ECustomAttributeBlendType : uint8_t
{
    Override                                       = 0,
    Blend                                          = 1,
    ECustomAttributeBlendType_MAX                  = 2

};


// Enum  /Script/Engine.EEvaluateCurveTableResult
enum class EEvaluateCurveTableResult : uint8_t
{
    RowFound                                       = 0,
    RowNotFound                                    = 1,
    EEvaluateCurveTableResult_MAX                  = 2

};


// Enum  /Script/Engine.EDecalChannelType
enum class EDecalChannelType : uint8_t
{
    AllObjects                                     = 0,
    OnlyChannel0                                   = 1,
    OnlyChannel1                                   = 2,
    Channel0andChannel1                            = 3,
    EDecalChannelType_MAX                          = 4

};


// Enum  /Script/Engine.LobbyType
enum class LobbyType : uint8_t
{
    Lobby_Main                                     = 0,
    Lobby_SelectAvatar                             = 1,
    Lobby_ShowAvatar                               = 2,
    Lobby_MAX                                      = 3

};


// Enum  /Script/Engine.EGrammaticalNumber
enum class EGrammaticalNumber : uint8_t
{
    Singular                                       = 0,
    Plural                                         = 1,
    EGrammaticalNumber_MAX                         = 2

};


// Enum  /Script/Engine.EGrammaticalGender
enum class EGrammaticalGender : uint8_t
{
    Neuter                                         = 0,
    Masculine                                      = 1,
    Feminine                                       = 2,
    Mixed                                          = 3,
    EGrammaticalGender_MAX                         = 4

};


// Enum  /Script/Engine.DistributionParamMode
enum class DistributionParamMode : uint8_t
{
    DPM_Normal                                     = 0,
    DPM_Abs                                        = 1,
    DPM_Direct                                     = 2,
    DPM_MAX                                        = 3

};


// Enum  /Script/Engine.EDistributionVectorMirrorFlags
enum class EDistributionVectorMirrorFlags : uint8_t
{
    EDVMF_Same                                     = 0,
    EDVMF_Different                                = 1,
    EDVMF_Mirror                                   = 2,
    EDVMF_MAX                                      = 3

};


// Enum  /Script/Engine.EDistributionVectorLockFlags
enum class EDistributionVectorLockFlags : uint8_t
{
    EDVLF_None                                     = 0,
    EDVLF_XY                                       = 1,
    EDVLF_XZ                                       = 2,
    EDVLF_YZ                                       = 3,
    EDVLF_XYZ                                      = 4,
    EDVLF_MAX                                      = 5

};


// Enum  /Script/Engine.EDSPVSConfigCategory
enum class EDSPVSConfigCategory : uint8_t
{
    CTY_LeastAggressive                            = 0,
    CTY_ModeratelyAggressive                       = 1,
    CTY_MostAggressive                             = 2,
    CTY_Max                                        = 3

};


// Enum  /Script/Engine.EDSPVSCategory
enum class EDSPVSCategory : uint8_t
{
    CATEGORY_Loose                                 = 0,
    CATEGORY_Strict                                = 1,
    CATEGORY_Null                                  = 2,
    CATEGORY_Max                                   = 3

};


// Enum  /Script/Engine.ENodeEnabledState
enum class ENodeEnabledState : uint8_t
{
    Enabled                                        = 0,
    Disabled                                       = 1,
    DevelopmentOnly                                = 2,
    ENodeEnabledState_MAX                          = 3

};


// Enum  /Script/Engine.ENodeAdvancedPins
enum class ENodeAdvancedPins : uint8_t
{
    NoPins                                         = 0,
    Shown                                          = 1,
    Hidden                                         = 2,
    ENodeAdvancedPins_MAX                          = 3

};


// Enum  /Script/Engine.ENodeTitleType
enum class ENodeTitleType : uint8_t
{
    FullTitle                                      = 0,
    ListView                                       = 1,
    EditableTitle                                  = 2,
    MenuTitle                                      = 3,
    MAX_TitleTypes                                 = 4,
    ENodeTitleType_MAX                             = 5

};


// Enum  /Script/Engine.EPinContainerType
enum class EPinContainerType : uint8_t
{
    None                                           = 0,
    Array                                          = 1,
    Set                                            = 2,
    Map                                            = 3,
    EPinContainerType_MAX                          = 4

};


// Enum  /Script/Engine.EEdGraphPinDirection
enum class EEdGraphPinDirection : uint8_t
{
    EGPD_Input                                     = 0,
    EGPD_Output                                    = 1,
    EGPD_MAX                                       = 2

};


// Enum  /Script/Engine.EBlueprintPinStyleType
enum class EBlueprintPinStyleType : uint8_t
{
    BPST_Original                                  = 0,
    BPST_VariantA                                  = 1,
    BPST_MAX                                       = 2

};


// Enum  /Script/Engine.ECanCreateConnectionResponse
enum class ECanCreateConnectionResponse : uint8_t
{
    CONNECT_RESPONSE_MAKE                          = 0,
    CONNECT_RESPONSE_DISALLOW                      = 1,
    CONNECT_RESPONSE_BREAK_OTHERS_A                = 2,
    CONNECT_RESPONSE_BREAK_OTHERS_B                = 3,
    CONNECT_RESPONSE_BREAK_OTHERS_AB               = 4,
    CONNECT_RESPONSE_MAKE_WITH_CONVERSION_NODE     = 5,
    CONNECT_RESPONSE_MAX                           = 6

};


// Enum  /Script/Engine.EGraphType
enum class EGraphType : uint8_t
{
    GT_Function                                    = 0,
    GT_Ubergraph                                   = 1,
    GT_Macro                                       = 2,
    GT_Animation                                   = 3,
    GT_StateMachine                                = 4,
    GT_MAX                                         = 5

};


// Enum  /Script/Engine.ELensEffectScaleMode
enum class ELensEffectScaleMode : uint8_t
{
    LESM_UniformScaleToFitY                        = 0,
    LESM_UniformScaleToFitX                        = 1,
    LESM_NonUniformScaleToFitXY                    = 2,
    LESM_MAX                                       = 3

};


// Enum  /Script/Engine.ETransitionType
enum class ETransitionType : uint8_t
{
    None                                           = 0,
    Paused                                         = 1,
    Loading                                        = 2,
    Saving                                         = 3,
    Connecting                                     = 4,
    Precaching                                     = 5,
    WaitingToConnect                               = 6,
    MAX                                            = 7

};


// Enum  /Script/Engine.EFullyLoadPackageType
enum class EFullyLoadPackageType : uint8_t
{
    FULLYLOAD_Map                                  = 0,
    FULLYLOAD_Game_PreLoadClass                    = 1,
    FULLYLOAD_Game_PostLoadClass                   = 2,
    FULLYLOAD_Always                               = 3,
    FULLYLOAD_Mutator                              = 4,
    FULLYLOAD_MAX                                  = 5

};


// Enum  /Script/Engine.EViewModeIndex
enum class EViewModeIndex : uint8_t
{
    VMI_BrushWireframe                             = 0,
    VMI_Wireframe                                  = 1,
    VMI_Unlit                                      = 2,
    VMI_Lit                                        = 3,
    VMI_Lit_DetailLighting                         = 4,
    VMI_LightingOnly                               = 5,
    VMI_LightComplexity                            = 6,
    VMI_ShaderComplexity                           = 8,
    VMI_LightmapDensity                            = 9,
    VMI_LitLightmapDensity                         = 10,
    VMI_ReflectionOverride                         = 11,
    VMI_VisualizeBuffer                            = 12,
    VMI_StationaryLightOverlap                     = 14,
    VMI_CollisionPawn                              = 15,
    VMI_CollisionVisibility                        = 16,
    VMI_LODColoration                              = 18,
    VMI_QuadOverdraw                               = 19,
    VMI_PrimitiveDistanceAccuracy                  = 20,
    VMI_MeshUVDensityAccuracy                      = 21,
    VMI_ShaderComplexityWithQuadOverdraw           = 22,
    VMI_HLODColoration                             = 23,
    VMI_GroupLODColoration                         = 24,
    VMI_MaterialTextureScaleAccuracy               = 25,
    VMI_RequiredTextureResolution                  = 26,
    VMI_PathTracing                                = 27,
    VMI_RayTracingDebug                            = 28,
    VMI_Max                                        = 32,
    VMI_Unknown                                    = 255

};


// Enum  /Script/Engine.ETravelType
enum class ETravelType : uint8_t
{
    TRAVEL_Absolute                                = 0,
    TRAVEL_Partial                                 = 1,
    TRAVEL_Relative                                = 2,
    TRAVEL_MAX                                     = 3

};


// Enum  /Script/Engine.ENetworkLagState
enum class ENetworkLagState : uint8_t
{
    NotLagging                                     = 0,
    Lagging                                        = 1,
    ENetworkLagState_MAX                           = 2

};


// Enum  /Script/Engine.EMouseCaptureMode
enum class EMouseCaptureMode : uint8_t
{
    NoCapture                                      = 0,
    CapturePermanently                             = 1,
    CapturePermanently_IncludingInitialMouseDown   = 2,
    CaptureDuringMouseDown                         = 3,
    CaptureDuringRightMouseDown                    = 4,
    EMouseCaptureMode_MAX                          = 5

};


// Enum  /Script/Engine.ECustomTimeStepSynchronizationState
enum class ECustomTimeStepSynchronizationState : uint8_t
{
    Closed                                         = 0,
    Error                                          = 1,
    Synchronized                                   = 2,
    Synchronizing                                  = 3,
    ECustomTimeStepSynchronizationState_MAX        = 4

};


// Enum  /Script/Engine.EMeshBufferAccess
enum class EMeshBufferAccess : uint8_t
{
    Default                                        = 0,
    ForceCPUAndGPU                                 = 1,
    EMeshBufferAccess_MAX                          = 2

};


// Enum  /Script/Engine.EComponentSocketType
enum class EComponentSocketType : uint8_t
{
    Invalid                                        = 0,
    Bone                                           = 1,
    Socket                                         = 2,
    EComponentSocketType_MAX                       = 3

};


// Enum  /Script/Engine.EPhysicalMaterialMaskColor
enum class EPhysicalMaterialMaskColor : uint8_t
{
    Red                                            = 0,
    Green                                          = 1,
    Blue                                           = 2,
    Cyan                                           = 3,
    Magenta                                        = 4,
    Yellow                                         = 5,
    White                                          = 6,
    Black                                          = 7,
    MAX                                            = 8

};


// Enum  /Script/Engine.EWalkableSlopeBehavior
enum class EWalkableSlopeBehavior : uint8_t
{
    WalkableSlope_Default                          = 0,
    WalkableSlope_Increase                         = 1,
    WalkableSlope_Decrease                         = 2,
    WalkableSlope_Unwalkable                       = 3,
    WalkableSlope_Max                              = 4

};


// Enum  /Script/Engine.EAutoPossessAI
enum class EAutoPossessAI : uint8_t
{
    Disabled                                       = 0,
    PlacedInWorld                                  = 1,
    Spawned                                        = 2,
    PlacedInWorldOrSpawned                         = 3,
    EAutoPossessAI_MAX                             = 4

};


// Enum  /Script/Engine.EUpdateRateShiftBucket
enum class EUpdateRateShiftBucket : uint8_t
{
    ShiftBucket0                                   = 0,
    ShiftBucket1                                   = 1,
    ShiftBucket2                                   = 2,
    ShiftBucket3                                   = 3,
    ShiftBucket4                                   = 4,
    ShiftBucket5                                   = 5,
    ShiftBucketMax                                 = 6,
    EUpdateRateShiftBucket_MAX                     = 7

};


// Enum  /Script/Engine.EShadowMapFlags
enum class EShadowMapFlags : uint8_t
{
    SMF_None                                       = 0,
    SMF_Streamed                                   = 1,
    SMF_MAX                                        = 2

};


// Enum  /Script/Engine.ELightMapPaddingType
enum class ELightMapPaddingType : uint8_t
{
    LMPT_NormalPadding                             = 0,
    LMPT_PrePadding                                = 1,
    LMPT_NoPadding                                 = 2,
    LMPT_MAX                                       = 3

};


// Enum  /Script/Engine.ETimelineSigType
enum class ETimelineSigType : uint8_t
{
    ETS_EventSignature                             = 0,
    ETS_FloatSignature                             = 1,
    ETS_VectorSignature                            = 2,
    ETS_LinearColorSignature                       = 3,
    ETS_InvalidSignature                           = 4,
    ETS_MAX                                        = 5

};


// Enum  /Script/Engine.EFilterInterpolationType
enum class EFilterInterpolationType : uint8_t
{
    BSIT_Average                                   = 0,
    BSIT_Linear                                    = 1,
    BSIT_Cubic                                     = 2,
    BSIT_MAX                                       = 3

};


// Enum  /Script/Engine.ECollisionResponse
enum class ECollisionResponse : uint8_t
{
    ECR_Ignore                                     = 0,
    ECR_Overlap                                    = 1,
    ECR_Block                                      = 2,
    ECR_MAX                                        = 3

};


// Enum  /Script/Engine.EOverlapFilterOption
enum class EOverlapFilterOption : uint8_t
{
    OverlapFilter_All                              = 0,
    OverlapFilter_DynamicOnly                      = 1,
    OverlapFilter_StaticOnly                       = 2,
    OverlapFilter_MAX                              = 3

};


// Enum  /Script/Engine.ENetworkSmoothingMode
enum class ENetworkSmoothingMode : uint8_t
{
    Disabled                                       = 0,
    Linear                                         = 1,
    Exponential                                    = 2,
    Replay                                         = 3,
    ENetworkSmoothingMode_MAX                      = 4

};


// Enum  /Script/Engine.ELightingBuildQuality
enum class ELightingBuildQuality : uint8_t
{
    Quality_Preview                                = 0,
    Quality_Medium                                 = 1,
    Quality_High                                   = 2,
    Quality_Production                             = 3,
    Quality_MAX                                    = 4

};


// Enum  /Script/Engine.EMaterialShadingRate
enum class EMaterialShadingRate : uint8_t
{
    MSR_1x1                                        = 0,
    MSR_2x1                                        = 1,
    MSR_1x2                                        = 2,
    MSR_2x2                                        = 3,
    MSR_4x2                                        = 4,
    MSR_2x4                                        = 5,
    MSR_4x4                                        = 6,
    MSR_Count                                      = 7,
    MSR_MAX                                        = 8

};


// Enum  /Script/Engine.EMaterialStencilCompare
enum class EMaterialStencilCompare : uint8_t
{
    MSC_Less                                       = 0,
    MSC_LessEqual                                  = 1,
    MSC_Greater                                    = 2,
    MSC_GreaterEqual                               = 3,
    MSC_Equal                                      = 4,
    MSC_NotEqual                                   = 5,
    MSC_Never                                      = 6,
    MSC_Always                                     = 7,
    MSC_Count                                      = 8,
    MSC_MAX                                        = 9

};


// Enum  /Script/Engine.EMaterialSamplerType
enum class EMaterialSamplerType : uint8_t
{
    SAMPLERTYPE_Color                              = 0,
    SAMPLERTYPE_Grayscale                          = 1,
    SAMPLERTYPE_Alpha                              = 2,
    SAMPLERTYPE_Normal                             = 3,
    SAMPLERTYPE_Masks                              = 4,
    SAMPLERTYPE_DistanceFieldFont                  = 5,
    SAMPLERTYPE_LinearColor                        = 6,
    SAMPLERTYPE_LinearGrayscale                    = 7,
    SAMPLERTYPE_Data                               = 8,
    SAMPLERTYPE_External                           = 9,
    SAMPLERTYPE_VirtualColor                       = 10,
    SAMPLERTYPE_VirtualGrayscale                   = 11,
    SAMPLERTYPE_VirtualAlpha                       = 12,
    SAMPLERTYPE_VirtualNormal                      = 13,
    SAMPLERTYPE_VirtualMasks                       = 14,
    SAMPLERTYPE_VirtualLinearColor                 = 15,
    SAMPLERTYPE_VirtualLinearGrayscale             = 16,
    SAMPLERTYPE_MAX                                = 17

};


// Enum  /Script/Engine.EMaterialTessellationMode
enum class EMaterialTessellationMode : uint8_t
{
    MTM_NoTessellation                             = 0,
    MTM_FlatTessellation                           = 1,
    MTM_PNTriangles                                = 2,
    MTM_MAX                                        = 3

};


// Enum  /Script/Engine.EMaterialShadingModel
enum class EMaterialShadingModel : uint8_t
{
    MSM_Unlit                                      = 0,
    MSM_DefaultLit                                 = 1,
    MSM_Subsurface                                 = 2,
    MSM_PreintegratedSkin                          = 3,
    MSM_ClearCoat                                  = 4,
    MSM_SubsurfaceProfile                          = 5,
    MSM_TwoSidedFoliage                            = 6,
    MSM_Hair                                       = 7,
    MSM_Cloth                                      = 8,
    MSM_Eye                                        = 9,
    MSM_SingleLayerWater                           = 10,
    MSM_ThinTranslucent                            = 11,
    MSM_ToonShading                                = 12,
    MSM_CodeVSM                                    = 13,
    MSM_SGSSSSkin                                  = 14,
    MSM_NUM                                        = 15,
    MSM_FromMaterialExpression                     = 16,
    MSM_MAX                                        = 17

};


// Enum  /Script/Engine.EParticleCollisionMode
enum class EParticleCollisionMode : uint8_t
{
    SceneDepth                                     = 0,
    DistanceField                                  = 1,
    EParticleCollisionMode_MAX                     = 2

};


// Enum  /Script/Engine.ETrailWidthMode
enum class ETrailWidthMode : uint8_t
{
    ETrailWidthMode_FromCentre                     = 0,
    ETrailWidthMode_FromFirst                      = 1,
    ETrailWidthMode_FromSecond                     = 2,
    ETrailWidthMode_MAX                            = 3

};


// Enum  /Script/Engine.EGBufferFormat
enum class EGBufferFormat : uint8_t
{
    Force8BitsPerChannel                           = 0,
    Default                                        = 1,
    HighPrecisionNormals                           = 3,
    Force16BitsPerChannel                          = 5,
    EGBufferFormat_MAX                             = 6

};


// Enum  /Script/Engine.ESceneCaptureCompositeMode
enum class ESceneCaptureCompositeMode : uint8_t
{
    SCCM_Overwrite                                 = 0,
    SCCM_Additive                                  = 1,
    SCCM_Composite                                 = 2,
    SCCM_MAX                                       = 3

};


// Enum  /Script/Engine.ESceneCaptureSource
enum class ESceneCaptureSource : uint8_t
{
    SCS_SceneColorHDR                              = 0,
    SCS_SceneColorHDRNoAlpha                       = 1,
    SCS_FinalColorLDR                              = 2,
    SCS_SceneColorSceneDepth                       = 3,
    SCS_SceneDepth                                 = 4,
    SCS_DeviceDepth                                = 5,
    SCS_Normal                                     = 6,
    SCS_BaseColor                                  = 7,
    SCS_FinalColorHDR                              = 8,
    SCS_FinalToneCurveHDR                          = 9,
    SCS_MAX                                        = 10

};


// Enum  /Script/Engine.ETranslucentSortPolicy
enum class ETranslucentSortPolicy : uint8_t
{
    SortByDistance                                 = 0,
    SortByProjectedZ                               = 1,
    SortAlongAxis                                  = 2,
    ETranslucentSortPolicy_MAX                     = 3

};


// Enum  /Script/Engine.ERefractionMode
enum class ERefractionMode : uint8_t
{
    RM_IndexOfRefraction                           = 0,
    RM_PixelNormalOffset                           = 1,
    RM_MAX                                         = 2

};


// Enum  /Script/Engine.ETranslucencyLightingMode
enum class ETranslucencyLightingMode : uint8_t
{
    TLM_VolumetricNonDirectional                   = 0,
    TLM_VolumetricDirectional                      = 1,
    TLM_VolumetricPerVertexNonDirectional          = 2,
    TLM_VolumetricPerVertexDirectional             = 3,
    TLM_Surface                                    = 4,
    TLM_SurfacePerPixelLighting                    = 5,
    TLM_MAX                                        = 6

};


// Enum  /Script/Engine.ESamplerSourceMode
enum class ESamplerSourceMode : uint8_t
{
    SSM_FromTextureAsset                           = 0,
    SSM_Wrap_WorldGroupSettings                    = 1,
    SSM_Clamp_WorldGroupSettings                   = 2,
    SSM_MAX                                        = 3

};


// Enum  /Script/Engine.EOcclusionCombineMode
enum class EOcclusionCombineMode : uint8_t
{
    OCM_Minimum                                    = 0,
    OCM_Multiply                                   = 1,
    OCM_MAX                                        = 2

};


// Enum  /Script/Engine.ELightmapType
enum class ELightmapType : uint8_t
{
    Default                                        = 0,
    ForceSurface                                   = 1,
    ForceVolumetric                                = 2,
    ELightmapType_MAX                              = 3

};


// Enum  /Script/Engine.EIndirectLightingCacheQuality
enum class EIndirectLightingCacheQuality : uint8_t
{
    ILCQ_Off                                       = 0,
    ILCQ_Point                                     = 1,
    ILCQ_Volume                                    = 2,
    ILCQ_MAX                                       = 3

};


// Enum  /Script/Engine.ESceneDepthPriorityGroup
enum class ESceneDepthPriorityGroup : uint8_t
{
    SDPG_World                                     = 0,
    SDPG_Foreground                                = 1,
    SDPG_MAX                                       = 2

};


// Enum  /Script/Engine.EAspectRatioAxisConstraint
enum class EAspectRatioAxisConstraint : uint8_t
{
    AspectRatio_MaintainYFOV                       = 0,
    AspectRatio_MaintainXFOV                       = 1,
    AspectRatio_MajorAxisFOV                       = 2,
    AspectRatio_MAX                                = 3

};


// Enum  /Script/Engine.EFontCacheType
enum class EFontCacheType : uint8_t
{
    Offline                                        = 0,
    Runtime                                        = 1,
    EFontCacheType_MAX                             = 2

};


// Enum  /Script/Engine.EFontImportCharacterSet
enum class EFontImportCharacterSet : uint8_t
{
    FontICS_Default                                = 0,
    FontICS_Ansi                                   = 1,
    FontICS_Symbol                                 = 2,
    FontICS_MAX                                    = 3

};


// Enum  /Script/Engine.EStandbyType
enum class EStandbyType : uint8_t
{
    STDBY_Rx                                       = 0,
    STDBY_Tx                                       = 1,
    STDBY_BadPing                                  = 2,
    STDBY_MAX                                      = 3

};


// Enum  /Script/Engine.ESuggestProjVelocityTraceOption
enum class ESuggestProjVelocityTraceOption : uint8_t
{
    DoNotTrace                                     = 0,
    TraceFullPath                                  = 1,
    OnlyTraceWhileAscending                        = 2,
    ESuggestProjVelocityTraceOption_MAX            = 3

};


// Enum  /Script/Engine.EWindowMode
enum class EWindowMode : uint8_t
{
    Fullscreen                                     = 0,
    WindowedFullscreen                             = 1,
    Windowed                                       = 2,
    EWindowMode_MAX                                = 3

};


// Enum  /Script/Engine.EHitProxyPriority
enum class EHitProxyPriority : uint8_t
{
    HPP_World                                      = 0,
    HPP_Wireframe                                  = 1,
    HPP_Foreground                                 = 2,
    HPP_UI                                         = 3,
    HPP_MAX                                        = 4

};


// Enum  /Script/Engine.EImportanceWeight
enum class EImportanceWeight : uint8_t
{
    Luminance                                      = 0,
    Red                                            = 1,
    Green                                          = 2,
    Blue                                           = 3,
    Alpha                                          = 4,
    EImportanceWeight_MAX                          = 5

};


// Enum  /Script/Engine.EAdManagerDelegate
enum class EAdManagerDelegate : uint8_t
{
    AMD_ClickedBanner                              = 0,
    AMD_UserClosedAd                               = 1,
    AMD_MAX                                        = 2

};


// Enum  /Script/Engine.EControllerAnalogStick
enum class EControllerAnalogStick : uint8_t
{
    CAS_LeftStick                                  = 0,
    CAS_RightStick                                 = 1,
    CAS_MAX                                        = 2

};


// Enum  /Script/Engine.EAnimAlphaInputType
enum class EAnimAlphaInputType : uint8_t
{
    Float                                          = 0,
    Bool                                           = 1,
    Curve                                          = 2,
    EAnimAlphaInputType_MAX                        = 3

};


// Enum  /Script/Engine.ETrackActiveCondition
enum class ETrackActiveCondition : uint8_t
{
    ETAC_Always                                    = 0,
    ETAC_GoreEnabled                               = 1,
    ETAC_GoreDisabled                              = 2,
    ETAC_MAX                                       = 3

};


// Enum  /Script/Engine.EInterpTrackMoveRotMode
enum class EInterpTrackMoveRotMode : uint8_t
{
    IMR_Keyframed                                  = 0,
    IMR_LookAtGroup                                = 1,
    IMR_Ignore                                     = 2,
    IMR_MAX                                        = 3

};


// Enum  /Script/Engine.EInterpMoveAxis
enum class EInterpMoveAxis : uint8_t
{
    AXIS_TranslationX                              = 0,
    AXIS_TranslationY                              = 1,
    AXIS_TranslationZ                              = 2,
    AXIS_RotationX                                 = 3,
    AXIS_RotationY                                 = 4,
    AXIS_RotationZ                                 = 5,
    AXIS_MAX                                       = 6

};


// Enum  /Script/Engine.ETrackToggleAction
enum class ETrackToggleAction : uint8_t
{
    ETTA_Off                                       = 0,
    ETTA_On                                        = 1,
    ETTA_Toggle                                    = 2,
    ETTA_Trigger                                   = 3,
    ETTA_MAX                                       = 4

};


// Enum  /Script/Engine.EVisibilityTrackCondition
enum class EVisibilityTrackCondition : uint8_t
{
    EVTC_Always                                    = 0,
    EVTC_GoreEnabled                               = 1,
    EVTC_GoreDisabled                              = 2,
    EVTC_MAX                                       = 3

};


// Enum  /Script/Engine.EVisibilityTrackAction
enum class EVisibilityTrackAction : uint8_t
{
    EVTA_Hide                                      = 0,
    EVTA_Show                                      = 1,
    EVTA_Toggle                                    = 2,
    EVTA_MAX                                       = 3

};


// Enum  /Script/Engine.ESlateGesture
enum class ESlateGesture : uint8_t
{
    None                                           = 0,
    Scroll                                         = 1,
    Magnify                                        = 2,
    Swipe                                          = 3,
    Rotate                                         = 4,
    LongPress                                      = 5,
    ESlateGesture_MAX                              = 6

};


// Enum  /Script/Engine.EMIDCreationFlags
enum class EMIDCreationFlags : uint8_t
{
    None                                           = 0,
    Transient                                      = 1,
    EMIDCreationFlags_MAX                          = 2

};


// Enum  /Script/Engine.EMatrixColumns
enum class EMatrixColumns : uint8_t
{
    First                                          = 0,
    Second                                         = 1,
    Third                                          = 2,
    Fourth                                         = 3,
    EMatrixColumns_MAX                             = 4

};


// Enum  /Script/Engine.ELerpInterpolationMode
enum class ELerpInterpolationMode : uint8_t
{
    QuatInterp                                     = 0,
    EulerInterp                                    = 1,
    DualQuatInterp                                 = 2,
    ELerpInterpolationMode_MAX                     = 3

};


// Enum  /Script/Engine.EEasingFunc
enum class EEasingFunc : uint8_t
{
    Linear                                         = 0,
    Step                                           = 1,
    SinusoidalIn                                   = 2,
    SinusoidalOut                                  = 3,
    SinusoidalInOut                                = 4,
    EaseIn                                         = 5,
    EaseOut                                        = 6,
    EaseInOut                                      = 7,
    ExpoIn                                         = 8,
    ExpoOut                                        = 9,
    ExpoInOut                                      = 10,
    CircularIn                                     = 11,
    CircularOut                                    = 12,
    CircularInOut                                  = 13,
    EEasingFunc_MAX                                = 14

};


// Enum  /Script/Engine.ERoundingMode
enum class ERoundingMode : uint8_t
{
    HalfToEven                                     = 0,
    HalfFromZero                                   = 1,
    HalfToZero                                     = 2,
    FromZero                                       = 3,
    ToZero                                         = 4,
    ToNegativeInfinity                             = 5,
    ToPositiveInfinity                             = 6,
    ERoundingMode_MAX                              = 7

};


// Enum  /Script/Engine.EStreamingVolumeUsage
enum class EStreamingVolumeUsage : uint8_t
{
    SVB_Loading                                    = 0,
    SVB_LoadingAndVisibility                       = 1,
    SVB_VisibilityBlockingOnLoad                   = 2,
    SVB_BlockingOnLoad                             = 3,
    SVB_LoadingNotVisible                          = 4,
    SVB_MAX                                        = 5

};


// Enum  /Script/Engine.ESyncOption
enum class ESyncOption : uint8_t
{
    Drive                                          = 0,
    Passive                                        = 1,
    Disabled                                       = 2,
    ESyncOption_MAX                                = 3

};


// Enum  /Script/Engine.EMaterialDecalResponse
enum class EMaterialDecalResponse : uint8_t
{
    MDR_None                                       = 0,
    MDR_ColorNormalRoughness                       = 1,
    MDR_Color                                      = 2,
    MDR_ColorNormal                                = 3,
    MDR_ColorRoughness                             = 4,
    MDR_Normal                                     = 5,
    MDR_NormalRoughness                            = 6,
    MDR_Roughness                                  = 7,
    MDR_MAX                                        = 8

};


// Enum  /Script/Engine.EDecalBlendMode
enum class EDecalBlendMode : uint8_t
{
    DBM_Translucent                                = 0,
    DBM_Stain                                      = 1,
    DBM_Normal                                     = 2,
    DBM_Emissive                                   = 3,
    DBM_DBuffer_ColorNormalRoughness               = 4,
    DBM_DBuffer_Color                              = 5,
    DBM_DBuffer_ColorNormal                        = 6,
    DBM_DBuffer_ColorRoughness                     = 7,
    DBM_DBuffer_Normal                             = 8,
    DBM_DBuffer_NormalRoughness                    = 9,
    DBM_DBuffer_Roughness                          = 10,
    DBM_DBuffer_Emissive                           = 11,
    DBM_DBuffer_AlphaComposite                     = 12,
    DBM_DBuffer_EmissiveAlphaComposite             = 13,
    DBM_Volumetric_DistanceFunction                = 14,
    DBM_AlphaComposite                             = 15,
    DBM_AmbientOcclusion                           = 16,
    DBM_MAX                                        = 17

};


// Enum  /Script/Engine.ETextureColorChannel
enum class ETextureColorChannel : uint8_t
{
    TCC_Red                                        = 0,
    TCC_Green                                      = 1,
    TCC_Blue                                       = 2,
    TCC_Alpha                                      = 3,
    TCC_MAX                                        = 4

};


// Enum  /Script/Engine.EMaterialAttributeBlend
enum class EMaterialAttributeBlend : uint8_t
{
    Blend                                          = 0,
    UseA                                           = 1,
    UseB                                           = 2,
    EMaterialAttributeBlend_MAX                    = 3

};


// Enum  /Script/Engine.EChannelMaskParameterColor
enum class EChannelMaskParameterColor : uint8_t
{
    Red                                            = 0,
    Green                                          = 1,
    Blue                                           = 2,
    Alpha                                          = 3,
    EChannelMaskParameterColor_MAX                 = 4

};


// Enum  /Script/Engine.EClampMode
enum class EClampMode : uint8_t
{
    CMODE_Clamp                                    = 0,
    CMODE_ClampMin                                 = 1,
    CMODE_ClampMax                                 = 2,
    CMODE_MAX                                      = 3

};


// Enum  /Script/Engine.ECustomMaterialOutputType
enum class ECustomMaterialOutputType : uint8_t
{
    CMOT_Float1                                    = 0,
    CMOT_Float2                                    = 1,
    CMOT_Float3                                    = 2,
    CMOT_Float4                                    = 3,
    CMOT_MaterialAttributes                        = 4,
    CMOT_MAX                                       = 5

};


// Enum  /Script/Engine.EDepthOfFieldFunctionValue
enum class EDepthOfFieldFunctionValue : uint8_t
{
    TDOF_NearAndFarMask                            = 0,
    TDOF_NearMask                                  = 1,
    TDOF_FarMask                                   = 2,
    TDOF_CircleOfConfusionRadius                   = 3,
    TDOF_MAX                                       = 4

};


// Enum  /Script/Engine.EFunctionInputType
enum class EFunctionInputType : uint8_t
{
    FunctionInput_Scalar                           = 0,
    FunctionInput_Vector2                          = 1,
    FunctionInput_Vector3                          = 2,
    FunctionInput_Vector4                          = 3,
    FunctionInput_Texture2D                        = 4,
    FunctionInput_TextureCube                      = 5,
    FunctionInput_Texture2DArray                   = 6,
    FunctionInput_VolumeTexture                    = 7,
    FunctionInput_StaticBool                       = 8,
    FunctionInput_MaterialAttributes               = 9,
    FunctionInput_TextureExternal                  = 10,
    FunctionInput_MAX                              = 11

};


// Enum  /Script/Engine.ENoiseFunction
enum class ENoiseFunction : uint8_t
{
    NOISEFUNCTION_SimplexTex                       = 0,
    NOISEFUNCTION_GradientTex                      = 1,
    NOISEFUNCTION_GradientTex3D                    = 2,
    NOISEFUNCTION_GradientALU                      = 3,
    NOISEFUNCTION_ValueALU                         = 4,
    NOISEFUNCTION_VoronoiALU                       = 5,
    NOISEFUNCTION_MAX                              = 6

};


// Enum  /Script/Engine.ERuntimeVirtualTextureTextureAddressMode
enum class ERuntimeVirtualTextureTextureAddressMode : uint8_t
{
    RVTTA_Clamp                                    = 0,
    RVTTA_Wrap                                     = 1,
    RVTTA_MAX                                      = 2

};


// Enum  /Script/Engine.ERuntimeVirtualTextureMipValueMode
enum class ERuntimeVirtualTextureMipValueMode : uint8_t
{
    RVTMVM_None                                    = 0,
    RVTMVM_MipLevel                                = 1,
    RVTMVM_MipBias                                 = 2,
    RVTMVM_MAX                                     = 3

};


// Enum  /Script/Engine.EMaterialSceneAttributeInputMode
enum class EMaterialSceneAttributeInputMode : uint8_t
{
    Coordinates                                    = 0,
    OffsetFraction                                 = 1,
    EMaterialSceneAttributeInputMode_MAX           = 2

};


// Enum  /Script/Engine.EMaterialScreenAttributeInputMode
enum class EMaterialScreenAttributeInputMode : uint8_t
{
    Coordinates                                    = 0,
    OffsetFraction                                 = 1,
    EMaterialScreenAttributeInputMode_MAX          = 2

};


// Enum  /Script/Engine.ESpeedTreeLODType
enum class ESpeedTreeLODType : uint8_t
{
    STLOD_Pop                                      = 0,
    STLOD_Smooth                                   = 1,
    STLOD_MAX                                      = 2

};


// Enum  /Script/Engine.ESpeedTreeWindType
enum class ESpeedTreeWindType : uint8_t
{
    STW_None                                       = 0,
    STW_Fastest                                    = 1,
    STW_Fast                                       = 2,
    STW_Better                                     = 3,
    STW_Best                                       = 4,
    STW_Palm                                       = 5,
    STW_BestPlus                                   = 6,
    STW_MAX                                        = 7

};


// Enum  /Script/Engine.ESpeedTreeGeometryType
enum class ESpeedTreeGeometryType : uint8_t
{
    STG_Branch                                     = 0,
    STG_Frond                                      = 1,
    STG_Leaf                                       = 2,
    STG_FacingLeaf                                 = 3,
    STG_Billboard                                  = 4,
    STG_MAX                                        = 5

};


// Enum  /Script/Engine.EMaterialExposedTextureProperty
enum class EMaterialExposedTextureProperty : uint8_t
{
    TMTM_TextureSize                               = 0,
    TMTM_TexelSize                                 = 1,
    TMTM_MAX                                       = 2

};


// Enum  /Script/Engine.ETextureMipValueMode
enum class ETextureMipValueMode : uint8_t
{
    TMVM_None                                      = 0,
    TMVM_MipLevel                                  = 1,
    TMVM_MipBias                                   = 2,
    TMVM_Derivative                                = 3,
    TMVM_MAX                                       = 4

};


// Enum  /Script/Engine.EMaterialVectorCoordTransform
enum class EMaterialVectorCoordTransform : uint8_t
{
    TRANSFORM_Tangent                              = 0,
    TRANSFORM_Local                                = 1,
    TRANSFORM_World                                = 2,
    TRANSFORM_View                                 = 3,
    TRANSFORM_Camera                               = 4,
    TRANSFORM_ParticleWorld                        = 5,
    TRANSFORM_MAX                                  = 6

};


// Enum  /Script/Engine.EMaterialVectorCoordTransformSource
enum class EMaterialVectorCoordTransformSource : uint8_t
{
    TRANSFORMSOURCE_Tangent                        = 0,
    TRANSFORMSOURCE_Local                          = 1,
    TRANSFORMSOURCE_World                          = 2,
    TRANSFORMSOURCE_View                           = 3,
    TRANSFORMSOURCE_Camera                         = 4,
    TRANSFORMSOURCE_ParticleWorld                  = 5,
    TRANSFORMSOURCE_MAX                            = 6

};


// Enum  /Script/Engine.EMaterialPositionTransformSource
enum class EMaterialPositionTransformSource : uint8_t
{
    TRANSFORMPOSSOURCE_Local                       = 0,
    TRANSFORMPOSSOURCE_World                       = 1,
    TRANSFORMPOSSOURCE_TranslatedWorld             = 2,
    TRANSFORMPOSSOURCE_View                        = 3,
    TRANSFORMPOSSOURCE_Camera                      = 4,
    TRANSFORMPOSSOURCE_Particle                    = 5,
    TRANSFORMPOSSOURCE_MAX                         = 6

};


// Enum  /Script/Engine.EVectorNoiseFunction
enum class EVectorNoiseFunction : uint8_t
{
    VNF_CellnoiseALU                               = 0,
    VNF_VectorALU                                  = 1,
    VNF_GradientALU                                = 2,
    VNF_CurlALU                                    = 3,
    VNF_VoronoiALU                                 = 4,
    VNF_MAX                                        = 5

};


// Enum  /Script/Engine.EMaterialExposedViewProperty
enum class EMaterialExposedViewProperty : uint8_t
{
    MEVP_BufferSize                                = 0,
    MEVP_FieldOfView                               = 1,
    MEVP_TanHalfFieldOfView                        = 2,
    MEVP_TanHalfFieldOfViewFPP                     = 3,
    MEVP_ViewSize                                  = 4,
    MEVP_WorldSpaceViewPosition                    = 5,
    MEVP_WorldSpaceCameraPosition                  = 6,
    MEVP_ViewportOffset                            = 7,
    MEVP_TemporalSampleCount                       = 8,
    MEVP_TemporalSampleIndex                       = 9,
    MEVP_TemporalSampleOffset                      = 10,
    MEVP_RuntimeVirtualTextureOutputLevel          = 11,
    MEVP_RuntimeVirtualTextureOutputDerivative     = 12,
    MEVP_PreExposure                               = 13,
    MEVP_RuntimeVirtualTextureMaxLevel             = 14,
    MEVP_IsUsePaniniInVS                           = 15,
    MEVP_MAX                                       = 16

};


// Enum  /Script/Engine.EWorldPositionIncludedOffsets
enum class EWorldPositionIncludedOffsets : uint8_t
{
    WPT_Default                                    = 0,
    WPT_ExcludeAllShaderOffsets                    = 1,
    WPT_CameraRelative                             = 2,
    WPT_CameraRelativeNoOffsets                    = 3,
    WPT_RawLocalPosition                           = 4,
    WPT_MAX                                        = 5

};


// Enum  /Script/Engine.EDynamicBranchMaterialOutputType
enum class EDynamicBranchMaterialOutputType : uint8_t
{
    DBMOT_Float1                                   = 0,
    DBMOT_Float2                                   = 1,
    DBMOT_Float3                                   = 2,
    DBMOT_Float4                                   = 3,
    DBMOT_MAX                                      = 4

};


// Enum  /Script/Engine.EMaterialFunctionUsage
enum class EMaterialFunctionUsage : uint8_t
{
    Default                                        = 0,
    MaterialLayer                                  = 1,
    MaterialLayerBlend                             = 2,
    EMaterialFunctionUsage_MAX                     = 3

};


// Enum  /Script/Engine.EMaterialUsage
enum class EMaterialUsage : uint8_t
{
    MATUSAGE_SkeletalMesh                          = 0,
    MATUSAGE_ParticleSprites                       = 1,
    MATUSAGE_BeamTrails                            = 2,
    MATUSAGE_MeshParticles                         = 3,
    MATUSAGE_StaticLighting                        = 4,
    MATUSAGE_MorphTargets                          = 5,
    MATUSAGE_SplineMesh                            = 6,
    MATUSAGE_InstancedStaticMeshes                 = 7,
    MATUSAGE_GeometryCollections                   = 8,
    MATUSAGE_Clothing                              = 9,
    MATUSAGE_NiagaraSprites                        = 10,
    MATUSAGE_NiagaraRibbons                        = 11,
    MATUSAGE_NiagaraMeshParticles                  = 12,
    MATUSAGE_GeometryCache                         = 13,
    MATUSAGE_Water                                 = 14,
    MATUSAGE_HairStrands                           = 15,
    MATUSAGE_LidarPointCloud                       = 16,
    MATUSAGE_VirtualHeightfieldMesh                = 17,
    MATUSAGE_Reveal                                = 18,
    MATUSAGE_MAX                                   = 19

};


// Enum  /Script/Engine.EMaterialLayerLinkState
enum class EMaterialLayerLinkState : uint8_t
{
    Uninitialized                                  = 0,
    LinkedToParent                                 = 1,
    UnlinkedFromParent                             = 2,
    NotFromParent                                  = 3,
    EMaterialLayerLinkState_MAX                    = 4

};


// Enum  /Script/Engine.EMaterialParameterAssociation
enum class EMaterialParameterAssociation : uint8_t
{
    LayerParameter                                 = 0,
    BlendParameter                                 = 1,
    GlobalParameter                                = 2,
    EMaterialParameterAssociation_MAX              = 3

};


// Enum  /Script/Engine.EMaterialMergeType
enum class EMaterialMergeType : uint8_t
{
    MaterialMergeType_Default                      = 0,
    MaterialMergeType_Simplygon                    = 1,
    MaterialMergeType_MAX                          = 2

};


// Enum  /Script/Engine.ETextureSizingType
enum class ETextureSizingType : uint8_t
{
    TextureSizingType_UseSingleTextureSize         = 0,
    TextureSizingType_UseAutomaticBiasedSizes      = 1,
    TextureSizingType_UseManualOverrideTextureSize = 2,
    TextureSizingType_UseSimplygonAutomaticSizing  = 3,
    TextureSizingType_AutomaticFromTexelDensity    = 4,
    TextureSizingType_AutomaticFromMeshScreenSize  = 5,
    TextureSizingType_AutomaticFromMeshDrawDistance = 6,
    TextureSizingType_MAX                          = 7

};


// Enum  /Script/Engine.ESceneTextureId
enum class ESceneTextureId : uint8_t
{
    PPI_SceneColor                                 = 0,
    PPI_SceneDepth                                 = 1,
    PPI_DiffuseColor                               = 2,
    PPI_SpecularColor                              = 3,
    PPI_SubsurfaceColor                            = 4,
    PPI_BaseColor                                  = 5,
    PPI_Specular                                   = 6,
    PPI_Metallic                                   = 7,
    PPI_WorldNormal                                = 8,
    PPI_SeparateTranslucency                       = 9,
    PPI_Opacity                                    = 10,
    PPI_Roughness                                  = 11,
    PPI_MaterialAO                                 = 12,
    PPI_CustomDepth                                = 13,
    PPI_PostProcessInput0                          = 14,
    PPI_PostProcessInput1                          = 15,
    PPI_PostProcessInput2                          = 16,
    PPI_PostProcessInput3                          = 17,
    PPI_PostProcessInput4                          = 18,
    PPI_PostProcessInput5                          = 19,
    PPI_PostProcessInput6                          = 20,
    PPI_DecalMask                                  = 21,
    PPI_ShadingModelColor                          = 22,
    PPI_ShadingModelID                             = 23,
    PPI_AmbientOcclusion                           = 24,
    PPI_CustomStencil                              = 25,
    PPI_StoredBaseColor                            = 26,
    PPI_StoredSpecular                             = 27,
    PPI_Velocity                                   = 28,
    PPI_WorldTangent                               = 29,
    PPI_Anisotropy                                 = 30,
    PPI_MAX                                        = 31

};


// Enum  /Script/Engine.EMaterialDomain
enum class EMaterialDomain : uint8_t
{
    MD_Surface                                     = 0,
    MD_DeferredDecal                               = 1,
    MD_LightFunction                               = 2,
    MD_Volume                                      = 3,
    MD_PostProcess                                 = 4,
    MD_UI                                          = 5,
    MD_RuntimeVirtualTexture                       = 6,
    MD_UIPostProcess                               = 7,
    MD_MAX                                         = 8

};


// Enum  /Script/Engine.EMeshInstancingReplacementMethod
enum class EMeshInstancingReplacementMethod : uint8_t
{
    RemoveOriginalActors                           = 0,
    KeepOriginalActorsAsEditorOnly                 = 1,
    EMeshInstancingReplacementMethod_MAX           = 2

};


// Enum  /Script/Engine.EUVOutput
enum class EUVOutput : uint8_t
{
    DoNotOutputChannel                             = 0,
    OutputChannel                                  = 1,
    EUVOutput_MAX                                  = 2

};


// Enum  /Script/Engine.EMeshMergeType
enum class EMeshMergeType : uint8_t
{
    MeshMergeType_Default                          = 0,
    MeshMergeType_MergeActor                       = 1,
    MeshMergeType_MAX                              = 2

};


// Enum  /Script/Engine.EMeshLODSelectionType
enum class EMeshLODSelectionType : uint8_t
{
    AllLODs                                        = 0,
    SpecificLOD                                    = 1,
    CalculateLOD                                   = 2,
    LowestDetailLOD                                = 3,
    EMeshLODSelectionType_MAX                      = 4

};


// Enum  /Script/Engine.EProxyNormalComputationMethod
enum class EProxyNormalComputationMethod : uint8_t
{
    AngleWeighted                                  = 0,
    AreaWeighted                                   = 1,
    EqualWeighted                                  = 2,
    EProxyNormalComputationMethod_MAX              = 3

};


// Enum  /Script/Engine.ELandscapeCullingPrecision
enum class ELandscapeCullingPrecision : uint8_t
{
    High                                           = 0,
    Medium                                         = 1,
    Low                                            = 2,
    ELandscapeCullingPrecision_MAX                 = 3

};


// Enum  /Script/Engine.EStaticMeshReductionTerimationCriterion
enum class EStaticMeshReductionTerimationCriterion : uint8_t
{
    Triangles                                      = 0,
    Vertices                                       = 1,
    Any                                            = 2,
    EStaticMeshReductionTerimationCriterion_MAX    = 3

};


// Enum  /Script/Engine.EMeshFeatureImportance
enum class EMeshFeatureImportance : uint8_t
{
    Off                                            = 0,
    Lowest                                         = 1,
    Low                                            = 2,
    Normal                                         = 3,
    High                                           = 4,
    Highest                                        = 5,
    EMeshFeatureImportance_MAX                     = 6

};


// Enum  /Script/Engine.EVertexPaintAxis
enum class EVertexPaintAxis : uint8_t
{
    X                                              = 0,
    Y                                              = 1,
    Z                                              = 2,
    EVertexPaintAxis_MAX                           = 3

};


// Enum  /Script/Engine.EMicroTransactionResult
enum class EMicroTransactionResult : uint8_t
{
    MTR_Succeeded                                  = 0,
    MTR_Failed                                     = 1,
    MTR_Canceled                                   = 2,
    MTR_RestoredFromServer                         = 3,
    MTR_MAX                                        = 4

};


// Enum  /Script/Engine.EMicroTransactionDelegate
enum class EMicroTransactionDelegate : uint8_t
{
    MTD_PurchaseQueryComplete                      = 0,
    MTD_PurchaseComplete                           = 1,
    MTD_MAX                                        = 2

};


// Enum  /Script/Engine.FNavigationSystemRunMode
enum class FNavigationSystemRunMode : uint8_t
{
    InvalidMode                                    = 0,
    GameMode                                       = 1,
    EditorMode                                     = 2,
    SimulationMode                                 = 3,
    PIEMode                                        = 4,
    InferFromWorldMode                             = 5,
    FNavigationSystemRunMode_MAX                   = 6

};


// Enum  /Script/Engine.ENavigationQueryResult
enum class ENavigationQueryResult : uint8_t
{
    Invalid                                        = 0,
    Error                                          = 1,
    Fail                                           = 2,
    Success                                        = 3,
    ENavigationQueryResult_MAX                     = 4

};


// Enum  /Script/Engine.ENavPathEvent
enum class ENavPathEvent : uint8_t
{
    Cleared                                        = 0,
    NewPath                                        = 1,
    UpdatedDueToGoalMoved                          = 2,
    UpdatedDueToNavigationChanged                  = 3,
    Invalidated                                    = 4,
    RePathFailed                                   = 5,
    MetaPathUpdate                                 = 6,
    Custom                                         = 7,
    ENavPathEvent_MAX                              = 8

};


// Enum  /Script/Engine.ENavDataGatheringModeConfig
enum class ENavDataGatheringModeConfig : uint8_t
{
    Invalid                                        = 0,
    Instant                                        = 1,
    Lazy                                           = 2,
    ENavDataGatheringModeConfig_MAX                = 3

};


// Enum  /Script/Engine.ENavDataGatheringMode
enum class ENavDataGatheringMode : uint8_t
{
    Default                                        = 0,
    Instant                                        = 1,
    Lazy                                           = 2,
    ENavDataGatheringMode_MAX                      = 3

};


// Enum  /Script/Engine.ENavigationOptionFlag
enum class ENavigationOptionFlag : uint8_t
{
    Default                                        = 0,
    Enable                                         = 1,
    Disable                                        = 2,
    MAX                                            = 3

};


// Enum  /Script/Engine.ENavLadderType
enum class ENavLadderType : uint8_t
{
    Vertical                                       = 0,
    Horizontal                                     = 1,
    ENavLadderType_MAX                             = 2

};


// Enum  /Script/Engine.ENavLinkDirection
enum class ENavLinkDirection : uint8_t
{
    BothWays                                       = 0,
    LeftToRight                                    = 1,
    RightToLeft                                    = 2,
    ENavLinkDirection_MAX                          = 3

};


// Enum  /Script/Engine.ENavObstacleType
enum class ENavObstacleType : uint8_t
{
    OrientedBox                                    = 0,
    Sphere                                         = 1,
    ENavObstacleType_MAX                           = 2

};


// Enum  /Script/Engine.NavQueryFilterGraphFlag
enum class NavQueryFilterGraphFlag : uint8_t
{
    None                                           = 0,
    Main                                           = 1,
    WithSecondaryJump                              = 2,
    Core                                           = 3,
    NavQueryFilterGraphFlag_MAX                    = 4

};


// Enum  /Script/Engine.EEmitterRenderMode
enum class EEmitterRenderMode : uint8_t
{
    ERM_Normal                                     = 0,
    ERM_Point                                      = 1,
    ERM_Cross                                      = 2,
    ERM_LightsOnly                                 = 3,
    ERM_None                                       = 4,
    ERM_MAX                                        = 5

};


// Enum  /Script/Engine.EParticleSubUVInterpMethod
enum class EParticleSubUVInterpMethod : uint8_t
{
    PSUVIM_None                                    = 0,
    PSUVIM_Linear                                  = 1,
    PSUVIM_Linear_Blend                            = 2,
    PSUVIM_Random                                  = 3,
    PSUVIM_Random_Blend                            = 4,
    PSUVIM_MAX                                     = 5

};


// Enum  /Script/Engine.EParticleBurstMethod
enum class EParticleBurstMethod : uint8_t
{
    EPBM_Instant                                   = 0,
    EPBM_Interpolated                              = 1,
    EPBM_MAX                                       = 2

};


// Enum  /Script/Engine.EParticleSystemInsignificanceReaction
enum class EParticleSystemInsignificanceReaction : uint8_t
{
    Auto                                           = 0,
    Complete                                       = 1,
    DisableTick                                    = 2,
    DisableTickAndKill                             = 3,
    Num                                            = 4,
    EParticleSystemInsignificanceReaction_MAX      = 5

};


// Enum  /Script/Engine.EParticleSignificanceLevel
enum class EParticleSignificanceLevel : uint8_t
{
    Low                                            = 0,
    Medium                                         = 1,
    High                                           = 2,
    Critical                                       = 3,
    Num                                            = 4,
    EParticleSignificanceLevel_MAX                 = 5

};


// Enum  /Script/Engine.EParticleDetailMode
enum class EParticleDetailMode : uint8_t
{
    PDM_Low                                        = 0,
    PDM_Medium                                     = 1,
    PDM_High                                       = 2,
    PDM_MAX                                        = 3

};


// Enum  /Script/Engine.EParticleSourceSelectionMethod
enum class EParticleSourceSelectionMethod : uint8_t
{
    EPSSM_Random                                   = 0,
    EPSSM_Sequential                               = 1,
    EPSSM_MAX                                      = 2

};


// Enum  /Script/Engine.EModuleType
enum class EModuleType : uint8_t
{
    EPMT_General                                   = 0,
    EPMT_TypeData                                  = 1,
    EPMT_Beam                                      = 2,
    EPMT_Trail                                     = 3,
    EPMT_Spawn                                     = 4,
    EPMT_Required                                  = 5,
    EPMT_Event                                     = 6,
    EPMT_Light                                     = 7,
    EPMT_SubUV                                     = 8,
    EPMT_MAX                                       = 9

};


// Enum  /Script/Engine.EAttractorParticleSelectionMethod
enum class EAttractorParticleSelectionMethod : uint8_t
{
    EAPSM_Random                                   = 0,
    EAPSM_Sequential                               = 1,
    EAPSM_MAX                                      = 2

};


// Enum  /Script/Engine.Beam2SourceTargetTangentMethod
enum class Beam2SourceTargetTangentMethod : uint8_t
{
    PEB2STTM_Direct                                = 0,
    PEB2STTM_UserSet                               = 1,
    PEB2STTM_Distribution                          = 2,
    PEB2STTM_Emitter                               = 3,
    PEB2STTM_MAX                                   = 4

};


// Enum  /Script/Engine.Beam2SourceTargetMethod
enum class Beam2SourceTargetMethod : uint8_t
{
    PEB2STM_Default                                = 0,
    PEB2STM_UserSet                                = 1,
    PEB2STM_Emitter                                = 2,
    PEB2STM_Particle                               = 3,
    PEB2STM_Actor                                  = 4,
    PEB2STM_MAX                                    = 5

};


// Enum  /Script/Engine.BeamModifierType
enum class BeamModifierType : uint8_t
{
    PEB2MT_Source                                  = 0,
    PEB2MT_Target                                  = 1,
    PEB2MT_MAX                                     = 2

};


// Enum  /Script/Engine.EParticleCameraOffsetUpdateMethod
enum class EParticleCameraOffsetUpdateMethod : uint8_t
{
    EPCOUM_DirectSet                               = 0,
    EPCOUM_Additive                                = 1,
    EPCOUM_Scalar                                  = 2,
    EPCOUM_MAX                                     = 3

};


// Enum  /Script/Engine.EParticleCollisionComplete
enum class EParticleCollisionComplete : uint8_t
{
    EPCC_Kill                                      = 0,
    EPCC_Freeze                                    = 1,
    EPCC_HaltCollisions                            = 2,
    EPCC_FreezeTranslation                         = 3,
    EPCC_FreezeRotation                            = 4,
    EPCC_FreezeMovement                            = 5,
    EPCC_MAX                                       = 6

};


// Enum  /Script/Engine.EParticleCollisionResponse
enum class EParticleCollisionResponse : uint8_t
{
    Bounce                                         = 0,
    Stop                                           = 1,
    Kill                                           = 2,
    EParticleCollisionResponse_MAX                 = 3

};


// Enum  /Script/Engine.ELocationBoneSocketSelectionMethod
enum class ELocationBoneSocketSelectionMethod : uint8_t
{
    BONESOCKETSEL_Sequential                       = 0,
    BONESOCKETSEL_Random                           = 1,
    BONESOCKETSEL_MAX                              = 2

};


// Enum  /Script/Engine.ELocationBoneSocketSource
enum class ELocationBoneSocketSource : uint8_t
{
    BONESOCKETSOURCE_Bones                         = 0,
    BONESOCKETSOURCE_Sockets                       = 1,
    BONESOCKETSOURCE_MAX                           = 2

};


// Enum  /Script/Engine.ELocationEmitterSelectionMethod
enum class ELocationEmitterSelectionMethod : uint8_t
{
    ELESM_Random                                   = 0,
    ELESM_Sequential                               = 1,
    ELESM_MAX                                      = 2

};


// Enum  /Script/Engine.CylinderHeightAxis
enum class CylinderHeightAxis : uint8_t
{
    PMLPC_HEIGHTAXIS_X                             = 0,
    PMLPC_HEIGHTAXIS_Y                             = 1,
    PMLPC_HEIGHTAXIS_Z                             = 2,
    PMLPC_HEIGHTAXIS_MAX                           = 3

};


// Enum  /Script/Engine.ELocationSkelVertSurfaceSource
enum class ELocationSkelVertSurfaceSource : uint8_t
{
    VERTSURFACESOURCE_Vert                         = 0,
    VERTSURFACESOURCE_Surface                      = 1,
    VERTSURFACESOURCE_MAX                          = 2

};


// Enum  /Script/Engine.EOrbitChainMode
enum class EOrbitChainMode : uint8_t
{
    EOChainMode_Add                                = 0,
    EOChainMode_Scale                              = 1,
    EOChainMode_Link                               = 2,
    EOChainMode_MAX                                = 3

};


// Enum  /Script/Engine.EParticleAxisLock
enum class EParticleAxisLock : uint8_t
{
    EPAL_NONE                                      = 0,
    EPAL_X                                         = 1,
    EPAL_Y                                         = 2,
    EPAL_Z                                         = 3,
    EPAL_NEGATIVE_X                                = 4,
    EPAL_NEGATIVE_Y                                = 5,
    EPAL_NEGATIVE_Z                                = 6,
    EPAL_ROTATE_X                                  = 7,
    EPAL_ROTATE_Y                                  = 8,
    EPAL_ROTATE_Z                                  = 9,
    EPAL_MAX                                       = 10

};


// Enum  /Script/Engine.EEmitterDynamicParameterValue
enum class EEmitterDynamicParameterValue : uint8_t
{
    EDPV_UserSet                                   = 0,
    EDPV_AutoSet                                   = 1,
    EDPV_VelocityX                                 = 2,
    EDPV_VelocityY                                 = 3,
    EDPV_VelocityZ                                 = 4,
    EDPV_VelocityMag                               = 5,
    EDPV_MAX                                       = 6

};


// Enum  /Script/Engine.EEmitterNormalsMode
enum class EEmitterNormalsMode : uint8_t
{
    ENM_CameraFacing                               = 0,
    ENM_Spherical                                  = 1,
    ENM_Cylindrical                                = 2,
    ENM_MAX                                        = 3

};


// Enum  /Script/Engine.EParticleSortMode
enum class EParticleSortMode : uint8_t
{
    PSORTMODE_None                                 = 0,
    PSORTMODE_ViewProjDepth                        = 1,
    PSORTMODE_DistanceToView                       = 2,
    PSORTMODE_Age_OldestFirst                      = 3,
    PSORTMODE_Age_NewestFirst                      = 4,
    PSORTMODE_MAX                                  = 5

};


// Enum  /Script/Engine.EParticleUVFlipMode
enum class EParticleUVFlipMode : uint8_t
{
    None                                           = 0,
    FlipUV                                         = 1,
    FlipUOnly                                      = 2,
    FlipVOnly                                      = 3,
    RandomFlipUV                                   = 4,
    RandomFlipUOnly                                = 5,
    RandomFlipVOnly                                = 6,
    RandomFlipUVIndependent                        = 7,
    EParticleUVFlipMode_MAX                        = 8

};


// Enum  /Script/Engine.ETrail2SourceMethod
enum class ETrail2SourceMethod : uint8_t
{
    PET2SRCM_Default                               = 0,
    PET2SRCM_Particle                              = 1,
    PET2SRCM_Actor                                 = 2,
    PET2SRCM_MAX                                   = 3

};


// Enum  /Script/Engine.EBeamTaperMethod
enum class EBeamTaperMethod : uint8_t
{
    PEBTM_None                                     = 0,
    PEBTM_Full                                     = 1,
    PEBTM_Partial                                  = 2,
    PEBTM_MAX                                      = 3

};


// Enum  /Script/Engine.EBeam2Method
enum class EBeam2Method : uint8_t
{
    PEB2M_Distance                                 = 0,
    PEB2M_Target                                   = 1,
    PEB2M_Branch                                   = 2,
    PEB2M_MAX                                      = 3

};


// Enum  /Script/Engine.EMeshCameraFacingOptions
enum class EMeshCameraFacingOptions : uint8_t
{
    XAxisFacing_NoUp                               = 0,
    XAxisFacing_ZUp                                = 1,
    XAxisFacing_NegativeZUp                        = 2,
    XAxisFacing_YUp                                = 3,
    XAxisFacing_NegativeYUp                        = 4,
    LockedAxis_ZAxisFacing                         = 5,
    LockedAxis_NegativeZAxisFacing                 = 6,
    LockedAxis_YAxisFacing                         = 7,
    LockedAxis_NegativeYAxisFacing                 = 8,
    VelocityAligned_ZAxisFacing                    = 9,
    VelocityAligned_NegativeZAxisFacing            = 10,
    VelocityAligned_YAxisFacing                    = 11,
    VelocityAligned_NegativeYAxisFacing            = 12,
    EMeshCameraFacingOptions_MAX                   = 13

};


// Enum  /Script/Engine.EMeshCameraFacingUpAxis
enum class EMeshCameraFacingUpAxis : uint8_t
{
    CameraFacing_NoneUP                            = 0,
    CameraFacing_ZUp                               = 1,
    CameraFacing_NegativeZUp                       = 2,
    CameraFacing_YUp                               = 3,
    CameraFacing_NegativeYUp                       = 4,
    CameraFacing_MAX                               = 5

};


// Enum  /Script/Engine.EMeshScreenAlignment
enum class EMeshScreenAlignment : uint8_t
{
    PSMA_MeshFaceCameraWithRoll                    = 0,
    PSMA_MeshFaceCameraWithSpin                    = 1,
    PSMA_MeshFaceCameraWithLockedAxis              = 2,
    PSMA_MAX                                       = 3

};


// Enum  /Script/Engine.ETrailsRenderAxisOption
enum class ETrailsRenderAxisOption : uint8_t
{
    Trails_CameraUp                                = 0,
    Trails_SourceUp                                = 1,
    Trails_WorldUp                                 = 2,
    Trails_MAX                                     = 3

};


// Enum  /Script/Engine.EParticleScreenAlignment
enum class EParticleScreenAlignment : uint8_t
{
    PSA_FacingCameraPosition                       = 0,
    PSA_Square                                     = 1,
    PSA_Rectangle                                  = 2,
    PSA_Velocity                                   = 3,
    PSA_AwayFromCenter                             = 4,
    PSA_TypeSpecific                               = 5,
    PSA_FacingCameraDistanceBlend                  = 6,
    PSA_MAX                                        = 7

};


// Enum  /Script/Engine.EParticleSystemOcclusionBoundsMethod
enum class EParticleSystemOcclusionBoundsMethod : uint8_t
{
    EPSOBM_None                                    = 0,
    EPSOBM_ParticleBounds                          = 1,
    EPSOBM_CustomBounds                            = 2,
    EPSOBM_MAX                                     = 3

};


// Enum  /Script/Engine.ParticleSystemLODMethod
enum class ParticleSystemLODMethod : uint8_t
{
    PARTICLESYSTEMLODMETHOD_Automatic              = 0,
    PARTICLESYSTEMLODMETHOD_DirectSet              = 1,
    PARTICLESYSTEMLODMETHOD_ActivateAutomatic      = 2,
    PARTICLESYSTEMLODMETHOD_MAX                    = 3

};


// Enum  /Script/Engine.EParticleSystemUpdateMode
enum class EParticleSystemUpdateMode : uint8_t
{
    EPSUM_RealTime                                 = 0,
    EPSUM_FixedTime                                = 1,
    EPSUM_MAX                                      = 2

};


// Enum  /Script/Engine.EParticleEventType
enum class EParticleEventType : uint8_t
{
    EPET_Any                                       = 0,
    EPET_Spawn                                     = 1,
    EPET_Death                                     = 2,
    EPET_Collision                                 = 3,
    EPET_Burst                                     = 4,
    EPET_Blueprint                                 = 5,
    EPET_MAX                                       = 6

};


// Enum  /Script/Engine.ParticleReplayState
enum class ParticleReplayState : uint8_t
{
    PRS_Disabled                                   = 0,
    PRS_Capturing                                  = 1,
    PRS_Replaying                                  = 2,
    PRS_MAX                                        = 3

};


// Enum  /Script/Engine.EParticleSysParamType
enum class EParticleSysParamType : uint8_t
{
    PSPT_None                                      = 0,
    PSPT_Scalar                                    = 1,
    PSPT_ScalarRand                                = 2,
    PSPT_Vector                                    = 3,
    PSPT_VectorRand                                = 4,
    PSPT_Color                                     = 5,
    PSPT_Actor                                     = 6,
    PSPT_Material                                  = 7,
    PSPT_VectorUnitRand                            = 8,
    PSPT_MAX                                       = 9

};


// Enum  /Script/Engine.ESettingsLockedAxis
enum class ESettingsLockedAxis : uint8_t
{
    None                                           = 0,
    X                                              = 1,
    Y                                              = 2,
    Z                                              = 3,
    Invalid                                        = 4,
    ESettingsLockedAxis_MAX                        = 5

};


// Enum  /Script/Engine.ESettingsDOF
enum class ESettingsDOF : uint8_t
{
    Full3D                                         = 0,
    YZPlane                                        = 1,
    XZPlane                                        = 2,
    XYPlane                                        = 3,
    ESettingsDOF_MAX                               = 4

};


// Enum  /Script/Engine.EViewTargetBlendFunction
enum class EViewTargetBlendFunction : uint8_t
{
    VTBlend_Linear                                 = 0,
    VTBlend_Cubic                                  = 1,
    VTBlend_EaseIn                                 = 2,
    VTBlend_EaseOut                                = 3,
    VTBlend_EaseInOut                              = 4,
    VTBlend_MAX                                    = 5

};


// Enum  /Script/Engine.EDynamicForceFeedbackAction
enum class EDynamicForceFeedbackAction : uint8_t
{
    Start                                          = 0,
    Update                                         = 1,
    Stop                                           = 2,
    EDynamicForceFeedbackAction_MAX                = 3

};


// Enum  /Script/Engine.ETranslucencyLayer
enum class ETranslucencyLayer : uint8_t
{
    Layer0                                         = 0,
    Layer1                                         = 1,
    Layer2                                         = 2,
    Layer3                                         = 3,
    Layer4                                         = 4,
    Layer5                                         = 5,
    Layer6                                         = 6,
    Layer_MAX                                      = 7,
    ETranslucencyLayer_MAX                         = 8

};


// Enum  /Script/Engine.EScreenVFXOperator
enum class EScreenVFXOperator : uint8_t
{
    Less                                           = 0,
    LessEqual                                      = 1,
    Greater                                        = 2,
    GreaterEqual                                   = 3,
    Equal                                          = 4,
    NotEqual                                       = 5,
    EScreenVFXOperator_MAX                         = 6

};


// Enum  /Script/Engine.EScreenVFXLayer
enum class EScreenVFXLayer : uint8_t
{
    BeforeRevealed                                 = 0,
    AfterRevealed                                  = 1,
    EScreenVFXLayer_MAX                            = 2

};


// Enum  /Script/Engine.ERendererStencilMask
enum class ERendererStencilMask : uint8_t
{
    ERSM_Default                                   = 0,
    ERSM                                           = 1,
    ERSM                                           = 2,
    ERSM                                           = 3,
    ERSM                                           = 4,
    ERSM                                           = 5,
    ERSM                                           = 6,
    ERSM                                           = 7,
    ERSM                                           = 8,
    ERSM                                           = 9,
    ERSM_MAX                                       = 10

};


// Enum  /Script/Engine.EHasCustomNavigableGeometry
enum class EHasCustomNavigableGeometry : uint8_t
{
    No                                             = 0,
    Yes                                            = 1,
    EvenIfNotCollidable                            = 2,
    DontExport                                     = 3,
    EHasCustomNavigableGeometry_MAX                = 4

};


// Enum  /Script/Engine.ECanBeCharacterBase
enum class ECanBeCharacterBase : uint8_t
{
    ECB_No                                         = 0,
    ECB_Yes                                        = 1,
    ECB_Owner                                      = 2,
    ECB_MAX                                        = 3

};


// Enum  /Script/Engine.EQuarztQuantizationReference
enum class EQuarztQuantizationReference : uint8_t
{
    BarRelative                                    = 0,
    TransportRelative                              = 1,
    CurrentTimeRelative                            = 2,
    Count                                          = 3,
    EQuarztQuantizationReference_MAX               = 4

};


// Enum  /Script/Engine.EQuartzDelegateType
enum class EQuartzDelegateType : uint8_t
{
    MetronomeTick                                  = 0,
    CommandEvent                                   = 1,
    Count                                          = 2,
    EQuartzDelegateType_MAX                        = 3

};


// Enum  /Script/Engine.EQuartzTimeSignatureQuantization
enum class EQuartzTimeSignatureQuantization : uint8_t
{
    HalfNote                                       = 0,
    QuarterNote                                    = 1,
    EighthNote                                     = 2,
    SixteenthNote                                  = 3,
    ThirtySecondNote                               = 4,
    Count                                          = 5,
    EQuartzTimeSignatureQuantization_MAX           = 6

};


// Enum  /Script/Engine.ERichCurveExtrapolation
enum class ERichCurveExtrapolation : uint8_t
{
    RCCE_Cycle                                     = 0,
    RCCE_CycleWithOffset                           = 1,
    RCCE_Oscillate                                 = 2,
    RCCE_Linear                                    = 3,
    RCCE_Constant                                  = 4,
    RCCE_None                                      = 5,
    RCCE_MAX                                       = 6

};


// Enum  /Script/Engine.ERichCurveInterpMode
enum class ERichCurveInterpMode : uint8_t
{
    RCIM_Linear                                    = 0,
    RCIM_Constant                                  = 1,
    RCIM_Cubic                                     = 2,
    RCIM_None                                      = 3,
    RCIM_MAX                                       = 4

};


// Enum  /Script/Engine.EMobileReflectionCompression
enum class EMobileReflectionCompression : uint8_t
{
    Default                                        = 0,
    On                                             = 1,
    Off                                            = 2,
    EMobileReflectionCompression_MAX               = 3

};


// Enum  /Script/Engine.EReflectionSourceType
enum class EReflectionSourceType : uint8_t
{
    CapturedScene                                  = 0,
    SpecifiedCubemap                               = 1,
    EReflectionSourceType_MAX                      = 2

};


// Enum  /Script/Engine.EDefaultBackBufferPixelFormat
enum class EDefaultBackBufferPixelFormat : uint8_t
{
    DBBPF_B8G8R8A8                                 = 0,
    DBBPF_A16B16G16R16_DEPRECATED                  = 1,
    DBBPF_FloatRGB_DEPRECATED                      = 2,
    DBBPF_FloatRGBA                                = 3,
    DBBPF_A2B10G10R10                              = 4,
    DBBPF_MAX                                      = 6

};


// Enum  /Script/Engine.EAutoExposureMethodUI
enum class EAutoExposureMethodUI : uint8_t
{
    AEM_Histogram                                  = 0,
    AEM_Basic                                      = 1,
    AEM_Manual                                     = 2,
    AEM_MAX                                        = 3

};


// Enum  /Script/Engine.EAlphaChannelMode
enum class EAlphaChannelMode : uint8_t
{
    Disabled                                       = 0,
    LinearColorSpaceOnly                           = 1,
    AllowThroughTonemapper                         = 2,
    EAlphaChannelMode_MAX                          = 3

};


// Enum  /Script/Engine.EEarlyZPass
enum class EEarlyZPass : uint8_t
{
    None                                           = 0,
    OpaqueOnly                                     = 1,
    OpaqueAndMasked                                = 2,
    Auto                                           = 3,
    EEarlyZPass_MAX                                = 4

};


// Enum  /Script/Engine.ECustomDepthStencil
enum class ECustomDepthStencil : uint8_t
{
    Disabled                                       = 0,
    Enabled                                        = 1,
    EnabledOnDemand                                = 2,
    EnabledWithStencil                             = 3,
    ECustomDepthStencil_MAX                        = 4

};


// Enum  /Script/Engine.EMobileMSAASampleCount
enum class EMobileMSAASampleCount : uint8_t
{
    One                                            = 1,
    Two                                            = 2,
    Four                                           = 4,
    Eight                                          = 8,
    EMobileMSAASampleCount_MAX                     = 9

};


// Enum  /Script/Engine.ECompositingSampleCount
enum class ECompositingSampleCount : uint8_t
{
    One                                            = 1,
    Two                                            = 2,
    Four                                           = 4,
    Eight                                          = 8,
    ECompositingSampleCount_MAX                    = 9

};


// Enum  /Script/Engine.EClearSceneOptions
enum class EClearSceneOptions : uint8_t
{
    NoClear                                        = 0,
    HardwareClear                                  = 1,
    QuadAtMaxZ                                     = 2,
    EClearSceneOptions_MAX                         = 3

};


// Enum  /Script/Engine.EReporterLineStyle
enum class EReporterLineStyle : uint8_t
{
    Line                                           = 0,
    Dash                                           = 1,
    EReporterLineStyle_MAX                         = 2

};


// Enum  /Script/Engine.ELegendPosition
enum class ELegendPosition : uint8_t
{
    Outside                                        = 0,
    Inside                                         = 1,
    ELegendPosition_MAX                            = 2

};


// Enum  /Script/Engine.EGraphDataStyle
enum class EGraphDataStyle : uint8_t
{
    Lines                                          = 0,
    Filled                                         = 1,
    EGraphDataStyle_MAX                            = 2

};


// Enum  /Script/Engine.EGraphAxisStyle
enum class EGraphAxisStyle : uint8_t
{
    Lines                                          = 0,
    Notches                                        = 1,
    Grid                                           = 2,
    EGraphAxisStyle_MAX                            = 3

};


// Enum  /Script/Engine.ReverbPreset
enum class ReverbPreset : uint8_t
{
    REVERB_Default                                 = 0,
    REVERB_Bathroom                                = 1,
    REVERB_StoneRoom                               = 2,
    REVERB_Auditorium                              = 3,
    REVERB_ConcertHall                             = 4,
    REVERB_Cave                                    = 5,
    REVERB_Hallway                                 = 6,
    REVERB_StoneCorridor                           = 7,
    REVERB_Alley                                   = 8,
    REVERB_Forest                                  = 9,
    REVERB_City                                    = 10,
    REVERB_Mountains                               = 11,
    REVERB_Quarry                                  = 12,
    REVERB_Plain                                   = 13,
    REVERB_ParkingLot                              = 14,
    REVERB_SewerPipe                               = 15,
    REVERB_Underwater                              = 16,
    REVERB_SmallRoom                               = 17,
    REVERB_MediumRoom                              = 18,
    REVERB_LargeRoom                               = 19,
    REVERB_MediumHall                              = 20,
    REVERB_LargeHall                               = 21,
    REVERB_Plate                                   = 22,
    REVERB_MAX                                     = 23

};


// Enum  /Script/Engine.ERichCurveKeyTimeCompressionFormat
enum class ERichCurveKeyTimeCompressionFormat : uint8_t
{
    RCKTCF_uint16                                  = 0,
    RCKTCF_float32                                 = 1,
    RCKTCF_MAX                                     = 2

};


// Enum  /Script/Engine.ERichCurveCompressionFormat
enum class ERichCurveCompressionFormat : uint8_t
{
    RCCF_Empty                                     = 0,
    RCCF_Constant                                  = 1,
    RCCF_Linear                                    = 2,
    RCCF_Cubic                                     = 3,
    RCCF_Mixed                                     = 4,
    RCCF_Weighted                                  = 5,
    RCCF_MAX                                       = 6

};


// Enum  /Script/Engine.ERichCurveTangentWeightMode
enum class ERichCurveTangentWeightMode : uint8_t
{
    RCTWM_WeightedNone                             = 0,
    RCTWM_WeightedArrive                           = 1,
    RCTWM_WeightedLeave                            = 2,
    RCTWM_WeightedBoth                             = 3,
    RCTWM_MAX                                      = 4

};


// Enum  /Script/Engine.ERichCurveTangentMode
enum class ERichCurveTangentMode : uint8_t
{
    RCTM_Auto                                      = 0,
    RCTM_User                                      = 1,
    RCTM_Break                                     = 2,
    RCTM_None                                      = 3,
    RCTM_MAX                                       = 4

};


// Enum  /Script/Engine.EConstraintTransform
enum class EConstraintTransform : uint8_t
{
    Absolute                                       = 0,
    Relative                                       = 1,
    EConstraintTransform_MAX                       = 2

};


// Enum  /Script/Engine.EControlConstraint
enum class EControlConstraint : uint8_t
{
    Orientation                                    = 0,
    Translation                                    = 1,
    MAX                                            = 2

};


// Enum  /Script/Engine.ERootMotionFinishVelocityMode
enum class ERootMotionFinishVelocityMode : uint8_t
{
    MaintainLastRootMotionVelocity                 = 0,
    SetVelocity                                    = 1,
    ClampVelocity                                  = 2,
    ClampVelocityIgnoreZ                           = 3,
    ERootMotionFinishVelocityMode_MAX              = 4

};


// Enum  /Script/Engine.ERootMotionSourceSettingsFlags
enum class ERootMotionSourceSettingsFlags : uint8_t
{
    UseSensitiveLiftoffCheck                       = 1,
    DisablePartialEndTick                          = 2,
    IgnoreZAccumulate                              = 4,
    ERootMotionSourceSettingsFlags_MAX             = 5

};


// Enum  /Script/Engine.ERootMotionSourceStatusFlags
enum class ERootMotionSourceStatusFlags : uint8_t
{
    Prepared                                       = 1,
    Finished                                       = 2,
    MarkedForRemoval                               = 4,
    ERootMotionSourceStatusFlags_MAX               = 5

};


// Enum  /Script/Engine.ERootMotionAccumulateMode
enum class ERootMotionAccumulateMode : uint8_t
{
    Override                                       = 0,
    Additive                                       = 1,
    ERootMotionAccumulateMode_MAX                  = 2

};


// Enum  /Script/Engine.ERuntimeVirtualTextureMainPassType
enum class ERuntimeVirtualTextureMainPassType : uint8_t
{
    Never                                          = 0,
    Exclusive                                      = 1,
    Always                                         = 2,
    ERuntimeVirtualTextureMainPassType_MAX         = 3

};


// Enum  /Script/Engine.ERuntimeVirtualTextureMaterialType
enum class ERuntimeVirtualTextureMaterialType : uint8_t
{
    BaseColor                                      = 0,
    BaseColor_Normal_DEPRECATED                    = 1,
    BaseColor_Normal_Specular                      = 2,
    BaseColor_Normal_Specular_YCoCg                = 3,
    BaseColor_Normal_Specular_Mask_YCoCg           = 4,
    WorldHeight                                    = 5,
    Count                                          = 6,
    ERuntimeVirtualTextureMaterialType_MAX         = 7

};


// Enum  /Script/Engine.EMobilePixelProjectedReflectionQuality
enum class EMobilePixelProjectedReflectionQuality : uint8_t
{
    Disabled                                       = 0,
    BestPerformance                                = 1,
    BetterQuality                                  = 2,
    BestQuality                                    = 3,
    EMobilePixelProjectedReflectionQuality_MAX     = 4

};


// Enum  /Script/Engine.EMobilePlanarReflectionMode
enum class EMobilePlanarReflectionMode : uint8_t
{
    Usual                                          = 0,
    MobilePPRExclusive                             = 1,
    MobilePPR                                      = 2,
    EMobilePlanarReflectionMode_MAX                = 3

};


// Enum  /Script/Engine.ELightUnits
enum class ELightUnits : uint8_t
{
    Unitless                                       = 0,
    Candelas                                       = 1,
    Lumens                                         = 2,
    ELightUnits_MAX                                = 3

};


// Enum  /Script/Engine.EAntiAliasingMethod
enum class EAntiAliasingMethod : uint8_t
{
    AAM_None                                       = 0,
    AAM_FXAA                                       = 1,
    AAM_TemporalAA                                 = 2,
    AAM_MSAA                                       = 3,
    AAM_MAX                                        = 5

};


// Enum  /Script/Engine.EDepthOfFieldMethod
enum class EDepthOfFieldMethod : uint8_t
{
    DOFM_BokehDOF                                  = 0,
    DOFM_Gaussian                                  = 1,
    DOFM_CircleDOF                                 = 2,
    DOFM_MAX                                       = 3

};


// Enum  /Script/Engine.ESceneCapturePrimitiveRenderMode
enum class ESceneCapturePrimitiveRenderMode : uint8_t
{
    PRM_LegacySceneCapture                         = 0,
    PRM_RenderScenePrimitives                      = 1,
    PRM_UseShowOnlyList                            = 2,
    PRM_MAX                                        = 3

};


// Enum  /Script/Engine.EComponentTransformOpt
enum class EComponentTransformOpt : uint8_t
{
    Default                                        = 0,
    RelativeSame                                   = 1,
    RelativeTranslation                            = 2,
    EComponentTransformOpt_MAX                     = 3

};


// Enum  /Script/Engine.ECustomVisibilityBits
enum class ECustomVisibilityBits : uint8_t
{
    ECVB_None                                      = 0,
    ECVB_Channel1                                  = 1,
    ECVB_Channel2                                  = 2,
    ECVB_Channel3                                  = 4,
    ECVB_Channel4                                  = 8,
    ECVB_Channel5                                  = 16,
    ECVB_Channel6                                  = 32,
    ECVB_Channel7                                  = 64,
    ECVB_Channel8                                  = 128,
    ECVB_MAX                                       = 129

};


// Enum  /Script/Engine.EMaterialProperty
enum class EMaterialProperty : uint8_t
{
    MP_EmissiveColor                               = 0,
    MP_Opacity                                     = 1,
    MP_OpacityMask                                 = 2,
    MP_DiffuseColor                                = 3,
    MP_SpecularColor                               = 4,
    MP_BaseColor                                   = 5,
    MP_Metallic                                    = 6,
    MP_Specular                                    = 7,
    MP_Roughness                                   = 8,
    MP_Anisotropy                                  = 9,
    MP_Normal                                      = 10,
    MP_Tangent                                     = 11,
    MP_WorldPositionOffset                         = 12,
    MP_WorldDisplacement                           = 13,
    MP_TessellationMultiplier                      = 14,
    MP_SubsurfaceColor                             = 15,
    MP_CustomData0                                 = 16,
    MP_CustomData1                                 = 17,
    MP_AmbientOcclusion                            = 18,
    MP_Refraction                                  = 19,
    MP_CustomizedUVs0                              = 20,
    MP_CustomizedUVs1                              = 21,
    MP_CustomizedUVs2                              = 22,
    MP_CustomizedUVs3                              = 23,
    MP_CustomizedUVs4                              = 24,
    MP_CustomizedUVs5                              = 25,
    MP_CustomizedUVs6                              = 26,
    MP_CustomizedUVs7                              = 27,
    MP_PixelDepthOffset                            = 28,
    MP_ShadingModel                                = 29,
    MP_MaterialAttributes                          = 31,
    MP_CustomOutput                                = 32,
    MP_MAX                                         = 33

};


// Enum  /Script/Engine.ESkinCacheDefaultBehavior
enum class ESkinCacheDefaultBehavior : uint8_t
{
    Exclusive                                      = 0,
    Inclusive                                      = 1,
    ESkinCacheDefaultBehavior_MAX                  = 2

};


// Enum  /Script/Engine.ESkinCacheUsage
enum class ESkinCacheUsage : uint8_t
{
    Auto                                           = 0,
    Disabled                                       = 255,
    Enabled                                        = 1,
    ESkinCacheUsage_MAX                            = 256

};


// Enum  /Script/Engine.EPhysicsTransformUpdateMode
enum class EPhysicsTransformUpdateMode : uint8_t
{
    SimulationUpatesComponentTransform             = 0,
    ComponentTransformIsKinematic                  = 1,
    EPhysicsTransformUpdateMode_MAX                = 2

};


// Enum  /Script/Engine.EAnimationMode
enum class EAnimationMode : uint8_t
{
    AnimationBlueprint                             = 0,
    AnimationSingleNode                            = 1,
    AnimationCustomMode                            = 2,
    EAnimationMode_MAX                             = 3

};


// Enum  /Script/Engine.EKinematicBonesUpdateToPhysics
enum class EKinematicBonesUpdateToPhysics : uint8_t
{
    SkipSimulatingBones                            = 0,
    SkipAllBones                                   = 1,
    EKinematicBonesUpdateToPhysics_MAX             = 2

};


// Enum  /Script/Engine.ECustomBoneAttributeLookup
enum class ECustomBoneAttributeLookup : uint8_t
{
    BoneOnly                                       = 0,
    ImmediateParent                                = 1,
    ParentHierarchy                                = 2,
    ECustomBoneAttributeLookup_MAX                 = 3

};


// Enum  /Script/Engine.EClothMassMode
enum class EClothMassMode : uint8_t
{
    UniformMass                                    = 0,
    TotalMass                                      = 1,
    Density                                        = 2,
    MaxClothMassMode                               = 3,
    EClothMassMode_MAX                             = 4

};


// Enum  /Script/Engine.ESkeletalMeshSkinningImportVersions
enum class ESkeletalMeshSkinningImportVersions : uint8_t
{
    Before_Versionning                             = 0,
    SkeletalMeshBuildRefactor                      = 1,
    VersionPlusOne                                 = 2,
    LatestVersion                                  = 1,
    ESkeletalMeshSkinningImportVersions_MAX        = 3

};


// Enum  /Script/Engine.ESkeletalMeshGeoImportVersions
enum class ESkeletalMeshGeoImportVersions : uint8_t
{
    Before_Versionning                             = 0,
    SkeletalMeshBuildRefactor                      = 1,
    VersionPlusOne                                 = 2,
    LatestVersion                                  = 1,
    ESkeletalMeshGeoImportVersions_MAX             = 3

};


// Enum  /Script/Engine.EBoneFilterActionOption
enum class EBoneFilterActionOption : uint8_t
{
    Remove                                         = 0,
    Keep                                           = 1,
    Invalid                                        = 2,
    EBoneFilterActionOption_MAX                    = 3

};


// Enum  /Script/Engine.SkeletalMeshOptimizationImportance
enum class SkeletalMeshOptimizationImportance : uint8_t
{
    SMOI_Off                                       = 0,
    SMOI_Lowest                                    = 1,
    SMOI_Low                                       = 2,
    SMOI_Normal                                    = 3,
    SMOI_High                                      = 4,
    SMOI_Highest                                   = 5,
    SMOI_MAX                                       = 6

};


// Enum  /Script/Engine.SkeletalMeshOptimizationType
enum class SkeletalMeshOptimizationType : uint8_t
{
    SMOT_NumOfTriangles                            = 0,
    SMOT_MaxDeviation                              = 1,
    SMOT_TriangleOrDeviation                       = 2,
    SMOT_MAX                                       = 3

};


// Enum  /Script/Engine.SkeletalMeshTerminationCriterion
enum class SkeletalMeshTerminationCriterion : uint8_t
{
    SMTC_NumOfTriangles                            = 0,
    SMTC_NumOfVerts                                = 1,
    SMTC_TriangleOrVert                            = 2,
    SMTC_AbsNumOfTriangles                         = 3,
    SMTC_AbsNumOfVerts                             = 4,
    SMTC_AbsTriangleOrVert                         = 5,
    SMTC_NumOfSections                             = 6,
    SMTC_MAX                                       = 7

};


// Enum  /Script/Engine.EBoneTranslationRetargetingMode
enum class EBoneTranslationRetargetingMode : uint8_t
{
    Animation                                      = 0,
    Skeleton                                       = 1,
    AnimationScaled                                = 2,
    AnimationRelative                              = 3,
    OrientAndScale                                 = 4,
    EBoneTranslationRetargetingMode_MAX            = 5

};


// Enum  /Script/Engine.EVertexOffsetUsageType
enum class EVertexOffsetUsageType : uint8_t
{
    None                                           = 0,
    PreSkinningOffset                              = 1,
    PostSkinningOffset                             = 2,
    EVertexOffsetUsageType_MAX                     = 3

};


// Enum  /Script/Engine.EBoneSpaces
enum class EBoneSpaces : uint8_t
{
    WorldSpace                                     = 0,
    ComponentSpace                                 = 1,
    EBoneSpaces_MAX                                = 2

};


// Enum  /Script/Engine.EVisibilityBasedAnimTickOption
enum class EVisibilityBasedAnimTickOption : uint8_t
{
    AlwaysTickPoseAndRefreshBones                  = 0,
    AlwaysTickPose                                 = 1,
    OnlyTickMontagesWhenNotRendered                = 2,
    OnlyTickPoseWhenRendered                       = 3,
    EVisibilityBasedAnimTickOption_MAX             = 4

};


// Enum  /Script/Engine.EPhysBodyOp
enum class EPhysBodyOp : uint8_t
{
    PBO_None                                       = 0,
    PBO_Term                                       = 1,
    PBO_MAX                                        = 2

};


// Enum  /Script/Engine.EBoneVisibilityStatus
enum class EBoneVisibilityStatus : uint8_t
{
    BVS_HiddenByParent                             = 0,
    BVS_Visible                                    = 1,
    BVS_ExplicitlyHidden                           = 2,
    BVS_MAX                                        = 3

};


// Enum  /Script/Engine.ESkyAtmosphereTransformMode
enum class ESkyAtmosphereTransformMode : uint8_t
{
    PlanetTopAtAbsoluteWorldOrigin                 = 0,
    PlanetTopAtComponentTransform                  = 1,
    PlanetCenterAtComponentTransform               = 2,
    ESkyAtmosphereTransformMode_MAX                = 3

};


// Enum  /Script/Engine.ESkyLightSourceType
enum class ESkyLightSourceType : uint8_t
{
    SLS_CapturedScene                              = 0,
    SLS_SpecifiedCubemap                           = 1,
    SLS_MAX                                        = 2

};


// Enum  /Script/Engine.EPriorityAttenuationMethod
enum class EPriorityAttenuationMethod : uint8_t
{
    Linear                                         = 0,
    CustomCurve                                    = 1,
    Manual                                         = 2,
    EPriorityAttenuationMethod_MAX                 = 3

};


// Enum  /Script/Engine.ESubmixSendMethod
enum class ESubmixSendMethod : uint8_t
{
    Linear                                         = 0,
    CustomCurve                                    = 1,
    Manual                                         = 2,
    ESubmixSendMethod_MAX                          = 3

};


// Enum  /Script/Engine.EReverbSendMethod
enum class EReverbSendMethod : uint8_t
{
    Linear                                         = 0,
    CustomCurve                                    = 1,
    Manual                                         = 2,
    EReverbSendMethod_MAX                          = 3

};


// Enum  /Script/Engine.EAirAbsorptionMethod
enum class EAirAbsorptionMethod : uint8_t
{
    Linear                                         = 0,
    CustomCurve                                    = 1,
    EAirAbsorptionMethod_MAX                       = 2

};


// Enum  /Script/Engine.ESoundSpatializationAlgorithm
enum class ESoundSpatializationAlgorithm : uint8_t
{
    SPATIALIZATION_Default                         = 0,
    SPATIALIZATION_HRTF                            = 1,
    SPATIALIZATION_MAX                             = 2

};


// Enum  /Script/Engine.ESoundDistanceCalc
enum class ESoundDistanceCalc : uint8_t
{
    SOUNDDISTANCE_Normal                           = 0,
    SOUNDDISTANCE_InfiniteXYPlane                  = 1,
    SOUNDDISTANCE_InfiniteXZPlane                  = 2,
    SOUNDDISTANCE_InfiniteYZPlane                  = 3,
    SOUNDDISTANCE_MAX                              = 4

};


// Enum  /Script/Engine.EVirtualizationMode
enum class EVirtualizationMode : uint8_t
{
    Disabled                                       = 0,
    PlayWhenSilent                                 = 1,
    Restart                                        = 2,
    EVirtualizationMode_MAX                        = 3

};


// Enum  /Script/Engine.EConcurrencyVolumeScaleMode
enum class EConcurrencyVolumeScaleMode : uint8_t
{
    Default                                        = 0,
    Distance                                       = 1,
    Priority                                       = 2,
    EConcurrencyVolumeScaleMode_MAX                = 3

};


// Enum  /Script/Engine.EMaxConcurrentResolutionRule
enum class EMaxConcurrentResolutionRule : uint8_t
{
    PreventNew                                     = 0,
    StopOldest                                     = 1,
    StopFarthestThenPreventNew                     = 2,
    StopFarthestThenOldest                         = 3,
    StopLowestPriority                             = 4,
    StopQuietest                                   = 5,
    StopLowestPriorityThenPreventNew               = 6,
    Count                                          = 7,
    EMaxConcurrentResolutionRule_MAX               = 8

};


// Enum  /Script/Engine.ESoundGroup
enum class ESoundGroup : uint8_t
{
    SOUNDGROUP_Default                             = 0,
    SOUNDGROUP_Effects                             = 1,
    SOUNDGROUP_UI                                  = 2,
    SOUNDGROUP_Music                               = 3,
    SOUNDGROUP_Voice                               = 4,
    SOUNDGROUP_GameSoundGroup1                     = 5,
    SOUNDGROUP_GameSoundGroup2                     = 6,
    SOUNDGROUP_GameSoundGroup3                     = 7,
    SOUNDGROUP_GameSoundGroup4                     = 8,
    SOUNDGROUP_GameSoundGroup5                     = 9,
    SOUNDGROUP_GameSoundGroup6                     = 10,
    SOUNDGROUP_GameSoundGroup7                     = 11,
    SOUNDGROUP_GameSoundGroup8                     = 12,
    SOUNDGROUP_GameSoundGroup9                     = 13,
    SOUNDGROUP_GameSoundGroup10                    = 14,
    SOUNDGROUP_GameSoundGroup11                    = 15,
    SOUNDGROUP_GameSoundGroup12                    = 16,
    SOUNDGROUP_GameSoundGroup13                    = 17,
    SOUNDGROUP_GameSoundGroup14                    = 18,
    SOUNDGROUP_GameSoundGroup15                    = 19,
    SOUNDGROUP_GameSoundGroup16                    = 20,
    SOUNDGROUP_GameSoundGroup17                    = 21,
    SOUNDGROUP_GameSoundGroup18                    = 22,
    SOUNDGROUP_GameSoundGroup19                    = 23,
    SOUNDGROUP_GameSoundGroup20                    = 24,
    SOUNDGROUP_MAX                                 = 25

};


// Enum  /Script/Engine.EModulationRouting
enum class EModulationRouting : uint8_t
{
    Disable                                        = 0,
    Inherit                                        = 1,
    Override                                       = 2,
    EModulationRouting_MAX                         = 3

};


// Enum  /Script/Engine.ModulationParamMode
enum class ModulationParamMode : uint8_t
{
    MPM_Normal                                     = 0,
    MPM_Abs                                        = 1,
    MPM_Direct                                     = 2,
    MPM_MAX                                        = 3

};


// Enum  /Script/Engine.ESourceBusChannels
enum class ESourceBusChannels : uint8_t
{
    Mono                                           = 0,
    Stereo                                         = 1,
    ESourceBusChannels_MAX                         = 2

};


// Enum  /Script/Engine.ESourceBusSendLevelControlMethod
enum class ESourceBusSendLevelControlMethod : uint8_t
{
    Linear                                         = 0,
    CustomCurve                                    = 1,
    Manual                                         = 2,
    ESourceBusSendLevelControlMethod_MAX           = 3

};


// Enum  /Script/Engine.EGainParamMode
enum class EGainParamMode : uint8_t
{
    Linear                                         = 0,
    Decibels                                       = 1,
    EGainParamMode_MAX                             = 2

};


// Enum  /Script/Engine.EAudioSpectrumType
enum class EAudioSpectrumType : uint8_t
{
    MagnitudeSpectrum                              = 0,
    PowerSpectrum                                  = 1,
    Decibel                                        = 2,
    EAudioSpectrumType_MAX                         = 3

};


// Enum  /Script/Engine.EFFTWindowType
enum class EFFTWindowType : uint8_t
{
    None                                           = 0,
    Hamming                                        = 1,
    Hann                                           = 2,
    Blackman                                       = 3,
    EFFTWindowType_MAX                             = 4

};


// Enum  /Script/Engine.EFFTPeakInterpolationMethod
enum class EFFTPeakInterpolationMethod : uint8_t
{
    NearestNeighbor                                = 0,
    Linear                                         = 1,
    Quadratic                                      = 2,
    ConstantQ                                      = 3,
    EFFTPeakInterpolationMethod_MAX                = 4

};


// Enum  /Script/Engine.EFFTSize
enum class EFFTSize : uint8_t
{
    DefaultSize                                    = 0,
    Min                                            = 1,
    Small                                          = 2,
    Medium                                         = 3,
    Large                                          = 4,
    VeryLarge                                      = 5,
    Max                                            = 6

};


// Enum  /Script/Engine.ESubmixSendStage
enum class ESubmixSendStage : uint8_t
{
    PostDistanceAttenuation                        = 0,
    PreDistanceAttenuation                         = 1,
    ESubmixSendStage_MAX                           = 2

};


// Enum  /Script/Engine.ESendLevelControlMethod
enum class ESendLevelControlMethod : uint8_t
{
    Linear                                         = 0,
    CustomCurve                                    = 1,
    Manual                                         = 2,
    ESendLevelControlMethod_MAX                    = 3

};


// Enum  /Script/Engine.EAudioRecordingExportType
enum class EAudioRecordingExportType : uint8_t
{
    SoundWave                                      = 0,
    WavFile                                        = 1,
    EAudioRecordingExportType_MAX                  = 2

};


// Enum  /Script/Engine.EAudioSpectrumBandPresetType
enum class EAudioSpectrumBandPresetType : uint8_t
{
    KickDrum                                       = 0,
    SnareDrum                                      = 1,
    Voice                                          = 2,
    Cymbals                                        = 3,
    EAudioSpectrumBandPresetType_MAX               = 4

};


// Enum  /Script/Engine.ESoundWaveFFTSize
enum class ESoundWaveFFTSize : uint8_t
{
    VerySmall                                      = 0,
    Small                                          = 1,
    Medium                                         = 2,
    Large                                          = 3,
    VeryLarge                                      = 4,
    ESoundWaveFFTSize_MAX                          = 5

};


// Enum  /Script/Engine.EDecompressionType
enum class EDecompressionType : uint8_t
{
    DTYPE_Setup                                    = 0,
    DTYPE_Invalid                                  = 1,
    DTYPE_Preview                                  = 2,
    DTYPE_Native                                   = 3,
    DTYPE_RealTime                                 = 4,
    DTYPE_Procedural                               = 5,
    DTYPE_Xenon                                    = 6,
    DTYPE_Streaming                                = 7,
    DTYPE_MAX                                      = 8

};


// Enum  /Script/Engine.ESoundWaveLoadingBehavior
enum class ESoundWaveLoadingBehavior : uint8_t
{
    Inherited                                      = 0,
    RetainOnLoad                                   = 1,
    PrimeOnLoad                                    = 2,
    LoadOnDemand                                   = 3,
    ForceInline                                    = 4,
    Uninitialized                                  = 255,
    ESoundWaveLoadingBehavior_MAX                  = 256

};


// Enum  /Script/Engine.ESplineCoordinateSpace
enum class ESplineCoordinateSpace : uint8_t
{
    Local                                          = 0,
    World                                          = 1,
    ESplineCoordinateSpace_MAX                     = 2

};


// Enum  /Script/Engine.ESplinePointType
enum class ESplinePointType : uint8_t
{
    Linear                                         = 0,
    Curve                                          = 1,
    Constant                                       = 2,
    CurveClamped                                   = 3,
    CurveCustomTangent                             = 4,
    ESplinePointType_MAX                           = 5

};


// Enum  /Script/Engine.ESplineMeshAxis
enum class ESplineMeshAxis : uint8_t
{
    X                                              = 0,
    Y                                              = 1,
    Z                                              = 2,
    ESplineMeshAxis_MAX                            = 3

};


// Enum  /Script/Engine.EStaticMeshUasge
enum class EStaticMeshUasge : uint8_t
{
    NormalMesh                                     = 0,
    BatchProxyMesh                                 = 1,
    BatchResourceHolderMesh                        = 2,
    EStaticMeshUasge_MAX                           = 3

};


// Enum  /Script/Engine.EOptimizationType
enum class EOptimizationType : uint8_t
{
    OT_NumOfTriangles                              = 0,
    OT_MaxDeviation                                = 1,
    OT_MAX                                         = 2

};


// Enum  /Script/Engine.EImportanceLevel
enum class EImportanceLevel : uint8_t
{
    IL_Off                                         = 0,
    IL_Lowest                                      = 1,
    IL_Low                                         = 2,
    IL_Normal                                      = 3,
    IL_High                                        = 4,
    IL_Highest                                     = 5,
    TEMP_BROKEN2                                   = 6,
    EImportanceLevel_MAX                           = 7

};


// Enum  /Script/Engine.ENormalMode
enum class ENormalMode : uint8_t
{
    NM_PreserveSmoothingGroups                     = 0,
    NM_RecalculateNormals                          = 1,
    NM_RecalculateNormalsSmooth                    = 2,
    NM_RecalculateNormalsHard                      = 3,
    TEMP_BROKEN                                    = 4,
    ENormalMode_MAX                                = 5

};


// Enum  /Script/Engine.EStereoLayerShape
enum class EStereoLayerShape : uint8_t
{
    SLSH_QuadLayer                                 = 0,
    SLSH_CylinderLayer                             = 1,
    SLSH_CubemapLayer                              = 2,
    SLSH_EquirectLayer                             = 3,
    SLSH_MAX                                       = 4

};


// Enum  /Script/Engine.EStereoLayerType
enum class EStereoLayerType : uint8_t
{
    SLT_WorldLocked                                = 0,
    SLT_TrackerLocked                              = 1,
    SLT_FaceLocked                                 = 2,
    SLT_MAX                                        = 3

};


// Enum  /Script/Engine.EOpacitySourceMode
enum class EOpacitySourceMode : uint8_t
{
    OSM_Alpha                                      = 0,
    OSM_ColorBrightness                            = 1,
    OSM_RedChannel                                 = 2,
    OSM_GreenChannel                               = 3,
    OSM_BlueChannel                                = 4,
    OSM_MAX                                        = 5

};


// Enum  /Script/Engine.ESubUVBoundingVertexCount
enum class ESubUVBoundingVertexCount : uint8_t
{
    BVC_FourVertices                               = 0,
    BVC_EightVertices                              = 1,
    BVC_MAX                                        = 2

};


// Enum  /Script/Engine.EVerticalTextAligment
enum class EVerticalTextAligment : uint8_t
{
    EVRTA_TextTop                                  = 0,
    EVRTA_TextCenter                               = 1,
    EVRTA_TextBottom                               = 2,
    EVRTA_QuadTop                                  = 3,
    EVRTA_MAX                                      = 4

};


// Enum  /Script/Engine.EHorizTextAligment
enum class EHorizTextAligment : uint8_t
{
    EHTA_Left                                      = 0,
    EHTA_Center                                    = 1,
    EHTA_Right                                     = 2,
    EHTA_MAX                                       = 3

};


// Enum  /Script/Engine.ETextureLossyCompressionAmount
enum class ETextureLossyCompressionAmount : uint8_t
{
    TLCA_Default                                   = 0,
    TLCA_None                                      = 1,
    TLCA_Lowest                                    = 2,
    TLCA_Low                                       = 3,
    TLCA_Medium                                    = 4,
    TLCA_High                                      = 5,
    TLCA_Highest                                   = 6,
    TLCA_MAX                                       = 7

};


// Enum  /Script/Engine.ETextureCompressionQuality
enum class ETextureCompressionQuality : uint8_t
{
    TCQ_Default                                    = 0,
    TCQ_Lowest                                     = 1,
    TCQ_Low                                        = 2,
    TCQ_Medium                                     = 3,
    TCQ_High                                       = 4,
    TCQ_Highest                                    = 5,
    TCQ_MAX                                        = 6

};


// Enum  /Script/Engine.ETextureSourceFormat
enum class ETextureSourceFormat : uint8_t
{
    TSF_Invalid                                    = 0,
    TSF_G8                                         = 1,
    TSF_BGRA8                                      = 2,
    TSF_BGRE8                                      = 3,
    TSF_RGBA16                                     = 4,
    TSF_RGBA16F                                    = 5,
    TSF_RGBA8                                      = 6,
    TSF_RGBE8                                      = 7,
    TSF_G16                                        = 8,
    TSF_MAX                                        = 9

};


// Enum  /Script/Engine.ETextureSourceArtType
enum class ETextureSourceArtType : uint8_t
{
    TSAT_Uncompressed                              = 0,
    TSAT_PNGCompressed                             = 1,
    TSAT_DDSFile                                   = 2,
    TSAT_MAX                                       = 3

};


// Enum  /Script/Engine.ETextureMipCount
enum class ETextureMipCount : uint8_t
{
    TMC_ResidentMips                               = 0,
    TMC_AllMips                                    = 1,
    TMC_AllMipsBiased                              = 2,
    TMC_MAX                                        = 3

};


// Enum  /Script/Engine.ECompositeTextureMode
enum class ECompositeTextureMode : uint8_t
{
    CTM_Disabled                                   = 0,
    CTM_NormalRoughnessToRed                       = 1,
    CTM_NormalRoughnessToGreen                     = 2,
    CTM_NormalRoughnessToBlue                      = 3,
    CTM_NormalRoughnessToAlpha                     = 4,
    CTM_MAX                                        = 5

};


// Enum  /Script/Engine.TextureAddress
enum class TextureAddress : uint8_t
{
    TA_Wrap                                        = 0,
    TA_Clamp                                       = 1,
    TA_Mirror                                      = 2,
    TA_MAX                                         = 3

};


// Enum  /Script/Engine.TextureFilter
enum class TextureFilter : uint8_t
{
    TF_Nearest                                     = 0,
    TF_Bilinear                                    = 1,
    TF_Trilinear                                   = 2,
    TF_Default                                     = 3,
    TF_MAX                                         = 4

};


// Enum  /Script/Engine.TextureCompressionSettings
enum class TextureCompressionSettings : uint8_t
{
    TC_Default                                     = 0,
    TC_Normalmap                                   = 1,
    TC_Masks                                       = 2,
    TC_Grayscale                                   = 3,
    TC_Displacementmap                             = 4,
    TC_VectorDisplacementmap                       = 5,
    TC_HDR                                         = 6,
    TC_EditorIcon                                  = 7,
    TC_Alpha                                       = 8,
    TC_DistanceFieldFont                           = 9,
    TC_HDR_Compressed                              = 10,
    TC_BC7                                         = 11,
    TC_HalfFloat                                   = 12,
    TC_ReflectionCapture                           = 13,
    TC_MAX                                         = 14

};


// Enum  /Script/Engine.ETextureDownscaleOptions
enum class ETextureDownscaleOptions : uint8_t
{
    Default                                        = 0,
    Unfiltered                                     = 1,
    SimpleAverage                                  = 2,
    Sharpen0                                       = 3,
    Sharpen1                                       = 4,
    Sharpen2                                       = 5,
    Sharpen3                                       = 6,
    Sharpen4                                       = 7,
    Sharpen5                                       = 8,
    Sharpen6                                       = 9,
    Sharpen7                                       = 10,
    Sharpen8                                       = 11,
    Sharpen9                                       = 12,
    Sharpen10                                      = 13,
    ETextureDownscaleOptions_MAX                   = 14

};


// Enum  /Script/Engine.ETextureMipLoadOptions
enum class ETextureMipLoadOptions : uint8_t
{
    Default                                        = 0,
    AllMips                                        = 1,
    OnlyFirstMip                                   = 2,
    ETextureMipLoadOptions_MAX                     = 3

};


// Enum  /Script/Engine.ETextureSamplerFilter
enum class ETextureSamplerFilter : uint8_t
{
    Point                                          = 0,
    Bilinear                                       = 1,
    Trilinear                                      = 2,
    AnisotropicPoint                               = 3,
    AnisotropicLinear                              = 4,
    ETextureSamplerFilter_MAX                      = 5

};


// Enum  /Script/Engine.ETexturePowerOfTwoSetting
enum class ETexturePowerOfTwoSetting : uint8_t
{
    None                                           = 0,
    PadToPowerOfTwo                                = 1,
    PadToSquarePowerOfTwo                          = 2,
    ETexturePowerOfTwoSetting_MAX                  = 3

};


// Enum  /Script/Engine.TextureMipGenSettings
enum class TextureMipGenSettings : uint8_t
{
    TMGS_FromTextureGroup                          = 0,
    TMGS_SimpleAverage                             = 1,
    TMGS_Sharpen0                                  = 2,
    TMGS_Sharpen1                                  = 3,
    TMGS_Sharpen2                                  = 4,
    TMGS_Sharpen3                                  = 5,
    TMGS_Sharpen4                                  = 6,
    TMGS_Sharpen5                                  = 7,
    TMGS_Sharpen6                                  = 8,
    TMGS_Sharpen7                                  = 9,
    TMGS_Sharpen8                                  = 10,
    TMGS_Sharpen9                                  = 11,
    TMGS_Sharpen10                                 = 12,
    TMGS_NoMipmaps                                 = 13,
    TMGS_LeaveExistingMips                         = 14,
    TMGS_Blur1                                     = 15,
    TMGS_Blur2                                     = 16,
    TMGS_Blur3                                     = 17,
    TMGS_Blur4                                     = 18,
    TMGS_Blur5                                     = 19,
    TMGS_Unfiltered                                = 20,
    TMGS_MAX                                       = 21

};


// Enum  /Script/Engine.TextureGroup
enum class TextureGroup : uint8_t
{
    TEXTUREGROUP_World                             = 0,
    TEXTUREGROUP_WorldNormalMap                    = 1,
    TEXTUREGROUP_WorldSpecular                     = 2,
    TEXTUREGROUP_Character                         = 3,
    TEXTUREGROUP_CharacterNormalMap                = 4,
    TEXTUREGROUP_CharacterSpecular                 = 5,
    TEXTUREGROUP_CharacterLow                      = 6,
    TEXTUREGROUP_Character_3P                      = 7,
    TEXTUREGROUP_CharacterNormalMap_3P             = 8,
    TEXTUREGROUP_CharacterSpecular_3P              = 9,
    TEXTUREGROUP_CharacterLow_3P                   = 10,
    TEXTUREGROUP_Weapon                            = 11,
    TEXTUREGROUP_WeaponNormalMap                   = 12,
    TEXTUREGROUP_WeaponSpecular                    = 13,
    TEXTUREGROUP_WeaponLow                         = 14,
    TEXTUREGROUP_Vehicle                           = 15,
    TEXTUREGROUP_VehicleNormalMap                  = 16,
    TEXTUREGROUP_VehicleSpecular                   = 17,
    TEXTUREGROUP_Cinematic                         = 18,
    TEXTUREGROUP_Effects                           = 19,
    TEXTUREGROUP_EffectsNotFiltered                = 20,
    TEXTUREGROUP_Skybox                            = 21,
    TEXTUREGROUP_UI                                = 22,
    TEXTUREGROUP_Lightmap                          = 23,
    TEXTUREGROUP_RenderTarget                      = 24,
    TEXTUREGROUP_MobileFlattened                   = 25,
    TEXTUREGROUP_ProcBuilding_Face                 = 26,
    TEXTUREGROUP_ProcBuilding_LightMap             = 27,
    TEXTUREGROUP_Shadowmap                         = 28,
    TEXTUREGROUP_CustomShadowmap                   = 29,
    TEXTUREGROUP_ColorLookupTable                  = 30,
    TEXTUREGROUP_Terrain_Heightmap                 = 31,
    TEXTUREGROUP_Terrain_Weightmap                 = 32,
    TEXTUREGROUP_Bokeh                             = 33,
    TEXTUREGROUP_IESLightProfile                   = 34,
    TEXTUREGROUP_Pixels2D                          = 35,
    TEXTUREGROUP_HierarchicalLOD                   = 36,
    TEXTUREGROUP_Impostor                          = 37,
    TEXTUREGROUP_ImpostorNormalDepth               = 38,
    TEXTUREGROUP_8BitData                          = 39,
    TEXTUREGROUP_16BitData                         = 40,
    TEXTUREGROUP_Project01                         = 41,
    TEXTUREGROUP_Project02                         = 42,
    TEXTUREGROUP_Project03                         = 43,
    TEXTUREGROUP_Project04                         = 44,
    TEXTUREGROUP_Project05                         = 45,
    TEXTUREGROUP_Project06                         = 46,
    TEXTUREGROUP_Project07                         = 47,
    TEXTUREGROUP_Project08                         = 48,
    TEXTUREGROUP_Project09                         = 49,
    TEXTUREGROUP_Project10                         = 50,
    TEXTUREGROUP_Project11                         = 51,
    TEXTUREGROUP_Project12                         = 52,
    TEXTUREGROUP_Project13                         = 53,
    TEXTUREGROUP_Project14                         = 54,
    TEXTUREGROUP_Project15                         = 55,
    TEXTUREGROUP_MAX                               = 56

};


// Enum  /Script/Engine.ETextureRenderTargetFormat
enum class ETextureRenderTargetFormat : uint8_t
{
    RTF_R8                                         = 0,
    RTF_RG8                                        = 1,
    RTF_RGBA8                                      = 2,
    RTF_RGBA8_SRGB                                 = 3,
    RTF_R16f                                       = 4,
    RTF_RG16f                                      = 5,
    RTF_RGBA16f                                    = 6,
    RTF_R32f                                       = 7,
    RTF_RG32f                                      = 8,
    RTF_RGBA32f                                    = 9,
    RTF_RGB10A2                                    = 10,
    RTF_MAX                                        = 11

};


// Enum  /Script/Engine.ETimecodeProviderSynchronizationState
enum class ETimecodeProviderSynchronizationState : uint8_t
{
    Closed                                         = 0,
    Error                                          = 1,
    Synchronized                                   = 2,
    Synchronizing                                  = 3,
    ETimecodeProviderSynchronizationState_MAX      = 4

};


// Enum  /Script/Engine.ETimelineDirection
enum class ETimelineDirection : uint8_t
{
    Forward                                        = 0,
    Backward                                       = 1,
    ETimelineDirection_MAX                         = 2

};


// Enum  /Script/Engine.ETimeStretchCurveMapping
enum class ETimeStretchCurveMapping : uint8_t
{
    T_Original                                     = 0,
    T_TargetMin                                    = 1,
    T_TargetMax                                    = 2,
    MAX                                            = 3

};


// Enum  /Script/Engine.ETwitterIntegrationDelegate
enum class ETwitterIntegrationDelegate : uint8_t
{
    TID_AuthorizeComplete                          = 0,
    TID_TweetUIComplete                            = 1,
    TID_RequestComplete                            = 2,
    TID_MAX                                        = 3

};


// Enum  /Script/Engine.ETwitterRequestMethod
enum class ETwitterRequestMethod : uint8_t
{
    TRM_Get                                        = 0,
    TRM_Post                                       = 1,
    TRM_Delete                                     = 2,
    TRM_MAX                                        = 3

};


// Enum  /Script/Engine.EUserDefinedStructureStatus
enum class EUserDefinedStructureStatus : uint8_t
{
    UDSS_UpToDate                                  = 0,
    UDSS_Dirty                                     = 1,
    UDSS_Error                                     = 2,
    UDSS_Duplicate                                 = 3,
    UDSS_MAX                                       = 4

};


// Enum  /Script/Engine.EUIScalingRule
enum class EUIScalingRule : uint8_t
{
    ShortestSide                                   = 0,
    LongestSide                                    = 1,
    Horizontal                                     = 2,
    Vertical                                       = 3,
    ScaleToFit                                     = 4,
    Custom                                         = 5,
    EUIScalingRule_MAX                             = 6

};


// Enum  /Script/Engine.ERenderFocusRule
enum class ERenderFocusRule : uint8_t
{
    Always                                         = 0,
    NonPointer                                     = 1,
    NavigationOnly                                 = 2,
    Never                                          = 3,
    ERenderFocusRule_MAX                           = 4

};


// Enum  /Script/Engine.EVectorFieldConstructionOp
enum class EVectorFieldConstructionOp : uint8_t
{
    VFCO_Extrude                                   = 0,
    VFCO_Revolve                                   = 1,
    VFCO_MAX                                       = 2

};


// Enum  /Script/Engine.EWindSourceType
enum class EWindSourceType : uint8_t
{
    Directional                                    = 0,
    Point                                          = 1,
    EWindSourceType_MAX                            = 2

};


// Enum  /Script/Engine.EPSCPoolMethod
enum class EPSCPoolMethod : uint8_t
{
    None                                           = 0,
    AutoRelease                                    = 1,
    ManualRelease                                  = 2,
    ManualRelease_OnComplete                       = 3,
    FreeInPool                                     = 4,
    EPSCPoolMethod_MAX                             = 5

};


// Enum  /Script/Engine.EVolumeLightingMethod
enum class EVolumeLightingMethod : uint8_t
{
    VLM_VolumetricLightmap                         = 0,
    VLM_SparseVolumeLightingSamples                = 1,
    VLM_MAX                                        = 2

};


// Enum  /Script/Engine.EVisibilityAggressiveness
enum class EVisibilityAggressiveness : uint8_t
{
    VIS_LeastAggressive                            = 0,
    VIS_ModeratelyAggressive                       = 1,
    VIS_MostAggressive                             = 2,
    VIS_Max                                        = 3

};


// Enum  /Script/ClothingSystemRuntimeCommon.EClothingWindMethod_Legacy
enum class EClothingWindMethod_Legacy : uint8_t
{
    Legacy                                         = 0,
    Accurate                                       = 1,
    EClothingWindMethod_MAX                        = 2

};


// Enum  /Script/ClothingSystemRuntimeCommon.EWeightMapTargetCommon
enum class EWeightMapTargetCommon : uint8_t
{
    None                                           = 0,
    MaxDistance                                    = 1,
    BackstopDistance                               = 2,
    BackstopRadius                                 = 3,
    AnimDriveMultiplier                            = 4,
    EWeightMapTargetCommon_MAX                     = 5

};


// Enum  /Script/ClothingSystemRuntimeNv.EClothingWindMethodNv
enum class EClothingWindMethodNv : uint8_t
{
    Legacy                                         = 0,
    Accurate                                       = 1,
    EClothingWindMethodNv_MAX                      = 2

};


// Enum  /Script/AndroidRuntimeSettings.EAndroidGraphicsDebugger
enum class EAndroidGraphicsDebugger : uint8_t
{
    None                                           = 0,
    Mali                                           = 1,
    Adreno                                         = 2,
    EAndroidGraphicsDebugger_MAX                   = 3

};


// Enum  /Script/AndroidRuntimeSettings.EGoogleVRCaps
enum class EGoogleVRCaps : uint8_t
{
    Cardboard                                      = 0,
    Daydream33                                     = 1,
    Daydream63                                     = 2,
    Daydream66                                     = 3,
    EGoogleVRCaps_MAX                              = 4

};


// Enum  /Script/AndroidRuntimeSettings.EGoogleVRMode
enum class EGoogleVRMode : uint8_t
{
    Cardboard                                      = 0,
    Daydream                                       = 1,
    DaydreamAndCardboard                           = 2,
    EGoogleVRMode_MAX                              = 3

};


// Enum  /Script/AndroidRuntimeSettings.EAndroidAudio
enum class EAndroidAudio : uint8_t
{
    Default                                        = 0,
    OGG                                            = 1,
    ADPCM                                          = 2,
    EAndroidAudio_MAX                              = 3

};


// Enum  /Script/AndroidRuntimeSettings.EOculusMobileDevice
enum class EOculusMobileDevice : uint8_t
{
    Quest                                          = 1,
    Quest2                                         = 2,
    EOculusMobileDevice_MAX                        = 3

};


// Enum  /Script/AndroidRuntimeSettings.EAndroidInstallLocation
enum class EAndroidInstallLocation : uint8_t
{
    InternalOnly                                   = 0,
    PreferExternal                                 = 1,
    Auto                                           = 2,
    EAndroidInstallLocation_MAX                    = 3

};


// Enum  /Script/AndroidRuntimeSettings.EAndroidDepthBufferPreference
enum class EAndroidDepthBufferPreference : uint8_t
{
    Default                                        = 0,
    Bits16                                         = 16,
    Bits24                                         = 24,
    Bits32                                         = 32,
    EAndroidDepthBufferPreference_MAX              = 33

};


// Enum  /Script/AndroidRuntimeSettings.EAndroidScreenOrientation
enum class EAndroidScreenOrientation : uint8_t
{
    Portrait                                       = 0,
    ReversePortrait                                = 1,
    SensorPortrait                                 = 2,
    Landscape                                      = 3,
    ReverseLandscape                               = 4,
    SensorLandscape                                = 5,
    Sensor                                         = 6,
    FullSensor                                     = 7,
    EAndroidScreenOrientation_MAX                  = 8

};


// Enum  /Script/GameplayTasks.EGameplayTaskState
enum class EGameplayTaskState : uint8_t
{
    Uninitialized                                  = 0,
    AwaitingActivation                             = 1,
    Paused                                         = 2,
    Active                                         = 3,
    Finished                                       = 4,
    EGameplayTaskState_MAX                         = 5

};


// Enum  /Script/VectorVM.EVectorVMOp
enum class EVectorVMOp : uint8_t
{
    done                                           = 0,
    add                                            = 1,
    sub                                            = 2,
    mul                                            = 3,
    div                                            = 4,
    mad                                            = 5,
    lerp                                           = 6,
    rcp                                            = 7,
    rsq                                            = 8,
    sqrt                                           = 9,
    neg                                            = 10,
    abs                                            = 11,
    exp                                            = 12,
    exp2                                           = 13,
    log                                            = 14,
    log2                                           = 15,
    sin                                            = 16,
    cos                                            = 17,
    tan                                            = 18,
    asin                                           = 19,
    acos                                           = 20,
    atan                                           = 21,
    atan2                                          = 22,
    ceil                                           = 23,
    floor                                          = 24,
    fmod                                           = 25,
    frac                                           = 26,
    trunc                                          = 27,
    clamp                                          = 28,
    min                                            = 29,
    max                                            = 30,
    pow                                            = 31,
    round                                          = 32,
    sign                                           = 33,
    step                                           = 34,
    random                                         = 35,
    noise                                          = 36,
    cmplt                                          = 37,
    cmple                                          = 38,
    cmpgt                                          = 39,
    cmpge                                          = 40,
    cmpeq                                          = 41,
    cmpneq                                         = 42,
    select                                         = 43,
    addi                                           = 44,
    subi                                           = 45,
    muli                                           = 46,
    divi                                           = 47,
    clampi                                         = 48,
    mini                                           = 49,
    maxi                                           = 50,
    absi                                           = 51,
    negi                                           = 52,
    signi                                          = 53,
    randomi                                        = 54,
    cmplti                                         = 55,
    cmplei                                         = 56,
    cmpgti                                         = 57,
    cmpgei                                         = 58,
    cmpeqi                                         = 59,
    cmpneqi                                        = 60,
    bit_and                                        = 61,
    bit_or                                         = 62,
    bit_xor                                        = 63,
    bit_not                                        = 64,
    bit_lshift                                     = 65,
    bit_rshift                                     = 66,
    logic_and                                      = 67,
    logic_or                                       = 68,
    logic_xor                                      = 69,
    logic_not                                      = 70,
    f2i                                            = 71,
    i2f                                            = 72,
    f2b                                            = 73,
    b2f                                            = 74,
    i2b                                            = 75,
    b2i                                            = 76,
    inputdata_float                                = 77,
    inputdata_int32                                = 78,
    inputdata_half                                 = 79,
    inputdata_noadvance_float                      = 80,
    inputdata_noadvance_int32                      = 81,
    inputdata_noadvance_half                       = 82,
    outputdata_float                               = 83,
    outputdata_int32                               = 84,
    outputdata_half                                = 85,
    acquireindex                                   = 86,
    external_func_call                             = 87,
    exec_index                                     = 88,
    noise2D                                        = 89,
    noise3D                                        = 90,
    enter_stat_scope                               = 91,
    exit_stat_scope                                = 92,
    update_id                                      = 93,
    acquire_id                                     = 94,
    NumOpcodes                                     = 95

};


// Enum  /Script/VectorVM.EVectorVMOperandLocation
enum class EVectorVMOperandLocation : uint8_t
{
    Register                                       = 0,
    Constant                                       = 1,
    Num                                            = 2,
    EVectorVMOperandLocation_MAX                   = 3

};


// Enum  /Script/VectorVM.EVectorVMBaseTypes
enum class EVectorVMBaseTypes : uint8_t
{
    Float                                          = 0,
    Int                                            = 1,
    Bool                                           = 2,
    Num                                            = 3,
    EVectorVMBaseTypes_MAX                         = 4

};


// Enum  /Script/NavigationSystem.ERuntimeGenerationType
enum class ERuntimeGenerationType : uint8_t
{
    Static                                         = 0,
    DynamicModifiersOnly                           = 1,
    Dynamic                                        = 2,
    LegacyGeneration                               = 3,
    ERuntimeGenerationType_MAX                     = 4

};


// Enum  /Script/NavigationSystem.EPathFindingMode
enum class EPathFindingMode : uint8_t
{
    Regular                                        = 0,
    Hierarchical                                   = 1,
    RoutePath                                      = 2,
    EPathFindingMode_MAX                           = 3

};


// Enum  /Script/NavigationSystem.ENavCostDisplay
enum class ENavCostDisplay : uint8_t
{
    TotalCost                                      = 0,
    HeuristicOnly                                  = 1,
    RealCostOnly                                   = 2,
    ENavCostDisplay_MAX                            = 3

};


// Enum  /Script/NavigationSystem.ENavSystemOverridePolicy
enum class ENavSystemOverridePolicy : uint8_t
{
    Override                                       = 0,
    Append                                         = 1,
    Skip                                           = 2,
    ENavSystemOverridePolicy_MAX                   = 3

};


// Enum  /Script/NavigationSystem.ERecastPartitioning
enum class ERecastPartitioning : uint8_t
{
    Monotone                                       = 0,
    Watershed                                      = 1,
    ChunkyMonotone                                 = 2,
    ERecastPartitioning_MAX                        = 3

};


// Enum  /Script/AIModule.EAISenseNotifyType
enum class EAISenseNotifyType : uint8_t
{
    OnEveryPerception                              = 0,
    OnPerceptionChange                             = 1,
    EAISenseNotifyType_MAX                         = 2

};


// Enum  /Script/AIModule.EAITaskPriority
enum class EAITaskPriority : uint8_t
{
    Lowest                                         = 0,
    Low                                            = 64,
    AutonomousAI                                   = 127,
    High                                           = 192,
    Ultimate                                       = 254,
    EAITaskPriority_MAX                            = 255

};


// Enum  /Script/AIModule.EGenericAICheck
enum class EGenericAICheck : uint8_t
{
    Less                                           = 0,
    LessOrEqual                                    = 1,
    Equal                                          = 2,
    NotEqual                                       = 3,
    GreaterOrEqual                                 = 4,
    Greater                                        = 5,
    IsTrue                                         = 6,
    MAX                                            = 7

};


// Enum  /Script/AIModule.EAILockSource
enum class EAILockSource : uint8_t
{
    Animation                                      = 0,
    Logic                                          = 1,
    Script                                         = 2,
    Gameplay                                       = 3,
    MAX                                            = 4

};


// Enum  /Script/AIModule.EAIRequestPriority
enum class EAIRequestPriority : uint8_t
{
    SoftScript                                     = 0,
    Logic                                          = 1,
    HardScript                                     = 2,
    Reaction                                       = 3,
    Ultimate                                       = 4,
    MAX                                            = 5

};


// Enum  /Script/AIModule.EPawnActionEventType
enum class EPawnActionEventType : uint8_t
{
    Invalid                                        = 0,
    FailedToStart                                  = 1,
    InstantAbort                                   = 2,
    FinishedAborting                               = 3,
    FinishedExecution                              = 4,
    Push                                           = 5,
    EPawnActionEventType_MAX                       = 6

};


// Enum  /Script/AIModule.EPawnActionResult
enum class EPawnActionResult : uint8_t
{
    NotStarted                                     = 0,
    InProgress                                     = 1,
    Success                                        = 2,
    Failed                                         = 3,
    Aborted                                        = 4,
    EPawnActionResult_MAX                          = 5

};


// Enum  /Script/AIModule.EPawnActionAbortState
enum class EPawnActionAbortState : uint8_t
{
    NeverStarted                                   = 0,
    NotBeingAborted                                = 1,
    MarkPendingAbort                               = 2,
    LatentAbortInProgress                          = 3,
    AbortDone                                      = 4,
    MAX                                            = 5

};


// Enum  /Script/AIModule.FAIDistanceType
enum class FAIDistanceType : uint8_t
{
    Distance3D                                     = 0,
    Distance2D                                     = 1,
    DistanceZ                                      = 2,
    MAX                                            = 3

};


// Enum  /Script/AIModule.EAIOptionFlag
enum class EAIOptionFlag : uint8_t
{
    Default                                        = 0,
    Enable                                         = 1,
    Disable                                        = 2,
    MAX                                            = 3

};


// Enum  /Script/AIModule.EBTFlowAbortMode
enum class EBTFlowAbortMode : uint8_t
{
    None                                           = 0,
    LowerPriority                                  = 1,
    Self                                           = 2,
    Both                                           = 3,
    EBTFlowAbortMode_MAX                           = 4

};


// Enum  /Script/AIModule.EBTNodeResult
enum class EBTNodeResult : uint8_t
{
    Succeeded                                      = 0,
    Failed                                         = 1,
    Aborted                                        = 2,
    InProgress                                     = 3,
    EBTNodeResult_MAX                              = 4

};


// Enum  /Script/AIModule.ETextKeyOperation
enum class ETextKeyOperation : uint8_t
{
    Equal                                          = 0,
    NotEqual                                       = 1,
    Contain                                        = 2,
    NotContain                                     = 3,
    ETextKeyOperation_MAX                          = 4

};


// Enum  /Script/AIModule.EArithmeticKeyOperation
enum class EArithmeticKeyOperation : uint8_t
{
    Equal                                          = 0,
    NotEqual                                       = 1,
    Less                                           = 2,
    LessOrEqual                                    = 3,
    Greater                                        = 4,
    GreaterOrEqual                                 = 5,
    EArithmeticKeyOperation_MAX                    = 6

};


// Enum  /Script/AIModule.EBasicKeyOperation
enum class EBasicKeyOperation : uint8_t
{
    Set                                            = 0,
    NotSet                                         = 1,
    EBasicKeyOperation_MAX                         = 2

};


// Enum  /Script/AIModule.EBTParallelMode
enum class EBTParallelMode : uint8_t
{
    AbortBackground                                = 0,
    WaitForBackground                              = 1,
    EBTParallelMode_MAX                            = 2

};


// Enum  /Script/AIModule.EBTDecoratorLogic
enum class EBTDecoratorLogic : uint8_t
{
    Invalid                                        = 0,
    Test                                           = 1,
    And                                            = 2,
    Or                                             = 3,
    Not                                            = 4,
    EBTDecoratorLogic_MAX                          = 5

};


// Enum  /Script/AIModule.EBTChildIndex
enum class EBTChildIndex : uint8_t
{
    FirstNode                                      = 0,
    TaskNode                                       = 1,
    EBTChildIndex_MAX                              = 2

};


// Enum  /Script/AIModule.EBTBlackboardRestart
enum class EBTBlackboardRestart : uint8_t
{
    ValueChange                                    = 0,
    ResultChange                                   = 1,
    EBTBlackboardRestart_MAX                       = 2

};


// Enum  /Script/AIModule.EBlackBoardEntryComparison
enum class EBlackBoardEntryComparison : uint8_t
{
    Equal                                          = 0,
    NotEqual                                       = 1,
    EBlackBoardEntryComparison_MAX                 = 2

};


// Enum  /Script/AIModule.EPathExistanceQueryType
enum class EPathExistanceQueryType : uint8_t
{
    NavmeshRaycast2D                               = 0,
    HierarchicalQuery                              = 1,
    RegularPathFinding                             = 2,
    PathWithOutArea                                = 3,
    EPathExistanceQueryType_MAX                    = 4

};


// Enum  /Script/AIModule.EPointOnCircleSpacingMethod
enum class EPointOnCircleSpacingMethod : uint8_t
{
    BySpaceBetween                                 = 0,
    ByNumberOfPoints                               = 1,
    EPointOnCircleSpacingMethod_MAX                = 2

};


// Enum  /Script/AIModule.EEQSNormalizationType
enum class EEQSNormalizationType : uint8_t
{
    Absolute                                       = 0,
    RelativeToScores                               = 1,
    EEQSNormalizationType_MAX                      = 2

};


// Enum  /Script/AIModule.EEnvTestDistance
enum class EEnvTestDistance : uint8_t
{
    Distance3D                                     = 0,
    Distance2D                                     = 1,
    DistanceZ                                      = 2,
    DistanceAbsoluteZ                              = 3,
    EEnvTestDistance_MAX                           = 4

};


// Enum  /Script/AIModule.EEnvTestDot
enum class EEnvTestDot : uint8_t
{
    Dot3D                                          = 0,
    Dot2D                                          = 1,
    EEnvTestDot_MAX                                = 2

};


// Enum  /Script/AIModule.EEnvTestPathfinding
enum class EEnvTestPathfinding : uint8_t
{
    PathExist                                      = 0,
    PathCost                                       = 1,
    PathLength                                     = 2,
    EEnvTestPathfinding_MAX                        = 3

};


// Enum  /Script/AIModule.EEnvQueryTestClamping
enum class EEnvQueryTestClamping : uint8_t
{
    None                                           = 0,
    SpecifiedValue                                 = 1,
    FilterThreshold                                = 2,
    EEnvQueryTestClamping_MAX                      = 3

};


// Enum  /Script/AIModule.EEnvDirection
enum class EEnvDirection : uint8_t
{
    TwoPoints                                      = 0,
    Rotation                                       = 1,
    EEnvDirection_MAX                              = 2

};


// Enum  /Script/AIModule.EEnvOverlapShape
enum class EEnvOverlapShape : uint8_t
{
    Box                                            = 0,
    Sphere                                         = 1,
    Capsule                                        = 2,
    EEnvOverlapShape_MAX                           = 3

};


// Enum  /Script/AIModule.EEnvTraceShape
enum class EEnvTraceShape : uint8_t
{
    Line                                           = 0,
    Box                                            = 1,
    Sphere                                         = 2,
    Capsule                                        = 3,
    EEnvTraceShape_MAX                             = 4

};


// Enum  /Script/AIModule.EEnvQueryTrace
enum class EEnvQueryTrace : uint8_t
{
    None                                           = 0,
    Navigation                                     = 1,
    Geometry                                       = 2,
    NavigationOverLedges                           = 3,
    EEnvQueryTrace_MAX                             = 4

};


// Enum  /Script/AIModule.EAIParamType
enum class EAIParamType : uint8_t
{
    Float                                          = 0,
    Int                                            = 1,
    Bool                                           = 2,
    BBKey                                          = 3,
    MAX                                            = 4

};


// Enum  /Script/AIModule.EEnvQueryParam
enum class EEnvQueryParam : uint8_t
{
    Float                                          = 0,
    Int                                            = 1,
    Bool                                           = 2,
    EEnvQueryParam_MAX                             = 3

};


// Enum  /Script/AIModule.EEnvQueryRunMode
enum class EEnvQueryRunMode : uint8_t
{
    SingleResult                                   = 0,
    RandomBest5Pct                                 = 1,
    RandomBest25Pct                                = 2,
    AllMatching                                    = 3,
    EEnvQueryRunMode_MAX                           = 4

};


// Enum  /Script/AIModule.EEnvTestScoreOperator
enum class EEnvTestScoreOperator : uint8_t
{
    AverageScore                                   = 0,
    MinScore                                       = 1,
    MaxScore                                       = 2,
    Multiply                                       = 3,
    EEnvTestScoreOperator_MAX                      = 4

};


// Enum  /Script/AIModule.EEnvTestFilterOperator
enum class EEnvTestFilterOperator : uint8_t
{
    AllPass                                        = 0,
    AnyPass                                        = 1,
    EEnvTestFilterOperator_MAX                     = 2

};


// Enum  /Script/AIModule.EEnvTestCost
enum class EEnvTestCost : uint8_t
{
    Low                                            = 0,
    Medium                                         = 1,
    High                                           = 2,
    EEnvTestCost_MAX                               = 3

};


// Enum  /Script/AIModule.EEnvTestWeight
enum class EEnvTestWeight : uint8_t
{
    None                                           = 0,
    Square                                         = 1,
    Inverse                                        = 2,
    Unused                                         = 3,
    Constant                                       = 4,
    Skip                                           = 5,
    EEnvTestWeight_MAX                             = 6

};


// Enum  /Script/AIModule.EEnvTestScoreEquation
enum class EEnvTestScoreEquation : uint8_t
{
    Linear                                         = 0,
    Square                                         = 1,
    InverseLinear                                  = 2,
    SquareRoot                                     = 3,
    Constant                                       = 4,
    EEnvTestScoreEquation_MAX                      = 5

};


// Enum  /Script/AIModule.EEnvTestFilterType
enum class EEnvTestFilterType : uint8_t
{
    Minimum                                        = 0,
    Maximum                                        = 1,
    Range                                          = 2,
    Match                                          = 3,
    EEnvTestFilterType_MAX                         = 4

};


// Enum  /Script/AIModule.EEnvTestPurpose
enum class EEnvTestPurpose : uint8_t
{
    Filter                                         = 0,
    Score                                          = 1,
    FilterAndScore                                 = 2,
    EEnvTestPurpose_MAX                            = 3

};


// Enum  /Script/AIModule.EEnvQueryHightlightMode
enum class EEnvQueryHightlightMode : uint8_t
{
    All                                            = 0,
    Best5Pct                                       = 1,
    Best25Pct                                      = 2,
    EEnvQueryHightlightMode_MAX                    = 3

};


// Enum  /Script/AIModule.ETeamAttitude
enum class ETeamAttitude : uint8_t
{
    Friendly                                       = 0,
    Neutral                                        = 1,
    Hostile                                        = 2,
    ETeamAttitude_MAX                              = 3

};


// Enum  /Script/AIModule.EPathFollowingRequestResult
enum class EPathFollowingRequestResult : uint8_t
{
    Failed                                         = 0,
    AlreadyAtGoal                                  = 1,
    RequestSuccessful                              = 2,
    EPathFollowingRequestResult_MAX                = 3

};


// Enum  /Script/AIModule.EPathFollowingAction
enum class EPathFollowingAction : uint8_t
{
    Error                                          = 0,
    NoMove                                         = 1,
    DirectMove                                     = 2,
    PartialPath                                    = 3,
    PathToGoal                                     = 4,
    EPathFollowingAction_MAX                       = 5

};


// Enum  /Script/AIModule.EPathFollowingStatus
enum class EPathFollowingStatus : uint8_t
{
    Idle                                           = 0,
    Waiting                                        = 1,
    Paused                                         = 2,
    Moving                                         = 3,
    EPathFollowingStatus_MAX                       = 4

};


// Enum  /Script/AIModule.EPawnActionFailHandling
enum class EPawnActionFailHandling : uint8_t
{
    RequireSuccess                                 = 0,
    IgnoreFailure                                  = 1,
    EPawnActionFailHandling_MAX                    = 2

};


// Enum  /Script/AIModule.EPawnSubActionTriggeringPolicy
enum class EPawnSubActionTriggeringPolicy : uint8_t
{
    CopyBeforeTriggering                           = 0,
    ReuseInstances                                 = 1,
    EPawnSubActionTriggeringPolicy_MAX             = 2

};


// Enum  /Script/AIModule.EPawnActionMoveMode
enum class EPawnActionMoveMode : uint8_t
{
    UsePathfinding                                 = 0,
    StraightLine                                   = 1,
    EPawnActionMoveMode_MAX                        = 2

};


// Enum  /Script/RigVM.ERigVMParameterType
enum class ERigVMParameterType : uint8_t
{
    Input                                          = 0,
    Output                                         = 1,
    Invalid                                        = 2,
    ERigVMParameterType_MAX                        = 3

};


// Enum  /Script/RigVM.ERigVMOpCode
enum class ERigVMOpCode : uint8_t
{
    Execute_0_Operands                             = 0,
    Execute_1_Operands                             = 1,
    Execute_2_Operands                             = 2,
    Execute_3_Operands                             = 3,
    Execute_4_Operands                             = 4,
    Execute_5_Operands                             = 5,
    Execute_6_Operands                             = 6,
    Execute_7_Operands                             = 7,
    Execute_8_Operands                             = 8,
    Execute_9_Operands                             = 9,
    Execute_10_Operands                            = 10,
    Execute_11_Operands                            = 11,
    Execute_12_Operands                            = 12,
    Execute_13_Operands                            = 13,
    Execute_14_Operands                            = 14,
    Execute_15_Operands                            = 15,
    Execute_16_Operands                            = 16,
    Execute_17_Operands                            = 17,
    Execute_18_Operands                            = 18,
    Execute_19_Operands                            = 19,
    Execute_20_Operands                            = 20,
    Execute_21_Operands                            = 21,
    Execute_22_Operands                            = 22,
    Execute_23_Operands                            = 23,
    Execute_24_Operands                            = 24,
    Execute_25_Operands                            = 25,
    Execute_26_Operands                            = 26,
    Execute_27_Operands                            = 27,
    Execute_28_Operands                            = 28,
    Execute_29_Operands                            = 29,
    Execute_30_Operands                            = 30,
    Execute_31_Operands                            = 31,
    Execute_32_Operands                            = 32,
    Execute_33_Operands                            = 33,
    Execute_34_Operands                            = 34,
    Execute_35_Operands                            = 35,
    Execute_36_Operands                            = 36,
    Execute_37_Operands                            = 37,
    Execute_38_Operands                            = 38,
    Execute_39_Operands                            = 39,
    Execute_40_Operands                            = 40,
    Execute_41_Operands                            = 41,
    Execute_42_Operands                            = 42,
    Execute_43_Operands                            = 43,
    Execute_44_Operands                            = 44,
    Execute_45_Operands                            = 45,
    Execute_46_Operands                            = 46,
    Execute_47_Operands                            = 47,
    Execute_48_Operands                            = 48,
    Execute_49_Operands                            = 49,
    Execute_50_Operands                            = 50,
    Execute_51_Operands                            = 51,
    Execute_52_Operands                            = 52,
    Execute_53_Operands                            = 53,
    Execute_54_Operands                            = 54,
    Execute_55_Operands                            = 55,
    Execute_56_Operands                            = 56,
    Execute_57_Operands                            = 57,
    Execute_58_Operands                            = 58,
    Execute_59_Operands                            = 59,
    Execute_60_Operands                            = 60,
    Execute_61_Operands                            = 61,
    Execute_62_Operands                            = 62,
    Execute_63_Operands                            = 63,
    Execute_64_Operands                            = 64,
    Zero                                           = 65,
    BoolFalse                                      = 66,
    BoolTrue                                       = 67,
    Copy                                           = 68,
    Increment                                      = 69,
    Decrement                                      = 70,
    Equals                                         = 71,
    NotEquals                                      = 72,
    JumpAbsolute                                   = 73,
    JumpForward                                    = 74,
    JumpBackward                                   = 75,
    JumpAbsoluteIf                                 = 76,
    JumpForwardIf                                  = 77,
    JumpBackwardIf                                 = 78,
    ChangeType                                     = 79,
    Exit                                           = 80,
    BeginBlock                                     = 81,
    EndBlock                                       = 82,
    Invalid                                        = 83,
    ERigVMOpCode_MAX                               = 84

};


// Enum  /Script/RigVM.ERigVMPinDirection
enum class ERigVMPinDirection : uint8_t
{
    Input                                          = 0,
    Output                                         = 1,
    IO                                             = 2,
    Visible                                        = 3,
    Hidden                                         = 4,
    Invalid                                        = 5,
    ERigVMPinDirection_MAX                         = 6

};


// Enum  /Script/RigVM.ERigVMRegisterType
enum class ERigVMRegisterType : uint8_t
{
    Plain                                          = 0,
    String                                         = 1,
    Name                                           = 2,
    Struct                                         = 3,
    Invalid                                        = 4,
    ERigVMRegisterType_MAX                         = 5

};


// Enum  /Script/RigVM.ERigVMMemoryType
enum class ERigVMMemoryType : uint8_t
{
    Work                                           = 0,
    Literal                                        = 1,
    External                                       = 2,
    Invalid                                        = 3,
    ERigVMMemoryType_MAX                           = 4

};


// Enum  /Script/ChaosSolverEngine.EClusterConnectionTypeEnum
enum class EClusterConnectionTypeEnum : uint8_t
{
    Chaos_PointImplicit                            = 0,
    Chaos_DelaunayTriangulation                    = 1,
    Chaos_MinimalSpanningSubsetDelaunayTriangulation = 2,
    Chaos_PointImplicitAugmentedWithMinimalDelaunay = 3,
    Chaos_None                                     = 4,
    Chaos_EClsuterCreationParameters_Max           = 5,
    Chaos_MAX                                      = 6

};


// Enum  /Script/GeometryCollectionEngine.EChaosBreakingSortMethod
enum class EChaosBreakingSortMethod : uint8_t
{
    SortNone                                       = 0,
    SortByHighestMass                              = 1,
    SortByHighestSpeed                             = 2,
    SortByNearestFirst                             = 3,
    Count                                          = 4,
    EChaosBreakingSortMethod_MAX                   = 5

};


// Enum  /Script/GeometryCollectionEngine.EChaosCollisionSortMethod
enum class EChaosCollisionSortMethod : uint8_t
{
    SortNone                                       = 0,
    SortByHighestMass                              = 1,
    SortByHighestSpeed                             = 2,
    SortByHighestImpulse                           = 3,
    SortByNearestFirst                             = 4,
    Count                                          = 5,
    EChaosCollisionSortMethod_MAX                  = 6

};


// Enum  /Script/GeometryCollectionEngine.EChaosTrailingSortMethod
enum class EChaosTrailingSortMethod : uint8_t
{
    SortNone                                       = 0,
    SortByHighestMass                              = 1,
    SortByHighestSpeed                             = 2,
    SortByNearestFirst                             = 3,
    Count                                          = 4,
    EChaosTrailingSortMethod_MAX                   = 5

};


// Enum  /Script/GeometryCollectionEngine.EGeometryCollectionDebugDrawActorHideGeometry
enum class EGeometryCollectionDebugDrawActorHideGeometry : uint8_t
{
    HideNone                                       = 0,
    HideWithCollision                              = 1,
    HideSelected                                   = 2,
    HideWholeCollection                            = 3,
    HideAll                                        = 4,
    EGeometryCollectionDebugDrawActorHideGeometry_MAX = 5

};


// Enum  /Script/GeometryCollectionEngine.ECollectionGroupEnum
enum class ECollectionGroupEnum : uint8_t
{
    Chaos_Traansform                               = 0,
    Chaos_Max                                      = 1

};


// Enum  /Script/GeometryCollectionEngine.ECollectionAttributeEnum
enum class ECollectionAttributeEnum : uint8_t
{
    Chaos_Active                                   = 0,
    Chaos_DynamicState                             = 1,
    Chaos_CollisionGroup                           = 2,
    Chaos_Max                                      = 3

};


// Enum  /Script/SGASDebugger.EGASDebuggerNodeType
enum class EGASDebuggerNodeType : uint8_t
{
    TaskStart                                      = 0,
    TaskEnd                                        = 1,
    GAStart                                        = 2,
    GAEnd                                          = 3,
    GAFailure                                      = 4,
    StateStart                                     = 5,
    StateEnd                                       = 6,
    GEAdd                                          = 7,
    GERemove                                       = 8,
    CueAdd                                         = 9,
    CueRemove                                      = 10,
    Custom                                         = 11,
    SlotState                                      = 12,
    UIBlackBoard                                   = 13,
    InputEvent                                     = 14,
    EGASDebuggerNodeType_MAX                       = 15

};


// Enum  /Script/InteractiveToolsFramework.EInputCaptureState
enum class EInputCaptureState : uint8_t
{
    Begin                                          = 1,
    Continue                                       = 2,
    End                                            = 3,
    Ignore                                         = 4,
    EInputCaptureState_MAX                         = 5

};


// Enum  /Script/InteractiveToolsFramework.EInputCaptureRequestType
enum class EInputCaptureRequestType : uint8_t
{
    Begin                                          = 1,
    Ignore                                         = 2,
    EInputCaptureRequestType_MAX                   = 3

};


// Enum  /Script/InteractiveToolsFramework.EInputCaptureSide
enum class EInputCaptureSide : uint8_t
{
    None                                           = 0,
    Left                                           = 1,
    Right                                          = 2,
    Both                                           = 3,
    Any                                            = 99,
    EInputCaptureSide_MAX                          = 100

};


// Enum  /Script/InteractiveToolsFramework.EInputDevices
enum class EInputDevices : uint32_t
{
    None                                           = 0,
    Keyboard                                       = 1,
    Mouse                                          = 2,
    Gamepad                                        = 4,
    OculusTouch                                    = 8,
    HTCViveWands                                   = 16,
    AnySpatialDevice                               = 24,
    TabletFingers                                  = 1024,
    EInputDevices_MAX                              = 1025

};


// Enum  /Script/InteractiveToolsFramework.ETransformGizmoSubElements
enum class ETransformGizmoSubElements : uint32_t
{
    None                                           = 0,
    TranslateAxisX                                 = 2,
    TranslateAxisY                                 = 4,
    TranslateAxisZ                                 = 8,
    TranslateAllAxes                               = 14,
    TranslatePlaneXY                               = 16,
    TranslatePlaneXZ                               = 32,
    TranslatePlaneYZ                               = 64,
    TranslateAllPlanes                             = 112,
    RotateAxisX                                    = 128,
    RotateAxisY                                    = 256,
    RotateAxisZ                                    = 512,
    RotateAllAxes                                  = 896,
    ScaleAxisX                                     = 1024,
    ScaleAxisY                                     = 2048,
    ScaleAxisZ                                     = 4096,
    ScaleAllAxes                                   = 7168,
    ScalePlaneYZ                                   = 8192,
    ScalePlaneXZ                                   = 16384,
    ScalePlaneXY                                   = 32768,
    ScaleAllPlanes                                 = 57344,
    ScaleUniform                                   = 65536,
    StandardTranslateRotate                        = 1022,
    TranslateRotateUniformScale                    = 66558,
    FullTranslateRotateScale                       = 131070,
    ETransformGizmoSubElements_MAX                 = 131071

};


// Enum  /Script/InteractiveToolsFramework.EToolChangeTrackingMode
enum class EToolChangeTrackingMode : uint8_t
{
    NoChangeTracking                               = 1,
    UndoToExit                                     = 2,
    FullUndoRedo                                   = 3,
    EToolChangeTrackingMode_MAX                    = 4

};


// Enum  /Script/InteractiveToolsFramework.EToolSide
enum class EToolSide : uint8_t
{
    Left                                           = 1,
    Mouse                                          = 1,
    Right                                          = 2,
    EToolSide_MAX                                  = 3

};


// Enum  /Script/InteractiveToolsFramework.EViewInteractionState
enum class EViewInteractionState : uint8_t
{
    None                                           = 0,
    Hovered                                        = 1,
    Focused                                        = 2,
    EViewInteractionState_MAX                      = 3

};


// Enum  /Script/InteractiveToolsFramework.ESelectedObjectsModificationType
enum class ESelectedObjectsModificationType : uint8_t
{
    Replace                                        = 0,
    Add                                            = 1,
    Remove                                         = 2,
    Clear                                          = 3,
    ESelectedObjectsModificationType_MAX           = 4

};


// Enum  /Script/InteractiveToolsFramework.EToolMessageLevel
enum class EToolMessageLevel : uint8_t
{
    Internal                                       = 0,
    UserMessage                                    = 1,
    UserNotification                               = 2,
    UserWarning                                    = 3,
    UserError                                      = 4,
    EToolMessageLevel_MAX                          = 5

};


// Enum  /Script/InteractiveToolsFramework.EToolContextCoordinateSystem
enum class EToolContextCoordinateSystem : uint8_t
{
    World                                          = 0,
    Local                                          = 1,
    EToolContextCoordinateSystem_MAX               = 2

};


// Enum  /Script/InteractiveToolsFramework.EStandardToolContextMaterials
enum class EStandardToolContextMaterials : uint8_t
{
    VertexColorMaterial                            = 1,
    EStandardToolContextMaterials_MAX              = 2

};


// Enum  /Script/InteractiveToolsFramework.ESceneSnapQueryTargetType
enum class ESceneSnapQueryTargetType : uint8_t
{
    None                                           = 0,
    MeshVertex                                     = 1,
    MeshEdge                                       = 2,
    Grid                                           = 4,
    All                                            = 7,
    ESceneSnapQueryTargetType_MAX                  = 8

};


// Enum  /Script/InteractiveToolsFramework.ESceneSnapQueryType
enum class ESceneSnapQueryType : uint8_t
{
    Position                                       = 1,
    Rotation                                       = 2,
    ESceneSnapQueryType_MAX                        = 3

};


// Enum  /Script/Basic.ESGDeviceQualityLevel
enum class ESGDeviceQualityLevel : uint8_t
{
    Low                                            = 0,
    Mid                                            = 1,
    High                                           = 2,
    Ultra                                          = 3,
    ESGDeviceQualityLevel_MAX                      = 4

};


// Enum  /Script/Basic.EFireWallInterpolationType
enum class EFireWallInterpolationType : uint8_t
{
    None                                           = 0,
    Linear                                         = 1,
    Bezier                                         = 2,
    EFireWallInterpolationType_MAX                 = 3

};


// Enum  /Script/Basic.ESGPreloadResLifeTime
enum class ESGPreloadResLifeTime : uint8_t
{
    Game                                           = 0,
    Lobby                                          = 1,
    Permanent                                      = 2,
    GameResult                                     = 3,
    ESGPreloadResLifeTime_MAX                      = 4

};


// Enum  /Script/Basic.EUnloadLevel
enum class EUnloadLevel : uint8_t
{
    Notice                                         = 0,
    Warning                                        = 1,
    Danger                                         = 2,
    Permanent                                      = 3,
    EUnloadLevel_MAX                               = 4

};


// Enum  /Script/Basic.EAutoTestInputType
enum class EAutoTestInputType : uint8_t
{
    EAutoTestInputType_None                        = 0,
    EAutoTestInputType_Press                       = 1,
    EAutoTestInputType_Release                     = 2,
    EAutoTestInputType_Click                       = 3,
    EAutoTestInputType_MAX                         = 4

};


// Enum  /Script/Basic.ECharacterState
enum class ECharacterState : uint8_t
{
    ECharacterState_None                           = 0,
    ECharacterState_Dead                           = 1,
    ECharacterState_Spawn                          = 2,
    ECharacterState_GetDamage                      = 3,
    ECharacterState_MAX                            = 4

};


// Enum  /Script/Basic.ECharacterAction
enum class ECharacterAction : uint8_t
{
    ECharacterAction_None                          = 0,
    ECharacterAction_Jump                          = 1,
    ECharacterAction_Move                          = 2,
    ECharacterAction_Crouch                        = 3,
    ECharacterAction_Stand                         = 4,
    ECharacterAction_MAX                           = 5

};


// Enum  /Script/Basic.ESGDecalType
enum class ESGDecalType : uint8_t
{
    ESGDecal_None                                  = 0,
    ESGDecal_Scene                                 = 1,
    ESGDecal_SprayPaint                            = 2,
    ESGDecal_WeaponBullet                          = 3,
    ESGDecal_Ability                               = 4,
    ESGDecal_Max                                   = 5

};


// Enum  /Script/Basic.ESGExtendTrack
enum class ESGExtendTrack : uint8_t
{
    ExtendTrack1                                   = 0,
    ExtendTrack2                                   = 1,
    ExtendTrack3                                   = 2,
    ExtendTrack4                                   = 3,
    ExtendTrack5                                   = 4,
    ExtendTrack6                                   = 5,
    ExtendTrack7                                   = 6,
    ExtendTrack8                                   = 7,
    ExtendTrack9                                   = 8,
    ExtendTrack10                                  = 9,
    ExtendTrack11                                  = 10,
    ExtendTrack12                                  = 11,
    ExtendTrack13                                  = 12,
    ExtendTrack14                                  = 13,
    ExtendTrack15                                  = 14,
    ExtendTrack16                                  = 15,
    ExtendTrack17                                  = 16,
    ExtendTrack18                                  = 17,
    ExtendTrack19                                  = 18,
    ExtendTrack20                                  = 19,
    ExtendTrack21                                  = 20,
    ExtendTrack22                                  = 21,
    ExtendTrack23                                  = 22,
    ExtendTrack24                                  = 23,
    Max                                            = 24

};


// Enum  /Script/Basic.ECrossHairDrawMode
enum class ECrossHairDrawMode : uint8_t
{
    Default                                        = 0,
    Normal                                         = 1,
    Scope                                          = 2,
    Aiming                                         = 3,
    ECrossHairDrawMode_MAX                         = 4

};


// Enum  /Script/Basic.ECrossHairSettingPart
enum class ECrossHairSettingPart : uint8_t
{
    Focus                                          = 0,
    Inner                                          = 1,
    Outer                                          = 2,
    OutLine                                        = 3,
    ECrossHairSettingPart_MAX                      = 4

};


// Enum  /Script/Basic.ECrossHairDataType
enum class ECrossHairDataType : uint8_t
{
    Default                                        = 0,
    Observe                                        = 1,
    None                                           = 2,
    ECrossHairDataType_MAX                         = 3

};


// Enum  /Script/Basic.ECrossHairType
enum class ECrossHairType : uint8_t
{
    Normal                                         = 0,
    ShotGun                                        = 1,
    SniperRifle                                    = 2,
    ECrossHairType_MAX                             = 3

};


// Enum  /Script/Basic.ENetProfileMonitorArg
enum class ENetProfileMonitorArg : uint8_t
{
    FPS                                            = 0,
    ClientNum                                      = 1,
    Ping                                           = 2,
    OutLoss                                        = 3,
    InLoss                                         = 4,
    OutBytesPS                                     = 5,
    InBytesPS                                      = 6,
    OutSaturation                                  = 7,
    Lost                                           = 8,
    Close                                          = 9,
    Reconnect                                      = 10,
    RecBuf                                         = 11,
    Max                                            = 12

};


// Enum  /Script/Basic.ESoundBusType
enum class ESoundBusType : uint8_t
{
    Enemy_FootStep                                 = 0,
    Enemy_Guns_Exempt                              = 1,
    Enemy_Guns_Critical                            = 2,
    Enemy_Char_Skills                              = 3,
    MaxBus                                         = 4,
    ESoundBusType_MAX                              = 5

};


// Enum  /Script/Basic.ESwitchCharacterGroup
enum class ESwitchCharacterGroup : uint8_t
{
    Self                                           = 0,
    Enemy                                          = 1,
    Teammate                                       = 2,
    ESwitchCharacterGroup_MAX                      = 3

};


// Enum  /Script/Basic.ESwitchGroupType
enum class ESwitchGroupType : uint8_t
{
    CharacterGroup                                 = 0,
    Footstep                                       = 1,
    EnvImpact                                      = 2,
    CharacterImpact                                = 3,
    ESwitchGroupType_MAX                           = 4

};


// Enum  /Script/Basic.ESGSwitcherType
enum class ESGSwitcherType : uint8_t
{
    None                                           = 0,
    SwitcherType01                                 = 1,
    SwitcherType02                                 = 2,
    SwitcherType03                                 = 4,
    SwitcherType04                                 = 8,
    ESGSwitcherType_MAX                            = 9

};


// Enum  /Script/SGAvatar.ESGAvatarNiagaraParamType
enum class ESGAvatarNiagaraParamType : uint8_t
{
    ENone                                          = 0,
    ENumbericMin                                   = 0,
    EBool                                          = 1,
    EInt                                           = 2,
    EFloat                                         = 3,
    EVector2                                       = 4,
    EVector3                                       = 5,
    EVector4                                       = 6,
    ELinearColor                                   = 7,
    ERotator                                       = 8,
    ENumbericMax                                   = 9,
    EObjectMin                                     = 31,
    EObject                                        = 32,
    EMaterial                                      = 33,
    ETextureRT                                     = 34,
    EStaticMesh                                    = 35,
    EActor                                         = 36,
    EObjectMax                                     = 37,
    ESGAvatarNiagaraParamType_MAX                  = 38

};


// Enum  /Script/SGAvatar.ESGAvatarMeshActivationBits
enum class ESGAvatarMeshActivationBits : uint8_t
{
    ENone                                          = 0,
    EActivateMesh                                  = 1,
    EDeactivateMesh                                = 2,
    EActivateVisibility                            = 4,
    EDeactivateVisibility                          = 8,
    ESGAvatarMeshActivationBits_MAX                = 9

};


// Enum  /Script/SGAvatar.EMeshType
enum class EMeshType : uint8_t
{
    None                                           = 0,
    SkeletalMesh                                   = 1,
    StaticMesh                                     = 2,
    EMeshType_MAX                                  = 3

};


// Enum  /Script/SGAvatar.ESGVisibleMode
enum class ESGVisibleMode : uint8_t
{
    ENone                                          = 0,
    EVISIBLE                                       = 1,
    EINVISIBLE                                     = 2,
    ESGVisibleMode_MAX                             = 3

};


// Enum  /Script/SGAvatar.EAvatarEventType
enum class EAvatarEventType : uint8_t
{
    ET_PureEvent                                   = 0,
    ET_MatEvent                                    = 1,
    ET_DecorationEvent                             = 2,
    ET_MeshFXEevent                                = 3,
    Max                                            = 4

};


// Enum  /Script/SGAvatar.EMatParamType
enum class EMatParamType : uint8_t
{
    PT_None                                        = 0,
    PT_Float                                       = 1,
    PT_Color                                       = 2,
    PT_LinearColor                                 = 3,
    PT_Int                                         = 4,
    PT_String                                      = 5,
    PT_Location                                    = 6,
    Max                                            = 7

};


// Enum  /Script/SGAvatar.ESGAvatarLogLevel
enum class ESGAvatarLogLevel : uint8_t
{
    Verbose                                        = 0,
    Log                                            = 1,
    Warning                                        = 2,
    Error                                          = 3,
    ESGAvatarLogLevel_MAX                          = 4

};


// Enum  /Script/SGAvatar.ELoadAvatarReason
enum class ELoadAvatarReason : uint8_t
{
    None                                           = 0,
    AvatarIDChanged                                = 1,
    RefreshMesh                                    = 2,
    ELoadAvatarReason_MAX                          = 3

};


// Enum  /Script/SGAvatar.ESGExpressionType
enum class ESGExpressionType : uint8_t
{
    Expression_None                                = 0,
    Expression_Idle                                = 1,
    Expression_AltIdle                             = 2,
    Expression_MeleeIdle                           = 3,
    Expression_Fire                                = 4,
    Expression_AltFire                             = 5,
    Expression_ScopeIn                             = 6,
    Expression_ScopeOut                            = 7,
    Expression_MeleeFire                           = 8,
    Expression_GetHit                              = 9,
    Expression_Death                               = 10,
    Expression_MAX                                 = 11

};


// Enum  /Script/SGWeapon.EWeaponEffectTriggerCompareType
enum class EWeaponEffectTriggerCompareType : uint8_t
{
    CompareType_None                               = 0,
    CompareType_Greater                            = 1,
    CompareType_Less                               = 2,
    CompareType_Equal                              = 3,
    CompareType_MAX                                = 4

};


// Enum  /Script/SGWeapon.EWeaponEffectTriggerCheckType
enum class EWeaponEffectTriggerCheckType : uint8_t
{
    CheckType_None                                 = 0,
    CheckType_FireIndex                            = 1,
    CheckType_MAX                                  = 2

};


// Enum  /Script/SGWeapon.EMeleeWeaponAction
enum class EMeleeWeaponAction : uint8_t
{
    None                                           = 0,
    Attack1                                        = 1,
    Attack2                                        = 2,
    Attack3                                        = 3,
    EMeleeWeaponAction_MAX                         = 4

};


// Enum  /Script/SGWeapon.EWeaponAnimActionType
enum class EWeaponAnimActionType : uint8_t
{
    EWeaponAnim_None                               = 0,
    EWeaponAnim_Equip                              = 1,
    EWeaponAnim_EquipFast                          = 2,
    EWeaponAnim_EquipFirst                         = 3,
    EWeaponAnim_Fire                               = 4,
    EWeaponAnim_FirstFire                          = 5,
    EWeaponAnim_SecondaryFire                      = 6,
    EWeaponAnim_FinalFire                          = 7,
    EWeaponAnim_ScopeFinalFire                     = 8,
    EWeaponAnim_SubAttackBegin                     = 9,
    EWeaponAnim_SubAttack1                         = 10,
    EWeaponAnim_SubAttack2                         = 11,
    EWeaponAnim_SubAttack3                         = 12,
    EWeaponAnim_SubAttack4                         = 13,
    EWeaponAnim_SubAttack5                         = 14,
    EWeaponAnim_SubAttackEnd                       = 15,
    EWeaponAnim_Reload                             = 16,
    EWeaponAnim_EmptyReload                        = 17,
    EWeaponAnim_Inspect                            = 18,
    EWeaponAnim_BasePose                           = 19,
    EWeaponAnim_Movement                           = 20,
    EWeaponAnim_IdleAdd                            = 21,
    EWeaponAnim_WalkAdd                            = 22,
    EWeaponAnim_RunAdd                             = 23,
    EWeaponAnim_ToStand                            = 24,
    EWeaponAnim_ToCrouch                           = 25,
    EWeaponAnim_JumpStart                          = 26,
    EWeaponAnim_JumpLand                           = 27,
    EWeaponAnim_MoveAdditive                       = 28,
    EWeaponAnim_TurnAdditive                       = 29,
    EWeaponAnim_AltBasePose                        = 30,
    EWeaponAnim_AltMovement                        = 31,
    EWeaponAnim_AltIdleAdd                         = 32,
    EWeaponAnim_AltWalkAdd                         = 33,
    EWeaponAnim_AltRunAdd                          = 34,
    EWeaponAnim_AltJumpStart                       = 35,
    EWeaponAnim_AltJumpLand                        = 36,
    EWeaponAnim_Max                                = 37

};


// Enum  /Script/SGWeapon.ESGWeaponAvatarEventType
enum class ESGWeaponAvatarEventType : uint8_t
{
    ENone                                          = 0,
    EBeforeMeshApply                               = 1,
    EAfterMeshApply                                = 2,
    EViewModeChangeToFPP                           = 3,
    EViewModeChangeToTPP                           = 4,
    EWeaponActive                                  = 5,
    EWeaponDeactive                                = 6,
    EReloadIn                                      = 7,
    EReloadOut                                     = 8,
    EScopeIn                                       = 9,
    EScopeOut                                      = 10,
    EInspectIn                                     = 11,
    EInspectOut                                    = 12,
    EFire                                          = 13,
    EPrimaryAttack                                 = 14,
    ESecondaryAttack                               = 15,
    ESingleFire                                    = 16,
    EBurstFire                                     = 17,
    ERecoilIndexAccumulated                        = 18,
    ERecoilIndexReset                              = 19,
    ESelfRoundKillChange                           = 20,
    EAnyoneRoundKillChange                         = 21,
    ETopKiller                                     = 22,
    ESGWeaponAvatarEventType_MAX                   = 23

};


// Enum  /Script/SGWeapon.ESGWeaponFXParamType
enum class ESGWeaponFXParamType : uint8_t
{
    ENone                                          = 0,
    ENumbericMin                                   = 1,
    EBool                                          = 2,
    EInt                                           = 3,
    EFloat                                         = 4,
    EVector2                                       = 5,
    EVector3                                       = 6,
    EVector4                                       = 7,
    ELinearColor                                   = 8,
    ERotator                                       = 9,
    ENumbericMax                                   = 10,
    ECurveMin                                      = 11,
    EBoolCurve                                     = 12,
    EIntCurve                                      = 13,
    EFloatCurve                                    = 14,
    EVector2Curve                                  = 15,
    EVector3Curve                                  = 16,
    EVector4Curve                                  = 17,
    ELinearColorCurve                              = 18,
    ERotatorCurve                                  = 19,
    ECurveMax                                      = 20,
    ESGWeaponFXParamType_MAX                       = 21

};


// Enum  /Script/SGWeapon.EWeaponSoundType
enum class EWeaponSoundType : uint8_t
{
    None                                           = 0,
    PrimaryAttack                                  = 1,
    SecondaryAttack                                = 2,
    PrimaryScopeAttack                             = 3,
    SecondaryScopeAttack                           = 4,
    PrimaryFinalAttack                             = 5,
    PrimaryScopeFinalAttack                        = 6,
    PrimaryScopeBurstAttack1                       = 7,
    PrimaryScopeBurstAttack2                       = 8,
    PrimaryScopeBurstAttack3                       = 9,
    PrimaryScopeBurstAttack4                       = 10,
    Reload                                         = 11,
    Active                                         = 12,
    ActiveFast                                     = 13,
    ActiveFirst                                    = 14,
    ScopeIn                                        = 15,
    ScopeOut                                       = 16,
    EWeaponSoundType_MAX                           = 17

};


// Enum  /Script/SGWeapon.ESGWeaponMatParamType
enum class ESGWeaponMatParamType : uint8_t
{
    None                                           = 0,
    Mesh                                           = 1,
    Niagara                                        = 2,
    MPC                                            = 3,
    Num                                            = 4,
    ESGWeaponMatParamType_MAX                      = 5

};


// Enum  /Script/SGWeapon.EWeaponKillSound
enum class EWeaponKillSound : uint8_t
{
    None                                           = 0,
    FirstKill                                      = 1,
    SecondKill                                     = 2,
    ThirdKill                                      = 3,
    FourthKill                                     = 4,
    FifthKill                                      = 5,
    SixthKill                                      = 6,
    UIAppear                                       = 7,
    UIDisappear                                    = 8,
    Max                                            = 9

};


// Enum  /Script/SGWeapon.EProxyCommand
enum class EProxyCommand : uint8_t
{
    PrimaryAttack                                  = 0,
    SecondaryAttack                                = 1,
    ScopeIn                                        = 2,
    Reload                                         = 3,
    Inspect                                        = 4,
    EProxyCommand_MAX                              = 5

};


// Enum  /Script/SGWeapon.EStateParameter
enum class EStateParameter : uint8_t
{
    AuthSync                                       = 0,
    AutoTransition                                 = 1,
    Reset                                          = 2,
    RandSeed                                       = 3,
    PrimaryMode                                    = 7,
    ScopeMode                                      = 8,
    ActiveMode                                     = 9,
    ShootID                                        = 10,
    PostReload                                     = 11,
    BurstIndex                                     = 12,
    NotifyAnim                                     = 13,
    ScopeTrajectory                                = 14,
    ExtraStart                                     = 24,
    EStateParameter_MAX                            = 25

};


// Enum  /Script/SGWeapon.EWeaponBuddySpecType
enum class EWeaponBuddySpecType : uint8_t
{
    None                                           = 0,
    SpecMaterial                                   = 1,
    SpecColor                                      = 2,
    EWeaponBuddySpecType_MAX                       = 3

};


// Enum  /Script/SGWeapon.EMeleeAttackType
enum class EMeleeAttackType : uint8_t
{
    None                                           = 0,
    PrimaryAttack1                                 = 1,
    PrimaryAttack2                                 = 2,
    PrimaryAttack3                                 = 3,
    PrimaryAttack4                                 = 4,
    PrimaryAttack5                                 = 5,
    PrimaryAttack6                                 = 6,
    SecondaryAttack                                = 7,
    EMeleeAttackType_MAX                           = 8

};


// Enum  /Script/SGWeapon.EWeaponComponentCullingFlags
enum class EWeaponComponentCullingFlags : uint8_t
{
    Effect                                         = 0,
    StateManager                                   = 1,
    Launcher                                       = 2,
    Scope                                          = 3,
    Trajectory                                     = 4,
    Misc                                           = 5,
    Num                                            = 6,
    EWeaponComponentCullingFlags_MAX               = 7

};


// Enum  /Script/SGWeapon.EAccuracyRecoveryMethod
enum class EAccuracyRecoveryMethod : uint8_t
{
    None                                           = 0,
    Linear                                         = 1,
    Exp                                            = 2,
    EAccuracyRecoveryMethod_MAX                    = 3

};


// Enum  /Script/SGWeapon.EMacroScopeFireType
enum class EMacroScopeFireType : uint8_t
{
    None                                           = 0,
    PrevScope                                      = 1,
    PostScope                                      = 2,
    EMacroScopeFireType_MAX                        = 3

};


// Enum  /Script/SGWeapon.EWeaponReloadType
enum class EWeaponReloadType : uint8_t
{
    Magazine                                       = 0,
    OneByOne                                       = 1,
    EWeaponReloadType_MAX                          = 2

};


// Enum  /Script/SGWeapon.EWeaponSocketType
enum class EWeaponSocketType : uint8_t
{
    None                                           = 0,
    LeftHand                                       = 1,
    RightHand                                      = 2,
    TwoHand                                        = 3,
    EWeaponSocketType_MAX                          = 4

};


// Enum  /Script/SGWeapon.EWeaponPoseType
enum class EWeaponPoseType : uint8_t
{
    None                                           = 0,
    OneHand                                        = 1,
    TwoHand                                        = 2,
    EWeaponPoseType_MAX                            = 3

};


// Enum  /Script/SGWeapon.EWeaponStateSound
enum class EWeaponStateSound : uint8_t
{
    None                                           = 0,
    PrimaryAttack                                  = 1,
    SecondaryAttack                                = 2,
    PrimaryScopeAttack                             = 3,
    SecondaryScopeAttack                           = 4,
    Reload                                         = 5,
    EWeaponStateSound_MAX                          = 6

};


// Enum  /Script/SGWeapon.EWeaponSightType
enum class EWeaponSightType : uint8_t
{
    IronSight                                      = 0,
    ScopeSight                                     = 1,
    EWeaponSightType_MAX                           = 2

};


// Enum  /Script/SGWeapon.EWeaponType
enum class EWeaponType : uint8_t
{
    None                                           = 0,
    Melee                                          = 1,
    Pistol                                         = 2,
    Rifle                                          = 3,
    ShotGun                                        = 4,
    MachineGun                                     = 5,
    SubMachineGun                                  = 6,
    Sniper                                         = 7,
    EWeaponType_MAX                                = 8

};


// Enum  /Script/SGWeapon.EWeaponGameEffect
enum class EWeaponGameEffect : uint8_t
{
    None                                           = 0,
    Damage                                         = 1,
    EWeaponGameEffect_MAX                          = 2

};


// Enum  /Script/SGWeapon.ESGWeaponChroma
enum class ESGWeaponChroma : uint8_t
{
    None                                           = 0,
    Chroma1                                        = 1,
    Chroma2                                        = 2,
    Chroma3                                        = 3,
    Chroma4                                        = 4,
    Max                                            = 5

};


// Enum  /Script/SGWeapon.EWeaponAvatarSlot
enum class EWeaponAvatarSlot : uint8_t
{
    None                                           = 0,
    Master                                         = 1,
    Core                                           = 2,
    MainMagazine                                   = 3,
    ExtraMagazine                                  = 4,
    Scope                                          = 5,
    ScopeOverlay                                   = 6,
    Muzzle                                         = 7,
    Bullet                                         = 8,
    StaticBullet                                   = 9,
    PendentMount                                   = 10,
    PendentBuddy                                   = 11,
    Grip                                           = 12,
    Attach                                         = 24,
    Split0                                         = 30,
    Max                                            = 31

};


// Enum  /Script/SGWeapon.ESGWeaponBaseDataAssetType
enum class ESGWeaponBaseDataAssetType : uint8_t
{
    BaseImpactEffectData                           = 0,
    BaseSoundData                                  = 1,
    BaseDesaturateFxData                           = 2,
    BaseAssistData                                 = 3,
    ESGWeaponBaseDataAssetType_MAX                 = 4

};


// Enum  /Script/SGWeapon.EWeaponActionParam
enum class EWeaponActionParam : uint8_t
{
    None                                           = 0,
    IndexMask                                      = 7,
    IsScope                                        = 8,
    IsFinalFire                                    = 16,
    IsFirstFire                                    = 64,
    IsAdditiveFire                                 = 128,
    EWeaponActionParam_MAX                         = 129

};


// Enum  /Script/AndroidDeviceProfileSelector.EGradeScoreType
enum class EGradeScoreType : uint8_t
{
    GST_GPU                                        = 0,
    GST_Memory                                     = 1,
    GST_CPUCore                                    = 2,
    GST_CPUFreq                                    = 3,
    GST_MAX                                        = 4

};


// Enum  /Script/AndroidDeviceProfileSelector.EGradeType
enum class EGradeType : uint8_t
{
    GAT_Grade01                                    = 1,
    GAT_Grade02                                    = 2,
    GAT_Grade03                                    = 3,
    GAT_Grade04                                    = 4,
    GAT_Grade05                                    = 5,
    GAT_Grade06                                    = 6,
    GAT_Grade07                                    = 7,
    GAT_MAX                                        = 8

};


// UserDefinedEnum  /Script/Engine.Default__UserDefinedEnum
enum class Default__UserDefinedEnum : uint8_t
{

};


