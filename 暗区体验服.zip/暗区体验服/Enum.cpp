																/* Create by 无心 */
																/* B站ID: 无心geigei  */
																/* telegram群@wuxingeigei */
// Enum  /Script/CoreUObject.EInterpCurveMode
enum class EInterpCurveMode : uint8_t
{
    CIM_Linear                                     = 0,
    CIM_CurveAuto                                  = 1,
    CIM_Constant                                   = 2,
    CIM_CurveUser                                  = 3,
    CIM_CurveBreak                                 = 4,
    CIM_CurveAutoClamped                           = 5,
    CIM_MAX                                        = 6

};


// Enum  /Script/CoreUObject.Default__Enum
enum class Default__Enum : uint8_t
{

};


// Enum  /Script/CoreUObject.ERangeBoundTypes
enum class ERangeBoundTypes : uint8_t
{
    Exclusive                                      = 0,
    Inclusive                                      = 1,
    Open                                           = 2,
    ERangeBoundTypes_MAX                           = 3

};


// Enum  /Script/CoreUObject.ELocalizedTextSourceCategory
enum class ELocalizedTextSourceCategory : uint8_t
{
    Game                                           = 0,
    Engine                                         = 1,
    Editor                                         = 2,
    ELocalizedTextSourceCategory_MAX               = 3

};


// Enum  /Script/CoreUObject.EAutomationEventType
enum class EAutomationEventType : uint8_t
{
    Info                                           = 0,
    Warning                                        = 1,
    Error                                          = 2,
    EAutomationEventType_MAX                       = 3

};


// Enum  /Script/AndroidDeviceProfileSelector.ECompareType
enum class ECompareType : uint8_t
{
    CMP_Equal                                      = 0,
    CMP_Less                                       = 1,
    CMP_LessEqual                                  = 2,
    CMP_Greater                                    = 3,
    CMP_GreaterEqual                               = 4,
    CMP_NotEqual                                   = 5,
    CMP_Regex                                      = 6,
    CMP_EqualIgnore                                = 7,
    CMP_LessIgnore                                 = 8,
    CMP_LessEqualIgnore                            = 9,
    CMP_GreaterIgnore                              = 10,
    CMP_GreaterEqualIgnore                         = 11,
    CMP_NotEqualIgnore                             = 12,
    CMP_Hash                                       = 13,
    CMP_MAX                                        = 14

};


// Enum  /Script/AndroidDeviceProfileSelector.ESourceType
enum class ESourceType : uint8_t
{
    SRC_PreviousRegexMatch                         = 0,
    SRC_GpuFamily                                  = 1,
    SRC_GlVersion                                  = 2,
    SRC_AndroidVersion                             = 3,
    SRC_DeviceMake                                 = 4,
    SRC_DeviceModel                                = 5,
    SRC_DeviceBuildNumber                          = 6,
    SRC_VulkanVersion                              = 7,
    SRC_UsingHoudini                               = 8,
    SRC_VulkanAvailable                            = 9,
    SRC_CommandLine                                = 10,
    SRC_Hardware                                   = 11,
    SRC_Chipset                                    = 12,
    SRC_MAX                                        = 13

};


// Enum  /Script/AkAudio.EAkCallbackType
enum class EAkCallbackType : uint8_t
{
    EndOfEvent                                     = 0,
    Marker                                         = 2,
    Duration                                       = 3,
    Starvation                                     = 5,
    MusicPlayStarted                               = 7,
    MusicSyncBeat                                  = 8,
    MusicSyncBar                                   = 9,
    MusicSyncEntry                                 = 10,
    MusicSyncExit                                  = 11,
    MusicSyncGrid                                  = 12,
    MusicSyncUserCue                               = 13,
    MusicSyncPoint                                 = 14,
    MIDIEvent                                      = 16,
    EAkCallbackType_MAX                            = 17

};


// Enum  /Script/AkAudio.EAkResult
enum class EAkResult : uint8_t
{
    NotImplemented                                 = 0,
    Success                                        = 1,
    Fail                                           = 2,
    PartialSuccess                                 = 3,
    NotCompatible                                  = 4,
    AlreadyConnected                               = 5,
    InvalidFile                                    = 7,
    AudioFileHeaderTooLarge                        = 8,
    MaxReached                                     = 9,
    InvalidID                                      = 14,
    IDNotFound                                     = 15,
    InvalidInstanceID                              = 16,
    NoMoreData                                     = 17,
    InvalidStateGroup                              = 20,
    ChildAlreadyHasAParent                         = 21,
    InvalidLanguage                                = 22,
    CannotAddItseflAsAChild                        = 23,
    InvalidParameter                               = 31,
    ElementAlreadyInList                           = 35,
    PathNotFound                                   = 36,
    PathNoVertices                                 = 37,
    PathNotRunning                                 = 38,
    PathNotPaused                                  = 39,
    PathNodeAlreadyInList                          = 40,
    PathNodeNotInList                              = 41,
    DataNeeded                                     = 43,
    NoDataNeeded                                   = 44,
    DataReady                                      = 45,
    NoDataReady                                    = 46,
    InsufficientMemory                             = 52,
    Cancelled                                      = 53,
    UnknownBankID                                  = 54,
    BankReadError                                  = 56,
    InvalidSwitchType                              = 57,
    FormatNotReady                                 = 63,
    WrongBankVersion                               = 64,
    FileNotFound                                   = 66,
    DeviceNotReady                                 = 67,
    BankAlreadyLoaded                              = 69,
    RenderedFX                                     = 71,
    ProcessNeeded                                  = 72,
    ProcessDone                                    = 73,
    MemManagerNotInitialized                       = 74,
    StreamMgrNotInitialized                        = 75,
    SSEInstructionsNotSupported                    = 76,
    Busy                                           = 77,
    UnsupportedChannelConfig                       = 78,
    PluginMediaNotAvailable                        = 79,
    MustBeVirtualized                              = 80,
    CommandTooLarge                                = 81,
    RejectedByFilter                               = 82,
    InvalidCustomPlatformName                      = 83,
    DLLCannotLoad                                  = 84,
    DLLPathNotFound                                = 85,
    NoJavaVM                                       = 86,
    OpenSLError                                    = 87,
    PluginNotRegistered                            = 88,
    DataAlignmentError                             = 89,
    EAkResult_MAX                                  = 90

};


// Enum  /Script/AkAudio.EAkAndroidAudioAPI
enum class EAkAndroidAudioAPI : uint8_t
{
    AAudio                                         = 0,
    OpenSL_ES                                      = 1,
    EAkAndroidAudioAPI_MAX                         = 2

};


// Enum  /Script/AkAudio.EAkAudioSessionMode
enum class EAkAudioSessionMode : uint8_t
{
    Default                                        = 0,
    VoiceChat                                      = 1,
    GameChat                                       = 2,
    VideoRecording                                 = 3,
    Measurement                                    = 4,
    MoviePlayback                                  = 5,
    VideoChat                                      = 6,
    EAkAudioSessionMode_MAX                        = 7

};


// Enum  /Script/AkAudio.EAkAudioSessionCategoryOptions
enum class EAkAudioSessionCategoryOptions : uint8_t
{
    MixWithOthers                                  = 0,
    DuckOthers                                     = 1,
    AllowBluetooth                                 = 2,
    DefaultToSpeaker                               = 3,
    EAkAudioSessionCategoryOptions_MAX             = 4

};


// Enum  /Script/AkAudio.EAkAudioSessionCategory
enum class EAkAudioSessionCategory : uint8_t
{
    Ambient                                        = 0,
    SoloAmbient                                    = 1,
    PlayAndRecord                                  = 2,
    EAkAudioSessionCategory_MAX                    = 3

};


// Enum  /Script/AkAudio.EReflectionFilterBits
enum class EReflectionFilterBits : uint8_t
{
    Wall                                           = 0,
    Ceiling                                        = 1,
    Floor                                          = 2,
    EReflectionFilterBits_MAX                      = 3

};


// Enum  /Script/AkAudio.AkCodecId
enum class AkCodecId : uint8_t
{
    Bank                                           = 0,
    PCM                                            = 1,
    ADPCM                                          = 2,
    XMA                                            = 3,
    Vorbis                                         = 4,
    WiiADPCM                                       = 5,
    PCMEX                                          = 7,
    ExternalSource                                 = 8,
    XWMA                                           = 9,
    AAC                                            = 10,
    FilePackage                                    = 11,
    ATRAC9                                         = 12,
    VAG                                            = 13,
    ProfilerCapture                                = 14,
    AnalysisFile                                   = 15,
    MIDI                                           = 16,
    OpusNX                                         = 17,
    CAF                                            = 18,
    AkOpus                                         = 19,
    AkCodecId_MAX                                  = 20

};


// Enum  /Script/AkAudio.EAkMidiCcValues
enum class EAkMidiCcValues : uint8_t
{
    AkMidiCcBankSelectCoarse                       = 0,
    AkMidiCcModWheelCoarse                         = 1,
    AkMidiCcBreathCtrlCoarse                       = 2,
    AkMidiCcCtrl3Coarse                            = 3,
    AkMidiCcFootPedalCoarse                        = 4,
    AkMidiCcPortamentoCoarse                       = 5,
    AkMidiCcDataEntryCoarse                        = 6,
    AkMidiCcVolumeCoarse                           = 7,
    AkMidiCcBalanceCoarse                          = 8,
    AkMidiCcCtrl9Coarse                            = 9,
    AkMidiCcPanPositionCoarse                      = 10,
    AkMidiCcExpressionCoarse                       = 11,
    AkMidiCcEffectCtrl1Coarse                      = 12,
    AkMidiCcEffectCtrl2Coarse                      = 13,
    AkMidiCcCtrl14Coarse                           = 14,
    AkMidiCcCtrl15Coarse                           = 15,
    AkMidiCcGenSlider1                             = 16,
    AkMidiCcGenSlider2                             = 17,
    AkMidiCcGenSlider3                             = 18,
    AkMidiCcGenSlider4                             = 19,
    AkMidiCcCtrl20Coarse                           = 20,
    AkMidiCcCtrl21Coarse                           = 21,
    AkMidiCcCtrl22Coarse                           = 22,
    AkMidiCcCtrl23Coarse                           = 23,
    AkMidiCcCtrl24Coarse                           = 24,
    AkMidiCcCtrl25Coarse                           = 25,
    AkMidiCcCtrl26Coarse                           = 26,
    AkMidiCcCtrl27Coarse                           = 27,
    AkMidiCcCtrl28Coarse                           = 28,
    AkMidiCcCtrl29Coarse                           = 29,
    AkMidiCcCtrl30Coarse                           = 30,
    AkMidiCcCtrl31Coarse                           = 31,
    AkMidiCcBankSelectFine                         = 32,
    AkMidiCcModWheelFine                           = 33,
    AkMidiCcBreathCtrlFine                         = 34,
    AkMidiCcCtrl3Fine                              = 35,
    AkMidiCcFootPedalFine                          = 36,
    AkMidiCcPortamentoFine                         = 37,
    AkMidiCcDataEntryFine                          = 38,
    AkMidiCcVolumeFine                             = 39,
    AkMidiCcBalanceFine                            = 40,
    AkMidiCcCtrl9Fine                              = 41,
    AkMidiCcPanPositionFine                        = 42,
    AkMidiCcExpressionFine                         = 43,
    AkMidiCcEffectCtrl1Fine                        = 44,
    AkMidiCcEffectCtrl2Fine                        = 45,
    AkMidiCcCtrl14Fine                             = 46,
    AkMidiCcCtrl15Fine                             = 47,
    AkMidiCcCtrl20Fine                             = 52,
    AkMidiCcCtrl21Fine                             = 53,
    AkMidiCcCtrl22Fine                             = 54,
    AkMidiCcCtrl23Fine                             = 55,
    AkMidiCcCtrl24Fine                             = 56,
    AkMidiCcCtrl25Fine                             = 57,
    AkMidiCcCtrl26Fine                             = 58,
    AkMidiCcCtrl27Fine                             = 59,
    AkMidiCcCtrl28Fine                             = 60,
    AkMidiCcCtrl29Fine                             = 61,
    AkMidiCcCtrl30Fine                             = 62,
    AkMidiCcCtrl31Fine                             = 63,
    AkMidiCcHoldPedal                              = 64,
    AkMidiCcPortamentoOnOff                        = 65,
    AkMidiCcSustenutoPedal                         = 66,
    AkMidiCcSoftPedal                              = 67,
    AkMidiCcLegatoPedal                            = 68,
    AkMidiCcHoldPedal2                             = 69,
    AkMidiCcSoundVariation                         = 70,
    AkMidiCcSoundTimbre                            = 71,
    AkMidiCcSoundReleaseTime                       = 72,
    AkMidiCcSoundAttackTime                        = 73,
    AkMidiCcSoundBrightness                        = 74,
    AkMidiCcSoundCtrl6                             = 75,
    AkMidiCcSoundCtrl7                             = 76,
    AkMidiCcSoundCtrl8                             = 77,
    AkMidiCcSoundCtrl9                             = 78,
    AkMidiCcSoundCtrl10                            = 79,
    AkMidiCcGeneralButton1                         = 80,
    AkMidiCcGeneralButton2                         = 81,
    AkMidiCcGeneralButton3                         = 82,
    AkMidiCcGeneralButton4                         = 83,
    AkMidiCcReverbLevel                            = 91,
    AkMidiCcTremoloLevel                           = 92,
    AkMidiCcChorusLevel                            = 93,
    AkMidiCcCelesteLevel                           = 94,
    AkMidiCcPhaserLevel                            = 95,
    AkMidiCcDataButtonP1                           = 96,
    AkMidiCcDataButtonM1                           = 97,
    AkMidiCcNonRegisterCoarse                      = 98,
    AkMidiCcNonRegisterFine                        = 99,
    AkMidiCcAllSoundOff                            = 120,
    AkMidiCcAllControllersOff                      = 121,
    AkMidiCcLocalKeyboard                          = 122,
    AkMidiCcAllNotesOff                            = 123,
    AkMidiCcOmniModeOff                            = 124,
    AkMidiCcOmniModeOn                             = 125,
    AkMidiCcOmniMonophonicOn                       = 126,
    AkMidiCcOmniPolyphonicOn                       = 127,
    EAkMidiCcValues_MAX                            = 128

};


// Enum  /Script/AkAudio.EAkMidiEventType
enum class EAkMidiEventType : uint8_t
{
    AkMidiEventTypeInvalid                         = 0,
    AkMidiEventTypeNoteOff                         = 128,
    AkMidiEventTypeNoteOn                          = 144,
    AkMidiEventTypeNoteAftertouch                  = 160,
    AkMidiEventTypeController                      = 176,
    AkMidiEventTypeProgramChange                   = 192,
    AkMidiEventTypeChannelAftertouch               = 208,
    AkMidiEventTypePitchBend                       = 224,
    AkMidiEventTypeSysex                           = 240,
    AkMidiEventTypeEscape                          = 247,
    AkMidiEventTypeMeta                            = 255,
    EAkMidiEventType_MAX                           = 256

};


// Enum  /Script/AkAudio.ERTPCValueType
enum class ERTPCValueType : uint8_t
{
    Default                                        = 0,
    Global                                         = 1,
    GameObject                                     = 2,
    PlayingID                                      = 3,
    Unavailable                                    = 4,
    ERTPCValueType_MAX                             = 5

};


// Enum  /Script/AkAudio.EAkCurveInterpolation
enum class EAkCurveInterpolation : uint8_t
{
    Log3                                           = 0,
    Sine                                           = 1,
    Log1                                           = 2,
    InvSCurve                                      = 3,
    Linear                                         = 4,
    SCurve                                         = 5,
    Exp1                                           = 6,
    SineRecip                                      = 7,
    Exp3                                           = 8,
    LastFadeCurve                                  = 8,
    Constant                                       = 9,
    EAkCurveInterpolation_MAX                      = 10

};


// Enum  /Script/AkAudio.AkActionOnEventType
enum class AkActionOnEventType : uint8_t
{
    Stop                                           = 0,
    Pause                                          = 1,
    Resume                                         = 2,
    Break                                          = 3,
    ReleaseEnvelope                                = 4,
    AkActionOnEventType_MAX                        = 5

};


// Enum  /Script/AkAudio.AkMultiPositionType
enum class AkMultiPositionType : uint8_t
{
    SingleSource                                   = 0,
    MultiSources                                   = 1,
    MultiDirections                                = 2,
    AkMultiPositionType_MAX                        = 3

};


// Enum  /Script/AkAudio.AkSpeakerConfiguration
enum class AkSpeakerConfiguration : uint32_t
{
    Ak_Speaker_Front_Left                          = 1,
    Ak_Speaker_Front_Right                         = 2,
    Ak_Speaker_Front_Center                        = 4,
    Ak_Speaker_Low_Frequency                       = 8,
    Ak_Speaker_Back_Left                           = 16,
    Ak_Speaker_Back_Right                          = 32,
    Ak_Speaker_Back_Center                         = 256,
    Ak_Speaker_Side_Left                           = 512,
    Ak_Speaker_Side_Right                          = 1024,
    Ak_Speaker_Top                                 = 2048,
    Ak_Speaker_Height_Front_Left                   = 4096,
    Ak_Speaker_Height_Front_Center                 = 8192,
    Ak_Speaker_Height_Front_Right                  = 16384,
    Ak_Speaker_Height_Back_Left                    = 32768,
    Ak_Speaker_Height_Back_Center                  = 65536,
    Ak_Speaker_Height_Back_Right                   = 131072,
    Ak_Speaker_MAX                                 = 131073

};


// Enum  /Script/AkAudio.AkChannelConfiguration
enum class AkChannelConfiguration : uint8_t
{
    Ak_Parent                                      = 0,
    Ak_LFE                                         = 1,
    Ak_1                                           = 2,
    Ak_2                                           = 3,
    Ak_2                                           = 4,
    Ak_3                                           = 5,
    Ak_3                                           = 6,
    Ak_4                                           = 7,
    Ak_4                                           = 8,
    Ak_5                                           = 9,
    Ak_5                                           = 10,
    Ak_7                                           = 11,
    Ak_5_1                                         = 12,
    Ak_7_1                                         = 13,
    Ak_7_1                                         = 14,
    Ak_Auro_9                                      = 15,
    Ak_Auro_10                                     = 16,
    Ak_Auro_11                                     = 17,
    Ak_Auro_13                                     = 18,
    Ak_Ambisonics_1st_order                        = 19,
    Ak_Ambisonics_2nd_order                        = 20,
    Ak_Ambisonics_3rd_order                        = 21,
    Ak_MAX                                         = 22

};


// Enum  /Script/AkAudio.AkAcousticPortalState
enum class AkAcousticPortalState : uint8_t
{
    Closed                                         = 0,
    Open                                           = 1,
    AkAcousticPortalState_MAX                      = 2

};


// Enum  /Script/AkAudio.PanningRule
enum class PanningRule : uint8_t
{
    PanningRule_Speakers                           = 0,
    PanningRule_Headphones                         = 1,
    PanningRule_MAX                                = 2

};


// Enum  /Script/AkAudio.AkMeshType
enum class AkMeshType : uint8_t
{
    StaticMesh                                     = 0,
    CollisionMesh                                  = 1,
    AkMeshType_MAX                                 = 2

};


// Enum  /Script/AkAudio.EAkCommSystem
enum class EAkCommSystem : uint8_t
{
    Socket                                         = 0,
    HTCS                                           = 1,
    EAkCommSystem_MAX                              = 2

};


// Enum  /Script/AkAudio.EAkChannelMask
enum class EAkChannelMask : uint8_t
{
    FrontLeft                                      = 0,
    FrontRight                                     = 1,
    FrontCenter                                    = 2,
    LowFrequency                                   = 3,
    BackLeft                                       = 4,
    BackRight                                      = 5,
    BackCenter                                     = 8,
    SideLeft                                       = 9,
    SideRight                                      = 10,
    Top                                            = 11,
    HeightFrontLeft                                = 12,
    HeightFrontCenter                              = 13,
    HeightFrontRight                               = 14,
    HeightBackLeft                                 = 15,
    HeightBackCenter                               = 16,
    HeightBackRight                                = 17,
    EAkChannelMask_MAX                             = 18

};


// Enum  /Script/AkAudio.EAkChannelConfigType
enum class EAkChannelConfigType : uint8_t
{
    Anonymous                                      = 0,
    Standard                                       = 1,
    Ambisonic                                      = 2,
    EAkChannelConfigType_MAX                       = 3

};


// Enum  /Script/AkAudio.TestEnumm
enum class TestEnumm : uint8_t
{
    test1                                          = 0,
    test2                                          = 1,
    TestEnumm_MAX                                  = 2

};


// Enum  /Script/AkAudio.EAkDiffractionFlags
enum class EAkDiffractionFlags : uint8_t
{
    UseBuiltInParam                                = 0,
    UseObstruction                                 = 1,
    CalcEmitterVirtualPosition                     = 3,
    EAkDiffractionFlags_MAX                        = 4

};


// Enum  /Script/AkAudio.EAkPanningRule
enum class EAkPanningRule : uint8_t
{
    Speakers                                       = 0,
    Headphones                                     = 1,
    EAkPanningRule_MAX                             = 2

};


// Enum  /Script/AkAudio.EAkOpenHarmonyAudioAPI
enum class EAkOpenHarmonyAudioAPI : uint8_t
{
    AAudio                                         = 0,
    OpenSL_ES                                      = 1,
    EAkOpenHarmonyAudioAPI_MAX                     = 2

};


// Enum  /Script/AkAudio.EAkWindowsAudioAPI
enum class EAkWindowsAudioAPI : uint8_t
{
    Wasapi                                         = 0,
    XAudio2                                        = 1,
    DirectSound                                    = 2,
    EAkWindowsAudioAPI_MAX                         = 3

};


// Enum  /Script/AkAudio.AudioBankOperation
enum class AudioBankOperation : uint8_t
{
    LoadBank                                       = 0,
    UnloadBank                                     = 1,
    AudioBankOperation_MAX                         = 2

};


// Enum  /Script/AkAudio.AudioObjectType
enum class AudioObjectType : uint8_t
{
    SFX                                            = 0,
    Music                                          = 1,
    Voice                                          = 2,
    Switch                                         = 3,
    State                                          = 4,
    RTPC                                           = 5,
    Trigger                                        = 6,
    SoundBank                                      = 7,
    AudioPackage                                   = 8,
    AuxBus                                         = 9,
    Room                                           = 10,
    MIDI                                           = 11,
    Emitter                                        = 12,
    Listener                                       = 13,
    Language                                       = 14,
    Device                                         = 15,
    Portal                                         = 16,
    Obs                                            = 17,
    Occ                                            = 18,
    AudioObjectType_MAX                            = 19

};


// Enum  /Script/AkAudio.AudioAction
enum class AudioAction : uint8_t
{
    PostEvent                                      = 0,
    Stop                                           = 1,
    Break                                          = 2,
    Pause                                          = 3,
    Resume                                         = 4,
    Mute                                           = 5,
    Unmute                                         = 6,
    Load                                           = 7,
    Unload                                         = 8,
    Reload                                         = 9,
    SetValue                                       = 10,
    GetValue                                       = 11,
    Activate                                       = 12,
    Deactivate                                     = 13,
    AudioRegister                                  = 14,
    AudioUnregister                                = 15,
    ObsOcc                                         = 16,
    AudioAction_MAX                                = 17

};


// Enum  /Script/AkAudio.AudioLogVerbosity
enum class AudioLogVerbosity : uint8_t
{
    Notification                                   = 0,
    Warning                                        = 1,
    Error                                          = 2,
    AudioLogVerbosity_MAX                          = 3

};


// Enum  /Script/AkAudio.EGeographicRTPCType
enum class EGeographicRTPCType : uint8_t
{
    Distance                                       = 0,
    Altitude                                       = 1,
    Longitude                                      = 2,
    Latitude                                       = 3,
    EGeographicRTPCType_MAX                        = 4

};


// Enum  /Script/MFGridLevelsRuntime.EMFLevelLoadType
enum class EMFLevelLoadType : uint8_t
{
    EMFLevelLoadType_NONE                          = 0,
    EMFLevelLoadType_CoverDistance                 = 1,
    EMFLevelLoadType_AdapterInDistance             = 2,
    EMFLevelLoadType_MAX                           = 3

};


// Enum  /Script/ProceduralMeshComponent.EProcMeshSliceCapOption
enum class EProcMeshSliceCapOption : uint8_t
{
    NoCap                                          = 0,
    CreateNewSectionForCap                         = 1,
    UseLastSectionForCap                           = 2,
    EProcMeshSliceCapOption_MAX                    = 3

};


// Enum  /Script/Engine.ETextGender
enum class ETextGender : uint8_t
{
    Masculine                                      = 0,
    Feminine                                       = 1,
    Neuter                                         = 2,
    ETextGender_MAX                                = 3

};


// Enum  /Script/Engine.EFormatArgumentType
enum class EFormatArgumentType : uint8_t
{
    Int                                            = 0,
    UInt                                           = 1,
    Float                                          = 2,
    Double                                         = 3,
    Text                                           = 4,
    Gender                                         = 5,
    EFormatArgumentType_MAX                        = 6

};


// Enum  /Script/InputCore.ETouchIndex
enum class ETouchIndex : uint8_t
{
    Touch1                                         = 0,
    Touch2                                         = 1,
    Touch3                                         = 2,
    Touch4                                         = 3,
    Touch5                                         = 4,
    Touch6                                         = 5,
    Touch7                                         = 6,
    Touch8                                         = 7,
    Touch9                                         = 8,
    Touch10                                        = 9,
    CursorPointerIndex                             = 10,
    MAX_TOUCHES                                    = 11,
    ETouchIndex_MAX                                = 12

};


// Enum  /Script/Engine.EEndPlayReason
enum class EEndPlayReason : uint8_t
{
    Destroyed                                      = 0,
    LevelTransition                                = 1,
    EndPlayInEditor                                = 2,
    RemovedFromWorld                               = 3,
    Quit                                           = 4,
    Reuse                                          = 5,
    EEndPlayReason_MAX                             = 6

};


// Enum  /Script/Engine.ETickingGroup
enum class ETickingGroup : uint8_t
{
    TG_PrePhysics                                  = 0,
    TG_StartPhysics                                = 1,
    TG_DuringPhysics                               = 2,
    TG_EndPhysics                                  = 3,
    TG_PostPhysics                                 = 4,
    TG_PostUpdateWork                              = 5,
    TG_LastDemotable                               = 6,
    TG_NewlySpawned                                = 7,
    TG_MAX                                         = 8

};


// Enum  /Script/Engine.EComponentCreationMethod
enum class EComponentCreationMethod : uint8_t
{
    Native                                         = 0,
    SimpleConstructionScript                       = 1,
    UserConstructionScript                         = 2,
    Instance                                       = 3,
    EComponentCreationMethod_MAX                   = 4

};


// Enum  /Script/Engine.ESkippableTickMode
enum class ESkippableTickMode : uint8_t
{
    FollowTickGroup                                = 0,
    Skippable                                      = 1,
    UnSkippable                                    = 2,
    ESkippableTickMode_MAX                         = 3

};


// Enum  /Script/Engine.ETemperatureSeverityType
enum class ETemperatureSeverityType : uint8_t
{
    Unknown                                        = 0,
    Good                                           = 1,
    Bad                                            = 2,
    Serious                                        = 3,
    Critical                                       = 4,
    NumSeverities                                  = 5,
    ETemperatureSeverityType_MAX                   = 6

};


// Enum  /Script/Engine.EQuartzCommandQuantization
enum class EQuartzCommandQuantization : uint8_t
{
    Bar                                            = 0,
    Beat                                           = 1,
    ThirtySecondNote                               = 2,
    SixteenthNote                                  = 3,
    EighthNote                                     = 4,
    QuarterNote                                    = 5,
    HalfNote                                       = 6,
    WholeNote                                      = 7,
    DottedSixteenthNote                            = 8,
    DottedEighthNote                               = 9,
    DottedQuarterNote                              = 10,
    DottedHalfNote                                 = 11,
    DottedWholeNote                                = 12,
    SixteenthNoteTriplet                           = 13,
    EighthNoteTriplet                              = 14,
    QuarterNoteTriplet                             = 15,
    HalfNoteTriplet                                = 16,
    Tick                                           = 17,
    Count                                          = 18,
    EQuartzCommandQuantization_MAX                 = 19

};


// Enum  /Script/Engine.EQuartzCommandDelegateSubType
enum class EQuartzCommandDelegateSubType : uint8_t
{
    CommandOnFailedToQueue                         = 0,
    CommandOnQueued                                = 1,
    CommandOnCanceled                              = 2,
    CommandOnAboutToStart                          = 3,
    CommandOnStarted                               = 4,
    Count                                          = 5,
    EQuartzCommandDelegateSubType_MAX              = 6

};


// Enum  /Script/Engine.EAudioComponentPlayState
enum class EAudioComponentPlayState : uint8_t
{
    Playing                                        = 0,
    Stopped                                        = 1,
    Paused                                         = 2,
    FadingIn                                       = 3,
    FadingOut                                      = 4,
    Count                                          = 5,
    EAudioComponentPlayState_MAX                   = 6

};


// Enum  /Script/Engine.EPlaneConstraintAxisSetting
enum class EPlaneConstraintAxisSetting : uint8_t
{
    Custom                                         = 0,
    X                                              = 1,
    Y                                              = 2,
    Z                                              = 3,
    UseGlobalPhysicsSetting                        = 4,
    EPlaneConstraintAxisSetting_MAX                = 5

};


// Enum  /Script/Engine.EInterpToBehaviourType
enum class EInterpToBehaviourType : uint8_t
{
    OneShot                                        = 0,
    OneShot_Reverse                                = 1,
    Loop_Reset                                     = 2,
    PingPong                                       = 3,
    EInterpToBehaviourType_MAX                     = 4

};


// Enum  /Script/Engine.ETeleportType
enum class ETeleportType : uint8_t
{
    None                                           = 0,
    TeleportPhysics                                = 1,
    ResetPhysics                                   = 2,
    ETeleportType_MAX                              = 3

};


// Enum  /Script/Engine.ERelativeTransformSpace
enum class ERelativeTransformSpace : uint8_t
{
    RTS_World                                      = 0,
    RTS_Actor                                      = 1,
    RTS_Component                                  = 2,
    RTS_ParentBoneSpace                            = 3,
    RTS_MAX                                        = 4

};


// Enum  /Script/Engine.EAttachLocation
enum class EAttachLocation : uint8_t
{
    KeepRelativeOffset                             = 0,
    KeepWorldPosition                              = 1,
    SnapToTarget                                   = 2,
    SnapToTargetIncludingScale                     = 3,
    EAttachLocation_MAX                            = 4

};


// Enum  /Script/Engine.EAttachmentRule
enum class EAttachmentRule : uint8_t
{
    KeepRelative                                   = 0,
    KeepWorld                                      = 1,
    SnapToTarget                                   = 2,
    EAttachmentRule_MAX                            = 3

};


// Enum  /Script/Engine.EDetachmentRule
enum class EDetachmentRule : uint8_t
{
    KeepRelative                                   = 0,
    KeepWorld                                      = 1,
    EDetachmentRule_MAX                            = 2

};


// Enum  /Script/Engine.EComponentMobility
enum class EComponentMobility : uint8_t
{
    Static                                         = 0,
    Stationary                                     = 1,
    Movable                                        = 2,
    EComponentMobility_MAX                         = 3

};


// Enum  /Script/Engine.EDetailMode
enum class EDetailMode : uint8_t
{
    DM_Low                                         = 0,
    DM_Medium                                      = 1,
    DM_High                                        = 2,
    DM_MAX                                         = 3

};


// Enum  /Script/Engine.EPlatformInterfaceDataType
enum class EPlatformInterfaceDataType : uint8_t
{
    PIDT_None                                      = 0,
    PIDT_Int                                       = 1,
    PIDT_Float                                     = 2,
    PIDT_String                                    = 3,
    PIDT_Object                                    = 4,
    PIDT_Custom                                    = 5,
    PIDT_MAX                                       = 6

};


// Enum  /Script/Engine.EMovementMode
enum class EMovementMode : uint8_t
{
    MOVE_None                                      = 0,
    MOVE_Walking                                   = 1,
    MOVE_NavWalking                                = 2,
    MOVE_Falling                                   = 3,
    MOVE_Swimming                                  = 4,
    MOVE_Flying                                    = 5,
    MOVE_Custom                                    = 6,
    MOVE_MAX                                       = 7

};


// Enum  /Script/Engine.ENetworkFailure
enum class ENetworkFailure : uint8_t
{
    NetDriverAlreadyExists                         = 0,
    NetDriverCreateFailure                         = 1,
    NetDriverListenFailure                         = 2,
    ConnectionLost                                 = 3,
    ConnectionTimeout                              = 4,
    FailureReceived                                = 5,
    OutdatedClient                                 = 6,
    OutdatedServer                                 = 7,
    PendingConnectionFailure                       = 8,
    NetGuidMismatch                                = 9,
    NetChecksumMismatch                            = 10,
    ENetworkFailure_MAX                            = 11

};


// Enum  /Script/Engine.ETravelFailure
enum class ETravelFailure : uint8_t
{
    NoLevel                                        = 0,
    LoadMapFailure                                 = 1,
    InvalidURL                                     = 2,
    PackageMissing                                 = 3,
    PackageVersion                                 = 4,
    NoDownload                                     = 5,
    TravelFailure                                  = 6,
    CheatCommands                                  = 7,
    PendingNetGameCreateFailure                    = 8,
    CloudSaveFailure                               = 9,
    ServerTravelFailure                            = 10,
    ClientTravelFailure                            = 11,
    ETravelFailure_MAX                             = 12

};


// Enum  /Script/Engine.EScreenOrientation
enum class EScreenOrientation : uint8_t
{
    Unknown                                        = 0,
    Portrait                                       = 1,
    PortraitUpsideDown                             = 2,
    LandscapeLeft                                  = 3,
    LandscapeRight                                 = 4,
    FaceUp                                         = 5,
    FaceDown                                       = 6,
    EScreenOrientation_MAX                         = 7

};


// Enum  /Script/Engine.EApplicationState
enum class EApplicationState : uint8_t
{
    Unknown                                        = 0,
    Inactive                                       = 1,
    Background                                     = 2,
    Active                                         = 3,
    EApplicationState_MAX                          = 4

};


// Enum  /Script/Engine.EObjectTypeQuery
enum class EObjectTypeQuery : uint8_t
{
    ObjectTypeQuery1                               = 0,
    ObjectTypeQuery2                               = 1,
    ObjectTypeQuery3                               = 2,
    ObjectTypeQuery4                               = 3,
    ObjectTypeQuery5                               = 4,
    ObjectTypeQuery6                               = 5,
    ObjectTypeQuery7                               = 6,
    ObjectTypeQuery8                               = 7,
    ObjectTypeQuery9                               = 8,
    ObjectTypeQuery10                              = 9,
    ObjectTypeQuery11                              = 10,
    ObjectTypeQuery12                              = 11,
    ObjectTypeQuery13                              = 12,
    ObjectTypeQuery14                              = 13,
    ObjectTypeQuery15                              = 14,
    ObjectTypeQuery16                              = 15,
    ObjectTypeQuery17                              = 16,
    ObjectTypeQuery18                              = 17,
    ObjectTypeQuery19                              = 18,
    ObjectTypeQuery20                              = 19,
    ObjectTypeQuery21                              = 20,
    ObjectTypeQuery22                              = 21,
    ObjectTypeQuery23                              = 22,
    ObjectTypeQuery24                              = 23,
    ObjectTypeQuery25                              = 24,
    ObjectTypeQuery26                              = 25,
    ObjectTypeQuery27                              = 26,
    ObjectTypeQuery28                              = 27,
    ObjectTypeQuery29                              = 28,
    ObjectTypeQuery30                              = 29,
    ObjectTypeQuery31                              = 30,
    ObjectTypeQuery32                              = 31,
    ObjectTypeQuery_MAX                            = 32,
    EObjectTypeQuery_MAX                           = 33

};


// Enum  /Script/Engine.EDrawDebugTrace
enum class EDrawDebugTrace : uint8_t
{
    None                                           = 0,
    ForOneFrame                                    = 1,
    ForDuration                                    = 2,
    Persistent                                     = 3,
    EDrawDebugTrace_MAX                            = 4

};


// Enum  /Script/Engine.ETraceTypeQuery
enum class ETraceTypeQuery : uint8_t
{
    TraceTypeQuery1                                = 0,
    TraceTypeQuery2                                = 1,
    TraceTypeQuery3                                = 2,
    TraceTypeQuery4                                = 3,
    TraceTypeQuery5                                = 4,
    TraceTypeQuery6                                = 5,
    TraceTypeQuery7                                = 6,
    TraceTypeQuery8                                = 7,
    TraceTypeQuery9                                = 8,
    TraceTypeQuery10                               = 9,
    TraceTypeQuery11                               = 10,
    TraceTypeQuery12                               = 11,
    TraceTypeQuery13                               = 12,
    TraceTypeQuery14                               = 13,
    TraceTypeQuery15                               = 14,
    TraceTypeQuery16                               = 15,
    TraceTypeQuery17                               = 16,
    TraceTypeQuery18                               = 17,
    TraceTypeQuery19                               = 18,
    TraceTypeQuery20                               = 19,
    TraceTypeQuery21                               = 20,
    TraceTypeQuery22                               = 21,
    TraceTypeQuery23                               = 22,
    TraceTypeQuery24                               = 23,
    TraceTypeQuery25                               = 24,
    TraceTypeQuery26                               = 25,
    TraceTypeQuery27                               = 26,
    TraceTypeQuery28                               = 27,
    TraceTypeQuery29                               = 28,
    TraceTypeQuery30                               = 29,
    TraceTypeQuery31                               = 30,
    TraceTypeQuery32                               = 31,
    TraceTypeQuery_MAX                             = 32,
    ETraceTypeQuery_MAX                            = 33

};


// Enum  /Script/Engine.EMoveComponentAction
enum class EMoveComponentAction : uint8_t
{
    Move                                           = 0,
    Stop                                           = 1,
    Return                                         = 2,
    EMoveComponentAction_MAX                       = 3

};


// Enum  /Script/Engine.EQuitPreference
enum class EQuitPreference : uint8_t
{
    Quit                                           = 0,
    Background                                     = 1,
    EQuitPreference_MAX                            = 2

};


// Enum  /Script/GameplayAbilities.EGameplayEffectGrantedAbilityRemovePolicy
enum class EGameplayEffectGrantedAbilityRemovePolicy : uint8_t
{
    CancelAbilityImmediately                       = 0,
    RemoveAbilityOnEnd                             = 1,
    DoNothing                                      = 2,
    EGameplayEffectGrantedAbilityRemovePolicy_MAX  = 3

};


// Enum  /Script/GameplayAbilities.EGameplayModsSelector
enum class EGameplayModsSelector : uint8_t
{
    Additive                                       = 0,
    Max                                            = 1,
    Min                                            = 2,
    Length                                         = 3

};


// Enum  /Script/GameplayAbilities.EGameplayEffectAttributeCaptureSource
enum class EGameplayEffectAttributeCaptureSource : uint8_t
{
    Source                                         = 0,
    Target                                         = 1,
    EGameplayEffectAttributeCaptureSource_MAX      = 2

};


// Enum  /Script/GameplayTasks.ETaskResourceOverlapPolicy
enum class ETaskResourceOverlapPolicy : uint8_t
{
    StartOnTop                                     = 0,
    StartAtEnd                                     = 1,
    ETaskResourceOverlapPolicy_MAX                 = 2

};


// Enum  /Script/GameplayTasks.EGameplayTaskRunResult
enum class EGameplayTaskRunResult : uint8_t
{
    Error                                          = 0,
    Failed                                         = 1,
    Success_Paused                                 = 2,
    Success_Active                                 = 3,
    Success_Finished                               = 4,
    EGameplayTaskRunResult_MAX                     = 5

};


// Enum  /Script/GameplayAbilities.EGameplayAbilityActivationMode
enum class EGameplayAbilityActivationMode : uint8_t
{
    Authority                                      = 0,
    NonAuthority                                   = 1,
    Predicting                                     = 2,
    Confirmed                                      = 3,
    Rejected                                       = 4,
    EGameplayAbilityActivationMode_MAX             = 5

};


// Enum  /Script/GameplayAbilities.EAbilityGenericReplicatedEvent
enum class EAbilityGenericReplicatedEvent : uint8_t
{
    GenericConfirm                                 = 0,
    GenericCancel                                  = 1,
    InputPressed                                   = 2,
    InputReleased                                  = 3,
    GenericSignalFromClient                        = 4,
    GenericSignalFromServer                        = 5,
    GameCustom1                                    = 6,
    GameCustom2                                    = 7,
    GameCustom3                                    = 8,
    GameCustom4                                    = 9,
    GameCustom5                                    = 10,
    GameCustom6                                    = 11,
    MAX                                            = 12

};


// Enum  /Script/Engine.EFastArraySerializerDeltaFlags
enum class EFastArraySerializerDeltaFlags : uint8_t
{
    None                                           = 0,
    HasBeenSerialized                              = 1,
    HasDeltaBeenRequested                          = 2,
    IsUsingDeltaSerialization                      = 4,
    EFastArraySerializerDeltaFlags_MAX             = 5

};


// Enum  /Script/GameplayAbilities.EGameplayEffectReplicationMode
enum class EGameplayEffectReplicationMode : uint8_t
{
    Minimal                                        = 0,
    Mixed                                          = 1,
    Full                                           = 2,
    EGameplayEffectReplicationMode_MAX             = 3

};


// Enum  /Script/GameplayAbilities.EAbilityTaskWaitState
enum class EAbilityTaskWaitState : uint8_t
{
    WaitingOnGame                                  = 1,
    WaitingOnUser                                  = 2,
    WaitingOnAvatar                                = 4,
    EAbilityTaskWaitState_MAX                      = 5

};


// Enum  /Script/GameplayAbilities.ERootMotionMoveToActorTargetOffsetType
enum class ERootMotionMoveToActorTargetOffsetType : uint8_t
{
    AlignFromTargetToSource                        = 0,
    AlignToTargetForward                           = 1,
    AlignToWorldSpace                              = 2,
    ERootMotionMoveToActorTargetOffsetType_MAX     = 3

};


// Enum  /Script/GameplayAbilities.EAbilityTaskNetSyncType
enum class EAbilityTaskNetSyncType : uint8_t
{
    BothWait                                       = 0,
    OnlyServerWait                                 = 1,
    OnlyClientWait                                 = 2,
    EAbilityTaskNetSyncType_MAX                    = 3

};


// Enum  /Script/GameplayAbilities.EWaitAttributeChangeComparison
enum class EWaitAttributeChangeComparison : uint8_t
{
    None                                           = 0,
    GreaterThan                                    = 1,
    LessThan                                       = 2,
    GreaterThanOrEqualTo                           = 3,
    LessThanOrEqualTo                              = 4,
    NotEqualTo                                     = 5,
    ExactlyEqualTo                                 = 6,
    MAX                                            = 7

};


// Enum  /Script/GameplayAbilities.EGameplayAbilityInputBinds
enum class EGameplayAbilityInputBinds : uint8_t
{
    Ability1                                       = 0,
    Ability2                                       = 1,
    Ability3                                       = 2,
    Ability4                                       = 3,
    Ability5                                       = 4,
    Ability6                                       = 5,
    Ability7                                       = 6,
    Ability8                                       = 7,
    Ability9                                       = 8,
    EGameplayAbilityInputBinds_MAX                 = 9

};


// Enum  /Script/GameplayAbilities.ETargetDataFilterSelf
enum class ETargetDataFilterSelf : uint8_t
{
    TDFS_Any                                       = 0,
    TDFS_NoSelf                                    = 1,
    TDFS_NoOthers                                  = 2,
    TDFS_MAX                                       = 3

};


// Enum  /Script/GameplayAbilities.EGameplayAbilityTargetingLocationType
enum class EGameplayAbilityTargetingLocationType : uint8_t
{
    LiteralTransform                               = 0,
    ActorTransform                                 = 1,
    SocketTransform                                = 2,
    EGameplayAbilityTargetingLocationType_MAX      = 3

};


// Enum  /Script/GameplayAbilities.EGameplayTargetingConfirmation
enum class EGameplayTargetingConfirmation : uint8_t
{
    Instant                                        = 0,
    UserConfirmed                                  = 1,
    Custom                                         = 2,
    CustomMulti                                    = 3,
    EGameplayTargetingConfirmation_MAX             = 4

};


// Enum  /Script/GameplayAbilities.ERepAnimPositionMethod
enum class ERepAnimPositionMethod : uint8_t
{
    Position                                       = 0,
    CurrentSectionId                               = 1,
    ERepAnimPositionMethod_MAX                     = 2

};


// Enum  /Script/GameplayAbilities.EGameplayAbilityTriggerSource
enum class EGameplayAbilityTriggerSource : uint8_t
{
    GameplayEvent                                  = 0,
    OwnedTagAdded                                  = 1,
    OwnedTagPresent                                = 2,
    EGameplayAbilityTriggerSource_MAX              = 3

};


// Enum  /Script/GameplayAbilities.EGameplayAbilityReplicationPolicy
enum class EGameplayAbilityReplicationPolicy : uint8_t
{
    ReplicateNo                                    = 0,
    ReplicateYes                                   = 1,
    EGameplayAbilityReplicationPolicy_MAX          = 2

};


// Enum  /Script/GameplayAbilities.EGameplayAbilityNetSecurityAdvancedPolicy
enum class EGameplayAbilityNetSecurityAdvancedPolicy : uint8_t
{
    None                                           = 0,
    DisallowClientCancelAbility                    = 1,
    DisallowClientEndAbility                       = 2,
    EGameplayAbilityNetSecurityAdvancedPolicy_MAX  = 3

};


// Enum  /Script/GameplayAbilities.EGameplayAbilityNetSecurityPolicy
enum class EGameplayAbilityNetSecurityPolicy : uint8_t
{
    ClientOrServer                                 = 0,
    ServerOnlyExecution                            = 1,
    ServerOnlyTermination                          = 2,
    ServerOnly                                     = 3,
    EGameplayAbilityNetSecurityPolicy_MAX          = 4

};


// Enum  /Script/GameplayAbilities.EGameplayAbilityNetExecutionPolicy
enum class EGameplayAbilityNetExecutionPolicy : uint8_t
{
    LocalPredicted                                 = 0,
    LocalOnly                                      = 1,
    ServerInitiated                                = 2,
    ServerOnly                                     = 3,
    Immediately                                    = 4,
    EGameplayAbilityNetExecutionPolicy_MAX         = 5

};


// Enum  /Script/GameplayAbilities.EGameplayAbilityInstancingPolicy
enum class EGameplayAbilityInstancingPolicy : uint8_t
{
    NonInstanced                                   = 0,
    InstancedPerActor                              = 1,
    InstancedPerExecution                          = 2,
    EGameplayAbilityInstancingPolicy_MAX           = 3

};


// Enum  /Script/GameplayAbilities.EGameplayCuePayloadType
enum class EGameplayCuePayloadType : uint8_t
{
    CueParameters                                  = 0,
    FromSpec                                       = 1,
    EGameplayCuePayloadType_MAX                    = 2

};


// Enum  /Script/GameplayAbilities.EGameplayEffectPeriodInhibitionRemovedPolicy
enum class EGameplayEffectPeriodInhibitionRemovedPolicy : uint8_t
{
    NeverReset                                     = 0,
    ResetPeriod                                    = 1,
    ExecuteAndResetPeriod                          = 2,
    EGameplayEffectPeriodInhibitionRemovedPolicy_MAX = 3

};


// Enum  /Script/GameplayAbilities.EGameplayEffectStackingExpirationPolicy
enum class EGameplayEffectStackingExpirationPolicy : uint8_t
{
    ClearEntireStack                               = 0,
    RemoveSingleStackAndRefreshDuration            = 1,
    RefreshDuration                                = 2,
    EGameplayEffectStackingExpirationPolicy_MAX    = 3

};


// Enum  /Script/GameplayAbilities.EGameplayEffectStackingPeriodPolicy
enum class EGameplayEffectStackingPeriodPolicy : uint8_t
{
    ResetOnSuccessfulApplication                   = 0,
    NeverReset                                     = 1,
    EGameplayEffectStackingPeriodPolicy_MAX        = 2

};


// Enum  /Script/GameplayAbilities.EGameplayEffectStackingDurationPolicy
enum class EGameplayEffectStackingDurationPolicy : uint8_t
{
    RefreshOnSuccessfulApplication                 = 0,
    NeverRefresh                                   = 1,
    EGameplayEffectStackingDurationPolicy_MAX      = 2

};


// Enum  /Script/GameplayAbilities.EGameplayEffectDurationType
enum class EGameplayEffectDurationType : uint8_t
{
    Instant                                        = 0,
    Infinite                                       = 1,
    HasDuration                                    = 2,
    EGameplayEffectDurationType_MAX                = 3

};


// Enum  /Script/GameplayAbilities.EGameplayEffectScopedModifierAggregatorType
enum class EGameplayEffectScopedModifierAggregatorType : uint8_t
{
    CapturedAttributeBacked                        = 0,
    Transient                                      = 1,
    EGameplayEffectScopedModifierAggregatorType_MAX = 2

};


// Enum  /Script/GameplayAbilities.EAttributeBasedFloatCalculationType
enum class EAttributeBasedFloatCalculationType : uint8_t
{
    AttributeMagnitude                             = 0,
    AttributeBaseValue                             = 1,
    AttributeBonusMagnitude                        = 2,
    AttributeMagnitudeEvaluatedUpToChannel         = 3,
    EAttributeBasedFloatCalculationType_MAX        = 4

};


// Enum  /Script/GameplayAbilities.EGameplayEffectMagnitudeCalculation
enum class EGameplayEffectMagnitudeCalculation : uint8_t
{
    ScalableFloat                                  = 0,
    AttributeBased                                 = 1,
    CustomCalculationClass                         = 2,
    SetByCaller                                    = 3,
    EGameplayEffectMagnitudeCalculation_MAX        = 4

};


// Enum  /Script/GameplayAbilities.EGameplayTagEventType
enum class EGameplayTagEventType : uint8_t
{
    NewOrRemoved                                   = 0,
    AnyCountChange                                 = 1,
    EGameplayTagEventType_MAX                      = 2

};


// Enum  /Script/GameplayAbilities.EGameplayCueEvent
enum class EGameplayCueEvent : uint8_t
{
    OnActive                                       = 0,
    WhileActive                                    = 1,
    Executed                                       = 2,
    Removed                                        = 3,
    EGameplayCueEvent_MAX                          = 4

};


// Enum  /Script/GameplayAbilities.EGameplayEffectStackingType
enum class EGameplayEffectStackingType : uint8_t
{
    None                                           = 0,
    AggregateBySource                              = 1,
    AggregateByTarget                              = 2,
    EGameplayEffectStackingType_MAX                = 3

};


// Enum  /Script/GameplayAbilities.EGameplayModOp
enum class EGameplayModOp : uint8_t
{
    Additive                                       = 0,
    Multiplicitive                                 = 1,
    Division                                       = 2,
    Override                                       = 3,
    Max                                            = 4

};


// Enum  /Script/GameplayAbilities.EGameplayModEvaluationChannel
enum class EGameplayModEvaluationChannel : uint8_t
{
    Channel0                                       = 0,
    Channel1                                       = 1,
    Channel2                                       = 2,
    Channel3                                       = 3,
    Channel4                                       = 4,
    Channel5                                       = 5,
    Channel6                                       = 6,
    Channel7                                       = 7,
    Channel8                                       = 8,
    Channel9                                       = 9,
    Channel_MAX                                    = 10,
    EGameplayModEvaluationChannel_MAX              = 11

};


// Enum  /Script/ControlRig.EControlRigComponentMapDirection
enum class EControlRigComponentMapDirection : uint8_t
{
    Input                                          = 0,
    Output                                         = 1,
    EControlRigComponentMapDirection_MAX           = 2

};


// Enum  /Script/ControlRig.EControlRigComponentSpace
enum class EControlRigComponentSpace : uint8_t
{
    WorldSpace                                     = 0,
    ActorSpace                                     = 1,
    ComponentSpace                                 = 2,
    RigSpace                                       = 3,
    LocalSpace                                     = 4,
    Max                                            = 5

};


// Enum  /Script/ControlRig.ERigExecutionType
enum class ERigExecutionType : uint8_t
{
    Runtime                                        = 0,
    Editing                                        = 1,
    Max                                            = 2

};


// Enum  /Script/ControlRig.EBoneGetterSetterMode
enum class EBoneGetterSetterMode : uint8_t
{
    LocalSpace                                     = 0,
    GlobalSpace                                    = 1,
    Max                                            = 2

};


// Enum  /Script/ControlRig.ETransformGetterType
enum class ETransformGetterType : uint8_t
{
    Initial                                        = 0,
    Current                                        = 1,
    Max                                            = 2

};


// Enum  /Script/ControlRig.EControlRigClampSpatialMode
enum class EControlRigClampSpatialMode : uint8_t
{
    Plane                                          = 0,
    Cylinder                                       = 1,
    Sphere                                         = 2,
    EControlRigClampSpatialMode_MAX                = 3

};


// Enum  /Script/ControlRig.ETransformSpaceMode
enum class ETransformSpaceMode : uint8_t
{
    LocalSpace                                     = 0,
    GlobalSpace                                    = 1,
    BaseSpace                                      = 2,
    BaseJoint                                      = 3,
    Max                                            = 4

};


// Enum  /Script/ControlRig.EControlRigDrawSettings
enum class EControlRigDrawSettings : uint8_t
{
    Points                                         = 0,
    Lines                                          = 1,
    LineStrip                                      = 2,
    DynamicMesh                                    = 3,
    EControlRigDrawSettings_MAX                    = 4

};


// Enum  /Script/ControlRig.EControlRigDrawHierarchyMode
enum class EControlRigDrawHierarchyMode : uint8_t
{
    Axes                                           = 0,
    Max                                            = 1

};


// Enum  /Script/ControlRig.EControlRigAnimEasingType
enum class EControlRigAnimEasingType : uint8_t
{
    Linear                                         = 0,
    QuadraticEaseIn                                = 1,
    QuadraticEaseOut                               = 2,
    QuadraticEaseInOut                             = 3,
    CubicEaseIn                                    = 4,
    CubicEaseOut                                   = 5,
    CubicEaseInOut                                 = 6,
    QuarticEaseIn                                  = 7,
    QuarticEaseOut                                 = 8,
    QuarticEaseInOut                               = 9,
    QuinticEaseIn                                  = 10,
    QuinticEaseOut                                 = 11,
    QuinticEaseInOut                               = 12,
    SineEaseIn                                     = 13,
    SineEaseOut                                    = 14,
    SineEaseInOut                                  = 15,
    CircularEaseIn                                 = 16,
    CircularEaseOut                                = 17,
    CircularEaseInOut                              = 18,
    ExponentialEaseIn                              = 19,
    ExponentialEaseOut                             = 20,
    ExponentialEaseInOut                           = 21,
    ElasticEaseIn                                  = 22,
    ElasticEaseOut                                 = 23,
    ElasticEaseInOut                               = 24,
    BackEaseIn                                     = 25,
    BackEaseOut                                    = 26,
    BackEaseInOut                                  = 27,
    BounceEaseIn                                   = 28,
    BounceEaseOut                                  = 29,
    BounceEaseInOut                                = 30,
    EControlRigAnimEasingType_MAX                  = 31

};


// Enum  /Script/ControlRig.EControlRigRotationOrder
enum class EControlRigRotationOrder : uint8_t
{
    XYZ                                            = 0,
    XZY                                            = 1,
    YXZ                                            = 2,
    YZX                                            = 3,
    ZXY                                            = 4,
    ZYX                                            = 5,
    EControlRigRotationOrder_MAX                   = 6

};


// Enum  /Script/ControlRig.ECRSimPointIntegrateType
enum class ECRSimPointIntegrateType : uint8_t
{
    Verlet                                         = 0,
    SemiExplicitEuler                              = 1,
    ECRSimPointIntegrateType_MAX                   = 2

};


// Enum  /Script/ControlRig.ECRSimConstraintType
enum class ECRSimConstraintType : uint8_t
{
    Distance                                       = 0,
    DistanceFromA                                  = 1,
    DistanceFromB                                  = 2,
    Plane                                          = 3,
    ECRSimConstraintType_MAX                       = 4

};


// Enum  /Script/ControlRig.ECRSimPointForceType
enum class ECRSimPointForceType : uint8_t
{
    Direction                                      = 0,
    ECRSimPointForceType_MAX                       = 1

};


// Enum  /Script/ControlRig.ECRSimSoftCollisionType
enum class ECRSimSoftCollisionType : uint8_t
{
    Plane                                          = 0,
    Sphere                                         = 1,
    Cone                                           = 2,
    ECRSimSoftCollisionType_MAX                    = 3

};


// Enum  /Script/ControlRig.EControlRigFKRigExecuteMode
enum class EControlRigFKRigExecuteMode : uint8_t
{
    Replace                                        = 0,
    Additive                                       = 1,
    Max                                            = 2

};


// Enum  /Script/ControlRig.ERigBoneType
enum class ERigBoneType : uint8_t
{
    Imported                                       = 0,
    User                                           = 1,
    ERigBoneType_MAX                               = 2

};


// Enum  /Script/ControlRig.ERigControlAxis
enum class ERigControlAxis : uint8_t
{
    X                                              = 0,
    Y                                              = 1,
    Z                                              = 2,
    ERigControlAxis_MAX                            = 3

};


// Enum  /Script/ControlRig.ERigControlValueType
enum class ERigControlValueType : uint8_t
{
    Initial                                        = 0,
    Current                                        = 1,
    Minimum                                        = 2,
    Maximum                                        = 3,
    ERigControlValueType_MAX                       = 4

};


// Enum  /Script/ControlRig.ERigControlType
enum class ERigControlType : uint8_t
{
    Bool                                           = 0,
    Float                                          = 1,
    Integer                                        = 2,
    Vector2D                                       = 3,
    Position                                       = 4,
    Scale                                          = 5,
    Rotator                                        = 6,
    Transform                                      = 7,
    TransformNoScale                               = 8,
    EulerTransform                                 = 9,
    ERigControlType_MAX                            = 10

};


// Enum  /Script/ControlRig.ERigHierarchyImportMode
enum class ERigHierarchyImportMode : uint8_t
{
    Append                                         = 0,
    Replace                                        = 1,
    ReplaceLocalTransform                          = 2,
    ReplaceGlobalTransform                         = 3,
    Max                                            = 4

};


// Enum  /Script/ControlRig.EControlRigSetKey
enum class EControlRigSetKey : uint8_t
{
    DoNotCare                                      = 0,
    Always                                         = 1,
    Never                                          = 2,
    EControlRigSetKey_MAX                          = 3

};


// Enum  /Script/ControlRig.ERigEvent
enum class ERigEvent : uint8_t
{
    None                                           = 0,
    RequestAutoKey                                 = 1,
    Max                                            = 2

};


// Enum  /Script/ControlRig.ERigElementType
enum class ERigElementType : uint8_t
{
    None                                           = 0,
    Bone                                           = 1,
    Space                                          = 2,
    Control                                        = 4,
    Curve                                          = 8,
    All                                            = 15,
    ERigElementType_MAX                            = 16

};


// Enum  /Script/ControlRig.ERigSpaceType
enum class ERigSpaceType : uint8_t
{
    Global                                         = 0,
    Bone                                           = 1,
    Control                                        = 2,
    Space                                          = 3,
    ERigSpaceType_MAX                              = 4

};


// Enum  /Script/ControlRig.EAimMode
enum class EAimMode : uint8_t
{
    AimAtTarget                                    = 0,
    OrientToTarget                                 = 1,
    MAX                                            = 2

};


// Enum  /Script/ControlRig.EApplyTransformMode
enum class EApplyTransformMode : uint8_t
{
    Override                                       = 0,
    Additive                                       = 1,
    Max                                            = 2

};


// Enum  /Script/ControlRig.ERigUnitDebugPointMode
enum class ERigUnitDebugPointMode : uint8_t
{
    Point                                          = 0,
    Vector                                         = 1,
    Max                                            = 2

};


// Enum  /Script/ControlRig.ERigUnitDebugTransformMode
enum class ERigUnitDebugTransformMode : uint8_t
{
    Point                                          = 0,
    Axes                                           = 1,
    Box                                            = 2,
    Max                                            = 3

};


// Enum  /Script/ControlRig.EControlRigCurveAlignment
enum class EControlRigCurveAlignment : uint8_t
{
    Front                                          = 0,
    Stretched                                      = 1,
    EControlRigCurveAlignment_MAX                  = 2

};


// Enum  /Script/ControlRig.EControlRigVectorKind
enum class EControlRigVectorKind : uint8_t
{
    Direction                                      = 0,
    Location                                       = 1,
    EControlRigVectorKind_MAX                      = 2

};


// Enum  /Script/ControlRig.ERBFVectorDistanceType
enum class ERBFVectorDistanceType : uint8_t
{
    Euclidean                                      = 0,
    Manhattan                                      = 1,
    ArcLength                                      = 2,
    ERBFVectorDistanceType_MAX                     = 3

};


// Enum  /Script/ControlRig.ERBFQuatDistanceType
enum class ERBFQuatDistanceType : uint8_t
{
    Euclidean                                      = 0,
    ArcLength                                      = 1,
    SwingAngle                                     = 2,
    TwistAngle                                     = 3,
    ERBFQuatDistanceType_MAX                       = 4

};


// Enum  /Script/ControlRig.ERBFKernelType
enum class ERBFKernelType : uint8_t
{
    Gaussian                                       = 0,
    Exponential                                    = 1,
    Linear                                         = 2,
    Cubic                                          = 3,
    Quintic                                        = 4,
    ERBFKernelType_MAX                             = 5

};


// Enum  /Script/ControlRig.EControlRigModifyBoneMode
enum class EControlRigModifyBoneMode : uint8_t
{
    OverrideLocal                                  = 0,
    OverrideGlobal                                 = 1,
    AdditiveLocal                                  = 2,
    AdditiveGlobal                                 = 3,
    Max                                            = 4

};


// Enum  /Script/ControlRig.ERigUnitVisualDebugPointMode
enum class ERigUnitVisualDebugPointMode : uint8_t
{
    Point                                          = 0,
    Vector                                         = 1,
    Max                                            = 2

};


// Enum  /Script/ControlRig.EControlRigState
enum class EControlRigState : uint8_t
{
    Init                                           = 0,
    Update                                         = 1,
    Invalid                                        = 2,
    EControlRigState_MAX                           = 3

};


// Enum  /Script/OBJPool.FOBJPoolSpawning
enum class FOBJPoolSpawning : uint8_t
{
    SpawnSuccessful                                = 0,
    SpawnFailed                                    = 1,
    FOBJPoolSpawning_MAX                           = 2

};


// Enum  /Script/OBJPool.EPoolCollisionType
enum class EPoolCollisionType : uint8_t
{
    NoCollision                                    = 0,
    QueryOnly                                      = 1,
    PhysicsOnly                                    = 2,
    QueryAndPhysics                                = 3,
    EPoolCollisionType_MAX                         = 4

};


// Enum  /Script/Niagara.ENiagaraSystemSpawnSectionEndBehavior
enum class ENiagaraSystemSpawnSectionEndBehavior : uint8_t
{
    SetSystemInactive                              = 0,
    Deactivate                                     = 1,
    None                                           = 2,
    ENiagaraSystemSpawnSectionEndBehavior_MAX      = 3

};


// Enum  /Script/Niagara.ENiagaraSystemSpawnSectionEvaluateBehavior
enum class ENiagaraSystemSpawnSectionEvaluateBehavior : uint8_t
{
    ActivateIfInactive                             = 0,
    None                                           = 1,
    ENiagaraSystemSpawnSectionEvaluateBehavior_MAX = 2

};


// Enum  /Script/Niagara.ENiagaraSystemSpawnSectionStartBehavior
enum class ENiagaraSystemSpawnSectionStartBehavior : uint8_t
{
    Activate                                       = 0,
    ENiagaraSystemSpawnSectionStartBehavior_MAX    = 1

};


// Enum  /Script/Niagara.ENiagaraCollisionMode
enum class ENiagaraCollisionMode : uint8_t
{
    None                                           = 0,
    SceneGeometry                                  = 1,
    DepthBuffer                                    = 2,
    DistanceField                                  = 3,
    ENiagaraCollisionMode_MAX                      = 4

};


// Enum  /Script/Niagara.ENiagaraLegacyTrailWidthMode
enum class ENiagaraLegacyTrailWidthMode : uint8_t
{
    FromCentre                                     = 0,
    FromFirst                                      = 1,
    FromSecond                                     = 2,
    ENiagaraLegacyTrailWidthMode_MAX               = 3

};


// Enum  /Script/Niagara.ENiagaraRendererSourceDataMode
enum class ENiagaraRendererSourceDataMode : uint8_t
{
    Particles                                      = 0,
    Emitter                                        = 1,
    ENiagaraRendererSourceDataMode_MAX             = 2

};


// Enum  /Script/Niagara.ENiagaraBindingSource
enum class ENiagaraBindingSource : uint8_t
{
    ImplicitFromSource                             = 0,
    ExplicitParticles                              = 1,
    ExplicitEmitter                                = 2,
    ExplicitSystem                                 = 3,
    ExplicitUser                                   = 4,
    MaxBindingSource                               = 5,
    ENiagaraBindingSource_MAX                      = 6

};


// Enum  /Script/Niagara.ENiagaraIterationSource
enum class ENiagaraIterationSource : uint8_t
{
    Particles                                      = 0,
    DataInterface                                  = 1,
    ENiagaraIterationSource_MAX                    = 2

};


// Enum  /Script/Niagara.ENiagaraScriptGroup
enum class ENiagaraScriptGroup : uint8_t
{
    Particle                                       = 0,
    Emitter                                        = 1,
    System                                         = 2,
    Max                                            = 3

};


// Enum  /Script/Niagara.ENiagaraScriptContextStaticSwitch
enum class ENiagaraScriptContextStaticSwitch : uint8_t
{
    System                                         = 0,
    Emitter                                        = 1,
    Particle                                       = 2,
    ENiagaraScriptContextStaticSwitch_MAX          = 3

};


// Enum  /Script/Niagara.ENiagaraCompileUsageStaticSwitch
enum class ENiagaraCompileUsageStaticSwitch : uint8_t
{
    Spawn                                          = 0,
    Update                                         = 1,
    Event                                          = 2,
    SimulationStage                                = 3,
    Default                                        = 4,
    ENiagaraCompileUsageStaticSwitch_MAX           = 5

};


// Enum  /Script/Niagara.ENiagaraScriptUsage
enum class ENiagaraScriptUsage : uint8_t
{
    Function                                       = 0,
    Module                                         = 1,
    DynamicInput                                   = 2,
    ParticleSpawnScript                            = 3,
    ParticleSpawnScriptInterpolated                = 4,
    ParticleUpdateScript                           = 5,
    ParticleEventScript                            = 6,
    ParticleSimulationStageScript                  = 7,
    ParticleGPUComputeScript                       = 8,
    EmitterSpawnScript                             = 9,
    EmitterUpdateScript                            = 10,
    SystemSpawnScript                              = 11,
    SystemUpdateScript                             = 12,
    ENiagaraScriptUsage_MAX                        = 13

};


// Enum  /Script/Niagara.ENiagaraScriptCompileStatus
enum class ENiagaraScriptCompileStatus : uint8_t
{
    NCS_Unknown                                    = 0,
    NCS_Dirty                                      = 1,
    NCS_Error                                      = 2,
    NCS_UpToDate                                   = 3,
    NCS_BeingCreated                               = 4,
    NCS_UpToDateWithWarnings                       = 5,
    NCS_ComputeUpToDateWithWarnings                = 6,
    NCS_MAX                                        = 7

};


// Enum  /Script/Niagara.ENiagaraInputNodeUsage
enum class ENiagaraInputNodeUsage : uint8_t
{
    Undefined                                      = 0,
    Parameter                                      = 1,
    Attribute                                      = 2,
    SystemConstant                                 = 3,
    TranslatorConstant                             = 4,
    RapidIterationParameter                        = 5,
    ENiagaraInputNodeUsage_MAX                     = 6

};


// Enum  /Script/Niagara.ENiagaraDataSetType
enum class ENiagaraDataSetType : uint8_t
{
    ParticleData                                   = 0,
    Shared                                         = 1,
    Event                                          = 2,
    ENiagaraDataSetType_MAX                        = 3

};


// Enum  /Script/Niagara.ENiagaraStatDisplayMode
enum class ENiagaraStatDisplayMode : uint8_t
{
    Percent                                        = 0,
    Absolute                                       = 1,
    ENiagaraStatDisplayMode_MAX                    = 2

};


// Enum  /Script/Niagara.ENiagaraStatEvaluationType
enum class ENiagaraStatEvaluationType : uint8_t
{
    Average                                        = 0,
    Maximum                                        = 1,
    ENiagaraStatEvaluationType_MAX                 = 2

};


// Enum  /Script/Niagara.ENiagaraAgeUpdateMode
enum class ENiagaraAgeUpdateMode : uint8_t
{
    TickDeltaTime                                  = 0,
    DesiredAge                                     = 1,
    DesiredAgeNoSeek                               = 2,
    ENiagaraAgeUpdateMode_MAX                      = 3

};


// Enum  /Script/Niagara.ENiagaraSimTarget
enum class ENiagaraSimTarget : uint8_t
{
    CPUSim                                         = 0,
    GPUComputeSim                                  = 1,
    ENiagaraSimTarget_MAX                          = 2

};


// Enum  /Script/Niagara.ENiagaraDefaultMode
enum class ENiagaraDefaultMode : uint8_t
{
    Value                                          = 0,
    Binding                                        = 1,
    Custom                                         = 2,
    ENiagaraDefaultMode_MAX                        = 3

};


// Enum  /Script/Niagara.ENiagaraGpuBufferFormat
enum class ENiagaraGpuBufferFormat : uint8_t
{
    Float                                          = 0,
    HalfFloat                                      = 1,
    UnsignedNormalizedByte                         = 2,
    Max                                            = 3

};


// Enum  /Script/Niagara.ENiagaraTickBehavior
enum class ENiagaraTickBehavior : uint8_t
{
    UsePrereqs                                     = 0,
    UseComponentTickGroup                          = 1,
    ForceTickFirst                                 = 2,
    ForceTickLast                                  = 3,
    ENiagaraTickBehavior_MAX                       = 4

};


// Enum  /Script/Niagara.ENCPoolMethod
enum class ENCPoolMethod : uint8_t
{
    None                                           = 0,
    AutoRelease                                    = 1,
    ManualRelease                                  = 2,
    ManualRelease_OnComplete                       = 3,
    FreeInPool                                     = 4,
    ENCPoolMethod_MAX                              = 5

};


// Enum  /Script/Niagara.ENDIExport_GPUAllocationMode
enum class ENDIExport_GPUAllocationMode : uint8_t
{
    FixedSize                                      = 0,
    PerParticle                                    = 1,
    ENDIExport_MAX                                 = 2

};


// Enum  /Script/Niagara.ESetResolutionMethod
enum class ESetResolutionMethod : uint8_t
{
    Independent                                    = 0,
    MaxAxis                                        = 1,
    CellSize                                       = 2,
    ESetResolutionMethod_MAX                       = 3

};


// Enum  /Script/Niagara.ENDISkeletalMesh_SkinningMode
enum class ENDISkeletalMesh_SkinningMode : uint8_t
{
    Invalid                                        = 255,
    None                                           = 0,
    SkinOnTheFly                                   = 1,
    PreSkin                                        = 2,
    ENDISkeletalMesh_MAX                           = 256

};


// Enum  /Script/Niagara.ENDISkeletalMesh_SourceMode
enum class ENDISkeletalMesh_SourceMode : uint8_t
{
    Default                                        = 0,
    Source                                         = 1,
    AttachParent                                   = 2,
    ENDISkeletalMesh_MAX                           = 3

};


// Enum  /Script/Niagara.ENDIStaticMesh_SourceMode
enum class ENDIStaticMesh_SourceMode : uint8_t
{
    Default                                        = 0,
    Source                                         = 1,
    AttachParent                                   = 2,
    DefaultMeshOnly                                = 3,
    ENDIStaticMesh_MAX                             = 4

};


// Enum  /Script/Niagara.ENiagaraScalabilityUpdateFrequency
enum class ENiagaraScalabilityUpdateFrequency : uint8_t
{
    SpawnOnly                                      = 0,
    Low                                            = 1,
    Medium                                         = 2,
    High                                           = 3,
    Continuous                                     = 4,
    ENiagaraScalabilityUpdateFrequency_MAX         = 5

};


// Enum  /Script/Niagara.ENiagaraCullReaction
enum class ENiagaraCullReaction : uint8_t
{
    Deactivate                                     = 0,
    DeactivateImmediate                            = 1,
    DeactivateResume                               = 2,
    DeactivateImmediateResume                      = 3,
    ENiagaraCullReaction_MAX                       = 4

};


// Enum  /Script/Niagara.EParticleAllocationMode
enum class EParticleAllocationMode : uint8_t
{
    AutomaticEstimate                              = 0,
    ManualEstimate                                 = 1,
    EParticleAllocationMode_MAX                    = 2

};


// Enum  /Script/Niagara.EScriptExecutionMode
enum class EScriptExecutionMode : uint8_t
{
    EveryParticle                                  = 0,
    SpawnedParticles                               = 1,
    SingleParticle                                 = 2,
    EScriptExecutionMode_MAX                       = 3

};


// Enum  /Script/Niagara.ENiagaraSortMode
enum class ENiagaraSortMode : uint8_t
{
    None                                           = 0,
    ViewDepth                                      = 1,
    ViewDistance                                   = 2,
    CustomAscending                                = 3,
    CustomDecending                                = 4,
    ENiagaraSortMode_MAX                           = 5

};


// Enum  /Script/Niagara.ENiagaraMeshLockedAxisSpace
enum class ENiagaraMeshLockedAxisSpace : uint8_t
{
    Simulation                                     = 0,
    World                                          = 1,
    Local                                          = 2,
    ENiagaraMeshLockedAxisSpace_MAX                = 3

};


// Enum  /Script/Niagara.ENiagaraMeshPivotOffsetSpace
enum class ENiagaraMeshPivotOffsetSpace : uint8_t
{
    Mesh                                           = 0,
    Simulation                                     = 1,
    World                                          = 2,
    Local                                          = 3,
    ENiagaraMeshPivotOffsetSpace_MAX               = 4

};


// Enum  /Script/Niagara.ENiagaraMeshFacingMode
enum class ENiagaraMeshFacingMode : uint8_t
{
    Default                                        = 0,
    Velocity                                       = 1,
    CameraPosition                                 = 2,
    CameraPlane                                    = 3,
    ENiagaraMeshFacingMode_MAX                     = 4

};


// Enum  /Script/Niagara.ENiagaraPlatformSetState
enum class ENiagaraPlatformSetState : uint8_t
{
    Disabled                                       = 0,
    Enabled                                        = 1,
    Active                                         = 2,
    Unknown                                        = 3,
    ENiagaraPlatformSetState_MAX                   = 4

};


// Enum  /Script/Niagara.ENiagaraPlatformSelectionState
enum class ENiagaraPlatformSelectionState : uint8_t
{
    Default                                        = 0,
    Enabled                                        = 1,
    Disabled                                       = 2,
    ENiagaraPlatformSelectionState_MAX             = 3

};


// Enum  /Script/Niagara.ENiagaraPreviewGridResetMode
enum class ENiagaraPreviewGridResetMode : uint8_t
{
    Never                                          = 0,
    Individual                                     = 1,
    All                                            = 2,
    ENiagaraPreviewGridResetMode_MAX               = 3

};


// Enum  /Script/Niagara.ENiagaraRibbonUVDistributionMode
enum class ENiagaraRibbonUVDistributionMode : uint8_t
{
    ScaledUniformly                                = 0,
    ScaledUsingRibbonSegmentLength                 = 1,
    TiledOverRibbonLength                          = 2,
    ENiagaraRibbonUVDistributionMode_MAX           = 3

};


// Enum  /Script/Niagara.ENiagaraRibbonUVEdgeMode
enum class ENiagaraRibbonUVEdgeMode : uint8_t
{
    SmoothTransition                               = 0,
    Locked                                         = 1,
    ENiagaraRibbonUVEdgeMode_MAX                   = 2

};


// Enum  /Script/Niagara.ENiagaraRibbonTessellationMode
enum class ENiagaraRibbonTessellationMode : uint8_t
{
    Automatic                                      = 0,
    Custom                                         = 1,
    Disabled                                       = 2,
    ENiagaraRibbonTessellationMode_MAX             = 3

};


// Enum  /Script/Niagara.ENiagaraRibbonDrawDirection
enum class ENiagaraRibbonDrawDirection : uint8_t
{
    FrontToBack                                    = 0,
    BackToFront                                    = 1,
    ENiagaraRibbonDrawDirection_MAX                = 2

};


// Enum  /Script/Niagara.ENiagaraRibbonAgeOffsetMode
enum class ENiagaraRibbonAgeOffsetMode : uint8_t
{
    Scale                                          = 0,
    Clip                                           = 1,
    ENiagaraRibbonAgeOffsetMode_MAX                = 2

};


// Enum  /Script/Niagara.ENiagaraRibbonFacingMode
enum class ENiagaraRibbonFacingMode : uint8_t
{
    Screen                                         = 0,
    Custom                                         = 1,
    CustomSideVector                               = 2,
    ENiagaraRibbonFacingMode_MAX                   = 3

};


// Enum  /Script/Niagara.ENiagaraScriptLibraryVisibility
enum class ENiagaraScriptLibraryVisibility : uint8_t
{
    Invalid                                        = 0,
    Unexposed                                      = 1,
    Library                                        = 2,
    Hidden                                         = 3,
    ENiagaraScriptLibraryVisibility_MAX            = 4

};


// Enum  /Script/Niagara.ENiagaraModuleDependencyScriptConstraint
enum class ENiagaraModuleDependencyScriptConstraint : uint8_t
{
    SameScript                                     = 0,
    AllScripts                                     = 1,
    ENiagaraModuleDependencyScriptConstraint_MAX   = 2

};


// Enum  /Script/Niagara.ENiagaraModuleDependencyType
enum class ENiagaraModuleDependencyType : uint8_t
{
    PreDependency                                  = 0,
    PostDependency                                 = 1,
    ENiagaraModuleDependencyType_MAX               = 2

};


// Enum  /Script/Niagara.EUnusedAttributeBehaviour
enum class EUnusedAttributeBehaviour : uint8_t
{
    Copy                                           = 0,
    Zero                                           = 1,
    None                                           = 2,
    MarkInvalid                                    = 3,
    PassThrough                                    = 4,
    EUnusedAttributeBehaviour_MAX                  = 5

};


// Enum  /Script/Niagara.ENiagaraSpriteFacingMode
enum class ENiagaraSpriteFacingMode : uint8_t
{
    FaceCamera                                     = 0,
    FaceCameraPlane                                = 1,
    CustomFacingVector                             = 2,
    FaceCameraPosition                             = 3,
    FaceCameraDistanceBlend                        = 4,
    ENiagaraSpriteFacingMode_MAX                   = 5

};


// Enum  /Script/Niagara.ENiagaraSpriteAlignment
enum class ENiagaraSpriteAlignment : uint8_t
{
    Unaligned                                      = 0,
    VelocityAligned                                = 1,
    CustomAlignment                                = 2,
    ENiagaraSpriteAlignment_MAX                    = 3

};


// Enum  /Script/Niagara.ENiagaraParameterPanelCategory
enum class ENiagaraParameterPanelCategory : uint8_t
{
    Input                                          = 0,
    Attributes                                     = 1,
    Output                                         = 2,
    Local                                          = 3,
    User                                           = 4,
    Engine                                         = 5,
    Owner                                          = 6,
    System                                         = 7,
    Emitter                                        = 8,
    Particles                                      = 9,
    ScriptTransient                                = 10,
    StaticSwitch                                   = 11,
    None                                           = 12,
    Num                                            = 13,
    ENiagaraParameterPanelCategory_MAX             = 14

};


// Enum  /Script/Niagara.ENiagaraScriptParameterUsage
enum class ENiagaraScriptParameterUsage : uint8_t
{
    Input                                          = 0,
    Output                                         = 1,
    Local                                          = 2,
    InputOutput                                    = 3,
    InitialValueInput                              = 4,
    None                                           = 5,
    Num                                            = 6,
    ENiagaraScriptParameterUsage_MAX               = 7

};


// Enum  /Script/Niagara.ENiagaraParameterScope
enum class ENiagaraParameterScope : uint8_t
{
    Input                                          = 0,
    User                                           = 1,
    Engine                                         = 2,
    Owner                                          = 3,
    System                                         = 4,
    Emitter                                        = 5,
    Particles                                      = 6,
    ScriptPersistent                               = 7,
    ScriptTransient                                = 8,
    Local                                          = 9,
    Custom                                         = 10,
    DISPLAY_ONLY_StaticSwitch                      = 11,
    Output                                         = 12,
    None                                           = 13,
    Num                                            = 14,
    ENiagaraParameterScope_MAX                     = 15

};


// Enum  /Script/Niagara.ENiagaraExecutionState
enum class ENiagaraExecutionState : uint8_t
{
    Active                                         = 0,
    Inactive                                       = 1,
    InactiveClear                                  = 2,
    Complete                                       = 3,
    Disabled                                       = 4,
    Num                                            = 5,
    ENiagaraExecutionState_MAX                     = 6

};


// Enum  /Script/Niagara.ENiagaraExecutionStateSource
enum class ENiagaraExecutionStateSource : uint8_t
{
    Scalability                                    = 0,
    Internal                                       = 1,
    Owner                                          = 2,
    InternalCompletion                             = 3,
    ENiagaraExecutionStateSource_MAX               = 4

};


// Enum  /Script/Niagara.ENiagaraNumericOutputTypeSelectionMode
enum class ENiagaraNumericOutputTypeSelectionMode : uint8_t
{
    None                                           = 0,
    Largest                                        = 1,
    Smallest                                       = 2,
    Scalar                                         = 3,
    ENiagaraNumericOutputTypeSelectionMode_MAX     = 4

};


// Enum  /Script/Niagara.ENiagaraVariantMode
enum class ENiagaraVariantMode : uint8_t
{
    None                                           = 0,
    Object                                         = 1,
    DataInterface                                  = 2,
    Bytes                                          = 3,
    ENiagaraVariantMode_MAX                        = 4

};


// Enum  /Script/NiagaraShader.FNiagaraCompileEventSeverity
enum class FNiagaraCompileEventSeverity : uint8_t
{
    Log                                            = 0,
    Warning                                        = 1,
    Error                                          = 2,
    FNiagaraCompileEventSeverity_MAX               = 3

};


// Enum  /Script/MFAnimationRuntime.ECalcStretchAlgorithm
enum class ECalcStretchAlgorithm : uint8_t
{
    ModifyBoneByAxisX                              = 0,
    ModifyBoneByTwoBoneDirection                   = 1,
    ECalcStretchAlgorithm_MAX                      = 2

};


// Enum  /Script/MFAnimationRuntime.EAdjustType
enum class EAdjustType : uint8_t
{
    Adjust_Scale                                   = 0,
    Adjust_Additive                                = 1,
    Adjust_MAX                                     = 2

};


// Enum  /Script/MFAnimationRuntime.EProfilingType
enum class EProfilingType : uint8_t
{
    Update                                         = 0,
    Evaluate                                       = 1,
    Max                                            = 2

};


// Enum  /Script/MFAnimationRuntime.EIKFootRootLocalAxis
enum class EIKFootRootLocalAxis : uint8_t
{
    NONE                                           = 0,
    X                                              = 1,
    Y                                              = 2,
    Z                                              = 3,
    EIKFootRootLocalAxis_MAX                       = 4

};


// Enum  /Script/ACLPlugin.ACLCompressionLevel
enum class ACLCompressionLevel : uint8_t
{
    ACLCL_Lowest                                   = 0,
    ACLCL_Low                                      = 1,
    ACLCL_Medium                                   = 2,
    ACLCL_High                                     = 3,
    ACLCL_Highest                                  = 4,
    ACLCL_MAX                                      = 5

};


// Enum  /Script/ACLPlugin.ACLVectorFormat
enum class ACLVectorFormat : uint8_t
{
    ACLVF_Vector3                                  = 0,
    ACLVF_Vector3_Variable                         = 1,
    ACLVF_Vector3_MAX                              = 2

};


// Enum  /Script/ACLPlugin.ACLRotationFormat
enum class ACLRotationFormat : uint8_t
{
    ACLRF_Quat                                     = 0,
    ACLRF_QuatDropW                                = 1,
    ACLRF_QuatDropW_Variable                       = 2,
    ACLRF_MAX                                      = 3

};


// Enum  /Script/ACLPlugin.ACLVisualFidelityChangeResult
enum class ACLVisualFidelityChangeResult : uint8_t
{
    Dispatched                                     = 0,
    Completed                                      = 1,
    Failed                                         = 2,
    ACLVisualFidelityChangeResult_MAX              = 3

};


// Enum  /Script/ACLPlugin.ACLVisualFidelity
enum class ACLVisualFidelity : uint8_t
{
    Highest                                        = 0,
    Medium                                         = 1,
    Lowest                                         = 2,
    ACLVisualFidelity_MAX                          = 3

};


// Enum  /Script/HairStrandsCore.EHairCardsSourceType
enum class EHairCardsSourceType : uint8_t
{
    Procedural                                     = 0,
    Imported                                       = 1,
    EHairCardsSourceType_MAX                       = 2

};


// Enum  /Script/HairStrandsCore.EHairCardsGenerationType
enum class EHairCardsGenerationType : uint8_t
{
    CardsCount                                     = 0,
    UseGuides                                      = 1,
    EHairCardsGenerationType_MAX                   = 2

};


// Enum  /Script/HairStrandsCore.EHairCardsClusterType
enum class EHairCardsClusterType : uint8_t
{
    Low                                            = 0,
    High                                           = 1,
    EHairCardsClusterType_MAX                      = 2

};


// Enum  /Script/HairStrandsCore.EGroomGeometryType
enum class EGroomGeometryType : uint8_t
{
    Strands                                        = 0,
    Cards                                          = 1,
    Meshes                                         = 2,
    EGroomGeometryType_MAX                         = 3

};


// Enum  /Script/HairStrandsCore.EHairLODSelectionType
enum class EHairLODSelectionType : uint8_t
{
    Cpu                                            = 0,
    Gpu                                            = 1,
    EHairLODSelectionType_MAX                      = 2

};


// Enum  /Script/HairStrandsCore.EHairInterpolationWeight
enum class EHairInterpolationWeight : uint8_t
{
    Parametric                                     = 0,
    Root                                           = 1,
    Index                                          = 2,
    Unknown                                        = 3,
    EHairInterpolationWeight_MAX                   = 4

};


// Enum  /Script/HairStrandsCore.EHairInterpolationQuality
enum class EHairInterpolationQuality : uint8_t
{
    Low                                            = 0,
    Medium                                         = 1,
    High                                           = 2,
    Unknown                                        = 3,
    EHairInterpolationQuality_MAX                  = 4

};


// Enum  /Script/HairStrandsCore.EGroomInterpolationType
enum class EGroomInterpolationType : uint8_t
{
    None                                           = 0,
    RigidTransform                                 = 2,
    OffsetTransform                                = 4,
    SmoothTransform                                = 8,
    EGroomInterpolationType_MAX                    = 9

};


// Enum  /Script/HairStrandsCore.EGroomStrandsSize
enum class EGroomStrandsSize : uint8_t
{
    None                                           = 0,
    Size2                                          = 2,
    Size4                                          = 4,
    Size8                                          = 8,
    Size16                                         = 16,
    Size32                                         = 32,
    EGroomStrandsSize_MAX                          = 33

};


// Enum  /Script/HairStrandsCore.EGroomNiagaraSolvers
enum class EGroomNiagaraSolvers : uint8_t
{
    None                                           = 0,
    CosseratRods                                   = 2,
    AngularSprings                                 = 4,
    CustomSolver                                   = 8,
    EGroomNiagaraSolvers_MAX                       = 9

};


// Enum  /Script/HairStrandsCore.EFollicleMaskChannel
enum class EFollicleMaskChannel : uint8_t
{
    R                                              = 0,
    G                                              = 1,
    B                                              = 2,
    A                                              = 3,
    EFollicleMaskChannel_MAX                       = 4

};


// Enum  /Script/HairStrandsCore.EStrandsTexturesMeshType
enum class EStrandsTexturesMeshType : uint8_t
{
    Static                                         = 0,
    Skeletal                                       = 1,
    EStrandsTexturesMeshType_MAX                   = 2

};


// Enum  /Script/HairStrandsCore.EStrandsTexturesTraceType
enum class EStrandsTexturesTraceType : uint8_t
{
    TraceInside                                    = 0,
    TraceOuside                                    = 1,
    TraceBidirectional                             = 2,
    EStrandsTexturesTraceType_MAX                  = 3

};


// Enum  /Script/HairStrandsCore.EGroomInterpolationWeight
enum class EGroomInterpolationWeight : uint8_t
{
    Parametric                                     = 0,
    Root                                           = 1,
    Index                                          = 2,
    Unknown                                        = 3,
    EGroomInterpolationWeight_MAX                  = 4

};


// Enum  /Script/HairStrandsCore.EGroomInterpolationQuality
enum class EGroomInterpolationQuality : uint8_t
{
    Low                                            = 0,
    Medium                                         = 1,
    High                                           = 2,
    Unknown                                        = 3,
    EGroomInterpolationQuality_MAX                 = 4

};


// Enum  /Script/MotionWarping.EWarpPointAnimProvider
enum class EWarpPointAnimProvider : uint8_t
{
    None                                           = 0,
    Static                                         = 1,
    Bone                                           = 2,
    EWarpPointAnimProvider_MAX                     = 3

};


// Enum  /Script/MotionWarping.EMotionWarpRotationType
enum class EMotionWarpRotationType : uint8_t
{
    Default                                        = 0,
    Facing                                         = 1,
    EMotionWarpRotationType_MAX                    = 2

};


// Enum  /Script/MotionWarping.ERootMotionModifierState
enum class ERootMotionModifierState : uint8_t
{
    Waiting                                        = 0,
    Active                                         = 1,
    MarkedForRemoval                               = 2,
    Disabled                                       = 3,
    ERootMotionModifierState_MAX                   = 4

};


// Enum  /Script/AnimationWarpingRuntime.EStrideWarpingAxisMode
enum class EStrideWarpingAxisMode : uint8_t
{
    IKFootRootLocalX                               = 0,
    IKFootRootLocalY                               = 1,
    IKFootRootLocalZ                               = 2,
    WorldSpaceVectorInput                          = 3,
    ComponentSpaceVectorInput                      = 4,
    ActorSpaceVectorInput                          = 5,
    EStrideWarpingAxisMode_MAX                     = 6

};


// Enum  /Script/MFGlobalEvent.EMFGlobalEventTriggerType
enum class EMFGlobalEventTriggerType : uint8_t
{
    Owner                                          = 0,
    Global                                         = 1,
    EMFGlobalEventTriggerType_MAX                  = 2

};


// Enum  /Script/MFMission.EMissionStatus
enum class EMissionStatus : uint8_t
{
    Inactive                                       = 0,
    InProcess                                      = 1,
    Success                                        = 2,
    Failed                                         = 3,
    EMissionStatus_MAX                             = 4

};


// Enum  /Script/MFMission.EMissionFailedType
enum class EMissionFailedType : uint8_t
{
    Normal                                         = 0,
    TimeOut                                        = 1,
    EMissionFailedType_MAX                         = 2

};


// Enum  /Script/MFMission.EMissionFlowNodeStatus
enum class EMissionFlowNodeStatus : uint8_t
{
    Inactive                                       = 0,
    Active                                         = 1,
    EMissionFlowNodeStatus_MAX                     = 2

};


// Enum  /Script/MFMission.EMissionTimeLimitType
enum class EMissionTimeLimitType : uint8_t
{
    None                                           = 0,
    EnterGame                                      = 1,
    TimeRecord                                     = 2,
    EMissionTimeLimitType_MAX                      = 3

};


// Enum  /Script/MFMission.EMissionFlowConnectionType
enum class EMissionFlowConnectionType : uint8_t
{
    ProgressChanged                                = 0,
    StatusSucceed                                  = 1,
    StatusFailed                                   = 2,
    EMissionFlowConnectionType_MAX                 = 3

};


// Enum  /Script/MFMission.EMFMissionFlowTextKeyOperation
enum class EMFMissionFlowTextKeyOperation : uint8_t
{
    Equal                                          = 0,
    NotEqual                                       = 1,
    Contain                                        = 2,
    NotContain                                     = 3,
    EMFMissionFlowTextKeyOperation_MAX             = 4

};


// Enum  /Script/MFMission.EMFMissionFlowArithmeticKeyOperation
enum class EMFMissionFlowArithmeticKeyOperation : uint8_t
{
    Equal                                          = 0,
    NotEqual                                       = 1,
    Less                                           = 2,
    LessOrEqual                                    = 3,
    Greater                                        = 4,
    GreaterOrEqual                                 = 5,
    EMFMissionFlowArithmeticKeyOperation_MAX       = 6

};


// Enum  /Script/MFMission.EMFMissionFlowBasicKeyOperation
enum class EMFMissionFlowBasicKeyOperation : uint8_t
{
    Set                                            = 0,
    NotSet                                         = 1,
    EMFMissionFlowBasicKeyOperation_MAX            = 2

};


// Enum  /Script/MFMission.EMissionFlowCompleteType
enum class EMissionFlowCompleteType : uint8_t
{
    OneBattle                                      = 0,
    MultipleBattle                                 = 1,
    EMissionFlowCompleteType_MAX                   = 2

};


// Enum  /Script/MFMission.EMissionFlowType
enum class EMissionFlowType : uint8_t
{
    Normal                                         = 0,
    Activity                                       = 1,
    EMissionFlowType_MAX                           = 2

};


// Enum  /Script/MFMission.EMissionFlowNodeType
enum class EMissionFlowNodeType : uint8_t
{
    BaseNode                                       = 0,
    CheckNode                                      = 1,
    RelationNode                                   = 2,
    AssembleNode                                   = 3,
    AffiliateNode                                  = 4,
    BehaviorNode                                   = 5,
    EMissionFlowNodeType_MAX                       = 6

};


// Enum  /Script/MFMission.EMissionObjectiveConditionCheckType
enum class EMissionObjectiveConditionCheckType : uint8_t
{
    And                                            = 0,
    Or                                             = 1,
    EMissionObjectiveConditionCheckType_MAX        = 2

};


// Enum  /Script/MFMission.EMissionRelatedTeamType
enum class EMissionRelatedTeamType : uint8_t
{
    TargetTeammateOnly                             = 0,
    RandomTeam                                     = 1,
    EMissionRelatedTeamType_MAX                    = 2

};


// Enum  /Script/MFMission.EMissionRelatedTargetType
enum class EMissionRelatedTargetType : uint8_t
{
    TargetOnly                                     = 0,
    TargetTeammateOnly                             = 1,
    RandomTeam                                     = 2,
    AllPMC                                         = 3,
    AllSCAV                                        = 4,
    SameFactionOtherTeam                           = 5,
    AllOtherTeam                                   = 6,
    TargetExcludeTeammateOnly                      = 7,
    EMissionRelatedTargetType_MAX                  = 8

};


// Enum  /Script/MFMission.EMissionCompareType
enum class EMissionCompareType : uint8_t
{
    CMP_None                                       = 0,
    CMP_Equals                                     = 1,
    CMP_NotEqual                                   = 2,
    CMP_Greater                                    = 3,
    CMP_Less                                       = 4,
    CMP_GreaterEqual                               = 5,
    CMP_LessEqual                                  = 6,
    CMP_Between                                    = 7,
    CMP_MAX                                        = 8

};


// Enum  /Script/MFMission.EMissionInstigatorType
enum class EMissionInstigatorType : uint8_t
{
    None                                           = 0,
    Individual                                     = 1,
    Team                                           = 2,
    Public                                         = 3,
    EMissionInstigatorType_MAX                     = 4

};


// Enum  /Script/MFMission.EMissionConditionCheckType
enum class EMissionConditionCheckType : uint8_t
{
    Event                                          = 0,
    Tick                                           = 1,
    Both                                           = 2,
    EMissionConditionCheckType_MAX                 = 3

};


// Enum  /Script/MFMission.EMissionConditionType
enum class EMissionConditionType : uint8_t
{
    Keeping                                        = 0,
    Filter                                         = 1,
    EMissionConditionType_MAX                      = 2

};


// Enum  /Script/MFMission.EMissionHelpType
enum class EMissionHelpType : uint8_t
{
    Alone                                          = 0,
    Teammate                                       = 1,
    Anyone                                         = 2,
    EMissionHelpType_MAX                           = 3

};


// Enum  /Script/MFMission.EMissionDataType
enum class EMissionDataType : uint8_t
{
    None                                           = 0,
    Person                                         = 1,
    Team                                           = 2,
    Faction                                        = 4,
    World                                          = 8,
    EMissionDataType_MAX                           = 9

};


// Enum  /Script/MFMission.ERunMissionResult
enum class ERunMissionResult : uint8_t
{
    Success                                        = 0,
    Failed                                         = 1,
    ERunMissionResult_MAX                          = 2

};


// Enum  /Script/MFMission.EMFMissionDataChangeType
enum class EMFMissionDataChangeType : uint8_t
{
    MissionFlowStatus                              = 0,
    MissionStatus                                  = 1,
    CurProgress                                    = 2,
    RemainTime                                     = 3,
    AttributeReplicate                             = 4,
    EMFMissionDataChangeType_MAX                   = 5

};


// Enum  /Script/MFNPCAI.EMFGraphAStarResult
enum class EMFGraphAStarResult : uint8_t
{
    WaitToSearch                                   = 0,
    SearchFail                                     = 1,
    SearchInProgress                               = 2,
    SearchAborted                                  = 3,
    SearchDone                                     = 4,
    SearchSuccess                                  = 5,
    GoalUnreachable                                = 6,
    InfiniteLoop                                   = 7,
    NotFound                                       = 8,
    RequestNotFound                                = 9,
    EMFGraphAStarResult_MAX                        = 10

};


// Enum  /Script/MFNPCAI.ENPCAIGoDirectlyResult
enum class ENPCAIGoDirectlyResult : uint8_t
{
    Success                                        = 0,
    ReachBoundary                                  = 1,
    AIPawnNotFound                                 = 2,
    ENPCAIGoDirectlyResult_MAX                     = 3

};


// Enum  /Script/MFNPCAI.ENPCAICellGridValue
enum class ENPCAICellGridValue : uint8_t
{
    None                                           = 0,
    NoNavMesh                                      = 1,
    Vehicle                                        = 2,
    BreakableObj                                   = 4,
    Paradrop                                       = 8,
    ENPCAICellGridValue_MAX                        = 9

};


// Enum  /Script/MFNPCAI.EAISpawnSceneEvtType
enum class EAISpawnSceneEvtType : uint8_t
{
    None                                           = 0,
    TriggerEvent                                   = 1,
    SpawnVector                                    = 2,
    AutoFillVectorAI                               = 3,
    EAISpawnSceneEvtType_MAX                       = 4

};


// Enum  /Script/MFNPCAI.EAISceneEventState
enum class EAISceneEventState : uint8_t
{
    Trigger                                        = 0,
    Completed                                      = 1,
    Expired                                        = 2,
    Removed                                        = 3,
    EAISceneEventState_MAX                         = 4

};


// Enum  /Script/MFNPCAI.EAIAimingType
enum class EAIAimingType : uint8_t
{
    Normal                                         = 0,
    Regular                                        = 1,
    EAIAimingType_MAX                              = 2

};


// Enum  /Script/MFNPCAI.EAIAimStatus
enum class EAIAimStatus : uint8_t
{
    Aiming                                         = 0,
    NoTarget                                       = 1,
    AimComplete                                    = 2,
    EAIAimStatus_MAX                               = 3

};


// Enum  /Script/MFNPCAI.ENPCAIAsyncTaskType
enum class ENPCAIAsyncTaskType : uint8_t
{
    None                                           = 0,
    FindAmbushAgainstPoint                         = 1,
    PeekPoint                                      = 2,
    FindPathByKeyRoute                             = 3,
    QueryRoundEnvironment                          = 4,
    ENPCAIAsyncTaskType_MAX                        = 5

};


// Enum  /Script/MFNPCAI.ENPCPlaceForCheckType
enum class ENPCPlaceForCheckType : uint8_t
{
    Simple                                         = 0,
    Danger                                         = 1,
    Suspicious                                     = 2,
    Fatal                                          = 3,
    GrenadeHit_Near                                = 4,
    GrenadeHit_Far                                 = 5,
    GrenadeComeing                                 = 6,
    FarFootStep                                    = 7,
    CloseFootStep                                  = 8,
    FarGunFire                                     = 9,
    CloseGunFire                                   = 10,
    GrenadeHolding                                 = 11,
    Fuzzy                                          = 12,
    CloseVehicleNoise                              = 13,
    FarVehicleNoise                                = 14,
    VehicleRushMe                                  = 15,
    CloseVehicleHorn                               = 16,
    FarVehicleHorn                                 = 17,
    Drone                                          = 18,
    ENPCPlaceForCheckType_MAX                      = 19

};


// Enum  /Script/MFNPCAI.EAIProfileEditState
enum class EAIProfileEditState : uint8_t
{
    None                                           = 0,
    ChoosingProperty                               = 1,
    EditingProperty                                = 2,
    Comparing                                      = 3,
    EAIProfileEditState_MAX                        = 4

};


// Enum  /Script/MFNPCAI.EAIProfileCoverType
enum class EAIProfileCoverType : uint8_t
{
    CoverType_None                                 = 0,
    CoverType_int32                                = 1,
    CoverType_int64                                = 2,
    CoverType_float                                = 3,
    CoverType_bool                                 = 4,
    CoverType_Byte                                 = 5,
    CoverType_Enum                                 = 6,
    CoverType_Set                                  = 7,
    CoverType_Array                                = 8,
    CoverType_Map                                  = 9,
    CoverType_Vector                               = 10,
    CoverType_AIMindGoalEnemyAngleMultiple         = 11,
    CoverType_AIBodyBulkAimingChoice               = 12,
    CoverType_AISenseSightNormal                   = 13,
    CoverType_String                               = 14,
    CoverType_Object                               = 15,
    CoverType_SoftClassPtr                         = 16,
    CoverType_MAX                                  = 17

};


// Enum  /Script/MFNPCAI.ENPCAIMovementKind
enum class ENPCAIMovementKind : uint8_t
{
    GotoPoint                                      = 0,
    GoDirectly                                     = 1,
    GoAccordingToWayPoints                         = 2,
    ENPCAIMovementKind_MAX                         = 3

};


// Enum  /Script/MFNPCAI.ENPCAIMoveResult
enum class ENPCAIMoveResult : uint8_t
{
    None                                           = 0,
    WaitPerform                                    = 1,
    Succeeded                                      = 2,
    Failed                                         = 3,
    Aborted                                        = 4,
    InProgress                                     = 5,
    ENPCAIMoveResult_MAX                           = 6

};


// Enum  /Script/MFNPCAI.EGetLinkUsageCountStatus
enum class EGetLinkUsageCountStatus : uint8_t
{
    Success                                        = 0,
    GetNavMeshManagerFailed                        = 1,
    GetSourceRegionIndexFailed                     = 2,
    GetTargetRegionIndexFailed                     = 3,
    RegionIndexNotValidNodeIndex                   = 4,
    RegionIndexNotValidAdjacencyIndex              = 5,
    Unreachable                                    = 6,
    EGetLinkUsageCountStatus_MAX                   = 7

};


// Enum  /Script/MFNPCAI.ENavSkeletonPointGetterFlag
enum class ENavSkeletonPointGetterFlag : uint8_t
{
    None                                           = 0,
    LinkId                                         = 1,
    NeighbourIndices                               = 2,
    VisibleIndices                                 = 3,
    All                                            = 255,
    ENavSkeletonPointGetterFlag_MAX                = 256

};


// Enum  /Script/MFNPCAI.ENavSkeletonDivergenceMethod
enum class ENavSkeletonDivergenceMethod : uint8_t
{
    Laplacian                                      = 0,
    GradientFlux                                   = 1,
    Neighbour                                      = 2,
    ENavSkeletonDivergenceMethod_MAX               = 3

};


// Enum  /Script/MFNPCAI.ENavSkeletonSamplePointKind
enum class ENavSkeletonSamplePointKind : uint8_t
{
    None                                           = 0,
    Isolate                                        = 1,
    Endpoint                                       = 2,
    Normal                                         = 3,
    KeptNormal                                     = 4,
    DoorLink                                       = 5,
    Junction                                       = 6,
    ENavSkeletonSamplePointKind_MAX                = 7

};


// Enum  /Script/MFNPCAI.ENavSkeletonSamplePointDropReason
enum class ENavSkeletonSamplePointDropReason : uint8_t
{
    None                                           = 0,
    CannotBeSkeletonPoint                          = 1,
    FindDistanceToWallFailed                       = 2,
    TooCloseToWall                                 = 3,
    InvalidWallHitNormal                           = 4,
    MismatchedNeighbours                           = 5,
    InvalidGradientSize                            = 6,
    InvalidDivergence                              = 7,
    TooLessWallCount                               = 8,
    Isolated                                       = 9,
    NotMainPoint                                   = 10,
    CloseToAnotherMainPoint                        = 11,
    CannotFindProperPointToConnect                 = 12,
    InvalidPointKind                               = 13,
    BeSimplified                                   = 14,
    InPrunedEndBranch                              = 15,
    Count                                          = 16,
    ENavSkeletonSamplePointDropReason_MAX          = 17

};


// Enum  /Script/MFNPCAI.EPathExistenceTestMode
enum class EPathExistenceTestMode : uint8_t
{
    Regular                                        = 0,
    Hierarchical                                   = 1,
    EPathExistenceTestMode_MAX                     = 2

};


// Enum  /Script/MFNPCAI.ENavAreaKind
enum class ENavAreaKind : uint8_t
{
    Burning                                        = 0,
    TearGas                                        = 1,
    TripMine                                       = 2,
    Claymore                                       = 3,
    Paradrop                                       = 4,
    ENavAreaKind_MAX                               = 5

};


// Enum  /Script/MFNPCAI.ENavMeshTileLabel
enum class ENavMeshTileLabel : uint8_t
{
    AllPolysReachable                              = 0,
    PartialPolysReachable                          = 1,
    InvalidBeginIndex                              = 2,
    ConsiderUnreachablePolys                       = 252,
    AllPolysUnreachable                            = 253,
    InvalidHeader                                  = 254,
    Unknown                                        = 255,
    ENavMeshTileLabel_MAX                          = 256

};


// Enum  /Script/MFNPCAI.EMETIS_OBJTYPE
enum class EMETIS_OBJTYPE : uint8_t
{
    METIS_OBJTYPE_CUT                              = 0,
    METIS_OBJTYPE_VOL                              = 1,
    METIS_OBJTYPE_NODE                             = 2,
    METIS_OBJTYPE_MAX                              = 3

};


// Enum  /Script/MFNPCAI.EMETIS_RTYPE
enum class EMETIS_RTYPE : uint8_t
{
    METIS_RTYPE_FM                                 = 0,
    METIS_RTYPE_GREEDY                             = 1,
    METIS_RTYPE_SEP2SIDED                          = 2,
    METIS_RTYPE_SEP1SIDED                          = 3,
    METIS_RTYPE_MAX                                = 4

};


// Enum  /Script/MFNPCAI.EMETIS_IPTYPE
enum class EMETIS_IPTYPE : uint8_t
{
    METIS_IPTYPE_GROW                              = 0,
    METIS_IPTYPE_RANDOM                            = 1,
    METIS_IPTYPE_EDGE                              = 2,
    METIS_IPTYPE_NODE                              = 3,
    METIS_IPTYPE_METISRB                           = 4,
    METIS_IPTYPE_MAX                               = 5

};


// Enum  /Script/MFNPCAI.EMETIS_CTYPE
enum class EMETIS_CTYPE : uint8_t
{
    METIS_CTYPE_RM                                 = 0,
    METIS_CTYPE_SHEM                               = 1,
    METIS_CTYPE_MAX                                = 2

};


// Enum  /Script/MFNPCAI.EMETIS_PTYPE
enum class EMETIS_PTYPE : uint8_t
{
    METIS_PTYPE_RB                                 = 0,
    METIS_PTYPE_KWAY                               = 1,
    METIS_PTYPE_MAX                                = 2

};


// Enum  /Script/MFNPCAI.EnumAIGrassType
enum class EnumAIGrassType : uint8_t
{
    E_Foliage                                      = 0,
    E_Landscape                                    = 1,
    E_MAX                                          = 2

};


// Enum  /Script/MFNPCAI.EnumAIGrassDebugBox
enum class EnumAIGrassDebugBox : uint8_t
{
    E_NONE                                         = 0,
    E_Foliage                                      = 1,
    E_Landscape                                    = 2,
    E_FoliageCylinders                             = 3,
    E_ALL                                          = 4,
    E_MAX                                          = 5

};


// Enum  /Script/MFNPCAI.EAILODActionPlan
enum class EAILODActionPlan : uint8_t
{
    NoLOD                                          = 0,
    Normal                                         = 1,
    Elite                                          = 2,
    Boss                                           = 3,
    EAILODActionPlan_MAX                           = 4

};


// Enum  /Script/MFNPCAI.EAimingType
enum class EAimingType : uint8_t
{
    Normal                                         = 0,
    Regular                                        = 1,
    EAimingType_MAX                                = 2

};


// Enum  /Script/MFNPCAI.ENPCAISceneEventID
enum class ENPCAISceneEventID : uint8_t
{
    None                                           = 0,
    Armory_Alarm_EscapeG1                          = 1,
    Armory_Alarm_EscapeWater                       = 2,
    Valley_Alarm_BossHouse                         = 3,
    Valley_Alarm_BossFactory                       = 4,
    CallHelp                                       = 5,
    ArmoryAlarmEscapeMine                          = 6,
    TVStation_Escape_Elevator                      = 7,
    ArmoryAlarmEscapeBunker                        = 8,
    Call_Defender_TVStation                        = 9,
    ENPCAISceneEventID_MAX                         = 10

};


// Enum  /Script/MFNPCAI.ESteepZoneSamplePointDropReason
enum class ESteepZoneSamplePointDropReason : uint8_t
{
    None                                           = 0,
    InvalidTrace                                   = 1,
    StartPenetrating                               = 2,
    WalkableFloor                                  = 3,
    NotEnoughNeighbours                            = 4,
    Count                                          = 5,
    ESteepZoneSamplePointDropReason_MAX            = 6

};


// Enum  /Script/MFNPCAI.ESteepZoneNavMeshPolyDropReason
enum class ESteepZoneNavMeshPolyDropReason : uint8_t
{
    None                                           = 0,
    GetTileAndPolyByRefFailed                      = 1,
    NotPoly                                        = 2,
    InvalidNormal                                  = 3,
    ValidIncludedAngle                             = 4,
    AllTrianglesDropped                            = 5,
    Count                                          = 6,
    ESteepZoneNavMeshPolyDropReason_MAX            = 7

};


// Enum  /Script/MFNPCAI.EAIKeyRouteQueryType
enum class EAIKeyRouteQueryType : uint8_t
{
    Safe                                           = 0,
    Short                                          = 1,
    EAIKeyRouteQueryType_MAX                       = 2

};


// Enum  /Script/MFNPCAI.ENPCSetPartType
enum class ENPCSetPartType : uint8_t
{
    None                                           = 0,
    Close                                          = 1,
    Middle                                         = 2,
    Far                                            = 3,
    ENPCSetPartType_MAX                            = 4

};


// Enum  /Script/MFNPCAI.EAITrackLOGType
enum class EAITrackLOGType : uint8_t
{
    Move                                           = 0,
    AimingBodyPart                                 = 1,
    AimingTime                                     = 2,
    AimingPredestined                              = 3,
    Shoot                                          = 4,
    BeHit                                          = 5,
    Decision                                       = 6,
    EAITrackLOGType_MAX                            = 7

};


// Enum  /Script/MFNPCAI.ENPCAITactic
enum class ENPCAITactic : uint8_t
{
    None                                           = 0,
    CloseFight                                     = 1,
    MidFight                                       = 2,
    LongFight                                      = 3,
    RushFace                                       = 4,
    FlankAttack                                    = 5,
    BackAround                                     = 6,
    Hide                                           = 7,
    RunAway                                        = 8,
    ENPCAITactic_MAX                               = 9

};


// Enum  /Script/MFNPCAI.EAIMainType
enum class EAIMainType : uint8_t
{
    EAIMainType_Scav                               = 0,
    EAIMainType_Boss                               = 1,
    EAIMainType_Follower                           = 2,
    EAIMainType_PMCAI                              = 3,
    EAIMainType_TeachingAI                         = 4,
    EAIMainType_TestAI                             = 5,
    EAIMainType_Elit                               = 6,
    EAIMainType_Elit_PlayerScavAI                  = 7,
    EAIMainType_AllyAI                             = 8,
    EAIMainType_MAX                                = 9

};


// Enum  /Script/MFNPCAI.EAIEnemyVisibilityType
enum class EAIEnemyVisibilityType : uint8_t
{
    NotVisible                                     = 0,
    VisibleBySense                                 = 1,
    Visible                                        = 2,
    EAIEnemyVisibilityType_MAX                     = 3

};


// Enum  /Script/MFNPCAI.EAIEnemyPriority
enum class EAIEnemyPriority : uint8_t
{
    EAIEnemyPriority_High                          = 0,
    EAIEnemyPriority_Medium                        = 1,
    EAIEnemyPriority_Low                           = 2,
    EAIEnemyPriority_MAX                           = 3

};


// Enum  /Script/MFNPCAI.EAIAimingBodyPartTrend
enum class EAIAimingBodyPartTrend : uint8_t
{
    None                                           = 0,
    Armor                                          = 1,
    NoArmor                                        = 2,
    Fatal                                          = 3,
    MinDamage                                      = 4,
    EAIAimingBodyPartTrend_MAX                     = 5

};


// Enum  /Script/MFNPCAI.EAIBodyBulkType
enum class EAIBodyBulkType : uint8_t
{
    HeadGroup                                      = 0,
    BodyGroup                                      = 1,
    LegsGroup                                      = 2,
    EAIBodyBulkType_MAX                            = 3

};


// Enum  /Script/MFNPCAI.EAIBodyPartType
enum class EAIBodyPartType : uint8_t
{
    EAIBodyPartType_Head                           = 0,
    EAIBodyPartType_Chest                          = 1,
    EAIBodyPartType_LefyArm                        = 2,
    EAIBodyPartType_RightArm                       = 3,
    EAIBodyPartType_LeftLeg                        = 4,
    EAIBodyPartType_RightLeg                       = 5,
    EAIBodyPartType_Stomach                        = 6,
    EAIBodyPartType_Max                            = 7

};


// Enum  /Script/MFNPCAI.ECrossShot_ToStance
enum class ECrossShot_ToStance : uint8_t
{
    Stand                                          = 0,
    Crouch                                         = 1,
    ECrossShot_MAX                                 = 2

};


// Enum  /Script/MFNPCAI.EAISenseBehaviorType
enum class EAISenseBehaviorType : uint8_t
{
    None                                           = 0,
    Loot                                           = 1,
    EAISenseBehaviorType_MAX                       = 2

};


// Enum  /Script/MFNPCAI.EAISoundType
enum class EAISoundType : uint8_t
{
    EAISoundType_ConfirmTargetScream               = 0,
    EAISoundType_MAX                               = 1

};


// Enum  /Script/MFNPCAI.ENPCAIPerceptibleTile
enum class ENPCAIPerceptibleTile : uint8_t
{
    None                                           = 0,
    Bomb                                           = 1,
    Stun                                           = 2,
    Smoke                                          = 3,
    Molotov                                        = 4,
    C4                                             = 5,
    Flash                                          = 6,
    FootSounder                                    = 7,
    TearGas                                        = 8,
    OffensiveGrenade                               = 9,
    TripMine                                       = 10,
    ClaymoreMine                                   = 11,
    SignalDetonator                                = 12,
    AlwaysOn                                       = 13,
    RPG                                            = 14,
    Monitor                                        = 15,
    CustomIndex                                    = 16,
    DefaultArea                                    = 17,
    AvoidanceArea                                  = 18,
    ObstacleArea                                   = 19,
    ParadropArea                                   = 20,
    VehicleArea                                    = 21,
    UnderPlatform                                  = 22,
    Unknown                                        = 23,
    Max                                            = 24

};


// Enum  /Script/MFNPCAI.EAIWorkResult
enum class EAIWorkResult : uint8_t
{
    Success                                        = 0,
    Failed                                         = 1,
    Wait                                           = 2,
    EAIWorkResult_MAX                              = 3

};


// Enum  /Script/MFNPCAI.EAISenseSightConf
enum class EAISenseSightConf : uint8_t
{
    Normal                                         = 0,
    Night                                          = 1,
    Light                                          = 2,
    EAISenseSightConf_MAX                          = 3

};


// Enum  /Script/MFNPCAI.ENPCAISenseChannel
enum class ENPCAISenseChannel : uint8_t
{
    NONE                                           = 0,
    Weapon_Channel                                 = 15,
    AISight_Channel                                = 25,
    ENPCAISenseChannel_MAX                         = 26

};


// Enum  /Script/MFNPCAI.EAISenseType
enum class EAISenseType : uint8_t
{
    ALL                                            = 0,
    Sight                                          = 1,
    Hearing                                        = 2,
    Damage                                         = 3,
    ComingExplosion                                = 4,
    EAISenseType_MAX                               = 5

};


// Enum  /Script/MFNPCAI.ENPCAISenseBarrier
enum class ENPCAISenseBarrier : uint8_t
{
    None                                           = 0,
    Normal                                         = 1,
    Grass                                          = 2,
    ALLY                                           = 3,
    OtherEnemy                                     = 4,
    Smoke                                          = 5,
    ENPCAISenseBarrier_MAX                         = 6

};


// Enum  /Script/MFNPCAI.ENPCAIPriority
enum class ENPCAIPriority : uint8_t
{
    Low                                            = 0,
    Middle                                         = 1,
    High                                           = 2,
    Max                                            = 3

};


// Enum  /Script/MFNPCAI.EAIGotoPointDecision
enum class EAIGotoPointDecision : uint8_t
{
    Normal                                         = 0,
    SafetyDoor                                     = 1,
    Swing                                          = 2,
    EAIGotoPointDecision_MAX                       = 3

};


// Enum  /Script/MFNPCAI.EAIGroupRequestPriority
enum class EAIGroupRequestPriority : uint8_t
{
    Low                                            = 0,
    Normal                                         = 1,
    Top                                            = 2,
    Fatal                                          = 3,
    EAIGroupRequestPriority_MAX                    = 4

};


// Enum  /Script/MFNPCAI.EAIProfileType
enum class EAIProfileType : uint8_t
{
    Aiming                                         = 0,
    AIType                                         = 1,
    Boss                                           = 2,
    Core                                           = 3,
    Curve                                          = 4,
    Global                                         = 5,
    Grenade                                        = 6,
    Hearing                                        = 7,
    Lay                                            = 8,
    Look                                           = 9,
    Mind                                           = 10,
    Move                                           = 11,
    Shoot                                          = 12,
    Sound                                          = 13,
    Weapon                                         = 14,
    Damage                                         = 15,
    Health                                         = 16,
    PlayerActionReaction                           = 17,
    BTBlock                                        = 18,
    Strategy                                       = 19,
    Smart                                          = 20,
    Tactic                                         = 21,
    RequestRun                                     = 22,
    MAX                                            = 23

};


// Enum  /Script/MFNPCAI.ENPCAIDecision
enum class ENPCAIDecision : uint8_t
{
    None                                           = 0,
    RushFaceWhenDisable                            = 1,
    ShootFromCover                                 = 2,
    ShootFromGround                                = 3,
    ShootPrecisely                                 = 4,
    RushFaceWithAlly                               = 5,
    FindCoverToHide                                = 6,
    ChangeCoverAfterNotSafe                        = 7,
    MoveFurther                                    = 8,
    MoveCloser                                     = 9,
    MoveToFlank                                    = 10,
    MoveToAttackPoint                              = 11,
    ChangeCover                                    = 12,
    SearchEnemy                                    = 13,
    HoldPosition                                   = 14,
    BackToCover                                    = 15,
    DogFight                                       = 16,
    CautionInPlace                                 = 17,
    CautionInCover                                 = 18,
    CheckSuspiciousPoint                           = 19,
    SuspiciousPointClear                           = 20,
    GoToNextPathNode                               = 21,
    FollowTargetBoss                               = 22,
    StandAndLookAround                             = 23,
    PacingInPlace                                  = 24,
    TakeMedicine                                   = 25,
    CallHelp                                       = 26,
    RushStrike                                     = 27,
    RushFace                                       = 28,
    LootNearby                                     = 29,
    DodgeGrenade                                   = 30,
    ThrowGrenade                                   = 31,
    WaitInEscapeVolume                             = 32,
    ShootFootstepCreator                           = 33,
    KillDBNOEnemy                                  = 34,
    SneakApproaching                               = 35,
    ReloadInGround                                 = 36,
    ReloadInCover                                  = 37,
    Overwatch                                      = 38,
    ActiveAlarmDevice                              = 39,
    Escape                                         = 40,
    DodgeFire                                      = 41,
    ThrowSmoke                                     = 42,
    ProneShoot                                     = 43,
    FindPronePoint                                 = 44,
    CrouchShoot                                    = 45,
    ProneSuppress                                  = 46,
    CrouchSuppress                                 = 47,
    StandSuppress                                  = 48,
    DualCharge                                     = 49,
    DualGuard                                      = 50,
    Retreat                                        = 51,
    ChangeCoverAfterNotAdvantage                   = 52,
    QuickToHide                                    = 53,
    ChangeCoverToCrouch                            = 54,
    CrouchAimingInCover                            = 55,
    CallForHelp                                    = 56,
    RidiculeVoice                                  = 57,
    StayInPlace                                    = 58,
    PositionAdjustment                             = 59,
    DodgeAttackMove                                = 60,
    MoveToLocNeedArrive                            = 61,
    SmokeToAssistHide                              = 62,
    TacticAction_RushFace                          = 63,
    GrenadeToPeek                                  = 64,
    DodgeGrenadeHold                               = 65,
    TeamMove                                       = 66,
    ThrowStepCreator                               = 67,
    SuppressionChangeClose                         = 68,
    SuppressionInPlace                             = 69,
    SuppressionControlDistance                     = 70,
    SuppressionDoor                                = 71,
    OutBattleVolume                                = 72,
    SlientDefenseDoor                              = 73,
    SlientDefenseChangeFar                         = 74,
    SlientDefenseControlDistance                   = 75,
    HoldAreaWithWall                               = 76,
    HoldRoomWithWall                               = 77,
    FootStepCreatorMoveClose                       = 78,
    FootStepCreatorMoveFar                         = 79,
    OpenDoorRush                                   = 80,
    OpenDoorSlient                                 = 81,
    MoveToDoorSafePoint                            = 82,
    EscapeRush                                     = 83,
    EscapeSlient                                   = 84,
    DodgeFlashProjectile                           = 85,
    RandomRangeShoot                               = 86,
    GrassMove                                      = 87,
    ProtectSafeBox                                 = 88,
    PeekFromPeekMark                               = 89,
    PlaceTrapDevice                                = 90,
    CallHelpOnHit                                  = 91,
    AroundFindEnemy                                = 92,
    AlwaysReload                                   = 93,
    MeleeAttackOnReload                            = 94,
    TakeMedicineOnHit                              = 95,
    FoolShootOnHit                                 = 96,
    BattleShow                                     = 97,
    OutOfBattleAct                                 = 98,
    OutOfAllyRange                                 = 99,
    WildlyShootInCover                             = 100,
    AntiCamper                                     = 101,
    TeamOrder_StayInLoc                            = 102,
    TeamOrder_AttackAndBack                        = 103,
    ENPCAIDecision_MAX                             = 104

};


// Enum  /Script/MFNPCAI.EAIPerformance
enum class EAIPerformance : uint8_t
{
    None                                           = 0,
    Camp1                                          = 1,
    Camp2                                          = 2,
    Camp3                                          = 3,
    Camp4                                          = 4,
    Camp5                                          = 5,
    Camp6                                          = 6,
    Camp7                                          = 7,
    Camp8                                          = 8,
    Camp9                                          = 9,
    Camp10                                         = 10,
    Camp11                                         = 11,
    Camp12                                         = 12,
    Camp13                                         = 13,
    Camp14                                         = 14,
    Boss1                                          = 15,
    Boss2                                          = 16,
    Boss3                                          = 17,
    Boss4                                          = 18,
    Boss5                                          = 19,
    Boss5                                          = 20,
    Boss5                                          = 21,
    Boss                                           = 22,
    Boss                                           = 23,
    EventBoss1                                     = 24,
    EventBoss2                                     = 25,
    EventBoss3                                     = 26,
    EventFollower1                                 = 27,
    EventFollower2                                 = 28,
    Follower1                                      = 29,
    Follower2                                      = 30,
    Follower3                                      = 31,
    Follower4                                      = 32,
    Follower5                                      = 33,
    Follower5                                      = 34,
    Follower_6                                     = 35,
    Follower_6                                     = 36,
    Follower_6                                     = 37,
    Follower_6                                     = 38,
    Follower_6                                     = 39,
    Follower_6                                     = 40,
    Follower7                                      = 41,
    PMC1                                           = 42,
    PlayerScav1                                    = 43,
    EventScav1                                     = 44,
    EventScav1                                     = 45,
    EventScav2                                     = 46,
    EventScav3                                     = 47,
    EventBossDoss1                                 = 48,
    EventFollowerDoss1                             = 49,
    EventFollowerDoss2                             = 50,
    EventGnesk                                     = 51,
    Event_260_Camp3                                = 52,
    Event_260_Camp6                                = 53,
    Event_260_Camp14                               = 54,
    Camp15                                         = 55,
    Boss                                           = 56,
    Boss_9                                         = 57,
    Boss_9                                         = 58,
    Boss_9                                         = 59,
    Boss_9                                         = 60,
    EAIPerformance_MAX                             = 61

};


// Enum  /Script/MFNPCAI.EAISenseSourceType
enum class EAISenseSourceType : uint8_t
{
    EAISenseSourceType_Grenade                     = 0,
    EAISenseSourceType_MAX                         = 1

};


// Enum  /Script/MFNPCAI.EBlackboardEntryCondition
enum class EBlackboardEntryCondition : uint8_t
{
    BlackboardEntryCondition_Equal                 = 0,
    BlackboardEntryCondition_Greater               = 1,
    BlackboardEntryCondition_Less                  = 2,
    BlackboardEntryCondition_MAX                   = 3

};


// Enum  /Script/MFNPCAI.ENPCKnowWeather
enum class ENPCKnowWeather : uint8_t
{
    Normal                                         = 0,
    Fog                                            = 1,
    ENPCKnowWeather_MAX                            = 2

};


// Enum  /Script/MFNPCAI.ENPCWeakenDebuffType
enum class ENPCWeakenDebuffType : uint8_t
{
    LoseSight                                      = 0,
    Tinnitus                                       = 1,
    Slowdown                                       = 2,
    ENPCWeakenDebuffType_MAX                       = 3

};


// Enum  /Script/MFNPCAI.ENPCPanicType
enum class ENPCPanicType : uint8_t
{
    None                                           = 0,
    Run                                            = 1,
    Crouch                                         = 2,
    Prone                                          = 3,
    ENPCPanicType_MAX                              = 4

};


// Enum  /Script/MFNPCAI.EAILiveState
enum class EAILiveState : uint8_t
{
    None                                           = 0,
    Spawned                                        = 1,
    Actived                                        = 2,
    Dead                                           = 3,
    EAILiveState_MAX                               = 4

};


// Enum  /Script/MFNPCAI.EAIMoveType
enum class EAIMoveType : uint8_t
{
    AIMoveType_Walk                                = 0,
    AIMoveType_Run                                 = 1,
    AIMoveType_Sprint                              = 2,
    AIMoveType_MAX                                 = 3

};


// Enum  /Script/MFNPCAI.EAILeanType
enum class EAILeanType : uint8_t
{
    AILeanType_Center                              = 0,
    AILeanType_Left                                = 1,
    AILeanType_Right                               = 2,
    AILeanType_MAX                                 = 3

};


// Enum  /Script/MFNPCAI.EAIPerceptionTargetType
enum class EAIPerceptionTargetType : uint8_t
{
    None                                           = 0,
    Player                                         = 1,
    OtherAI                                        = 2,
    DroneActor                                     = 3,
    EAIPerceptionTargetType_MAX                    = 4

};


// Enum  /Script/MFNPCAI.EAIPose
enum class EAIPose : uint8_t
{
    AIPose_Stand                                   = 0,
    AIPose_Crouch                                  = 1,
    AIPose_Prone                                   = 2,
    AIPose_Slide                                   = 3,
    AIPose_Move                                    = 4,
    AIPose_Vehicle                                 = 5,
    AIPose_MAX                                     = 6

};


// Enum  /Script/MFNPCAI.EAISpecialFireType
enum class EAISpecialFireType : uint8_t
{
    EAISpecialFireType_Miss                        = 0,
    EAISpecialFireType_MAX                         = 1

};


// Enum  /Script/MFNPCAI.EAILookPointMode
enum class EAILookPointMode : uint8_t
{
    ToMovingDirection                              = 0,
    ToCustomPoint                                  = 1,
    NoSteering                                     = 2,
    EAILookPointMode_MAX                           = 3

};


// Enum  /Script/AIActionPointGeneratorRuntime.EActionPointType
enum class EActionPointType : uint8_t
{
    None                                           = 0,
    CoverPoint                                     = 1,
    TacticPoint                                    = 2,
    KeyRoutePoint                                  = 3,
    NavSkeletonPoint                               = 4,
    CoverEdgePoint                                 = 5,
    EActionPointType_MAX                           = 6

};


// Enum  /Script/AIActionPointGeneratorRuntime.ETakeCoverResult
enum class ETakeCoverResult : uint8_t
{
    InvalidActor                                   = 0,
    AlreadyNull                                    = 1,
    Occupied                                       = 2,
    OtherUsing                                     = 3,
    SelfUsing                                      = 4,
    Released                                       = 5,
    COUNT                                          = 6,
    ETakeCoverResult_MAX                           = 7

};


// Enum  /Script/AIActionPointGeneratorRuntime.ENavMeshEdgeDropReason
enum class ENavMeshEdgeDropReason : uint8_t
{
    None                                           = 0,
    LengthTooShort                                 = 1,
    InvalidHoleSide                                = 2,
    InvalidMovableRange                            = 3,
    SetupDefenceMapFailed                          = 4,
    NoAnyDefenceRegionFastTest                     = 5,
    NoAnyDefenceRegion                             = 6,
    Count                                          = 7,
    ENavMeshEdgeDropReason_MAX                     = 8

};


// Enum  /Script/AIActionPointGeneratorRuntime.ENavMeshTacticPointDropReason
enum class ENavMeshTacticPointDropReason : uint8_t
{
    None                                           = 0,
    InExclusionVolume                              = 1,
    AbsoluteDefenceRatioNotEnough                  = 2,
    WindowDefenceRatioNotEnough                    = 3,
    LessThanRequiredMinimumDefenceAngle            = 4,
    GreaterThanLimitedMaximumDefenceAngle          = 5,
    DefenceDirectionNotInHoleSide                  = 6,
    PointsTooClose                                 = 7,
    Count                                          = 8,
    ENavMeshTacticPointDropReason_MAX              = 9

};


// Enum  /Script/AIActionPointGeneratorRuntime.ENPCPoseType
enum class ENPCPoseType : uint8_t
{
    Invalid                                        = 0,
    Prone                                          = 1,
    Crouch                                         = 2,
    Stand                                          = 3,
    ENPCPoseType_MAX                               = 4

};


// Enum  /Script/AIActionPointGeneratorRuntime.ETacticPointType
enum class ETacticPointType : uint8_t
{
    NONE                                           = 0,
    FlashBag                                       = 1,
    Smoke                                          = 2,
    HighValue                                      = 3,
    FatalGate                                      = 4,
    Escape                                         = 5,
    Trap                                           = 6,
    OverWatch                                      = 7,
    Prone                                          = 8,
    Window                                         = 9,
    Door                                           = 10,
    Retreat                                        = 11,
    Transfer                                       = 12,
    DoorSafety                                     = 13,
    ETacticPointType_MAX                           = 14

};


// Enum  /Script/CoverGenerator.ENavLinkType
enum class ENavLinkType : uint8_t
{
    None                                           = 0,
    Door                                           = 1,
    Cabinet                                        = 2,
    JumpingDown                                    = 3,
    JumpingOver                                    = 4,
    Climb                                          = 5,
    Vault                                          = 6,
    ENavLinkType_MAX                               = 7

};


// Enum  /Script/MFPluginWrapper.EMFBoxLoginSourceType
enum class EMFBoxLoginSourceType : uint8_t
{
    NONE                                           = 0,
    QQLogin                                        = 1,
    WeChatLogin                                    = 2,
    Tourist                                        = 3,
    EMFBoxLoginSourceType_MAX                      = 4

};


// Enum  /Script/MFPluginWrapper.EMFBoxClientType
enum class EMFBoxClientType : uint8_t
{
    NONE                                           = 0,
    InitBox                                        = 1,
    EMFBoxClientType_MAX                           = 2

};


// Enum  /Script/MFPluginWrapper.EMFNewNetworkState
enum class EMFNewNetworkState : uint8_t
{
    NotReachable                                   = 0,
    WWAN                                           = 1,
    Wifi                                           = 2,
    Others                                         = 3,
    EMFNewNetworkState_MAX                         = 4

};


// Enum  /Script/MFPluginWrapper.EPufferTaskState
enum class EPufferTaskState : uint8_t
{
    PufferTask_None                                = 0,
    PufferTask_Downloading                         = 1,
    PufferTask_Error                               = 2,
    PufferTask_MAX                                 = 3

};


// Enum  /Script/MFPluginWrapper.EUamDeviceRank
enum class EUamDeviceRank : uint8_t
{
    SuperFirstGear                                 = 7,
    FirstGear                                      = 6,
    SecondGear                                     = 5,
    ThirdGear                                      = 3,
    FourthGear                                     = 2,
    FifthGear                                      = 1,
    SixthGear                                      = 0,
    EUamDeviceRank_MAX                             = 8

};


// Enum  /Script/MFPluginWrapper.EUAGraphicStyleQuality
enum class EUAGraphicStyleQuality : uint8_t
{
    GfxStyleQualityDefault                         = 0,
    GfxStyleQualityRealistic                       = 0,
    GfxStyleQualityWarm                            = 1,
    GfxStyleQualityCold                            = 2,
    GfxStyleQualityBright                          = 3,
    EUAGraphicStyleQuality_MAX                     = 4

};


// Enum  /Script/MFPluginWrapper.EUAFrameRateLevel
enum class EUAFrameRateLevel : uint8_t
{
    FrameRateDefault                               = 0,
    FrameRateLow                                   = 0,
    FrameRateMedium                                = 1,
    FrameRateHigh                                  = 2,
    FrameRateSuper                                 = 3,
    FrameRateMax                                   = 4,
    FrameRate90                                    = 5,
    FrameRate120                                   = 6,
    FrameRate144                                   = 7,
    FrameRate165                                   = 8,
    EUAFrameRateLevel_MAX                          = 9

};


// Enum  /Script/MFPluginWrapper.EUAGrahpicsQuality
enum class EUAGrahpicsQuality : uint8_t
{
    GfxQualityDefault                              = 0,
    GfxQualitySuperLow                             = 0,
    GfxQualityLow                                  = 1,
    GfxQualityMedium                               = 2,
    GfxQualityHigh                                 = 3,
    GfxQualityHDRHigh                              = 4,
    GfxQualitySuperHigh                            = 5,
    GfxQualityNum                                  = 6,
    EUAGrahpicsQuality_MAX                         = 7

};


// Enum  /Script/MFPluginWrapper.EMFLBSLocationAuthorizationStates
enum class EMFLBSLocationAuthorizationStates : uint8_t
{
    AuthorizedWhenInUse                            = 0,
    AuthorizedDenied                               = 1,
    AuthorizedNotDetermined                        = 2,
    EMFLBSLocationAuthorizationStates_MAX          = 3

};


// Enum  /Script/MFPluginWrapper.EMFVoiceEvent
enum class EMFVoiceEvent : uint8_t
{
    kEventNoDeviceConnected                        = 0,
    kEventHeadsetDisconnected                      = 10,
    kEventHeadsetConnected                         = 11,
    kEventBluetoothHeadsetDisconnected             = 20,
    kEventBluetoothHeadsetConnected                = 21,
    kEventMicStateOpenSucc                         = 30,
    kEventMicStateOpenErr                          = 31,
    kEventMicStateNoOpen                           = 32,
    kEventSpeakerStateOpenSucc                     = 40,
    kEventSpeakerStateOpenErr                      = 41,
    kEventSpeakerStateNoOpen                       = 42,
    kEventAudioInterruptBegin                      = 50,
    kEventAudioInterruptEnd                        = 51,
    kEventAudioRecoderException                    = 52,
    kEventAudioRenderException                     = 53,
    kEventPhoneCallPickUp                          = 54,
    kEventPhoneCallHangUp                          = 55,
    EMFVoiceEvent_MAX                              = 56

};


// Enum  /Script/MFPluginWrapper.EMFVoiceSpeechTranslateType
enum class EMFVoiceSpeechTranslateType : uint8_t
{
    SPEECH_TRANSLATE_STST                          = 0,
    SPEECH_TRANSLATE_STTT                          = 1,
    SPEECH_TRANSLATE_STTS                          = 2,
    SPEECH_TRANSLATE_MAX                           = 3

};


// Enum  /Script/MFPluginWrapper.EMFVoiceSpeechLanguageType
enum class EMFVoiceSpeechLanguageType : uint8_t
{
    SPEECH_LANGUAGE_ZH                             = 0,
    SPEECH_LANGUAGE_EN                             = 1,
    SPEECH_LANGUAGE_JA                             = 2,
    SPEECH_LANGUAGE_KO                             = 3,
    SPEECH_LANGUAGE_DE                             = 4,
    SPEECH_LANGUAGE_FR                             = 5,
    SPEECH_LANGUAGE_ES                             = 6,
    SPEECH_LANGUAGE_IT                             = 7,
    SPEECH_LANGUAGE_TR                             = 8,
    SPEECH_LANGUAGE_RU                             = 9,
    SPEECH_LANGUAGE_PT                             = 10,
    SPEECH_LANGUAGE_VI                             = 11,
    SPEECH_LANGUAGE_ID                             = 12,
    SPEECH_LANGUAGE_MS                             = 13,
    SPEECH_LANGUAGE_TH                             = 14,
    SPEECH_LANGUAGE_ZH_TW                          = 15,
    SPEECH_LANGUAGE_AF                             = 16,
    SPEECH_LANGUAGE_SQ                             = 17,
    SPEECH_LANGUAGE_AM                             = 18,
    SPEECH_LANGUAGE_AR                             = 19,
    SPEECH_LANGUAGE_HY                             = 20,
    SPEECH_LANGUAGE_AZ                             = 21,
    SPEECH_LANGUAGE_EU                             = 22,
    SPEECH_LANGUAGE_BN                             = 23,
    SPEECH_LANGUAGE_BS                             = 24,
    SPEECH_LANGUAGE_BG                             = 25,
    SPEECH_LANGUAGE_MY                             = 26,
    SPEECH_LANGUAGE_CA                             = 27,
    SPEECH_LANGUAGE_HR                             = 28,
    SPEECH_LANGUAGE_CS                             = 29,
    SPEECH_LANGUAGE_DA                             = 30,
    SPEECH_LANGUAGE_NL                             = 31,
    SPEECH_LANGUAGE_ET                             = 32,
    SPEECH_LANGUAGE_FIL                            = 33,
    SPEECH_LANGUAGE_FI                             = 34,
    SPEECH_LANGUAGE_GL                             = 35,
    SPEECH_LANGUAGE_KA                             = 36,
    SPEECH_LANGUAGE_EL                             = 37,
    SPEECH_LANGUAGE_GU                             = 38,
    SPEECH_LANGUAGE_IW                             = 39,
    SPEECH_LANGUAGE_HI                             = 40,
    SPEECH_LANGUAGE_HU                             = 41,
    SPEECH_LANGUAGE_IS                             = 42,
    SPEECH_LANGUAGE_JV                             = 43,
    SPEECH_LANGUAGE_KN                             = 44,
    SPEECH_LANGUAGE_KK                             = 45,
    SPEECH_LANGUAGE_KM                             = 46,
    SPEECH_LANGUAGE_LO                             = 47,
    SPEECH_LANGUAGE_LV                             = 48,
    SPEECH_LANGUAGE_LT                             = 49,
    SPEECH_LANGUAGE_MK                             = 50,
    SPEECH_LANGUAGE_ML                             = 51,
    SPEECH_LANGUAGE_MR                             = 52,
    SPEECH_LANGUAGE_MN                             = 53,
    SPEECH_LANGUAGE_NE                             = 54,
    SPEECH_LANGUAGE_NO                             = 55,
    SPEECH_LANGUAGE_FA                             = 56,
    SPEECH_LANGUAGE_PL                             = 57,
    SPEECH_LANGUAGE_PA                             = 58,
    SPEECH_LANGUAGE_RO                             = 59,
    SPEECH_LANGUAGE_SR                             = 60,
    SPEECH_LANGUAGE_SI                             = 61,
    SPEECH_LANGUAGE_SK                             = 62,
    SPEECH_LANGUAGE_SL                             = 63,
    SPEECH_LANGUAGE_SU                             = 64,
    SPEECH_LANGUAGE_SW                             = 65,
    SPEECH_LANGUAGE_SV                             = 66,
    SPEECH_LANGUAGE_TA                             = 67,
    SPEECH_LANGUAGE_TE                             = 68,
    SPEECH_LANGUAGE_UK                             = 69,
    SPEECH_LANGUAGE_UR                             = 70,
    SPEECH_LANGUAGE_UZ                             = 71,
    SPEECH_LANGUAGE_ZU                             = 72,
    SPEECH_LANGUAGE_CNT                            = 73,
    SPEECH_LANGUAGE_MAX                            = 74

};


// Enum  /Script/MFPluginWrapper.EMFVoiceMemberRole
enum class EMFVoiceMemberRole : uint8_t
{
    kVoiceMemberRoleNone                           = 0,
    kVoiceMemberRoleAnchor                         = 1,
    kVoiceMemberRoleAudience                       = 2,
    EMFVoiceMemberRole_MAX                         = 3

};


// Enum  /Script/MFPluginWrapper.EMFVoiceLanguage
enum class EMFVoiceLanguage : uint8_t
{
    kVoiceLanguageChina                            = 0,
    kVoiceLanguageKorean                           = 1,
    kVoiceLanguageEnglish                          = 2,
    kVoiceLanguageJapanese                         = 3,
    EMFVoiceLanguage_MAX                           = 4

};


// Enum  /Script/MFBaseModule.EGameSceneType
enum class EGameSceneType : uint8_t
{
    GST_None                                       = 0,
    GST_Lobby                                      = 1,
    GST_InBattle                                   = 2,
    GST_CG                                         = 3,
    GST_ShootingRoom                               = 4,
    GST_MAX                                        = 5

};


// Enum  /Script/MFBaseModule.EPlayGameMode
enum class EPlayGameMode : uint8_t
{
    PGM_ClassicGameMode                            = 0,
    PGM_RoundGameMode                              = 1,
    PGM_PVEGameMode                                = 2,
    PGM_BRGameMode                                 = 3,
    PGM_TutorialGameMode                           = 4,
    PGM_MAX                                        = 5

};


// Enum  /Script/MFBaseModule.EQCCFileType
enum class EQCCFileType : uint8_t
{
    None                                           = 0,
    Domestic                                       = 1,
    Oversea                                        = 2,
    EQCCFileType_MAX                               = 3

};


// Enum  /Script/MFBaseModule.EMobileDeviceLevel
enum class EMobileDeviceLevel : uint8_t
{
    MobileDeviceLevel_0_VeryVeryLow                = 0,
    MobileDeviceLevel_1_VeryLow                    = 1,
    MobileDeviceLevel_2_Low                        = 2,
    MobileDeviceLevel_3_Medium                     = 3,
    MobileDeviceLevel_4_Medium                     = 4,
    MobileDeviceLevel_5_High                       = 5,
    MobileDeviceLevel_6_HDR                        = 6,
    MobileDeviceLevel_7_Ultra                      = 7,
    MobileDeviceLevel_Num                          = 8,
    MobileDeviceLevel_MAX                          = 9

};


// Enum  /Script/PhysXVehicles.EWheelSweepType
enum class EWheelSweepType : uint8_t
{
    SimpleAndComplex                               = 0,
    Simple                                         = 1,
    Complex                                        = 2,
    EWheelSweepType_MAX                            = 3

};


// Enum  /Script/PhysXVehicles.EVehicleDifferential4W
enum class EVehicleDifferential4W : uint8_t
{
    LimitedSlip_4W                                 = 0,
    LimitedSlip_FrontDrive                         = 1,
    LimitedSlip_RearDrive                          = 2,
    Open_4W                                        = 3,
    Open_FrontDrive                                = 4,
    Open_RearDrive                                 = 5,
    EVehicleDifferential4W_MAX                     = 6

};


// Enum  /Script/RigLogicModule.EDNADataLayer
enum class EDNADataLayer : uint8_t
{
    Descriptor                                     = 0,
    Definition                                     = 1,
    Behavior                                       = 2,
    Geometry                                       = 3,
    GeometryWithoutBlendShapes                     = 4,
    AllWithoutBlendShapes                          = 5,
    All                                            = 6,
    EDNADataLayer_MAX                              = 7

};


// Enum  /Script/RigLogicModule.EDirection
enum class EDirection : uint8_t
{
    Left                                           = 0,
    Right                                          = 1,
    Up                                             = 2,
    Down                                           = 3,
    Front                                          = 4,
    Back                                           = 5,
    EDirection_MAX                                 = 6

};


// Enum  /Script/RigLogicModule.ERotationUnit
enum class ERotationUnit : uint8_t
{
    Degrees                                        = 0,
    Radians                                        = 1,
    ERotationUnit_MAX                              = 2

};


// Enum  /Script/RigLogicModule.ETranslationUnit
enum class ETranslationUnit : uint8_t
{
    CM                                             = 0,
    M                                              = 1,
    ETranslationUnit_MAX                           = 2

};


// Enum  /Script/RigLogicModule.EGender
enum class EGender : uint8_t
{
    Male                                           = 0,
    Female                                         = 1,
    Other                                          = 2,
    EGender_MAX                                    = 3

};


// Enum  /Script/RigLogicModule.EArchetype
enum class EArchetype : uint8_t
{
    Asian                                          = 0,
    Black                                          = 1,
    Caucasian                                      = 2,
    Hispanic                                       = 3,
    Alien                                          = 4,
    Other                                          = 5,
    EArchetype_MAX                                 = 6

};


// Enum  /Script/RigLogicModule.ERigLogicCalculationType
enum class ERigLogicCalculationType : uint8_t
{
    Scalar                                         = 0,
    SSE                                            = 1,
    AVX                                            = 2,
    ERigLogicCalculationType_MAX                   = 3

};


// Enum  /Script/PoseSearch.EActorMovementCompensationMode
enum class EActorMovementCompensationMode : uint8_t
{
    ComponentSpace                                 = 0,
    WorldSpace                                     = 1,
    SuddenMotionOnly                               = 2,
    EActorMovementCompensationMode_MAX             = 3

};


// Enum  /Script/PoseSearch.EPelvisHeightMode
enum class EPelvisHeightMode : uint8_t
{
    AllLegs                                        = 0,
    AllPlantedFeet                                 = 1,
    FrontPlantedFeetUphill_FrontFeetDownhill       = 2,
    EPelvisHeightMode_MAX                          = 3

};


// Enum  /Script/PoseSearch.EFootPlacementLockType
enum class EFootPlacementLockType : uint8_t
{
    Unlocked                                       = 0,
    PivotAroundBall                                = 1,
    PivotAroundAnkle                               = 2,
    LockRotation                                   = 3,
    EFootPlacementLockType_MAX                     = 4

};


// Enum  /Script/PoseSearch.EOffsetRootBone_CollisionTestingMode
enum class EOffsetRootBone_CollisionTestingMode : uint8_t
{
    Disabled                                       = 0,
    ShrinkMaxTranslation                           = 1,
    PlanarCollision                                = 2,
    EOffsetRootBone_MAX                            = 3

};


// Enum  /Script/PoseSearch.EOrientationWarpingSpace
enum class EOrientationWarpingSpace : uint8_t
{
    ComponentTransform                             = 0,
    RootBoneTransform                              = 1,
    CustomTransform                                = 2,
    EOrientationWarpingSpace_MAX                   = 3

};


// Enum  /Script/PoseSearch.EWarpingVectorMode
enum class EWarpingVectorMode : uint8_t
{
    ComponentSpaceVector                           = 0,
    ActorSpaceVector                               = 1,
    WorldSpaceVector                               = 2,
    IKFootRootLocalSpaceVector                     = 3,
    EWarpingVectorMode_MAX                         = 4

};


// Enum  /Script/PoseSearch.EWarpingEvaluationMode
enum class EWarpingEvaluationMode : uint8_t
{
    Manual                                         = 0,
    Graph                                          = 1,
    EWarpingEvaluationMode_MAX                     = 2

};


// Enum  /Script/PoseSearch.EPoseSearchMirrorOption
enum class EPoseSearchMirrorOption : uint8_t
{
    UnmirroredOnly                                 = 0,
    MirroredOnly                                   = 1,
    UnmirroredAndMirrored                          = 2,
    EPoseSearchMirrorOption_MAX                    = 3

};


// Enum  /Script/PoseSearch.EPoseSearchMode
enum class EPoseSearchMode : uint8_t
{
    BruteForce                                     = 0,
    PCAKDTree                                      = 1,
    VPTree                                         = 2,
    EPoseSearchMode_MAX                            = 3

};


// Enum  /Script/PoseSearch.EPermutationTimeType
enum class EPermutationTimeType : uint8_t
{
    UseSampleTime                                  = 0,
    UsePermutationTime                             = 1,
    UseSampleToPermutationTime                     = 2,
    EPermutationTimeType_MAX                       = 3

};


// Enum  /Script/PoseSearch.EInputQueryPose
enum class EInputQueryPose : uint8_t
{
    UseCharacterPose                               = 0,
    UseContinuingPose                              = 1,
    EInputQueryPose_MAX                            = 2

};


// Enum  /Script/PoseSearch.EComponentStrippingVector
enum class EComponentStrippingVector : uint8_t
{
    None                                           = 0,
    StripXY                                        = 1,
    StripZ                                         = 2,
    EComponentStrippingVector_MAX                  = 3

};


// Enum  /Script/PoseSearch.EHeadingAxis
enum class EHeadingAxis : uint8_t
{
    X                                              = 0,
    Y                                              = 1,
    Z                                              = 2,
    Num                                            = 3,
    EHeadingAxis_MAX                               = 4

};


// Enum  /Script/PoseSearch.EPoseSearchBoneFlags
enum class EPoseSearchBoneFlags : uint8_t
{
    Velocity                                       = 1,
    Position                                       = 2,
    Rotation                                       = 4,
    Phase                                          = 8,
    EPoseSearchBoneFlags_MAX                       = 9

};


// Enum  /Script/PoseSearch.EPoseSearchTrajectoryFlags
enum class EPoseSearchTrajectoryFlags : uint8_t
{
    Velocity                                       = 1,
    Position                                       = 2,
    VelocityDirection                              = 4,
    FacingDirection                                = 8,
    VelocityXY                                     = 16,
    PositionXY                                     = 32,
    VelocityDirectionXY                            = 64,
    FacingDirectionXY                              = 128,
    EPoseSearchTrajectoryFlags_MAX                 = 129

};


// Enum  /Script/PoseSearch.EOffsetRootBoneMode
enum class EOffsetRootBoneMode : uint8_t
{
    Accumulate                                     = 0,
    Interpolate                                    = 1,
    Hold                                           = 2,
    Release                                        = 3,
    EOffsetRootBoneMode_MAX                        = 4

};


// Enum  /Script/PoseSearch.EPoseSearchInterruptMode
enum class EPoseSearchInterruptMode : uint8_t
{
    DoNotInterrupt                                 = 0,
    InterruptOnDatabaseChange                      = 1,
    InterruptOnDatabaseChangeAndInvalidateContinuingPose = 2,
    ForceInterrupt                                 = 3,
    ForceInterruptAndInvalidateContinuingPose      = 4,
    EPoseSearchInterruptMode_MAX                   = 5

};


// Enum  /Script/PoseSearch.EPoseSearchDataPreprocessor
enum class EPoseSearchDataPreprocessor : uint8_t
{
    None                                           = 0,
    Normalize                                      = 1,
    NormalizeOnlyByDeviation                       = 2,
    NormalizeWithCommonSchema                      = 3,
    EPoseSearchDataPreprocessor_MAX                = 4

};


// Enum  /Script/BlendStack.EAnimSyncMethod
enum class EAnimSyncMethod : uint8_t
{
    DoNotSync                                      = 0,
    SyncGroup                                      = 1,
    Graph                                          = 2,
    EAnimSyncMethod_MAX                            = 3

};


// Enum  /Script/UMG.ESlateAccessibleBehavior
enum class ESlateAccessibleBehavior : uint8_t
{
    NotAccessible                                  = 0,
    Auto                                           = 1,
    Summary                                        = 2,
    Custom                                         = 3,
    ToolTip                                        = 4,
    ESlateAccessibleBehavior_MAX                   = 5

};


// Enum  /Script/SlateCore.EUINavigation
enum class EUINavigation : uint8_t
{
    Left                                           = 0,
    Right                                          = 1,
    Up                                             = 2,
    Down                                           = 3,
    Next                                           = 4,
    Previous                                       = 5,
    Num                                            = 6,
    Invalid                                        = 7,
    EUINavigation_MAX                              = 8

};


// Enum  /Script/SlateCore.ECheckBoxState
enum class ECheckBoxState : uint8_t
{
    Unchecked                                      = 0,
    Checked                                        = 1,
    Undetermined                                   = 2,
    ECheckBoxState_MAX                             = 3

};


// Enum  /Script/SlateCore.EWidgetClipping
enum class EWidgetClipping : uint8_t
{
    Inherit                                        = 0,
    ClipToBounds                                   = 1,
    ClipToBoundsWithoutIntersecting                = 2,
    ClipToBoundsAlways                             = 3,
    OnDemand                                       = 4,
    EWidgetClipping_MAX                            = 5

};


// Enum  /Script/CoreUObject.EMouseCursor
enum class EMouseCursor : uint8_t
{
    None                                           = 0,
    Default                                        = 1,
    TextEditBeam                                   = 2,
    ResizeLeftRight                                = 3,
    ResizeUpDown                                   = 4,
    ResizeSouthEast                                = 5,
    ResizeSouthWest                                = 6,
    CardinalCross                                  = 7,
    Crosshairs                                     = 8,
    Hand                                           = 9,
    GrabHand                                       = 10,
    GrabHandClosed                                 = 11,
    SlashedCircle                                  = 12,
    EyeDropper                                     = 13,
    EMouseCursor_MAX                               = 14

};


// Enum  /Script/SlateCore.ESlateBrushImageType
enum class ESlateBrushImageType : uint8_t
{
    NoImage                                        = 0,
    FullColor                                      = 1,
    Linear                                         = 2,
    ESlateBrushImageType_MAX                       = 3

};


// Enum  /Script/SlateCore.ESlateBrushMirrorType
enum class ESlateBrushMirrorType : uint8_t
{
    NoMirror                                       = 0,
    Horizontal                                     = 1,
    Vertical                                       = 2,
    Both                                           = 3,
    ESlateBrushMirrorType_MAX                      = 4

};


// Enum  /Script/SlateCore.ESlateBrushTileType
enum class ESlateBrushTileType : uint8_t
{
    NoTile                                         = 0,
    Horizontal                                     = 1,
    Vertical                                       = 2,
    Both                                           = 3,
    ESlateBrushTileType_MAX                        = 4

};


// Enum  /Script/SlateCore.ESlateBrushDrawType
enum class ESlateBrushDrawType : uint8_t
{
    NoDrawType                                     = 0,
    Box                                            = 1,
    Border                                         = 2,
    Image                                          = 3,
    ESlateBrushDrawType_MAX                        = 4

};


// Enum  /Script/SlateCore.ESlateColorStylingMode
enum class ESlateColorStylingMode : uint8_t
{
    UseColor_Specified                             = 0,
    UseColor_Specified_Link                        = 1,
    UseColor_Foreground                            = 2,
    UseColor_Foreground_Subdued                    = 3,
    UseColor_MAX                                   = 4

};


// Enum  /Script/UMG.ESlateVisibility
enum class ESlateVisibility : uint8_t
{
    Visible                                        = 0,
    Collapsed                                      = 1,
    Hidden                                         = 2,
    HitTestInvisible                               = 3,
    SelfHitTestInvisible                           = 4,
    ESlateVisibility_MAX                           = 5

};


// Enum  /Script/SlateCore.EUINavigationRule
enum class EUINavigationRule : uint8_t
{
    Escape                                         = 0,
    Explicit                                       = 1,
    Wrap                                           = 2,
    Stop                                           = 3,
    Custom                                         = 4,
    CustomBoundary                                 = 5,
    Invalid                                        = 6,
    EUINavigationRule_MAX                          = 7

};


// Enum  /Script/SlateCore.EFlowDirectionPreference
enum class EFlowDirectionPreference : uint8_t
{
    Inherit                                        = 0,
    Culture                                        = 1,
    LeftToRight                                    = 2,
    RightToLeft                                    = 3,
    EFlowDirectionPreference_MAX                   = 4

};


// Enum  /Script/SlateCore.EMaskGeometryType
enum class EMaskGeometryType : uint8_t
{
    None                                           = 0,
    Rectangle                                      = 1,
    Circle                                         = 2,
    EMaskGeometryType_MAX                          = 3

};


// Enum  /Script/SlateCore.EColorVisionDeficiency
enum class EColorVisionDeficiency : uint8_t
{
    NormalVision                                   = 0,
    Deuteranope                                    = 1,
    Protanope                                      = 2,
    Tritanope                                      = 3,
    EColorVisionDeficiency_MAX                     = 4

};


// Enum  /Script/Engine.EMouseLockMode
enum class EMouseLockMode : uint8_t
{
    DoNotLock                                      = 0,
    LockOnCapture                                  = 1,
    LockAlways                                     = 2,
    LockInFullscreen                               = 3,
    EMouseLockMode_MAX                             = 4

};


// Enum  /Script/Engine.EWindowTitleBarMode
enum class EWindowTitleBarMode : uint8_t
{
    Overlay                                        = 0,
    VerticalBox                                    = 1,
    EWindowTitleBarMode_MAX                        = 2

};


// Enum  /Script/SlateCore.ESelectInfo
enum class ESelectInfo : uint8_t
{
    OnKeyPress                                     = 0,
    OnNavigation                                   = 1,
    OnMouseClick                                   = 2,
    Direct                                         = 3,
    ESelectInfo_MAX                                = 4

};


// Enum  /Script/SlateCore.ETextCommit
enum class ETextCommit : uint8_t
{
    Default                                        = 0,
    OnEnter                                        = 1,
    OnUserMovedFocus                               = 2,
    OnCleared                                      = 3,
    ETextCommit_MAX                                = 4

};


// Enum  /Script/Slate.ETextJustify
enum class ETextJustify : uint8_t
{
    Left                                           = 0,
    Center                                         = 1,
    Right                                          = 2,
    ETextJustify_MAX                               = 3

};


// Enum  /Script/Slate.ETextFlowDirection
enum class ETextFlowDirection : uint8_t
{
    Auto                                           = 0,
    LeftToRight                                    = 1,
    RightToLeft                                    = 2,
    ETextFlowDirection_MAX                         = 3

};


// Enum  /Script/SlateCore.ETextShapingMethod
enum class ETextShapingMethod : uint8_t
{
    Auto                                           = 0,
    KerningOnly                                    = 1,
    FullShaping                                    = 2,
    ETextShapingMethod_MAX                         = 3

};


// Enum  /Script/Slate.EVirtualKeyboardDismissAction
enum class EVirtualKeyboardDismissAction : uint8_t
{
    TextChangeOnDismiss                            = 0,
    TextCommitOnAccept                             = 1,
    TextCommitOnDismiss                            = 2,
    EVirtualKeyboardDismissAction_MAX              = 3

};


// Enum  /Script/Slate.EVirtualKeyboardTrigger
enum class EVirtualKeyboardTrigger : uint8_t
{
    OnFocusByPointer                               = 0,
    OnAllFocusEvents                               = 1,
    EVirtualKeyboardTrigger_MAX                    = 2

};


// Enum  /Script/UMG.EVirtualKeyboardType
enum class EVirtualKeyboardType : uint8_t
{
    Default                                        = 0,
    Number                                         = 1,
    Web                                            = 2,
    Email                                          = 3,
    Password                                       = 4,
    AlphaNumeric                                   = 5,
    EVirtualKeyboardType_MAX                       = 6

};


// Enum  /Script/SlateCore.EMenuPlacement
enum class EMenuPlacement : uint8_t
{
    MenuPlacement_BelowAnchor                      = 0,
    MenuPlacement_CenteredBelowAnchor              = 1,
    MenuPlacement_BelowRightAnchor                 = 2,
    MenuPlacement_ComboBox                         = 3,
    MenuPlacement_ComboBoxRight                    = 4,
    MenuPlacement_MenuRight                        = 5,
    MenuPlacement_AboveAnchor                      = 6,
    MenuPlacement_CenteredAboveAnchor              = 7,
    MenuPlacement_AboveRightAnchor                 = 8,
    MenuPlacement_MenuLeft                         = 9,
    MenuPlacement_Center                           = 10,
    MenuPlacement_RightLeftCenter                  = 11,
    MenuPlacement_MatchBottomLeft                  = 12,
    MenuPlacement_MAX                              = 13

};


// Enum  /Script/Slate.ETextWrappingPolicy
enum class ETextWrappingPolicy : uint8_t
{
    DefaultWrapping                                = 0,
    AllowPerCharacterWrapping                      = 1,
    ETextWrappingPolicy_MAX                        = 2

};


// Enum  /Script/GMTool.EDateTimeDisplayMode
enum class EDateTimeDisplayMode : uint8_t
{
    DateOnly                                       = 0,
    TimeOnly                                       = 1,
    DateAndTime                                    = 2,
    EDateTimeDisplayMode_MAX                       = 3

};


// Enum  /Script/GMTool.EInputFieldType
enum class EInputFieldType : uint8_t
{
    None                                           = 0,
    Text                                           = 1,
    Integer                                        = 2,
    Float                                          = 3,
    DateTime                                       = 4,
    Dropdown                                       = 5,
    Boolean                                        = 6,
    CharDropdown                                   = 7,
    EInputFieldType_MAX                            = 8

};


// Enum  /Script/SlateCore.ESlateCheckBoxType
enum class ESlateCheckBoxType : uint8_t
{
    CheckBox                                       = 0,
    ToggleButton                                   = 1,
    ESlateCheckBoxType_MAX                         = 2

};


// Enum  /Script/KawaiiPhysics.EBoneConstrainType
enum class EBoneConstrainType : uint8_t
{
    PositiontConstraint                            = 0,
    OrientConstraint                               = 1,
    RotationConstraint                             = 2,
    EBoneConstrainType_MAX                         = 3

};


// Enum  /Script/KawaiiPhysics.ECollisionLimitType
enum class ECollisionLimitType : uint8_t
{
    None                                           = 0,
    Spherical                                      = 1,
    Capsule                                        = 2,
    Planar                                         = 3,
    ECollisionLimitType_MAX                        = 4

};


// Enum  /Script/KawaiiPhysics.EBoneForwardAxis
enum class EBoneForwardAxis : uint8_t
{
    X_Positive                                     = 0,
    X_Negative                                     = 1,
    Y_Positive                                     = 2,
    Y_Negative                                     = 3,
    Z_Positive                                     = 4,
    Z_Negative                                     = 5,
    EBoneForwardAxis_MAX                           = 6

};


// Enum  /Script/KawaiiPhysics.EPlanarConstraint
enum class EPlanarConstraint : uint8_t
{
    None                                           = 0,
    X                                              = 1,
    Y                                              = 2,
    Z                                              = 3,
    EPlanarConstraint_MAX                          = 4

};


// Enum  /Script/VariantManagerContent.EPropertyValueCategory
enum class EPropertyValueCategory : uint8_t
{
    Undefined                                      = 0,
    Generic                                        = 1,
    RelativeLocation                               = 2,
    RelativeRotation                               = 4,
    RelativeScale3D                                = 8,
    Visibility                                     = 16,
    Material                                       = 32,
    Color                                          = 64,
    Option                                         = 128,
    EPropertyValueCategory_MAX                     = 129

};


// Enum  /Script/MaterialBenchmark.EExecType
enum class EExecType : uint8_t
{
    EET_PerBooth                                   = 0,
    EET_AllBooths                                  = 1,
    EET_UseDynamicBooth                            = 2,
    EET_Num                                        = 3,
    EET_MAX                                        = 4

};


// Enum  /Script/MFDataVisualizer.EFoliageCollectType
enum class EFoliageCollectType : uint8_t
{
    E_FoliageCount                                 = 0,
    E_FaceCount                                    = 1,
    E_TypeCount                                    = 2,
    E_MAX                                          = 3

};


// Enum  /Script/MFDataVisualizer.ERenderObjType
enum class ERenderObjType : uint8_t
{
    E_PrimitiveCount                               = 0,
    E_FaceCount                                    = 1,
    E_InstrucmentCount                             = 2,
    E_MAX                                          = 3

};


// Enum  /Script/Paper2D.EFlipbookCollisionMode
enum class EFlipbookCollisionMode : uint8_t
{
    NoCollision                                    = 0,
    FirstFrameCollision                            = 1,
    EachFrameCollision                             = 2,
    EFlipbookCollisionMode_MAX                     = 3

};


// Enum  /Script/Paper2D.EPaperSpriteAtlasPadding
enum class EPaperSpriteAtlasPadding : uint8_t
{
    DilateBorder                                   = 0,
    PadWithZero                                    = 1,
    EPaperSpriteAtlasPadding_MAX                   = 2

};


// Enum  /Script/Paper2D.ETileMapProjectionMode
enum class ETileMapProjectionMode : uint8_t
{
    Orthogonal                                     = 0,
    IsometricDiamond                               = 1,
    IsometricStaggered                             = 2,
    HexagonalStaggered                             = 3,
    ETileMapProjectionMode_MAX                     = 4

};


// Enum  /Script/Paper2D.ESpritePivotMode
enum class ESpritePivotMode : uint8_t
{
    Top_Left                                       = 0,
    Top_Center                                     = 1,
    Top_Right                                      = 2,
    Center_Left                                    = 3,
    Center_Center                                  = 4,
    Center_Right                                   = 5,
    Bottom_Left                                    = 6,
    Bottom_Center                                  = 7,
    Bottom_Right                                   = 8,
    Custom                                         = 9,
    ESpritePivotMode_MAX                           = 10

};


// Enum  /Script/Paper2D.ESpritePolygonMode
enum class ESpritePolygonMode : uint8_t
{
    SourceBoundingBox                              = 0,
    TightBoundingBox                               = 1,
    ShrinkWrapped                                  = 2,
    FullyCustom                                    = 3,
    Diced                                          = 4,
    ESpritePolygonMode_MAX                         = 5

};


// Enum  /Script/Paper2D.ESpriteShapeType
enum class ESpriteShapeType : uint8_t
{
    Box                                            = 0,
    Circle                                         = 1,
    Polygon                                        = 2,
    ESpriteShapeType_MAX                           = 3

};


// Enum  /Script/Paper2D.ESpriteCollisionMode
enum class ESpriteCollisionMode : uint8_t
{
    None                                           = 0,
    Use2DPhysics                                   = 1,
    Use3DPhysics                                   = 2,
    ESpriteCollisionMode_MAX                       = 3

};


// Enum  /Script/MFClimateRuntime.EMFClimateCelestialOrbitType
enum class EMFClimateCelestialOrbitType : uint8_t
{
    Sun                                            = 0,
    SunCounter                                     = 1,
    Satellite                                      = 2,
    Distant                                        = 3,
    Manual                                         = 4,
    EMFClimateCelestialOrbitType_MAX               = 5

};


// Enum  /Script/MFClimateRuntime.EMFClimateCloudNoiseGroupTier
enum class EMFClimateCloudNoiseGroupTier : uint8_t
{
    Desktop                                        = 0,
    Mobile                                         = 1,
    EMFClimateCloudNoiseGroupTier_MAX              = 2

};


// Enum  /Script/MFClimateRuntime.EMFClimateNoiseType
enum class EMFClimateNoiseType : uint8_t
{
    PerlinWorley                                   = 0,
    WorleyCloud                                    = 1,
    NRCCloud                                       = 2,
    EMFClimateNoiseType_MAX                        = 3

};


// Enum  /Script/MFClimateRuntime.EMFClimateRainWeatherType
enum class EMFClimateRainWeatherType : uint8_t
{
    Rain                                           = 0,
    Snow                                           = 1,
    Sand                                           = 2,
    Num                                            = 3,
    EMFClimateRainWeatherType_MAX                  = 4

};


// Enum  /Script/MFClimateRuntime.EMFClimateTickBudgetAdvice
enum class EMFClimateTickBudgetAdvice : uint8_t
{
    DontTick                                       = 0,
    Tick                                           = 1,
    FullUpdate                                     = 2,
    EMFClimateTickBudgetAdvice_MAX                 = 3

};


// Enum  /Script/MFClimateRuntime.EWeatherLayerEvaluationMode
enum class EWeatherLayerEvaluationMode : uint8_t
{
    TimeOfDay                                      = 0,
    SunAngle                                       = 1,
    Constant                                       = 2,
    NUM_EVALUATION_MODE                            = 3,
    EWeatherLayerEvaluationMode_MAX                = 4

};


// Enum  /Script/MFClimateRuntime.EMFClimateCloudMaskType
enum class EMFClimateCloudMaskType : uint8_t
{
    Normal                                         = 0,
    FullCover                                      = 1,
    EMFClimateCloudMaskType_MAX                    = 2

};


// Enum  /Script/MFClimateRuntime.EMFClimateGetFeatureErrorMode
enum class EMFClimateGetFeatureErrorMode : uint8_t
{
    ReturnNull                                     = 0,
    LogAndReturnNull                               = 1,
    Assert                                         = 2,
    EMFClimateGetFeatureErrorMode_MAX              = 3

};


// Enum  /Script/MFEnvironment.EEnvActorType
enum class EEnvActorType : uint8_t
{
    EnvActorType_Water                             = 0,
    EnvActorType_Capsule                           = 1,
    EnvActorType_Mud                               = 2,
    EnvActorType_AutoExposure                      = 3,
    EnvActorType_MAX                               = 4

};


// Enum  /Script/MFEnvironment.EMFPhysFoliageMeshTypeEnum
enum class EMFPhysFoliageMeshTypeEnum : uint8_t
{
    SkeletalMesh                                   = 0,
    StaticMesh                                     = 1,
    EditableMesh                                   = 2,
    EMFPhysFoliageMeshTypeEnum_MAX                 = 3

};


// Enum  /Script/MFEnvironment.EMFEnvTrailShapeEnum
enum class EMFEnvTrailShapeEnum : uint8_t
{
    None                                           = 0,
    Circle                                         = 1,
    Triangle                                       = 2,
    EMFEnvTrailShapeEnum_MAX                       = 3

};


// Enum  /Script/SGFramework.EAttachPosition
enum class EAttachPosition : uint8_t
{
    Attach_Default                                 = 0,
    Attach_Primary                                 = 1,
    Attach_Secondary                               = 2,
    Attach_Pistol                                  = 3,
    Attach_Melee                                   = 4,
    Attach_Throwable                               = 5,
    Attach_Helmet                                  = 6,
    Attach_Vest                                    = 7,
    Attach_Bag                                     = 8,
    Attach_BagIcon                                 = 9,
    Attach_VestBag                                 = 10,
    Attach_VestBagIcon                             = 11,
    Attach_OwnerWeapon                             = 16,
    Attach_Headset                                 = 18,
    Attach_FaceCover                               = 19,
    Attach_EyeWear                                 = 20,
    Attach_PocketIcon                              = 21,
    Attach_SafeBoxIcon                             = 22,
    Attach_Pocket                                  = 23,
    Attach_SafeBox                                 = 24,
    Attach_ArmBand                                 = 25,
    Attach_DogTag                                  = 26,
    Attach_KeyContainerIcon                        = 27,
    Attach_KeyContainer                            = 28,
    Attach_Avatar                                  = 29,
    Attach_MultilayerContainer                     = 30,
    Attach_VehicleKey                              = 31,
    Attach_KeyCabinet                              = 32,
    Attach_Special                                 = 33,
    Attach_Virtual                                 = 34,
    Attach_Staging                                 = 35,
    Attach_VirtualBag                              = 36,
    Attach_VirtualBagIcon                          = 37,
    Attach_AutoPocket                              = 50,
    Attach_AutoVestBag                             = 51,
    Attach_AutoBag                                 = 52,
    Attach_NoOwner                                 = 98,
    Attach_Auto                                    = 99,
    Attach_MAX                                     = 100

};


// Enum  /Script/SGFramework.EInventoryContainerOccupyState
enum class EInventoryContainerOccupyState : uint8_t
{
    None                                           = 0,
    Full                                           = 1,
    HalfFull                                       = 2,
    Empty                                          = 3,
    EInventoryContainerOccupyState_MAX             = 4

};


// Enum  /Script/SGFramework.ESGInnerWeaponEvent
enum class ESGInnerWeaponEvent : uint8_t
{
    EInnerEvent_None                               = 0,
    EStateEvent_SwitchToIdle                       = 1,
    EStateEvent_BeginEquip                         = 2,
    EStateEvent_BeginEquipEnd                      = 3,
    EStateEvent_EndEquip                           = 4,
    EStateEvent_EndUnEquip                         = 5,
    EStateEvent_BeginEquipWithCharge               = 6,
    EStateEvent_PreFire                            = 7,
    EStateEvent_BeginKeepPreFire                   = 8,
    EStateEvent_EndKeepPreFire                     = 9,
    EStateEvent_TimeoutAutoFire                    = 10,
    EStateEvent_CancelFire                         = 11,
    EStateEvent_BeginFire                          = 12,
    EStateEvent_EndFire                            = 13,
    EStateEvent_BeginJumpFire                      = 14,
    EStateEvent_BeginKeepFire                      = 15,
    EStateEvent_EndKeepFire                        = 16,
    EStateEvent_FinalEndFire                       = 17,
    EStateEvent_BeginChangeClip                    = 18,
    EStateEvent_OpenBlotBeforeReloading            = 19,
    EStateEvent_CloseBlotBeforeReloading           = 20,
    EStateEvent_ChangeClip_HoldMagazineOnHand      = 21,
    EStateEvent_ChangeClip_GetNewMagazineOnHand    = 22,
    EStateEvent_ChangeClip_AttachNewMagazineToWeapon = 23,
    EStateEvent_EndChangeClip                      = 24,
    EStateEvent_ChangeClip_OneByOne_Begin          = 25,
    EStateEvent_ChangeClip_OneByOne_BeginWithAmmoIn = 26,
    EStateEvent_ChangeClip_CloseBolt               = 27,
    EStateEvent_ChangeClip_OneByOne_LoopBegin      = 28,
    EStateEvent_ChangeClip_OneByOne_LoopEnd        = 29,
    EStateEvent_ChangeClip_OneByOne_End            = 30,
    EStateEvent_AbortChangeClip                    = 31,
    EStateEvent_SwitchToInactive                   = 32,
    EStateEvent_BeginInteraction                   = 33,
    EStateEvent_EndInteraction                     = 34,
    EStateEvent_EmptyClip                          = 35,
    EStateEvent_InstantHit                         = 36,
    EStateEvent_Kill                               = 37,
    EStateEvent_EndPullBolt                        = 38,
    EStateEvent_StartPullBolt                      = 39,
    EStateEvent_HammerCharged                      = 40,
    EStateEvent_TriggerOnHangup                    = 41,
    EStateEvent_TriggerWithChamber                 = 42,
    EStateEvent_TriggerWithChamberOpenBolt         = 43,
    EStateEvent_TriggerWithNoChamber               = 44,
    EStateEvent_StartHolding                       = 45,
    EStateEvent_EndHolding                         = 46,
    EStateEvent_FastReload_Begin                   = 47,
    EStateEvent_FastReload_HoldMagzine             = 48,
    EStateEvent_FastReload_DettachMagazine         = 49,
    EStateEvent_FastReload_AttachMagazine          = 50,
    EStateEvent_BeginTacticalReload                = 51,
    EStateEvent_TacticalReload_HoldMagazineOnHand  = 52,
    EStateEvent_TacticalReload_GetNewMagazineOnHand = 53,
    EStateEvent_TacticalReload_AttachNewMagazineToWeapon = 54,
    EStateEvent_EndTacticalReload                  = 55,
    EStateEvent_BeginCheckWeapon                   = 56,
    EStateEvent_EndCheckWeapon                     = 57,
    EStateEvent_BeginCheckBore                     = 58,
    EStateEvent_BeginCheckBoreWithRemoveMag        = 59,
    EStateEvent_EndCheckBore                       = 60,
    EStateEvent_BeginCheckFireMode                 = 61,
    EStateEvent_EndCheckFireMode                   = 62,
    EStateEvent_BeginCheckMagazine                 = 63,
    EStateEvent_EndCheckMagazine                   = 64,
    EStateEvent_UnloadMagazine                     = 65,
    EStateEvent_LoadMagazine                       = 66,
    EStateEvent_BeginHoldOpen                      = 67,
    EStateEvent_ReleaseHoldOpen                    = 68,
    EStateEvent_AmmoInBeginInHoldOpen              = 69,
    EStateEvent_AmmoInBegin                        = 70,
    EStateEvent_AmmoIn                             = 71,
    EStateEvent_AmmoOutBegin                       = 72,
    EStateEvent_AmmoOutBeginInHoldOpen             = 73,
    EStateEvent_AmmoOut                            = 74,
    EStateEvent_SwitchFireMode0                    = 75,
    EStateEvent_SwitchFireMode1                    = 76,
    EStateEvent_SwitchFireMode2                    = 77,
    EStateEvent_SwitchFireModeEnd                  = 78,
    EStateEvent_BeginSetupMod                      = 79,
    EStateEvent_EndSetupMod                        = 80,
    EStateEvent_BagOpen                            = 81,
    EStateEvent_BeginBagOpen                       = 82,
    EStateEvent_EndBagOpen                         = 83,
    EStateEvent_EndPreFire                         = 84,
    EStateEvent_FastThrowPreFire                   = 85,
    EStateEvent_FastThrowBeginFire                 = 86,
    EInnerEvent_Max                                = 87,
    ESGInnerWeaponEvent_MAX                        = 88

};


// Enum  /Script/SGFramework.FWeaponMergeMode
enum class FWeaponMergeMode : uint8_t
{
    WeaponMerge_None                               = 0,
    WeaponMerge_Simple                             = 1,
    WeaponMerge_Full                               = 2,
    WeaponMerge_MAX                                = 3

};


// Enum  /Script/SGFramework.ESGActionAbilityType
enum class ESGActionAbilityType : uint8_t
{
    ESGActionAbilityType_Aim                       = 0,
    ESGActionAbilityType_Fire                      = 1,
    ESGActionAbilityType_SwitchWeapon              = 2,
    ESGActionAbilityType_Reload                    = 3,
    ESGActionAbilityType_ReloadBores               = 4,
    ESGActionAbilityType_ReloadOneByOne            = 5,
    ESGActionAbilityType_SwitchFireMode            = 6,
    ESGActionAbilityType_CheckMagazine             = 7,
    ESGActionAbilityType_PullBolt                  = 8,
    ESGActionAbilityType_ReleaseHoldOpen           = 9,
    ESGActionAbilityType_ThrowWeapon               = 10,
    ESGActionAbilityType_HoldOpen                  = 11,
    ESGActionAbilityType_OpenBag                   = 12,
    ESGActionAbilityType_InteractWithDoor          = 13,
    ESGActionAbilityType_MeleeFire                 = 14,
    ESGActionAbilityType_PickUp                    = 15,
    ESGActionAbilityType_Loot                      = 16,
    ESGActionAbilityType_ReloadOnHang              = 17,
    ESGActionAbilityType_ReloadOneByOneOnHang      = 18,
    ESGActionAbilityType_Rescue                    = 19,
    ESGActionAbilityType_FillMagazine              = 20,
    ESGActionAbilityType_UnfillMagazine            = 21,
    ESGActionAbilityType_EmptyTrigger              = 22,
    ESGActionAbilityType_SetupAdapter              = 23,
    ESGActionAbilityType_TurnInPlace               = 24,
    ESGActionAbilityType_SetBipod                  = 25,
    ESGActionAbilityType_ToggleHeadwear            = 26,
    ESGActionAbilityType_LowReady                  = 27,
    ESGActionAbilityType_RollUpBag                 = 28,
    ESGActionAbilityType_FoldStock                 = 29,
    ESGActionAbilityType_CloseBolt                 = 30,
    ESGActionAbilityType_ReloadBoresOnHang         = 31,
    ESGActionAbilityType_InteractWithActor         = 32,
    ESGActionAbilityType_ViewWeapon                = 33,
    ESGActionAbilityType_Gesture                   = 34,
    ESGActionAbilityType_GestureTwoHand            = 35,
    ESGActionAbilityType_GestureFullBody           = 36,
    ESGActionAbilityType_ClimbLadder               = 37,
    ESGActionAbilityType_BoresPump                 = 38,
    ESGActionAbilityType_MoveBlockAvoidance        = 39,
    ESGActionAbilityType_FoldScope                 = 40,
    ESGActionAbilityType_HandLUseItem              = 41,
    ESGActionAbilityType_WeaponRepair              = 42,
    ESGActionAbilityType_PreviewPlace              = 43,
    ESGActionAbilityType_DeliverCargo              = 44,
    ESGActionAbilityType_RescueSelf                = 45,
    ESGActionAbilityType_Spray                     = 46,
    ESGActionAbilityType_TacticalPistol            = 47,
    ESGActionAbilityType_HostedInteract            = 48,
    ESGActionAbilityType_InteractDoubleHands       = 49,
    ESGActionAbilityType_EmplacingGun              = 50,
    ESGActionAbilityType_PlaceObject               = 51,
    ESGActionAbilityType_ThrowItem                 = 52,
    ESGActionAbilityType_MoveInventory             = 53,
    ESGActionAbilityType_ControlTacticalProps      = 54,
    ESGActionAbilityType_ZiplineMove               = 55,
    ESGActionAbilityType_Photograph                = 56,
    ESGActionAbilityType_TacticalDetector          = 57,
    ESGActionAbilityType_ViewGold                  = 58,
    ESGActionAbilityType_UseSkill                  = 59,
    ESGActionAbilityType_ClearUp                   = 60,
    ESGActionAbilityType_Dive                      = 61,
    ESGActionAbilityType_Slide                     = 62,
    ESGActionAbilityType_Radar                     = 63,
    ESGActionAbilityType_Max                       = 64

};


// Enum  /Script/SGFramework.ESGWeaponLODPolicy
enum class ESGWeaponLODPolicy : uint8_t
{
    ESGWeaponLODPolicy_None                        = 0,
    ESGWeaponLODPolicy_1P                          = 1,
    ESGWeaponLODPolicy_LOD0                        = 2,
    ESGWeaponLODPolicy_LOD1                        = 3,
    ESGWeaponLODPolicy_LOD2                        = 4,
    ESGWeaponLODPolicy_LOD3                        = 5,
    ESGWeaponLODPolicy_MAX                         = 6

};


// Enum  /Script/SGFramework.EContainerIteractAnimState
enum class EContainerIteractAnimState : uint8_t
{
    Closed                                         = 0,
    Opening                                        = 1,
    Opened                                         = 2,
    Closing                                        = 3,
    EContainerIteractAnimState_MAX                 = 4

};


// Enum  /Script/Engine.EInputEvent
enum class EInputEvent : uint8_t
{
    IE_Pressed                                     = 0,
    IE_Released                                    = 1,
    IE_Repeat                                      = 2,
    IE_DoubleClick                                 = 3,
    IE_Axis                                        = 4,
    IE_MAX                                         = 5

};


// Enum  /Script/SGFramework.ECharacterEnduranceType
enum class ECharacterEnduranceType : uint8_t
{
    Head                                           = 0,
    Chest                                          = 1,
    Stomach                                        = 2,
    LeftArm                                        = 3,
    RightArm                                       = 4,
    LeftLeg                                        = 5,
    RightLeg                                       = 6,
    Max                                            = 7,
    Max_Space                                      = 8

};


// Enum  /Script/SGFramework.ECharacterHealthConditionType
enum class ECharacterHealthConditionType : uint8_t
{
    Normal                                         = 0,
    Injured                                        = 1,
    NearlyDying                                    = 2,
    Dying                                          = 3,
    ECharacterHealthConditionType_MAX              = 4

};


// Enum  /Script/SGFramework.ESGZoomType
enum class ESGZoomType : uint8_t
{
    ESGZoomType_None                               = 0,
    ESGZoomType_WeaponZooming                      = 1,
    ESGZoomType_ShoulderZooming                    = 2,
    ESGZoomType_MAX                                = 3

};


// Enum  /Script/SGFramework.EChestHitSubGroupType
enum class EChestHitSubGroupType : uint8_t
{
    ChestHitSubGroupType_None                      = 0,
    ChestHitSubGroupType_LeftUpperChest            = 1,
    ChestHitSubGroupType_RightUpperChest           = 2,
    ChestHitSubGroupType_MAX                       = 3

};


// Enum  /Script/SGFramework.EHeadHitSubGroupType
enum class EHeadHitSubGroupType : uint8_t
{
    HeadHitSubGroupType_None                       = 0,
    HeadHitSubGroupType_TopHead                    = 1,
    HeadHitSubGroupType_Eye                        = 2,
    HeadHitSubGroupType_Ear                        = 3,
    HeadHitSubGroupType_Face                       = 4,
    HeadHitSubGroupType_Chin                       = 5,
    HeadHitSubGroupType_Neck                       = 6,
    HeadHitSubGroupType_BackNeck                   = 7,
    HeadHitSubGroupType_LeftEar                    = 8,
    HeadHitSubGroupType_RightEar                   = 9,
    HeadHitSubGroupType_MAX                        = 10

};


// Enum  /Script/SGFramework.EHitGroupType
enum class EHitGroupType : uint8_t
{
    HitGroupType_None                              = 0,
    HitGroupType_Head                              = 1,
    HitGroupType_Neck                              = 2,
    HitGroupType_LeftShoulder                      = 3,
    HitGroupType_RightShoulder                     = 4,
    HitGroupType_ChestFront                        = 5,
    HitGroupType_ChestBack                         = 6,
    HitGroupType_WaistFront                        = 7,
    HitGroupType_WaistBack                         = 8,
    HitGroupType_Hip                               = 9,
    HitGroupType_LeftLeg                           = 10,
    HitGroupType_LeftLegLower                      = 11,
    HitGroupType_LeftFoot                          = 12,
    HitGroupType_RightLeg                          = 13,
    HitGroupType_RightLegLower                     = 14,
    HitGroupType_RightFoot                         = 15,
    HitGroupType_LeftArm                           = 16,
    HitGroupType_LeftForeArm                       = 17,
    HitGroupType_LeftHand                          = 18,
    HitGroupType_RightArm                          = 19,
    HitGroupType_RightForeArm                      = 20,
    HitGroupType_RightHand                         = 21,
    HitGroupType_MAX                               = 22

};


// Enum  /Script/SGFramework.EDamageTypeEnum
enum class EDamageTypeEnum : uint8_t
{
    EDamageType_None                               = 0,
    EDamageType_GunWeapon                          = 1,
    EDamageType_MeleeWeapon                        = 2,
    EDamageType_ThrowingWeapon                     = 3,
    EDamageType_Trap                               = 4,
    EDamageType_Falling                            = 5,
    EDamageType_BoneBreakRun                       = 6,
    EDamageType_SpecialForDBNO                     = 7,
    EDamageType_BoneBreakLanded                    = 8,
    EDamageType_VehicleHited                       = 9,
    EDamageType_VehicleCollision                   = 10,
    EDamageType_Signal                             = 11,
    EDamageType_Poison                             = 12,
    EDamageType_MAX                                = 13

};


// Enum  /Script/SGFramework.ESGDamageCauserType
enum class ESGDamageCauserType : uint8_t
{
    ESGDamageCauserType_None                       = 0,
    ESGDamageCauserType_GunWeapon                  = 1,
    ESGDamageCauserType_MeleeWeapon                = 2,
    ESGDamageCauserType_ThrowingWeapon             = 3,
    ESGDamageCauserType_ThrowingWeaponBurn         = 4,
    ESGDamageCauserType_OtherWeapon                = 5,
    ESGDamageCauserType_Trap                       = 6,
    ESGDamageCauserType_Bleed                      = 7,
    ESGDamageCauserType_Burn                       = 8,
    ESGDamageCauserType_LackInFood                 = 9,
    ESGDamageCauserType_LackInMoisture             = 10,
    ESGDamageCauserType_BoneBreakRun               = 11,
    ESGDamageCauserType_Poison                     = 12,
    ESGDamageCauserType_TripMine                   = 13,
    ESGDamageCauserType_Vehicle                    = 14,
    ESGDamageCauserType_SignalValue                = 15,
    ESGDamageCauserType_RocketWreckage             = 16,
    ESGDamageCauserType_TearGas                    = 17,
    ESGDamageCauserType_BodyBurn                   = 18,
    ESGDamageCauserType_MAX                        = 19

};


// Enum  /Script/SGFramework.ECharacterDeathType
enum class ECharacterDeathType : uint8_t
{
    ECharacterDeathType_None                       = 0,
    ECharacterDeathType_Bullet                     = 1,
    ECharacterDeathType_BulletSpread               = 2,
    ECharacterDeathType_MeleeWeapon                = 3,
    ECharacterDeathType_MeleeWeaponSpread          = 4,
    ECharacterDeathType_ThrownWeapon               = 5,
    ECharacterDeathType_PetrolBomb                 = 6,
    ECharacterDeathType_Fall                       = 7,
    ECharacterDeathType_Environment                = 8,
    ECharacterDeathType_Debuff                     = 9,
    ECharacterDeathType_Drug                       = 10,
    ECharacterDeathType_TripMine                   = 11,
    ECharacterDeathType_StealHeadWhenDBNO          = 12,
    ECharacterDeathType_VehicleHit                 = 13,
    ECharacterDeathType_VehicleHitSpread           = 14,
    ECharacterDeathType_VehicleCollision           = 15,
    ECharacterDeathType_VehicleCollisionSpread     = 16,
    ECharacterDeathType_VehicleExplosion           = 17,
    ECharacterDeathType_VehicleExplosionSpread     = 18,
    ECharacterDeathType_SignalValue                = 19,
    ECharacterDeathType_RocketWreckage             = 20,
    ECharacterDeathType_MAX                        = 21

};


// Enum  /Script/SGFramework.EFactionType
enum class EFactionType : uint8_t
{
    None                                           = 0,
    NormalPMC                                      = 1,
    NormalScav                                     = 2,
    PlayerScav                                     = 3,
    RebelFaction                                   = 4,
    LakeFaction                                    = 5,
    GangsterFaction                                = 6,
    KurtTeam                                       = 7,
    NavyFaction                                    = 8,
    Blackgold                                      = 9,
    Gnesk                                          = 10,
    MadDog                                         = 11,
    RoleplayA                                      = 12,
    RoleplayB                                      = 13,
    Cleaner                                        = 14,
    Kamona                                         = 15,
    NUM_FactionType_MAX                            = 16,
    EFactionType_MAX                               = 17

};


// Enum  /Script/SGFramework.ECharacterType
enum class ECharacterType : uint8_t
{
    ECharacterType_None                            = 0,
    ECharacterType_PMC                             = 1,
    ECharacterType_SCAV                            = 2,
    ECharacterType_AI_SCAV                         = 3,
    ECharacterType_AI_SCAV_BOSS                    = 4,
    ECharacterType_AI_PMC                          = 5,
    ECharacterType_AI_ELIT                         = 6,
    ECharacterType_BOSS                            = 7,
    ECharacterType_AI_SCAV_Follower                = 8,
    ECharacterType_AI_Animal                       = 9,
    ECharacterType_MAX                             = 10

};


// Enum  /Script/SGFramework.EPlayerPoseType
enum class EPlayerPoseType : uint8_t
{
    PoseType_None                                  = 0,
    PoseType_Stand                                 = 1,
    PoseType_Crouch                                = 2,
    PoseType_Prone                                 = 3,
    PoseType_LeanLeft                              = 4,
    PoseType_LeanRight                             = 5,
    PoseType_DBNO                                  = 6,
    PoseType_Vehicle                               = 7,
    PoseType_Dive                                  = 8,
    PoseType_Slide                                 = 9,
    PoseType_Max                                   = 10

};


// Enum  /Script/SGFramework.EWeaponLeanAimType
enum class EWeaponLeanAimType : uint8_t
{
    EWeapLeanAimType_Center                        = 0,
    EWeapLeanAimType_Left                          = 1,
    EWeapLeanAimType_Right                         = 2,
    EWeapLeanAimType_MAX                           = 3

};


// Enum  /Script/SGFramework.ESlotEnum
enum class ESlotEnum : uint8_t
{
    SE_Inspect                                     = 0,
    SE_Use                                         = 1,
    SE_Discard                                     = 2,
    SE_MAX                                         = 3

};


// Enum  /Script/SGFramework.EPlayerEndGameType
enum class EPlayerEndGameType : uint8_t
{
    EPlayerEndGameType_None                        = 0,
    EPlayerEndGameType_Escaped                     = 1,
    EPlayerEndGameType_Died                        = 2,
    EPlayerEndGameType_MIA                         = 3,
    EPlayerEndGameType_Quit                        = 4,
    EPlayerEndGameType_NoReenter                   = 5,
    EPlayerEndGameType_HurriedlyEscaped            = 6,
    EPlayerEndGameType_Victory                     = 7,
    EPlayerEndGameType_Failed                      = 8,
    EPlayerEndGameType_RoundQuit                   = 9,
    EPlayerEndGameType_WaitRevive                  = 10,
    EPlayerEndGameType_MAX                         = 11

};


// Enum  /Script/SGFramework.EDoorAction
enum class EDoorAction : uint8_t
{
    NONE                                           = 0,
    WRECK                                          = 1,
    UNLOCK                                         = 2,
    PUSH                                           = 3,
    PULL                                           = 4,
    WRECK_FAIL                                     = 5,
    UNLOCK_CARD                                    = 6,
    INSTALL_BOMB                                   = 7,
    REPAIR_BOMB                                    = 8,
    EXPLOSION_FIRST_OPEN                           = 9,
    EDoorAction_MAX                                = 10

};


// Enum  /Script/SGFramework.ESGRecoveryAttributeType
enum class ESGRecoveryAttributeType : uint8_t
{
    Endurence                                      = 0,
    Food                                           = 1,
    Moisture                                       = 2,
    ESGRecoveryAttributeType_MAX                   = 3

};


// Enum  /Script/SGFramework.EWeaponEquipPosition
enum class EWeaponEquipPosition : uint8_t
{
    EWeaponEquipPosition_None                      = 0,
    EWeaponEquipPosition_OnBack                    = 1,
    EWeaponEquipPosition_InHand                    = 2,
    EWeaponEquipPosition_InLeftHand                = 3,
    EWeaponEquipPosition_MAX                       = 4

};


// Enum  /Script/SGFramework.ECharacterGameEffectType
enum class ECharacterGameEffectType : uint8_t
{
    Clear                                          = 0,
    Regeneration                                   = 1,
    Excited                                        = 2,
    Fortitude                                      = 3,
    HearingEnhance                                 = 4,
    OutOfEndurance                                 = 5,
    Bleed                                          = 6,
    LackInMoisture                                 = 7,
    LackInFoodSlight                               = 8,
    LackInFoodMedium                               = 9,
    LackInFood                                     = 10,
    Pain                                           = 11,
    Tinnitus                                       = 12,
    HearingReduce                                  = 13,
    IsCompleteOverWeight                           = 14,
    IsOverWeight                                   = 15,
    ActivityMark                                   = 16,
    ActivityBeMarked                               = 17,
    BoneBreak                                      = 18,
    TunnelVision                                   = 19,
    Tremble                                        = 20,
    FreshWound                                     = 21,
    PainInhibite                                   = 22,
    Trap                                           = 23,
    Poison                                         = 24,
    SlightTearGas                                  = 25,
    MediumTearGas                                  = 26,
    InhibiteTearGas                                = 27,
    Burning                                        = 28,
    Hiccup                                         = 29,
    Fart                                           = 30,
    OneByOneRegeneration                           = 31,
    MaxIncrease                                    = 32,
    SpreadDamageDecrease                           = 33,
    Adrenaline                                     = 34,
    Invulnerable                                   = 35,
    Max                                            = 36

};


// Enum  /Script/SGFramework.ECharacterDebuffType
enum class ECharacterDebuffType : uint8_t
{
    Bleed                                          = 0,
    BoneBreak                                      = 1,
    OutOfEndurance                                 = 2,
    Pain                                           = 3,
    Max                                            = 4

};


// Enum  /Script/Engine.ENetRole
enum class ENetRole : uint8_t
{
    ROLE_None                                      = 0,
    ROLE_SimulatedProxy                            = 1,
    ROLE_AutonomousProxy                           = 2,
    ROLE_Authority                                 = 3,
    ROLE_MAX                                       = 4

};


// Enum  /Script/SGFramework.EInventoryLockType
enum class EInventoryLockType : uint8_t
{
    Selecting_Lock                                 = 0,
    Useing_Lock                                    = 1,
    Adapter_Armor_Lock                             = 2,
    Adapter_Lock                                   = 3,
    Reload_Lock                                    = 4,
    FillContainer_Lock                             = 5,
    UnFillContainer_Lock                           = 6,
    EInventoryLockType_MAX                         = 7

};


// Enum  /Script/SGFramework.ESGThermalImagerType
enum class ESGThermalImagerType : uint8_t
{
    None                                           = 0,
    Headwear                                       = 1,
    Scope                                          = 2,
    ESGThermalImagerType_MAX                       = 3

};


// Enum  /Script/SGFramework.ESGInventoryParentType
enum class ESGInventoryParentType : uint8_t
{
    None                                           = 0,
    Assemble                                       = 1,
    Container                                      = 2,
    ESGInventoryParentType_MAX                     = 3

};


// Enum  /Script/SGFramework.ECharacterSex
enum class ECharacterSex : uint8_t
{
    CharacterSex_None                              = 0,
    CharacterSex_Male                              = 1,
    CharacterSex_Female                            = 2,
    CharacterSex_MAX                               = 3

};


// Enum  /Script/SGFramework.ESGWeaponType
enum class ESGWeaponType : uint8_t
{
    None                                           = 0,
    EWeaponType_MainWeapon                         = 1,
    EWeaponType_AssistWeapon                       = 2,
    EWeaponType_MeleeWeapon                        = 3,
    EWeaponType_ThrowingWeapon                     = 4,
    EWeaponType_SpecialWeapon                      = 5,
    EWeaponType_EmptyHand                          = 6,
    EWeaponType_Max                                = 7,
    ESGWeaponType_MAX                              = 8

};


// Enum  /Script/SGFramework.ESGInteractEvent
enum class ESGInteractEvent : uint8_t
{
    ESGInteractEvent_PickUp                        = 0,
    ESGInteractEvent_Loot                          = 1,
    ESGInteractEvent_Door                          = 2,
    ESGInteractEvent_Actor                         = 3,
    ESGInteractEvent_Max                           = 4

};


// Enum  /Script/Engine.ERichCurveExtrapolation
enum class ERichCurveExtrapolation : uint8_t
{
    RCCE_Cycle                                     = 0,
    RCCE_CycleWithOffset                           = 1,
    RCCE_Oscillate                                 = 2,
    RCCE_Linear                                    = 3,
    RCCE_Constant                                  = 4,
    RCCE_None                                      = 5,
    RCCE_MAX                                       = 6

};


// Enum  /Script/Engine.ERichCurveTangentWeightMode
enum class ERichCurveTangentWeightMode : uint8_t
{
    RCTWM_WeightedNone                             = 0,
    RCTWM_WeightedArrive                           = 1,
    RCTWM_WeightedLeave                            = 2,
    RCTWM_WeightedBoth                             = 3,
    RCTWM_MAX                                      = 4

};


// Enum  /Script/Engine.ERichCurveTangentMode
enum class ERichCurveTangentMode : uint8_t
{
    RCTM_Auto                                      = 0,
    RCTM_User                                      = 1,
    RCTM_Break                                     = 2,
    RCTM_None                                      = 3,
    RCTM_MAX                                       = 4

};


// Enum  /Script/Engine.ERichCurveInterpMode
enum class ERichCurveInterpMode : uint8_t
{
    RCIM_Linear                                    = 0,
    RCIM_Constant                                  = 1,
    RCIM_Cubic                                     = 2,
    RCIM_None                                      = 3,
    RCIM_MAX                                       = 4

};


// Enum  /Script/SGFramework.EAnimInstanceUseType
enum class EAnimInstanceUseType : uint8_t
{
    AnimInstanceUseType_None                       = 0,
    AnimInstanceUseType_FacialAnim                 = 1,
    AnimInstanceUseType_Physics                    = 2,
    AnimInstanceUseType_MAX                        = 3

};


// Enum  /Script/SGFramework.ESGBadgeAttach
enum class ESGBadgeAttach : uint8_t
{
    None                                           = 0,
    LeftArm                                        = 1,
    Backpack                                       = 2,
    Vest                                           = 3,
    VestContainer                                  = 4,
    Helmet                                         = 5,
    Max                                            = 6

};


// Enum  /Script/SGFramework.EWearableEnablePolicy
enum class EWearableEnablePolicy : uint8_t
{
    None                                           = 0,
    OnlyWhenOn                                     = 1,
    OnlyWhenOff                                    = 2,
    EWearableEnablePolicy_MAX                      = 3

};


// Enum  /Script/SGFramework.ESGAvatarType
enum class ESGAvatarType : uint8_t
{
    None                                           = 0,
    Coat                                           = 1,
    Gloves                                         = 2,
    Jacket                                         = 3,
    Pants                                          = 4,
    Shoes                                          = 5,
    Torso                                          = 6,
    Legs                                           = 7,
    Head                                           = 8,
    Hair                                           = 9,
    HeadMask                                       = 10,
    Watch                                          = 11,
    Glass                                          = 12,
    Hat                                            = 13,
    Hood                                           = 14,
    Badge                                          = 15,
    Skirts                                         = 16,
    Cloak                                          = 17,
    Expand_MyBag                                   = 18,
    Expand_VestBag                                 = 19,
    Expand_Vest                                    = 20,
    Expand_Helmet                                  = 21,
    Expand_EyeWear                                 = 22,
    Expand_FaceCover                               = 23,
    Expand_ThighArmor                              = 24,
    Expand_Other                                   = 25,
    Max                                            = 26

};


// Enum  /Script/SGFramework.ESGVehicleUsedWay
enum class ESGVehicleUsedWay : uint8_t
{
    None                                           = 0,
    GetOn                                          = 1,
    GetOff                                         = 2,
    SwitchSeat                                     = 3,
    ESGVehicleUsedWay_MAX                          = 4

};


// Enum  /Script/SGFramework.ESGInventorySpawnSourceType
enum class ESGInventorySpawnSourceType : uint8_t
{
    Default                                        = 0,
    LootPoint                                      = 1,
    CharaterTakeIn                                 = 2,
    AIEquipPoolRandom                              = 3,
    Merge                                          = 4,
    UnfillContainer                                = 5,
    DuplicationDropConvert                         = 6,
    InBattleGiveItem                               = 7,
    EditorDefaultInventory                         = 8,
    GMCheat                                        = 9,
    QuestActionSpawn                               = 10,
    ReplaceDrop                                    = 11,
    LootPointGuarantee                             = 12,
    Gashapon                                       = 13,
    ShoppingStation                                = 14,
    RebornInit                                     = 15,
    FillInfiniteAmmoGive                           = 16,
    GuaranteeAct                                   = 17,
    ESGInventorySpawnSourceType_MAX                = 18

};


// Enum  /Script/SGFramework.EAdapterAnimationType
enum class EAdapterAnimationType : uint8_t
{
    AdapterAnim_None                               = 0,
    AdapterAnim_BeltOut                            = 1,
    AdapterAnim_BeltIn                             = 2,
    AdapterAnim_BipodOn                            = 3,
    AdapterAnim_BipodOff                           = 4,
    AdapterAnim_CheckMag                           = 5,
    AdapterAnim_Fire                               = 6,
    AdapterAnim_ScopeSwitch                        = 7,
    AdapterAnim_ScopeSwitchBack                    = 8,
    AdapterAnim_FoldIronSight                      = 9,
    AdapterAnim_UnFoldIronSight                    = 10,
    AdapterAnim_ViewWeapon                         = 11,
    AdapterAnim_PutDown                            = 12,
    AdapterAnim_TakeUp                             = 13,
    AdapterAnim_PickUp                             = 14,
    AdapterAnim_MagInLoop                          = 15,
    AdapterAnim_FoldStock                          = 16,
    AdapterAnim_UnFoldStock                        = 17,
    AdapterAnim_MAX                                = 18

};


// Enum  /Script/SGFramework.ESGWeaponHoldGrenadeEvent
enum class ESGWeaponHoldGrenadeEvent : uint8_t
{
    Holding                                        = 0,
    NotHolding                                     = 1,
    ESGWeaponHoldGrenadeEvent_MAX                  = 2

};


// Enum  /Script/SGFramework.ESGWeaponFiringEvent
enum class ESGWeaponFiringEvent : uint8_t
{
    StartFiring                                    = 0,
    StopFiring                                     = 1,
    CancelFiring                                   = 2,
    ESGWeaponFiringEvent_MAX                       = 3

};


// Enum  /Script/SGFramework.ESGDoorState
enum class ESGDoorState : uint8_t
{
    OpenedInner                                    = 0,
    OpenedOuter                                    = 1,
    OpenedSlidingOut                               = 2,
    Closed                                         = 3,
    ESGDoorState_MAX                               = 4

};


// Enum  /Script/SGFramework.ESGCardReaderDoorState
enum class ESGCardReaderDoorState : uint8_t
{
    None                                           = 0,
    Unlock                                         = 1,
    Locked                                         = 2,
    UnLockCoolDown                                 = 3,
    UnLockCountDown                                = 4,
    ESGCardReaderDoorState_MAX                     = 5

};


// Enum  /Script/SGFramework.ESGDoorExplosionState
enum class ESGDoorExplosionState : uint8_t
{
    None                                           = 0,
    Installing                                     = 1,
    CountDown                                      = 2,
    CountDownError                                 = 3,
    Repairing                                      = 4,
    FinalCountDown                                 = 5,
    Completed                                      = 6,
    ESGDoorExplosionState_MAX                      = 7

};


// Enum  /Script/SGFramework.ESGPlayerCondition
enum class ESGPlayerCondition : uint8_t
{
    E_None                                         = 0,
    E_Alive                                        = 1,
    E_Escape                                       = 2,
    E_Died                                         = 3,
    E_Mia                                          = 4,
    E_WaitForReborn                                = 5,
    E_MAX                                          = 6

};


// Enum  /Script/SGFramework.ESGPlayerFailCondition
enum class ESGPlayerFailCondition : uint8_t
{
    E_DBNO                                         = 0,
    E_DEATH                                        = 1,
    E_IRREGULARDBNO                                = 2,
    E_IRREGULARDEATH                               = 3,
    E_MAX                                          = 4

};


// Enum  /Script/SGFramework.EPlayerTeamType
enum class EPlayerTeamType : uint8_t
{
    EPlayerTeamType_None                           = 0,
    EPlayerTeamType_PMC                            = 1,
    EPlayerTeamType_SCAV                           = 2,
    EPlayerTeamType_BOSS                           = 3,
    EPlayerTeamType_MAX                            = 4

};


// Enum  /Script/SGFramework.EAPIReportTypes
enum class EAPIReportTypes : uint8_t
{
    E_None                                         = 0,
    E_StruckDown                                   = 1,
    E_TakeBossToken                                = 2,
    E_TakeGoldenItems                              = 3,
    E_MAX                                          = 4

};


// Enum  /Script/SGFramework.EOBSpectateState
enum class EOBSpectateState : uint8_t
{
    E_None                                         = 0,
    E_WatchBattle                                  = 1,
    E_FreeView                                     = 2,
    E_MAX                                          = 3

};


// Enum  /Script/SGFramework.ESGCompetitionFlagType
enum class ESGCompetitionFlagType : uint8_t
{
    E_None                                         = 0,
    E_ProjectileTrajectory                         = 1,
    E_Directional                                  = 2,
    E_SoundIndicator                               = 3,
    E_MAX                                          = 32

};


// Enum  /Script/SGFramework.ESGRescueUIType
enum class ESGRescueUIType : uint8_t
{
    NONE                                           = 0,
    SearchingRescueTarget                          = 1,
    StartOrEndBeingRescued                         = 2,
    CanRescueSelf                                  = 3,
    ESGRescueUIType_MAX                            = 4

};


// Enum  /Script/SGFramework.ERescueFailureReason
enum class ERescueFailureReason : uint8_t
{
    None                                           = 0,
    Rescue_TeamMateIsBeingRescued                  = 1,
    Rescue_TeamMateIsBeingRescuedBySelf            = 2,
    Others                                         = 3,
    ERescueFailureReason_MAX                       = 4

};


// Enum  /Script/SGFramework.EReviveFailureReason
enum class EReviveFailureReason : uint8_t
{
    ReviveFail_None                                = 0,
    ReviveFail_TeamMateIsBeingRevived              = 1,
    ReviveFail_Others                              = 2,
    ReviveFail_MAX                                 = 3

};


// Enum  /Script/SGFramework.EDeathDropType
enum class EDeathDropType : uint8_t
{
    DeathDrop_Normal                               = 0,
    DeathDrop_RewardBox                            = 1,
    DeathDrop_MAX                                  = 2

};


// Enum  /Script/SGFramework.EBetweenRelationType
enum class EBetweenRelationType : uint8_t
{
    EBetweenRelationType_None                      = 0,
    EBetweenRelationType_Self                      = 1,
    EBetweenRelationType_Teammate                  = 2,
    EBetweenRelationType_FactionFriendly           = 3,
    EBetweenRelationType_Hostility                 = 4,
    EBetweenRelationType_MAX                       = 5

};


// Enum  /Script/SGFramework.EUseInventoryPhase
enum class EUseInventoryPhase : uint8_t
{
    Start                                          = 0,
    Cancel                                         = 1,
    Complete                                       = 2,
    EUseInventoryPhase_MAX                         = 3

};


// Enum  /Script/SGFramework.ESGSimulatedProgressAbilityType
enum class ESGSimulatedProgressAbilityType : uint8_t
{
    None                                           = 0,
    UsingInventory                                 = 1,
    RescuingTeammate                               = 2,
    BeingRescued                                   = 3,
    FillContainer                                  = 4,
    UnfillContainer                                = 5,
    Max                                            = 6

};


// Enum  /Script/SGFramework.ESGVehicleUserType
enum class ESGVehicleUserType : uint8_t
{
    None                                           = 0,
    Driver                                         = 1,
    Passenger                                      = 2,
    ESGVehicleUserType_MAX                         = 3

};


// Enum  /Script/SGFramework.ESGEmplaceGunState
enum class ESGEmplaceGunState : uint8_t
{
    None                                           = 0,
    StartEmplacing                                 = 1,
    Emplacing                                      = 2,
    LeaveEmplacing                                 = 3,
    ESGEmplaceGunState_MAX                         = 4

};


// Enum  /Script/SGFramework.EChaseActivityState
enum class EChaseActivityState : uint8_t
{
    None                                           = 0,
    ActivityInvNotSpawn                            = 1,
    FirstActivityInvSpawned                        = 2,
    BossAIDied                                     = 3,
    FirstActivityInvCollected                      = 4,
    AllActivityInvDestroyed                        = 5,
    EChaseActivityState_MAX                        = 6

};


// Enum  /Script/SGFramework.EWatchGameState
enum class EWatchGameState : uint8_t
{
    EWatchGame_None                                = 0,
    EWatchGame_Watching                            = 1,
    EWatchGame_ResultUI                            = 2,
    EWatchGame_ReinforceUI                         = 3,
    EWatchGame_ReviveUI                            = 4,
    EWatchGame_MAX                                 = 5

};


// Enum  /Script/SGFramework.ESGGameModeType
enum class ESGGameModeType : uint8_t
{
    ESGGameModeType_RoundGame                      = 0,
    ESGGameModeType_BRGame                         = 1,
    ESGGameModeType_PersonalBattle                 = 2,
    ESGGameModeType_MAX                            = 3

};


// Enum  /Script/SGFramework.ESGPlayerFailResult
enum class ESGPlayerFailResult : uint8_t
{
    E_DBNO                                         = 0,
    E_DEATH                                        = 1,
    E_IRREGULARDBNO                                = 2,
    E_IRREGULARDEATH                               = 3,
    E_MAX                                          = 4

};


// Enum  /Script/SGFramework.ESGInventoryType
enum class ESGInventoryType : uint8_t
{
    None                                           = 0,
    Weapon                                         = 1,
    WeaponAdapter                                  = 2,
    Ammo                                           = 3,
    Armor                                          = 4,
    Recovery                                       = 5,
    Mybag                                          = 6,
    Vestbag                                        = 7,
    CorpseContainer                                = 8,
    LootContainer                                  = 9,
    Avatar                                         = 10,
    Safe                                           = 11,
    Pocket                                         = 12,
    Badge                                          = 13,
    Item                                           = 14,
    ESGInventoryType_MAX                           = 15

};


// Enum  /Script/SGFramework.ESGBagTipsType
enum class ESGBagTipsType : uint8_t
{
    BagTipsType_Default                            = 0,
    BagTipsType_PickFail                           = 1,
    BagTipsType_PickSucess                         = 2,
    BagTipsType_PickSucessButDropOne               = 3,
    BagTipsType_SwitchSucess                       = 4,
    BagTipsType_SwitchSucessButDropOne             = 5,
    BagTipsType_SwitchFail                         = 6,
    BagTipsType_Overload                           = 7,
    BagTipsType_NotAllowed                         = 8,
    BagTipsType_NewBagNotAllowed                   = 9,
    BagTipsType_PickFailBagHasContent              = 10,
    BagTipsType_ContainerStackOverflow             = 11,
    BagTipsType_NoBagNoLegalOptionContainer        = 12,
    BagTipsType_EquippedBagNotEnoughSpace          = 13,
    BagTipsType_WishListFulfilled                  = 14,
    BagTipsType_WishListSellItemAdded              = 15,
    BagTipsType_MergePartial                       = 16,
    BagTipsType_MAX                                = 17

};


// Enum  /Script/InputCore.ETouchType
enum class ETouchType : uint8_t
{
    Began                                          = 0,
    Moved                                          = 1,
    Stationary                                     = 2,
    ForceChanged                                   = 3,
    FirstMove                                      = 4,
    Ended                                          = 5,
    NumTypes                                       = 6,
    ETouchType_MAX                                 = 7

};


// Enum  /Script/SGFramework.ESoundSourceType
enum class ESoundSourceType : uint8_t
{
    None                                           = 0,
    WALK                                           = 1,
    SPRINTING                                      = 2,
    PRONE                                          = 3,
    CROUCH                                         = 4,
    QUIET_STEP                                     = 5,
    QUIET_STEP_PRONE                               = 6,
    QUIET_STEP_CROUCH                              = 7,
    RUB_GRASS                                      = 8,
    NPC_YELL                                       = 9,
    MildPoisoning                                  = 10,
    ModeratePoisoning                              = 11,
    INJURED_BREATH                                 = 12,
    NEAR_DEATH_BREATH                              = 13,
    OwnFootStepMaker                               = 14,
    OtherFootStepMaker                             = 15,
    FIRE_SINGLE                                    = 16,
    FIRE_DARTLE                                    = 17,
    FarawayGunSound                                = 18,
    EXPLOSION                                      = 19,
    ChangeMag                                      = 20,
    Heal                                           = 21,
    DoorOperate                                    = 22,
    DropEquipment                                  = 23,
    BehaviorSwitch                                 = 24,
    PlayerYell                                     = 25,
    ActivityFootStepMaker                          = 26,
    InventoryContainer                             = 27,
    Landed                                         = 28,
    VehicleEngine                                  = 29,
    VehicleThrottle                                = 30,
    VehicleHorn                                    = 31,
    VehicleExplosion                               = 32,
    ZiplineMoving                                  = 33,
    DroneMoving                                    = 34,
    WeaponZoom                                     = 35,
    SpeicalPlayerBreath                            = 36,
    DiveLanded                                     = 37,
    Slide                                          = 38,
    LootBoxUnlock                                  = 39,
    MAX                                            = 40

};


// Enum  /Script/PhysicsCore.EPhysicalSurface
enum class EPhysicalSurface : uint8_t
{
    SurfaceType_Default                            = 0,
    SurfaceType1                                   = 1,
    SurfaceType2                                   = 2,
    SurfaceType3                                   = 3,
    SurfaceType4                                   = 4,
    SurfaceType5                                   = 5,
    SurfaceType6                                   = 6,
    SurfaceType7                                   = 7,
    SurfaceType8                                   = 8,
    SurfaceType9                                   = 9,
    SurfaceType10                                  = 10,
    SurfaceType11                                  = 11,
    SurfaceType12                                  = 12,
    SurfaceType13                                  = 13,
    SurfaceType14                                  = 14,
    SurfaceType15                                  = 15,
    SurfaceType16                                  = 16,
    SurfaceType17                                  = 17,
    SurfaceType18                                  = 18,
    SurfaceType19                                  = 19,
    SurfaceType20                                  = 20,
    SurfaceType21                                  = 21,
    SurfaceType22                                  = 22,
    SurfaceType23                                  = 23,
    SurfaceType24                                  = 24,
    SurfaceType25                                  = 25,
    SurfaceType26                                  = 26,
    SurfaceType27                                  = 27,
    SurfaceType28                                  = 28,
    SurfaceType29                                  = 29,
    SurfaceType30                                  = 30,
    SurfaceType31                                  = 31,
    SurfaceType32                                  = 32,
    SurfaceType33                                  = 33,
    SurfaceType34                                  = 34,
    SurfaceType35                                  = 35,
    SurfaceType36                                  = 36,
    SurfaceType37                                  = 37,
    SurfaceType38                                  = 38,
    SurfaceType39                                  = 39,
    SurfaceType40                                  = 40,
    SurfaceType41                                  = 41,
    SurfaceType42                                  = 42,
    SurfaceType43                                  = 43,
    SurfaceType44                                  = 44,
    SurfaceType45                                  = 45,
    SurfaceType46                                  = 46,
    SurfaceType47                                  = 47,
    SurfaceType48                                  = 48,
    SurfaceType49                                  = 49,
    SurfaceType50                                  = 50,
    SurfaceType51                                  = 51,
    SurfaceType52                                  = 52,
    SurfaceType53                                  = 53,
    SurfaceType54                                  = 54,
    SurfaceType55                                  = 55,
    SurfaceType56                                  = 56,
    SurfaceType57                                  = 57,
    SurfaceType58                                  = 58,
    SurfaceType59                                  = 59,
    SurfaceType60                                  = 60,
    SurfaceType61                                  = 61,
    SurfaceType62                                  = 62,
    SurfaceType_Max                                = 63,
    EPhysicalSurface_MAX                           = 64

};


// Enum  /Script/SGFramework.EInteractEventType
enum class EInteractEventType : uint8_t
{
    EnableInteract                                 = 0,
    DisableInteract                                = 1,
    Start                                          = 2,
    Cancel                                         = 3,
    Complete                                       = 4,
    DestoryInteract                                = 5,
    EInteractEventType_MAX                         = 6

};


// Enum  /Script/SGFramework.ESGInteractType
enum class ESGInteractType : uint8_t
{
    Normal                                         = 0,
    ChasePutIn                                     = 1,
    ChaseCheck                                     = 2,
    ESGInteractType_MAX                            = 3

};


// Enum  /Script/SGFramework.EUseActorFailureReason
enum class EUseActorFailureReason : uint8_t
{
    None                                           = 0,
    UseInventory_NoEnduranceLoss                   = 1,
    UseInventory_NeedToCureOutOfEndurance          = 2,
    UseInventory_NoNeedToCureBoneBreak             = 3,
    UseInventory_NoNeedToCureBleed                 = 4,
    UseInventory_NoNeedToCureOutOfEndurance        = 5,
    UseInventory_InsufficientDurabilityToCureOutOfEndurance = 6,
    UseInventory_InsufficientDurabilityToCureBoneBreak = 7,
    UseInventory_InsufficientDurabilityToCureBleed = 8,
    UseInventory_NotOwnInventory                   = 9,
    UseInventory_AlreadyUsingInventory             = 10,
    GiveInventory_AlreadyHasOwner                  = 11,
    LootInventory_OutOfRange                       = 12,
    UseInventory_NoNumberOfUses                    = 13,
    UseInventory_NotInDBNO                         = 14,
    UseInventory_InCooldown                        = 15,
    Others                                         = 16,
    EUseActorFailureReason_MAX                     = 17

};


// Enum  /Script/SGFramework.ETradeInventoryFailureReason
enum class ETradeInventoryFailureReason : uint8_t
{
    None                                           = 0,
    TradeInventory_InventoryInfoChange             = 1,
    TradeInventory_InventoryLeftCountDeficiency    = 2,
    TradeInventory_CharacterLeftSpaceDeficiency    = 3,
    TradeInventory_CheckCostInventoryFail          = 4,
    TradeInventory_SpawnInventoryFail              = 5,
    TradeInventory_InteractDistanceAbnormal        = 6,
    TradeInventory_RemainingTradeCountInsufficient = 7,
    TradeInventory_DiscountCouponDeficiency        = 8,
    TradeInventory_GiveGiftInventory               = 9,
    Others                                         = 10,
    ETradeInventoryFailureReason_MAX               = 11

};


// Enum  /Script/SGFramework.ETeamExchangeFailureReason
enum class ETeamExchangeFailureReason : uint8_t
{
    None                                           = 0,
    TeamExchange_CheckCostItemFail                 = 1,
    TeamExchange_CheckExchangeCountFail            = 2,
    TeamExchange_InteractDistanceAbnormal          = 3,
    TeamExchange_CharacterNotPMC                   = 4,
    TeamExchange_InvalidItemNum                    = 5,
    TeamExchange_InvalidItemID                     = 6,
    Others                                         = 7,
    ETeamExchangeFailureReason_MAX                 = 8

};


// Enum  /Script/SGFramework.EActivityInventoryState
enum class EActivityInventoryState : uint8_t
{
    None                                           = 0,
    Teammate                                       = 1,
    Self                                           = 2,
    Other                                          = 3,
    EActivityInventoryState_MAX                    = 4

};


// Enum  /Script/SGFramework.EChaseActivityStage
enum class EChaseActivityStage : uint8_t
{
    Search                                         = 0,
    SearchAndTakeOut                               = 1,
    TakeOut                                        = 2,
    SearchAndGuard                                 = 3,
    Guard                                          = 4,
    Failed                                         = 5,
    EChaseActivityStage_MAX                        = 6

};


// Enum  /Script/SGFramework.EUAUIMode
enum class EUAUIMode : uint8_t
{
    None                                           = 0,
    Character                                      = 1,
    Drone                                          = 2,
    DroneSpectating                                = 3,
    PhotoGraph                                     = 4,
    Spectating                                     = 5,
    OBSpectating                                   = 6,
    OBFreeView                                     = 7,
    DBNO                                           = 8,
    PrepareStage                                   = 9,
    Bag                                            = 10,
    BigMap                                         = 11,
    Settlement                                     = 12,
    EscapePerform                                  = 13,
    EndGame                                        = 14,
    GameSettings                                   = 15,
    Preparations                                   = 16,
    VehicleDriver                                  = 17,
    VehiclePassenger                               = 18,
    Monitor                                        = 19,
    MonitorSpectating                              = 20,
    EmplacingGun                                   = 21,
    Reborning                                      = 22,
    EUAUIMode_MAX                                  = 23

};


// Enum  /Script/SGFramework.EMobileInputPhase
enum class EMobileInputPhase : uint8_t
{
    MobileInputPhase_Began                         = 0,
    MobileInputPhase_Moved                         = 1,
    MobileInputPhase_Stationary                    = 2,
    MobileInputPhase_Ended                         = 3,
    MobileInputPhase_Canceled                      = 4,
    MobileInputPhase_MAX                           = 5

};


// Enum  /Script/SGFramework.ESGWeaponShootingMode
enum class ESGWeaponShootingMode : uint8_t
{
    EShootingMode_None                             = 0,
    EShootingMode_Semi                             = 1,
    EShootingMode_Auto                             = 2,
    EShootingMode_Burst                            = 3,
    EShootingMode_MAX                              = 4

};


// Enum  /Script/SGFramework.EAnnounceRangeType
enum class EAnnounceRangeType : uint8_t
{
    Announce_Self                                  = 0,
    Announce_Team                                  = 1,
    Announce_Faction                               = 2,
    Announce_All                                   = 3,
    Announce_MAX                                   = 4

};


// Enum  /Script/SGFramework.EInteractionActorType
enum class EInteractionActorType : uint8_t
{
    None                                           = 0,
    Door                                           = 1,
    PoisonGas                                      = 2,
    SceneGasGate                                   = 3,
    EInteractionActorType_MAX                      = 4

};


// Enum  /Script/SGFramework.EGetOutOfStuckResult
enum class EGetOutOfStuckResult : uint8_t
{
    Success                                        = 0,
    IsNotStuck                                     = 1,
    CannotFindLocation                             = 2,
    NoChance                                       = 3,
    OtherFailReason                                = 4,
    EGetOutOfStuckResult_MAX                       = 5

};


// Enum  /Script/SGFramework.EInventoryInteractionType
enum class EInventoryInteractionType : uint8_t
{
    None                                           = 0,
    Fill                                           = 1,
    FillExtra                                      = 2,
    UnFill                                         = 3,
    Use                                            = 4,
    Reload                                         = 5,
    ReloadBores                                    = 6,
    ReloadOneByOne                                 = 7,
    ReloadOneByOneHang                             = 8,
    ReloadBoresOnHang                              = 9,
    SetupAdapter                                   = 10,
    CheckMagazine                                  = 11,
    RollUpBag                                      = 12,
    FoldStock                                      = 13,
    WeaponControll                                 = 14,
    FoldScope                                      = 15,
    RepairWeapon                                   = 16,
    SetupArmorAdapter                              = 17,
    ViewWeapon                                     = 18,
    ClearBores                                     = 19,
    ClearUp                                        = 20,
    EInventoryInteractionType_MAX                  = 21

};


// Enum  /Script/SGFramework.EWeatherType
enum class EWeatherType : uint8_t
{
    None                                           = 0,
    Sunny                                          = 1,
    Rainny                                         = 2,
    Cloudy                                         = 3,
    Snow                                           = 4,
    Blizzard                                       = 5,
    Sand                                           = 6,
    StormRainy                                     = 99,
    EWeatherType_MAX                               = 100

};


// Enum  /Script/SGFramework.EThunderstormStage
enum class EThunderstormStage : uint8_t
{
    None                                           = 0,
    Begin                                          = 1,
    ReachtoPeak                                    = 2,
    Fade                                           = 3,
    End                                            = 4,
    EThunderstormStage_MAX                         = 5

};


// Enum  /Script/SGFramework.EScorePanelTimeType
enum class EScorePanelTimeType : uint8_t
{
    E_GameTime                                     = 0,
    E_Custom                                       = 1,
    E_MAX                                          = 2

};


// Enum  /Script/SGFramework.EBattleLeaveReason
enum class EBattleLeaveReason : uint8_t
{
    Normal                                         = 0,
    Dead                                           = 1,
    GameOver                                       = 2,
    TargetLost                                     = 3,
    Mismatching                                    = 4,
    Unknown                                        = 255,
    EBattleLeaveReason_MAX                         = 256

};


// Enum  /Script/SGFramework.ECostMoneyReasonType
enum class ECostMoneyReasonType : uint8_t
{
    None                                           = 0,
    MultiInventoryCost                             = 1,
    GashaponCost                                   = 2,
    RebornEquipment                                = 3,
    ECostMoneyReasonType_MAX                       = 4

};


// Enum  /Script/SGFramework.EVehicleTakeInType
enum class EVehicleTakeInType : uint8_t
{
    None                                           = 0,
    TakeIn                                         = 1,
    AISpawn                                        = 2,
    LootPointSpawn                                 = 3,
    EVehicleTakeInType_MAX                         = 4

};


// Enum  /Script/SGFramework.EWeakNetLevel
enum class EWeakNetLevel : uint8_t
{
    Level_None                                     = 0,
    Level_Yellow                                   = 1,
    Level_Red                                      = 2,
    Level_MAX                                      = 3

};


// Enum  /Script/SGFramework.EClientMoveCorrectionType
enum class EClientMoveCorrectionType : uint8_t
{
    Normal                                         = 0,
    VaultOrLadderEnd                               = 1,
    EClientMoveCorrectionType_MAX                  = 2

};


// Enum  /Script/SGFramework.ESGMonitorInterference
enum class ESGMonitorInterference : uint8_t
{
    EMonitorInterference_None                      = 0,
    EMonitorInterference_Little                    = 1,
    EMonitorInterference_Big                       = 2,
    EMonitorInterference_MAX                       = 3

};


// Enum  /Script/SGFramework.EHandleReinforcementType
enum class EHandleReinforcementType : uint8_t
{
    None                                           = 0,
    Reject                                         = 1,
    Accept                                         = 2,
    Ignore                                         = 3,
    EHandleReinforcementType_MAX                   = 4

};


// Enum  /Script/SGFramework.ESGGeneralTransitionReason
enum class ESGGeneralTransitionReason : uint8_t
{
    ESGGeneralTransitionReason_None                = 0,
    ESGGeneralTransitionReason_Drone               = 1,
    ESGGeneralTransitionReason_LostSignal          = 2,
    ESGGeneralTransitionReason_Monitor             = 3,
    ESGGeneralTransitionReason_FixedPointMonitor   = 4,
    ESGGeneralTransitionReason_Reborn              = 5,
    ESGGeneralTransitionReason_MAX                 = 6

};


// Enum  /Script/SGFramework.ESGUIOperationForSpectating
enum class ESGUIOperationForSpectating : uint8_t
{
    OP_Loot                                        = 0,
    OP_OpenBag                                     = 1,
    OP_LifeState                                   = 2,
    OP_OpenMap                                     = 3,
    OP_LootRewardBox                               = 4,
    OP_LootScavBox                                 = 5,
    OP_OpenWithdrawSubmit                          = 6,
    OP_MAX                                         = 7

};


// Enum  /Script/SGFramework.EUAPlayerRoundState
enum class EUAPlayerRoundState : uint8_t
{
    EUAPlayerRoundState_NONE                       = 0,
    EUAPlayerRoundState_Load                       = 1,
    EUAPlayerRoundState_ChooseEquipment            = 2,
    EUAPlayerRoundState_WaitForBegin               = 3,
    EUAPlayerRoundState_CountDown                  = 4,
    EUAPlayerRoundState_Gaming                     = 5,
    EUAPlayerRoundState_Watch                      = 6,
    EUAPlayerRoundState_MAX                        = 7

};


// Enum  /Script/SGFramework.ESGViewTargetChangeReason
enum class ESGViewTargetChangeReason : uint8_t
{
    ESGViewTargetChangeReason_None                 = 0,
    ESGViewTargetChangeReason_Drone                = 1,
    ESGViewTargetChangeReason_Possess              = 2,
    ESGViewTargetChangeReason_Spectating           = 3,
    ESGViewTargetChangeReason_LostSignal           = 4,
    ESGViewTargetChangeReason_Monitor              = 5,
    ESGViewTargetChangeReason_FixedPointMonitor    = 6,
    ESGViewTargetChangeReason_Radar                = 7,
    ESGViewTargetChangeReason_MAX                  = 8

};


// Enum  /Script/SGFramework.EPullBoltFailureReason
enum class EPullBoltFailureReason : uint8_t
{
    EPullBoltFailureReason_None                    = 0,
    EPullBoltFailureReason_BoresFull               = 1,
    EPullBoltFailureReason_MagEmpty                = 2,
    EPullBoltFailureReason_MAX                     = 3

};


// Enum  /Script/SGFramework.EInteractFrameworkActionType
enum class EInteractFrameworkActionType : uint8_t
{
    UnDefine                                       = 0,
    Loot                                           = 1,
    PickUp                                         = 2,
    UnlockDoor                                     = 3,
    OpenDoor                                       = 4,
    CloseDoor                                      = 5,
    EnterVehicle                                   = 6,
    LeaveVehicle                                   = 7,
    SwitchVehicleSeat                              = 8,
    CloseLootBox                                   = 9,
    SurveyCorpseBox                                = 10,
    Recovery                                       = 11,
    CommonInteract                                 = 12,
    InstallDoorBomb                                = 13,
    RepairDoorBomb                                 = 14,
    RevivalCorpseBox                               = 15,
    InstallLootBoxDecoder                          = 16,
    RepairLootBoxDecoder                           = 17,
    UnlockLockLootContainer                        = 18,
    RecoveryMonitor                                = 19,
    KnockDoor                                      = 20,
    EInteractFrameworkActionType_MAX               = 21

};


// Enum  /Script/SGFramework.EGashaponGearsType
enum class EGashaponGearsType : uint8_t
{
    GashaponGears_None                             = 0,
    GashaponGears_One                              = 1,
    GashaponGears_Two                              = 2,
    GashaponGears_Three                            = 3,
    GashaponGears_Four                             = 4,
    GashaponGears_Five                             = 5,
    GashaponGears_Six                              = 6,
    GashaponGears_Seven                            = 7,
    GashaponGears_Eight                            = 8,
    GashaponGears_Nine                             = 9,
    GashaponGears_Ten                              = 10,
    GashaponGears                                  = 11,
    GashaponGears                                  = 12,
    GashaponGears                                  = 13,
    GashaponGears                                  = 14,
    GashaponGears                                  = 15,
    GashaponGears                                  = 16,
    GashaponGears                                  = 17,
    GashaponGears                                  = 18,
    GashaponGears                                  = 19,
    GashaponGears                                  = 20,
    GashaponGears                                  = 21,
    GashaponGears                                  = 22,
    GashaponGears                                  = 23,
    GashaponGears                                  = 24,
    GashaponGears                                  = 25,
    GashaponGears                                  = 26,
    GashaponGears                                  = 27,
    GashaponGears                                  = 28,
    GashaponGears                                  = 29,
    GashaponGears                                  = 30,
    GashaponGears_Max                              = 31

};


// Enum  /Script/SGFramework.EMiniGameCommand
enum class EMiniGameCommand : uint8_t
{
    Default                                        = 0,
    Request_Message                                = 1,
    Request_CloseGame                              = 2,
    Order_Message                                  = 3,
    Order_CloseGame                                = 4,
    Order_OpenGame                                 = 5,
    Order_PassGame                                 = 6,
    EMiniGameCommand_MAX                           = 7

};


// Enum  /Script/Engine.EViewSignificantState
enum class EViewSignificantState : uint8_t
{
    None                                           = 0,
    ViewTarget                                     = 1,
    NotViewTarget                                  = 2,
    EViewSignificantState_MAX                      = 3

};


// Enum  /Script/Engine.ENetDormancy
enum class ENetDormancy : uint8_t
{
    DORM_Never                                     = 0,
    DORM_Awake                                     = 1,
    DORM_DormantAll                                = 2,
    DORM_DormantPartial                            = 3,
    DORM_Initial                                   = 4,
    DORM_MAX                                       = 5

};


// Enum  /Script/Engine.EAutoReceiveInput
enum class EAutoReceiveInput : uint8_t
{
    Disabled                                       = 0,
    Player0                                        = 1,
    Player1                                        = 2,
    Player2                                        = 3,
    Player3                                        = 4,
    Player4                                        = 5,
    Player5                                        = 6,
    Player6                                        = 7,
    Player7                                        = 8,
    EAutoReceiveInput_MAX                          = 9

};


// Enum  /Script/Engine.ESpawnActorCollisionHandlingMethod
enum class ESpawnActorCollisionHandlingMethod : uint8_t
{
    Undefined                                      = 0,
    AlwaysSpawn                                    = 1,
    AdjustIfPossibleButAlwaysSpawn                 = 2,
    AdjustIfPossibleButDontSpawnIfColliding        = 3,
    DontSpawnIfColliding                           = 4,
    ESpawnActorCollisionHandlingMethod_MAX         = 5

};


// Enum  /Script/Engine.ERotatorQuantization
enum class ERotatorQuantization : uint8_t
{
    ByteComponents                                 = 0,
    ShortComponents                                = 1,
    ERotatorQuantization_MAX                       = 2

};


// Enum  /Script/Engine.EVectorQuantization
enum class EVectorQuantization : uint8_t
{
    RoundWholeNumber                               = 0,
    RoundOneDecimal                                = 1,
    RoundTwoDecimals                               = 2,
    EVectorQuantization_MAX                        = 3

};


// Enum  /Script/Engine.EActorUpdateOverlapsMethod
enum class EActorUpdateOverlapsMethod : uint8_t
{
    UseConfigDefault                               = 0,
    AlwaysUpdate                                   = 1,
    OnlyUpdateMovable                              = 2,
    NeverUpdate                                    = 3,
    EActorUpdateOverlapsMethod_MAX                 = 4

};


// Enum  /Script/Engine.ECameraShakePlaySpace
enum class ECameraShakePlaySpace : uint8_t
{
    CameraLocal                                    = 0,
    World                                          = 1,
    UserDefined                                    = 2,
    ECameraShakePlaySpace_MAX                      = 3

};


// Enum  /Script/Engine.EViewTargetBlendFunction
enum class EViewTargetBlendFunction : uint8_t
{
    VTBlend_Linear                                 = 0,
    VTBlend_Cubic                                  = 1,
    VTBlend_EaseIn                                 = 2,
    VTBlend_EaseOut                                = 3,
    VTBlend_EaseInOut                              = 4,
    VTBlend_MAX                                    = 5

};


// Enum  /Script/Engine.ETravelType
enum class ETravelType : uint8_t
{
    TRAVEL_Absolute                                = 0,
    TRAVEL_Partial                                 = 1,
    TRAVEL_Relative                                = 2,
    TRAVEL_MAX                                     = 3

};


// Enum  /Script/Engine.ECollisionChannel
enum class ECollisionChannel : uint8_t
{
    ECC_WorldStatic                                = 0,
    ECC_WorldDynamic                               = 1,
    ECC_Pawn                                       = 2,
    ECC_Visibility                                 = 3,
    ECC_Camera                                     = 4,
    ECC_PhysicsBody                                = 5,
    ECC_Vehicle                                    = 6,
    ECC_Destructible                               = 7,
    ECC_EngineTraceChannel1                        = 8,
    ECC_EngineTraceChannel2                        = 9,
    ECC_EngineTraceChannel3                        = 10,
    ECC_EngineTraceChannel4                        = 11,
    ECC_EngineTraceChannel5                        = 12,
    ECC_EngineTraceChannel6                        = 13,
    ECC_GameTraceChannel1                          = 14,
    ECC_GameTraceChannel2                          = 15,
    ECC_GameTraceChannel3                          = 16,
    ECC_GameTraceChannel4                          = 17,
    ECC_GameTraceChannel5                          = 18,
    ECC_GameTraceChannel6                          = 19,
    ECC_GameTraceChannel7                          = 20,
    ECC_GameTraceChannel8                          = 21,
    ECC_GameTraceChannel9                          = 22,
    ECC_GameTraceChannel10                         = 23,
    ECC_GameTraceChannel11                         = 24,
    ECC_GameTraceChannel12                         = 25,
    ECC_GameTraceChannel13                         = 26,
    ECC_GameTraceChannel14                         = 27,
    ECC_GameTraceChannel15                         = 28,
    ECC_GameTraceChannel16                         = 29,
    ECC_GameTraceChannel17                         = 30,
    ECC_GameTraceChannel18                         = 31,
    ECC_OverlapAll_Deprecated                      = 32,
    ECC_MAX                                        = 33

};


// Enum  /Script/Engine.EControllerAnalogStick
enum class EControllerAnalogStick : uint8_t
{
    CAS_LeftStick                                  = 0,
    CAS_RightStick                                 = 1,
    CAS_MAX                                        = 2

};


// Enum  /Script/Engine.EDynamicForceFeedbackAction
enum class EDynamicForceFeedbackAction : uint8_t
{
    Start                                          = 0,
    Update                                         = 1,
    Stop                                           = 2,
    EDynamicForceFeedbackAction_MAX                = 3

};


// Enum  /Script/InputCore.EControllerHand
enum class EControllerHand : uint8_t
{
    Left                                           = 0,
    Right                                          = 1,
    AnyHand                                        = 2,
    Pad                                            = 3,
    ExternalCamera                                 = 4,
    Gun                                            = 5,
    Special                                        = 6,
    Special                                        = 7,
    Special                                        = 8,
    Special                                        = 9,
    Special                                        = 10,
    Special                                        = 11,
    Special                                        = 12,
    Special                                        = 13,
    Special                                        = 14,
    Special                                        = 15,
    Special                                        = 16,
    ControllerHand_Count                           = 17,
    EControllerHand_MAX                            = 18

};


// Enum  /Script/SGFramework.ESGDynamicHUDType
enum class ESGDynamicHUDType : uint8_t
{
    None                                           = 0,
    MovieCameraTool                                = 1,
    TalentInteract                                 = 2,
    PermissionControl                              = 3,
    ESGDynamicHUDType_MAX                          = 4

};


// Enum  /Script/SGFramework.ESGVehicleUseFailCode
enum class ESGVehicleUseFailCode : uint8_t
{
    None                                           = 0,
    InvailArg                                      = 1,
    UseVehicleFail                                 = 2,
    Leave_NotFoundPos                              = 3,
    ESGVehicleUseFailCode_MAX                      = 4

};


// Enum  /Script/AIModule.EPathFollowingResult
enum class EPathFollowingResult : uint8_t
{
    Success                                        = 0,
    Blocked                                        = 1,
    OffPath                                        = 2,
    Aborted                                        = 3,
    Skipped_DEPRECATED                             = 4,
    Invalid                                        = 5,
    EPathFollowingResult_MAX                       = 6

};


// Enum  /Script/AIModule.EEnvQueryStatus
enum class EEnvQueryStatus : uint8_t
{
    Processing                                     = 0,
    Success                                        = 1,
    Failed                                         = 2,
    Aborted                                        = 3,
    OwnerLost                                      = 4,
    MissingParam                                   = 5,
    EEnvQueryStatus_MAX                            = 6

};


// Enum  /Script/AIModule.EPathFollowingRequestResult
enum class EPathFollowingRequestResult : uint8_t
{
    Failed                                         = 0,
    AlreadyAtGoal                                  = 1,
    RequestSuccessful                              = 2,
    EPathFollowingRequestResult_MAX                = 3

};


// Enum  /Script/SGFramework.ESGVehicleTakeDamagePartType
enum class ESGVehicleTakeDamagePartType : uint8_t
{
    None                                           = 0,
    Body                                           = 1,
    Wheel                                          = 2,
    Window                                         = 3,
    ESGVehicleTakeDamagePartType_MAX               = 4

};


// Enum  /Script/SGFramework.FDownloadTaskErrorCode
enum class FDownloadTaskErrorCode : uint8_t
{
    None                                           = 0,
    DiskFull                                       = 1,
    PermissionDenied                               = 2,
    Timeout                                        = 3,
    NetworkError                                   = 4,
    HttpError                                      = 5,
    FileSaveFailed                                 = 6,
    FDownloadTaskErrorCode_MAX                     = 7

};


// Enum  /Script/SGFramework.EDownloadTaskState
enum class EDownloadTaskState : uint8_t
{
    DownloadTaskState_Idle                         = 0,
    DownloadTaskState_InProgress                   = 1,
    DownloadTaskState_Completed                    = 2,
    DownloadTaskState_Failed                       = 3,
    DownloadTaskState_MAX                          = 4

};


// Enum  /Script/SGFramework.ESignalAffectAttribute
enum class ESignalAffectAttribute : uint8_t
{
    SignalValue                                    = 0,
    DBNOHealth                                     = 1,
    ESignalAffectAttribute_MAX                     = 2

};


// Enum  /Script/SGFramework.EVolumeType
enum class EVolumeType : uint8_t
{
    EVolumeType_Box                                = 0,
    EVolumeType_Sphere                             = 1,
    EVolumeType_RoundBox                           = 2,
    EVolumeType_Max                                = 3

};


// Enum  /Script/SGFramework.EQTEType
enum class EQTEType : uint8_t
{
    QTEType_TwoChatacter                           = 0,
    QTEType_SingleCharacter                        = 1,
    QTEType_WithSceneObject                        = 2,
    QTEType_MAX                                    = 3

};


// Enum  /Script/SGFramework.EQTEStep
enum class EQTEStep : uint8_t
{
    QTEStep_None                                   = 0,
    QTEStep_PreReady                               = 1,
    QTEStep_Ready                                  = 2,
    QTEStep_Action                                 = 3,
    QTEStep_WaitInput                              = 4,
    QTEStep_Interrupt                              = 5,
    QTEStep_Finish                                 = 6,
    QTEStep_MAX                                    = 7

};


// Enum  /Script/SGFramework.EDelayReason
enum class EDelayReason : uint8_t
{
    None                                           = 0,
    TcaticalPistolTransition                       = 1,
    EDelayReason_MAX                               = 2

};


// Enum  /Script/SGFramework.EViewMonitorStatus
enum class EViewMonitorStatus : uint8_t
{
    EViewMonitorStatus_None                        = 0,
    EViewMonitorStatus_Loading                     = 1,
    EViewMonitorStatus_Viewing                     = 2,
    EViewMonitorStatus_MAX                         = 3

};


// Enum  /Script/SGFramework.ESGInventoryChildConfigOperation
enum class ESGInventoryChildConfigOperation : uint8_t
{
    And                                            = 0,
    Or                                             = 1,
    ESGInventoryChildConfigOperation_MAX           = 2

};


// Enum  /Script/SGFramework.ESGRadiusCheckType
enum class ESGRadiusCheckType : uint8_t
{
    None                                           = 0,
    Sphere                                         = 1,
    Box                                            = 2,
    Cylinder                                       = 3,
    ESGRadiusCheckType_MAX                         = 4

};


// Enum  /Script/SGFramework.Enum_RotationState
enum class Enum_RotationState : uint8_t
{
    None                                           = 0,
    StartRatation                                  = 1,
    ForWarding                                     = 2,
    EndRatation                                    = 3,
    BackWarding                                    = 4,
    Enum_MAX                                       = 5

};


// Enum  /Script/SGFramework.EAdviseInvType
enum class EAdviseInvType : uint8_t
{
    Drug                                           = 0,
    Tactic                                         = 1,
    EAdviseInvType_MAX                             = 2

};


// Enum  /Script/SGFramework.EAILODLevel
enum class EAILODLevel : uint8_t
{
    None                                           = 0,
    Level_TINY                                     = 1,
    Level_LOD                                      = 2,
    Level_TickDisable                              = 3,
    EAILODLevel_MAX                                = 4

};


// Enum  /Script/SGFramework.EAISpawnStep
enum class EAISpawnStep : uint8_t
{
    AISpawnStep_NotReady                           = 0,
    AISpawnStep_Begin                              = 1,
    AISpawnStep_PMCAI                              = 2,
    AISpawnStep_Boss                               = 3,
    AISpawnStep_Boss_BeforeGame                    = 4,
    AISpawnStep_ScavAI_BeforeGame                  = 5,
    AISpawnStep_PlayerScavAI                       = 6,
    AISpawnStep_ScavAI                             = 7,
    AISpawnStep_WaitForGame                        = 8,
    AISpawnStep_End                                = 9,
    AISpawnStep_MAX                                = 10

};


// Enum  /Script/SGFramework.EAIRemoveReason
enum class EAIRemoveReason : uint8_t
{
    ENone                                          = 0,
    EPressureBalance                               = 1,
    ETooManyAIInSquad                              = 2,
    ETooManyAIInMap                                = 3,
    EWaitOutOfTime                                 = 4,
    EExcluded                                      = 5,
    EHotPoint                                      = 6,
    EAIRemoveReason_MAX                            = 7

};


// Enum  /Script/SGFramework.EAICharacterPriority
enum class EAICharacterPriority : uint8_t
{
    EHigh                                          = 0,
    ENormal                                        = 1,
    ELow                                           = 2,
    EPendingRemove                                 = 3,
    EToRemove                                      = 4,
    EInvalid                                       = 5,
    EAICharacterPriority_MAX                       = 6

};


// Enum  /Script/SGFramework.EAIFillupSpawnRule
enum class EAIFillupSpawnRule : uint8_t
{
    None                                           = 0,
    CharacterNum                                   = 1,
    AINum                                          = 2,
    EAIFillupSpawnRule_MAX                         = 3

};


// Enum  /Script/SGFramework.ESpawnResult
enum class ESpawnResult : uint8_t
{
    Success                                        = 0,
    Failed                                         = 1,
    ESpawnResult_MAX                               = 2

};


// Enum  /Script/SGFramework.EAILatentResult
enum class EAILatentResult : uint8_t
{
    Success                                        = 0,
    Failed                                         = 1,
    EAILatentResult_MAX                            = 2

};


// Enum  /Script/SGFramework.EAISpawnPointOption
enum class EAISpawnPointOption : uint8_t
{
    AreaSpawnPoint                                 = 0,
    PlayerSpawnPoint                               = 1,
    VectorSpawnPoint                               = 2,
    EAISpawnPointOption_MAX                        = 3

};


// Enum  /Script/SGFramework.EAISpawnSquadType
enum class EAISpawnSquadType : uint8_t
{
    None                                           = 0,
    ScavAI                                         = 1,
    BossTeam                                       = 2,
    PMCAI                                          = 3,
    PMCAI                                          = 4,
    PlayerScavAI                                   = 5,
    SupportAI                                      = 6,
    AntiCamperAI                                   = 7,
    VectorAI                                       = 8,
    EAISpawnSquadType_MAX                          = 9

};


// Enum  /Script/SGFramework.EAISpawnRequestFail
enum class EAISpawnRequestFail : uint8_t
{
    TimeOut                                        = 0,
    SpawnPointNotEnough                            = 1,
    EAISpawnRequestFail_MAX                        = 2

};


// Enum  /Script/SGFramework.ESpawnReason
enum class ESpawnReason : uint8_t
{
    Normal                                         = 0,
    AlarmDevice                                    = 1,
    PlayerEnter                                    = 2,
    ByVector                                       = 3,
    BySpawnPoint                                   = 4,
    ESpawnReason_MAX                               = 5

};


// Enum  /Script/SGFramework.EAISpawnProgress
enum class EAISpawnProgress : uint8_t
{
    Wait                                           = 0,
    Spawned                                        = 1,
    Ready                                          = 2,
    Actived                                        = 3,
    EAISpawnProgress_MAX                           = 4

};


// Enum  /Script/SGFramework.EAIState
enum class EAIState : uint8_t
{
    AIPawnState_None                               = 0,
    AIPawnState_Wander                             = 1,
    AIPawnState_ChasePlayer                        = 2,
    AIPawnState_MAX                                = 3

};


// Enum  /Script/SGFramework.EMagBulletAnimState
enum class EMagBulletAnimState : uint8_t
{
    EMagBulletAnimState_StartOneFill               = 0,
    EMagBulletAnimState_AttachToMag                = 1,
    EMagBulletAnimState_EndOneFill                 = 2,
    EMagBulletAnimState_MAX                        = 3

};


// Enum  /Script/SGFramework.EBoreBulletAnimState
enum class EBoreBulletAnimState : uint8_t
{
    EBoreBulletAnimState_EjectBullet               = 0,
    EBoreBulletAnimState_MagPopBullet              = 1,
    EBoreBulletAnimState_EndMagAnim                = 2,
    EBoreBulletAnimState_MAX                       = 3

};


// Enum  /Script/SGFramework.EWeaponSwaySpringType
enum class EWeaponSwaySpringType : uint8_t
{
    SpringDamper                                   = 0,
    Damper                                         = 1,
    EWeaponSwaySpringType_MAX                      = 2

};


// Enum  /Script/SGFramework.EFootstepNotifyType
enum class EFootstepNotifyType : uint8_t
{
    FootstepNotify_Run                             = 0,
    FootstepNotify_Jump                            = 1,
    FootstepNotify_Dive                            = 2,
    FootstepNotify_Slide                           = 3,
    FootstepNotify_MAX                             = 4

};


// Enum  /Script/SGFramework.ECharacterPreviewAnimationBranchType
enum class ECharacterPreviewAnimationBranchType : uint8_t
{
    None                                           = 0,
    Female                                         = 1,
    Pistol                                         = 2,
    Pistol_Female                                  = 3,
    EmptyHand                                      = 4,
    EmptyHand_Female                               = 5,
    ECharacterPreviewAnimationBranchType_MAX       = 6

};


// Enum  /Script/SGFramework.ETakeCoverLeanAnimType
enum class ETakeCoverLeanAnimType : uint8_t
{
    LeanRight                                      = 0,
    LeanLeft                                       = 1,
    ETakeCoverLeanAnimType_MAX                     = 2

};


// Enum  /Script/SGFramework.ECharacterBattleStateType
enum class ECharacterBattleStateType : uint8_t
{
    ECharacterBattleStateType_JoinTeam             = 0,
    ECharacterBattleStateType_Idle                 = 1,
    ECharacterBattleStateType_MatchStart           = 2,
    ECharacterBattleStateType_LeaveTeam            = 3,
    ECharacterBattleStateType_MAX                  = 4

};


// Enum  /Script/SGFramework.ERelaxType
enum class ERelaxType : uint8_t
{
    ERelaxType_None                                = 0,
    ERelaxType_Idle                                = 1,
    ERelaxType_WeaponSway                          = 2,
    ERelaxType_CloseADS                            = 3,
    ERelaxType_CloseBag                            = 4,
    ERelaxType_ContinuousMoveStop                  = 5,
    ERelaxType_MAX                                 = 6

};


// Enum  /Script/SGFramework.EPreviewCharacterSceneTwoBoneIKType
enum class EPreviewCharacterSceneTwoBoneIKType : uint8_t
{
    LeftHand                                       = 0,
    RightHand                                      = 1,
    EPreviewCharacterSceneTwoBoneIKType_MAX        = 2

};


// Enum  /Script/SGFramework.ESteeringStatus
enum class ESteeringStatus : uint8_t
{
    None                                           = 0,
    TurnLeft                                       = 1,
    Middle                                         = 2,
    TurnRight                                      = 3,
    ESteeringStatus_MAX                            = 4

};


// Enum  /Script/SGFramework.ETacticalPistolAnimationType
enum class ETacticalPistolAnimationType : uint8_t
{
    None                                           = 0,
    IdleToTactical                                 = 1,
    TacticalToMainWeapon                           = 2,
    TacticalToPistol                               = 3,
    TacticalToPistol_Fast                          = 4,
    PistolToTactical                               = 5,
    TacticalTakeUp                                 = 6,
    TacticalPutDown                                = 7,
    ETacticalPistolAnimationType_MAX               = 8

};


// Enum  /Script/SGFramework.EFallingAnimType
enum class EFallingAnimType : uint8_t
{
    None                                           = 0,
    Low                                            = 1,
    Medium                                         = 2,
    High                                           = 3,
    EFallingAnimType_MAX                           = 4

};


// Enum  /Script/SGFramework.ERootYawOffsetMode
enum class ERootYawOffsetMode : uint8_t
{
    Accumlate                                      = 0,
    Hold                                           = 1,
    BlendOut                                       = 2,
    ERootYawOffsetMode_MAX                         = 3

};


// Enum  /Script/SGFramework.ETurnInPlaceState
enum class ETurnInPlaceState : uint8_t
{
    Idle                                           = 0,
    TurnInPlaceRotation                            = 1,
    TurnInPlaceRecovery                            = 2,
    ETurnInPlaceState_MAX                          = 3

};


// Enum  /Script/SGFramework.ELocomotionType
enum class ELocomotionType : uint8_t
{
    Normal                                         = 0,
    Fracture                                       = 1,
    ELocomotionType_MAX                            = 2

};


// Enum  /Script/SGFramework.EAnimTransitionState
enum class EAnimTransitionState : uint8_t
{
    None                                           = 0,
    Stand_To_Prone                                 = 1,
    Prone_To_Stand                                 = 2,
    Crouch_To_Prone                                = 3,
    Prone_To_Crouch                                = 4,
    Sprint_To_Prone                                = 5,
    Sprint_To_Crouch                               = 6,
    Sprint_To_Stand                                = 7,
    Stand_To_Sprint                                = 8,
    Stand_To_Run                                   = 9,
    Run_To_Stand                                   = 10,
    Stand_To_Casual                                = 11,
    Casual_To_Stand                                = 12,
    Sprint_To_Crouch_Sliding                       = 13,
    Sprint_To_Run                                  = 14,
    Stand_To_Crouch                                = 15,
    Crouch_To_Stand                                = 16,
    Run_To_Sprint                                  = 17,
    EAnimTransitionState_MAX                       = 18

};


// Enum  /Script/SGFramework.EAnimDir
enum class EAnimDir : uint8_t
{
    None                                           = 0,
    Forward                                        = 1,
    Right                                          = 2,
    Back                                           = 3,
    Left                                           = 4,
    EAnimDir_MAX                                   = 5

};


// Enum  /Script/SGFramework.EAnimSpeedType
enum class EAnimSpeedType : uint8_t
{
    StandWalkF                                     = 0,
    StandWalkB                                     = 1,
    StandWalkL                                     = 2,
    StandWalkR                                     = 3,
    StandRunF                                      = 4,
    StandRunL                                      = 5,
    StandRunR                                      = 6,
    StandRunB                                      = 7,
    StandSprint                                    = 8,
    CrouchWalk                                     = 9,
    CrouchRunF                                     = 10,
    CrouchRunB                                     = 11,
    Max                                            = 12

};


// Enum  /Script/SGFramework.EDiveAndSlideStance
enum class EDiveAndSlideStance : uint8_t
{
    Stand                                          = 0,
    Slide                                          = 1,
    Dive                                           = 2,
    Max                                            = 3

};


// Enum  /Script/SGFramework.EAnimStance
enum class EAnimStance : uint8_t
{
    Stand                                          = 0,
    Crouch                                         = 1,
    Prone                                          = 2,
    DBNO                                           = 3,
    Max                                            = 4

};


// Enum  /Script/SGFramework.EMovementStance
enum class EMovementStance : uint8_t
{
    Idle                                           = 0,
    Walk                                           = 1,
    Run                                            = 2,
    Sprint                                         = 3,
    EMovementStance_MAX                            = 4

};


// Enum  /Script/SGFramework.EWeaponType
enum class EWeaponType : uint8_t
{
    Unarmed                                        = 0,
    Rifle                                          = 1,
    Pistol                                         = 2,
    Throwable                                      = 3,
    Melle                                          = 4,
    EWeaponType_MAX                                = 5

};


// Enum  /Script/SGFramework.ECameraAnimatedScaler
enum class ECameraAnimatedScaler : uint8_t
{
    ECameraAnimatedScaler_Large                    = 0,
    ECameraAnimatedScaler_Small                    = 1,
    ECameraAnimatedScaler_None                     = 2,
    ECameraAnimatedScaler_MAX                      = 3

};


// Enum  /Script/SGFramework.ESGAvatarComponentType
enum class ESGAvatarComponentType : uint8_t
{
    None                                           = 0,
    InventoryEquipMeshComponent                    = 1,
    ESGAvatarComponentType_MAX                     = 2

};


// Enum  /Script/SGFramework.ECameraShakeAdditiveType
enum class ECameraShakeAdditiveType : uint8_t
{
    FiringTime                                     = 0,
    FiringCount                                    = 1,
    ECameraShakeAdditiveType_MAX                   = 2

};


// Enum  /Script/SGFramework.ECameraShakeAxis
enum class ECameraShakeAxis : uint8_t
{
    ECameraShakeAxis_X                             = 0,
    ECameraShakeAxis_Y                             = 1,
    ECameraShakeAxis_Z                             = 2,
    ECameraShakeAxis_Pitch                         = 3,
    ECameraShakeAxis_Yaw                           = 4,
    ECameraShakeAxis_Roll                          = 5,
    ECameraShakeAxis_FOV                           = 6,
    ECameraShakeAxis_MAX                           = 7

};


// Enum  /Script/SGFramework.ELandingTypes
enum class ELandingTypes : uint8_t
{
    LandingTypes_None                              = 0,
    LandingTypes_Light                             = 1,
    LandingTypes_Heavy                             = 2,
    LandingTypes_Death                             = 3,
    LandingTypes_MAX                               = 4

};


// Enum  /Script/SGFramework.ECameraViewportTypes
enum class ECameraViewportTypes : uint8_t
{
    CVT_16to9_Full                                 = 0,
    CVT_16to9_VertSplit                            = 1,
    CVT_16to9_HorizSplit                           = 2,
    CVT_4to3_Full                                  = 3,
    CVT_4to3_HorizSplit                            = 4,
    CVT_4to3_VertSplit                             = 5,
    CVT_Max                                        = 6

};


// Enum  /Script/SGFramework.EAISpecialAudioEvt
enum class EAISpecialAudioEvt : uint8_t
{
    None                                           = 0,
    HitGrunt                                       = 1,
    DeathGrunt                                     = 2,
    EAISpecialAudioEvt_MAX                         = 3

};


// Enum  /Script/SGFramework.EAnimalMovementState
enum class EAnimalMovementState : uint8_t
{
    None                                           = 0,
    Idle                                           = 1,
    Moving                                         = 2,
    EAnimalMovementState_MAX                       = 3

};


// Enum  /Script/SGFramework.ESGCharDamageBebugType
enum class ESGCharDamageBebugType : uint8_t
{
    None                                           = 0,
    FallDamage                                     = 1,
    JumpVehicleDamage                              = 2,
    ESGCharDamageBebugType_MAX                     = 3

};


// Enum  /Script/SGFramework.EDBNOEndReason
enum class EDBNOEndReason : uint8_t
{
    DBNOEndReason_None                             = 0,
    DBNOEndReason_BeRescuered                      = 1,
    DBNOEndReason_BeKilledByOthers                 = 2,
    DBNOEndReason_LostEndurance                    = 3,
    DBNOEndReason_MAX                              = 4

};


// Enum  /Script/SGFramework.ECancelEmplaceGunAbilityReason
enum class ECancelEmplaceGunAbilityReason : uint8_t
{
    Reconnect                                      = 0,
    CurrentWeaponChanged                           = 1,
    ServerSetEmplaceGunInfo                        = 2,
    MovementModeChanged                            = 3,
    OutOfDistance                                  = 4,
    PoseChanged                                    = 5,
    ECancelEmplaceGunAbilityReason_MAX             = 6

};


// Enum  /Script/SGFramework.ECharacterFoodStateType
enum class ECharacterFoodStateType : uint8_t
{
    Normal                                         = 0,
    SlightLackInFood                               = 1,
    MediumLackInFood                               = 2,
    HeavyLackInFood                                = 3,
    ECharacterFoodStateType_MAX                    = 4

};


// Enum  /Script/SGFramework.EFootPrintType
enum class EFootPrintType : uint8_t
{
    Bleed                                          = 0,
    BleedProne                                     = 1,
    SnowDefault                                    = 2,
    SnowThin                                       = 3,
    SandDefault                                    = 4,
    SandThin                                       = 5,
    Max                                            = 6

};


// Enum  /Script/SGFramework.FWeatherFootPrintType
enum class FWeatherFootPrintType : uint8_t
{
    None                                           = 0,
    Snow                                           = 1,
    Sand                                           = 2,
    FWeatherFootPrintType_MAX                      = 3

};


// Enum  /Script/SGFramework.EWeatherSoundType
enum class EWeatherSoundType : uint8_t
{
    None                                           = 0,
    Rain                                           = 1,
    Snow                                           = 2,
    EWeatherSoundType_MAX                          = 3

};


// Enum  /Script/SGFramework.EFootEffectDir
enum class EFootEffectDir : uint8_t
{
    None                                           = 0,
    Left                                           = 1,
    Right                                          = 2,
    EFootEffectDir_MAX                             = 3

};


// Enum  /Script/SGFramework.EForbidThrowItemType
enum class EForbidThrowItemType : uint8_t
{
    E_NoneOperation                                = 0,
    E_VehicleOperation                             = 1,
    E_MaxOperation                                 = 32,
    E_MAX                                          = 33

};


// Enum  /Script/SGFramework.ESGMovementLockType
enum class ESGMovementLockType : uint8_t
{
    ESGMovementLockType_None                       = 0,
    ESGMovementLockType_LoadProtect                = 1,
    ESGMovementLockType_RoundLoad                  = 2,
    ESGMovementLockType_Performance                = 3,
    ESGMovementLockType_Destroy                    = 4,
    ESGMovementLockType_Reconnect                  = 5,
    ESGMovementLockType_UseInv                     = 6,
    ESGMovementLockType_Zipline                    = 7,
    ESGMovementLockType_WeakNet                    = 8,
    ESGMovementLockType_BlockAccount               = 9,
    ESGMovementLockType_Tutorial                   = 10,
    ESGMovementLockType_Reborn                     = 11,
    ESGMovementLockType_MAX                        = 12

};


// Enum  /Script/SGFramework.ESGMaxSpeedFactor
enum class ESGMaxSpeedFactor : uint32_t
{
    None                                           = 0,
    MaxSpeedFactor_StandSprintAngleSpeedSamples    = 1,
    MaxSpeedFactor_MaxCrouchSprintSpeed            = 2,
    MaxSpeedFactor_MaxStandSprintSpeed             = 4,
    MaxSpeedFactor_MoveRatioForWeapon              = 8,
    MaxSpeedFactor_MaxCrouchSprintExhaustedSpeed   = 16,
    MaxSpeedFactor_MaxStandSprintExhaustedSpeed    = 32,
    MaxSpeedFactor_MaxStandSilentWalkSpeed         = 64,
    MaxSpeedFactor_StandRunAngleSpeedSamples       = 128,
    MaxSpeedFactor_StandSilentWalkSpeedScale       = 256,
    MaxSpeedFactor_MaxProneBackwardSpeed           = 512,
    MaxSpeedFactor_MaxProneStrafeSpeed             = 1024,
    MaxSpeedFactor_MaxDBNOBackwardSpeed            = 2048,
    MaxSpeedFactor_MaxDBNOStrafeSpeed              = 4096,
    MaxSpeedFactor_MaxCrouchBackwardSpeed          = 8192,
    MaxSpeedFactor_MaxCrouchStrafeSpeed            = 16384,
    MaxSpeedFactor_InTrap                          = 32768,
    MaxSpeedFactor_MaxStandBackwardSpeed           = 65536,
    MaxSpeedFactor_MaxStandStrafeSpeed             = 131072,
    MaxSpeedFactor_StandLeanWalkSpeedScale         = 262144,
    MaxSpeedFactor_SlopeFactor                     = 524288,
    MaxSpeedFactor_WeaponMovingScale               = 1048576,
    MaxSpeedFactor_StunEffectMovementSpeedScale    = 2097152,
    MaxSpeedFactor_OverWeightSpeedScale            = 4194304,
    MaxSpeedFactor_AbilityMovementSpeedScale       = 8388608,
    MaxSpeedFactor_MovementSpeedScaleWhenLegOutOfEndurance = 16777216,
    MaxSpeedFactor_MovementForbiddenScale          = 33554432,
    MaxSpeedFactor_CalTakeDamageMovementScale      = 67108864,
    MaxSpeedFactor_SprintMaxSpeedLowerLimit        = 134217728,
    MaxSpeedFactor_WalkAndSprintAbilityMovementSpeedScale = 268435456,
    MaxSpeedFactor_Reserve29                       = 536870912,
    MaxSpeedFactor_Reserve30                       = 1073741824,
    MaxSize                                        = 1073741825,
    ESGMaxSpeedFactor_MAX                          = 1073741826

};


// Enum  /Script/SGFramework.ELadderClimbingInputType
enum class ELadderClimbingInputType : uint8_t
{
    None                                           = 0,
    Up                                             = 1,
    Down                                           = 2,
    Jump                                           = 3,
    ELadderClimbingInputType_MAX                   = 4

};


// Enum  /Script/SGFramework.ELadderClimbingDirectionType
enum class ELadderClimbingDirectionType : uint8_t
{
    None                                           = 0,
    Left                                           = 1,
    Right                                          = 2,
    Forward                                        = 3,
    Backward                                       = 4,
    ELadderClimbingDirectionType_MAX               = 5

};


// Enum  /Script/SGFramework.ELadderClimbingStateType
enum class ELadderClimbingStateType : uint8_t
{
    None                                           = 0,
    Enter                                          = 1,
    Exit                                           = 2,
    Loop                                           = 3,
    Idle                                           = 4,
    Max                                            = 5

};


// Enum  /Script/SGFramework.EVaultFailReason
enum class EVaultFailReason : uint8_t
{
    EVaultFailReason_None                          = 0,
    EVaultFailReason_NotEnoughRoomToStand          = 1,
    EVaultFailReason_ExceedMaxFloorAngleToStand    = 2,
    EVaultFailReason_ExceedApexPointAdjustmentMaxErrorTolerance = 3,
    EVaultFailReason_NotEnoughRoomToPass           = 4,
    EVaultFailReason_ServerValidationFailedAndRollBack = 5,
    EVaultFailReason_VaultPathDistanceTooFar       = 6,
    EVaultFailReason_VaultPathDistanceTooShort     = 7,
    EVaultFailReason_VaultHeightLowThanThreshold   = 8,
    EVaultFailReason_VaultHeightHighThanThreshold  = 9,
    EVaultFailReason_NoObstacle                    = 10,
    EVaultFailReason_ExceedAngleTowardsObstacleTolerance = 11,
    EVaultFailReason_VaultPathBlockHit             = 12,
    EVaultFailReason_Unknown                       = 13,
    EVaultFailReason_MAX                           = 14

};


// Enum  /Script/SGFramework.EObstacleHeightLevel
enum class EObstacleHeightLevel : uint8_t
{
    EObstacleHeight_None                           = 0,
    EObstacleHeight_Low                            = 1,
    EObstacleHeight_High                           = 2,
    EObstacleHeight_MAX                            = 3

};


// Enum  /Script/SGFramework.EVaultChoice
enum class EVaultChoice : uint8_t
{
    EChoice_None                                   = 0,
    EChoice_Climb                                  = 1,
    EChoice_Vault                                  = 2,
    EChoice_MAX                                    = 3

};


// Enum  /Script/SGFramework.EVaultPhase
enum class EVaultPhase : uint8_t
{
    EVaultPhase_None                               = 0,
    EVaultPhase_Vaulting                           = 1,
    EVaultPhase_MAX                                = 2

};


// Enum  /Script/SGFramework.EZiplineMoveState
enum class EZiplineMoveState : uint8_t
{
    None                                           = 0,
    StartMoveToEntry                               = 1,
    StartEnter                                     = 2,
    ZiplineMoving                                  = 3,
    StartLeave                                     = 4,
    Max                                            = 5

};


// Enum  /Script/SGFramework.ECaptureType
enum class ECaptureType : uint8_t
{
    None                                           = 0,
    CaptureOnce                                    = 1,
    CaptureAlways                                  = 2,
    ECaptureType_MAX                               = 3

};


// Enum  /Script/SGFramework.ESGRagdollStage
enum class ESGRagdollStage : uint8_t
{
    None                                           = 0,
    RagdollPrestart                                = 1,
    RagdollStart                                   = 2,
    RagdollStop                                    = 3,
    RagdollBaked_Local                             = 4,
    RagdollBaked_WaitAvatarLoad                    = 5,
    RagdollBaked_ServerOverride                    = 6,
    ESGRagdollStage_MAX                            = 7

};


// Enum  /Script/SGFramework.ECharacterFlashBurnStateType
enum class ECharacterFlashBurnStateType : uint8_t
{
    None                                           = 0,
    Normal                                         = 1,
    MildFlashBurn                                  = 2,
    ModerateFlashBurn                              = 3,
    SevereFlashBurn                                = 4,
    ECharacterFlashBurnStateType_MAX               = 5

};


// Enum  /Script/SGFramework.ECharacterTearGasStateType
enum class ECharacterTearGasStateType : uint8_t
{
    Normal                                         = 0,
    SlightTearGas                                  = 1,
    MediumTearGas                                  = 2,
    ECharacterTearGasStateType_MAX                 = 3

};


// Enum  /Script/SGFramework.ESGCompSigOwnerType
enum class ESGCompSigOwnerType : uint8_t
{
    Player                                         = 0,
    AI                                             = 1,
    Vehicle                                        = 2,
    Controller                                     = 3,
    ESGCompSigOwnerType_MAX                        = 4

};


// Enum  /Script/SGFramework.ESwitchMeshAnimTickOptFailReason
enum class ESwitchMeshAnimTickOptFailReason : uint8_t
{
    None                                           = 0,
    SwitchFailReason_Ragdoll                       = 1,
    ESwitchMeshAnimTickOptFailReason_MAX           = 2

};


// Enum  /Script/SGFramework.ERestrictActionInWater
enum class ERestrictActionInWater : uint8_t
{
    None                                           = 0,
    Prone                                          = 1,
    Crouch                                         = 2,
    MAX                                            = 3

};


// Enum  /Script/SGFramework.ECameraReactionAxis
enum class ECameraReactionAxis : uint8_t
{
    Pitch                                          = 0,
    Yaw                                            = 1,
    Roll                                           = 2,
    ECameraReactionAxis_MAX                        = 3

};


// Enum  /Script/SGFramework.ECharacterSoundSpecialConfig
enum class ECharacterSoundSpecialConfig : uint8_t
{
    None                                           = 0,
    QuietWhenDead                                  = 1,
    ECharacterSoundSpecialConfig_MAX               = 2

};


// Enum  /Script/SGFramework.EActionPostureType
enum class EActionPostureType : uint8_t
{
    None                                           = 0,
    Stand                                          = 1,
    Crouch                                         = 2,
    Prone                                          = 3,
    Move                                           = 4,
    Sprint                                         = 5,
    Silent                                         = 6,
    Lean                                           = 7,
    Aim                                            = 8,
    Jump                                           = 9,
    ThrowWeapon                                    = 10,
    UseInventory                                   = 11,
    EActionPostureType_MAX                         = 12

};


// Enum  /Script/SGFramework.EStationaryStateBattleResultType
enum class EStationaryStateBattleResultType : uint8_t
{
    None                                           = 0,
    EnemyDied                                      = 1,
    SelfDied                                       = 2,
    NoOneDied                                      = 3,
    EStationaryStateBattleResultType_MAX           = 4

};


// Enum  /Script/SGFramework.EStationaryStateEarlyStageTacticalBehaviorType
enum class EStationaryStateEarlyStageTacticalBehaviorType : uint8_t
{
    None                                           = 0,
    Lean                                           = 1,
    Throw                                          = 2,
    Fire                                           = 3,
    ADS                                            = 4,
    BeginUseInventory                              = 5,
    UseInventorySucceed                            = 6,
    EStationaryStateEarlyStageTacticalBehaviorType_MAX = 7

};


// Enum  /Script/SGFramework.EStationaryStateEarlyStageExitType
enum class EStationaryStateEarlyStageExitType : uint8_t
{
    None                                           = 0,
    NotExited                                      = 1,
    SilentExit                                     = 2,
    NormalExit                                     = 3,
    EStationaryStateEarlyStageExitType_MAX         = 4

};


// Enum  /Script/SGFramework.EStationaryStateMovementType
enum class EStationaryStateMovementType : uint8_t
{
    None                                           = 0,
    SilentStand                                    = 1,
    SilentCrouch                                   = 2,
    SilentProne                                    = 3,
    NormalStand                                    = 4,
    NormalCrouch                                   = 5,
    NormalProne                                    = 6,
    Sprint                                         = 7,
    EStationaryStateMovementType_MAX               = 8

};


// Enum  /Script/SGFramework.ECharacterMoveDistanceType
enum class ECharacterMoveDistanceType : uint8_t
{
    StandSilentWalk                                = 0,
    StandWalk                                      = 1,
    StandSprint                                    = 2,
    CrouchSilentWalk                               = 3,
    CrouchWalk                                     = 4,
    CrouchSprint                                   = 5,
    ProneSilentWalk                                = 6,
    DBNO                                           = 7,
    Max                                            = 8

};


// Enum  /Script/SGFramework.EAvatarDisableTickReason
enum class EAvatarDisableTickReason : uint8_t
{
    AvatarDisableTickReason_None                   = 0,
    AvatarDisableTickReason_OffScreen              = 1,
    AvatarDisableTickReason_SlaveComponent         = 2,
    AvatarDisableTickReason_MAX                    = 3

};


// Enum  /Script/SGFramework.EAvatarHiddenReason
enum class EAvatarHiddenReason : uint32_t
{
    AvatarHiddenReason_None                        = 0,
    AvatarHiddenReason_FPPHidden                   = 1,
    AvatarHiddenReason_LayerHidden                 = 2,
    AvatarHiddenReason_MergeHidden                 = 4,
    AvatarHiddenReason_FarHidden                   = 8,
    AvatarHiddenReason_BadgeHidden                 = 16,
    AvatarHiddenReason_ForceHidden                 = 32,
    AvatarHiddenReason_InVehicleHidden             = 64,
    AvatarHiddenReason_ExpandAvatar                = 128,
    AvatarHiddenReason_CharacterHidden             = 256,
    AvatarHiddenReason_MAX                         = 257

};


// Enum  /Script/SGFramework.ECharacterHiddenReason
enum class ECharacterHiddenReason : uint8_t
{
    CharacterHiddenReason_None                     = 0,
    CharacterHiddenReason_EscapeHidden             = 1,
    CharacterHiddenReason_3PPerformanceHidden      = 2,
    CharacterHiddenReason_LoadProtect              = 4,
    CharacterHiddenReason_Destroy                  = 8,
    CharacterHiddenReason_PlaySpawnEffect          = 16,
    CharacterHiddenReason_MAX                      = 17

};


// Enum  /Script/SGFramework.SpringVecComponent
enum class SpringVecComponent : uint8_t
{
    X                                              = 0,
    Y                                              = 1,
    Z                                              = 2,
    SpringVecComponent_MAX                         = 3

};


// Enum  /Script/SGFramework.EUAMTarget
enum class EUAMTarget : uint8_t
{
    RootRotation                                   = 0,
    HandsPosition                                  = 1,
    HandsRotation                                  = 2,
    EUAMTarget_MAX                                 = 3

};


// Enum  /Script/SGFramework.EMorphTargetType
enum class EMorphTargetType : uint8_t
{
    None                                           = 0,
    Helmet                                         = 1,
    Vest                                           = 2,
    Belt                                           = 3,
    Backpack                                       = 4,
    Headset                                        = 5,
    FaceCover                                      = 6,
    EyeWear                                        = 7,
    Watch                                          = 8,
    Armor                                          = 9,
    Max                                            = 10

};


// Enum  /Script/SGFramework.ELadderClimbExitType
enum class ELadderClimbExitType : uint8_t
{
    Top                                            = 0,
    Bottom                                         = 1,
    Fall                                           = 2,
    ELadderClimbExitType_MAX                       = 3

};


// Enum  /Script/SGFramework.ELadderClimbEnterType
enum class ELadderClimbEnterType : uint8_t
{
    Top                                            = 0,
    Bottom                                         = 1,
    ELadderClimbEnterType_MAX                      = 2

};


// Enum  /Script/SGFramework.ECharacterMeshBoneType
enum class ECharacterMeshBoneType : uint8_t
{
    Head                                           = 0,
    Pelvis                                         = 1,
    Spine                                          = 2,
    ECharacterMeshBoneType_MAX                     = 3

};


// Enum  /Script/SGFramework.ECharacterMeshPolicy
enum class ECharacterMeshPolicy : uint8_t
{
    None                                           = 0,
    Game                                           = 1,
    Lobby                                          = 2,
    ECharacterMeshPolicy_MAX                       = 3

};


// Enum  /Script/SGFramework.EServerMoveResultType
enum class EServerMoveResultType : uint8_t
{
    MoveResult_None                                = 0,
    MoveResult_UseClientLoc                        = 1,
    MoveResult_UseServerLoc                        = 2,
    MoveResult_MovementModeMismatch                = 3,
    MoveResult_LargeLocDiff                        = 4,
    MoveResult_TimeDilationCheat                   = 5,
    MoveResult_ForcePosUpdate                      = 6,
    MoveResult_MAX                                 = 7

};


// Enum  /Script/SGFramework.ESprintReloadType
enum class ESprintReloadType : uint8_t
{
    None                                           = 0,
    CanSprintReload                                = 1,
    HiPriCanNotSprintReload                        = 2,
    ESprintReloadType_MAX                          = 3

};


// Enum  /Script/SGFramework.ECharacterSprintFailureReason
enum class ECharacterSprintFailureReason : uint8_t
{
    SprintFailureReason_None                       = 0,
    SprintFailureReason_InTrap                     = 1,
    SprintFailureReason_NotFoundSprintComponent    = 2,
    SprintFailureReason_DBNO                       = 3,
    SprintFailureReason_Crouch                     = 4,
    SprintFailureReason_Leaning                    = 5,
    SprintFailureReason_Dead                       = 6,
    SprintFailureReason_Prone                      = 7,
    SprintFailureReason_NoWeapon                   = 8,
    SprintFailureReason_IsSprintForbidden          = 9,
    SprintFailureReason_WeaponCanNotSprint         = 10,
    SprintFailureReason_PlayUpperBodyAnim          = 11,
    SprintFailureReason_Aim                        = 12,
    SprintFailureReason_InStunning                 = 13,
    SprintFailureReason_SilentWalk                 = 14,
    SprintFailureReason_NotMoveForward             = 15,
    SprintFailureReason_NotMovingOnGround          = 16,
    SprintFailureReason_LowerEnergyEmpty           = 17,
    SprintFailureReason_CompleteOverweight         = 18,
    SprintFailureReason_LegBoneBreak               = 19,
    SprintFailureReason_RescuingTeammate           = 20,
    SprintFailureReason_TutorialLimit              = 21,
    SprintFailureReason_Weapon_PlayAnim            = 22,
    SprintFailureReason_Weapon_NotValid            = 23,
    SprintFailureReason_Weapon_IsZooming           = 24,
    SprintFailureReason_Weapon_NoSprintComponent   = 25,
    SprintFailureReason_Weapon_DoingWeaponOperation = 26,
    SprintFailureReason_Weapon_IsShooting          = 27,
    SprintFailureReason_Weapon_SwitchingWeapon     = 28,
    SprintFailureReason_Weapon_InAbility           = 29,
    SprintFailureReason_Weapon_SwitchFireMode      = 30,
    SprintFailureReason_Weapon_CheckMagazine       = 31,
    SprintFailureReason_Weapon_ReleaseHoldOpen     = 32,
    SprintFailureReason_Weapon_KeepPreFire         = 33,
    SprintFailureReason_Weapon_Firing              = 34,
    SprintFailureReason_Sliding                    = 35,
    SprintFailureReason_Succeed                    = 36,
    SprintFailureReason_MAX                        = 37

};


// Enum  /Script/SGFramework.ECharacterPose
enum class ECharacterPose : uint8_t
{
    CharacterPose_Stand                            = 0,
    CharacterPose_Crouch                           = 1,
    CharacterPose_Prone                            = 2,
    CharacterPose_MAX                              = 3

};


// Enum  /Script/SGFramework.ELeftHandIKReason
enum class ELeftHandIKReason : uint8_t
{
    LeftHandIKReason_None                          = 0,
    LeftHandIKReason_WeaponTraceObstacle           = 1,
    LeftHandIKReason_Todo                          = 2,
    LeftHandIKReason_MAX                           = 3

};


// Enum  /Script/SGFramework.ESGCharacterVehicleSyncType
enum class ESGCharacterVehicleSyncType : uint8_t
{
    None                                           = 0,
    AttachCharacter                                = 1,
    DetachCharacter                                = 2,
    SwitchSeating                                  = 3,
    ESGCharacterVehicleSyncType_MAX                = 4

};


// Enum  /Script/SGFramework.ESGCharacterDisplayPolicy
enum class ESGCharacterDisplayPolicy : uint8_t
{
    ESGCharacterDisplayPolicy_None                 = 0,
    ESGCharacterDisplayPolicy_1P                   = 1,
    ESGCharacterDisplayPolicy_LOD0                 = 2,
    ESGCharacterDisplayPolicy_LOD1                 = 3,
    ESGCharacterDisplayPolicy_LOD2                 = 4,
    ESGCharacterDisplayPolicy_LOD3                 = 5,
    ESGCharacterDisplayPolicy_LOD4                 = 6,
    ESGCharacterDisplayPolicy_MAX                  = 7

};


// Enum  /Script/SGFramework.WeaponType
enum class WeaponType : uint8_t
{
    SHORT                                          = 0,
    MID                                            = 1,
    LONG                                           = 2,
    WeaponType_MAX                                 = 3

};


// Enum  /Script/SGFramework.CollapseState
enum class CollapseState : uint8_t
{
    NONE                                           = 0,
    PULL                                           = 1,
    RESET                                          = 2,
    CollapseState_MAX                              = 3

};


// Enum  /Script/SGFramework.ESGCompetitionStatusType
enum class ESGCompetitionStatusType : uint8_t
{
    E_None                                         = 0,
    E_Die                                          = 1,
    E_EscapeSuccess                                = 2,
    E_Hit                                          = 3,
    E_DBNO                                         = 4,
    E_Escapeing                                    = 5,
    E_MAX                                          = 32

};


// Enum  /Script/SGFramework.ESGCompSignificanceVolumeRelevantType
enum class ESGCompSignificanceVolumeRelevantType : uint8_t
{
    SignificanceVolumeRelevantType_Mutex           = 0,
    SignificanceVolumeRelevantType_Compatible      = 1,
    SignificanceVolumeRelevantType_MAX             = 2

};


// Enum  /Script/SGFramework.ESearchEffectDoAction
enum class ESearchEffectDoAction : uint8_t
{
    ESearchEffectDoAction_None                     = 0,
    ESearchEffectDoAction_PlaySound                = 1,
    ESearchEffectDoAction_MAX                      = 2

};


// Enum  /Script/SGFramework.ESGrosshairFadeType
enum class ESGrosshairFadeType : uint8_t
{
    None                                           = 0,
    Spread                                         = 1,
    FadeIn                                         = 2,
    FadeOut                                        = 3,
    Spread_Aim                                     = 4,
    FadeIn_Aim                                     = 5,
    FadeOut_Aim                                    = 6,
    ESGrosshairFadeType_MAX                        = 7

};


// Enum  /Script/SGFramework.ESGrosshairHiddenType
enum class ESGrosshairHiddenType : uint8_t
{
    None                                           = 0,
    Visible                                        = 1,
    Visible_Aim                                    = 2,
    Hidden                                         = 3,
    Hidden_Sprinting                               = 4,
    Hidden_WeaponFolded                            = 5,
    Hidden_GameplayTag                             = 6,
    Max                                            = 7

};


// Enum  /Script/SGFramework.EDataTableType
enum class EDataTableType : uint32_t
{
    DataTable_Default                              = 0,
    AnimSet_AllWeapon                              = 1,
    AnimSet_WeaponBase                             = 2,
    WeaponParameter                                = 3,
    ModePickupLevelConfigsMappings                 = 4,
    UACommonItemTable                              = 5,
    UAWeaponDetailTable                            = 6,
    UAItemContextMenuTable                         = 7,
    UAInventoryBPItemIDTable                       = 8,
    UABattleMapTable                               = 9,
    UAVestBagGridTable                             = 10,
    UAErrorCodeTable                               = 11,
    UALanguageTextTable                            = 12,
    UADeviceInfoTable                              = 13,
    UACharacterLevelTable                          = 14,
    UAGlobalNumTable                               = 15,
    UAGachaMapTable                                = 16,
    UAModuleContextTable                           = 17,
    UAModuleTable                                  = 18,
    UAServiceTable                                 = 19,
    UAPanelTable                                   = 20,
    UAStatisTable                                  = 21,
    UABattleResultTable                            = 22,
    UAWeaponAssembleTable                          = 23,
    DataTable_MAX                                  = 24,
    UATaskConfTable                                = 25,
    UATaskTargetConfTable                          = 26,
    UATaskActiveRewardConfTable                    = 27,
    UATaskKillTargetConfTable                      = 28,
    UATaskCommitTargetConfTable                    = 29,
    UABusinessmanConfTable                         = 30,
    UATradeItemClassifyConfTable                   = 31,
    UATradeConfTable                               = 32,
    UABodyPartsTable                               = 33,
    UAFunctionControlTable                         = 34,
    UAMailTable                                    = 35,
    UAMallConfTable                                = 36,
    UAWeaponAffixTable                             = 37,
    UAContainerTable                               = 38,
    UAContainerRuleConfTable                       = 39,
    UAActConfigTable                               = 40,
    UAEquipSlotTable                               = 41,
    UAContextMenuLevel1Table                       = 42,
    UAContextMenuLevel2Table                       = 43,
    UAContextMenuPickUpTable                       = 44,
    UABuffIconConfTable                            = 45,
    UATaskTypeTable                                = 46,
    UAAmmoNumTable                                 = 47,
    DummyItemTable                                 = 48,
    UAGameModeTable                                = 49,
    UAGamePadMessageTable                          = 50,
    UALootPointInfoTable                           = 51,
    UABattleQuickChatTable                         = 52,
    UALootDropTable                                = 53,
    UAPlayModeTable                                = 54,
    UAArmorDetailConfTable                         = 55,
    WeaponMergeBlackList                           = 56,
    UABulletDetailConfTable                        = 57,
    UARookieStepTable                              = 58,
    UARookieDetailTable                            = 59,
    UARookieTriggerTable                           = 60,
    UARookieTriggerIDTable                         = 61,
    UARookieItemPickTable                          = 62,
    UALootDropOperationConfTable                   = 63,
    UADropItemConfTable                            = 64,
    UALootDropPoolConfTable                        = 65,
    UAGlobalTable                                  = 66,
    UAScopeScaleTable                              = 67,
    UAGlovesGestureTable                           = 68,
    UALandMarkTable                                = 69,
    UAMeleeWeaponDetailTable                       = 70,
    UAAISpawnAreaInfoTable                         = 71,
    UAAISpawnScavSpawnControllerTable              = 72,
    UAAISpawnBossSpawnControllerTable              = 74,
    UAAISpawnPMCConfigTable                        = 75,
    UAAISpawnPMCSpawnControllerTable               = 76,
    UAAISpawnElitTable                             = 77,
    UABattleQuickConductorTable                    = 78,
    UABattleQuickTeamTable                         = 79,
    UAEscapeTextTable                              = 80,
    UAEscapeInteractTextTable                      = 81,
    UACaptureTable                                 = 82,
    UABossTokenConfTable                           = 83,
    UAHUDSubTitleVOTable                           = 84,
    UAHUDSubTitleTextTable                         = 85,
    UALootDataInfosTable                           = 86,
    UALootReplaceConfTable                         = 87,
    UABattleQuickMapSignTable                      = 88,
    UALoadingImageTable                            = 89,
    UALoadingTipsTable                             = 90,
    UAAchieveTaskConfTable                         = 91,
    UAInventorySoundDiffusionTable                 = 92,
    UATraceTargetTable                             = 93,
    UAAISoundDiffusionTable                        = 95,
    UASafeLootLimitConfTable                       = 96,
    UASafePoolLimitValueConfTable                  = 97,
    UAMissionFlowClassTable                        = 98,
    UAActivityTemplateMissionTable                 = 99,
    UAScreenEffectPaddingTable                     = 100,
    UABrokenImageConfTable                         = 101,
    UALootResourceConfTable                        = 102,
    AISpawnGroupDataTable                          = 103,
    AIPerformanceDataTable                         = 104,
    AIWeaponConfigDataTable                        = 105,
    AINameDataTable                                = 106,
    EventAIIDModifierDataTable                     = 107,
    AISceneEventDataTable                          = 108,
    AITrackLOGTemplateDataTable                    = 109,
    UAHUDConfigTable                               = 110,
    UAFriRecommConfTable                           = 111,
    UAResourceListConfTable                        = 112,
    SGInventoryDataAssetTable                      = 113,
    SGInventoryGAData                              = 114,
    UARankedLevelTable                             = 115,
    UABrilliantTimeReplayTable                     = 116,
    UATeamVoiceTable                               = 117,
    ServerKey2Text                                 = 118,
    ActReplaceDesc                                 = 119,
    AIEventAvatarTable                             = 120,
    UAGuaranteeCheckItemConfTable                  = 121,
    UAGuaranteeContainerConfTable                  = 122,
    UAGuaranteedPoolConfTable                      = 123,
    UAGuaranteeGenItemConfTable                    = 124,
    UAGuaranteeLimitStrategyConfTable              = 125,
    UAGuaranteedUseAttrConfTable                   = 126,
    UAConsumablesUseAwardConfTable                 = 127,
    UAFactionRelationTypeTable                     = 128,
    SGInventoryGADataAuto                          = 129,
    UAAIUniqueItemInfoTable                        = 130,
    UALoseDropTable                                = 131,
    UADurabilityChangeTable                        = 132,
    SGAdviseInvPriorityTable                       = 133,
    UALootProtectionConfTable                      = 134,
    UAProtectionTypeConfTable                      = 135,
    UATraceStyleTable                              = 136,
    UAWeaponSkinConfTable                          = 137,
    SGAdviseGrenadeTable                           = 138,
    AccountBanReasonTable                          = 139,
    UAParadropConfigTable                          = 140,
    AIFactionDataTable                             = 141,
    UAStandaloneWeatherTable                       = 142,
    UAModeWeatherTable                             = 143,
    UAShockConfTable                               = 144,
    UALootDropActivityConfTable                    = 145,
    UALootDropActivityPoolConfTable                = 146,
    UALootDropControlConfTable                     = 147,
    UALootProtectionItemsConfTable                 = 148,
    UADeliverCargosConfTable                       = 149,
    SGCharacterCompSignificance                    = 150,
    UAEquipmentSkinConfTable                       = 151,
    UATutorialEventTable                           = 152,
    UAConsumablesDetailConfTable                   = 153,
    UAConsumablesBuffConfTable                     = 154,
    UABanThrowsConfTable                           = 155,
    UANationalFlagConfTable                        = 156,
    SGVehicleParams                                = 157,
    UANewTraceConfigTable                          = 158,
    UANewTraceStyleTable                           = 159,
    UANewTraceRuleTable                            = 160,
    UAPlayerEscapeShow                             = 161,
    UAAISpawnPlayerScavConfigTable                 = 162,
    UAAISpawnSupportTable                          = 163,
    UAAISpawnAntiCamperTable                       = 164,
    UAAISpawnByVectorTable                         = 165,
    UABattleEventTable                             = 166,
    UAModeWeatherImpactTable                       = 167,
    UAWeatherImpactDetailTable                     = 168,
    UAParadropWaveConfigTable                      = 169,
    UALootFactionItemConfTable                     = 170,
    UAScavAIDynamicLimitTable                      = 171,
    UAAvatarSetCfgTable                            = 172,
    UAAvatarSuitConfTable                          = 173,
    UAWeaponAvatarSetCfgTable                      = 174,
    UAAvatarDataTable                              = 175,
    UAExtraSkinConfTable                           = 176,
    UAShoppingStationConfTable                     = 177,
    UAShoppingStationTabConfigTable                = 178,
    UAShoppingStationItemConfTable                 = 179,
    UAShoppingStationGroupConfTable                = 180,
    AIAnimalSpawnDataTable                         = 181,
    AIAnimalTypeDataTable                          = 182,
    UASideClashConfTable                           = 183,
    AIPictureNameDataTable                         = 184,
    UAActivityInventoryAdditionDataTable           = 185,
    SGLoopMaterialItemTable                        = 186,
    AINameOverseaDataTable                         = 187,
    UAResourceTypeIconConfTable                    = 188,
    UAVehicleMachineDetailTable                    = 189,
    UABattleEventPointsTable                       = 190,
    AIBehaviorLODActionsTable                      = 191,
    UAAnnounceConfigTable                          = 192,
    UATaskReportAnnounceConfigTable                = 193,
    UAAnnounceStyleTable                           = 194,
    UAFactionMappingTable                          = 195,
    SGGamePlaySettingsTable                        = 196,
    UAVehiclePartDetailTable                       = 197,
    UADownloadConfTable                            = 198,
    UADownloadDisplayTable                         = 199,
    UAUnbanMapIdConfTable                          = 200,
    UAObDSListConfTable                            = 201,
    UAVirtualWeaponTable                           = 202,
    UAVirtualLaserTable                            = 203,
    UAVirtualFlashTable                            = 204,
    UAVirtualAmmoRelTable                          = 205,
    UAHostedInteractConfTable                      = 206,
    UALootLimitUserTagTable                        = 207,
    UAUnbanLootMapIdConfTable                      = 208,
    UAPVEStatisTable                               = 209,
    UADeathBoxSkinConfTable                        = 210,
    UAGiftPackTemplateConfTable                    = 211,
    AIRandEquipSuitPoolTable                       = 212,
    UAAvatarItemCfgTable                           = 213,
    UADownloadBlockConfTable                       = 214,
    UALootLimitPointTypeBlacklistTable             = 215,
    UAActivityAutoGiveInventoryTable               = 216,
    UACanBeDestroyedActorConfigTable               = 217,
    UAScavEquipConfTable                           = 218,
    UAModeAIDifficultyTable                        = 219,
    UADMGLimitConfTable                            = 220,
    UADMGLimitMapidConfTable                       = 221,
    UABlockWordIconCfgTable                        = 222,
    UAModeReplicationRuleTable                     = 223,
    UAEquipTemplateConfTable                       = 224,
    UAEquipPurchaseConfTable                       = 225,
    AiEquipID2ContainerDropIdTable                 = 226,
    AiContainerDropConfTable                       = 227,
    UAOverseaSubtitleTable                         = 228,
    UAHighResourceMarkTable                        = 229,
    UACharacterInitDataConfigTable                 = 230,
    UACharacterBuffDataTable                       = 231,
    UAHUDModeVisibilityTable                       = 232,
    UAUIStateVisibilityTable                       = 233,
    UAModeAudioConfTable                           = 234,
    UAMapUnlockTable                               = 235,
    UAMultiModeWidgetConfTable                     = 236,
    UADownloadPropertyConfigTable                  = 237,
    UATimeCountDownTipsTable                       = 238,
    UAGameViewSettingTable                         = 239,
    UADeviceModelViewSettingTable                  = 240,
    UAWeaponSkinSprayConfTable                     = 241,
    UAInventoryAreaMapTable                        = 242,
    UAPickUpPriorityTable                          = 243,
    UATalentConfigTable                            = 244,
    UASettleUIConfigTable                          = 245,
    UAStoryTaskConfTable                           = 246,
    UAAssetsToCookRuleConfigTable                  = 247,
    ViewGoldConfigTable                            = 248,
    UAWeaponPresetTable                            = 249,
    UANewBagModeConfigTable                        = 250,
    UARebornConfigTable                            = 251,
    SGInventoryPackageTable                        = 252,
    UACharacterSpawnEffectTable                    = 253,
    UAWeaponSkinOverrideConfigTable                = 254,
    UASprayIconTextureTable                        = 255,
    UASettleTipsConfigTable                        = 256,
    UAGeneralTransitionConfigTable                 = 257,
    UAAreaIDToLocationIDTable                      = 258,
    UARadioConfigTable                             = 259,
    UARadioTextAudioTable                          = 260,
    UAGuaranteeActContainerTable                   = 261,
    UAGuaranteeActItemPoolTable                    = 262,
    UADeviceWorkloadScoreTable                     = 263,
    UATutorialGamePadHudTipsTable                  = 264,
    UACommonKVConfTable                            = 265,
    UAModeGameSettingConfTable                     = 266,
    EDataTableType_MAX                             = 267

};


// Enum  /Script/SGFramework.ESGDoorBombDirectionType
enum class ESGDoorBombDirectionType : uint8_t
{
    None                                           = 0,
    Front                                          = 1,
    Back                                           = 2,
    ESGDoorBombDirectionType_MAX                   = 3

};


// Enum  /Script/SGFramework.ESGDoorCategory
enum class ESGDoorCategory : uint8_t
{
    Building                                       = 0,
    Car                                            = 1,
    CarBack                                        = 2,
    ESGDoorCategory_MAX                            = 3

};


// Enum  /Script/SGFramework.ESGDoorUseMode
enum class ESGDoorUseMode : uint8_t
{
    Default                                        = 0,
    Unlock                                         = 1,
    ESGDoorUseMode_MAX                             = 2

};


// Enum  /Script/SGFramework.ESGAlarmState
enum class ESGAlarmState : uint8_t
{
    Unlock                                         = 0,
    Locked                                         = 1,
    ESGAlarmState_MAX                              = 2

};


// Enum  /Script/SGFramework.ESGCardReaderDoorType
enum class ESGCardReaderDoorType : uint8_t
{
    Normal                                         = 0,
    CanReset                                       = 1,
    ESGCardReaderDoorType_MAX                      = 2

};


// Enum  /Script/SGFramework.ESGDoorOpenType
enum class ESGDoorOpenType : uint8_t
{
    None                                           = 0,
    Normal                                         = 1,
    NeedWreck                                      = 2,
    NeedUnlock                                     = 3,
    NeedUnlock_Card                                = 4,
    NeedUnlock_Gate                                = 5,
    NeedCloseGenerator                             = 6,
    Disabled                                       = 7,
    HiddenInteract                                 = 8,
    ESGDoorOpenType_MAX                            = 9

};


// Enum  /Script/SGFramework.ESGDoorUseType
enum class ESGDoorUseType : uint8_t
{
    None                                           = 0,
    Normal                                         = 1,
    LockedContainer                                = 2,
    ESGDoorUseType_MAX                             = 3

};


// Enum  /Script/SGFramework.ESGDoorType
enum class ESGDoorType : uint8_t
{
    OneWay_CouterClockwise                         = 0,
    OneWay_Clockwise                               = 1,
    TwoWay                                         = 2,
    Sliding                                        = 3,
    NoWay                                          = 4,
    ESGDoorType_MAX                                = 5

};


// Enum  /Script/SGFramework.ESGDownloadTargetType
enum class ESGDownloadTargetType : uint8_t
{
    SGDownloadTargetType_All                       = 0,
    SGDownloadTargetType_Avatar                    = 1,
    SGDownloadTargetType_Weapon                    = 2,
    SGDownloadTargetType_CoreOtherResource         = 3,
    SGDownloadTargetType_MAX                       = 4

};


// Enum  /Script/SGFramework.ESGDSCommandDoType
enum class ESGDSCommandDoType : uint8_t
{
    CommandLine                                    = 0,
    CallFunction                                   = 1,
    ESGDSCommandDoType_MAX                         = 2

};


// Enum  /Script/SGFramework.ESGDSCommandTimingType
enum class ESGDSCommandTimingType : uint8_t
{
    PreFork                                        = 0,
    AfterFork                                      = 1,
    AllPlayLoginSucc                               = 2,
    PrePlayerLogin                                 = 3,
    PostPlayerLogin                                = 4,
    EngineInit                                     = 5,
    AfterForkOpenPort                              = 6,
    DSExpectedTimeEnd                              = 7,
    ESGDSCommandTimingType_MAX                     = 8

};


// Enum  /Script/SGFramework.ESGFenceSelector
enum class ESGFenceSelector : uint8_t
{
    None                                           = 0,
    Use                                            = 1,
    Use                                            = 2,
    Use                                            = 3,
    Use                                            = 4,
    ESGFenceSelector_MAX                           = 5

};


// Enum  /Script/SGFramework.ESGFlowFinishState
enum class ESGFlowFinishState : uint8_t
{
    ESGFlowState_Success                           = 0,
    ESGFlowState_Failed                            = 1,
    ESGFlowState_MAX                               = 2

};


// Enum  /Script/SGFramework.ESGLoadBudgetType
enum class ESGLoadBudgetType : uint8_t
{
    LoadBudgetType_Normal                          = 0,
    LoadBudgetType_Loading                         = 1,
    LoadBudgetType_Replay                          = 2,
    LoadBudgetType_Spectating                      = 4,
    LoadBudgetType_Reborn                          = 8,
    LoadBudgetType_MAX                             = 9

};


// Enum  /Script/SGFramework.ESGCharacterSpawnType
enum class ESGCharacterSpawnType : uint8_t
{
    ESGCharacterSpawnType_NONE                     = 0,
    ESGCharacterSpawnType_AutoSpawn                = 1,
    ESGCharacterSpawnType_ActiveTriger             = 2,
    ESGCharacterSpawnType_MAX                      = 3

};


// Enum  /Script/SGFramework.EActivityType
enum class EActivityType : uint8_t
{
    EActivityType_None                             = 0,
    EActivityType_Chase                            = 1,
    EActivityType_Voiceprint                       = 7,
    EActivityType_HalloweenBox                     = 10,
    EActivityType_NPCLuckyBox                      = 14,
    EActivityType_MAX                              = 15

};


// Enum  /Script/SGFramework.EGestureType
enum class EGestureType : uint8_t
{
    OneHand                                        = 0,
    TwoHand                                        = 1,
    FullBody                                       = 2,
    EGestureType_MAX                               = 3

};


// Enum  /Script/SGFramework.EAnimSectionType
enum class EAnimSectionType : uint8_t
{
    None                                           = 0,
    Start                                          = 1,
    Loop                                           = 2,
    End                                            = 3,
    EAnimSectionType_MAX                           = 4

};


// Enum  /Script/SGFramework.EInteractActivateFlowStep
enum class EInteractActivateFlowStep : uint8_t
{
    Begin                                          = 0,
    ResetPosture                                   = 1,
    PrecastAndMoveToActor                          = 2,
    PlayInteractAnimation                          = 3,
    ActualExecInteract                             = 4,
    FinishInteract                                 = 5,
    EInteractActivateFlowStep_MAX                  = 6

};


// Enum  /Script/SGFramework.ESensitivityMode
enum class ESensitivityMode : uint32_t
{
    Unknown                                        = 4294967295,
    High                                           = 0,
    Middle                                         = 1,
    Low                                            = 2,
    Custom                                         = 3,
    ESensitivityMode_MAX                           = 4

};


// Enum  /Script/SGFramework.EBigMapIconInfo
enum class EBigMapIconInfo : uint8_t
{
    Character                                      = 0,
    Paradrop                                       = 1,
    Vehicle                                        = 2,
    EBigMapIconInfo_MAX                            = 3

};


// Enum  /Script/SGFramework.ELimitRandomAreaPlanStatusType
enum class ELimitRandomAreaPlanStatusType : uint8_t
{
    PlanStatusType_None                            = 0,
    PlanStatusType_WaitShow                        = 1,
    PlanStatusType_WaitMove                        = 2,
    PlanStatusType_Moving                          = 3,
    PlanStatusType_MoveEnd                         = 4,
    PlanStatusType_MAX                             = 5

};


// Enum  /Script/SGFramework.EReplayExternalDataType
enum class EReplayExternalDataType : uint8_t
{
    BulletHit                                      = 0,
    GrenadeExplode                                 = 1,
    StartFire                                      = 2,
    EquipInfo                                      = 3,
    MoveStateChange                                = 4,
    PlayerZoneInfo                                 = 5,
    UseDoorKey                                     = 6,
    LootBox                                        = 7,
    LootBoxItem                                    = 8,
    LeanType                                       = 9,
    RescueTeammate                                 = 10,
    ThrowGrenade                                   = 11,
    EReplayExternalDataType_MAX                    = 12

};


// Enum  /Script/SGFramework.EScorePanelConfigType
enum class EScorePanelConfigType : uint8_t
{
    E_None                                         = 0,
    E_Score                                        = 1,
    E_TIME                                         = 2,
    E_BOTH                                         = 3,
    E_MAX                                          = 4

};


// Enum  /Script/SGFramework.EAIRLType
enum class EAIRLType : uint8_t
{
    None                                           = 0,
    PMCAI_Harass                                   = 1,
    Boss_Valley                                    = 2,
    Boss_Farmland                                  = 3,
    PMCAI_Harass_Online                            = 4,
    EAIRLType_MAX                                  = 5

};


// Enum  /Script/SGFramework.ESGVehicleDisableReason
enum class ESGVehicleDisableReason : uint8_t
{
    None                                           = 0,
    Dead                                           = 1,
    Velocity                                       = 2,
    TakeDamage                                     = 3,
    Relevant                                       = 4,
    Debug                                          = 5,
    ESGVehicleDisableReason_MAX                    = 6

};


// Enum  /Script/SGFramework.ESGVehicleEnableReason
enum class ESGVehicleEnableReason : uint8_t
{
    None                                           = 0,
    Initialization                                 = 1,
    Driving                                        = 2,
    TakeDamage                                     = 3,
    Relevant                                       = 4,
    Velocity                                       = 5,
    Debug                                          = 6,
    ESGVehicleEnableReason_MAX                     = 7

};


// Enum  /Script/SGFramework.EReinforcementTargetType
enum class EReinforcementTargetType : uint8_t
{
    Team                                           = 0,
    Faction                                        = 1,
    EReinforcementTargetType_MAX                   = 2

};


// Enum  /Script/SGFramework.EEscapePointSourceType
enum class EEscapePointSourceType : uint8_t
{
    Default                                        = 0,
    Mission                                        = 1,
    EEscapePointSourceType_MAX                     = 2

};


// Enum  /Script/SGFramework.EPlayerStartPointType
enum class EPlayerStartPointType : uint8_t
{
    Default                                        = 0,
    OriginPoint                                    = 1,
    BornAndRespawn                                 = 2,
    OnlyRespawn                                    = 3,
    EPlayerStartPointType_MAX                      = 4

};


// Enum  /Script/SGFramework.ECompScanningType
enum class ECompScanningType : uint8_t
{
    None                                           = 0,
    Ultravioletlight                               = 1,
    ECompScanningType_MAX                          = 2

};


// Enum  /Script/SGFramework.ECharacterJobType
enum class ECharacterJobType : uint8_t
{
    None                                           = 0,
    Coroner                                        = 1,
    StoryPlayer                                    = 2,
    Scav2077                                       = 3,
    Scavenger                                      = 4,
    TraumaTeam2077                                 = 5,
    Hecate                                         = 6,
    ECharacterJobType_MAX                          = 7

};


// Enum  /Script/SGFramework.ESGActorSpawnUsePool
enum class ESGActorSpawnUsePool : uint8_t
{
    NormalActorPool                                = 0,
    GameStateActorPool                             = 1,
    ESGActorSpawnUsePool_MAX                       = 2

};


// Enum  /Script/SGFramework.EGameLoadingStageType
enum class EGameLoadingStageType : uint8_t
{
    None                                           = 0,
    WaitTakeIn                                     = 1,
    WaitLoadScript                                 = 2,
    WaitSpawnCharacter                             = 3,
    WaitSpawnEquipment                             = 4,
    WaitPreGameInitialize                          = 5,
    EGameLoadingStageType_MAX                      = 6

};


// Enum  /Script/SGFramework.EGameBattleTestMode
enum class EGameBattleTestMode : uint8_t
{
    None                                           = 0,
    NoRandomTest                                   = 1,
    NoAI                                           = 2,
    AINoRandom                                     = 4,
    LootNoRandom                                   = 8,
    PlayerStartNoRandom                            = 16,
    EGameBattleTestMode_MAX                        = 17

};


// Enum  /Script/SGFramework.ENewTraceDisplayPlatform
enum class ENewTraceDisplayPlatform : uint8_t
{
    UnKnow                                         = 0,
    ScenePlatform                                  = 1,
    NewMapPlatform                                 = 2,
    DirectionalBarPlatform                         = 3,
    ENewTraceDisplayPlatform_MAX                   = 4

};


// Enum  /Script/SGFramework.EHostedInteractRule
enum class EHostedInteractRule : uint8_t
{
    UnKnow                                         = 0,
    Person                                         = 1,
    TeamInfo                                       = 2,
    Faction                                        = 3,
    GameState                                      = 4,
    All                                            = 5,
    EHostedInteractRule_MAX                        = 6

};


// Enum  /Script/SGFramework.ENewTraceSyncRule
enum class ENewTraceSyncRule : uint8_t
{
    UnKnow                                         = 0,
    PlayerController                               = 1,
    TeamInfo                                       = 2,
    Faction                                        = 3,
    GameState                                      = 4,
    All                                            = 5,
    ENewTraceSyncRule_MAX                          = 6

};


// Enum  /Script/SGFramework.ENewTraceableMarkType
enum class ENewTraceableMarkType : uint8_t
{
    UnKnow                                         = 0,
    PlayerTrace                                    = 1,
    EscapeTrace                                    = 2,
    MissionTrace                                   = 3,
    SpecialTrace                                   = 4,
    ContainerTrace                                 = 5,
    All                                            = 6,
    ENewTraceableMarkType_MAX                      = 7

};


// Enum  /Script/SGFramework.EShowVoiceResult
enum class EShowVoiceResult : uint8_t
{
    Completed                                      = 0,
    Failed                                         = 1,
    EShowVoiceResult_MAX                           = 2

};


// Enum  /Script/SGFramework.EMapSignType
enum class EMapSignType : uint8_t
{
    None                                           = 0,
    Map                                            = 1,
    EscapePoint                                    = 2,
    QuestTrace                                     = 3,
    EMapSignType_MAX                               = 4

};


// Enum  /Script/SGFramework.EFactionRelationType
enum class EFactionRelationType : uint8_t
{
    None                                           = 0,
    Friendly                                       = 1,
    Neutral                                        = 2,
    hostile                                        = 3,
    EFactionRelationType_MAX                       = 4

};


// Enum  /Script/SGFramework.ESGDSSwitcherFlag
enum class ESGDSSwitcherFlag : uint8_t
{
    None                                           = 0,
    SGDSSwitcherFlag_NetObjPool                    = 1,
    SGDSSwitcherFlag_NetJIT                        = 2,
    SGDSSwitcherFlag_LootLevel                     = 4,
    SGDSSwitcherFlag_OpimizedAssembleRep           = 8,
    ESGDSSwitcherFlag_MAX                          = 9

};


// Enum  /Script/SGFramework.EUABagOperation
enum class EUABagOperation : uint8_t
{
    Loot                                           = 0,
    OpenBag                                        = 1,
    OnHit                                          = 2,
    EUABagOperation_MAX                            = 3

};


// Enum  /Script/SGFramework.EFollowCharacterWidgetType
enum class EFollowCharacterWidgetType : uint8_t
{
    EFollowCharacterWidgetType_Simple              = 0,
    EFollowCharacterWidgetType_ChaseActivity       = 1,
    EFollowCharacterWidgetType_DossBoss            = 2,
    EFollowCharacterWidgetType_Faction             = 3,
    EFollowCharacterWidgetType_FactionAI           = 4,
    EFollowCharacterWidgetType_MAX                 = 5

};


// Enum  /Script/SGFramework.ESGUIState
enum class ESGUIState : uint8_t
{
    None                                           = 0,
    Character                                      = 1,
    VehicleDriver                                  = 2,
    VehiclePassenger                               = 3,
    Bag                                            = 4,
    BigMap                                         = 5,
    Settlement                                     = 6,
    Spectating                                     = 7,
    ESGUIState_MAX                                 = 8

};


// Enum  /Script/SGFramework.ESGUIMode
enum class ESGUIMode : uint8_t
{
    None                                           = 0,
    Character                                      = 1,
    VehicleDriver                                  = 2,
    VehiclePassenger                               = 3,
    ESGUIMode_MAX                                  = 4

};


// Enum  /Script/SGFramework.ESGHUDLayerType
enum class ESGHUDLayerType : uint8_t
{
    HUDLayer_ScreenEffect                          = 0,
    HUDLayer_GamePad                               = 1,
    HUDLayer_Settings                              = 2,
    HUDLayer_BaseInfo                              = 3,
    HUDLayer_EventInfo                             = 4,
    HUDLayer_AnnounceTips                          = 5,
    HUDLayer_SystemInfo                            = 6,
    HUDLayer_FullScreen                            = 7,
    NUM_HUDLayer_Max                               = 8,
    ESGHUDLayerType_MAX                            = 9

};


// Enum  /Script/SGFramework.EReportType
enum class EReportType : uint8_t
{
    GameHUDTable                                   = 0,
    TaskReport                                     = 1,
    Toast                                          = 2,
    EReportType_MAX                                = 3

};


// Enum  /Script/SGFramework.EActorFilterType
enum class EActorFilterType : uint8_t
{
    None                                           = 0,
    SpecifiedActors                                = 1,
    IgnoreSpecifiedActors                          = 2,
    EActorFilterType_MAX                           = 3

};


// Enum  /Script/SGFramework.ELeaveGameReason
enum class ELeaveGameReason : uint8_t
{
    Unknow                                         = 0,
    Dead                                           = 1,
    Escaped                                        = 2,
    GameOver                                       = 3,
    Discard                                        = 4,
    Offline                                        = 5,
    ELeaveGameReason_MAX                           = 6

};


// Enum  /Script/SGFramework.ERelevantCheckType
enum class ERelevantCheckType : uint8_t
{
    None                                           = 0,
    ForceRelevant                                  = 1,
    ForceRelevantIgnoreOther                       = 2,
    RelevantIgnoreOther                            = 3,
    NotRelevant                                    = 4,
    ERelevantCheckType_MAX                         = 5

};


// Enum  /Script/SGFramework.ENumCompareType
enum class ENumCompareType : uint8_t
{
    CMP_Equals                                     = 0,
    CMP_NotEqual                                   = 1,
    CMP_Greater                                    = 2,
    CMP_Less                                       = 3,
    CMP_GreaterEqual                               = 4,
    CMP_LessEqual                                  = 5,
    CMP_Between                                    = 6,
    CMP_MAX                                        = 7

};


// Enum  /Script/SGFramework.EFactionMemberType
enum class EFactionMemberType : uint8_t
{
    None                                           = 0,
    Player                                         = 1,
    AI                                             = 2,
    AIBoss                                         = 3,
    EFactionMemberType_MAX                         = 4

};


// Enum  /Script/SGFramework.ETeamInfoType
enum class ETeamInfoType : uint8_t
{
    None                                           = 0,
    PlayerTeam                                     = 1,
    AITeam                                         = 2,
    ETeamInfoType_MAX                              = 3

};


// Enum  /Script/SGFramework.EWeatherImpactType
enum class EWeatherImpactType : uint8_t
{
    None                                           = 0,
    Thunder                                        = 1,
    Blizzard                                       = 2,
    EWeatherImpactType_MAX                         = 3

};


// Enum  /Script/SGFramework.EPlayerAliveState
enum class EPlayerAliveState : uint8_t
{
    EPlayerAliveState_None                         = 0,
    EPlayerAliveState_Alive                        = 1,
    EPlayerAliveState_Dead                         = 2,
    EPlayerAliveState_DBNO                         = 3,
    EPlayerAliveState_Quit                         = 4,
    EPlayerAliveState_MAX                          = 5

};


// Enum  /Script/SGFramework.EDrawDebugType
enum class EDrawDebugType : uint32_t
{
    EDrawDebugType_None                            = 0,
    EDrawDebugType_Weapon                          = 1,
    EDrawDebugType_Camera                          = 2,
    EDrawDebugType_PlayerState                     = 4,
    EDrawDebugType_SelfMovement                    = 8,
    EDrawDebugType_AllMovement                     = 15,
    EDrawDebugType_Breath                          = 16,
    EDrawDebugType_Location                        = 32,
    EDrawDebugType_AnimationCurve                  = 64,
    EDrawDebugType_AttributeSets_Movement          = 128,
    EDrawDebugType_Damage                          = 240,
    EDrawDebugType_InputRotate                     = 256,
    EDrawDebugType_MAX                             = 257

};


// Enum  /Script/SGFramework.EInputMode
enum class EInputMode : uint8_t
{
    EIM_None                                       = 0,
    EIM_GameOnly                                   = 1,
    EIM_GameAndUI                                  = 2,
    EIM_UIOnly                                     = 3,
    EIM_MAX                                        = 4

};


// Enum  /Script/SGFramework.ESoundReplicationType
enum class ESoundReplicationType : uint8_t
{
    SRT_All                                        = 0,
    SRT_AllButOwner                                = 1,
    SRT_IfSourceNotReplicated                      = 2,
    SRT_None                                       = 3,
    SRT_MAX                                        = 4

};


// Enum  /Script/SGFramework.EGlobalEventParameterTag
enum class EGlobalEventParameterTag : uint8_t
{
    Instigator                                     = 0,
    Character                                      = 1,
    Target                                         = 2,
    EnduranceType                                  = 3,
    ArmorType                                      = 4,
    DamageInfo                                     = 5,
    UseInventoryPhase                              = 6,
    EscapeVolume                                   = 7,
    Inventory                                      = 8,
    InventoryMag                                   = 9,
    ItemID                                         = 10,
    AttachPosition                                 = 11,
    EndGameType                                    = 12,
    TeamMember                                     = 13,
    GameEffectType                                 = 14,
    ThrowableProjectile                            = 15,
    IntCount                                       = 16,
    IntOldCount                                    = 17,
    IntNewCount                                    = 18,
    Bool                                           = 19,
    Int64Count                                     = 20,
    AnnounceID                                     = 21,
    Killer                                         = 22,
    KilledPlayer                                   = 23,
    KillerWeapon                                   = 24,
    KillDistance                                   = 25,
    DamageTakePlayer                               = 26,
    DamageCausePlayer                              = 27,
    DamageCauser                                   = 28,
    InteractActor                                  = 29,
    InteractEventType                              = 30,
    Trigger                                        = 31,
    AttractAI                                      = 32,
    VolumeID                                       = 33,
    BagType                                        = 34,
    BagTabType                                     = 35,
    Container                                      = 36,
    DetailBoardType                                = 37,
    TaskID                                         = 38,
    WidgetID                                       = 39,
    StackableItemSourceInfo                        = 40,
    ParadropState                                  = 41,
    FactionType                                    = 42,
    AISceneEvent                                   = 43,
    SearchingPlayer                                = 44,
    InteractCharacter                              = 45,
    SpawnInventory                                 = 46,
    PlayerState                                    = 47,
    ChaseActivityStage                             = 48,
    Rescuer                                        = 49,
    Weaker                                         = 50,
    Interacter                                     = 51,
    InteractActorConfigID                          = 52,
    InteractActorGID                               = 53,
    AssistKiller                                   = 54,
    ActorComponent                                 = 55,
    OldParentActor                                 = 56,
    OldDoorOpenType                                = 57,
    NewDoorOpenType                                = 58,
    EGlobalEventParameterTag_MAX                   = 59

};


// Enum  /Script/SGFramework.EGlobalEventTag
enum class EGlobalEventTag : uint8_t
{
    Killed                                         = 0,
    TakeDamage                                     = 1,
    TakeInItem                                     = 2,
    FlowStateChange                                = 3,
    Interact                                       = 4,
    InventoryAdded                                 = 5,
    InventoryRemoved                               = 6,
    InventoryDestroyed                             = 7,
    PrePlayerFinishGame                            = 8,
    PlayerFinishGame                               = 9,
    AttractAI                                      = 10,
    ReadyToPlay                                    = 11,
    LootContainer                                  = 12,
    UseInventory                                   = 13,
    UseRecoveryInventory                           = 14,
    GameplayEffectApplied                          = 15,
    AttachPositionChanged                          = 16,
    ContainerInteractChanged                       = 17,
    SwitchWeaponCompleted                          = 18,
    GameBegin                                      = 19,
    ThrowableProjectileSpawn                       = 20,
    LocationReport                                 = 21,
    CharacterCostBullet                            = 22,
    ModifyInventoryTotalCount                      = 23,
    PushBullet                                     = 24,
    VolumeActorChanged                             = 25,
    AIActived                                      = 26,
    AIEscaped                                      = 27,
    Pair                                           = 28,
    PlayerBeginGame                                = 29,
    ClickItem                                      = 30,
    AddMapSign                                     = 31,
    WeaponCheck                                    = 32,
    WeaponAssemble                                 = 33,
    MoveInventory                                  = 34,
    VolumeBeginOverlap                             = 35,
    BagStateChange                                 = 36,
    BigMapDetailBoardShow                          = 37,
    BagTabClick                                    = 38,
    InspectItemClick                               = 39,
    OpenPPT                                        = 40,
    OpenItemDetail                                 = 41,
    ParadropStateChange                            = 42,
    FactionScoreUpdate                             = 43,
    SceneEventTrigger                              = 44,
    SceneEventExpired                              = 45,
    SceneEventRemoved                              = 46,
    SceneEventCompleted                            = 47,
    FSMStateChange                                 = 48,
    MComStartUpLoad                                = 49,
    MComInterruptUpLoad                            = 50,
    StartSearchingContainer                        = 51,
    CharacterDestroyActor                          = 52,
    OnOneShotEnd                                   = 53,
    UnfillContainer                                = 54,
    StartLoot                                      = 55,
    MultiInventoryInteraction                      = 56,
    ChaseActivityStageChange                       = 57,
    FinishRescueTeammate                           = 58,
    StuckLocationReport                            = 59,
    CapturePointVolumeBelongChange                 = 60,
    CapturePointReportPlayer                       = 61,
    OnVehicleBeginPlay                             = 62,
    OnVehicleDestroyed                             = 63,
    RoundGamePrepare                               = 64,
    RoundEndForPlay                                = 65,
    StartInvDetecting                              = 66,
    InteractActor                                  = 67,
    StartChase                                     = 68,
    AssistKill                                     = 69,
    LimitAreaPlanDataInfoChange                    = 70,
    BRRemainNumChange                              = 71,
    BRRemainTeamNumChange                          = 72,
    StatisDataChange                               = 73,
    MissionFlowStateFinished                       = 74,
    ActorBeBroken                                  = 75,
    PadButtonClick                                 = 76,
    BattleLineInfoChange                           = 77,
    AIFighting                                     = 78,
    PickUpGroupRandomSpawnComplete                 = 79,
    AddCharacterComponent                          = 80,
    AddPlayerScore                                 = 81,
    DoorOpenTypeChange                             = 82,
    AcceptRadio                                    = 83,
    TodHourChange                                  = 84,
    TodWeatherChange                               = 85,
    PlayerReborn                                   = 86,
    EGlobalEventTag_MAX                            = 87

};


// Enum  /Script/SGFramework.EProtectActorInteractStrategy
enum class EProtectActorInteractStrategy : uint8_t
{
    Strategy_None                                  = 0,
    Strategy_OnlyLimitTeammateByWhitelist          = 1,
    Strategy_OnlyLimitFactionByWhitelist           = 2,
    Strategy_MAX                                   = 3

};


// Enum  /Script/SGFramework.EHoverForceSide
enum class EHoverForceSide : uint8_t
{
    EHFSide_None                                   = 0,
    EHFSide_Left                                   = 1,
    EHFSide_Right                                  = 2,
    EHFSide_MAX                                    = 3

};


// Enum  /Script/SGFramework.EHUDType
enum class EHUDType : uint8_t
{
    SecondModeMatchType_Mode                       = 0,
    SecondModeMatchType_Map                        = 1,
    SecondModeMatchType_MAX                        = 2

};


// Enum  /Script/SGFramework.EHUDShakeEvents
enum class EHUDShakeEvents : uint8_t
{
    EHUDShakeEvents_HeavyWalk                      = 0,
    EHUDShakeEvents_HeavyCrouch                    = 1,
    EHUDShakeEvents_HeavyProne                     = 2,
    EHUDShakeEvents_HeavyStandUp                   = 3,
    EHUDShakeEvents_Run                            = 4,
    EHUDShakeEvents_Jump                           = 5,
    EHUDShakeEvents_Landed                         = 6,
    EHUDShakeEvents_Lean                           = 7,
    EHUDShakeEvents_RotateView                     = 8,
    EHUDShakeEvents_DartleFire                     = 9,
    EHUDShakeEvents_SingleFire                     = 10,
    EHUDShakeEvents_Melee                          = 11,
    EHUDShakeEvents_UseItem                        = 12,
    EHUDShakeEvents_CheckMagazine                  = 13,
    EHUDShakeEvents_AttachMagazine                 = 14,
    EHUDShakeEvents_ChangeClip                     = 15,
    EHUDShakeEvents_TakeDamage                     = 16,
    EHUDShakeEvents_Explode                        = 17,
    EHUDShakeEvents_HeadTakeDamage                 = 18,
    EHUDShakeEvents_MAX                            = 19

};


// Enum  /Script/SGFramework.EHUDShakeTypes
enum class EHUDShakeTypes : uint8_t
{
    EHUDShakeTypes_None                            = 0,
    EHUDShakeTypes_LocX_RotR                       = 1,
    EHUDShakeTypes_RotY_RotP                       = 2,
    EHUDShakeTypes_Breath_RotY_RotP                = 3,
    EHUDShakeTypes_MAX                             = 4

};


// Enum  /Script/SGFramework.EHUDShakeTags
enum class EHUDShakeTags : uint8_t
{
    EHUDShakeTags_A                                = 0,
    EHUDShakeTags_B                                = 1,
    EHUDShakeTags_C                                = 2,
    EHUDShakeTags_MAX                              = 3

};


// Enum  /Script/SGFramework.ECommonInputButtonType
enum class ECommonInputButtonType : uint8_t
{
    ECommonInput_Fire                              = 0,
    ECommonInput_Sprint                            = 1,
    ECommonInput_Prone                             = 2,
    ECommonInput_Crouch                            = 3,
    ECommonInput_Lean                              = 4,
    ECommonInput_Ads                               = 5,
    ECommonInput_UseItem                           = 6,
    ECommonInput_Jump                              = 7,
    ECommonInput_GrenadeHit                        = 8,
    ECommonInput_GunHit                            = 9,
    ECommonInput_GrenadeFire                       = 10,
    ECommonInput_MAX                               = 11

};


// Enum  /Script/SGFramework.EButtonAcceptInputType
enum class EButtonAcceptInputType : uint8_t
{
    ENoneInput                                     = 0,
    EOnlyClick                                     = 1,
    EOutsideAcceptInput                            = 2,
    EAllAcceptInput                                = 3,
    EButtonAcceptInputType_MAX                     = 4

};


// Enum  /Script/SGFramework.EMotionRotateMode
enum class EMotionRotateMode : uint8_t
{
    EMotionRotateMode_None                         = 0,
    EMotionRotateMode_ADS                          = 1,
    EMotionRotateMode_Always                       = 2,
    EMotionRotateMode_MAX                          = 3

};


// Enum  /Script/SGFramework.ELeanShootInputMode
enum class ELeanShootInputMode : uint8_t
{
    ELeanShootInputMode_Click                      = 0,
    ELeanShootInputMode_Pressing                   = 1,
    ELeanShootInputMode_MAX                        = 2

};


// Enum  /Script/SGFramework.ELeanShootMode
enum class ELeanShootMode : uint8_t
{
    ELeanShootMode_Closed                          = 0,
    ELeanShootMode_Always                          = 1,
    ELeanShootMode_WhenAim                         = 2,
    ELeanShootMode_MAX                             = 3

};


// Enum  /Script/SGFramework.EUseButtonIconType
enum class EUseButtonIconType : uint8_t
{
    UseButtonType_None                             = 0,
    UseButtonType_DriveVehicle                     = 1,
    UseButtonType_SeatVehicle                      = 2,
    UseButtonType_CloseDoor                        = 3,
    UseButtonType_OpenDoor                         = 4,
    UseButtonType_RescueTeamate                    = 5,
    UseButtonType_HoldAirBox                       = 6,
    UseButtonType_MAX                              = 7

};


// Enum  /Script/SGFramework.ESGMobileMoveHandle
enum class ESGMobileMoveHandle : uint8_t
{
    SGMobileMoveHandle_None                        = 0,
    SGMobileMoveHandle_Joystick                    = 1,
    SGMobileMoveHandle_Classics                    = 2,
    SGMobileMoveHandle_MAX                         = 3

};


// Enum  /Script/SGFramework.ERotateSensitivityMode
enum class ERotateSensitivityMode : uint8_t
{
    SensitivityMode_Fixed                          = 0,
    SensitivityMode_DistanceAcc                    = 1,
    SensitivityMode_SpeedAcc                       = 2,
    SensitivityMode_SpeedAccTest                   = 3,
    SensitivityMode_MAX                            = 4

};


// Enum  /Script/SGFramework.ESGGashaponActivateActionAbilityType
enum class ESGGashaponActivateActionAbilityType : uint8_t
{
    E_InteractDoubleHands                          = 0,
    E_InteractWithActor                            = 1,
    E_MAX                                          = 2

};


// Enum  /Script/SGFramework.ESGInteractCostType
enum class ESGInteractCostType : uint8_t
{
    InteractCostType_Count                         = 0,
    InteractCostType_Durability                    = 1,
    InteractCostType_MAX                           = 2

};


// Enum  /Script/SGFramework.EInteractFailureReason
enum class EInteractFailureReason : uint8_t
{
    None                                           = 0,
    EInteractFailureReason_MAX                     = 1

};


// Enum  /Script/SGFramework.EInteractPostureType
enum class EInteractPostureType : uint8_t
{
    None                                           = 0,
    Stand                                          = 1,
    Crouch                                         = 2,
    Prone                                          = 3,
    EInteractPostureType_MAX                       = 4

};


// Enum  /Script/SGFramework.ERelationToInteractInstigator
enum class ERelationToInteractInstigator : uint8_t
{
    Nobody                                         = 0,
    Self                                           = 1,
    Teammate                                       = 2,
    Faction                                        = 3,
    ERelationToInteractInstigator_MAX              = 4

};


// Enum  /Script/SGFramework.EInteractFrameworkProtoType
enum class EInteractFrameworkProtoType : uint8_t
{
    InteractProtoType_UnDefine                     = 0,
    InteractProtoType_Door                         = 1,
    InteractProtoType_Vehicle                      = 2,
    InteractProtoType_Container                    = 3,
    InteractProtoType_ShopStation                  = 4,
    InteractProtoType_Corpse                       = 5,
    InteractProtoType_MAX                          = 6

};


// Enum  /Script/SGFramework.EInteractFrameworkInteractRoute
enum class EInteractFrameworkInteractRoute : uint8_t
{
    InteractRoute_UnDefine                         = 0,
    InteractRoute_Condition                        = 1,
    InteractRoute_Aiming                           = 2,
    InteractRoute_MAX                              = 3

};


// Enum  /Script/SGFramework.EDetectedDirection
enum class EDetectedDirection : uint8_t
{
    None                                           = 0,
    Forward                                        = 1,
    Left                                           = 2,
    Right                                          = 3,
    Back                                           = 4,
    EDetectedDirection_MAX                         = 5

};


// Enum  /Script/SGFramework.ESwitchActionType
enum class ESwitchActionType : uint8_t
{
    SwitchActionType_None                          = 0,
    SwitchActionType_SwitchingOn                   = 1,
    SwitchActionType_SwitchingOff                  = 2,
    SwitchActionType_MAX                           = 3

};


// Enum  /Script/SGFramework.EHostedInteractFailType
enum class EHostedInteractFailType : uint8_t
{
    EHostedInteractFailType_None                   = 0,
    EHostedInteractFailType_InteractAngle          = 1,
    EHostedInteractFailType_InteractDistance       = 2,
    EHostedInteractFailType_CostInventoryDeficiency = 3,
    EHostedInteractFailType_MAX                    = 4

};


// Enum  /Script/SGFramework.EInventoryForcedInteractType
enum class EInventoryForcedInteractType : uint8_t
{
    EInventoryForcedInteract_Lock                  = 0,
    EInventoryForcedInteract_UnLocking             = 1,
    EInventoryForcedInteract_UnLock                = 2,
    EInventoryForcedInteract_MAX                   = 3

};


// Enum  /Script/SGFramework.ESGMovableArmorCollisionProxyShape
enum class ESGMovableArmorCollisionProxyShape : uint8_t
{
    Sphere                                         = 0,
    Box                                            = 1,
    ESGMovableArmorCollisionProxyShape_MAX         = 2

};


// Enum  /Script/SGFramework.ESGMovableArmorType
enum class ESGMovableArmorType : uint8_t
{
    None                                           = 0,
    WeaponAdapter                                  = 1,
    Weapon                                         = 2,
    ESGMovableArmorType_MAX                        = 3

};


// Enum  /Script/SGFramework.ESGShowBulletType
enum class ESGShowBulletType : uint8_t
{
    ShowBulletType_AutoDecide                      = 0,
    ShowBulletType_ForceHidden                     = 1,
    ShowBulletType_ForceDisplay                    = 2,
    ShowBulletType_MAX                             = 3

};


// Enum  /Script/SGFramework.ELootContainerLevel
enum class ELootContainerLevel : uint8_t
{
    None                                           = 0,
    SafeBox                                        = 1,
    HighLevelBox                                   = 2,
    LowLevelBox                                    = 3,
    AirDrop                                        = 4,
    ELootContainerLevel_MAX                        = 5

};


// Enum  /Script/SGFramework.ESGSkinType
enum class ESGSkinType : uint8_t
{
    Normal                                         = 0,
    SlaveSkin                                      = 1,
    AdvanceSlaveSkin                               = 2,
    ESGSkinType_MAX                                = 3

};


// Enum  /Script/SGFramework.ESprayType
enum class ESprayType : uint8_t
{
    NotSprayGunBare                                = 0,
    SprayAll                                       = 1,
    SpraySelfOnly                                  = 2,
    ESprayType_MAX                                 = 3

};


// Enum  /Script/SGFramework.ESGExtraMeshActionType
enum class ESGExtraMeshActionType : uint8_t
{
    HasAssembleIdCreateMesh                        = 0,
    ParentAssembleIdCreateMesh                     = 1,
    ChildAssembleIdHideBone                        = 2,
    ESGExtraMeshActionType_MAX                     = 3

};


// Enum  /Script/SGFramework.ESGMainHeadwearType
enum class ESGMainHeadwearType : uint8_t
{
    None                                           = 0,
    ThermalImager                                  = 1,
    FaceShield                                     = 2,
    MaskThermalImager                              = 3,
    ESGMainHeadwearType_MAX                        = 4

};


// Enum  /Script/SGFramework.ESGTakeInSourceType
enum class ESGTakeInSourceType : uint8_t
{
    TakeInSourceType_None                          = 0,
    TakeInSourceType_Doss                          = 1,
    TakeInSourceType_InBattle                      = 2,
    TakeInSourceType_MAX                           = 3

};


// Enum  /Script/SGFramework.ESGGiveInventoryByClassType
enum class ESGGiveInventoryByClassType : uint8_t
{
    None                                           = 0,
    InitPlayerEquipments                           = 1,
    NotAddToCharacter                              = 2,
    InBattleGiveItem                               = 3,
    Split                                          = 4,
    UnfillContainer                                = 5,
    EditorDefaultInventory                         = 6,
    GMCheat                                        = 7,
    AICreate                                       = 8,
    RebornInit                                     = 9,
    ESGGiveInventoryByClassType_MAX                = 10

};


// Enum  /Script/SGFramework.ESGRecoveryItemRecommendationOrder
enum class ESGRecoveryItemRecommendationOrder : uint8_t
{
    Default                                        = 0,
    ByHealthCondition                              = 1,
    ByBodyPart                                     = 2,
    ByDebuff                                       = 3,
    ESGRecoveryItemRecommendationOrder_MAX         = 4

};


// Enum  /Script/SGFramework.ESGInventoryHiddenFlag
enum class ESGInventoryHiddenFlag : uint32_t
{
    InventoryHiddenFlag_None                       = 0,
    InventoryHiddenFlag_ServerHidden               = 1,
    InventoryHiddenFlag_DisplayPolicyHidden        = 2,
    InventoryHiddenFlag_BackWeapon                 = 4,
    InventoryHiddenFlag_ThrowWeapon                = 8,
    InventoryHiddenFlag_LobbyTempHidden            = 16,
    InventoryHiddenFlag_Photograph                 = 32,
    InventoryHiddenFlag_LootBoxHidden              = 64,
    InventoryHiddenFlag_LootBoxDistanceHidden      = 128,
    InventoryHiddenFlag_LoadProtect                = 256,
    InventoryHiddenFlag_Destroy                    = 512,
    InventoryHiddenFlag_PerformanceHidden3P        = 1024,
    InventoryHiddenFlag_Freezed                    = 2048,
    InventoryHiddenFlag_DisplayPolicyNotRelease    = 4096,
    InventoryHiddenFlag_DummyReplace               = 8192,
    InventoryHiddenFlag_PredictHidden              = 16384,
    InventoryHiddenFlag_PlaySpawnEffect            = 32768,
    InventoryHiddenFlag_3PAssembleOpt              = 65536,
    InventoryHiddenFlag_PlayDying                  = 131072,
    InventoryHiddenFlag_MAX                        = 131073

};


// Enum  /Script/SGFramework.ESGInventoryDetailedSourceType
enum class ESGInventoryDetailedSourceType : uint8_t
{
    UnKnown                                        = 0,
    LootSpawn                                      = 1,
    PMCSelfTakeIn                                  = 2,
    PMCTeamPlayerTakeIn                            = 3,
    PMCOtherPlayerTakeIn                           = 4,
    ScavSelfTakeIn                                 = 5,
    ScavTeamPlayerTakeIn                           = 6,
    ScavOtherPlayerTakeIn                          = 7,
    OrdinaryAISpawn                                = 8,
    BossRetinueAISpawn                             = 9,
    BossAISpawn                                    = 10,
    PMCAISpawn                                     = 11,
    ReplaceDropSpawn                               = 12,
    LootGuaranteeSpawn                             = 13,
    GashaponSpawn                                  = 14,
    QuestActionSpawn                               = 15,
    ShoppingStationSpawn                           = 16,
    GuaranteeActSpawn                              = 17,
    ESGInventoryDetailedSourceType_MAX             = 18

};


// Enum  /Script/SGFramework.EKeyAutoUseOrderInfo
enum class EKeyAutoUseOrderInfo : uint8_t
{
    EKeyAutoUseOrderInfo_Mybag                     = 0,
    EKeyAutoUseOrderInfo_Vestbag                   = 1,
    EKeyAutoUseOrderInfo_Pocket                    = 2,
    EKeyAutoUseOrderInfo_Safe                      = 3,
    EKeyAutoUseOrderInfo_Max                       = 4

};


// Enum  /Script/SGFramework.EInventoryInfoChangeType
enum class EInventoryInfoChangeType : uint8_t
{
    Default                                        = 0,
    StackCount                                     = 1,
    IsNewFlag                                      = 2,
    Assemble                                       = 3,
    RollUp                                         = 4,
    Search                                         = 5,
    DogTag                                         = 6,
    Rotate                                         = 7,
    ContainerChild                                 = 8,
    ChangeIcon                                     = 9,
    All                                            = 10,
    EInventoryInfoChangeType_MAX                   = 11

};


// Enum  /Script/SGFramework.EPlayerMoveInventoryResultCode
enum class EPlayerMoveInventoryResultCode : uint8_t
{
    Success                                        = 0,
    Success_Discard                                = 1,
    Success_DiscardToCorpse                        = 2,
    Success_Pickup                                 = 3,
    Success_PickupFromCorpse                       = 4,
    Success_CorpseInside                           = 5,
    Success_DropFromCorpse                         = 6,
    Success_MoveToCorpse                           = 7,
    Success_AttachAdapter                          = 8,
    Success_DetachAdapter                          = 9,
    Success_ClearUp                                = 10,
    Success_CancelClearUp                          = 11,
    Error                                          = 12,
    Error_NullInventory                            = 13,
    Error_OnlySelf                                 = 14,
    Error_FromCharacterInvalid                     = 15,
    Error_ToCharacterInvalid                       = 16,
    Error_InventoryTypeCompMissing                 = 17,
    Error_EquipAttachPosNotFit                     = 18,
    Error_WeaponCantFire                           = 19,
    Error_SamePos                                  = 20,
    Error_Ocuupied                                 = 21,
    Error_CantDetach                               = 22,
    Error_AttachPosNotFit                          = 23,
    Error_NohandleWeaponInteract                   = 24,
    Error_CorpseToOtherCorpse                      = 25,
    Error_ForbiddenByContianerRule                 = 26,
    Error_ToContainerNotRoughSearched              = 27,
    Error_NotEmptyContainerToContainer             = 28,
    Error_LockedByOtherCharacter                   = 29,
    Error_ChildLockedByOtherCharacter              = 30,
    Error_AttachPositionBlockedByOtherInv          = 31,
    Error_NotEngoughSpace                          = 32,
    Error_TargetContainerFolded                    = 33,
    Error_ContainerStackOverflow                   = 34,
    Error_SwapEquipNotEnoughSpace                  = 35,
    Error_AttachAdapterNewSizeNotFitInContainer    = 36,
    Error_InContainerRolledUp                      = 37,
    Error_TryRollUpNoEmptyBag                      = 38,
    Error_TryRollUpNoSearchBag                     = 39,
    Error_ItemCannotMove                           = 40,
    Error_SetParentIllegal                         = 41,
    Error_BlackLootToSafeBox                       = 42,
    Error_FactionInvToSafeBox                      = 43,
    Error_AntiHackCheck                            = 44,
    Error_InvalidOper                              = 45,
    Error_RollUpCancelDrop                         = 46,
    Error_RollUping                                = 47,
    Error_LootTeammateCurse                        = 48,
    Error_PermitTeammateLoot                       = 49,
    Error_ToKeyContainer                           = 50,
    Error_CanNotThrowItem                          = 51,
    Error_LimitByInventoryTag                      = 52,
    Error_RestrictedInteraction                    = 53,
    Error_ContainerCantOperate                     = 54,
    Error_PreOccupying                             = 55,
    Error_CannotClearUp                            = 56,
    Error_CannotClearUpBySpace                     = 57,
    Error_CannotEquipTwoShield                     = 58,
    EPlayerMoveInventoryResultCode_MAX             = 59

};


// Enum  /Script/SGFramework.EInventoryAddToContainerResultCode
enum class EInventoryAddToContainerResultCode : uint8_t
{
    Success_FullyMerged                            = 0,
    Success_PartialMerged                          = 1,
    Success_PartialMergedWithNoSpace               = 2,
    Success_UseAutoSort                            = 3,
    Success                                        = 4,
    Failed                                         = 5,
    Failed_NotEnoughSpace                          = 6,
    Failed_ContainerToContainer_HasContent         = 7,
    Failed_ToContainerNotRoughSearched             = 8,
    Failed_ToContainerFolded                       = 9,
    Failed_ForbbidenByRule                         = 10,
    Failed_ContainerStackOverflow                  = 11,
    Failed_SelfPutIntoSelf                         = 12,
    Failed_NoBagNoLegalOptionContainer             = 13,
    Failed_EquippedBagNotEnoughSpace               = 14,
    Failed_ToRolledUpBag                           = 15,
    Failed_ToKeyContainer                          = 16,
    Failed_CantDetach                              = 17,
    Failed_LockedByOtherCharacter                  = 18,
    Error_BlackLootToSafeBox                       = 19,
    Error_FactionInvToSafeBox                      = 20,
    Error_InvalidOper                              = 21,
    EInventoryAddToContainerResultCode_MAX         = 22

};


// Enum  /Script/SGFramework.EEquipSlotCheckRejectionResult
enum class EEquipSlotCheckRejectionResult : uint8_t
{
    CanEquip                                       = 0,
    CannotEquip                                    = 1,
    TriedAttachPosOccupied                         = 2,
    TriedInvRejectOtherEquippedInv                 = 3,
    TriedInvRejectOtherEquippedInvAttachChild      = 4,
    TriedInvAttachChildRejectOtherEquippedInv      = 5,
    TriedInvAttachChildRejectOtherEquippedInvAttachChild = 6,
    OtherEquippedInvRejectTriedInv                 = 7,
    OtherEquippedInvRejectTriedInvAttachChild      = 8,
    OtherEquippedInvAttachChildRejectTriedInv      = 9,
    OtherEquippedInvAttachChildRejectTriedInvAttachChild = 10,
    EEquipSlotCheckRejectionResult_MAX             = 11

};


// Enum  /Script/SGFramework.EPlayerMoveInvExtraOperationType
enum class EPlayerMoveInvExtraOperationType : uint8_t
{
    None                                           = 0,
    Rotate                                         = 1,
    RollUp                                         = 2,
    RollUp_Unfold                                  = 3,
    RollUpAndRotate                                = 4,
    EPlayerMoveInvExtraOperationType_MAX           = 5

};


// Enum  /Script/SGFramework.EInventoryAttachSocket
enum class EInventoryAttachSocket : uint8_t
{
    None                                           = 0,
    MagazineSocket                                 = 1,
    GripSocket                                     = 2,
    HandguardSocket                                = 3,
    StockSocket                                    = 4,
    ShellSocket                                    = 5,
    RecieverSocket                                 = 6,
    MuzzleFlashSocket                              = 7,
    AimSocket                                      = 8,
    ScopeSocket                                    = 9,
    BarrelSocket                                   = 10,
    CarryHandleSocket                              = 11,
    SlideSocket                                    = 12,
    FrontIronSightSocket                           = 13,
    RearIronSightSocket                            = 14,
    RailSocket                                     = 15,
    ForegripSocket                                 = 16,
    UpperRecieverSocket                            = 17,
    DustCoverSocket                                = 18,
    ChamberSocket                                  = 19,
    mod_magazine                                   = 20,
    mod_pistol_grip                                = 21,
    mod_handguard                                  = 22,
    mod_stock                                      = 23,
    mod_reciever                                   = 24,
    mod_muzzle                                     = 25,
    mod_sight_front                                = 26,
    mod_sight_rear                                 = 27,
    mod_scope                                      = 28,
    mod_barrel                                     = 29,
    mod_foregrip                                   = 30,
    mod_charge                                     = 31,
    mod_mount                                      = 32,
    mod_tacital                                    = 33,
    mod_gas_block                                  = 34,
    EInventoryAttachSocket_MAX                     = 35

};


// Enum  /Script/SGFramework.EAssembleSocketState
enum class EAssembleSocketState : uint8_t
{
    ESocketState_Available                         = 0,
    ESocketState_Occupied                          = 1,
    ESocketState_Covered                           = 2,
    ESocketState_MAX                               = 3

};


// Enum  /Script/SGFramework.ESGPickupSourceType
enum class ESGPickupSourceType : uint8_t
{
    Default                                        = 0,
    Discard                                        = 1,
    ESGPickupSourceType_MAX                        = 2

};


// Enum  /Script/SGFramework.ESGInventoryDurabilityCostType
enum class ESGInventoryDurabilityCostType : uint8_t
{
    CostByUsageCount                               = 0,
    CostByGameEffect                               = 1,
    ESGInventoryDurabilityCostType_MAX             = 2

};


// Enum  /Script/SGFramework.EArmorSlot
enum class EArmorSlot : uint8_t
{
    Helmet                                         = 0,
    Vest                                           = 1,
    BackPack                                       = 2,
    Headset                                        = 3,
    FaceCover                                      = 4,
    EyeWear                                        = 5,
    FaceShield                                     = 6,
    ThighArmor                                     = 7,
    Max                                            = 8

};


// Enum  /Script/SGFramework.ESGItemType
enum class ESGItemType : uint8_t
{
    None                                           = 0,
    Key                                            = 1,
    Hardware                                       = 2,
    Other                                          = 3,
    ESGItemType_MAX                                = 4

};


// Enum  /Script/SGFramework.ESGRecoveryType
enum class ESGRecoveryType : uint8_t
{
    None                                           = 0,
    Medicine                                       = 1,
    Food                                           = 2,
    ESGRecoveryType_MAX                            = 3

};


// Enum  /Script/SGFramework.ESGArmorType
enum class ESGArmorType : uint8_t
{
    None                                           = 0,
    Helmet                                         = 1,
    Vest                                           = 2,
    Belt                                           = 3,
    Backpack                                       = 4,
    Headset                                        = 5,
    FaceCover                                      = 6,
    EyeWear                                        = 7,
    FaceShield                                     = 8,
    ThighArmor                                     = 9,
    ESGArmorType_MAX                               = 10

};


// Enum  /Script/SGFramework.ESGInventoryIconType
enum class ESGInventoryIconType : uint8_t
{
    Normal                                         = 0,
    Kill                                           = 1,
    Rotate                                         = 2,
    Small                                          = 3,
    White                                          = 4,
    ESGInventoryIconType_MAX                       = 5

};


// Enum  /Script/SGFramework.ESGInvItemIDEquipmentType
enum class ESGInvItemIDEquipmentType : uint8_t
{
    None                                           = 0,
    Weapon_MainWeapon                              = 1,
    Accessory                                      = 2,
    Cloth_Gear_VestBag                             = 3,
    Cloth_Gear_MyBag                               = 4,
    Cloth_Gear_Headset                             = 5,
    Cloth_Gear_Helmet                              = 6,
    Cloth_Gear_FaceShield                          = 7,
    Cloth_Gear_Vest                                = 8,
    Cloth_Gear_GasMask                             = 9,
    Cloth_Gear_ThighArmor                          = 10,
    ESGInvItemIDEquipmentType_MAX                  = 11

};


// Enum  /Script/SGFramework.ESGInvItemIdType
enum class ESGInvItemIdType : uint8_t
{
    None                                           = 0,
    Weapon                                         = 1,
    Weapon_MainWeapon                              = 2,
    Weapon_Pistol                                  = 3,
    Weapon_Melee                                   = 4,
    Weapon_Throwable                               = 5,
    Weapon_Tactical                                = 6,
    Special_SpecialItem                            = 7,
    Weapon_Shield                                  = 8,
    Accessory                                      = 9,
    Accessory_Accessory                            = 10,
    Accessory_Accessory_Magazine                   = 11,
    Accessory_Ammunition                           = 12,
    Accessory_Accessory_Flash                      = 13,
    Accessory_Accessory_Laser                      = 14,
    Accessory_Accessory_Shield                     = 15,
    Cloth                                          = 16,
    Cloth_Gear                                     = 17,
    Cloth_Gear_VestBag                             = 18,
    Cloth_Gear_VestBag_NoArmor                     = 19,
    Cloth_Gear_VestBag_Armor                       = 20,
    Cloth_Gear_MyBag                               = 21,
    Cloth_Gear_Headset                             = 22,
    Cloth_Gear_Helmet                              = 23,
    Cloth_Gear_FaceShield                          = 24,
    Cloth_Gear_Vest                                = 25,
    Cloth_Gear_Armband                             = 26,
    Cloth_Gear_EyeWear                             = 27,
    Cloth_Gear_SafeBox                             = 28,
    Cloth_Gear_VirtualPocket                       = 29,
    Cloth_Gear_KeyContainer                        = 30,
    Cloth_Gear_GasMask                             = 31,
    Cloth_Gear_ThighArmor                          = 32,
    Other                                          = 33,
    Other_Medicine                                 = 34,
    Other_Medicine_Stimulator                      = 35,
    Other_Card                                     = 36,
    Other_Currency                                 = 37,
    Other_Food                                     = 38,
    Other_Food_Drink                               = 39,
    Other_Food_Food                                = 40,
    Other_Key                                      = 41,
    Other_Map                                      = 42,
    Other_Chest                                    = 43,
    Other_Other                                    = 44,
    Other_Other_DogTag                             = 45,
    Other_Other_ActItem                            = 46,
    Other_Other_GiftPack                           = 47,
    Other_Other_TaskItem                           = 48,
    Other_Other_MasterKey                          = 49,
    Other_Other_MasterCard                         = 50,
    Other_Other_MasterKeyCard                      = 51,
    VehicleKey                                     = 52,
    VirtualUnique                                  = 53,
    VirtualUnique_Fashion                          = 54,
    VirtualUnique_Fashion_Glove                    = 55,
    VirtualUnique_Fashion_Melee                    = 56,
    VirtualUnique_Ornament                         = 57,
    VirtualUnique_Fashion_Badge                    = 58,
    VirtualUnique_Fashion_Gesture                  = 59,
    VirtualUnique_Equip_Avatar                     = 60,
    Combination                                    = 61,
    ESGInvItemIdType_MAX                           = 62

};


// Enum  /Script/SGFramework.EEnterLadderType
enum class EEnterLadderType : uint8_t
{
    None                                           = 0,
    Bottom                                         = 1,
    Top                                            = 2,
    EEnterLadderType_MAX                           = 3

};


// Enum  /Script/SGFramework.EDetectorState
enum class EDetectorState : uint8_t
{
    Activated                                      = 0,
    Deactivated                                    = 1,
    PowerOnAnim                                    = 2,
    PowerOff                                       = 3,
    EDetectorState_MAX                             = 4

};


// Enum  /Script/SGFramework.ESGLinearMotionSimulationStageEndConditionType
enum class ESGLinearMotionSimulationStageEndConditionType : uint8_t
{
    None                                           = 0,
    EndSpeed                                       = 1,
    TotalDistance                                  = 2,
    TotalTime                                      = 3,
    SGLinearMotionEndConditionType_MAX             = 4,
    ESGLinearMotionSimulationStageEndConditionType_MAX = 5

};


// Enum  /Script/SGFramework.ESGLinearMotionSimulationStageInitialSpeedType
enum class ESGLinearMotionSimulationStageInitialSpeedType : uint8_t
{
    None                                           = 0,
    CurrentStageConfig                             = 1,
    LastStageEndSpeed                              = 2,
    SGLinearMotionInitialSpeedType_MAX             = 3,
    ESGLinearMotionSimulationStageInitialSpeedType_MAX = 4

};


// Enum  /Script/SGFramework.EBloodColor
enum class EBloodColor : uint8_t
{
    BloodColore_Normal                             = 0,
    BloodColor_Red                                 = 1,
    EBloodColor_MAX                                = 2

};


// Enum  /Script/SGFramework.ESimpleAnimationState
enum class ESimpleAnimationState : uint8_t
{
    Closed                                         = 0,
    Opening                                        = 1,
    Opened                                         = 2,
    Closing                                        = 3,
    ESimpleAnimationState_MAX                      = 4

};


// Enum  /Script/SGFramework.EMissionTaskType
enum class EMissionTaskType : uint8_t
{
    E_TASK_TYPE_NONE                               = 0,
    E_TASK_TYPE_MAIN                               = 1,
    E_TASK_TYPE_DAILY                              = 2,
    E_TASK_TYPE_ACT                                = 3,
    E_TASK_TYPE_WEEKLY                             = 4,
    E_TASK_TYPE_ERGENT                             = 5,
    E_TASK_TYPE_SEASON_WEEK                        = 6,
    E_TASK_TYPE_SEASON                             = 7,
    E_TASK_TYPE_MENTOR                             = 8,
    E_TASK_TYPE_MAX                                = 9

};


// Enum  /Script/SGFramework.ESGSettlemetMessageFlag
enum class ESGSettlemetMessageFlag : uint8_t
{
    ESGSettlemetFlag_None                          = 0,
    ESGSettlemetFlag_MergeMailToItems              = 1,
    ESGSettlemetFlag_DeductingTeammatesProps       = 2,
    ESGSettlemetFlag_MAX                           = 3

};


// Enum  /Script/SGFramework.ESGInventoryTagFunction
enum class ESGInventoryTagFunction : uint8_t
{
    ESGInventoryTagFunction_None                   = 0,
    ESGInventoryTagFunction_LimitThrow             = 1,
    ESGInventoryTagFunction_LimitMove              = 2,
    ESGInventoryTagFunction_LimitPickUp            = 3,
    ESGInventoryTagFunction_RollUpBag              = 4,
    ESGInventoryTagFunction_TakeOutReplace         = 5,
    ESGInventoryTagFunction_NotTakeOut             = 6,
    ESGInventoryTagFunction_NotDrop                = 7,
    ESGInventoryTagFunction_MAX                    = 8

};


// Enum  /Script/SGFramework.ESGInventoryTagEffectiveRelation
enum class ESGInventoryTagEffectiveRelation : uint8_t
{
    ESGInventoryTagEffectiveRelation_All           = 0,
    ESGInventoryTagEffectiveRelation_Self          = 1,
    ESGInventoryTagEffectiveRelation_NotSelf       = 2,
    ESGInventoryTagEffectiveRelation_SameTeam      = 3,
    ESGInventoryTagEffectiveRelation_SameTeamExceptSelf = 4,
    ESGInventoryTagEffectiveRelation_NotSameTeam   = 5,
    ESGInventoryTagEffectiveRelation_SameFaction   = 6,
    ESGInventoryTagEffectiveRelation_NotSameFaction = 7,
    ESGInventoryTagEffectiveRelation_MAX           = 8

};


// Enum  /Script/SGFramework.ESGTakeOutReplaceType
enum class ESGTakeOutReplaceType : uint8_t
{
    ESGTakeOutReplaceType_None                     = 0,
    ESGTakeOutReplaceType_All                      = 1,
    ESGTakeOutReplaceType_SameTeam                 = 2,
    ESGTakeOutReplaceType_NotSameTeam              = 3,
    ESGTakeOutReplaceType_OrderFaction             = 4,
    ESGTakeOutReplaceType_NotSameFaction           = 5,
    ESGTakeOutReplaceType_MAX                      = 6

};


// Enum  /Script/SGFramework.ESecondModeMatchType
enum class ESecondModeMatchType : uint8_t
{
    SecondModeMatchType_Mode                       = 0,
    SecondModeMatchType_Map                        = 1,
    SecondModeMatchType_MAX                        = 2

};


// Enum  /Script/SGFramework.ESGMonitorStatus
enum class ESGMonitorStatus : uint8_t
{
    EMonitorStatus_Deployable                      = 0,
    EMonitorStatus_Viewable                        = 1,
    EMonitorStatus_Viewing                         = 2,
    EMonitorStatus_Destroyed                       = 3,
    EMonitorStatus_Max                             = 4

};


// Enum  /Script/SGFramework.ESGMonitorType
enum class ESGMonitorType : uint8_t
{
    EMonitorType_Recyclable                        = 0,
    EMonitorType_FixedPoint                        = 1,
    EMonitorType_MAX                               = 2

};


// Enum  /Script/SGFramework.ESGTickReason
enum class ESGTickReason : uint8_t
{
    None                                           = 0,
    Construct                                      = 101,
    Initialize                                     = 102,
    NotReady                                       = 103,
    TobeReady                                      = 104,
    BeginPlay                                      = 105,
    EndPlay                                        = 106,
    EndGame                                        = 107,
    NotUseTick                                     = 108,
    ActiveUpdated                                  = 109,
    VisibilityUpdated                              = 110,
    ViewTargetChanged                              = 111,
    ModeChanged                                    = 112,
    OwnerChanged                                   = 113,
    Optimize                                       = 114,
    Significance                                   = 115,
    SignificanceA                                  = 116,
    SignificanceB                                  = 117,
    SignificanceC                                  = 118,
    SignificanceD                                  = 119,
    SignificanceE                                  = 120,
    SigTickLimitTask                               = 121,
    LODOptimize                                    = 122,
    PlayAnimation                                  = 123,
    AnimationComplete                              = 124,
    ObjectPool                                     = 125,
    IsPreview                                      = 126,
    Loading                                        = 127,
    Exception                                      = 128,
    TickSwitch                                     = 129,
    TickComplete                                   = 130,
    MeshUpdated                                    = 131,
    AvatarUpdated                                  = 132,
    AnimationUpdated                               = 133,
    MaterialUpdated                                = 134,
    TransformUpdated                               = 135,
    StateUpdated                                   = 136,
    AdapterUpdated                                 = 137,
    MergeFinished                                  = 138,
    WeaponAssemble3POpt                            = 139,
    GameFlowUpdated                                = 140,
    ToStart                                        = 141,
    ToStop                                         = 142,
    Reset                                          = 143,
    Reconnect                                      = 144,
    SpanwAI                                        = 145,
    StartFire                                      = 146,
    StopFire                                       = 147,
    ThrowProjectile                                = 148,
    WeaponSwitch                                   = 149,
    CalcDamage                                     = 150,
    DelayTodo                                      = 151,
    MovePoseUpdate                                 = 152,
    Sleep                                          = 153,
    VehicleEnterLeave                              = 154,
    ToDestroy                                      = 155,
    Dead                                           = 156,
    Revived                                        = 157,
    DEBUG                                          = 158,
    P_LOCK                                         = 159,
    ESGTickReason_MAX                              = 160

};


// Enum  /Script/SGFramework.ETickDisableFlag
enum class ETickDisableFlag : uint8_t
{
    TickDisableFlag_None                           = 0,
    TickDisableFlag_Corpse                         = 1,
    TickDisableFlag_Reserved1                      = 2,
    TickDisableFlag_Reserved2                      = 4,
    TickDisableFlag_Reserved3                      = 8,
    TickDisableFlag_Reserved4                      = 16,
    TickDisableFlag_All                            = 255,
    TickDisableFlag_MAX                            = 256

};


// Enum  /Script/SGFramework.EOrnamentSimulateMethod
enum class EOrnamentSimulateMethod : uint8_t
{
    None                                           = 0,
    RigidBody                                      = 1,
    Kawaii                                         = 2,
    SpringBone                                     = 3,
    EOrnamentSimulateMethod_MAX                    = 4

};


// Enum  /Script/SGFramework.ESGParadropAnnounceType
enum class ESGParadropAnnounceType : uint8_t
{
    None                                           = 0,
    NoAnnounce                                     = 1,
    Normal                                         = 2,
    Special                                        = 3,
    ESGParadropAnnounceType_MAX                    = 4

};


// Enum  /Script/SGFramework.ESGParadropState
enum class ESGParadropState : uint8_t
{
    None                                           = 0,
    Throwing                                       = 1,
    Falling                                        = 2,
    Landing                                        = 3,
    Done                                           = 4,
    ESGParadropState_MAX                           = 5

};


// Enum  /Script/SGFramework.ETargetNotInRangeReason
enum class ETargetNotInRangeReason : uint8_t
{
    None                                           = 0,
    InsideEndRange                                 = 1,
    OutsideStartRange                              = 2,
    Other                                          = 3,
    ETargetNotInRangeReason_MAX                    = 4

};


// Enum  /Script/SGFramework.ELockOwner
enum class ELockOwner : uint8_t
{
    LockOwner_None                                 = 0,
    LockOwner_BreakWindow                          = 1,
    LockOwner_SearchAndKill                        = 2,
    LockOwner_SearchAndLoot                        = 3,
    LockOwner_MAX                                  = 4

};


// Enum  /Script/SGFramework.ESGInputLockType
enum class ESGInputLockType : uint8_t
{
    ESGInputLockType_None                          = 0,
    ESGInputLockType_LoadProtect                   = 1,
    ESGInputLockType_Reconnect                     = 2,
    ESGInputLockType_ApplyMOV                      = 3,
    ESGInputLockType_Tutorial                      = 4,
    ESGInputLockType_GameAbility                   = 5,
    ESGInputLockType_MAX                           = 6

};


// Enum  /Script/SGFramework.EPlayerTouchSettlementType
enum class EPlayerTouchSettlementType : uint8_t
{
    EPlayerTouchSettlementType_NotTouch            = 0,
    EPlayerTouchSettlementType_Escape              = 1,
    EPlayerTouchSettlementType_Died                = 2,
    EPlayerTouchSettlementType_MIA                 = 3,
    EPlayerTouchSettlementType_Quit                = 4,
    EPlayerTouchSettlementType_NoReenter           = 5,
    EPlayerTouchSettlementType_Victory             = 6,
    EPlayerTouchSettlementType_Failed              = 7,
    EPlayerTouchSettlementType_BRTopThreeQuit      = 8,
    EPlayerTouchSettlementType_MAX                 = 9

};


// Enum  /Script/SGFramework.EBattleResultTier3Style
enum class EBattleResultTier3Style : uint8_t
{
    E_None                                         = 0,
    E_Value                                        = 1,
    E_VictoryValue                                 = 2,
    E_Score                                        = 3,
    E_ConvertedValue                               = 4,
    E_MAX                                          = 5

};


// Enum  /Script/SGFramework.EBattleResultTier2Style
enum class EBattleResultTier2Style : uint8_t
{
    E_None                                         = 0,
    E_Result                                       = 1,
    E_Rank                                         = 2,
    E_ArenaRank                                    = 3,
    E_MAX                                          = 4

};


// Enum  /Script/SGFramework.ESGPickUpGroupType
enum class ESGPickUpGroupType : uint8_t
{
    Type_None                                      = 0,
    Type_Group                                     = 1,
    Type_Single                                    = 2,
    Type_Area                                      = 3,
    Type_MAX                                       = 4

};


// Enum  /Script/SGFramework.ESGUIInputMode
enum class ESGUIInputMode : uint8_t
{
    E_UnInited                                     = 0,
    E_Mobile                                       = 1,
    E_UIOnly                                       = 2,
    E_GameOnly                                     = 3,
    E_MAX                                          = 4

};


// Enum  /Script/SGFramework.ESGMagType
enum class ESGMagType : uint8_t
{
    MagType_NoneADS                                = 0,
    MagType_ADS                                    = 1,
    MagType_1x                                     = 2,
    MagType_2d5x                                   = 3,
    MagType_3x                                     = 4,
    MagType_3d5x                                   = 5,
    MagType_4x                                     = 6,
    MagType_6x                                     = 7,
    MagType_6d5x                                   = 8,
    MagType_9x                                     = 9,
    MagType_10x                                    = 10,
    MagType_16x                                    = 11,
    MagType_20x                                    = 12,
    MagType_2x                                     = 13,
    MagType_7x                                     = 14,
    MagType_5x                                     = 15,
    MagType_15x                                    = 16,
    MagType_MAX                                    = 17

};


// Enum  /Script/SGFramework.EGlobalSensitivityType
enum class EGlobalSensitivityType : uint8_t
{
    ESensitivityType_Low                           = 0,
    ESensitivityType_Normal                        = 1,
    ESensitivityType_High                          = 2,
    ESensitivityType_Custom                        = 3,
    ESensitivityType_MAX                           = 4

};


// Enum  /Script/SGFramework.EJoyStickMode
enum class EJoyStickMode : uint8_t
{
    EJoyStickMode_None                             = 0,
    EJoyStickMode_CustomPanel                      = 1,
    EJoyStickMode_Normal                           = 2,
    EJoyStickMode_EnterCar                         = 3,
    EJoyStickMode_Driving                          = 4,
    EJoyStickMode_Skydiving_Plane                  = 5,
    EJoyStickMode_Skydiving                        = 6,
    EJoyStickMode_BigMap                           = 7,
    EJoyStickMode_VehiclePassengerInCar            = 8,
    EJoyStickMode_VehiclePassengerLeanOut          = 9,
    EJoyStickMode_Bag                              = 10,
    EJoyStickMode_Swim                             = 11,
    EJoyStickMode_Spectating                       = 12,
    EJoyStickMode_DrivingMode2                     = 13,
    EJoyStickMode_FreeCamera                       = 14,
    EJoyStickMode_DrivingMode3                     = 15,
    EJoyStickMode_MAX                              = 16

};


// Enum  /Script/SGFramework.EPointIndexType
enum class EPointIndexType : uint8_t
{
    PointIndex_Movement                            = 0,
    PointIndex_Rotation                            = 1,
    PointIndex_MAX                                 = 2

};


// Enum  /Script/SGFramework.EPlayerIdentityType
enum class EPlayerIdentityType : uint8_t
{
    None                                           = 0,
    OBPlayer                                       = 1,
    CompetitionPlayer                              = 2,
    Administrator                                  = 3,
    EPlayerIdentityType_MAX                        = 4

};


// Enum  /Script/SGFramework.ESGCharRelevancyRoleStatus
enum class ESGCharRelevancyRoleStatus : uint8_t
{
    None                                           = 0,
    DBNO                                           = 1,
    DEAD                                           = 2,
    ESGCharRelevancyRoleStatus_MAX                 = 3

};


// Enum  /Script/SGFramework.ESGCharRelevancyBehavior
enum class ESGCharRelevancyBehavior : uint8_t
{
    None                                           = 0,
    Jump                                           = 1,
    Landed                                         = 2,
    TidyUpBag                                      = 3,
    UsingInventory                                 = 4,
    BeHit                                          = 5,
    PickUpItem                                     = 6,
    TurnInPlace                                    = 7,
    Speak                                          = 8,
    ESGCharRelevancyBehavior_MAX                   = 9

};


// Enum  /Script/SGFramework.ESGCharRelevancyMovePose
enum class ESGCharRelevancyMovePose : uint8_t
{
    Stand                                          = 0,
    Crouch                                         = 1,
    Sprint                                         = 2,
    Prone                                          = 3,
    ESGCharRelevancyMovePose_MAX                   = 4

};


// Enum  /Script/SGFramework.ESGCharRelevancyRepPausedMode
enum class ESGCharRelevancyRepPausedMode : uint8_t
{
    None                                           = 0,
    All_Paused                                     = 1,
    Period_Paused                                  = 2,
    OnlyMove_Paused                                = 3,
    ESGCharRelevancyRepPausedMode_MAX              = 4

};


// Enum  /Script/SGFramework.EChaseActivityScoreMode
enum class EChaseActivityScoreMode : uint8_t
{
    Player                                         = 0,
    Team                                           = 1,
    EChaseActivityScoreMode_MAX                    = 2

};


// Enum  /Script/SGFramework.EDetectTargetType
enum class EDetectTargetType : uint8_t
{
    DetectTargetType_Inventory                     = 0,
    DetectTargetType_Container                     = 1,
    DetectTargetType_MAX                           = 2

};


// Enum  /Script/SGFramework.EPlayerSimplePoseType
enum class EPlayerSimplePoseType : uint8_t
{
    SimplePose_Stand                               = 0,
    SimplePose_Sprint                              = 1,
    SimplePose_Crouch                              = 2,
    SimplePose_Prone                               = 3,
    SimplePose_DBNO                                = 4,
    SimplePose_Max                                 = 5

};


// Enum  /Script/SGFramework.EGamePlayer1PResultType
enum class EGamePlayer1PResultType : uint8_t
{
    None                                           = 0,
    InvalidCharacter                               = 1,
    InvalidLocalPC                                 = 2,
    NotControlled                                  = 3,
    ControlledByOther                              = 4,
    NotOwnered                                     = 5,
    OwneredByOther                                 = 6,
    OtherReason                                    = 7,
    UnknownError                                   = 8,
    EGamePlayer1PResultType_MAX                    = 9

};


// Enum  /Script/SGFramework.EGamePlayer1PType
enum class EGamePlayer1PType : uint8_t
{
    ViewTarget                                     = 0,
    Owner                                          = 1,
    EGamePlayer1PType_MAX                          = 2

};


// Enum  /Script/SGFramework.ESameTeamResultType
enum class ESameTeamResultType : uint8_t
{
    None                                           = 0,
    SameTeam                                       = 1,
    NotSameTeam                                    = 2,
    ESameTeamResultType_MAX                        = 3

};


// Enum  /Script/SGFramework.ECharacterResultType
enum class ECharacterResultType : uint8_t
{
    None                                           = 0,
    Success                                        = 1,
    Failed                                         = 2,
    ECharacterResultType_MAX                       = 3

};


// Enum  /Script/SGFramework.EPlayerStateResultType
enum class EPlayerStateResultType : uint8_t
{
    None                                           = 0,
    Success                                        = 1,
    WaitingToCreate                                = 2,
    NotRegisterd                                   = 3,
    EPlayerStateResultType_MAX                     = 4

};


// Enum  /Script/SGFramework.EOnSameTeamResultType
enum class EOnSameTeamResultType : uint8_t
{
    None                                           = 0,
    NotValid                                       = 1,
    SameTeam                                       = 2,
    NotSameTeam                                    = 3,
    EOnSameTeamResultType_MAX                      = 4

};


// Enum  /Script/SGFramework.ESGViewTargetType
enum class ESGViewTargetType : uint8_t
{
    ESGViewTargetChangeReason_None                 = 0,
    ESGViewTargetChangeReason_PC                   = 1,
    ESGViewTargetChangeReason_PS                   = 2,
    ESGViewTargetChangeReason_Character            = 3,
    ESGViewTargetChangeReason_Drone                = 4,
    ESGViewTargetChangeReason_Spectat              = 5,
    ESGViewTargetChangeReason_Monitor              = 6,
    ESGViewTargetChangeReason_FixedPointMonitor    = 7,
    ESGViewTargetChangeReason_MAX                  = 8

};


// Enum  /Script/SGFramework.ENPCCourierOrderState
enum class ENPCCourierOrderState : uint8_t
{
    None                                           = 0,
    Default_NoCourier                              = 1,
    CourierPrepared                                = 2,
    OrderPreparing                                 = 3,
    OrderDeliveried                                = 4,
    OrderDropped                                   = 5,
    OrderSigned                                    = 6,
    OrderClosed                                    = 7,
    ENPCCourierOrderState_MAX                      = 8

};


// Enum  /Script/SGFramework.ENPCCourierCourierType
enum class ENPCCourierCourierType : uint8_t
{
    None                                           = 0,
    Scav_Normal                                    = 1,
    PMC_Normal                                     = 2,
    Mediate_Support1                               = 3,
    Mediate_Support2                               = 4,
    Mediate_Leading                                = 5,
    Fight_Loser                                    = 6,
    Fight_Winner                                   = 7,
    Group_Captain                                  = 8,
    Group_Second                                   = 9,
    Group_Third                                    = 10,
    Group_Forth                                    = 11,
    ENPCCourierCourierType_MAX                     = 12

};


// Enum  /Script/SGFramework.ETakeOutLimitType
enum class ETakeOutLimitType : uint8_t
{
    TakeOutLimitType_None                          = 0,
    TakeOutLimitType_SelfTakeIn                    = 1,
    TakeOutLimitType_TeamTakeIn                    = 2,
    TakeOutLimitType_OrderTakeInSourceType         = 3,
    TakeOutLimitType_FactionTakeIn                 = 4,
    TakeOutLimitType_MAX                           = 5

};


// Enum  /Script/SGFramework.EAnimOffsetType
enum class EAnimOffsetType : uint8_t
{
    EAnimOffsetType_None                           = 0,
    EAnimOffsetType_Rot                            = 1,
    EAnimOffsetType_Loc                            = 2,
    EAnimOffsetType_SightRot                       = 3,
    EAnimOffsetType_MAX                            = 4

};


// Enum  /Script/SGFramework.ECharacterHurtReason
enum class ECharacterHurtReason : uint8_t
{
    ECharacterHurtReason_None                      = 0,
    ECharacterHurtReason_GunShotPenetrateArmor     = 1,
    ECharacterHurtReason_GunShotNotPenetrateArmor  = 2,
    ECharacterHurtReason_GunShotNoArmor            = 3,
    ECharacterHurtReason_ThrownWeapon              = 4,
    ECharacterHurtReason_LackInFoodOrMoisture      = 5,
    ECharacterHurtReason_Debuff                    = 6,
    ECharacterHurtReason_Environment               = 7,
    ECharacterHurtReason_MeleeWeapon               = 8,
    ECharacterHurtReason_MAX                       = 9

};


// Enum  /Script/SGFramework.EDeathType
enum class EDeathType : uint8_t
{
    DeathType_None                                 = 0,
    DeathType_HeadShot                             = 1,
    DeathType_ChestShot                            = 2,
    DeathType_OtherShot                            = 3,
    DeathType_MAX                                  = 4

};


// Enum  /Script/SGFramework.ESGCharacterCoverAimingState
enum class ESGCharacterCoverAimingState : uint8_t
{
    CharacterCoverAimingState_Side                 = 0,
    CharacterCoverAimingState_Forward              = 1,
    CharacterCoverAimingState_Top                  = 2,
    CharacterCoverAimingState_MAX                  = 3

};


// Enum  /Script/SGFramework.ESGCharacterCoverState
enum class ESGCharacterCoverState : uint8_t
{
    CharacterCoverState_None                       = 0,
    CharacterCoverState_Idle                       = 1,
    CharacterCoverState_Moving                     = 2,
    CharacterCoverState_Blindfire                  = 3,
    CharacterCoverState_Aiming                     = 4,
    CharacterCoverState_LookingOut                 = 5,
    CharacterCoverState_MAX                        = 6

};


// Enum  /Script/SGFramework.ESGCoverHeight
enum class ESGCoverHeight : uint8_t
{
    CoverHeight_Heigh                              = 0,
    CoverHeight_Low                                = 1,
    CoverHeight_MAX                                = 2

};


// Enum  /Script/SGFramework.ESGCoverType
enum class ESGCoverType : uint8_t
{
    Cover_None                                     = 0,
    Cover_Both                                     = 1,
    Cover_Right                                    = 2,
    Cover_Left                                     = 3,
    Cover_MAX                                      = 4

};


// Enum  /Script/SGFramework.EVaultEndMoveType
enum class EVaultEndMoveType : uint8_t
{
    EVaultEndMove_Walking                          = 0,
    EVaultEndMove_Falling                          = 1,
    EVaultEndMove_MAX                              = 2

};


// Enum  /Script/SGFramework.EVaultAnimType
enum class EVaultAnimType : uint8_t
{
    EVaultAnim_None                                = 0,
    EVA_Climb_FH_Stationary                        = 1,
    EVA_Climb_FH_Move                              = 2,
    EVA_Climb_Rifle_Stationary                     = 3,
    EVA_Climb_Rifle_Move                           = 4,
    EVA_Vault_FH_Stationary                        = 5,
    EVA_Vault_FH_MoveNarrow                        = 6,
    EVA_Vault_FH_Move                              = 7,
    EVA_Vault_Rifle_Stationary                     = 8,
    EVA_Vault_Rifle_MoveNarrow                     = 9,
    EVA_Vault_Rifle_Move                           = 10,
    EVaultAnimType_MAX                             = 11

};


// Enum  /Script/SGFramework.EObstacleHeightType
enum class EObstacleHeightType : uint8_t
{
    EObstacleHeight_None                           = 0,
    EObstacleHeight                                = 1,
    EObstacleHeight                                = 2,
    EObstacleHeight                                = 3,
    EObstacleHeight                                = 4,
    EObstacleHeight                                = 5,
    EObstacleHeight_Max                            = 6

};


// Enum  /Script/SGFramework.EClimbVaultChoice
enum class EClimbVaultChoice : uint8_t
{
    EChoice_None                                   = 0,
    EChoice_Climb                                  = 1,
    EChoice_Vault                                  = 2,
    EChoice_MAX                                    = 3

};


// Enum  /Script/SGFramework.ESGCustomMovementType
enum class ESGCustomMovementType : uint8_t
{
    SGCustomMovementType_None                      = 0,
    SGCustomMovementType_Valting                   = 1,
    SGCustomMovementType_Climbing                  = 2,
    SGCustomMovementType_LadderClimbing            = 3,
    SGCustomMovementType_JumpEnterLadder           = 4,
    SGCustomMovementType_EmplaceGunMove            = 5,
    SGCustomMovementType_ZiplineMove               = 6,
    SGCustomMovementType_WalkToTargetPoint         = 7,
    SGCustomMovementType_MAX                       = 8

};


// Enum  /Script/SGFramework.EAssistAimMode
enum class EAssistAimMode : uint8_t
{
    Closed                                         = 0,
    Normal                                         = 1,
    Improved                                       = 2,
    EAssistAimMode_MAX                             = 3

};


// Enum  /Script/SGFramework.EMovementFailureReason
enum class EMovementFailureReason : uint8_t
{
    MovementFailureReason_None                     = 0,
    MovementFailureReason_CharacterNotExist        = 1,
    MovementFailureReason_AlreadyInState           = 2,
    MovementFailureReason_NotSupport               = 3,
    MovementFailureReason_TooFrequent              = 4,
    MovementFailureReason_SimulatingPhysics        = 5,
    MovementFailureReason_Swimming                 = 6,
    MovementFailureReason_UsingItem                = 7,
    MovementFailureReason_InDBNOStatus             = 8,
    MovementFailureReason_NotPassCollisionTest     = 9,
    MovementFailureReason_TouchWaterVolume         = 10,
    MovementFailureReason_CanNotStandNow           = 11,
    MovementFailureReason_CanNotProneNow           = 12,
    MovementFailureReason_Falling                  = 13,
    MovementFailureReason_LadderClimbing           = 14,
    MovementFailureReason_MAX                      = 15

};


// Enum  /Script/SGFramework.ETurnInfo
enum class ETurnInfo : uint8_t
{
    None                                           = 0,
    Left                                           = 1,
    Right                                          = 2,
    ETurnInfo_MAX                                  = 3

};


// Enum  /Script/SGFramework.EHitDirection
enum class EHitDirection : uint8_t
{
    HitDirection_None                              = 0,
    HitDirection_Front                             = 1,
    HitDirection_Back                              = 2,
    HitDirection_Left                              = 3,
    HitDirection_Right                             = 4,
    HitDirection_Swim                              = 5,
    HitDirection_Fall                              = 6,
    HitDirection_MAX                               = 7

};


// Enum  /Script/SGFramework.ESGBlockType
enum class ESGBlockType : uint8_t
{
    None                                           = 0,
    ESGBlockType_Instant                           = 1,
    ESGBlockType_Last                              = 2,
    ESGBlockType_MAX                               = 3

};


// Enum  /Script/SGFramework.EProjectileMolotovType
enum class EProjectileMolotovType : uint8_t
{
    Normal                                         = 0,
    PoisonGas                                      = 1,
    EProjectileMolotovType_MAX                     = 2

};


// Enum  /Script/SGFramework.ETrajectoryDrawPolicy
enum class ETrajectoryDrawPolicy : uint8_t
{
    DrawPolicy_Spline                              = 0,
    DrawPolicy_BeamParticle                        = 1,
    DrawPolicy_InstanceStaticMesh                  = 2,
    DrawPolicy_ProceduralMesh_Simple               = 3,
    DrawPolicy_ProceduralMesh_Complex              = 4,
    DrawPolicy_MAX                                 = 5

};


// Enum  /Script/SGFramework.ERangeInAreaType
enum class ERangeInAreaType : uint8_t
{
    None                                           = 0,
    Escape                                         = 1,
    Door                                           = 2,
    ERangeInAreaType_MAX                           = 3

};


// Enum  /Script/SGFramework.RotateType
enum class RotateType : uint8_t
{
    ClockWise                                      = 0,
    AntiClockWise                                  = 1,
    RotateType_MAX                                 = 2

};


// Enum  /Script/SGFramework.ESGReplayContentType
enum class ESGReplayContentType : uint8_t
{
    Normal                                         = 0,
    KillCam                                        = 1,
    Highlights                                     = 2,
    ESGReplayContentType_MAX                       = 3

};


// Enum  /Script/SGFramework.ESGReplayTypes
enum class ESGReplayTypes : uint8_t
{
    None                                           = 0,
    MFLocalFileNetworkReplayStreaming              = 1,
    MFHttpNetworkReplayStreaming                   = 2,
    ESGReplayTypes_MAX                             = 3

};


// Enum  /Script/SGFramework.ESCSTimeType
enum class ESCSTimeType : uint8_t
{
    ESCSTimeType_Max                               = 0,
    ESCSTimeType_Min                               = 1

};


// Enum  /Script/SGFramework.ESCSType
enum class ESCSType : uint8_t
{
    ESCSType_FollowState                           = 0,
    ESCSType_OnlyTime                              = 1,
    ESCSType_FollowAndTime                         = 2,
    ESCSType_MAX                                   = 3

};


// Enum  /Script/SGFramework.ECharacterStateForAntiFlow
enum class ECharacterStateForAntiFlow : uint8_t
{
    None                                           = 0,
    Sprint                                         = 1,
    Prone                                          = 2,
    Crouch                                         = 3,
    ECharacterStateForAntiFlow_MAX                 = 4

};


// Enum  /Script/SGFramework.EAntiType
enum class EAntiType : uint8_t
{
    None                                           = 0,
    BulletRays                                     = 1,
    EAntiType_MAX                                  = 2

};


// Enum  /Script/SGFramework.ETextureMergeID
enum class ETextureMergeID : uint8_t
{
    TextureMergeID_None                            = 0,
    TextureMergeID_Diffuse                         = 1,
    TextureMergeID_NormalRoughness                 = 2,
    TextureMergeID_MetalAO                         = 3,
    TextureMergeID_SkinMask                        = 4,
    TextureMergeID_SkinTiling                      = 5,
    TextureMergeID_MAX                             = 6

};


// Enum  /Script/SGFramework.ESGSpecicalProjectile
enum class ESGSpecicalProjectile : uint8_t
{
    None                                           = 0,
    ESGSpecicalProjectile_SnowBall                 = 1,
    ESGSpecicalProjectile_MAX                      = 2

};


// Enum  /Script/SGFramework.ETooltipShowPositionVertical
enum class ETooltipShowPositionVertical : uint8_t
{
    None                                           = 0,
    Top                                            = 1,
    Center                                         = 2,
    Bottom                                         = 3,
    ETooltipShowPositionVertical_MAX               = 4

};


// Enum  /Script/SGFramework.ETooltipShowPositionHorizontal
enum class ETooltipShowPositionHorizontal : uint8_t
{
    None                                           = 0,
    Left                                           = 1,
    Center                                         = 2,
    Right                                          = 3,
    ETooltipShowPositionHorizontal_MAX             = 4

};


// Enum  /Script/SGFramework.ESGVehicleLeavePointTraceChannel
enum class ESGVehicleLeavePointTraceChannel : uint8_t
{
    None                                           = 0,
    WorldStatic                                    = 1,
    WeaponTrace                                    = 2,
    ESGVehicleLeavePointTraceChannel_MAX           = 3

};


// Enum  /Script/SGFramework.EVehicleSoundType
enum class EVehicleSoundType : uint8_t
{
    EVehicleSound_None                             = 0,
    EVehicleSound_LocalEngineStartUp               = 1,
    EVehicleSound_RemoteEngineStartUp              = 2,
    EVehicleSound_EngineStop                       = 3,
    EVehicleSound_Engine                           = 4,
    EVehicleSound_BoostEngine                      = 5,
    EVehicleSound_StopBoostEngine                  = 6,
    EVehicleSound_Skid                             = 7,
    EVehicleSound_SkidEnd                          = 8,
    EVehicleSound_LocalHornPressed                 = 9,
    EVehicleSound_LocalHornReleased                = 10,
    EVehicleSound_RemoteHornPressed                = 11,
    EVehicleSound_RemoteHornReleased               = 12,
    EVehicleSound_Explode                          = 13,
    EVehicleSound_TireExplode                      = 14,
    EVehicleSound_BurningBeforeExplode             = 15,
    EVehicleSound_StopBurningBeforeExplode         = 16,
    EVehicleSound_BurningAfterExplode              = 17,
    EVehicleSound_StopBurningAfterExplode          = 18,
    EVehicleSound_BeHit                            = 19,
    EVehicleSound_HitAgainst                       = 20,
    EVehicleSound_Landing                          = 21,
    EVehicleSound_BrakeStart                       = 22,
    EVehicleSound_BrakeStop                        = 23,
    EVehicleSound_TyreNoiseStart                   = 24,
    EVehicleSound_TyreNoiseStop                    = 25,
    EVehicleSound_ShiftGears                       = 26,
    EVehicleSound_TurnToStart                      = 27,
    EVehicleSound_TurnToStop                       = 28,
    EVehicleSound_GetOn                            = 29,
    EVehicleSound_GetOff                           = 30,
    EVehicleSound_CameraShake                      = 31,
    EVehicleSound_MAX                              = 32

};


// Enum  /Script/SGFramework.EVehicleRTPC
enum class EVehicleRTPC : uint8_t
{
    EVehicleRTPC_None                              = 0,
    EVehicleRTPC_Speed                             = 1,
    EVehicleRTPC_RPM                               = 2,
    EVehicleRTPC_View                              = 3,
    EVehicleRTPC_TyreBrokenNum                     = 4,
    EVehicleRTPC_Gear                              = 5,
    EVehicleRTPC_CameraShakeScale                  = 6,
    EVehicleRTPC_CameraShakeType                   = 7,
    EVehicleRTPC_MAX                               = 8

};


// Enum  /Script/SGFramework.EVehicleSpawnType
enum class EVehicleSpawnType : uint8_t
{
    AllRandom                                      = 1,
    TotalCount                                     = 2,
    EVehicleSpawnType_MAX                          = 3

};


// Enum  /Script/SGFramework.EVehicleInteractionResult
enum class EVehicleInteractionResult : uint8_t
{
    GotOnAsDriver                                  = 0,
    GotOnAsPassenger                               = 1,
    GotOff                                         = 2,
    SwitchSeat                                     = 3,
    Failed                                         = 4,
    InvalidInputArguments                          = 5,
    EVehicleInteractionResult_MAX                  = 6

};


// Enum  /Script/SGFramework.ESGDriverViewMode
enum class ESGDriverViewMode : uint8_t
{
    ESGDVM_NormalView                              = 0,
    ESGDVM_EngineBayView                           = 1,
    ESGDVM_RearView                                = 2,
    ESGDVM_MAX                                     = 3

};


// Enum  /Script/SGFramework.ESGVehicleOwnership
enum class ESGVehicleOwnership : uint8_t
{
    None                                           = 0,
    Public                                         = 1,
    Key                                            = 2,
    Team                                           = 3,
    ESGVehicleOwnership_MAX                        = 4

};


// Enum  /Script/SGFramework.ESGVehicleAdjustType
enum class ESGVehicleAdjustType : uint8_t
{
    None                                           = 0,
    TimeStamp                                      = 1,
    DeltaPos                                       = 2,
    Reset                                          = 3,
    ESGVehicleAdjustType_MAX                       = 4

};


// Enum  /Script/SGFramework.EMoveSwayDamperAxis
enum class EMoveSwayDamperAxis : uint8_t
{
    None                                           = 0,
    Forward                                        = 1,
    Right                                          = 2,
    Up                                             = 3,
    Back                                           = 4,
    Left                                           = 5,
    Down                                           = 6,
    EMoveSwayDamperAxis_MAX                        = 7

};


// Enum  /Script/SGFramework.EPreloadAnimationMode
enum class EPreloadAnimationMode : uint8_t
{
    None                                           = 0,
    Minimal                                        = 1,
    All                                            = 2,
    EPreloadAnimationMode_MAX                      = 3

};


// Enum  /Script/SGFramework.ESGWeaponDisplayMode
enum class ESGWeaponDisplayMode : uint8_t
{
    EWeapDisplayMode_None                          = 0,
    EWeapDisplayMode_Zooming                       = 1,
    EWeapDisplayMode_FirstPerson                   = 2,
    EWeapDisplayMode_ThirdPerson                   = 3,
    EWeapDisplayMode_ThirdPersonOther              = 4,
    EWeapDisplayMode_MAX                           = 5

};


// Enum  /Script/SGFramework.ECaptureLightGroupType
enum class ECaptureLightGroupType : uint8_t
{
    Weapon                                         = 0,
    Helmet                                         = 1,
    HelmetAdapter                                  = 2,
    HorizontalAssembly                             = 3,
    ObliqueAssembly                                = 4,
    ThighArmor                                     = 5,
    ECaptureLightGroupType_MAX                     = 6

};


// Enum  /Script/SGFramework.EBoltState
enum class EBoltState : uint8_t
{
    BOLTSTATE_CLOSE                                = 0,
    BOLTSTATE_OPEN                                 = 1,
    BOLTSTATE_TONIL                                = 2,
    BOLTSTATE_MAX                                  = 3

};


// Enum  /Script/SGFramework.EWeapAnimRecoil
enum class EWeapAnimRecoil : uint8_t
{
    EWeapAnimRecoil_None                           = 0,
    EWeapAnimRecoil_Override                       = 1,
    EWeapAnimRecoil_Additive                       = 2,
    EWeapAnimRecoil_Wave                           = 3,
    EWeapAnimRecoil_Spring                         = 4,
    EWeapAnimRecoil_SpringDamper                   = 5,
    EWeapAnimRecoil_MAX                            = 6

};


// Enum  /Script/SGFramework.EEquimpedFlashlightType
enum class EEquimpedFlashlightType : uint8_t
{
    EquimpedFlashlightType_None                    = 0,
    EquimpedFlashlightType_OnlyNormalFlash         = 1,
    EquimpedFlashlightType_OnlyPurpleFlash         = 2,
    EquimpedFlashlightType_Both                    = 3,
    EquimpedFlashlightType_MAX                     = 4

};


// Enum  /Script/SGFramework.EWeaponAssemblePolicy
enum class EWeaponAssemblePolicy : uint8_t
{
    Default                                        = 0,
    FullAssemble_FullMesh                          = 1,
    FullAssemble_MergedMesh                        = 2,
    PartialAssemble_MergedMesh                     = 3,
    FullAssemble_NoneMesh                          = 4,
    OriginPath                                     = 5,
    None                                           = 6,
    EWeaponAssemblePolicy_MAX                      = 7

};


// Enum  /Script/SGFramework.EWeaponOwnershipQueryResult
enum class EWeaponOwnershipQueryResult : uint8_t
{
    Failed                                         = 0,
    Waiting                                        = 1,
    WeaponAssemble1P                               = 2,
    WeaponAssemble3P                               = 3,
    WeaponAssembleNoOwner                          = 4,
    EWeaponOwnershipQueryResult_MAX                = 5

};


// Enum  /Script/SGFramework.EWeaponOwnershipType
enum class EWeaponOwnershipType : uint8_t
{
    Default                                        = 0,
    Owner                                          = 1,
    NoOwner                                        = 2,
    EWeaponOwnershipType_MAX                       = 3

};


// Enum  /Script/SGFramework.ESGPerWeaponAnimSetAnimType
enum class ESGPerWeaponAnimSetAnimType : uint8_t
{
    EAnimType_Hand_ViewWeapon                      = 0,
    EAnimType_Weapon_ViewWeapon                    = 1,
    EAnimType_Hand_NoAmmoViewWeapon                = 2,
    EAnimType_Weapon_NoAmmoViewWeapon              = 3,
    EAnimType_Hand_BoltHoldOpenOrHammerDown        = 4,
    EAnimType_Weapon_BoltHoldOpenOrHammerDown      = 5,
    EAnimType_MAX                                  = 6

};


// Enum  /Script/SGFramework.EInfiniteAmmoMode
enum class EInfiniteAmmoMode : uint8_t
{
    EInfiniteAmmoMode_None                         = 0,
    EInfiniteAmmoMode_FireInfinite                 = 1,
    EInfiniteAmmoMode_FillInfinite                 = 2,
    EInfiniteAmmoMode_Max                          = 3

};


// Enum  /Script/SGFramework.ESGGrenadeDamageType
enum class ESGGrenadeDamageType : uint8_t
{
    None                                           = 0,
    EGrenadeDamageType_FragDamage                  = 1,
    EGrenadeDamageType_HegDamage                   = 2,
    EGrenadeDamageType_MolotovDamage               = 3,
    EGrenadeDamageType_Max                         = 4,
    ESGGrenadeDamageType_MAX                       = 5

};


// Enum  /Script/SGFramework.ESGWeaponReloadKind
enum class ESGWeaponReloadKind : uint8_t
{
    Unknown                                        = 0,
    Normal                                         = 1,
    OneByOne                                       = 2,
    MultiBores                                     = 3,
    ESGWeaponReloadKind_MAX                        = 4

};


// Enum  /Script/SGFramework.EAvoidValidationFlagType
enum class EAvoidValidationFlagType : uint32_t
{
    E_SetAdsMoaX                                   = 1,
    E_SetAdsMoaY                                   = 2,
    E_ToggleBulletGravity                          = 4,
    E_ToggleBulletSpread                           = 8,
    E_ToggleBulletRecoil                           = 16,
    E_RecoilHorizontal                             = 32,
    E_RecoilVertical                               = 64,
    E_Gunkick                                      = 128,
    E_SetAccuracy                                  = 256,
    E_ADotEnableSpread                             = 512,
    E_ADotEnableMoa                                = 1024,
    E_MAX                                          = 1025

};


// Enum  /Script/SGFramework.ESGWeaponValidateFailType
enum class ESGWeaponValidateFailType : uint8_t
{
    FailType_CheckFireMode                         = 0,
    FailType_CheckDamageThroughBody                = 1,
    FailType_CheckRotation                         = 2,
    FailType_CheckBulletFlyPath                    = 3,
    FailType_CheckBulletFlyPath_XY                 = 4,
    FailType_CheckBulletFlyPath_Z                  = 5,
    FailType_CheckFlyDistance                      = 6,
    FailType_CheckCauserLocation                   = 7,
    FailType_CheckStartFireXY                      = 8,
    FailType_CheckStartFireZ                       = 9,
    FailType_CheckDamageTakerLoc                   = 10,
    FailType_CheckBulletFlyImportantLoc            = 11,
    FailType_CheckBulletFlyEffectDis               = 12,
    FailType_CheckBulletFlyFirstDrop               = 13,
    FailType_CheckBulletFlyMaxDropDis              = 14,
    FailType_CheckBulletFlyBlock                   = 15,
    FailType_CheckBulletFlyDropVector              = 16,
    FailType_CheckBulletFlyDropAngle               = 17,
    FailType_CheckBulletFlyPathDropVector          = 18,
    FailType_CheckBulletFlyOneSectionBlock         = 19,
    FailType_CheckBulletFlyOneSectionBlock_Bias    = 20,
    FailType_CheckDamageValue                      = 21,
    FailType_CheckRecoil                           = 22,
    FailType_CheckAmmoClass                        = 23,
    FailType_CheckCaliberType                      = 24,
    FailType_CheckFireInterval_Single              = 25,
    FailType_CheckFireInterval_Auto                = 26,
    FailType_CheckFireInterval_Auto_FailCount      = 27,
    FailType_CheckShotGunMOAOrSpread               = 28,
    FailType_CheckFireSpread                       = 29,
    FailType_CheckRecoilWhenHit                    = 30,
    FailType_CheckAutoAiming                       = 31,
    FailType_CheckZoom                             = 32,
    FailType_CheckEnergy                           = 33,
    FailType_CheckAmmoWhenHit                      = 34,
    FailType_CheckStartFireLocBlockToCharacter     = 35,
    FailType_CheckBlockReverseDirection            = 36,
    FailType_CheckFireInterval_Burst               = 37,
    FailType_CheckFireInterval_BurstInner          = 38,
    FailType_CheckFireInfoHasHandled               = 39,
    FailType_CheckFireInfoHasHandled_HitLargerThanFire = 40,
    FailType_CheckFireEndLoc                       = 41,
    FailType_CheckNetStat_LagFail                  = 42,
    FailType_CheckNetStat_LossFail                 = 43,
    FailType_CheckNetStat_ImediatelyFail           = 44,
    FailType_CheckDamageTakerLocWeakNet            = 45,
    FailType_CheckDamageTakerLocVehicle            = 46,
    FailType_CheckRotationLimit_InVechile          = 47,
    FailType_CheckRotation_InVechile               = 48,
    FailType_CheckHitBone                          = 49,
    FailType_CheckNetStat_Lag_ImediatelyFail       = 50,
    FailType_CheckFireTimeIsTooEarly               = 51,
    FailType_CheckSumFail                          = 52,
    FailType_CheckDamageTakerLocWeakNet_InCover    = 53,
    FailType_CheckDSReceivePacketRatio             = 54,
    FailType_CheckDamageCauserWeakNet              = 55,
    FailType_CheckDamageCauserWeakNet_Lean         = 56,
    FailType_GunEnd                                = 100,
    FailType_MeleeCheckFireInterval                = 101,
    FailType_MeleeCheckPhase                       = 102,
    FailType_MeleeCheckPhaseInterval               = 103,
    FailType_MeleeCheckDamageValue                 = 104,
    FailType_MeleeCheckRotation                    = 105,
    FailType_MeleeCheckCauserLoc                   = 106,
    FailType_MeleeCheckCauserXY                    = 107,
    FailType_MeleeCheckCauserZ                     = 108,
    FailType_MeleeCheckTakerLoc                    = 109,
    FailType_MeleeCheckFireDis                     = 110,
    FailType_MeleeCheckBlock                       = 111,
    FailType_MeleeCheckBlockReverse                = 112,
    FailType_MAX                                   = 113

};


// Enum  /Script/SGFramework.EWeaponMergeStatus
enum class EWeaponMergeStatus : uint8_t
{
    EStatus_None                                   = 0,
    EStatus_Success                                = 1,
    EStatus_Policy                                 = 2,
    EStatus_InvalidParameter                       = 3,
    EStatus_NotEnoughAdapters                      = 4,
    EStatus_LoadingAdapters                        = 5,
    EStatus_Materials                              = 6,
    EStatus_WaitForShare                           = 7,
    EStatus_WaitForStreamIn                        = 8,
    EStatus_MeshMerge                              = 9,
    EStatus_MAX                                    = 10

};


// Enum  /Script/SGFramework.EWeaponMeshDisplayType
enum class EWeaponMeshDisplayType : uint8_t
{
    WeaponMeshDisplayType_Modular                  = 0,
    WeaponMeshDisplayType_Simple                   = 1,
    WeaponMeshDisplayType_Faraway                  = 2,
    WeaponMeshDisplayType_Hide                     = 3,
    WeaponMeshDisplayType_Default                  = 4,
    WeaponMeshDisplayType_MAX                      = 5

};


// Enum  /Script/SGFramework.ESGFireEffectParticleType
enum class ESGFireEffectParticleType : uint8_t
{
    EParticleType_Fire                             = 0,
    EParticleType_Fog                              = 1,
    EParticleType_Light                            = 2,
    EParticleType_Light_LDR                        = 3,
    EParticleType_Light3P                          = 4,
    EParticleType_Light3P_LDR                      = 5,
    EParticleType_Bullet                           = 6,
    EParticleType_Bullet3P                         = 7,
    EParticleType_BulletShell                      = 8,
    EParticleType_BulletShell3P                    = 9,
    EParticleType_Fire3P                           = 10,
    EParticleType_BulletTracer                     = 11,
    EParticleType_SmokeTrail                       = 12,
    EParticleType_Molotov                          = 13,
    EParticleType_CompositeFire                    = 14,
    EParticleType_CompositeFire3P                  = 15,
    EParticleType_MergeFire_FPHDR                  = 16,
    EParticleType_MergeFire_FPLDR                  = 17,
    EParticleType_MergeFire_TPHDR                  = 18,
    EParticleType_MergeFire_TPLDR                  = 19,
    EParticleType_Max                              = 20

};


// Enum  /Script/SGFramework.ETestAnimType
enum class ETestAnimType : uint8_t
{
    TestReload                                     = 0,
    TestFastReload                                 = 1,
    TestTacticalReload                             = 2,
    TestAmmoIn                                     = 3,
    TestAmmoOut                                    = 4,
    TestCheckWeapon                                = 5,
    TestCheckMagazine                              = 6,
    TestCheckFireMode0                             = 7,
    TestCheckFireMode1                             = 8,
    TestCheckFireMode2                             = 9,
    TestPullBolt                                   = 10,
    TestEquip                                      = 11,
    TestUnEquip                                    = 12,
    TestCheckChamber                               = 13,
    TestSetupMod                                   = 14,
    ETestAnimType_MAX                              = 15

};


// Enum  /Script/SGFramework.ESGMagazineCheckState
enum class ESGMagazineCheckState : uint8_t
{
    ESGMagazineCheckState_Unknown                  = 0,
    ESGMagazineCheckState_RoughChecked             = 1,
    ESGMagazineCheckState_FullyChecked             = 2,
    ESGMagazineCheckState_FullOrEmpty              = 3,
    ESGMagazineCheckState_MAX                      = 4

};


// Enum  /Script/SGFramework.ESGChangeClipState
enum class ESGChangeClipState : uint8_t
{
    ESGChangeClipState_Begin                       = 0,
    ESGChangeClipState_Loop                        = 1,
    ESGChangeClipState_End                         = 2,
    ESGChangeClipState_PutOldMagazineInBag         = 3,
    ESGChangeClipState_GetNewMagazine              = 4,
    ESGChangeClipState_AttachMagazineToWeapon      = 5,
    ESGChangeClipState_ReleaseMagazine             = 6,
    ESGChangeClipState_OpenBoltEnd                 = 7,
    ESGChangeClipState_EndBoltStart                = 8,
    ESGChangeClipState_ReleaseHoldOn               = 9,
    ESGChangeClipState_MAX                         = 10

};


// Enum  /Script/SGFramework.ESGRecoilRecoverAlgorithm
enum class ESGRecoilRecoverAlgorithm : uint8_t
{
    ESGRecoilRecoverAlgorithm_None                 = 0,
    ESGRecoilRecoverAlgorithm_SmoothLowerSpeed     = 1,
    ESGRecoilRecoverAlgorithm_SpeedCurve           = 2,
    ESGRecoilRecoverAlgorithm_MAX                  = 3

};


// Enum  /Script/SGFramework.EFillMagazineFailReason
enum class EFillMagazineFailReason : uint8_t
{
    EFillMagazineFailReason_None                   = 0,
    EFillMagazineFailReason_Success                = 1,
    EFillMagazineFailReason_InvalidMagazine        = 2,
    EFillMagazineFailReason_InvalidAmmoInventory   = 3,
    EFillMagazineFailReason_TypeNotMatch           = 4,
    EFillMagazineFailReason_MagazineFull           = 5,
    EFillMagazineFailReason_Unknown                = 6,
    EFillMagazineFailReason_MAX                    = 7

};


// Enum  /Script/SGFramework.ESGWeaponRecoilState
enum class ESGWeaponRecoilState : uint8_t
{
    ESGWeaponRecoilState_None                      = 0,
    ESGWeaponRecoilState_Recoil                    = 1,
    ESGWeaponRecoilState_Recover                   = 2,
    ESGWeaponRecoilState_MAX                       = 3

};


// Enum  /Script/SGFramework.ESGInputTriggerEvent
enum class ESGInputTriggerEvent : uint8_t
{
    EWeapEvent_None                                = 0,
    EWeapEvent_Activate                            = 1,
    EWeapEvent_HoldFire                            = 2,
    EWeapEvent_BeginFire                           = 3,
    EWeapEvent_BeginZoomAndFire                    = 4,
    EWeapEvent_EndFire                             = 5,
    EWeapEvent_EndAltFire                          = 6,
    EWeapEvent_BeginChangeClip                     = 7,
    EWeapEvent_BeginMount                          = 8,
    EWeapEvent_Deactivate                          = 9,
    EWeapEvent_PutBackWeapon                       = 10,
    EWeapEvent_BeginZooming                        = 11,
    EWeapEvent_EndZooming                          = 12,
    EWeapEvent_Interaction                         = 13,
    EWeapEvent_StopShootAiming                     = 14,
    EWeapEvent_BeginShoulderZoom                   = 15,
    EWeapEvent_AbortChangeClip                     = 16,
    EWeapEvent_ReloadFast                          = 17,
    EWeapEvent_CheckMagazine                       = 18,
    EWeapEvent_CheckWeapon                         = 19,
    EWeapEvent_HoldOpen                            = 20,
    EWeapEvent_AmmoOut                             = 21,
    EWeapEvent_AmmoIn                              = 22,
    EWeapEvent_BeginPullBolt                       = 23,
    EWeapEvent_AbortPreFiring                      = 24,
    EWeapEvent_BeginSwitchFireMode                 = 25,
    EWeapEvent_BeginCheckFireMode                  = 26,
    EWeapEvent_BeginCheckBore                      = 27,
    EWeapEvent_SetupMod                            = 28,
    EWeapEvent_EndBagOpen                          = 29,
    EWeapEvent_BeginBagOpen                        = 30,
    EWeapEvent_KeepBagOpen                         = 31,
    EWeapEvent_Max                                 = 32,
    EWeapEvent_BeginUnloadMag                      = 33,
    EWeapEvent_BeginLoadMag                        = 34

};


// Enum  /Script/SGFramework.ESGAdapterEvent
enum class ESGAdapterEvent : uint8_t
{
    ESGAdapterEvent_None                           = 0,
    ESGAdapterEvent_BeginZooming                   = 1,
    ESGAdapterEvent_EndZooming                     = 2,
    ESGAdapterEvent_BeginZoomPlug                  = 3,
    ESGAdapterEvent_EndZoomPlug                    = 4,
    ESGAdapterEvent_Max                            = 5

};


// Enum  /Script/SGFramework.EHandIKType
enum class EHandIKType : uint8_t
{
    HandIKType_None                                = 0,
    HandIKType_Primary                             = 1,
    HandIKType_Submachine                          = 2,
    HandIKType_Pistol                              = 3,
    HandIKType_SpecialLongWeapon                   = 4,
    HandIKType_Max                                 = 5

};


// Enum  /Script/SGFramework.ESGWeaponFireMode
enum class ESGWeaponFireMode : uint8_t
{
    EFireModeType_None                             = 0,
    EFireModeType_InstantFire                      = 1,
    EFireModeType_ProjectileFire                   = 2,
    EFireModeType_PhysicalBullet                   = 3,
    EFireModeType_MeleeFire                        = 4,
    EFireModeType_ProjectileLauncherFire           = 5,
    EFireModeType_MAX                              = 6

};


// Enum  /Script/SGFramework.EWeaponSwitchType
enum class EWeaponSwitchType : uint8_t
{
    EWeapSwitch_EmptyHand                          = 0,
    EWeapSwitch_FirstMainWeapon                    = 1,
    EWeapSwitch_SecondMainWeapon                   = 2,
    EWeapSwitch_AssiWeapon                         = 3,
    EWeapSwitch_MeleeWeapon                        = 4,
    EWeapSwitch_FirstThrowWeapon                   = 5,
    EWeapSwitch_Max                                = 6

};


// Enum  /Script/SGFramework.EWeaponSlot
enum class EWeaponSlot : uint8_t
{
    WS_Primary                                     = 0,
    WS_Secondary                                   = 1,
    WS_Assist                                      = 2,
    WS_Melee                                       = 3,
    WS_LeftHand                                    = 4,
    WS_MAX                                         = 5

};


// Enum  /Script/SGFramework.EMagazineType
enum class EMagazineType : uint8_t
{
    MagazineType_None                              = 0,
    MagazineType_Rifle                             = 1,
    MagazineType_ShotGun                           = 2,
    MagazineType_Sniper                            = 3,
    MagazineType_Pistol                            = 4,
    MagazineType_MAX                               = 5

};


// Enum  /Script/SGFramework.EItemAmmo
enum class EItemAmmo : uint8_t
{
    ItemAmmo_None                                  = 0,
    ItemAmmo_5mm56                                 = 1,
    ItemAmmo_7mm62                                 = 2,
    ItemAmmo_9mm                                   = 3,
    ItemAmmo_mm45ACP                               = 4,
    ItemAmmo_12Gauge                               = 5,
    ItemAmmo_mm300Magnum                           = 6,
    ItemAmmo_Bolt                                  = 7,
    ItemAmmo_5mm8                                  = 8,
    ItemAmmo_155mm                                 = 9,
    ItemAmmo_MAX                                   = 10

};


// Enum  /Script/SGFramework.ESGPenetrationObjectType
enum class ESGPenetrationObjectType : uint8_t
{
    None                                           = 0,
    Water                                          = 1,
    ESGPenetrationObjectType_MAX                   = 2

};


// Enum  /Script/SGFramework.ESGThrowSubType
enum class ESGThrowSubType : uint8_t
{
    EThrowSubType_None                             = 0,
    EThrowSubType_FragGrenade                      = 1,
    EThrowSubType_StunGrenade                      = 2,
    EThrowSubType_SmokeGrenade                     = 3,
    EThrowSubType_MolotovCocktail                  = 4,
    EThrowSubType_C4                               = 5,
    EThrowSubType_Flash                            = 6,
    EThrowSubType_FootSounder                      = 7,
    EThrowSubType_TearGas                          = 8,
    EThrowSubType_OffensiveGrenade                 = 9,
    EThrowSubType_TripMine                         = 10,
    EThrowSubType_ClaymoreMine                     = 11,
    EThrowSubType_SignalDetonator                  = 12,
    EThrowSubType_AlwaysOn                         = 13,
    EThrowSubType_RPG                              = 14,
    EThrowSubType_Monitor                          = 15,
    EThrowSubType_T11                              = 16,
    EThrowSubType_Max                              = 17

};


// Enum  /Script/SGFramework.EVehicleAnimType
enum class EVehicleAnimType : uint8_t
{
    EVehicleAnimType_None                          = 0,
    EVehicleAnimType_LongWeapon                    = 1,
    EVehicleAnimType_ShortWeapon                   = 2,
    EVehicleAnimType_MeleeWeapon                   = 3,
    EVehicleAnimType_ThrowWeapon                   = 4,
    EVehicleAnimTypeMax                            = 5,
    EVehicleAnimType_MAX                           = 6

};


// Enum  /Script/SGFramework.ESGWeaponResType
enum class ESGWeaponResType : uint8_t
{
    ESGWeapResType_None                            = 0,
    ESGWeapResType_AnimationBase                   = 1,
    ESGWeapResType_WeaponAnim                      = 2,
    ESGWeapResType_WeaponTrajectory                = 3,
    ESGWeapResType_MAX                             = 4

};


// Enum  /Script/SGFramework.ETakeHitDirInfo
enum class ETakeHitDirInfo : uint8_t
{
    None                                           = 0,
    Front                                          = 1,
    Back                                           = 2,
    Left                                           = 3,
    Right                                          = 4,
    ETakeHitDirInfo_MAX                            = 5

};


// Enum  /Script/SGFramework.EAnimationPlayType
enum class EAnimationPlayType : uint8_t
{
    AnimPlayType_None                              = 0,
    AnimPlayType_FullBody                          = 1,
    AnimPlayType_FullBodyNoIK                      = 2,
    AnimPlayType_FullBodyWithCameraRotation        = 3,
    AnimPlayType_UpperBody                         = 4,
    AnimPlayType_UpperBodyNoIK                     = 5,
    AnimPlayType_LowerBody                         = 6,
    AnimPlayType_FPPAnimSlot                       = 7,
    AnimPlayType_MAX                               = 8

};


// Enum  /Script/SGFramework.ESGWeaponAddFunction
enum class ESGWeaponAddFunction : uint8_t
{
    EWeapAddFunc_None                              = 0,
    EWeapAddFunc_Zooming                           = 1,
    EWeapAddFunc_Silencer                          = 2,
    EWeapAddFunc_FlashSuppressor                   = 3,
    EWeapAddFunc_ClipExtent                        = 4,
    EWeapAddFunc_ChangeClipFaster                  = 5,
    EBackWeapPos_Max                               = 6,
    ESGWeaponAddFunction_MAX                       = 7

};


// Enum  /Script/SGFramework.EBurstStopMode
enum class EBurstStopMode : uint8_t
{
    EBurstStopMode_Clear                           = 0,
    EBurstStopMode_Stay                            = 1,
    EBurstStopMode_Fin                             = 2,
    EBurstStopMode_MAX                             = 3

};


// Enum  /Script/SGFramework.ESGAutoZoomWeaponType
enum class ESGAutoZoomWeaponType : uint8_t
{
    EAutoZoomWeaponType_None                       = 0,
    EAutoZoomWeaponType_Auto                       = 1,
    EAutoZoomWeaponType_Pump                       = 2,
    EAutoZoomWeaponType_Semi                       = 3,
    EAutoZoomWeaponType_MAX                        = 4

};


// Enum  /Script/SGFramework.ESGAttachedInventoryType
enum class ESGAttachedInventoryType : uint8_t
{
    ESGAttachedInventoryType_None                  = 0,
    ESGAttachedInventoryType_MyBag                 = 1,
    ESGAttachedInventoryType_Vestbag               = 2,
    ESGAttachedInventoryType_Avatar                = 3,
    ESGAttachedInventoryType_Vest                  = 4,
    ESGAttachedInventoryType_MAX                   = 5

};


// Enum  /Script/SGFramework.ESGMeleeWeaponAttachPoint
enum class ESGMeleeWeaponAttachPoint : uint8_t
{
    ESGMeleeWeaponAttachPoint_MeleeWeapon          = 0,
    ESGMeleeWeaponAttachPoint_MeleeWeaponBack      = 1,
    ESGMeleeWeaponAttachPoint_MAX                  = 2

};


// Enum  /Script/SGFramework.ESGBackWeaponPos
enum class ESGBackWeaponPos : uint8_t
{
    EBackWeapPos_None                              = 0,
    EBackWeapPos_Primary                           = 1,
    EBackWeapPos_Secondary                         = 2,
    EBackWeapPos_Assist                            = 3,
    EBackWeapPos_Melee                             = 4,
    EBackWeapPos_MeleeBack                         = 5,
    EBackWeapPos_Grenade                           = 6,
    EBackWeapPos_Max                               = 7

};


// Enum  /Script/SGFramework.ESGBackWeaponAttachType
enum class ESGBackWeaponAttachType : uint8_t
{
    EBackWeapAT_None                               = 0,
    EBackWeapAT_MainWeapon                         = 1,
    EBackWeapAT_AssistWeapon                       = 2,
    EBackWeapAT_MeleeWeapon                        = 3,
    EBackWeapAT_Grenade                            = 4,
    EBackWeapAT_Custom                             = 5,
    EBackWeapAT_MAX                                = 6

};


// Enum  /Script/SGFramework.ESGEffectState
enum class ESGEffectState : uint8_t
{
    NoEffect                                       = 0,
    Show1PEffects                                  = 1,
    Show3PEffects                                  = 2,
    ESGEffectState_MAX                             = 3

};


// Enum  /Script/SGFramework.ESGWeaponHandgripType
enum class ESGWeaponHandgripType : uint8_t
{
    ESGWeaponHandgripType_Normal                   = 0,
    ESGWeaponHandgripType_Casual                   = 1,
    ESGWeaponHandgripType_MAX                      = 2

};


// Enum  /Script/SGFramework.ESGWeaponReargripType
enum class ESGWeaponReargripType : uint8_t
{
    ESGWeaponReargripType_None                     = 0,
    ESGWeaponReargripType_PistolGrip               = 1,
    ESGWeaponReargripType_StockGrip                = 2,
    ESGWeaponReargripType_MAX                      = 3

};


// Enum  /Script/SGFramework.ESGWeaponForegripType
enum class ESGWeaponForegripType : uint8_t
{
    ESGWeaponForegripType_None                     = 0,
    ESGWeaponForegripType_VerticalForegrip         = 1,
    ESGWeaponForegripType_AngledForegrip           = 2,
    ESGWeaponForegripType_ThumbForegrip            = 3,
    ESGWeaponForegripType_DiagonalForegrip         = 4,
    ESGWeaponForegripType_ShiftForegrip            = 5,
    ESGWeaponForegripType_HandguardForegrip        = 6,
    ESGWeaponForegripType_LeftHandGrip             = 7,
    ESGWeaponForegripType_LaserAvoid               = 8,
    ESGWeaponForegripType_AccessoriesGrip          = 9,
    ESGWeaponForegripType_AccessoriesGrip2         = 10,
    ESGWeaponForegripType_MAX                      = 11

};


// Enum  /Script/SGFramework.ESGWeapAdapterItemType
enum class ESGWeapAdapterItemType : uint8_t
{
    EWeapAASubType_None                            = 0,
    EWeapAASubType_Suppressor_Default              = 1,
    EWeapAASubType_SuppressorForAR                 = 2,
    EWeapAASubType_FlashHiderAR                    = 3,
    EWeapAASubType_CompensatorAR                   = 4,
    EWeapAASubType_SuppressorSMG                   = 5,
    EWeapAASubType_FlashHiderSMG                   = 6,
    EWeapAASubType_CompensatorSMG                  = 7,
    EWeapAASubType_SuppressorSR                    = 8,
    EWeapAASubType_FlashHiderSR                    = 9,
    EWeapAASubType_CompensatorSR                   = 10,
    EWeapAASubType_SuppressorHG                    = 11,
    EWeapAASubType_Choke                           = 12,
    EWeapAASubType_Duckbill                        = 13,
    EWeapAASubType_SilencerAR                      = 14,
    EWeapAASubType_SilencerSR                      = 15,
    EWeapAASubType_SilencerSMG                     = 16,
    EWeapAASubType_SilencerPistol                  = 17,
    EWeapAASubType_VerticalForegrip                = 18,
    EWeapAASubType_AngledForegrip                  = 19,
    EWeapAASubType_ThumbForegrip                   = 20,
    EWeapAASubType_HalfForegrip                    = 21,
    EWeapAASubType_LightForegrip                   = 22,
    EWeapAASubType_Quiver                          = 23,
    EWeapAASubType_RangeScope_Default              = 24,
    EWeapAASubType_RedDot                          = 25,
    EWeapAASubType_Holographic                     = 26,
    EWeapAASubType_2xScope                         = 27,
    EWeapAASubType_3xScope                         = 28,
    EWeapAASubType_4xScope                         = 29,
    EWeapAASubType_6xScope                         = 30,
    EWeapAASubType_8xScope                         = 31,
    EWeapAASubType_VSS4xScope                      = 32,
    EWeapAASubType_Dot                             = 33,
    EWeapAASubType_ExtendedMagAR                   = 34,
    EWeapAASubType_QuickDrawMagAR                  = 35,
    EWeapAASubType_ExtendedQuickDrawMagAR          = 36,
    EWeapAASubType_ExtendedMagSMG                  = 37,
    EWeapAASubType_QuickDrawMagSMG                 = 38,
    EWeapAASubType_ExtendedQuickDrawMagSMG         = 39,
    EWeapAASubType_ExtendedMagSR                   = 40,
    EWeapAASubType_QuickDrawMagSR                  = 41,
    EWeapAASubType_ExtendedQuickDrawMagSR          = 42,
    EWeapAASubType_ExtendedMagHG                   = 43,
    EWeapAASubType_QuickDrawMagHG                  = 44,
    EWeapAASubType_ExtendedQuickDrawMagHG          = 45,
    EWeapAASubType_Stock_Default                   = 46,
    EWeapAASubType_TacticalStock                   = 47,
    EWeapAASubType_StockUZI                        = 48,
    EWeapAASubType_CheekPadRifle                   = 49,
    EWeapAASubType_CheekPadSniper                  = 50,
    EWeapAASubType_BulletLoops                     = 51,
    EWeapAASubType_BulletLoopsKar98k               = 52,
    EWeapAASubType_Mag762                          = 53,
    EWeapAASubType_Mag556                          = 54,
    EWeapAASubType_Mag155                          = 55,
    EWeapAASubType_Mag9                            = 56,
    EWeapAASubType_Mag762_10_Sniper                = 57,
    EWeapAASubType_Mag_Custom                      = 58,
    EWeapAASubType_FlashLight                      = 59,
    EWeapAASubType_Max                             = 60

};


// Enum  /Script/SGFramework.ETacticalPistolStatus
enum class ETacticalPistolStatus : uint8_t
{
    None                                           = 0,
    NonTacticalPistol                              = 1,
    TacticalPistol                                 = 2,
    TransToTacticalPistol                          = 3,
    TransToNonTacticalPistol                       = 4,
    TacticalPistolToPistol                         = 5,
    PistolToTacticalPistol                         = 6,
    TacticalPistolPutDown                          = 7,
    TacticalPistolTakeUp                           = 8,
    ETacticalPistolStatus_MAX                      = 9

};


// Enum  /Script/SGFramework.EAdapterType
enum class EAdapterType : uint8_t
{
    Sub_Adapter_Default                            = 0,
    Sub_Adapter_Muzzle                             = 1,
    Sub_Adapter_LowerRail                          = 2,
    Sub_Adapter_UpperRail                          = 3,
    Sub_Adapter_SideRail                           = 4,
    Sub_Adapter_Magazines                          = 5,
    Sub_Adapter_Stocks                             = 6,
    Sub_Adapter_Grip                               = 7,
    Sub_Adapter_Cheek                              = 8,
    Sub_Adapter_MAX                                = 9

};


// Enum  /Script/SGFramework.ESGWeaponHoldPose
enum class ESGWeaponHoldPose : uint8_t
{
    EWeapHoldPose_None                             = 0,
    EWeapHoldPose_Stand                            = 1,
    EWeapHoldPose_StandWalk                        = 2,
    EWeapHoldPose_Crouch                           = 3,
    EWeapHoldPose_CrouchWalk                       = 4,
    EWeapHoldPose_Prone                            = 5,
    EWeapHoldPose_ProneMove                        = 6,
    EWeapHoldPose_Jump                             = 7,
    EWeapHoldPose_Sprint                           = 8,
    EWeapHoldPose_Dive                             = 9,
    EWeapHoldPose_Max                              = 10

};


// Enum  /Script/SGFramework.ESGWeaponMode
enum class ESGWeaponMode : uint8_t
{
    EWeapMode_None                                 = 0,
    EWeapMode_OwnerFirstPerson                     = 1,
    EWeapMode_OwnerThirdPerson                     = 2,
    EWeapMode_ObserverFirstPerson                  = 3,
    EWeapMode_ThirdPerson                          = 4,
    EWeapMode_MAX                                  = 5

};


// Enum  /Script/SGFramework.ESGMeleeWeaponState
enum class ESGMeleeWeaponState : uint8_t
{
    None                                           = 0,
    Idle                                           = 1,
    ExtraIdle                                      = 2,
    ESGMeleeWeaponState_MAX                        = 3

};


// Enum  /Script/SGFramework.ESGMeleeWeaponSubType
enum class ESGMeleeWeaponSubType : uint8_t
{
    EMeleeWeaponSubType_None                       = 0,
    EMeleeWeaponSubType_Blunt                      = 1,
    EMeleeWeaponSubType_Sharp                      = 2,
    EMeleeWeaponSubType_Max                        = 3

};


// Enum  /Script/SGFramework.ESGGunSilencerType
enum class ESGGunSilencerType : uint8_t
{
    ESilencerNone                                  = 0,
    ESilencerLow                                   = 1,
    ESilencerMiddle                                = 2,
    ESilencerHigh                                  = 3,
    ESilencerMax                                   = 4,
    ESGGunSilencerType_MAX                         = 5

};


// Enum  /Script/SGFramework.ESGWeaponDisplayPolicy
enum class ESGWeaponDisplayPolicy : uint8_t
{
    ESGWeaponDisplayPolicy_None                    = 0,
    ESGWeaponDisplayPolicy_1P                      = 1,
    ESGWeaponDisplayPolicy_LOD0                    = 2,
    ESGWeaponDisplayPolicy_LOD1                    = 3,
    ESGWeaponDisplayPolicy_LOD2                    = 4,
    ESGWeaponDisplayPolicy_LOD3                    = 5,
    ESGWeaponDisplayPolicy_NotRender               = 6,
    ESGWeaponDisplayPolicy_ForceSimple             = 7,
    ESGWeaponDisplayPolicy_ForceFaraway            = 8,
    ESGWeaponDisplayPolicy_ForceModular            = 9,
    ESGWeaponDisplayPolicy_MAX                     = 10

};


// Enum  /Script/SGFramework.ESGWeaponDetectorType
enum class ESGWeaponDetectorType : uint8_t
{
    None                                           = 0,
    EWeaponDetectorType_DefaultDetector            = 1,
    EWeaponDetectorType_LifeDetector               = 2,
    EWeaponDetectorType_InventoryDetector          = 3,
    EWeaponDetectorType_Max                        = 4,
    ESGWeaponDetectorType_MAX                      = 5

};


// Enum  /Script/SGFramework.ESGThrowWeaponSubType
enum class ESGThrowWeaponSubType : uint8_t
{
    EThrowWeaponSubType_None                       = 0,
    EThrowWeaponSubType_MonitorPDA                 = 1,
    EThrowWeaponSubType_Max                        = 2

};


// Enum  /Script/SGFramework.ESGGunWeaponSubType
enum class ESGGunWeaponSubType : uint8_t
{
    EGunWeaponSubType_None                         = 0,
    EGunWeaponSubType_LMG                          = 1,
    EGunWeaponSubType_SMG                          = 2,
    EGunWeaponSubType_DMR                          = 3,
    EGunWeaponSubType_Pistol                       = 4,
    EGunWeaponSubType_SniperRifle                  = 5,
    EGunWeaponSubType_AssualtRifle                 = 6,
    EGunWeaponSubType_AssualtCarbine               = 7,
    EGunWeaponSubType_Shotgun                      = 8,
    EGunWeaponSubType_Missile                      = 9,
    EGunWeaponSubType_CannotFire                   = 10,
    EGunWeaponSubType_Max                          = 11

};


// Enum  /Script/SGFramework.ESGSpecialWeaponSubType
enum class ESGSpecialWeaponSubType : uint8_t
{
    ESGSpecialWeaponSubType_None                   = 0,
    ESGSpecialWeaponSubType_Telescope              = 1,
    ESGSpecialWeaponSubType_DroneRemoteControl     = 2,
    ESGSpecialWeaponSubType_Max                    = 3

};


// Enum  /Script/SGFramework.ESGMeleeWeaponAnimType
enum class ESGMeleeWeaponAnimType : uint8_t
{
    None                                           = 0,
    EMeleeWeaponType_MultiIdle                     = 1,
    EMeleeWeaponType_BothHands                     = 2,
    EMeleeWeaponType_TwoBonesGrip                  = 3,
    EMeleeWeaponType_TwoMesh                       = 4,
    EWeaponType_Max                                = 5,
    ESGMeleeWeaponAnimType_MAX                     = 6

};


// Enum  /Script/SGFramework.EAntiHackZoomEventType
enum class EAntiHackZoomEventType : uint8_t
{
    None                                           = 0,
    StartZoom                                      = 1,
    ReachZoomFOV                                   = 2,
    ReachZoomTime                                  = 3,
    CancelZoom                                     = 4,
    EAntiHackZoomEventType_MAX                     = 5

};


// Enum  /Script/SGFramework.EWeaponAssembleUpdateType
enum class EWeaponAssembleUpdateType : uint8_t
{
    NoChange                                       = 0,
    Ownership                                      = 1,
    Assemble                                       = 2,
    Both                                           = 3,
    EWeaponAssembleUpdateType_MAX                  = 4

};


// Enum  /Script/SGFramework.EWeaponAssembleResourceType
enum class EWeaponAssembleResourceType : uint8_t
{
    Mesh                                           = 0,
    Skin                                           = 1,
    Spray                                          = 2,
    EWeaponAssembleResourceType_MAX                = 3

};


// Enum  /Script/SGFramework.EWeaponAssembleTaskCreateCompResult
enum class EWeaponAssembleTaskCreateCompResult : uint8_t
{
    Running                                        = 0,
    Completed                                      = 1,
    Failed                                         = 2,
    EWeaponAssembleTaskCreateCompResult_MAX        = 3

};


// Enum  /Script/SGFramework.EWeaponAssembleSubTaskType
enum class EWeaponAssembleSubTaskType : uint8_t
{
    Default                                        = 0,
    WaitForRepInfo                                 = 1,
    LoadMeshResource                               = 2,
    LoadSkinResource                               = 3,
    LoadSprayResource                              = 4,
    MergeMesh                                      = 5,
    CreateMeshComponent                            = 6,
    ClearOriComponentMesh                          = 7,
    Assemble                                       = 8,
    None                                           = 9,
    OriginPath                                     = 10,
    EWeaponAssembleSubTaskType_MAX                 = 11

};


// Enum  /Script/SGFramework.EWeaponAssembleTaskStatus
enum class EWeaponAssembleTaskStatus : uint8_t
{
    Pending                                        = 0,
    Running                                        = 1,
    Completed                                      = 2,
    Failed                                         = 3,
    EWeaponAssembleTaskStatus_MAX                  = 4

};


// Enum  /Script/SGFramework.EWeaponAssembleSubTaskRunType
enum class EWeaponAssembleSubTaskRunType : uint8_t
{
    Execute                                        = 0,
    Rollback                                       = 1,
    EWeaponAssembleSubTaskRunType_MAX              = 2

};


// Enum  /Script/SGFramework.ESoundIndicatorReportScoreType
enum class ESoundIndicatorReportScoreType : uint8_t
{
    None                                           = 0,
    Prone                                          = 1,
    SilenceWalk                                    = 2,
    Crouch                                         = 3,
    Lean                                           = 4,
    Fire                                           = 5,
    Sprint                                         = 6,
    Jump                                           = 7,
    ADS                                            = 8,
    ThrowGrenade                                   = 9,
    ESoundIndicatorReportScoreType_MAX             = 10

};


// Enum  /Script/SGFramework.ESoundColorType
enum class ESoundColorType : uint8_t
{
    None                                           = 0,
    Normal                                         = 1,
    Friendly                                       = 2,
    Dangerous                                      = 3,
    Warning                                        = 4,
    MAX                                            = 5

};


// Enum  /Script/SGFramework.ESoundSourceActorType
enum class ESoundSourceActorType : uint8_t
{
    None                                           = 0,
    Active                                         = 1,
    Passive                                        = 2,
    ESoundSourceActorType_MAX                      = 3

};


// Enum  /Script/SGFramework.ESoundInfluenceType
enum class ESoundInfluenceType : uint8_t
{
    None                                           = 0,
    PhysicsSurface                                 = 1,
    FacialEquipment                                = 2,
    Weight                                         = 3,
    Silencer                                       = 4,
    SpecialAI                                      = 5,
    HearingInjection                               = 6,
    SpecialPlayer                                  = 7,
    DBNO                                           = 8,
    ESoundInfluenceType_MAX                        = 9

};


// Enum  /Script/SGFramework.ESGVehicleHitEventSourceType
enum class ESGVehicleHitEventSourceType : uint8_t
{
    None                                           = 0,
    ClientReport                                   = 1,
    ServerGameplay                                 = 2,
    ServerPredict                                  = 3,
    ESGVehicleHitEventSourceType_MAX               = 4

};


// Enum  /Script/SGFramework.ESGVehicleHitEventValidateFailType
enum class ESGVehicleHitEventValidateFailType : uint8_t
{
    None                                           = 0,
    AbnormalHitDistance                            = 1,
    ExceedingForwardSpeedDifferenceThreshold       = 2,
    ExceedingUpSpeedDifferenceThreshold            = 3,
    UnreasonableTimeStamp                          = 4,
    FixClientMissingReport                         = 5,
    ESGVehicleHitEventValidateFailType_MAX         = 6

};


// Enum  /Script/SGFramework.ESGVehicleHitType
enum class ESGVehicleHitType : uint8_t
{
    None                                           = 0,
    Wall                                           = 1,
    Vehicle                                        = 2,
    Falling                                        = 3,
    HitPerson                                      = 4,
    ESGVehicleHitType_MAX                          = 5

};


// Enum  /Script/SGFramework.EVehicleCameraShakeType
enum class EVehicleCameraShakeType : uint8_t
{
    DrivingRandom                                  = 0,
    PhysicalMaterial                               = 1,
    Throttle                                       = 2,
    Hit                                            = 3,
    EVehicleCameraShakeType_MAX                    = 4

};


// Enum  /Script/SGFramework.EPassengerSeatType
enum class EPassengerSeatType : uint8_t
{
    PassengerSeatType_FrontRight                   = 0,
    PassengerSeatType_BackLeft                     = 1,
    PassengerSeatType_BackRight                    = 2,
    PassengerSeatType_MAX                          = 3

};


// Enum  /Script/SGFramework.EPassengerWeapType
enum class EPassengerWeapType : uint8_t
{
    PassengerWeapType_None                         = 0,
    PassengerWeapType_Gun                          = 1,
    PassengerSeatType_Pistol                       = 2,
    EPassengerWeapType_MAX                         = 3

};


// Enum  /Script/SGFramework.EVehicleSwitchSeatType
enum class EVehicleSwitchSeatType : uint8_t
{
    None                                           = 0,
    DriverToPassenger                              = 1,
    PassengerToDriver                              = 2,
    PassengerToPassenger                           = 3,
    EVehicleSwitchSeatType_MAX                     = 4

};


// Enum  /Script/SGFramework.EVehicleEngineState
enum class EVehicleEngineState : uint8_t
{
    EVES_Stop                                      = 0,
    EVES_Accel                                     = 1,
    EVES_Uniform                                   = 2,
    EVES_MAX                                       = 3

};


// Enum  /Script/SGFramework.ESGVehicleType
enum class ESGVehicleType : uint8_t
{
    SpawnVechieType_None                           = 0,
    SpawnVechieType_Uaz_ClosedTop                  = 1,
    SpawnVechieType_Dacia1300                      = 2,
    SpawnVechieType_Boat                           = 3,
    SpawnVechieType_Uaz_MetalTop                   = 4,
    SpawnVechieType_Uaz_OpenTop                    = 5,
    SpawnVechieType_Buggy                          = 6,
    SpawnVechieType_Reserver                       = 7,
    SpawnVechieType_MotoCycle                      = 8,
    SpawnVechieType_MotoBike                       = 9,
    SpawnVechieType_MAX                            = 10

};


// Enum  /Script/SGFramework.VehicleCannotLeanOutReason
enum class VehicleCannotLeanOutReason : uint8_t
{
    VehicleCannotLeanOutReason_OK                  = 0,
    VehicleCannotLeanOutReason_VehicleSink         = 1,
    VehicleCannotLeanOutReason_NotAllowWeapon      = 2,
    VehicleCannotLeanOutReason_NoHandedWeapon      = 3,
    VehicleCannotLeanOutReason_MAX                 = 4

};


// Enum  /Script/SGFramework.ESGCharacterInVehicleState
enum class ESGCharacterInVehicleState : uint8_t
{
    ESGState_None                                  = 0,
    ESGState_PreEnterVehicle                       = 1,
    ESGState_InVehicle                             = 2,
    ESGState_MAX                                   = 3

};


// Enum  /Script/MFWeakNetwork.EMFNetworkState
enum class EMFNetworkState : uint8_t
{
    NotReachable                                   = 0,
    WWAN                                           = 1,
    Wifi                                           = 2,
    Others                                         = 3,
    EMFNetworkState_MAX                            = 4

};


// Enum  /Script/OnlineSubsystem.EInAppPurchaseState
enum class EInAppPurchaseState : uint8_t
{
    Unknown                                        = 0,
    Success                                        = 1,
    Failed                                         = 2,
    Cancelled                                      = 3,
    Invalid                                        = 4,
    NotAllowed                                     = 5,
    Restored                                       = 6,
    AlreadyOwned                                   = 7,
    EInAppPurchaseState_MAX                        = 8

};


// Enum  /Script/OnlineSubsystemUtils.EInAppPurchaseStatus
enum class EInAppPurchaseStatus : uint8_t
{
    Invalid                                        = 0,
    Failed                                         = 1,
    Deferred                                       = 2,
    Canceled                                       = 3,
    Purchased                                      = 4,
    Restored                                       = 5,
    EInAppPurchaseStatus_MAX                       = 6

};


// Enum  /Script/OnlineSubsystemUtils.EOnlineProxyStoreOfferDiscountType
enum class EOnlineProxyStoreOfferDiscountType : uint8_t
{
    NotOnSale                                      = 0,
    Percentage                                     = 1,
    DiscountAmount                                 = 2,
    PayAmount                                      = 3,
    EOnlineProxyStoreOfferDiscountType_MAX         = 4

};


// Enum  /Script/OnlineSubsystemUtils.EBeaconConnectionState
enum class EBeaconConnectionState : uint8_t
{
    Invalid                                        = 0,
    Closed                                         = 1,
    Pending                                        = 2,
    Open                                           = 3,
    EBeaconConnectionState_MAX                     = 4

};


// Enum  /Script/OnlineSubsystemUtils.EClientRequestType
enum class EClientRequestType : uint8_t
{
    NonePending                                    = 0,
    ExistingSessionReservation                     = 1,
    ReservationUpdate                              = 2,
    EmptyServerReservation                         = 3,
    Reconnect                                      = 4,
    Abandon                                        = 5,
    ReservationRemoveMembers                       = 6,
    EClientRequestType_MAX                         = 7

};


// Enum  /Script/OnlineSubsystemUtils.EPartyReservationResult
enum class EPartyReservationResult : uint8_t
{
    NoResult                                       = 0,
    RequestPending                                 = 1,
    GeneralError                                   = 2,
    PartyLimitReached                              = 3,
    IncorrectPlayerCount                           = 4,
    RequestTimedOut                                = 5,
    ReservationDuplicate                           = 6,
    ReservationNotFound                            = 7,
    ReservationAccepted                            = 8,
    ReservationDenied                              = 9,
    ReservationDenied_CrossPlayRestriction         = 10,
    ReservationDenied_Banned                       = 11,
    ReservationRequestCanceled                     = 12,
    ReservationInvalid                             = 13,
    BadSessionId                                   = 14,
    ReservationDenied_ContainsExistingPlayers      = 15,
    EPartyReservationResult_MAX                    = 16

};


// Enum  /Script/OnlineSubsystemUtils.ESpectatorClientRequestType
enum class ESpectatorClientRequestType : uint8_t
{
    NonePending                                    = 0,
    ExistingSessionReservation                     = 1,
    ReservationUpdate                              = 2,
    EmptyServerReservation                         = 3,
    Reconnect                                      = 4,
    Abandon                                        = 5,
    ESpectatorClientRequestType_MAX                = 6

};


// Enum  /Script/OnlineSubsystemUtils.ESpectatorReservationResult
enum class ESpectatorReservationResult : uint8_t
{
    NoResult                                       = 0,
    RequestPending                                 = 1,
    GeneralError                                   = 2,
    SpectatorLimitReached                          = 3,
    IncorrectPlayerCount                           = 4,
    RequestTimedOut                                = 5,
    ReservationDuplicate                           = 6,
    ReservationNotFound                            = 7,
    ReservationAccepted                            = 8,
    ReservationDenied                              = 9,
    ReservationDenied_CrossPlayRestriction         = 10,
    ReservationDenied_Banned                       = 11,
    ReservationRequestCanceled                     = 12,
    ReservationInvalid                             = 13,
    BadSessionId                                   = 14,
    ReservationDenied_ContainsExistingPlayers      = 15,
    ESpectatorReservationResult_MAX                = 16

};


// Enum  /Script/OnlineSubsystem.EMPMatchOutcome
enum class EMPMatchOutcome : uint8_t
{
    None                                           = 0,
    Quit                                           = 1,
    Won                                            = 2,
    Lost                                           = 3,
    Tied                                           = 4,
    TimeExpired                                    = 5,
    First                                          = 6,
    Second                                         = 7,
    Third                                          = 8,
    Fourth                                         = 9,
    EMPMatchOutcome_MAX                            = 10

};


// Enum  /Script/MFQuestSystem.EQuestStatus
enum class EQuestStatus : uint8_t
{
    EQuestStatus_Inactive                          = 0,
    EQuestStatus_InProcess                         = 1,
    EQuestStatus_Success                           = 2,
    EQuestStatus_Failed                            = 3,
    EQuestStatus_MAX                               = 4

};


// Enum  /Script/MFQuestSystem.EQuestNodeType
enum class EQuestNodeType : uint8_t
{
    BaseNode                                       = 0,
    CheckNode                                      = 1,
    AssembleNode                                   = 2,
    AffiliateNode                                  = 3,
    EQuestNodeType_MAX                             = 4

};


// Enum  /Script/MFQuestSystem.ERecoveryAttributeChangeType
enum class ERecoveryAttributeChangeType : uint8_t
{
    Recover                                        = 0,
    Lose                                           = 1,
    ERecoveryAttributeChangeType_MAX               = 2

};


// Enum  /Script/MFQuestSystem.ETaskType
enum class ETaskType : uint8_t
{
    E_TASK_TYPE_NONE                               = 0,
    E_TASK_TYPE_MAIN                               = 1,
    E_TASK_TYPE_DAILY                              = 2,
    E_TASK_TYPE_ACT                                = 3,
    E_TASK_TYPE_WEEKLY                             = 4,
    E_TASK_TYPE_ERGENT                             = 5,
    E_TASK_TYPE_SEASON_WEEK                        = 6,
    E_TASK_TYPE_SEASON                             = 7,
    E_TASK_TYPE_MENTOR                             = 8,
    E_TASK_TYPE_MAX                                = 9

};


// Enum  /Script/MFQuestSystem.EQuestType
enum class EQuestType : uint8_t
{
    Normal                                         = 0,
    Distributer                                    = 1,
    Activity                                       = 2,
    Achievement                                    = 3,
    EQuestType_MAX                                 = 4

};


// Enum  /Script/MFQuestSystem.EQuestObjectiveType
enum class EQuestObjectiveType : uint8_t
{
    Percentage                                     = 0,
    ClearArea                                      = 1,
    OccupiedArea                                   = 2,
    EQuestObjectiveType_MAX                        = 3

};


// Enum  /Script/MFQuestSystem.ERelatedTargetType
enum class ERelatedTargetType : uint8_t
{
    TargetOnly                                     = 0,
    TargetTeammateOnly                             = 1,
    RandomTeam                                     = 2,
    AllPMC                                         = 3,
    AllSCAV                                        = 4,
    ERelatedTargetType_MAX                         = 5

};


// Enum  /Script/MFQuestSystem.ENumberCompareType
enum class ENumberCompareType : uint8_t
{
    CMP_Equals                                     = 0,
    CMP_NotEqual                                   = 1,
    CMP_Greater                                    = 2,
    CMP_Less                                       = 3,
    CMP_GreaterEqual                               = 4,
    CMP_LessEqual                                  = 5,
    CMP_Between                                    = 6,
    CMP_MAX                                        = 7

};


// Enum  /Script/MFQuestSystem.ERunQuestResult
enum class ERunQuestResult : uint8_t
{
    Success                                        = 0,
    Failed                                         = 1,
    ERunQuestResult_MAX                            = 2

};


// Enum  /Script/MFQuestSystem.EQuestNodeStatus
enum class EQuestNodeStatus : uint8_t
{
    EQuestNodeStatus_Active                        = 0,
    EQuestNodeStatus_Inactive                      = 1,
    EQuestNodeStatus_MAX                           = 2

};


// Enum  /Script/MFQuestSystem.EQuestNodeConnectionType
enum class EQuestNodeConnectionType : uint8_t
{
    EQuestNodeConnectionType_And                   = 0,
    EQuestNodeConnectionType_Or                    = 1,
    EQuestNodeConnectionType_MAX                   = 2

};


// Enum  /Script/MFQuestSystem.EQuestInstigatorType
enum class EQuestInstigatorType : uint8_t
{
    EQuestInstigatorType_None                      = 0,
    EQuestInstigatorType_Individual                = 1,
    EQuestInstigatorType_Team                      = 2,
    EQuestInstigatorType_Public                    = 3,
    EQuestInstigatorType_MAX                       = 4

};


// Enum  /Script/MFQuestSystem.EQuestConditionCheckType
enum class EQuestConditionCheckType : uint8_t
{
    EQuestConditionCheckType_Event                 = 0,
    EQuestConditionCheckType_Tick                  = 1,
    EQuestConditionCheckType_Both                  = 2,
    EQuestConditionCheckType_MAX                   = 3

};


// Enum  /Script/MFQuestSystem.EQuestConditionType
enum class EQuestConditionType : uint8_t
{
    EQuestConditionType_Keeping                    = 0,
    EQuestConditionType_Filter                     = 1,
    EQuestConditionType_MAX                        = 2

};


// Enum  /Script/MFQuestSystem.EQuestFailedType
enum class EQuestFailedType : uint8_t
{
    EQuestFailed_Normal                            = 0,
    EQuestFailed_TimeOut                           = 1,
    EQuestFailed_MAX                               = 2

};


// Enum  /Script/StructUtils.EPropertyBagMissingEnum
enum class EPropertyBagMissingEnum : uint8_t
{
    Missing                                        = 0,
    EPropertyBagMissingEnum_MAX                    = 1

};


// Enum  /Script/StructUtils.EPropertyBagResult
enum class EPropertyBagResult : uint8_t
{
    Success                                        = 0,
    TypeMismatch                                   = 1,
    OutOfBounds                                    = 2,
    PropertyNotFound                               = 3,
    EPropertyBagResult_MAX                         = 4

};


// Enum  /Script/StructUtils.EPropertyBagContainerType
enum class EPropertyBagContainerType : uint8_t
{
    None                                           = 0,
    Array                                          = 1,
    Count                                          = 2,
    EPropertyBagContainerType_MAX                  = 3

};


// Enum  /Script/StructUtils.EPropertyBagPropertyType
enum class EPropertyBagPropertyType : uint8_t
{
    None                                           = 0,
    Bool                                           = 1,
    Byte                                           = 2,
    Int32                                          = 3,
    Int64                                          = 4,
    Float                                          = 5,
    Double                                         = 6,
    Name                                           = 7,
    String                                         = 8,
    Text                                           = 9,
    Enum                                           = 10,
    Struct                                         = 11,
    Object                                         = 12,
    SoftObject                                     = 13,
    Class                                          = 14,
    SoftClass                                      = 15,
    UInt32                                         = 16,
    UInt64                                         = 17,
    Count                                          = 18,
    EPropertyBagPropertyType_MAX                   = 19

};


// Enum  /Script/StructUtilsEngine.EStructUtilsResult
enum class EStructUtilsResult : uint8_t
{
    Valid                                          = 0,
    NotValid                                       = 1,
    EStructUtilsResult_MAX                         = 2

};


// Enum  /Script/MFLevelTool.EActorProcessStatus
enum class EActorProcessStatus : uint8_t
{
    NotProcessed                                   = 0,
    Success                                        = 1,
    Failed                                         = 2,
    Skipped                                        = 3,
    EActorProcessStatus_MAX                        = 4

};


// Enum  /Script/MFLevelTool.EFilterLogic
enum class EFilterLogic : uint8_t
{
    FL_AND                                         = 0,
    FL_OR                                          = 1,
    FL_MAX                                         = 2

};


// Enum  /Script/MFMobileJoystick.EMFAdvanceProgressBarFillType
enum class EMFAdvanceProgressBarFillType : uint8_t
{
    Custom                                         = 0,
    Clockwise                                      = 1,
    Counterclockwise                               = 2,
    EMFAdvanceProgressBarFillType_MAX              = 3

};


// Enum  /Script/MFMobileJoystick.EAcceptOP
enum class EAcceptOP : uint8_t
{
    EAOP_Direct                                    = 0,
    EAOP_ScaleBySpeed                              = 1,
    EAOP_MAX                                       = 2

};


// Enum  /Script/MFMobileJoystick.EBlendOP
enum class EBlendOP : uint8_t
{
    EOP_BlendFactor                                = 0,
    EOP_BlendFactor_Interp                         = 1,
    EOP_BlendFactor_Curve                          = 2,
    EOP_BlendFactor_MagicMin                       = 3,
    EOP_BlendFactor_MagicMax                       = 4,
    EOP_MAX                                        = 5

};


// Enum  /Script/AICreateSDK.EAuthorizeRequest
enum class EAuthorizeRequest : uint8_t
{
    AuthorizeRequestUnused                         = 0,
    AuthorizeRequestQuery                          = 1,
    AuthorizeRequestBind                           = 2,
    AuthorizeRequestUnbind                         = 3,
    EAuthorizeRequest_MAX                          = 4

};


// Enum  /Script/Pandora.EPropertyClass
enum class EPropertyClass : uint8_t
{
    Byte                                           = 0,
    Int8                                           = 1,
    Int16                                          = 2,
    Int                                            = 3,
    Int64                                          = 4,
    UInt16                                         = 5,
    UInt32                                         = 6,
    UInt64                                         = 7,
    UnsizedInt                                     = 8,
    UnsizedUInt                                    = 9,
    Float                                          = 10,
    Double                                         = 11,
    Bool                                           = 12,
    SoftClass                                      = 13,
    WeakObject                                     = 14,
    LazyObject                                     = 15,
    SoftObject                                     = 16,
    Class                                          = 17,
    Object                                         = 18,
    Interface                                      = 19,
    Name                                           = 20,
    Str                                            = 21,
    Array                                          = 22,
    Map                                            = 23,
    Set                                            = 24,
    Struct                                         = 25,
    Delegate                                       = 26,
    MulticastDelegate                              = 27,
    Text                                           = 28,
    Enum                                           = 29,
    EPropertyClass_MAX                             = 30

};


// Enum  /Script/Pandora.EPandoraEnv
enum class EPandoraEnv : uint8_t
{
    Test                                           = 0,
    Product                                        = 1,
    Alpha                                          = 2,
    EPandoraEnv_MAX                                = 3

};


// Enum  /Script/GameMatrix.EGameMatrixDeviceType
enum class EGameMatrixDeviceType : uint8_t
{
    InValid                                        = 0,
    Android                                        = 1,
    Android_TV                                     = 2,
    Mac                                            = 3,
    Windows                                        = 4,
    PC_Win                                         = 5,
    PC_Mac                                         = 6,
    H5                                             = 7,
    EGameMatrixDeviceType_MAX                      = 8

};


// Enum  /Script/Dawn20RuntimeComponents.EDawn20InteriorVolumePlaneBiasMode
enum class EDawn20InteriorVolumePlaneBiasMode : uint8_t
{
    None                                           = 0,
    ForceEnable                                    = 1,
    ForceDisable                                   = 2,
    EDawn20InteriorVolumePlaneBiasMode_MAX         = 3

};


// Enum  /Script/LandscapeGrassHDRuntime.EGrassHDBuildState
enum class EGrassHDBuildState : uint8_t
{
    CullOBBs_Started_GameThread                    = 0,
    CullOBBs_Started_RenderThread                  = 1,
    CullOBBs_NeedRetry                             = 2,
    CullOBBs_PreparingNormalizedOBBs               = 3,
    CullOBBs_WaitingForOBBsFilling                 = 4,
    CullOBBs_WaitingForNextFrame                   = 5,
    CullOBBs_WaitingForReadbackStart               = 6,
    CullOBBs_WaitingForReadbackReady               = 7,
    CullOBBs_WaitingForResult                      = 8,
    OBBsReady                                      = 9,
    AddingBuildData                                = 10,
    Completed                                      = 11,
    Invalid                                        = 12,
    EGrassHDBuildState_MAX                         = 13

};


// Enum  /Script/UACommon.EDownloadFileState
enum class EDownloadFileState : uint8_t
{
    DownloadFileState_None                         = 0,
    DownloadFileState_Failed                       = 1,
    DownloadFileState_Head                         = 2,
    DownloadFileState_Progress                     = 3,
    DownloadFileState_Paused                       = 4,
    DownloadFileState_Completed                    = 5,
    DownloadFileState_MAX                          = 6

};


// Enum  /Script/Engine.ETextureMipCount
enum class ETextureMipCount : uint8_t
{
    TMC_ResidentMips                               = 0,
    TMC_AllMips                                    = 1,
    TMC_AllMipsBiased                              = 2,
    TMC_MAX                                        = 3

};


// Enum  /Script/UACommon.EPreviewCaptureMode
enum class EPreviewCaptureMode : uint8_t
{
    None                                           = 0,
    Poster                                         = 1,
    RealTime                                       = 2,
    Photo                                          = 3,
    EPreviewCaptureMode_MAX                        = 4

};


// Enum  /Script/UACommon.EUAGamePadWidgetVersion
enum class EUAGamePadWidgetVersion : uint8_t
{
    ALL                                            = 0,
    UAM                                            = 1,
    UAMO                                           = 2,
    EUAGamePadWidgetVersion_MAX                    = 3

};


// Enum  /Script/UACommon.EUATraceNewMapShowAreaType
enum class EUATraceNewMapShowAreaType : uint8_t
{
    MinInscribedCircle                             = 0,
    MaxInscribedCircle                             = 1,
    CircumscribedCircle                            = 2,
    EUATraceNewMapShowAreaType_MAX                 = 3

};


// Enum  /Script/UACommon.EUAPlayerSignEnum
enum class EUAPlayerSignEnum : uint8_t
{
    None                                           = 0,
    EnemySign                                      = 1,
    LootSign                                       = 2,
    CommonSign                                     = 3,
    EUAPlayerSignEnum_MAX                          = 4

};


// Enum  /Script/UACommon.EGamePadEffectTable
enum class EGamePadEffectTable : uint8_t
{
    None                                           = 0,
    GamePadView_Fire                               = 1,
    GamePadView_LeftFire                           = 2,
    GamePadView_ChangeClip                         = 3,
    GamePadView_Crouch                             = 4,
    GamePadView_Prone                              = 5,
    GamePadView_Jump                               = 6,
    F_Guide_Lefthand                               = 7,
    F_Guide_Righthand                              = 8,
    GamePadView_ADS                                = 9,
    GamePadView_Bag                                = 10,
    GamePadView_Bigmap                             = 11,
    GamePadView_Loot                               = 12,
    GamePadView_CloseBagEffect                     = 13,
    GamePadView_SwitchGenerade                     = 14,
    GamePadView_TutorialAMagazine                  = 15,
    GamePadView_TutorialAAmmo                      = 16,
    GamePadView_VestBagPageEffet                   = 17,
    GamePadView_BagPageEffet                       = 18,
    GamePadView_HealthPageEffet                    = 19,
    GamePadView_CorpseBagPageEffet                 = 20,
    GamePadView_DragAmmoEffect                     = 21,
    GamePadView_CorpseBagSearchEffect              = 22,
    GamePadView_Drag_MedFromCorpseBag              = 23,
    GamePadView_Drag_MedToLeg                      = 24,
    GamePadView_Drag_KeyToPocket                   = 25,
    GamePadView_EscaapePoint                       = 26,
    GamePadView_SilentMove                         = 27,
    GamePadView_LegEffect                          = 28,
    GamePadView_CloseMapEffect                     = 29,
    GamePadView_WeaponCheck_Effect                 = 30,
    GamePadView_FastRun_Effect                     = 31,
    GamePadView_CorpseMedItemEffect                = 32,
    GamePadView_MedinBagEffect                     = 33,
    GamePadView_FakeMapEffect                      = 34,
    GamePadView_ItemSearch_Effect                  = 35,
    GamePadView_FakeMap_PlayerIcon_Effect          = 36,
    GamePadView_FakeMap_CaptainIcon_Effect         = 37,
    GamePadView_FakeMap_BlockSymble_Effect         = 38,
    GamePadView_FakeMap_EscapePoints_Effect        = 39,
    GamePadView_FakeMap_EscapeRoute_Effect         = 40,
    GamePadView_FakeMap_CloseButton_Effect         = 41,
    GamePadView_TutorialBMedItemEffect             = 42,
    GamePadView_TutorialBMedItemtobagGrid1Effect   = 43,
    GamePadView_TutorialKeytoPocketEffect          = 44,
    GamePadView_TutorialPocketPageEffect           = 45,
    GamePadView_TutorialOpenDoorEffect             = 46,
    GamePadView_TutorialLootBoxGrid1Effect         = 47,
    GamePadView_Setting_Effect                     = 48,
    GamePadView_DebuffInfo_Effect                  = 49,
    GamePadView_ItemQuickUse_Effect                = 50,
    GamePadView_PrimaryWeapon_Effect               = 51,
    GamePadView_SecondaryWeapon_Effect             = 52,
    GamePadView_VestArmor_Effect                   = 53,
    GamePadView_Helmet_Effect                      = 54,
    GamePadView_VestIcon_Effect                    = 55,
    GamePadView_Pocket1_Effect                     = 56,
    GamePadView_CorpseVestArmor_Effect             = 57,
    GamePadView_CorpseHelmet_Effect                = 58,
    GamePadView_CorpseVestTab_Effect               = 59,
    GamePadView_CorpseVestSearch_Effect            = 60,
    GamePadView_CorpsePocketSearch_Effect          = 61,
    GamePadView_CorpseVestIcon_Effect              = 62,
    GamePadView_CorpsePocket1_Effect               = 63,
    GamePadView_LifeState_Effect                   = 64,
    GamePadView_Tab_Safebox_Effect                 = 65,
    GamePadView_Safebox_Effect                     = 66,
    GamePadView_Loot_Bag_Icon_Effect               = 67,
    GamePadView_Bag_Icon_Effect                    = 68,
    GamePadView_VoiceInstructions                  = 69,
    GamePadView_CorpseVase                         = 70,
    GamePadView_ChangeMagaZineAnim_Effect          = 71,
    GamePadView_TutorialMag                        = 72,
    GamePadView_TutorialPushBullet                 = 73,
    GamePadView_ChangeAmmoAnim_Effect              = 74,
    GamePadView_PlayerSecondaryWeaponEffect        = 75,
    GamePadView_Loot_PistolEffect                  = 76,
    GamePadView_PistolEffect                       = 77,
    FirstLootInventoryEffect                       = 78,
    LootViewButtonEffect                           = 79,
    GamePadView_PickButton_Effect                  = 80,
    GamePadView_GoldenLoot_Effect                  = 81,
    GamePadView_FirstLootPick_Effect               = 82,
    GamePadView_GoldenInspect_Effect               = 83,
    SecondLootInventoryEffect                      = 84,
    FirstBagInventoryEffect                        = 85,
    SecondBagInventoryEffect                       = 86,
    FirstDeathBoxGunEffect                         = 87,
    SecondhudMarkMapEffect                         = 88,
    GamePadView_GUNLOOTDeathboxEffect              = 89,
    ArmorLOOTDeathboxEffect                        = 90,
    ManualLOOTEffect                               = 91,
    Mask_ArmorClickSelfEffect                      = 92,
    ArmorReplaceEffect                             = 93,
    Overseas_ArmorLOOTDeathboxEffect               = 94,
    Overseas_FirstDeathBoxGunEffect                = 95,
    Overseas_GUNLOOTDeathboxEffect                 = 96,
    BP_Left_Gesture                                = 97,
    Overseas_HeritageLootboxEffect                 = 98,
    EGamePadEffectTable_MAX                        = 99

};


// Enum  /Script/UACommon.EUAGamePadHightWidgetTable
enum class EUAGamePadHightWidgetTable : uint8_t
{
    None                                           = 0,
    GuideCircle                                    = 1,
    GuideCircle                                    = 2,
    GuideSquare                                    = 3,
    GuideSquare                                    = 4,
    GuideRectangle                                 = 5,
    GuideCircle                                    = 6,
    EUAGamePadHightWidgetTable_MAX                 = 7

};


// Enum  /Script/UACommon.EUAGamePadTable
enum class EUAGamePadTable : uint8_t
{
    None                                           = 0,
    GamePadView_ADS                                = 1,
    GamePadView_Bag                                = 2,
    GamePadView_BigMap                             = 3,
    GamePadView_ChangeClip                         = 4,
    GamePadView_Crouch                             = 5,
    GamePadView_Fire                               = 6,
    GamePadView_Jump                               = 7,
    GamePadView_LeftFire                           = 8,
    GamePadView_Movement                           = 9,
    GamePadView_Prone                              = 10,
    GamePadView_Quietstep                          = 11,
    GamePadView_Sprint                             = 12,
    GamePadView_ItemSearch                         = 13,
    GamePadView_LifeState                          = 14,
    GamePadView_UseProgress                        = 15,
    GamePadView_WeaponUse                          = 16,
    GamePadView_DoorInteraction                    = 17,
    GamePadView_ThrowCancel                        = 18,
    GamePadView_SelectGrenade                      = 19,
    GamePadView_QuickUseItem                       = 20,
    BP_PCHUDWidget_DirectionalBar                  = 21,
    GamePadView_WeaponCheck                        = 22,
    GamePadView_CheckWeaponTxt                     = 23,
    BPFX_Pain                                      = 24,
    DoorInteraction                                = 25,
    BP_GamePadView_LockMove                        = 26,
    BP_GameID                                      = 27,
    BPFX_DropOfBlood                               = 28,
    BPFX_Bullet_Hit                                = 29,
    BP_GamePadView_EnergyProgress                  = 30,
    BPFX_Clear                                     = 31,
    BPFX_Bleed                                     = 32,
    GamePadView_Chat                               = 33,
    BP_GamePadView_Collimator                      = 34,
    BP_GamePadView_Magnitude                       = 35,
    GamePadView_CustomInteractContainer            = 36,
    BPFX_SmokeBomb                                 = 37,
    BPFX_ArticuloMortis                            = 38,
    BP_GamePadView_DBNOHealth                      = 39,
    BP_GamePadView_RescueInteraction               = 40,
    GamePadView_LeanL                              = 41,
    GamePadView_LeanR                              = 42,
    GamePadView_GetInventory                       = 43,
    GamePadView_LootInventory                      = 44,
    DoorInteractionTips                            = 45,
    BPFX_Flash_Effect                              = 46,
    GamePadView_Voice_Intercom                     = 47,
    GamePadView_Voice_Reception                    = 48,
    BP_GamePadView_LaserSwitch                     = 50,
    BPFX_LackInSupplies                            = 51,
    SoundIndicatorV2                               = 52,
    GamePadView_QuestTrackCountDown                = 53,
    BP_SelfSoundIndicator                          = 54,
    GamePadView_ChatHint                           = 55,
    BPFX_FaceShield                                = 56,
    BP_GamePadView_ThermalSwitch                   = 57,
    Temp                                           = 58,
    Temp2                                          = 59,
    BP_MainHud_WeaponSlotMain_First                = 60,
    BP_MainHud_WeaponSlotMain_Second               = 61,
    BP_MainHud_WeaponSlot_AssisMelee               = 62,
    GamePadView_PullBolt                           = 63,
    BP_BringOutValuePanel                          = 98,
    GamePadView_OneClickReload                     = 113,
    GamePadView_MinMap                             = 114,
    EUAGamePadTable_MAX                            = 115

};


// Enum  /Script/UACommon.EUAHUDPreInstallLoc
enum class EUAHUDPreInstallLoc : uint8_t
{
    None                                           = 0,
    Tips_Panel_Right                               = 1,
    dialogBox_Bottom                               = 2,
    Objective_Panel                                = 3,
    Suggestive_Panel_Left                          = 4,
    WarnMessage_Panel                              = 5,
    LightTips_Panel                                = 6,
    Activity_Phase_Panel                           = 7,
    RouletteTips_Panel                             = 8,
    EUAHUDPreInstallLoc_MAX                        = 9

};


// Enum  /Script/UACommon.EUASettleUIType
enum class EUASettleUIType : uint8_t
{
    Settlement                                     = 0,
    Loading                                        = 1,
    WaitReinforce                                  = 2,
    WaitRevive                                     = 3,
    EUASettleUIType_MAX                            = 4

};


// Enum  /Script/UACommon.EUASettleFilterType
enum class EUASettleFilterType : uint8_t
{
    None                                           = 0,
    InValues                                       = 1,
    NotInValues                                    = 2,
    ContainValue                                   = 3,
    EUASettleFilterType_MAX                        = 4

};


// Enum  /Script/UACommon.EUAArgResolveMethod
enum class EUAArgResolveMethod : uint8_t
{
    None                                           = 0,
    Inventory                                      = 1,
    Volume                                         = 2,
    EnvDamage                                      = 3,
    LootBox                                        = 4,
    EUAArgResolveMethod_MAX                        = 5

};


// Enum  /Script/UACommon.EUAPVEMissionProgressMethod
enum class EUAPVEMissionProgressMethod : uint8_t
{
    Amount                                         = 0,
    CheckBox                                       = 1,
    Time                                           = 2,
    EUAPVEMissionProgressMethod_MAX                = 3

};


// Enum  /Script/UACommon.EUAPVEMissionObjectiveMethod
enum class EUAPVEMissionObjectiveMethod : uint8_t
{
    Every                                          = 0,
    Below                                          = 1,
    Exceed                                         = 2,
    EUAPVEMissionObjectiveMethod_MAX               = 3

};


// Enum  /Script/UACommon.EUAStatisParamFilterType
enum class EUAStatisParamFilterType : uint8_t
{
    None                                           = 0,
    Equal                                          = 1,
    NotEqual                                       = 2,
    GreaterEqual                                   = 3,
    LessEqual                                      = 4,
    Between                                        = 5,
    FixLenNumDivideIn                              = 6,
    FixLenNumDivideNotIn                           = 7,
    EqualArray                                     = 8,
    EUAStatisParamFilterType_MAX                   = 9

};


// Enum  /Script/UACommon.EUAStatisMethod
enum class EUAStatisMethod : uint8_t
{
    SumValue                                       = 0,
    Max                                            = 1,
    Min                                            = 2,
    LastValue                                      = 3,
    SumCount                                       = 4

};


// Enum  /Script/UACommon.EGamePadLayer
enum class EGamePadLayer : uint8_t
{
    NONE                                           = 0,
    EFFECT                                         = 1,
    OVERSEAS                                       = 2,
    OPERATE                                        = 3,
    PHOTO                                          = 4,
    BASEINFO                                       = 5,
    EGamePadLayer_MAX                              = 6

};


// Enum  /Script/UACommon.EGameModeName
enum class EGameModeName : uint8_t
{
    EGameMode_None                                 = 0,
    EGameMode_NormalEvacuate                       = 1,
    EGameMode_TutorialGuide                        = 2,
    EGameMode_TutorialWarm                         = 3,
    EGameMode_OB                                   = 5,
    EGameMode_TutorialEvacuate                     = 6,
    EGameMode_ActivityEvacuate                     = 7,
    EGameMode_PCGTest                              = 8,
    EGameMode_Range                                = 9,
    EGameMode_RangeWaitdownload                    = 10,
    EGameMode_Round                                = 11,
    EGameMode_PVE                                  = 12,
    EGameMode_BR                                   = 13,
    EGameMode_TutorialNew                          = 14,
    EGameMode_EconomyRound                         = 15,
    EGameMode_NotLoss                              = 16,
    EGameMode_LootGold                             = 17,
    EGameMode_PersonalBattle                       = 18,
    EGameMode_MAX                                  = 19

};


// Enum  /Script/UACommon.EStartPointType
enum class EStartPointType : uint8_t
{
    EPlayerTeamType_None                           = 0,
    EPlayerTeamType_PMC                            = 1,
    EPlayerTeamType_SCAV                           = 2,
    EPlayerTeamType_PMCAndSCAV                     = 3,
    EPlayerTeamType_OnlyForFaction                 = 4,
    EPlayerTeamType_MAX                            = 5

};


// Enum  /Script/UAGame.ETutorialFlowBarType
enum class ETutorialFlowBarType : uint8_t
{
    TutorialFlowBarType_Text                       = 0,
    TutorialFlowBarType_DynamicImage               = 1,
    TutorialFlowBarType_Teammate                   = 2,
    TutorialFlowBarType_Arrow                      = 3,
    TutorialFlowBarType_PVETeam                    = 4,
    TutorialFlowBarType_MAX                        = 5

};


// Enum  /Script/UAGame.ETutorialBagType
enum class ETutorialBagType : uint8_t
{
    TutorialBagType_None                           = 0,
    TutorialBagType_Self                           = 1,
    TutorialBagType_Loot                           = 2,
    TutorialBagType_Corpse                         = 3,
    TutorialBagType_MAX                            = 4

};


// Enum  /Script/UAGame.ETutorialBagWidgetType
enum class ETutorialBagWidgetType : uint8_t
{
    Undefined                                      = 0,
    PickupsNearby                                  = 1,
    MyBag                                          = 2,
    MyBagIcon                                      = 3,
    VestBag                                        = 4,
    VestBagIcon                                    = 5,
    PickBag                                        = 6,
    Character                                      = 7,
    Inventory                                      = 8,
    Adapter                                        = 9,
    FirstMainWeapon                                = 10,
    SecondMainWeapon                               = 11,
    AssistWeapon                                   = 12,
    MeleeWeapon                                    = 13,
    ThrowWeapon                                    = 14,
    Armor_Helmet                                   = 15,
    Armor_Vest                                     = 16,
    Pocket                                         = 17,
    SafeBox                                        = 18,
    SafeBoxIcon                                    = 19,
    Headset                                        = 20,
    FaceCover                                      = 21,
    EyeWear                                        = 22,
    ArmBand                                        = 23,
    DogTag                                         = 24,
    SplitItemWindow                                = 25,
    RotateItemWindow                               = 26,
    MAX                                            = 27

};


// Enum  /Script/UAGame.ETutorialToggleFXType
enum class ETutorialToggleFXType : uint8_t
{
    None                                           = 0,
    Open                                           = 1,
    Close                                          = 2,
    ETutorialToggleFXType_MAX                      = 3

};


// Enum  /Script/UAGame.ETutorialFXType
enum class ETutorialFXType : uint8_t
{
    None                                           = 0,
    BPFX_ArticuloMortis                            = 1,
    BPFX_Eye                                       = 2,
    BPFX_Eye_Anim2                                 = 3,
    BP_Eye_AnimLoop                                = 4,
    BP_Eye_Eye                                     = 5,
    BPFX_Eye_Anim2_Open                            = 6,
    ETutorialFXType_MAX                            = 7

};


// Enum  /Script/UAGame.EInteractionEscapeMode
enum class EInteractionEscapeMode : uint8_t
{
    World                                          = 0,
    Team                                           = 1,
    Personal                                       = 2,
    EInteractionEscapeMode_MAX                     = 3

};


// Enum  /Script/UAGame.ESubWidgetDisplayMode
enum class ESubWidgetDisplayMode : uint8_t
{
    NormalDisplay                                  = 0,
    ConstrainToEdge                                = 1,
    HideWhenOutOfRange                             = 2,
    ESubWidgetDisplayMode_MAX                      = 3

};


// Enum  /Script/UAGame.InventoryDestroyedEffectType
enum class InventoryDestroyedEffectType : uint8_t
{
    QuestFailed                                    = 0,
    InventoryDestroyedEffectType_MAX               = 1

};


// Enum  /Script/UAGame.ETutorialCharacterStateCheckType
enum class ETutorialCharacterStateCheckType : uint8_t
{
    TutorialCharacterStateCheckType_None           = 0,
    TutorialCharacterStateCheckType_OnceInState    = 1,
    TutorialCharacterStateCheckType_AddProgressInState = 2,
    TutorialCharacterStateCheckType_MAX            = 3

};


// Enum  /Script/UAGame.EQuestConditionCharacterType
enum class EQuestConditionCharacterType : uint8_t
{
    ECharacterType_AI                              = 0,
    ECharacterType_TEAMMATE                        = 1,
    ECharacterType_MAX                             = 2

};


// Enum  /Script/UAGame.EQuestConditionCharacterStatus
enum class EQuestConditionCharacterStatus : uint8_t
{
    ECharacterType_ALIVE_HAS                       = 0,
    ECharacterType_ALIVE_ALL                       = 1,
    ECharacterType_DIED_HAS                        = 2,
    ECharacterType_DIED_ALL                        = 3,
    ECharacterType_MAX                             = 4

};


// Enum  /Script/UAGame.EQuestCheckCustomAttribute
enum class EQuestCheckCustomAttribute : uint8_t
{
    TotalEndurance                                 = 0,
    EQuestCheckCustomAttribute_MAX                 = 1

};


// Enum  /Script/UAGame.ECheckItemType
enum class ECheckItemType : uint8_t
{
    Weapon                                         = 0,
    Helmet                                         = 1,
    Vest                                           = 2,
    Headset                                        = 3,
    FaceCover                                      = 4,
    EyeWear                                        = 5,
    VestBag                                        = 6,
    Bag                                            = 7,
    ECheckItemType_MAX                             = 8

};


// Enum  /Script/UAGame.EGameplayTagCheckType
enum class EGameplayTagCheckType : uint8_t
{
    AnyMatching                                    = 0,
    AllMatching                                    = 1,
    EGameplayTagCheckType_MAX                      = 2

};


// Enum  /Script/UAGame.EQuestTakeLimitLogicType
enum class EQuestTakeLimitLogicType : uint8_t
{
    Enum_And                                       = 0,
    Enum_Or                                        = 1,
    Enum_MAX                                       = 2

};


// Enum  /Script/UAGame.ETeamInfoCheckType
enum class ETeamInfoCheckType : uint8_t
{
    MaxCount                                       = 0,
    AliveCount                                     = 1,
    EscapeCount                                    = 2,
    DiedCount                                      = 3,
    ETeamInfoCheckType_MAX                         = 4

};


// Enum  /Script/UAGame.ETimeLimitType
enum class ETimeLimitType : uint8_t
{
    EnterGame                                      = 0,
    TimeRecord                                     = 1,
    ETimeLimitType_MAX                             = 2

};


// Enum  /Script/UAGame.ETutorialBagState
enum class ETutorialBagState : uint8_t
{
    BigMapState_None                               = 0,
    BigMapState_Open                               = 1,
    BigMapState_Close                              = 2,
    BigMapState_MAX                                = 3

};


// Enum  /Script/UAGame.EBigMapState
enum class EBigMapState : uint8_t
{
    BigMapState_None                               = 0,
    BigMapState_Open                               = 1,
    BigMapState_Close                              = 2,
    BigMapState_MAX                                = 3

};


// Enum  /Script/UAGame.ETutorialDoorState
enum class ETutorialDoorState : uint8_t
{
    TutorialDoorState_None                         = 0,
    TutorialDoorState_Open                         = 1,
    TutorialDoorState_Close                        = 2,
    TutorialDoorState_MAX                          = 3

};


// Enum  /Script/UAGame.EFacePanelState
enum class EFacePanelState : uint8_t
{
    FacePanelState_None                            = 0,
    FacePanelState_Open                            = 1,
    FacePanelState_Close                           = 2,
    FacePanelState_MAX                             = 3

};


// Enum  /Script/UAGame.ETutorialSettingState
enum class ETutorialSettingState : uint8_t
{
    SettingPannalState_None                        = 0,
    SettingPannalState_Open                        = 1,
    SettingPannalState_Close                       = 2,
    SettingPannalState_MAX                         = 3

};


// Enum  /Script/UAGame.ETutorialDamageType
enum class ETutorialDamageType : uint8_t
{
    ETutorialDamageType_None                       = 0,
    ETutorialDamageType_Bullet                     = 1,
    ETutorialDamageType_Grenade                    = 2,
    ETutorialDamageType_MAX                        = 3

};


// Enum  /Script/UAGame.EQuestInteractEnableType
enum class EQuestInteractEnableType : uint8_t
{
    Self                                           = 0,
    Teammate                                       = 1,
    Anyone                                         = 2,
    EQuestInteractEnableType_MAX                   = 3

};


// Enum  /Script/UAGame.EQuestTraceMarkType
enum class EQuestTraceMarkType : uint8_t
{
    QuestInventory                                 = 0,
    InteractItem                                   = 1,
    Area                                           = 2,
    EscapePoint                                    = 3,
    EQuestTraceMarkType_MAX                        = 4

};


// Enum  /Script/UAGame.EAutoCollectActorType
enum class EAutoCollectActorType : uint8_t
{
    CollectActor_Manual                            = 0,
    CollectActor_Distance                          = 1,
    CollectActor_All                               = 2,
    CollectActor_MAX                               = 3

};


// Enum  /Script/UAGame.ESoundDirType
enum class ESoundDirType : uint8_t
{
    None                                           = 0,
    LEFT                                           = 1,
    CENTER                                         = 2,
    RIGHT                                          = 3,
    ESoundDirType_MAX                              = 4

};


// Enum  /Script/UAGame.ESplineDrawType
enum class ESplineDrawType : uint8_t
{
    Consecutive                                    = 0,
    Discrete                                       = 1,
    Consecutive_SL                                 = 2,
    Discrete_SL                                    = 3,
    ESplineDrawType_MAX                            = 4

};


// Enum  /Script/UAGame.EConsumptionType
enum class EConsumptionType : uint8_t
{
    Personal                                       = 0,
    Team                                           = 1,
    Global                                         = 2,
    EConsumptionType_MAX                           = 3

};


// Enum  /Script/UAGame.EActivityDataCenterType
enum class EActivityDataCenterType : uint8_t
{
    E_None                                         = 0,
    E_GameState                                    = 1,
    E_TeamInfo                                     = 2,
    E_PlayerState                                  = 3,
    E_MAX                                          = 4

};


// Enum  /Script/UAGame.ELootRandomItemType
enum class ELootRandomItemType : uint8_t
{
    MainSetting                                    = 0,
    NormalItem                                     = 1,
    SubItemTable                                   = 2,
    AssembledItem                                  = 3,
    ELootRandomItemType_MAX                        = 4

};


// Enum  /Script/UAGame.ESGLootRandomItemOperation
enum class ESGLootRandomItemOperation : uint8_t
{
    And                                            = 0,
    Or                                             = 1,
    ESGLootRandomItemOperation_MAX                 = 2

};


// Enum  /Script/UAGame.EUAActorMeshPerformanceState
enum class EUAActorMeshPerformanceState : uint8_t
{
    None                                           = 0,
    Playing                                        = 1,
    Waiting                                        = 2,
    Complete                                       = 3,
    EUAActorMeshPerformanceState_MAX               = 4

};


// Enum  /Script/UAGame.EUASceneEventListeningRule
enum class EUASceneEventListeningRule : uint8_t
{
    And                                            = 0,
    Or                                             = 1,
    EUASceneEventListeningRule_MAX                 = 2

};


// Enum  /Script/UAGame.EVehicleLootType
enum class EVehicleLootType : uint8_t
{
    Normal                                         = 0,
    PossessByAI                                    = 1,
    EVehicleLootType_MAX                           = 2

};


// Enum  /Script/UAGame.EPMCAI2_PlanState
enum class EPMCAI2_PlanState : uint8_t
{
    EPreParing                                     = 0,
    EWaitForRep                                    = 1,
    EWaitForActivating                             = 2,
    EUsed                                          = 3,
    EPMCAI2_MAX                                    = 4

};


// Enum  /Script/UAGame.EVectorAISpawnLocType
enum class EVectorAISpawnLocType : uint8_t
{
    VectorAround                                   = 0,
    RandomPlayerSpawnPoint                         = 1,
    RandomAISpawnPoint                             = 2,
    EVectorAISpawnLocType_MAX                      = 3

};


// Enum  /Script/UAGame.EAnnounceManagerActiveQueueResult
enum class EAnnounceManagerActiveQueueResult : uint8_t
{
    ActiveSuccess                                  = 0,
    SlotPlayingNow                                 = 1,
    QueueBeEmpty                                   = 2,
    WaitAnotherQueue                               = 3,
    EAnnounceManagerActiveQueueResult_MAX          = 4

};


// Enum  /Script/UAGame.EAnnounceWidgetRuntimeState
enum class EAnnounceWidgetRuntimeState : uint8_t
{
    RestInPool                                     = 0,
    WaitRequestAsyncLoad                           = 1,
    ReadyToShow                                    = 2,
    ShowNow                                        = 3,
    WaitHideAnimatePlay                            = 4,
    HideNow                                        = 5,
    WaitEndAnimatePlay                             = 6,
    EAnnounceWidgetRuntimeState_MAX                = 7

};


// Enum  /Script/UAGame.EAnnounceOrderType
enum class EAnnounceOrderType : uint8_t
{
    DefaultUnderBag                                = 0,
    OverTheBag                                     = 1,
    EAnnounceOrderType_MAX                         = 2

};


// Enum  /Script/UAGame.EAnnounceTemplateType
enum class EAnnounceTemplateType : uint8_t
{
    TopInfoTips                                    = 0,
    CountDownBr                                    = 1,
    ChangeTextColor                                = 2,
    OtherType                                      = 99,
    EAnnounceTemplateType_MAX                      = 100

};


// Enum  /Script/UAGame.EAnnounceSlot
enum class EAnnounceSlot : uint8_t
{
    Top                                            = 0,
    Bottom                                         = 1,
    Right                                          = 2,
    Center                                         = 3,
    RightBottom                                    = 4,
    Left                                           = 5,
    FillScreen                                     = 6,
    LeftUp                                         = 7,
    RightUp                                        = 8,
    EAnnounceSlot_MAX                              = 9

};


// Enum  /Script/UAGame.EAnnounceType
enum class EAnnounceType : uint8_t
{
    InstantMessage                                 = 0,
    CountDown                                      = 1,
    EAnnounceType_MAX                              = 2

};


// Enum  /Script/UAGame.EAnnounceReliable
enum class EAnnounceReliable : uint8_t
{
    Reliable                                       = 2,
    UnResend                                       = 0,
    EAnnounceReliable_MAX                          = 3

};


// Enum  /Script/UAGame.EUATutorialArrowTipType
enum class EUATutorialArrowTipType : uint8_t
{
    Container                                      = 0,
    FillAmmo                                       = 1,
    EUATutorialArrowTipType_MAX                    = 2

};


// Enum  /Script/UAGame.EUATutorialHighlightEffectType
enum class EUATutorialHighlightEffectType : uint8_t
{
    None                                           = 0,
    Search                                         = 1,
    Inspect                                        = 2,
    GamePad                                        = 3,
    SelectMenu                                     = 4,
    SelectMenu_NotMine                             = 5,
    EscapePointIcon                                = 6,
    SelectMenu_ItemPopup                           = 7,
    InspectHighEffect                              = 8,
    ItemHighEffect_NotMine                         = 9,
    EUATutorialHighlightEffectType_MAX             = 10

};


// Enum  /Script/UAGame.EUATakeOutValueComputeMode
enum class EUATakeOutValueComputeMode : uint8_t
{
    Normal                                         = 0,
    SafeArea                                       = 1,
    EUATakeOutValueComputeMode_MAX                 = 2

};


// Enum  /Script/UAGame.EUAMarkedType
enum class EUAMarkedType : uint8_t
{
    EUAMarkedType_None                             = 0,
    EUAMarkedType_TitleInfo                        = 1,
    EUAMarkedType_MAX                              = 2

};


// Enum  /Script/UAGame.EEscapeInteractVolumeState
enum class EEscapeInteractVolumeState : uint8_t
{
    EEscapeInteractVolumeState_None                = 0,
    EEscapeInteractVolumeState_Unactivate          = 1,
    EEscapeInteractVolumeState_Activate            = 2,
    EEscapeInteractVolumeState_Interacted          = 3,
    EEscapeInteractVolumeState_MAX                 = 4

};


// Enum  /Script/UAGame.EUAEscapeTimeType
enum class EUAEscapeTimeType : uint8_t
{
    Locality                                       = 0,
    Global                                         = 1,
    EUAEscapeTimeType_MAX                          = 2

};


// Enum  /Script/UAGame.EUATimeType
enum class EUATimeType : uint8_t
{
    None                                           = 0,
    Open                                           = 1,
    Close                                          = 2,
    EUATimeType_MAX                                = 3

};


// Enum  /Script/UAGame.EEscapeArmedState
enum class EEscapeArmedState : uint8_t
{
    Default                                        = 0,
    Armed                                          = 1,
    UnArmed                                        = 2,
    EEscapeArmedState_MAX                          = 3

};


// Enum  /Script/UAGame.EEscapePerformanceType
enum class EEscapePerformanceType : uint8_t
{
    EEscapePerformanceType_None                    = 0,
    EEscapePerformanceType_SinglePerson            = 1,
    EEscapePerformanceType_Team                    = 2,
    EEscapePerformanceType_MAX                     = 3

};


// Enum  /Script/UAGame.EEscapeState
enum class EEscapeState : uint8_t
{
    EEscapeState_None                              = 0,
    EEscapeState_CanEscape                         = 1,
    EEscapeState_Close                             = 2,
    EEscapeState_Open                              = 3,
    EEscapeState_NotOpen                           = 4,
    EEscapeState_MAX                               = 5

};


// Enum  /Script/UAGame.EEscapeVolumeStyle
enum class EEscapeVolumeStyle : uint8_t
{
    Normal                                         = 0,
    ThemeActivity                                  = 1,
    EEscapeVolumeStyle_MAX                         = 2

};


// Enum  /Script/UAGame.EEscapeVolumeType
enum class EEscapeVolumeType : uint8_t
{
    Locality                                       = 0,
    Global                                         = 1,
    EEscapeVolumeType_MAX                          = 2

};


// Enum  /Script/UAGame.EChatacterVisibleState
enum class EChatacterVisibleState : uint8_t
{
    EChatacterVisibleState_None                    = 0,
    EChatacterVisibleState_Invisible               = 1,
    EChatacterVisibleState_Visible                 = 2,
    EChatacterVisibleState_MAX                     = 3

};


// Enum  /Script/UAGame.EUAFSMCompareType
enum class EUAFSMCompareType : uint8_t
{
    UAFSMCompareType_None                          = 0,
    UAFSMCompareType_Less                          = 1,
    UAFSMCompareType_LessEqual                     = 2,
    UAFSMCompareType_Equals                        = 3,
    UAFSMCompareType_GreaterEqual                  = 4,
    UAFSMCompareType_Greater                       = 5,
    UAFSMCompareType_NotEqual                      = 6,
    UAFSMCompareType_Between                       = 7,
    UAFSMCompareType_MAX                           = 8

};


// Enum  /Script/UAGame.EUAFSMRelative
enum class EUAFSMRelative : uint8_t
{
    UAFSMRelative_None                             = 0,
    UAFSMRelative_And                              = 1,
    UAFSMRelative_Or                               = 2,
    UAFSMRelative_MAX                              = 3

};


// Enum  /Script/UAGame.EGameMapId
enum class EGameMapId : uint8_t
{
    None                                           = 0,
    Erangel                                        = 1,
    Desert                                         = 2,
    ErangelOrigin                                  = 3,
    Savage                                         = 4,
    Max                                            = 5

};


// Enum  /Script/UAGame.ESubGameModeType
enum class ESubGameModeType : uint32_t
{
    None                                           = 0,
    Main                                           = 100,
    DeathPoisonFog                                 = 200,
    Compact                                        = 201,
    RandomMap                                      = 300,
    Fog                                            = 301,
    CustomItemSniper                               = 400,
    CustomItemColdArms                             = 401,
    CustomItem3xRich                               = 402,
    CustomItemPistol                               = 403,
    CustomItemShotgun                              = 404,
    CustomItemDrug                                 = 405,
    HardCore                                       = 500,
    FPP                                            = 501,
    BattleOfFiveArmies                             = 502,
    BattleOfThreeTeams                             = 503,
    MAX                                            = 504

};


// Enum  /Script/UAGame.EMainGameModeType
enum class EMainGameModeType : uint8_t
{
    None                                           = 0,
    ClassicPVP                                     = 1,
    LeisurePVP                                     = 2,
    MAX                                            = 3

};


// Enum  /Script/UAGame.EGameTeamType
enum class EGameTeamType : uint8_t
{
    None                                           = 0,
    OnePlayer                                      = 1,
    TwoPlayers                                     = 2,
    FourPlayers                                    = 3,
    ThreeTeams                                     = 4,
    FiveTeams                                      = 5,
    Max                                            = 6

};


// Enum  /Script/UAGame.EGameMatchType
enum class EGameMatchType : uint8_t
{
    None                                           = 0,
    Normal                                         = 1,
    Rank                                           = 2,
    Custom                                         = 3,
    Max                                            = 4

};


// Enum  /Script/UAGame.EUARoleID
enum class EUARoleID : uint8_t
{
    Sledge                                         = 0,
    Ash                                            = 1,
    Bandit                                         = 2,
    Castle                                         = 3,
    Glaz                                           = 4,
    Jager                                          = 5,
    Kapkan                                         = 6,
    Rook                                           = 7,
    Tharcher                                       = 8,
    Thermite                                       = 9,
    EUARoleID_MAX                                  = 10

};


// Enum  /Script/UAGame.EBattleRoyalContentionAreaType
enum class EBattleRoyalContentionAreaType : uint8_t
{
    Escape                                         = 0,
    Paradrop                                       = 1,
    BattleRoyal                                    = 2,
    EBattleRoyalContentionAreaType_MAX             = 3

};


// Enum  /Script/UAGame.EBattleRoyalParadropType
enum class EBattleRoyalParadropType : uint8_t
{
    None                                           = 0,
    InsideBRVolume                                 = 1,
    ArroundEscape                                  = 2,
    EBattleRoyalParadropType_MAX                   = 3

};


// Enum  /Script/UAGame.EBattleRoyalEscapePointType
enum class EBattleRoyalEscapePointType : uint8_t
{
    None                                           = 0,
    InsideBRVolume                                 = 1,
    OutsideBRVolume                                = 2,
    EBattleRoyalEscapePointType_MAX                = 3

};


// Enum  /Script/UAGame.EBattleRoyalVolumeType
enum class EBattleRoyalVolumeType : uint8_t
{
    None                                           = 0,
    InsideLastBRVolume                             = 1,
    EBattleRoyalVolumeType_MAX                     = 2

};


// Enum  /Script/UAGame.EUATutorialDefaultInventory
enum class EUATutorialDefaultInventory : uint8_t
{
    None                                           = 0,
    TutorialAKM                                    = 1,
    TutorialHK416                                  = 2,
    EUATutorialDefaultInventory_MAX                = 3

};


// Enum  /Script/UAGame.EMarketItemType
enum class EMarketItemType : uint8_t
{
    None                                           = 0,
    MainWeapon                                     = 1,
    Pistol                                         = 2,
    Equip                                          = 3,
    Prop                                           = 4,
    RepairEquip                                    = 5,
    EMarketItemType_MAX                            = 6

};


// Enum  /Script/UAGame.EUARadioEnv
enum class EUARadioEnv : uint8_t
{
    Outdoor                                        = 0,
    Indoor                                         = 1,
    EUARadioEnv_MAX                                = 2

};


// Enum  /Script/UAGame.EUARadioType
enum class EUARadioType : uint8_t
{
    None                                           = 0,
    Fire_Default                                   = 10,
    Fire_Wander                                    = 11,
    Fire_PatrolTeam                                = 12,
    Fire_Sniper                                    = 13,
    Death_Default                                  = 20,
    Death_Renor                                    = 21,
    Death_Ajax                                     = 22,
    Loot_Default                                   = 30,
    Loot_SafeBox                                   = 31,
    Loot_AirDrop                                   = 32,
    Open_Default                                   = 40,
    Open_SluiceGate                                = 41,
    Open_RoomDoor                                  = 42,
    Open_BlackDoor                                 = 43,
    Enter_Default                                  = 50,
    EUARadioType_MAX                               = 51

};


// Enum  /Script/UAGame.EUARoundState
enum class EUARoundState : uint8_t
{
    EUARoundState_NONE                             = 0,
    EUARoundState_Prepare                          = 1,
    EUARoundState_CountDown                        = 2,
    EUARoundState_Gaming                           = 3,
    EUARoundState_MAX                              = 4

};


// Enum  /Script/UAGame.ETutorialLevelType
enum class ETutorialLevelType : uint8_t
{
    None                                           = 0,
    CStory                                         = 1,
    GreenHand                                      = 2,
    ETutorialLevelType_MAX                         = 3

};


// Enum  /Script/UAGame.ETutorialBagTabType
enum class ETutorialBagTabType : uint8_t
{
    TutorialTabType_None                           = 0,
    TutorialTabType_Equipment                      = 1,
    TutorialTabType_VestBag                        = 2,
    TutorialTabType_Pockage                        = 3,
    TutorialTabType_Bag                            = 4,
    TutorialTabType_SafeBox                        = 5,
    TutorialTabType_Character                      = 100,
    TutorialTabType_Health                         = 101,
    TutorialTabType_Quest                          = 102,
    TutorialTabType_Map                            = 103,
    TutorialTabType_Season                         = 104,
    TutorialTabType_MAX                            = 105

};


// Enum  /Script/UAGame.ETutorialCharacterState
enum class ETutorialCharacterState : uint8_t
{
    TutorialCharacterState_None                    = 0,
    TutorialCharacterState_Stand                   = 1,
    TutorialCharacterState_Jump                    = 2,
    TutorialCharacterState_Crouch                  = 3,
    TutorialCharacterState_Prone                   = 4,
    TutorialCharacterState_Zooming                 = 5,
    TutorialCharacterState_LoseEndurance           = 6,
    TutorialCharacterState_Sprint                  = 7,
    TutorialCharacterState_SilentWalk              = 8,
    TutorialCharacterState_HoldingBreath           = 9,
    TutorialCharacterState_ChangeClip              = 10,
    TutorialCharacterState_MAX                     = 11

};


// Enum  /Script/UAGame.EBigMapTouchResponseType
enum class EBigMapTouchResponseType : uint8_t
{
    None                                           = 0,
    Global                                         = 1,
    Locality                                       = 2,
    EBigMapTouchResponseType_MAX                   = 3

};


// Enum  /Script/UAGame.ENewMapDisplayModel
enum class ENewMapDisplayModel : uint8_t
{
    Free                                           = 0,
    FollowViewCharacter                            = 1,
    ENewMapDisplayModel_MAX                        = 2

};


// Enum  /Script/UAGame.ENewMapTouchResponseType
enum class ENewMapTouchResponseType : uint8_t
{
    None                                           = 0,
    Global                                         = 1,
    Locality                                       = 2,
    ENewMapTouchResponseType_MAX                   = 3

};


// Enum  /Script/UAGame.EHUDWeaponSlotType
enum class EHUDWeaponSlotType : uint8_t
{
    FirstMainWeapon                                = 0,
    SecondMainWeapon                               = 1,
    AssistantWeapon                                = 2,
    MeleeWeapon                                    = 3,
    EHUDWeaponSlotType_MAX                         = 4

};


// Enum  /Script/UAGame.EWidgetTopParentActorType
enum class EWidgetTopParentActorType : uint8_t
{
    CharaterSelf                                   = 0,
    LootBox                                        = 1,
    CorpseBox                                      = 2,
    BagBox                                         = 3,
    EWidgetTopParentActorType_MAX                  = 4

};


// Enum  /Script/UAGame.EUAHUDNewBagWidgetIdentification
enum class EUAHUDNewBagWidgetIdentification : uint8_t
{
    Undefined                                      = 0,
    PickupsNearby                                  = 1,
    MyBag                                          = 2,
    MyBagIcon                                      = 3,
    VestBag                                        = 4,
    VestBagIcon                                    = 5,
    PickBag                                        = 6,
    Character                                      = 7,
    Inventory                                      = 8,
    Adapter                                        = 9,
    FirstMainWeapon                                = 10,
    SecondMainWeapon                               = 11,
    AssistWeapon                                   = 12,
    MeleeWeapon                                    = 13,
    ThrowWeapon                                    = 14,
    Armor_Helmet                                   = 15,
    Armor_Vest                                     = 16,
    Pocket                                         = 17,
    SafeBox                                        = 18,
    SafeBoxIcon                                    = 19,
    Headset                                        = 20,
    FaceCover                                      = 21,
    EyeWear                                        = 22,
    ArmBand                                        = 23,
    DogTag                                         = 24,
    SplitItemWindow                                = 25,
    RotateItemWindow                               = 26,
    PickBagIcon                                    = 27,
    KeyBagIcon                                     = 28,
    KeyBag                                         = 29,
    VehicleKey                                     = 30,
    SpecialItem                                    = 31,
    StagingContaienr                               = 32,
    MAX                                            = 33

};


// Enum  /Script/UAGame.EUAHUDBagWidgetIdentification
enum class EUAHUDBagWidgetIdentification : uint8_t
{
    Undefined                                      = 0,
    PickupsNearby                                  = 1,
    MyBag                                          = 2,
    Weapons                                        = 3,
    Apparel                                        = 4,
    Inventory                                      = 5,
    Adapter                                        = 6,
    FirstMainWeapon                                = 7,
    SecondMainWeapon                               = 8,
    AssistWeapon                                   = 9,
    MeleeWeapon                                    = 10,
    ThrowWeapon                                    = 11,
    Helmet                                         = 12,
    FlatJacket                                     = 13,
    Apparel_Hat                                    = 14,
    Apparel_Glasses                                = 15,
    Apparel_UpShirt                                = 16,
    Apparel_Pants                                  = 17,
    Apparel_Shoes                                  = 18,
    Apparel_Ghillie                                = 19,
    MAX                                            = 20

};


// Enum  /Script/UAGame.EItemAction
enum class EItemAction : uint8_t
{
    ActionNone                                     = 0,
    ActionPickup                                   = 1,
    ActionUse                                      = 2,
    ActionAttach                                   = 3,
    ActionReload                                   = 4,
    ActionExchange                                 = 5,
    ActionDetach                                   = 6,
    ActionDiscard                                  = 7,
    ActionPickupPart                               = 8,
    ActionDiscardPart                              = 9,
    ActionRevertSkin                               = 10,
    ActionPutonSkin                                = 11,
    EItemAction_MAX                                = 12

};


// Enum  /Script/UAGame.EBRPlayerState
enum class EBRPlayerState : uint8_t
{
    PlayerState_NONE                               = 0,
    PlayerState_Normal                             = 1,
    PlayerState_Airplane                           = 2,
    PlayerState_Air                                = 3,
    PlayerState_Drive                              = 4,
    PlayerState_Weak                               = 5,
    PlayerState_OffLine                            = 6,
    PlayerState_Dead                               = 7,
    PlayerState_Spectating                         = 8,
    PlayerState_MAX                                = 9

};


// Enum  /Script/UAGame.EHostedInteractDoAction
enum class EHostedInteractDoAction : uint8_t
{
    EHostedInteractAction_None                     = 0,
    EHostedInteractCompleteAction_LootInventory    = 1,
    EHostedInteractDoAction_MAX                    = 2

};


// Enum  /Script/UAGame.EPlaceObject_Exec
enum class EPlaceObject_Exec : uint8_t
{
    OnPutDownCompleted                             = 0,
    OnPlaceObjectCompleted                         = 1,
    OnTakeupCompleted                              = 2,
    OnInterrupted                                  = 3,
    EPlaceObject_MAX                               = 4

};


// Enum  /Script/UAGame.EPlayCGAnimation_Exec
enum class EPlayCGAnimation_Exec : uint8_t
{
    OnLoadLevelCompleted                           = 0,
    OnStartPlayAnimation                           = 1,
    OnAnimationCompleted                           = 2,
    OnInterrupted                                  = 3,
    EPlayCGAnimation_MAX                           = 4

};


// Enum  /Script/UAGame.EPlayMontageWithEnd_Exec
enum class EPlayMontageWithEnd_Exec : uint8_t
{
    OnAnimationCompleted                           = 0,
    EPlayMontageWithEnd_MAX                        = 1

};


// Enum  /Script/UAGame.EDecoderLootContainerStateType
enum class EDecoderLootContainerStateType : uint8_t
{
    None                                           = 0,
    Locked                                         = 1,
    CountDown                                      = 2,
    NeedRepair                                     = 3,
    Finished                                       = 4,
    EDecoderLootContainerStateType_MAX             = 5

};


// Enum  /Script/UAGame.ELockLootContainerConditionType
enum class ELockLootContainerConditionType : uint8_t
{
    None                                           = 0,
    CostInventory                                  = 1,
    CheckMissionStatues                            = 2,
    ELockLootContainerConditionType_MAX            = 3

};


// Enum  /Script/UAGame.EChangeDoorDataType
enum class EChangeDoorDataType : uint8_t
{
    ChangeDoorOpenType                             = 0,
    SetGateLockCountDown                           = 1,
    EChangeDoorDataType_MAX                        = 2

};


// Enum  /Script/UAGame.ELimitAreaStateType
enum class ELimitAreaStateType : uint8_t
{
    StartLimitArea                                 = 0,
    ClearupLimitArea                               = 1,
    ELimitAreaStateType_MAX                        = 2

};


// Enum  /Script/UAGame.EEscapeConditionsChangeType
enum class EEscapeConditionsChangeType : uint8_t
{
    EEscapeConditionsType_Add                      = 0,
    EEscapeConditionsType_Remove                   = 1,
    EEscapeConditionsType_MAX                      = 2

};


// Enum  /Script/UAGame.EEscapeConditionsType
enum class EEscapeConditionsType : uint8_t
{
    EEscapeConditionsType_CanEscape                = 0,
    EEscapeConditionsType_Close                    = 1,
    EEscapeConditionsType_Person                   = 2,
    EEscapeConditionsType_MAX                      = 3

};


// Enum  /Script/UAGame.ETargetEscapeState
enum class ETargetEscapeState : uint8_t
{
    ETargetEscapeState_None                        = 0,
    ETargetEscapeState_CanEscape                   = 1,
    ETargetEscapeState_Close                       = 2,
    ETargetEscapeState_Open                        = 3,
    ETargetEscapeState_NotOpen                     = 4,
    ETargetEscapeState_MAX                         = 5

};


// Enum  /Script/UAGame.EMissionConditionMemberCountType
enum class EMissionConditionMemberCountType : uint8_t
{
    E_Alive                                        = 0,
    E_InGame                                       = 1,
    E_MAX                                          = 2

};


// Enum  /Script/UAGame.EFPSCCheckType
enum class EFPSCCheckType : uint8_t
{
    EFPSCCheckType_All                             = 0,
    EFPSCCheckType_Farthest                        = 1,
    EFPSCCheckType_Nearest                         = 2,
    EFPSCCheckType_DistanceRange                   = 3,
    EFPSCCheckType_MAX                             = 4

};


// Enum  /Script/UAGame.EAISceneEventType
enum class EAISceneEventType : uint8_t
{
    SceneEventTrigger                              = 0,
    SceneEventExpired                              = 1,
    SceneEventRemoved                              = 2,
    SceneEventCompleted                            = 3,
    EAISceneEventType_MAX                          = 4

};


// Enum  /Script/UAGame.EDamageStatisType
enum class EDamageStatisType : uint8_t
{
    CauseDamage                                    = 0,
    TakeDamage                                     = 1,
    EDamageStatisType_MAX                          = 2

};


// Enum  /Script/UAGame.EPlayerFlowState
enum class EPlayerFlowState : uint8_t
{
    None                                           = 0,
    PreProcess                                     = 1,
    Load                                           = 2,
    Wait                                           = 3,
    CountDown                                      = 4,
    Game                                           = 5,
    ExitGame                                       = 6,
    WatchGame                                      = 7,
    Preparations                                   = 8,
    Transition                                     = 9,
    EPlayerFlowState_MAX                           = 10

};


// Enum  /Script/UAGame.EMissionObjective_RandTimerType
enum class EMissionObjective_RandTimerType : uint8_t
{
    GameBegin                                      = 0,
    ObjectiveActivated                             = 1,
    EMissionObjective_MAX                          = 2

};


// Enum  /Script/UAGame.ESpawnActorMode
enum class ESpawnActorMode : uint8_t
{
    NetRelevantActor                               = 0,
    ActorSpawnPointInVolume                        = 1,
    ESpawnActorMode_MAX                            = 2

};


// Enum  /Script/UAGame.EStartInvDetectingMode
enum class EStartInvDetectingMode : uint8_t
{
    Nearest                                        = 0,
    GlobalMap                                      = 1,
    EStartInvDetectingMode_MAX                     = 2

};


// Enum  /Script/UAGame.EUAMissionTimeCheckType
enum class EUAMissionTimeCheckType : uint8_t
{
    Equal                                          = 0,
    NotEqual                                       = 1,
    GreaterThan                                    = 2,
    LessThan                                       = 3,
    GreaterThanOrEqual                             = 4,
    LessThanOrEqual                                = 5,
    Between                                        = 6,
    EUAMissionTimeCheckType_MAX                    = 7

};


// Enum  /Script/UAGame.EUAMissionWeatherCheckType
enum class EUAMissionWeatherCheckType : uint8_t
{
    CurrentEqual                                   = 0,
    WeatherChange                                  = 1,
    EUAMissionWeatherCheckType_MAX                 = 2

};


// Enum  /Script/UAGame.EMissionObjectiveWriteBattleLineOperateType_AISpawnAreaNames
enum class EMissionObjectiveWriteBattleLineOperateType_AISpawnAreaNames : uint8_t
{
    AddUnique                                      = 0,
    Add                                            = 1,
    RemoveAll                                      = 2,
    RemoveSingle                                   = 3,
    Clear                                          = 4,
    EMissionObjectiveWriteBattleLineOperateType_MAX = 5

};


// Enum  /Script/UAGame.EMissionObjectiveWriteBattleLineOperateType_StageId
enum class EMissionObjectiveWriteBattleLineOperateType_StageId : uint8_t
{
    Set                                            = 0,
    Addition                                       = 1,
    CopyBy                                         = 2,
    ExChange                                       = 3,
    EMissionObjectiveWriteBattleLineOperateType_MAX = 4

};


// Enum  /Script/UAGame.EMissionConditionTeamInfoType
enum class EMissionConditionTeamInfoType : uint8_t
{
    MaxCount                                       = 0,
    AliveCount                                     = 1,
    EscapeCount                                    = 2,
    DiedCount                                      = 3,
    EMissionConditionTeamInfoType_MAX              = 4

};


// Enum  /Script/UAGame.EMissionConditionCharacterType
enum class EMissionConditionCharacterType : uint8_t
{
    ECharacterType_AI                              = 0,
    ECharacterType_TEAMMATE                        = 1,
    ECharacterType_MAX                             = 2

};


// Enum  /Script/UAGame.EMissionConditionCharacterStatus
enum class EMissionConditionCharacterStatus : uint8_t
{
    ECharacterType_ALIVE_HAS                       = 0,
    ECharacterType_ALIVE_ALL                       = 1,
    ECharacterType_DIED_HAS                        = 2,
    ECharacterType_DIED_ALL                        = 3,
    ECharacterType_MAX                             = 4

};


// Enum  /Script/UAGame.EMissionConditionGameplayTagCheckType
enum class EMissionConditionGameplayTagCheckType : uint8_t
{
    AnyMatching                                    = 0,
    AllMatching                                    = 1,
    EMissionConditionGameplayTagCheckType_MAX      = 2

};


// Enum  /Script/UAGame.EMissionConditionNumberType
enum class EMissionConditionNumberType : uint8_t
{
    Int32                                          = 0,
    Int64                                          = 1,
    EMissionConditionNumberType_MAX                = 2

};


// Enum  /Script/UAGame.EMissionConditionItemType
enum class EMissionConditionItemType : uint8_t
{
    Weapon                                         = 0,
    Helmet                                         = 1,
    Vest                                           = 2,
    Headset                                        = 3,
    FaceCover                                      = 4,
    EyeWear                                        = 5,
    VestBag                                        = 6,
    Bag                                            = 7,
    EMissionConditionItemType_MAX                  = 8

};


// Enum  /Script/UAGame.EMissionConditionCustomAttribute
enum class EMissionConditionCustomAttribute : uint8_t
{
    TotalEndurance                                 = 0,
    EMissionConditionCustomAttribute_MAX           = 1

};


// Enum  /Script/UAGame.ESGInventoryContainerLootStatus
enum class ESGInventoryContainerLootStatus : uint8_t
{
    None                                           = 0,
    AlreadyLoot                                    = 1,
    NeverLoot                                      = 2,
    ESGInventoryContainerLootStatus_MAX            = 3

};


// Enum  /Script/UAGame.EMissionSubType
enum class EMissionSubType : uint8_t
{
    E_MISSION_SUB_TYPE_NONE                        = 0,
    E_MISSION_SUB_TYPE_RANDOM_TASK                 = 1,
    E_MISSION_SUB_TYPE_DUEL_TASK                   = 2,
    E_MISSION_SUB_TYPE_GLOBAL_TASK                 = 3,
    E_MISSION_SUB_TYPE_ACTIVITY_TASK               = 4,
    E_MISSION_SUB_TYPE_RANDOM_EVENT                = 5,
    E_MISSION_SUB_TYPE_RESIDENT_EVENT              = 6,
    E_MISSION_SUB_TYPE_ACTIVITY_EVENT              = 7,
    E_MISSION_SUB_TYPE_MAX                         = 8

};


// Enum  /Script/UAGame.EDistributeMissionType
enum class EDistributeMissionType : uint8_t
{
    UrgentTask                                     = 0,
    DynamicEvent                                   = 1,
    ActivityEvent                                  = 2,
    EDistributeMissionType_MAX                     = 3

};


// Enum  /Script/UAGame.EParadropPointType
enum class EParadropPointType : uint8_t
{
    None                                           = 0,
    Individual                                     = 1,
    Sub                                            = 2,
    EParadropPointType_MAX                         = 3

};


// Enum  /Script/UAGame.EUAParadropSupplyFrameMeshHideType
enum class EUAParadropSupplyFrameMeshHideType : uint8_t
{
    Never                                          = 0,
    AfterLanding                                   = 1,
    Always                                         = 2,
    EUAParadropSupplyFrameMeshHideType_MAX         = 3

};


// Enum  /Script/UAGame.EUAPlayerRoundReulst
enum class EUAPlayerRoundReulst : uint8_t
{
    EUAPlayerRoundReulst_NONE                      = 0,
    EUAPlayerRoundReulst_Win                       = 1,
    EUAPlayerRoundReulst_Loss                      = 2,
    EUAPlayerRoundReulst_Draw                      = 3,
    EUAPlayerRoundReulst_MAX                       = 4

};


// Enum  /Script/UAGame.EPlayerActiveSettlementType
enum class EPlayerActiveSettlementType : uint8_t
{
    EPlayerActiveSettlementType_None               = 0,
    EPlayerActiveSettlementType_BRGame             = 1,
    EPlayerActiveSettlementType_MAX                = 2

};


// Enum  /Script/UAGame.EPVEGameControlType
enum class EPVEGameControlType : uint8_t
{
    E_None                                         = 0,
    E_STOPGAME                                     = 1,
    E_MAX                                          = 2

};


// Enum  /Script/UAGame.EPVEModifyStatisDataType
enum class EPVEModifyStatisDataType : uint8_t
{
    E_None                                         = 0,
    E_Set                                          = 1,
    E_Add                                          = 2,
    E_AddProgress                                  = 3,
    E_MAX                                          = 4

};


// Enum  /Script/UAGame.EEmergencyTaskType
enum class EEmergencyTaskType : uint8_t
{
    Normal                                         = 0,
    Activity                                       = 1,
    EEmergencyTaskType_MAX                         = 2

};


// Enum  /Script/UAGame.EQuestUnLockType
enum class EQuestUnLockType : uint8_t
{
    QuestUnLock_None                               = 0,
    QuestUnLock_TimeToMeet                         = 1,
    QuestUnLock_ProgressChange                     = 2,
    QuestUnLock_MAX                                = 3

};


// Enum  /Script/UAGame.EQuestCharacterType
enum class EQuestCharacterType : uint8_t
{
    QuestCharacterType_None                        = 0,
    QuestCharacterType_PMC                         = 1,
    QuestCharacterType_SCAV                        = 2,
    QuestCharacterType_AI_SCAV                     = 3,
    QuestCharacterType_MAX                         = 4

};


// Enum  /Script/UAGame.EDummyGrid2DFailedType
enum class EDummyGrid2DFailedType : uint8_t
{
    Grid2D_SUCCESS                                 = 0,
    Grid2D_Invalid                                 = 1,
    Grid2D_ItemDisable                             = 2,
    Grid2D_Config                                  = 3,
    Grid2D_NotInit                                 = 4,
    Grid2D_NetStartup                              = 5,
    Grid2D_Hidden                                  = 6,
    Grid2D_NoMeshComp                              = 7,
    Grid2D_HasAttachParent                         = 8,
    Grid2D_HasChildren                             = 9,
    Gird2D_HasNotDefaultSkin                       = 10,
    EDummyGrid2DFailedType_MAX                     = 11

};


// Enum  /Script/UAGame.EClassRepNodeMapping
enum class EClassRepNodeMapping : uint8_t
{
    NotRouted                                      = 0,
    RelevantAllConnections                         = 1,
    Spatialize_Static                              = 2,
    Spatialize_Dynamic                             = 3,
    Spatialize_Dormancy                            = 4,
    Spatialize_Static_Dormancy                     = 5,
    RelevantTeam                                   = 6,
    RelevantFollowOwner                            = 7,
    RelevantOwnerConnection                        = 8,
    RelevantConnectionsGroup                       = 9,
    DynamicPolicy                                  = 10,
    RelvantAI                                      = 11,
    RelevantFaction                                = 12,
    RelevantForFactionWhenNoOwner                  = 13,
    SimpleDistanceRelevancy                        = 14,
    RelevantFollowConnAndSpectator                 = 15,
    EClassRepNodeMapping_MAX                       = 16

};


// Enum  /Script/UAGame.ERoundGlobalDataType
enum class ERoundGlobalDataType : uint8_t
{
    None                                           = 0,
    Faction                                        = 1,
    PersonaArena                                   = 2,
    ERoundGlobalDataType_MAX                       = 3

};


// Enum  /Script/UAGame.EEscapeExploreState
enum class EEscapeExploreState : uint8_t
{
    EEscapeExploreState_None                       = 0,
    EEscapeExploreState_AlwaysOpen                 = 1,
    EEscapeExploreState_Open                       = 2,
    EEscapeExploreState_Close                      = 3,
    EEscapeExploreState_Unknown                    = 4,
    EEscapeExploreState_MAX                        = 5

};


// Enum  /Script/UAGame.ESignType
enum class ESignType : uint8_t
{
    EscapeSign                                     = 0,
    QuestSign                                      = 1,
    PlayerSign                                     = 2,
    None                                           = 3,
    ESignType_MAX                                  = 4

};


// Enum  /Script/UAGame.EUACheckPointOprationType
enum class EUACheckPointOprationType : uint8_t
{
    E_None                                         = 0,
    E_SetCheckPoint                                = 1,
    E_ReportRookieStep                             = 2,
    E_MAX                                          = 3

};


// Enum  /Script/UAGame.EDetailBoardType
enum class EDetailBoardType : uint8_t
{
    TaskIcon                                       = 0,
    EscapeIcon                                     = 1,
    ChaseTargetIcon                                = 2,
    EDetailBoardType_MAX                           = 3

};


// Enum  /Script/UAGame.EMoveCheckStyle
enum class EMoveCheckStyle : uint8_t
{
    OnlyMove                                       = 0,
    OnlyAdd                                        = 1,
    EMoveCheckStyle_MAX                            = 2

};


// Enum  /Script/UAGame.EBattleIntensityExpectation
enum class EBattleIntensityExpectation : uint8_t
{
    None                                           = 0,
    Low                                            = 1,
    Normal                                         = 2,
    High                                           = 3,
    VeryHigh                                       = 4,
    EBattleIntensityExpectation_MAX                = 5

};


// Enum  /Script/UAGame.ETraceMarkOperatorType
enum class ETraceMarkOperatorType : uint8_t
{
    None                                           = 0,
    Trace                                          = 1,
    Mark                                           = 2,
    All                                            = 3,
    InfomationTrace                                = 4,
    ETraceMarkOperatorType_MAX                     = 5

};


// Enum  /Script/UAGame.ETraceableMarkType
enum class ETraceableMarkType : uint8_t
{
    None                                           = 0,
    QuestPoint                                     = 1,
    QuestArea                                      = 2,
    ChaseActivity                                  = 3,
    Inventory                                      = 4,
    InteractItem                                   = 5,
    Area                                           = 6,
    EscapePoint                                    = 7,
    Character                                      = 8,
    AISpawnArea                                    = 9,
    SecretQuest                                    = 10,
    Point                                          = 11,
    DossEscapePoint                                = 12,
    All                                            = 13,
    ETraceableMarkType_MAX                         = 14

};


// Enum  /Script/CoreUObject.ELifetimeCondition
enum class ELifetimeCondition : uint8_t
{
    COND_None                                      = 0,
    COND_InitialOnly                               = 1,
    COND_OwnerOnly                                 = 2,
    COND_SkipOwner                                 = 3,
    COND_SimulatedOnly                             = 4,
    COND_AutonomousOnly                            = 5,
    COND_SimulatedOrPhysics                        = 6,
    COND_InitialOrOwner                            = 7,
    COND_Custom                                    = 8,
    COND_ReplayOrOwner                             = 9,
    COND_ReplayOnly                                = 10,
    COND_SimulatedOnlyNoReplay                     = 11,
    COND_SimulatedOrPhysicsNoReplay                = 12,
    COND_SkipReplay                                = 13,
    COND_ViewTarget                                = 14,
    COND_ViewTargetSkipOwner                       = 15,
    COND_Never                                     = 17,
    COND_Max                                       = 18

};


// Enum  /Script/CoreUObject.EDataValidationResult
enum class EDataValidationResult : uint8_t
{
    Invalid                                        = 0,
    Valid                                          = 1,
    NotValidated                                   = 2,
    EDataValidationResult_MAX                      = 3

};


// Enum  /Script/CoreUObject.EAppMsgType
enum class EAppMsgType : uint8_t
{
    Ok                                             = 0,
    YesNo                                          = 1,
    OkCancel                                       = 2,
    YesNoCancel                                    = 3,
    CancelRetryContinue                            = 4,
    YesNoYesAllNoAll                               = 5,
    YesNoYesAllNoAllCancel                         = 6,
    YesNoYesAll                                    = 7,
    EAppMsgType_MAX                                = 8

};


// Enum  /Script/CoreUObject.EAppReturnType
enum class EAppReturnType : uint8_t
{
    No                                             = 0,
    Yes                                            = 1,
    YesAll                                         = 2,
    NoAll                                          = 3,
    Cancel                                         = 4,
    Ok                                             = 5,
    Retry                                          = 6,
    Continue                                       = 7,
    EAppReturnType_MAX                             = 8

};


// Enum  /Script/CoreUObject.EPropertyAccessChangeNotifyMode
enum class EPropertyAccessChangeNotifyMode : uint8_t
{
    Default                                        = 0,
    Never                                          = 1,
    Always                                         = 2,
    EPropertyAccessChangeNotifyMode_MAX            = 3

};


// Enum  /Script/CoreUObject.EUnit
enum class EUnit : uint8_t
{
    Micrometers                                    = 0,
    Millimeters                                    = 1,
    Centimeters                                    = 2,
    Meters                                         = 3,
    Kilometers                                     = 4,
    Inches                                         = 5,
    Feet                                           = 6,
    Yards                                          = 7,
    Miles                                          = 8,
    Lightyears                                     = 9,
    Degrees                                        = 10,
    Radians                                        = 11,
    MetersPerSecond                                = 12,
    KilometersPerHour                              = 13,
    MilesPerHour                                   = 14,
    Celsius                                        = 15,
    Farenheit                                      = 16,
    Kelvin                                         = 17,
    Micrograms                                     = 18,
    Milligrams                                     = 19,
    Grams                                          = 20,
    Kilograms                                      = 21,
    MetricTons                                     = 22,
    Ounces                                         = 23,
    Pounds                                         = 24,
    Stones                                         = 25,
    Newtons                                        = 26,
    PoundsForce                                    = 27,
    KilogramsForce                                 = 28,
    Hertz                                          = 29,
    Kilohertz                                      = 30,
    Megahertz                                      = 31,
    Gigahertz                                      = 32,
    RevolutionsPerMinute                           = 33,
    Bytes                                          = 34,
    Kilobytes                                      = 35,
    Megabytes                                      = 36,
    Gigabytes                                      = 37,
    Terabytes                                      = 38,
    Lumens                                         = 39,
    Milliseconds                                   = 43,
    Seconds                                        = 44,
    Minutes                                        = 45,
    Hours                                          = 46,
    Days                                           = 47,
    Months                                         = 48,
    Years                                          = 49,
    Multiplier                                     = 52,
    Percentage                                     = 51,
    Unspecified                                    = 53,
    EUnit_MAX                                      = 54

};


// Enum  /Script/CoreUObject.EPixelFormat
enum class EPixelFormat : uint8_t
{
    PF_Unknown                                     = 0,
    PF_A32B32G32R32F                               = 1,
    PF_B8G8R8A8                                    = 2,
    PF_G8                                          = 3,
    PF_G16                                         = 4,
    PF_DXT1                                        = 5,
    PF_DXT3                                        = 6,
    PF_DXT5                                        = 7,
    PF_UYVY                                        = 8,
    PF_FloatRGB                                    = 9,
    PF_FloatRGBA                                   = 10,
    PF_DepthStencil                                = 11,
    PF_ShadowDepth                                 = 12,
    PF_R32_FLOAT                                   = 13,
    PF_G16R16                                      = 14,
    PF_G16R16F                                     = 15,
    PF_G16R16F_FILTER                              = 16,
    PF_G32R32F                                     = 17,
    PF_A2B10G10R10                                 = 18,
    PF_A16B16G16R16                                = 19,
    PF_D24                                         = 20,
    PF_R16F                                        = 21,
    PF_R16F_FILTER                                 = 22,
    PF_BC5                                         = 23,
    PF_V8U8                                        = 24,
    PF_A1                                          = 25,
    PF_FloatR11G11B10                              = 26,
    PF_A8                                          = 27,
    PF_R32_UINT                                    = 28,
    PF_R32_SINT                                    = 29,
    PF_PVRTC2                                      = 30,
    PF_PVRTC4                                      = 31,
    PF_R16_UINT                                    = 32,
    PF_R16_SINT                                    = 33,
    PF_R16G16B16A16_UINT                           = 34,
    PF_R16G16B16A16_SINT                           = 35,
    PF_R5G6B5_UNORM                                = 36,
    PF_R8G8B8A8                                    = 37,
    PF_A8R8G8B8                                    = 38,
    PF_BC4                                         = 39,
    PF_R8G8                                        = 40,
    PF_ATC_RGB                                     = 41,
    PF_ATC_RGBA_E                                  = 42,
    PF_ATC_RGBA_I                                  = 43,
    PF_X24_G8                                      = 44,
    PF_ETC1                                        = 45,
    PF_ETC2_RGB                                    = 46,
    PF_ETC2_RGBA                                   = 47,
    PF_R32G32B32A32_UINT                           = 48,
    PF_R16G16_UINT                                 = 49,
    PF_ASTC_4x4                                    = 50,
    PF_ASTC_5x4                                    = 72,
    PF_ASTC_5x5                                    = 73,
    PF_ASTC_6x6                                    = 51,
    PF_ASTC_8x5                                    = 74,
    PF_ASTC_8x6                                    = 75,
    PF_ASTC_8x8                                    = 52,
    PF_ASTC_10x8                                   = 76,
    PF_ASTC_10x10                                  = 53,
    PF_ASTC_12x12                                  = 54,
    PF_BC6H                                        = 55,
    PF_BC7                                         = 56,
    PF_R8_UINT                                     = 57,
    PF_L8                                          = 58,
    PF_XGXR8                                       = 59,
    PF_R8G8B8A8_UINT                               = 60,
    PF_R8G8B8A8_SNORM                              = 61,
    PF_R16G16B16A16_UNORM                          = 62,
    PF_R16G16B16A16_SNORM                          = 63,
    PF_PLATFORM_HDR                                = 64,
    PF_PLATFORM_HDR                                = 65,
    PF_PLATFORM_HDR                                = 66,
    PF_NV12                                        = 67,
    PF_R32G32_UINT                                 = 68,
    PF_ETC2_R11_EAC                                = 69,
    PF_ETC2_RG11_EAC                               = 70,
    PF_R4G4B4A4                                    = 77,
    PF_MAX                                         = 78

};


// Enum  /Script/CoreUObject.EAxis
enum class EAxis : uint8_t
{
    None                                           = 0,
    X                                              = 1,
    Y                                              = 2,
    Z                                              = 3,
    EAxis_MAX                                      = 4

};


// Enum  /Script/CoreUObject.ELogTimes
enum class ELogTimes : uint8_t
{
    None                                           = 0,
    UTC                                            = 1,
    SinceGStartTime                                = 2,
    Local                                          = 3,
    ELogTimes_MAX                                  = 4

};


// Enum  /Script/CoreUObject.ESearchDir
enum class ESearchDir : uint8_t
{
    FromStart                                      = 0,
    FromEnd                                        = 1,
    ESearchDir_MAX                                 = 2

};


// Enum  /Script/CoreUObject.ESearchCase
enum class ESearchCase : uint8_t
{
    CaseSensitive                                  = 0,
    IgnoreCase                                     = 1,
    ESearchCase_MAX                                = 2

};


// Enum  /Script/InputCore.EConsoleForGamepadLabels
enum class EConsoleForGamepadLabels : uint8_t
{
    None                                           = 0,
    XBoxOne                                        = 1,
    PS4                                            = 2,
    EConsoleForGamepadLabels_MAX                   = 3

};


// Enum  /Script/SlateCore.EFontLayoutMethod
enum class EFontLayoutMethod : uint8_t
{
    Metrics                                        = 0,
    BoundingBox                                    = 1,
    EFontLayoutMethod_MAX                          = 2

};


// Enum  /Script/SlateCore.EFontLoadingPolicy
enum class EFontLoadingPolicy : uint8_t
{
    LazyLoad                                       = 0,
    Stream                                         = 1,
    Inline                                         = 2,
    MemoryMapping                                  = 3,
    EFontLoadingPolicy_MAX                         = 4

};


// Enum  /Script/SlateCore.EFontHinting
enum class EFontHinting : uint8_t
{
    Default                                        = 0,
    Auto                                           = 1,
    AutoLight                                      = 2,
    Monochrome                                     = 3,
    None                                           = 4,
    EFontHinting_MAX                               = 5

};


// Enum  /Script/SlateCore.EFocusCause
enum class EFocusCause : uint8_t
{
    Mouse                                          = 0,
    Navigation                                     = 1,
    SetDirectly                                    = 2,
    Cleared                                        = 3,
    OtherWidgetLostFocus                           = 4,
    WindowActivate                                 = 5,
    EFocusCause_MAX                                = 6

};


// Enum  /Script/SlateCore.ESlateDebuggingFocusEvent
enum class ESlateDebuggingFocusEvent : uint8_t
{
    FocusChanging                                  = 0,
    FocusLost                                      = 1,
    FocusReceived                                  = 2,
    MAX                                            = 3

};


// Enum  /Script/SlateCore.ESlateDebuggingNavigationMethod
enum class ESlateDebuggingNavigationMethod : uint8_t
{
    Unknown                                        = 0,
    Explicit                                       = 1,
    CustomDelegateBound                            = 2,
    CustomDelegateUnbound                          = 3,
    NextOrPrevious                                 = 4,
    HitTestGrid                                    = 5,
    ESlateDebuggingNavigationMethod_MAX            = 6

};


// Enum  /Script/SlateCore.ESlateDebuggingStateChangeEvent
enum class ESlateDebuggingStateChangeEvent : uint8_t
{
    MouseCaptureGained                             = 0,
    MouseCaptureLost                               = 1,
    ESlateDebuggingStateChangeEvent_MAX            = 2

};


// Enum  /Script/SlateCore.ESlateDebuggingInputEvent
enum class ESlateDebuggingInputEvent : uint8_t
{
    MouseMove                                      = 0,
    MouseEnter                                     = 1,
    MouseLeave                                     = 2,
    PreviewMouseButtonDown                         = 3,
    MouseButtonDown                                = 4,
    MouseButtonUp                                  = 5,
    MouseButtonDoubleClick                         = 6,
    MouseWheel                                     = 7,
    TouchStart                                     = 8,
    TouchEnd                                       = 9,
    TouchForceChanged                              = 10,
    TouchFirstMove                                 = 11,
    TouchMoved                                     = 12,
    DragDetected                                   = 13,
    DragEnter                                      = 14,
    DragLeave                                      = 15,
    DragOver                                       = 16,
    DragDrop                                       = 17,
    DropMessage                                    = 18,
    PreviewKeyDown                                 = 19,
    KeyDown                                        = 20,
    KeyUp                                          = 21,
    KeyChar                                        = 22,
    AnalogInput                                    = 23,
    TouchGesture                                   = 24,
    MotionDetected                                 = 25,
    MAX                                            = 26

};


// Enum  /Script/SlateCore.EScrollDirection
enum class EScrollDirection : uint8_t
{
    Scroll_Down                                    = 0,
    Scroll_Up                                      = 1,
    Scroll_MAX                                     = 2

};


// Enum  /Script/SlateCore.EOrientation
enum class EOrientation : uint8_t
{
    Orient_Horizontal                              = 0,
    Orient_Vertical                                = 1,
    Orient_MAX                                     = 2

};


// Enum  /Script/SlateCore.EVerticalAlignment
enum class EVerticalAlignment : uint8_t
{
    VAlign_Fill                                    = 0,
    VAlign_Top                                     = 1,
    VAlign_Center                                  = 2,
    VAlign_Bottom                                  = 3,
    VAlign_MAX                                     = 4

};


// Enum  /Script/SlateCore.EHorizontalAlignment
enum class EHorizontalAlignment : uint8_t
{
    HAlign_Fill                                    = 0,
    HAlign_Left                                    = 1,
    HAlign_Center                                  = 2,
    HAlign_Right                                   = 3,
    HAlign_MAX                                     = 4

};


// Enum  /Script/SlateCore.ENavigationGenesis
enum class ENavigationGenesis : uint8_t
{
    Keyboard                                       = 0,
    Controller                                     = 1,
    User                                           = 2,
    ENavigationGenesis_MAX                         = 3

};


// Enum  /Script/SlateCore.ENavigationSource
enum class ENavigationSource : uint8_t
{
    FocusedWidget                                  = 0,
    WidgetUnderCursor                              = 1,
    ENavigationSource_MAX                          = 2

};


// Enum  /Script/SlateCore.EUINavigationAction
enum class EUINavigationAction : uint8_t
{
    Accept                                         = 0,
    Back                                           = 1,
    Num                                            = 2,
    Invalid                                        = 3,
    EUINavigationAction_MAX                        = 4

};


// Enum  /Script/SlateCore.EButtonPressMethod
enum class EButtonPressMethod : uint8_t
{
    DownAndUp                                      = 0,
    ButtonPress                                    = 1,
    ButtonRelease                                  = 2,
    EButtonPressMethod_MAX                         = 3

};


// Enum  /Script/SlateCore.EButtonTouchMethod
enum class EButtonTouchMethod : uint8_t
{
    DownAndUp                                      = 0,
    Down                                           = 1,
    PreciseTap                                     = 2,
    EButtonTouchMethod_MAX                         = 3

};


// Enum  /Script/SlateCore.EButtonClickMethod
enum class EButtonClickMethod : uint8_t
{
    DownAndUp                                      = 0,
    MouseDown                                      = 1,
    MouseUp                                        = 2,
    PreciseClick                                   = 3,
    EButtonClickMethod_MAX                         = 4

};


// Enum  /Script/SlateCore.ESlateParentWindowSearchMethod
enum class ESlateParentWindowSearchMethod : uint8_t
{
    ActiveWindow                                   = 0,
    MainWindow                                     = 1,
    ESlateParentWindowSearchMethod_MAX             = 2

};


// Enum  /Script/SlateCore.EConsumeMouseWheel
enum class EConsumeMouseWheel : uint8_t
{
    WhenScrollingPossible                          = 0,
    Always                                         = 1,
    Never                                          = 2,
    EConsumeMouseWheel_MAX                         = 3

};


// Enum  /Script/ImageWrapper.EBitmapCSType
enum class EBitmapCSType : uint32_t
{
    BCST_BLCS_CALIBRATED_RGB                       = 0,
    BCST_LCS_sRGB                                  = 1934772034,
    BCST_LCS_WINDOWS_COLOR_SPACE                   = 1466527264,
    BCST_PROFILE_LINKED                            = 1279872587,
    BCST_PROFILE_EMBEDDED                          = 1296188740,
    BCST_MAX                                       = 1934772035

};


// Enum  /Script/ImageWrapper.EBitmapHeaderVersion
enum class EBitmapHeaderVersion : uint8_t
{
    BHV_BITMAPINFOHEADER                           = 0,
    BHV_BITMAPV2INFOHEADER                         = 1,
    BHV_BITMAPV3INFOHEADER                         = 2,
    BHV_BITMAPV4HEADER                             = 3,
    BHV_BITMAPV5HEADER                             = 4,
    BHV_MAX                                        = 5

};


// Enum  /Script/Slate.ETableViewMode
enum class ETableViewMode : uint8_t
{
    List                                           = 0,
    Tile                                           = 1,
    Tree                                           = 2,
    ETableViewMode_MAX                             = 3

};


// Enum  /Script/Slate.ESelectionMode
enum class ESelectionMode : uint8_t
{
    None                                           = 0,
    Single                                         = 1,
    SingleToggle                                   = 2,
    Multi                                          = 3,
    ESelectionMode_MAX                             = 4

};


// Enum  /Script/Slate.EMultiBlockType
enum class EMultiBlockType : uint8_t
{
    None                                           = 0,
    ButtonRow                                      = 1,
    EditableText                                   = 2,
    Heading                                        = 3,
    MenuEntry                                      = 4,
    Separator                                      = 5,
    ToolBarButton                                  = 6,
    ToolBarComboButton                             = 7,
    Widget                                         = 8,
    EMultiBlockType_MAX                            = 9

};


// Enum  /Script/Slate.EMultiBoxType
enum class EMultiBoxType : uint8_t
{
    MenuBar                                        = 0,
    ToolBar                                        = 1,
    VerticalToolBar                                = 2,
    UniformToolBar                                 = 3,
    Menu                                           = 4,
    ButtonRow                                      = 5,
    EMultiBoxType_MAX                              = 6

};


// Enum  /Script/Slate.EProgressBarFillType
enum class EProgressBarFillType : uint8_t
{
    LeftToRight                                    = 0,
    RightToLeft                                    = 1,
    FillFromCenter                                 = 2,
    TopToBottom                                    = 3,
    BottomToTop                                    = 4,
    EProgressBarFillType_MAX                       = 5

};


// Enum  /Script/Slate.EAssumePaintSizeUse
enum class EAssumePaintSizeUse : uint8_t
{
    None                                           = 0,
    Once                                           = 1,
    Always                                         = 2,
    EAssumePaintSizeUse_MAX                        = 3

};


// Enum  /Script/Slate.EStretch
enum class EStretch : uint8_t
{
    None                                           = 0,
    Fill                                           = 1,
    ScaleToFit                                     = 2,
    ScaleToFitX                                    = 3,
    ScaleToFitY                                    = 4,
    ScaleToFill                                    = 5,
    ScaleBySafeZone                                = 6,
    UserSpecified                                  = 7,
    EStretch_MAX                                   = 8

};


// Enum  /Script/Slate.EStretchDirection
enum class EStretchDirection : uint8_t
{
    Both                                           = 0,
    DownOnly                                       = 1,
    UpOnly                                         = 2,
    EStretchDirection_MAX                          = 3

};


// Enum  /Script/Slate.EScrollWhenFocusChanges
enum class EScrollWhenFocusChanges : uint8_t
{
    NoScroll                                       = 0,
    InstantScroll                                  = 1,
    AnimatedScroll                                 = 2,
    EScrollWhenFocusChanges_MAX                    = 3

};


// Enum  /Script/Slate.EDescendantScrollDestination
enum class EDescendantScrollDestination : uint8_t
{
    IntoView                                       = 0,
    TopOrLeft                                      = 1,
    Center                                         = 2,
    EDescendantScrollDestination_MAX               = 3

};


// Enum  /Script/Slate.EListItemAlignment
enum class EListItemAlignment : uint8_t
{
    EvenlyDistributed                              = 0,
    EvenlySize                                     = 1,
    EvenlyWide                                     = 2,
    LeftAligned                                    = 3,
    RightAligned                                   = 4,
    CenterAligned                                  = 5,
    Fill                                           = 6,
    EListItemAlignment_MAX                         = 7

};


// Enum  /Script/Slate.ETextTransformPolicy
enum class ETextTransformPolicy : uint8_t
{
    None                                           = 0,
    ToLower                                        = 1,
    ToUpper                                        = 2,
    ETextTransformPolicy_MAX                       = 3

};


// Enum  /Script/Slate.ECustomizedToolMenuVisibility
enum class ECustomizedToolMenuVisibility : uint8_t
{
    None                                           = 0,
    Visible                                        = 1,
    Hidden                                         = 2,
    ECustomizedToolMenuVisibility_MAX              = 3

};


// Enum  /Script/Slate.EMultipleKeyBindingIndex
enum class EMultipleKeyBindingIndex : uint8_t
{
    Primary                                        = 0,
    Secondary                                      = 1,
    NumChords                                      = 2,
    EMultipleKeyBindingIndex_MAX                   = 3

};


// Enum  /Script/Slate.EUserInterfaceActionType
enum class EUserInterfaceActionType : uint8_t
{
    None                                           = 0,
    Button                                         = 1,
    ToggleButton                                   = 2,
    RadioButton                                    = 3,
    Check                                          = 4,
    CollapsedButton                                = 5,
    EUserInterfaceActionType_MAX                   = 6

};


// Enum  /Script/ImageWriteQueue.EDesiredImageFormat
enum class EDesiredImageFormat : uint8_t
{
    PNG                                            = 0,
    JPG                                            = 1,
    BMP                                            = 2,
    EXR                                            = 3,
    EDesiredImageFormat_MAX                        = 4

};


// Enum  /Script/MaterialShaderQualitySettings.EMobileShadowQuality
enum class EMobileShadowQuality : uint8_t
{
    NoFiltering                                    = 0,
    PCF_1x1                                        = 1,
    PCF_2x2                                        = 2,
    PCF_3x3                                        = 3,
    EMobileShadowQuality_MAX                       = 4

};


// Enum  /Script/EngineSettings.ESubLevelStripMode
enum class ESubLevelStripMode : uint8_t
{
    ExactClass                                     = 0,
    IsChildOf                                      = 1,
    ESubLevelStripMode_MAX                         = 2

};


// Enum  /Script/EngineSettings.EFourPlayerSplitScreenType
enum class EFourPlayerSplitScreenType : uint8_t
{
    Grid                                           = 0,
    Vertical                                       = 1,
    Horizontal                                     = 2,
    EFourPlayerSplitScreenType_MAX                 = 3

};


// Enum  /Script/EngineSettings.EThreePlayerSplitScreenType
enum class EThreePlayerSplitScreenType : uint8_t
{
    FavorTop                                       = 0,
    FavorBottom                                    = 1,
    Vertical                                       = 2,
    Horizontal                                     = 3,
    EThreePlayerSplitScreenType_MAX                = 4

};


// Enum  /Script/EngineSettings.ETwoPlayerSplitScreenType
enum class ETwoPlayerSplitScreenType : uint8_t
{
    Horizontal                                     = 0,
    Vertical                                       = 1,
    ETwoPlayerSplitScreenType_MAX                  = 2

};


// Enum  /Script/Chaos.EClusterUnionMethod
enum class EClusterUnionMethod : uint8_t
{
    PointImplicit                                  = 0,
    DelaunayTriangulation                          = 1,
    MinimalSpanningSubsetDelaunayTriangulation     = 2,
    PointImplicitAugmentedWithMinimalDelaunay      = 3,
    None                                           = 4,
    EClusterUnionMethod_MAX                        = 5

};


// Enum  /Script/Chaos.EFieldPhysicsDefaultFields
enum class EFieldPhysicsDefaultFields : uint8_t
{
    Field_RadialIntMask                            = 0,
    Field_RadialFalloff                            = 1,
    Field_UniformVector                            = 2,
    Field_RadialVector                             = 3,
    Field_RadialVectorFalloff                      = 4,
    Field_EFieldPhysicsDefaultFields_Max           = 5,
    Field_MAX                                      = 6

};


// Enum  /Script/Chaos.EFieldPhysicsType
enum class EFieldPhysicsType : uint8_t
{
    Field_None                                     = 0,
    Field_DynamicState                             = 1,
    Field_LinearForce                              = 2,
    Field_ExternalClusterStrain                    = 3,
    Field_Kill                                     = 4,
    Field_LinearVelocity                           = 5,
    Field_AngularVelociy                           = 6,
    Field_AngularTorque                            = 7,
    Field_InternalClusterStrain                    = 8,
    Field_DisableThreshold                         = 9,
    Field_SleepingThreshold                        = 10,
    Field_PositionStatic                           = 11,
    Field_PositionAnimated                         = 12,
    Field_PositionTarget                           = 13,
    Field_DynamicConstraint                        = 14,
    Field_CollisionGroup                           = 15,
    Field_ActivateDisabled                         = 16,
    Field_PhysicsType_Max                          = 17

};


// Enum  /Script/Chaos.EFieldFalloffType
enum class EFieldFalloffType : uint8_t
{
    Field_FallOff_None                             = 0,
    Field_Falloff_Linear                           = 1,
    Field_Falloff_Inverse                          = 2,
    Field_Falloff_Squared                          = 3,
    Field_Falloff_Logarithmic                      = 4,
    Field_Falloff_Max                              = 5

};


// Enum  /Script/Chaos.EFieldResolutionType
enum class EFieldResolutionType : uint8_t
{
    Field_Resolution_Minimal                       = 0,
    Field_Resolution_DisabledParents               = 1,
    Field_Resolution_Maximum                       = 2,
    Field_Resolution_Max                           = 3

};


// Enum  /Script/Chaos.EFieldCullingOperationType
enum class EFieldCullingOperationType : uint8_t
{
    Field_Culling_Inside                           = 0,
    Field_Culling_Outside                          = 1,
    Field_Culling_Operation_Max                    = 2,
    Field_Culling_MAX                              = 3

};


// Enum  /Script/Chaos.EFieldOperationType
enum class EFieldOperationType : uint8_t
{
    Field_Multiply                                 = 0,
    Field_Divide                                   = 1,
    Field_Add                                      = 2,
    Field_Substract                                = 3,
    Field_Operation_Max                            = 4

};


// Enum  /Script/Chaos.ESetMaskConditionType
enum class ESetMaskConditionType : uint8_t
{
    Field_Set_Always                               = 0,
    Field_Set_IFF_NOT_Interior                     = 1,
    Field_Set_IFF_NOT_Exterior                     = 2,
    Field_MaskCondition_Max                        = 3

};


// Enum  /Script/Chaos.EEmissionPatternTypeEnum
enum class EEmissionPatternTypeEnum : uint8_t
{
    Chaos_Emission_Pattern_First_Frame             = 0,
    Chaos_Emission_Pattern_On_Demand               = 1,
    Chaos_Max                                      = 2

};


// Enum  /Script/Chaos.EInitialVelocityTypeEnum
enum class EInitialVelocityTypeEnum : uint8_t
{
    Chaos_Initial_Velocity_User_Defined            = 0,
    Chaos_Initial_Velocity_None                    = 1,
    Chaos_Max                                      = 2

};


// Enum  /Script/Chaos.EGeometryCollectionPhysicsTypeEnum
enum class EGeometryCollectionPhysicsTypeEnum : uint8_t
{
    Chaos_AngularVelocity                          = 0,
    Chaos_DynamicState                             = 1,
    Chaos_LinearVelocity                           = 2,
    Chaos_InitialAngularVelocity                   = 3,
    Chaos_InitialLinearVelocity                    = 4,
    Chaos_CollisionGroup                           = 5,
    Chaos_LinearForce                              = 6,
    Chaos_AngularTorque                            = 7,
    Chaos_Max                                      = 8

};


// Enum  /Script/Chaos.EObjectStateTypeEnum
enum class EObjectStateTypeEnum : uint8_t
{
    Chaos_NONE                                     = 0,
    Chaos_Object_Sleeping                          = 1,
    Chaos_Object_Kinematic                         = 2,
    Chaos_Object_Static                            = 3,
    Chaos_Object_Dynamic                           = 4,
    Chaos_Object_UserDefined                       = 100,
    Chaos_Max                                      = 101

};


// Enum  /Script/Chaos.EImplicitTypeEnum
enum class EImplicitTypeEnum : uint8_t
{
    Chaos_Implicit_Box                             = 0,
    Chaos_Implicit_Sphere                          = 1,
    Chaos_Implicit_Capsule                         = 2,
    Chaos_Implicit_LevelSet                        = 3,
    Chaos_Implicit_None                            = 4,
    Chaos_Max                                      = 5

};


// Enum  /Script/Chaos.ECollisionTypeEnum
enum class ECollisionTypeEnum : uint8_t
{
    Chaos_Volumetric                               = 0,
    Chaos_Surface_Volumetric                       = 1,
    Chaos_Max                                      = 2

};


// Enum  /Script/Chaos.EChaosBufferMode
enum class EChaosBufferMode : uint8_t
{
    Double                                         = 0,
    Triple                                         = 1,
    Num                                            = 2,
    Invalid                                        = 3,
    EChaosBufferMode_MAX                           = 4

};


// Enum  /Script/Chaos.EChaosThreadingMode
enum class EChaosThreadingMode : uint8_t
{
    DedicatedThread                                = 0,
    TaskGraph                                      = 1,
    SingleThread                                   = 2,
    Num                                            = 3,
    Invalid                                        = 4,
    EChaosThreadingMode_MAX                        = 5

};


// Enum  /Script/Chaos.EChaosSolverTickMode
enum class EChaosSolverTickMode : uint8_t
{
    Fixed                                          = 0,
    Variable                                       = 1,
    VariableCapped                                 = 2,
    VariableCappedWithTarget                       = 3,
    EChaosSolverTickMode_MAX                       = 4

};


// Enum  /Script/Chaos.EGeometryCollectionCacheType
enum class EGeometryCollectionCacheType : uint8_t
{
    None                                           = 0,
    Record                                         = 1,
    Play                                           = 2,
    RecordAndPlay                                  = 3,
    EGeometryCollectionCacheType_MAX               = 4

};


// Enum  /Script/PhysicsCore.EBodyCollisionResponse
enum class EBodyCollisionResponse : uint8_t
{
    BodyCollision_Enabled                          = 0,
    BodyCollision_Disabled                         = 1,
    BodyCollision_MAX                              = 2

};


// Enum  /Script/PhysicsCore.EPhysicsType
enum class EPhysicsType : uint8_t
{
    PhysType_Default                               = 0,
    PhysType_Kinematic                             = 1,
    PhysType_Simulated                             = 2,
    PhysType_MAX                                   = 3

};


// Enum  /Script/PhysicsCore.ECollisionTraceFlag
enum class ECollisionTraceFlag : uint8_t
{
    CTF_UseDefault                                 = 0,
    CTF_UseSimpleAndComplex                        = 1,
    CTF_UseSimpleAsComplex                         = 2,
    CTF_UseComplexAsSimple                         = 3,
    CTF_MAX                                        = 4

};


// Enum  /Script/PhysicsCore.ELinearConstraintMotion
enum class ELinearConstraintMotion : uint8_t
{
    LCM_Free                                       = 0,
    LCM_Limited                                    = 1,
    LCM_Locked                                     = 2,
    LCM_MAX                                        = 3

};


// Enum  /Script/PhysicsCore.EConstraintFrame
enum class EConstraintFrame : uint8_t
{
    Frame1                                         = 0,
    Frame2                                         = 1,
    EConstraintFrame_MAX                           = 2

};


// Enum  /Script/PhysicsCore.EAngularConstraintMotion
enum class EAngularConstraintMotion : uint8_t
{
    ACM_Free                                       = 0,
    ACM_Limited                                    = 1,
    ACM_Locked                                     = 2,
    ACM_MAX                                        = 3

};


// Enum  /Script/PhysicsCore.ESleepFamily
enum class ESleepFamily : uint8_t
{
    Normal                                         = 0,
    Sensitive                                      = 1,
    Custom                                         = 2,
    ESleepFamily_MAX                               = 3

};


// Enum  /Script/PhysicsCore.ERadialImpulseFalloff
enum class ERadialImpulseFalloff : uint8_t
{
    RIF_Constant                                   = 0,
    RIF_Linear                                     = 1,
    RIF_MAX                                        = 2

};


// Enum  /Script/PhysicsCore.EFrictionCombineMode
enum class EFrictionCombineMode : uint8_t
{
    Average                                        = 0,
    Min                                            = 1,
    Multiply                                       = 2,
    Max                                            = 3

};


// Enum  /Script/MRMesh.EMeshTrackerVertexColorMode
enum class EMeshTrackerVertexColorMode : uint8_t
{
    None                                           = 0,
    Confidence                                     = 1,
    Block                                          = 2,
    EMeshTrackerVertexColorMode_MAX                = 3

};


// Enum  /Script/AugmentedReality.EARTrackingState
enum class EARTrackingState : uint8_t
{
    Unknown                                        = 0,
    Tracking                                       = 1,
    NotTracking                                    = 2,
    StoppedTracking                                = 3,
    EARTrackingState_MAX                           = 4

};


// Enum  /Script/AugmentedReality.EGeoAnchorComponentDebugMode
enum class EGeoAnchorComponentDebugMode : uint8_t
{
    None                                           = 0,
    ShowGeoData                                    = 1,
    EGeoAnchorComponentDebugMode_MAX               = 2

};


// Enum  /Script/AugmentedReality.EPoseComponentDebugMode
enum class EPoseComponentDebugMode : uint8_t
{
    None                                           = 0,
    ShowSkeleton                                   = 1,
    EPoseComponentDebugMode_MAX                    = 2

};


// Enum  /Script/AugmentedReality.EQRCodeComponentDebugMode
enum class EQRCodeComponentDebugMode : uint8_t
{
    None                                           = 0,
    ShowQRCode                                     = 1,
    EQRCodeComponentDebugMode_MAX                  = 2

};


// Enum  /Script/AugmentedReality.EImageComponentDebugMode
enum class EImageComponentDebugMode : uint8_t
{
    None                                           = 0,
    ShowDetectedImage                              = 1,
    EImageComponentDebugMode_MAX                   = 2

};


// Enum  /Script/AugmentedReality.EARFaceTransformMixing
enum class EARFaceTransformMixing : uint8_t
{
    ComponentOnly                                  = 0,
    ComponentLocationTrackedRotation               = 1,
    ComponentWithTracked                           = 2,
    TrackingOnly                                   = 3,
    EARFaceTransformMixing_MAX                     = 4

};


// Enum  /Script/AugmentedReality.EFaceComponentDebugMode
enum class EFaceComponentDebugMode : uint8_t
{
    None                                           = 0,
    ShowEyeVectors                                 = 1,
    ShowFaceMesh                                   = 2,
    EFaceComponentDebugMode_MAX                    = 3

};


// Enum  /Script/AugmentedReality.EPlaneComponentDebugMode
enum class EPlaneComponentDebugMode : uint8_t
{
    None                                           = 0,
    ShowNetworkRole                                = 1,
    ShowClassification                             = 2,
    EPlaneComponentDebugMode_MAX                   = 3

};


// Enum  /Script/AugmentedReality.EARSessionConfigFlags
enum class EARSessionConfigFlags : uint8_t
{
    None                                           = 0,
    GenerateMeshData                               = 1,
    RenderMeshDataInWireframe                      = 2,
    GenerateCollisionForMeshData                   = 4,
    GenerateNavMeshForMeshData                     = 8,
    UseMeshDataForOcclusion                        = 16,
    EARSessionConfigFlags_MAX                      = 17

};


// Enum  /Script/AugmentedReality.EARServicePermissionRequestResult
enum class EARServicePermissionRequestResult : uint8_t
{
    Granted                                        = 0,
    Denied                                         = 1,
    EARServicePermissionRequestResult_MAX          = 2

};


// Enum  /Script/AugmentedReality.EARServiceInstallRequestResult
enum class EARServiceInstallRequestResult : uint8_t
{
    Installed                                      = 0,
    DeviceNotCompatible                            = 1,
    UserDeclinedInstallation                       = 2,
    FatalError                                     = 3,
    EARServiceInstallRequestResult_MAX             = 4

};


// Enum  /Script/AugmentedReality.EARServiceAvailability
enum class EARServiceAvailability : uint8_t
{
    UnknownError                                   = 0,
    UnknownChecking                                = 1,
    UnknownTimedOut                                = 2,
    UnsupportedDeviceNotCapable                    = 3,
    SupportedNotInstalled                          = 4,
    SupportedVersionTooOld                         = 5,
    SupportedInstalled                             = 6,
    EARServiceAvailability_MAX                     = 7

};


// Enum  /Script/AugmentedReality.EARGeoTrackingAccuracy
enum class EARGeoTrackingAccuracy : uint8_t
{
    Undetermined                                   = 0,
    Low                                            = 1,
    Medium                                         = 2,
    High                                           = 3,
    EARGeoTrackingAccuracy_MAX                     = 4

};


// Enum  /Script/AugmentedReality.EARGeoTrackingStateReason
enum class EARGeoTrackingStateReason : uint8_t
{
    None                                           = 0,
    NotAvailableAtLocation                         = 1,
    NeedLocationPermissions                        = 2,
    DevicePointedTooLow                            = 3,
    WorldTrackingUnstable                          = 4,
    WaitingForLocation                             = 5,
    GeoDataNotLoaded                               = 6,
    VisualLocalizationFailed                       = 7,
    WaitingForAvailabilityCheck                    = 8,
    EARGeoTrackingStateReason_MAX                  = 9

};


// Enum  /Script/AugmentedReality.EARGeoTrackingState
enum class EARGeoTrackingState : uint8_t
{
    Initializing                                   = 0,
    Localized                                      = 1,
    Localizing                                     = 2,
    NotAvailable                                   = 3,
    EARGeoTrackingState_MAX                        = 4

};


// Enum  /Script/AugmentedReality.EARSceneReconstruction
enum class EARSceneReconstruction : uint8_t
{
    None                                           = 0,
    MeshOnly                                       = 1,
    MeshWithClassification                         = 2,
    EARSceneReconstruction_MAX                     = 3

};


// Enum  /Script/AugmentedReality.EARSessionTrackingFeature
enum class EARSessionTrackingFeature : uint8_t
{
    None                                           = 0,
    PoseDetection2D                                = 1,
    PersonSegmentation                             = 2,
    PersonSegmentationWithDepth                    = 3,
    SceneDepth                                     = 4,
    SmoothedSceneDepth                             = 5,
    EARSessionTrackingFeature_MAX                  = 6

};


// Enum  /Script/AugmentedReality.EARFaceTrackingUpdate
enum class EARFaceTrackingUpdate : uint8_t
{
    CurvesAndGeo                                   = 0,
    CurvesOnly                                     = 1,
    EARFaceTrackingUpdate_MAX                      = 2

};


// Enum  /Script/AugmentedReality.EAREnvironmentCaptureProbeType
enum class EAREnvironmentCaptureProbeType : uint8_t
{
    None                                           = 0,
    Manual                                         = 1,
    Automatic                                      = 2,
    EAREnvironmentCaptureProbeType_MAX             = 3

};


// Enum  /Script/AugmentedReality.EARFrameSyncMode
enum class EARFrameSyncMode : uint8_t
{
    SyncTickWithCameraImage                        = 0,
    SyncTickWithoutCameraImage                     = 1,
    EARFrameSyncMode_MAX                           = 2

};


// Enum  /Script/AugmentedReality.EARLightEstimationMode
enum class EARLightEstimationMode : uint8_t
{
    None                                           = 0,
    AmbientLightEstimate                           = 1,
    DirectionalLightEstimate                       = 2,
    EARLightEstimationMode_MAX                     = 3

};


// Enum  /Script/AugmentedReality.EARPlaneDetectionMode
enum class EARPlaneDetectionMode : uint8_t
{
    None                                           = 0,
    HorizontalPlaneDetection                       = 1,
    VerticalPlaneDetection                         = 2,
    EARPlaneDetectionMode_MAX                      = 3

};


// Enum  /Script/AugmentedReality.EARSessionType
enum class EARSessionType : uint8_t
{
    None                                           = 0,
    Orientation                                    = 1,
    World                                          = 2,
    Face                                           = 3,
    Image                                          = 4,
    ObjectScanning                                 = 5,
    PoseTracking                                   = 6,
    GeoTracking                                    = 7,
    EARSessionType_MAX                             = 8

};


// Enum  /Script/AugmentedReality.EARWorldAlignment
enum class EARWorldAlignment : uint8_t
{
    Gravity                                        = 0,
    GravityAndHeading                              = 1,
    Camera                                         = 2,
    EARWorldAlignment_MAX                          = 3

};


// Enum  /Script/AugmentedReality.EARDepthAccuracy
enum class EARDepthAccuracy : uint8_t
{
    Unkown                                         = 0,
    Approximate                                    = 1,
    Accurate                                       = 2,
    EARDepthAccuracy_MAX                           = 3

};


// Enum  /Script/AugmentedReality.EARDepthQuality
enum class EARDepthQuality : uint8_t
{
    Unkown                                         = 0,
    Low                                            = 1,
    High                                           = 2,
    EARDepthQuality_MAX                            = 3

};


// Enum  /Script/AugmentedReality.EARTextureType
enum class EARTextureType : uint8_t
{
    Unknown                                        = 0,
    CameraImage                                    = 1,
    CameraDepth                                    = 2,
    EnvironmentCapture                             = 3,
    PersonSegmentationImage                        = 4,
    PersonSegmentationDepth                        = 5,
    SceneDepthMap                                  = 6,
    SceneDepthConfidenceMap                        = 7,
    EARTextureType_MAX                             = 8

};


// Enum  /Script/AugmentedReality.EAREye
enum class EAREye : uint8_t
{
    LeftEye                                        = 0,
    RightEye                                       = 1,
    EAREye_MAX                                     = 2

};


// Enum  /Script/AugmentedReality.EARFaceBlendShape
enum class EARFaceBlendShape : uint8_t
{
    EyeBlinkLeft                                   = 0,
    EyeLookDownLeft                                = 1,
    EyeLookInLeft                                  = 2,
    EyeLookOutLeft                                 = 3,
    EyeLookUpLeft                                  = 4,
    EyeSquintLeft                                  = 5,
    EyeWideLeft                                    = 6,
    EyeBlinkRight                                  = 7,
    EyeLookDownRight                               = 8,
    EyeLookInRight                                 = 9,
    EyeLookOutRight                                = 10,
    EyeLookUpRight                                 = 11,
    EyeSquintRight                                 = 12,
    EyeWideRight                                   = 13,
    JawForward                                     = 14,
    JawLeft                                        = 15,
    JawRight                                       = 16,
    JawOpen                                        = 17,
    MouthClose                                     = 18,
    MouthFunnel                                    = 19,
    MouthPucker                                    = 20,
    MouthLeft                                      = 21,
    MouthRight                                     = 22,
    MouthSmileLeft                                 = 23,
    MouthSmileRight                                = 24,
    MouthFrownLeft                                 = 25,
    MouthFrownRight                                = 26,
    MouthDimpleLeft                                = 27,
    MouthDimpleRight                               = 28,
    MouthStretchLeft                               = 29,
    MouthStretchRight                              = 30,
    MouthRollLower                                 = 31,
    MouthRollUpper                                 = 32,
    MouthShrugLower                                = 33,
    MouthShrugUpper                                = 34,
    MouthPressLeft                                 = 35,
    MouthPressRight                                = 36,
    MouthLowerDownLeft                             = 37,
    MouthLowerDownRight                            = 38,
    MouthUpperUpLeft                               = 39,
    MouthUpperUpRight                              = 40,
    BrowDownLeft                                   = 41,
    BrowDownRight                                  = 42,
    BrowInnerUp                                    = 43,
    BrowOuterUpLeft                                = 44,
    BrowOuterUpRight                               = 45,
    CheekPuff                                      = 46,
    CheekSquintLeft                                = 47,
    CheekSquintRight                               = 48,
    NoseSneerLeft                                  = 49,
    NoseSneerRight                                 = 50,
    TongueOut                                      = 51,
    HeadYaw                                        = 52,
    HeadPitch                                      = 53,
    HeadRoll                                       = 54,
    LeftEyeYaw                                     = 55,
    LeftEyePitch                                   = 56,
    LeftEyeRoll                                    = 57,
    RightEyeYaw                                    = 58,
    RightEyePitch                                  = 59,
    RightEyeRoll                                   = 60,
    MAX                                            = 61

};


// Enum  /Script/AugmentedReality.EARFaceTrackingDirection
enum class EARFaceTrackingDirection : uint8_t
{
    FaceRelative                                   = 0,
    FaceMirrored                                   = 1,
    EARFaceTrackingDirection_MAX                   = 2

};


// Enum  /Script/AugmentedReality.EARCandidateImageOrientation
enum class EARCandidateImageOrientation : uint8_t
{
    Landscape                                      = 0,
    Portrait                                       = 1,
    EARCandidateImageOrientation_MAX               = 2

};


// Enum  /Script/AugmentedReality.EARAltitudeSource
enum class EARAltitudeSource : uint8_t
{
    Precise                                        = 0,
    Coarse                                         = 1,
    UserDefined                                    = 2,
    Unknown                                        = 3,
    EARAltitudeSource_MAX                          = 4

};


// Enum  /Script/AugmentedReality.EARJointTransformSpace
enum class EARJointTransformSpace : uint8_t
{
    Model                                          = 0,
    ParentJoint                                    = 1,
    EARJointTransformSpace_MAX                     = 2

};


// Enum  /Script/AugmentedReality.EARObjectClassification
enum class EARObjectClassification : uint8_t
{
    NotApplicable                                  = 0,
    Unknown                                        = 1,
    Wall                                           = 2,
    Ceiling                                        = 3,
    Floor                                          = 4,
    Table                                          = 5,
    Seat                                           = 6,
    Face                                           = 7,
    Image                                          = 8,
    World                                          = 9,
    SceneObject                                    = 10,
    HandMesh                                       = 11,
    Door                                           = 12,
    Window                                         = 13,
    EARObjectClassification_MAX                    = 14

};


// Enum  /Script/AugmentedReality.EARPlaneOrientation
enum class EARPlaneOrientation : uint8_t
{
    Horizontal                                     = 0,
    Vertical                                       = 1,
    Diagonal                                       = 2,
    EARPlaneOrientation_MAX                        = 3

};


// Enum  /Script/AugmentedReality.EARWorldMappingState
enum class EARWorldMappingState : uint8_t
{
    NotAvailable                                   = 0,
    StillMappingNotRelocalizable                   = 1,
    StillMappingRelocalizable                      = 2,
    Mapped                                         = 3,
    EARWorldMappingState_MAX                       = 4

};


// Enum  /Script/AugmentedReality.EARSessionStatus
enum class EARSessionStatus : uint8_t
{
    NotStarted                                     = 0,
    Running                                        = 1,
    NotSupported                                   = 2,
    FatalError                                     = 3,
    PermissionNotGranted                           = 4,
    UnsupportedConfiguration                       = 5,
    Other                                          = 6,
    EARSessionStatus_MAX                           = 7

};


// Enum  /Script/AugmentedReality.EARTrackingQualityReason
enum class EARTrackingQualityReason : uint8_t
{
    None                                           = 0,
    Initializing                                   = 1,
    Relocalizing                                   = 2,
    ExcessiveMotion                                = 3,
    InsufficientFeatures                           = 4,
    InsufficientLight                              = 5,
    BadState                                       = 6,
    EARTrackingQualityReason_MAX                   = 7

};


// Enum  /Script/AugmentedReality.EARTrackingQuality
enum class EARTrackingQuality : uint8_t
{
    NotTracking                                    = 0,
    OrientationOnly                                = 1,
    OrientationAndPosition                         = 2,
    EARTrackingQuality_MAX                         = 3

};


// Enum  /Script/AugmentedReality.EARLineTraceChannels
enum class EARLineTraceChannels : uint8_t
{
    None                                           = 0,
    FeaturePoint                                   = 1,
    GroundPlane                                    = 2,
    PlaneUsingExtent                               = 4,
    PlaneUsingBoundaryPolygon                      = 8,
    EARLineTraceChannels_MAX                       = 9

};


// Enum  /Script/AugmentedReality.EARCaptureType
enum class EARCaptureType : uint8_t
{
    Camera                                         = 0,
    QRCode                                         = 1,
    SpatialMapping                                 = 2,
    SceneUnderstanding                             = 3,
    EARCaptureType_MAX                             = 4

};


// Enum  /Script/HeadMountedDisplay.EXRVisualType
enum class EXRVisualType : uint8_t
{
    Controller                                     = 0,
    Hand                                           = 1,
    EXRVisualType_MAX                              = 2

};


// Enum  /Script/HeadMountedDisplay.EHandKeypoint
enum class EHandKeypoint : uint8_t
{
    Palm                                           = 0,
    Wrist                                          = 1,
    ThumbMetacarpal                                = 2,
    ThumbProximal                                  = 3,
    ThumbDistal                                    = 4,
    ThumbTip                                       = 5,
    IndexMetacarpal                                = 6,
    IndexProximal                                  = 7,
    IndexIntermediate                              = 8,
    IndexDistal                                    = 9,
    IndexTip                                       = 10,
    MiddleMetacarpal                               = 11,
    MiddleProximal                                 = 12,
    MiddleIntermediate                             = 13,
    MiddleDistal                                   = 14,
    MiddleTip                                      = 15,
    RingMetacarpal                                 = 16,
    RingProximal                                   = 17,
    RingIntermediate                               = 18,
    RingDistal                                     = 19,
    RingTip                                        = 20,
    LittleMetacarpal                               = 21,
    LittleProximal                                 = 22,
    LittleIntermediate                             = 23,
    LittleDistal                                   = 24,
    LittleTip                                      = 25,
    EHandKeypoint_MAX                              = 26

};


// Enum  /Script/HeadMountedDisplay.EXRTrackedDeviceType
enum class EXRTrackedDeviceType : uint8_t
{
    HeadMountedDisplay                             = 0,
    Controller                                     = 1,
    TrackingReference                              = 2,
    Other                                          = 3,
    Invalid                                        = 254,
    Any                                            = 255,
    EXRTrackedDeviceType_MAX                       = 256

};


// Enum  /Script/HeadMountedDisplay.ESpectatorScreenMode
enum class ESpectatorScreenMode : uint8_t
{
    Disabled                                       = 0,
    SingleEyeLetterboxed                           = 1,
    Undistorted                                    = 2,
    Distorted                                      = 3,
    SingleEye                                      = 4,
    SingleEyeCroppedToFill                         = 5,
    Texture                                        = 6,
    TexturePlusEye                                 = 7,
    ESpectatorScreenMode_MAX                       = 8

};


// Enum  /Script/HeadMountedDisplay.EXRSystemFlags
enum class EXRSystemFlags : uint8_t
{
    NoFlags                                        = 0,
    IsAR                                           = 1,
    IsTablet                                       = 2,
    IsHeadMounted                                  = 4,
    SupportsHandTracking                           = 8,
    EXRSystemFlags_MAX                             = 9

};


// Enum  /Script/HeadMountedDisplay.EXRDeviceConnectionResult
enum class EXRDeviceConnectionResult : uint8_t
{
    NoTrackingSystem                               = 0,
    FeatureNotSupported                            = 1,
    NoValidViewport                                = 2,
    MiscFailure                                    = 3,
    Success                                        = 4,
    EXRDeviceConnectionResult_MAX                  = 5

};


// Enum  /Script/HeadMountedDisplay.EHMDWornState
enum class EHMDWornState : uint8_t
{
    Unknown                                        = 0,
    Worn                                           = 1,
    NotWorn                                        = 2,
    EHMDWornState_MAX                              = 3

};


// Enum  /Script/HeadMountedDisplay.EHMDTrackingOrigin
enum class EHMDTrackingOrigin : uint8_t
{
    Floor                                          = 0,
    Eye                                            = 1,
    Stage                                          = 2,
    Unbounded                                      = 3,
    EHMDTrackingOrigin_MAX                         = 4

};


// Enum  /Script/HeadMountedDisplay.EOrientPositionSelector
enum class EOrientPositionSelector : uint8_t
{
    Orientation                                    = 0,
    Position                                       = 1,
    OrientationAndPosition                         = 2,
    EOrientPositionSelector_MAX                    = 3

};


// Enum  /Script/HeadMountedDisplay.ETrackingStatus
enum class ETrackingStatus : uint8_t
{
    NotTracked                                     = 0,
    InertialOnly                                   = 1,
    Tracked                                        = 2,
    ETrackingStatus_MAX                            = 3

};


// Enum  /Script/HeadMountedDisplay.ESpatialInputGestureAxis
enum class ESpatialInputGestureAxis : uint8_t
{
    None                                           = 0,
    Manipulation                                   = 1,
    Navigation                                     = 2,
    NavigationRails                                = 3,
    ESpatialInputGestureAxis_MAX                   = 4

};


// Enum  /Script/Foliage.EFoliageScaling
enum class EFoliageScaling : uint8_t
{
    Uniform                                        = 0,
    Free                                           = 1,
    LockXY                                         = 2,
    LockXZ                                         = 3,
    LockYZ                                         = 4,
    EFoliageScaling_MAX                            = 5

};


// Enum  /Script/Foliage.EVertexColorMaskChannel
enum class EVertexColorMaskChannel : uint8_t
{
    Red                                            = 0,
    Green                                          = 1,
    Blue                                           = 2,
    Alpha                                          = 3,
    MAX_None                                       = 4,
    EVertexColorMaskChannel_MAX                    = 5

};


// Enum  /Script/Foliage.FoliageVertexColorMask
enum class FoliageVertexColorMask : uint8_t
{
    FOLIAGEVERTEXCOLORMASK_Disabled                = 0,
    FOLIAGEVERTEXCOLORMASK_Red                     = 1,
    FOLIAGEVERTEXCOLORMASK_Green                   = 2,
    FOLIAGEVERTEXCOLORMASK_Blue                    = 3,
    FOLIAGEVERTEXCOLORMASK_Alpha                   = 4,
    FOLIAGEVERTEXCOLORMASK_MAX                     = 5

};


// Enum  /Script/Foliage.ESimulationQuery
enum class ESimulationQuery : uint8_t
{
    None                                           = 0,
    CollisionOverlap                               = 1,
    ShadeOverlap                                   = 2,
    AnyOverlap                                     = 3,
    ESimulationQuery_MAX                           = 4

};


// Enum  /Script/Foliage.ESimulationOverlap
enum class ESimulationOverlap : uint8_t
{
    CollisionOverlap                               = 0,
    ShadeOverlap                                   = 1,
    None                                           = 2,
    ESimulationOverlap_MAX                         = 3

};


// Enum  /Script/Landscape.ELandscapeBlendMode
enum class ELandscapeBlendMode : uint8_t
{
    LSBM_AdditiveBlend                             = 0,
    LSBM_AlphaBlend                                = 1,
    LSBM_MAX                                       = 2

};


// Enum  /Script/Landscape.ELandscapeSetupErrors
enum class ELandscapeSetupErrors : uint8_t
{
    LSE_None                                       = 0,
    LSE_NoLandscapeInfo                            = 1,
    LSE_CollsionXY                                 = 2,
    LSE_NoLayerInfo                                = 3,
    LSE_MAX                                        = 4

};


// Enum  /Script/Landscape.ELandscapeClearMode
enum class ELandscapeClearMode : uint8_t
{
    Clear_Weightmap                                = 1,
    Clear_Heightmap                                = 2,
    Clear_All                                      = 3,
    Clear_MAX                                      = 4

};


// Enum  /Script/Landscape.ELandscapeGizmoType
enum class ELandscapeGizmoType : uint8_t
{
    LGT_None                                       = 0,
    LGT_Height                                     = 1,
    LGT_Weight                                     = 2,
    LGT_MAX                                        = 3

};


// Enum  /Script/Landscape.EGrassScaling
enum class EGrassScaling : uint8_t
{
    Uniform                                        = 0,
    Free                                           = 1,
    LockXY                                         = 2,
    EGrassScaling_MAX                              = 3

};


// Enum  /Script/Landscape.ESplineModulationColorMask
enum class ESplineModulationColorMask : uint8_t
{
    Red                                            = 0,
    Green                                          = 1,
    Blue                                           = 2,
    Alpha                                          = 3,
    ESplineModulationColorMask_MAX                 = 4

};


// Enum  /Script/Landscape.ELandscapeLODFalloff
enum class ELandscapeLODFalloff : uint8_t
{
    Linear                                         = 0,
    SquareRoot                                     = 1,
    ELandscapeLODFalloff_MAX                       = 2

};


// Enum  /Script/Landscape.ELandscapeLayerDisplayMode
enum class ELandscapeLayerDisplayMode : uint8_t
{
    Default                                        = 0,
    Alphabetical                                   = 1,
    UserSpecific                                   = 2,
    ELandscapeLayerDisplayMode_MAX                 = 3

};


// Enum  /Script/Landscape.ELandscapeLayerPaintingRestriction
enum class ELandscapeLayerPaintingRestriction : uint8_t
{
    None                                           = 0,
    UseMaxLayers                                   = 1,
    ExistingOnly                                   = 2,
    UseComponentWhitelist                          = 3,
    ELandscapeLayerPaintingRestriction_MAX         = 4

};


// Enum  /Script/Landscape.ELandscapeImportAlphamapType
enum class ELandscapeImportAlphamapType : uint8_t
{
    Additive                                       = 0,
    Layered                                        = 1,
    ELandscapeImportAlphamapType_MAX               = 2

};


// Enum  /Script/Landscape.LandscapeSplineMeshOrientation
enum class LandscapeSplineMeshOrientation : uint8_t
{
    LSMO_XUp                                       = 0,
    LSMO_YUp                                       = 1,
    LSMO_MAX                                       = 2

};


// Enum  /Script/Landscape.ELandscapeLayerBlendType
enum class ELandscapeLayerBlendType : uint8_t
{
    LB_WeightBlend                                 = 0,
    LB_AlphaBlend                                  = 1,
    LB_HeightBlend                                 = 2,
    LB_MAX                                         = 3

};


// Enum  /Script/Landscape.ELandscapeCustomizedCoordType
enum class ELandscapeCustomizedCoordType : uint8_t
{
    LCCT_None                                      = 0,
    LCCT_CustomUV0                                 = 1,
    LCCT_CustomUV1                                 = 2,
    LCCT_CustomUV2                                 = 3,
    LCCT_WeightMapUV                               = 4,
    LCCT_MAX                                       = 5

};


// Enum  /Script/Landscape.ETerrainCoordMappingType
enum class ETerrainCoordMappingType : uint8_t
{
    TCMT_Auto                                      = 0,
    TCMT_XY                                        = 1,
    TCMT_XZ                                        = 2,
    TCMT_YZ                                        = 3,
    TCMT_MAX                                       = 4

};


// Enum  /Script/TimeManagement.EFrameNumberDisplayFormats
enum class EFrameNumberDisplayFormats : uint8_t
{
    NonDropFrameTimecode                           = 0,
    DropFrameTimecode                              = 1,
    Seconds                                        = 2,
    Frames                                         = 3,
    MAX_Count                                      = 4,
    EFrameNumberDisplayFormats_MAX                 = 5

};


// Enum  /Script/TimeManagement.ETimedDataInputState
enum class ETimedDataInputState : uint8_t
{
    Connected                                      = 0,
    Unresponsive                                   = 1,
    Disconnected                                   = 2,
    ETimedDataInputState_MAX                       = 3

};


// Enum  /Script/TimeManagement.ETimedDataInputEvaluationType
enum class ETimedDataInputEvaluationType : uint8_t
{
    None                                           = 0,
    Timecode                                       = 1,
    PlatformTime                                   = 2,
    ETimedDataInputEvaluationType_MAX              = 3

};


// Enum  /Script/MovieScene.EMovieSceneKeyInterpolation
enum class EMovieSceneKeyInterpolation : uint8_t
{
    Auto                                           = 0,
    User                                           = 1,
    Break                                          = 2,
    Linear                                         = 3,
    Constant                                       = 4,
    EMovieSceneKeyInterpolation_MAX                = 5

};


// Enum  /Script/MovieScene.EMovieSceneBlendType
enum class EMovieSceneBlendType : uint8_t
{
    Invalid                                        = 0,
    Absolute                                       = 1,
    Additive                                       = 2,
    Relative                                       = 4,
    AdditiveFromBase                               = 8,
    EMovieSceneBlendType_MAX                       = 9

};


// Enum  /Script/MovieScene.EMovieSceneCompletionMode
enum class EMovieSceneCompletionMode : uint8_t
{
    KeepState                                      = 0,
    RestoreState                                   = 1,
    ProjectDefault                                 = 2,
    EMovieSceneCompletionMode_MAX                  = 3

};


// Enum  /Script/MovieScene.EMovieSceneBuiltInEasing
enum class EMovieSceneBuiltInEasing : uint8_t
{
    Linear                                         = 0,
    SinIn                                          = 1,
    SinOut                                         = 2,
    SinInOut                                       = 3,
    QuadIn                                         = 4,
    QuadOut                                        = 5,
    QuadInOut                                      = 6,
    CubicIn                                        = 7,
    CubicOut                                       = 8,
    CubicInOut                                     = 9,
    QuartIn                                        = 10,
    QuartOut                                       = 11,
    QuartInOut                                     = 12,
    QuintIn                                        = 13,
    QuintOut                                       = 14,
    QuintInOut                                     = 15,
    ExpoIn                                         = 16,
    ExpoOut                                        = 17,
    ExpoInOut                                      = 18,
    CircIn                                         = 19,
    CircOut                                        = 20,
    CircInOut                                      = 21,
    EMovieSceneBuiltInEasing_MAX                   = 22

};


// Enum  /Script/MovieScene.EEvaluationMethod
enum class EEvaluationMethod : uint8_t
{
    Static                                         = 0,
    Swept                                          = 1,
    EEvaluationMethod_MAX                          = 2

};


// Enum  /Script/MovieScene.EMovieSceneSequenceFlags
enum class EMovieSceneSequenceFlags : uint8_t
{
    None                                           = 0,
    Volatile                                       = 1,
    BlockingEvaluation                             = 2,
    InheritedFlags                                 = 1,
    EMovieSceneSequenceFlags_MAX                   = 3

};


// Enum  /Script/MovieScene.EUpdateClockSource
enum class EUpdateClockSource : uint8_t
{
    Tick                                           = 0,
    Platform                                       = 1,
    Audio                                          = 2,
    RelativeTimecode                               = 3,
    Timecode                                       = 4,
    Custom                                         = 5,
    EUpdateClockSource_MAX                         = 6

};


// Enum  /Script/MovieScene.EMovieSceneEvaluationType
enum class EMovieSceneEvaluationType : uint8_t
{
    FrameLocked                                    = 0,
    WithSubFrames                                  = 1,
    EMovieSceneEvaluationType_MAX                  = 2

};


// Enum  /Script/MovieScene.EMovieScenePlayerStatus
enum class EMovieScenePlayerStatus : uint8_t
{
    Stopped                                        = 0,
    Playing                                        = 1,
    Recording                                      = 2,
    Scrubbing                                      = 3,
    Jumping                                        = 4,
    Stepping                                       = 5,
    Paused                                         = 6,
    MAX                                            = 7

};


// Enum  /Script/MovieScene.EMovieSceneObjectBindingSpace
enum class EMovieSceneObjectBindingSpace : uint8_t
{
    Local                                          = 0,
    Root                                           = 1,
    EMovieSceneObjectBindingSpace_MAX              = 2

};


// Enum  /Script/MovieScene.ESectionEvaluationFlags
enum class ESectionEvaluationFlags : uint8_t
{
    None                                           = 0,
    PreRoll                                        = 1,
    PostRoll                                       = 2,
    ESectionEvaluationFlags_MAX                    = 3

};


// Enum  /Script/MovieScene.EMovieScenePositionType
enum class EMovieScenePositionType : uint8_t
{
    Frame                                          = 0,
    Time                                           = 1,
    MarkedFrame                                    = 2,
    EMovieScenePositionType_MAX                    = 3

};


// Enum  /Script/MovieScene.EUpdatePositionMethod
enum class EUpdatePositionMethod : uint8_t
{
    Play                                           = 0,
    Jump                                           = 1,
    Scrub                                          = 2,
    EUpdatePositionMethod_MAX                      = 3

};


// Enum  /Script/MovieScene.ESpawnOwnership
enum class ESpawnOwnership : uint8_t
{
    InnerSequence                                  = 0,
    MasterSequence                                 = 1,
    External                                       = 2,
    ESpawnOwnership_MAX                            = 3

};


// Enum  /Script/AnimationCore.ETransformConstraintType
enum class ETransformConstraintType : uint8_t
{
    Translation                                    = 0,
    Rotation                                       = 1,
    Scale                                          = 2,
    Parent                                         = 3,
    ETransformConstraintType_MAX                   = 4

};


// Enum  /Script/AnimationCore.EConstraintType
enum class EConstraintType : uint8_t
{
    Transform                                      = 0,
    Aim                                            = 1,
    MAX                                            = 2

};


// Enum  /Script/AnimGraphRuntime.ESphericalLimitType
enum class ESphericalLimitType : uint8_t
{
    Inner                                          = 0,
    Outer                                          = 1,
    ESphericalLimitType_MAX                        = 2

};


// Enum  /Script/AnimGraphRuntime.AnimPhysSimSpaceType
enum class AnimPhysSimSpaceType : uint8_t
{
    Component                                      = 0,
    Actor                                          = 1,
    World                                          = 2,
    RootRelative                                   = 3,
    BoneRelative                                   = 4,
    AnimPhysSimSpaceType_MAX                       = 5

};


// Enum  /Script/AnimGraphRuntime.AnimPhysLinearConstraintType
enum class AnimPhysLinearConstraintType : uint8_t
{
    Free                                           = 0,
    Limited                                        = 1,
    AnimPhysLinearConstraintType_MAX               = 2

};


// Enum  /Script/AnimGraphRuntime.AnimPhysAngularConstraintType
enum class AnimPhysAngularConstraintType : uint8_t
{
    Angular                                        = 0,
    Cone                                           = 1,
    AnimPhysAngularConstraintType_MAX              = 2

};


// Enum  /Script/AnimGraphRuntime.EBlendListTransitionType
enum class EBlendListTransitionType : uint8_t
{
    StandardBlend                                  = 0,
    Inertialization                                = 1,
    EBlendListTransitionType_MAX                   = 2

};


// Enum  /Script/AnimGraphRuntime.EDrivenDestinationMode
enum class EDrivenDestinationMode : uint8_t
{
    Bone                                           = 0,
    MorphTarget                                    = 1,
    MaterialParameter                              = 2,
    EDrivenDestinationMode_MAX                     = 3

};


// Enum  /Script/AnimGraphRuntime.EDrivenBoneModificationMode
enum class EDrivenBoneModificationMode : uint8_t
{
    AddToInput                                     = 0,
    ReplaceComponent                               = 1,
    AddToRefPose                                   = 2,
    EDrivenBoneModificationMode_MAX                = 3

};


// Enum  /Script/AnimGraphRuntime.EConstraintOffsetOption
enum class EConstraintOffsetOption : uint8_t
{
    None                                           = 0,
    Offset_RefPose                                 = 1,
    EConstraintOffsetOption_MAX                    = 2

};


// Enum  /Script/AnimGraphRuntime.CopyBoneDeltaMode
enum class CopyBoneDeltaMode : uint8_t
{
    Accumulate                                     = 0,
    Copy                                           = 1,
    CopyBoneDeltaMode_MAX                          = 2

};


// Enum  /Script/AnimGraphRuntime.EInterpolationBlend
enum class EInterpolationBlend : uint8_t
{
    Linear                                         = 0,
    Cubic                                          = 1,
    Sinusoidal                                     = 2,
    EaseInOutExponent2                             = 3,
    EaseInOutExponent3                             = 4,
    EaseInOutExponent4                             = 5,
    EaseInOutExponent5                             = 6,
    MAX                                            = 7

};


// Enum  /Script/AnimGraphRuntime.EBoneModificationMode
enum class EBoneModificationMode : uint8_t
{
    BMM_Ignore                                     = 0,
    BMM_Replace                                    = 1,
    BMM_Additive                                   = 2,
    BMM_MAX                                        = 3

};


// Enum  /Script/AnimGraphRuntime.EModifyCurveApplyMode
enum class EModifyCurveApplyMode : uint8_t
{
    Add                                            = 0,
    Scale                                          = 1,
    Blend                                          = 2,
    WeightedMovingAverage                          = 3,
    RemapCurve                                     = 4,
    EModifyCurveApplyMode_MAX                      = 5

};


// Enum  /Script/AnimGraphRuntime.EPoseDriverOutput
enum class EPoseDriverOutput : uint8_t
{
    DrivePoses                                     = 0,
    DriveCurves                                    = 1,
    EPoseDriverOutput_MAX                          = 2

};


// Enum  /Script/AnimGraphRuntime.EPoseDriverSource
enum class EPoseDriverSource : uint8_t
{
    Rotation                                       = 0,
    Translation                                    = 1,
    EPoseDriverSource_MAX                          = 2

};


// Enum  /Script/AnimGraphRuntime.EPoseDriverType
enum class EPoseDriverType : uint8_t
{
    SwingAndTwist                                  = 0,
    SwingOnly                                      = 1,
    Translation                                    = 2,
    EPoseDriverType_MAX                            = 3

};


// Enum  /Script/AnimGraphRuntime.ESnapshotSourceMode
enum class ESnapshotSourceMode : uint8_t
{
    NamedSnapshot                                  = 0,
    SnapshotPin                                    = 1,
    ESnapshotSourceMode_MAX                        = 2

};


// Enum  /Script/AnimGraphRuntime.ERefPoseType
enum class ERefPoseType : uint8_t
{
    EIT_LocalSpace                                 = 0,
    EIT_Additive                                   = 1,
    EIT_MAX                                        = 2

};


// Enum  /Script/AnimGraphRuntime.ESimulationSpace
enum class ESimulationSpace : uint8_t
{
    ComponentSpace                                 = 0,
    WorldSpace                                     = 1,
    BaseBoneSpace                                  = 2,
    ESimulationSpace_MAX                           = 3

};


// Enum  /Script/AnimGraphRuntime.EScaleChainInitialLength
enum class EScaleChainInitialLength : uint8_t
{
    FixedDefaultLengthValue                        = 0,
    Distance                                       = 1,
    ChainLength                                    = 2,
    EScaleChainInitialLength_MAX                   = 3

};


// Enum  /Script/AnimGraphRuntime.ESequenceEvalReinit
enum class ESequenceEvalReinit : uint8_t
{
    NoReset                                        = 0,
    StartPosition                                  = 1,
    ExplicitTime                                   = 2,
    ESequenceEvalReinit_MAX                        = 3

};


// Enum  /Script/AnimGraphRuntime.ESplineBoneAxis
enum class ESplineBoneAxis : uint8_t
{
    None                                           = 0,
    X                                              = 1,
    Y                                              = 2,
    Z                                              = 3,
    ESplineBoneAxis_MAX                            = 4

};


// Enum  /Script/AnimGraphRuntime.ERotationComponent
enum class ERotationComponent : uint8_t
{
    EulerX                                         = 0,
    EulerY                                         = 1,
    EulerZ                                         = 2,
    QuaternionAngle                                = 3,
    SwingAngle                                     = 4,
    TwistAngle                                     = 5,
    ERotationComponent_MAX                         = 6

};


// Enum  /Script/AnimGraphRuntime.EEasingFuncType
enum class EEasingFuncType : uint8_t
{
    Linear                                         = 0,
    Sinusoidal                                     = 1,
    Cubic                                          = 2,
    QuadraticInOut                                 = 3,
    CubicInOut                                     = 4,
    HermiteCubic                                   = 5,
    QuarticInOut                                   = 6,
    QuinticInOut                                   = 7,
    CircularIn                                     = 8,
    CircularOut                                    = 9,
    CircularInOut                                  = 10,
    ExpIn                                          = 11,
    ExpOut                                         = 12,
    ExpInOut                                       = 13,
    CustomCurve                                    = 14,
    EEasingFuncType_MAX                            = 15

};


// Enum  /Script/AnimGraphRuntime.ERBFNormalizeMethod
enum class ERBFNormalizeMethod : uint8_t
{
    OnlyNormalizeAboveOne                          = 0,
    AlwaysNormalize                                = 1,
    NormalizeWithinMedian                          = 2,
    NoNormalization                                = 3,
    ERBFNormalizeMethod_MAX                        = 4

};


// Enum  /Script/AnimGraphRuntime.ERBFDistanceMethod
enum class ERBFDistanceMethod : uint8_t
{
    Euclidean                                      = 0,
    Quaternion                                     = 1,
    SwingAngle                                     = 2,
    TwistAngle                                     = 3,
    DefaultMethod                                  = 4,
    ERBFDistanceMethod_MAX                         = 5

};


// Enum  /Script/AnimGraphRuntime.ERBFFunctionType
enum class ERBFFunctionType : uint8_t
{
    Gaussian                                       = 0,
    Exponential                                    = 1,
    Linear                                         = 2,
    Cubic                                          = 3,
    Quintic                                        = 4,
    DefaultFunction                                = 5,
    ERBFFunctionType_MAX                           = 6

};


// Enum  /Script/AnimGraphRuntime.ERBFSolverType
enum class ERBFSolverType : uint8_t
{
    Additive                                       = 0,
    Interpolative                                  = 1,
    ERBFSolverType_MAX                             = 2

};


// Enum  /Script/MovieSceneTracks.MovieScene3DPathSection_Axis
enum class MovieScene3DPathSection_Axis : uint8_t
{
    X                                              = 0,
    Y                                              = 1,
    Z                                              = 2,
    NEG_X                                          = 3,
    NEG_Y                                          = 4,
    NEG_Z                                          = 5,
    MovieScene3DPathSection_MAX                    = 6

};


// Enum  /Script/MovieSceneTracks.EFireEventsAtPosition
enum class EFireEventsAtPosition : uint8_t
{
    AtStartOfEvaluation                            = 0,
    AtEndOfEvaluation                              = 1,
    AfterSpawn                                     = 2,
    EFireEventsAtPosition_MAX                      = 3

};


// Enum  /Script/MovieSceneTracks.ELevelVisibility
enum class ELevelVisibility : uint8_t
{
    Visible                                        = 0,
    Hidden                                         = 1,
    ELevelVisibility_MAX                           = 2

};


// Enum  /Script/MovieSceneTracks.EParticleKey
enum class EParticleKey : uint8_t
{
    Activate                                       = 0,
    Deactivate                                     = 1,
    Trigger                                        = 2,
    EParticleKey_MAX                               = 3

};


// Enum  /Script/UMG.EDragPivot
enum class EDragPivot : uint8_t
{
    MouseDown                                      = 0,
    TopLeft                                        = 1,
    TopCenter                                      = 2,
    TopRight                                       = 3,
    CenterLeft                                     = 4,
    CenterCenter                                   = 5,
    CenterRight                                    = 6,
    BottomLeft                                     = 7,
    BottomCenter                                   = 8,
    BottomRight                                    = 9,
    EDragPivot_MAX                                 = 10

};


// Enum  /Script/UMG.EDynamicBoxType
enum class EDynamicBoxType : uint8_t
{
    Horizontal                                     = 0,
    Vertical                                       = 1,
    Wrap                                           = 2,
    VerticalWrap                                   = 3,
    Radial                                         = 4,
    Overlay                                        = 5,
    EDynamicBoxType_MAX                            = 6

};


// Enum  /Script/UMG.ESlateSizeRule
enum class ESlateSizeRule : uint8_t
{
    Automatic                                      = 0,
    Fill                                           = 1,
    ESlateSizeRule_MAX                             = 2

};


// Enum  /Script/UMG.EVisiblityScope
enum class EVisiblityScope : uint8_t
{
    OnlyOversea                                    = 0,
    OnlyCN                                         = 1,
    OverseaAndCN                                   = 2,
    EVisiblityScope_MAX                            = 3

};


// Enum  /Script/UMG.ELocalizationFeature
enum class ELocalizationFeature : uint8_t
{
    None                                           = 0,
    AllOversea                                     = 1,
    English                                        = 2,
    ELocalizationFeature_MAX                       = 3

};


// Enum  /Script/UMG.EUMGSequencePlayMode
enum class EUMGSequencePlayMode : uint8_t
{
    Forward                                        = 0,
    Reverse                                        = 1,
    PingPong                                       = 2,
    EUMGSequencePlayMode_MAX                       = 3

};


// Enum  /Script/UMG.EWidgetAnimationEvent
enum class EWidgetAnimationEvent : uint8_t
{
    Started                                        = 0,
    Finished                                       = 1,
    EWidgetAnimationEvent_MAX                      = 2

};


// Enum  /Script/UMG.EWidgetTickFrequency
enum class EWidgetTickFrequency : uint8_t
{
    Never                                          = 0,
    Auto                                           = 1,
    EWidgetTickFrequency_MAX                       = 2

};


// Enum  /Script/UMG.EWidgetDesignFlags
enum class EWidgetDesignFlags : uint8_t
{
    None                                           = 0,
    Designing                                      = 1,
    ShowOutline                                    = 2,
    ExecutePreConstruct                            = 4,
    EWidgetDesignFlags_MAX                         = 5

};


// Enum  /Script/UMG.EBindingKind
enum class EBindingKind : uint8_t
{
    Function                                       = 0,
    Property                                       = 1,
    EBindingKind_MAX                               = 2

};


// Enum  /Script/UMG.ETickMode
enum class ETickMode : uint8_t
{
    Disabled                                       = 0,
    Enabled                                        = 1,
    Automatic                                      = 2,
    ETickMode_MAX                                  = 3

};


// Enum  /Script/UMG.EWindowVisibility
enum class EWindowVisibility : uint8_t
{
    Visible                                        = 0,
    SelfHitTestInvisible                           = 1,
    EWindowVisibility_MAX                          = 2

};


// Enum  /Script/UMG.EWidgetGeometryMode
enum class EWidgetGeometryMode : uint8_t
{
    Plane                                          = 0,
    Cylinder                                       = 1,
    EWidgetGeometryMode_MAX                        = 2

};


// Enum  /Script/UMG.EWidgetBlendMode
enum class EWidgetBlendMode : uint8_t
{
    Opaque                                         = 0,
    Masked                                         = 1,
    Transparent                                    = 2,
    EWidgetBlendMode_MAX                           = 3

};


// Enum  /Script/UMG.EWidgetTimingPolicy
enum class EWidgetTimingPolicy : uint8_t
{
    RealTime                                       = 0,
    GameTime                                       = 1,
    EWidgetTimingPolicy_MAX                        = 2

};


// Enum  /Script/UMG.EWidgetSpace
enum class EWidgetSpace : uint8_t
{
    World                                          = 0,
    Screen                                         = 1,
    EWidgetSpace_MAX                               = 2

};


// Enum  /Script/UMG.EWidgetInteractionSource
enum class EWidgetInteractionSource : uint8_t
{
    World                                          = 0,
    Mouse                                          = 1,
    CenterScreen                                   = 2,
    Custom                                         = 3,
    EWidgetInteractionSource_MAX                   = 4

};


// Enum  /Script/CinematicCamera.ECameraFocusMethod
enum class ECameraFocusMethod : uint8_t
{
    DoNotOverride                                  = 0,
    Manual                                         = 1,
    Tracking                                       = 2,
    Disable                                        = 3,
    MAX                                            = 4

};


// Enum  /Script/AudioPlatformConfiguration.ESoundwaveSampleRateSettings
enum class ESoundwaveSampleRateSettings : uint8_t
{
    Max                                            = 0,
    High                                           = 1,
    Medium                                         = 2,
    Low                                            = 3,
    Min                                            = 4,
    MatchDevice                                    = 5

};


// Enum  /Script/AudioMixer.EMusicalNoteName
enum class EMusicalNoteName : uint8_t
{
    C                                              = 0,
    Db                                             = 1,
    D                                              = 2,
    Eb                                             = 3,
    E                                              = 4,
    F                                              = 5,
    Gb                                             = 6,
    G                                              = 7,
    Ab                                             = 8,
    A                                              = 9,
    Bb                                             = 10,
    B                                              = 11,
    EMusicalNoteName_MAX                           = 12

};


// Enum  /Script/AudioMixer.ESubmixEffectDynamicsChannelLinkMode
enum class ESubmixEffectDynamicsChannelLinkMode : uint8_t
{
    Disabled                                       = 0,
    Average                                        = 1,
    Peak                                           = 2,
    Count                                          = 3,
    ESubmixEffectDynamicsChannelLinkMode_MAX       = 4

};


// Enum  /Script/AudioMixer.ESubmixEffectDynamicsPeakMode
enum class ESubmixEffectDynamicsPeakMode : uint8_t
{
    MeanSquared                                    = 0,
    RootMeanSquared                                = 1,
    Peak                                           = 2,
    Count                                          = 3,
    ESubmixEffectDynamicsPeakMode_MAX              = 4

};


// Enum  /Script/AudioMixer.ESubmixEffectDynamicsProcessorType
enum class ESubmixEffectDynamicsProcessorType : uint8_t
{
    Compressor                                     = 0,
    Limiter                                        = 1,
    Expander                                       = 2,
    Gate                                           = 3,
    Count                                          = 4,
    ESubmixEffectDynamicsProcessorType_MAX         = 5

};


// Enum  /Script/GameplayTags.EGameplayTagQueryExprType
enum class EGameplayTagQueryExprType : uint8_t
{
    Undefined                                      = 0,
    AnyTagsMatch                                   = 1,
    AllTagsMatch                                   = 2,
    NoTagsMatch                                    = 3,
    AnyExprMatch                                   = 4,
    AllExprMatch                                   = 5,
    NoExprMatch                                    = 6,
    EGameplayTagQueryExprType_MAX                  = 7

};


// Enum  /Script/GameplayTags.EGameplayContainerMatchType
enum class EGameplayContainerMatchType : uint8_t
{
    Any                                            = 0,
    All                                            = 1,
    EGameplayContainerMatchType_MAX                = 2

};


// Enum  /Script/GameplayTags.EGameplayTagMatchType
enum class EGameplayTagMatchType : uint8_t
{
    Explicit                                       = 0,
    IncludeParentTags                              = 1,
    EGameplayTagMatchType_MAX                      = 2

};


// Enum  /Script/GameplayTags.EGameplayTagSelectionType
enum class EGameplayTagSelectionType : uint8_t
{
    None                                           = 0,
    NonRestrictedOnly                              = 1,
    RestrictedOnly                                 = 2,
    All                                            = 3,
    EGameplayTagSelectionType_MAX                  = 4

};


// Enum  /Script/GameplayTags.EGameplayTagSourceType
enum class EGameplayTagSourceType : uint8_t
{
    Native                                         = 0,
    DefaultTagList                                 = 1,
    TagList                                        = 2,
    RestrictedTagList                              = 3,
    DataTable                                      = 4,
    Invalid                                        = 5,
    EGameplayTagSourceType_MAX                     = 6

};


// Enum  /Script/MeshDescription.EComputeNTBsOptions
enum class EComputeNTBsOptions : uint8_t
{
    None                                           = 0,
    Normals                                        = 1,
    Tangents                                       = 2,
    WeightedNTBs                                   = 4,
    EComputeNTBsOptions_MAX                        = 5

};


// Enum  /Script/PropertyAccess.EPropertyAccessCopyBatch
enum class EPropertyAccessCopyBatch : uint8_t
{
    InternalUnbatched                              = 0,
    ExternalUnbatched                              = 1,
    InternalBatched                                = 2,
    ExternalBatched                                = 3,
    Count                                          = 4,
    EPropertyAccessCopyBatch_MAX                   = 5

};


// Enum  /Script/PropertyAccess.EPropertyAccessCopyType
enum class EPropertyAccessCopyType : uint8_t
{
    None                                           = 0,
    Plain                                          = 1,
    Complex                                        = 2,
    Bool                                           = 3,
    Struct                                         = 4,
    Object                                         = 5,
    Name                                           = 6,
    Array                                          = 7,
    PromoteBoolToByte                              = 8,
    PromoteBoolToInt32                             = 9,
    PromoteBoolToInt64                             = 10,
    PromoteBoolToFloat                             = 11,
    PromoteByteToInt32                             = 12,
    PromoteByteToInt64                             = 13,
    PromoteByteToFloat                             = 14,
    PromoteInt32ToInt64                            = 15,
    PromoteInt32ToFloat                            = 16,
    EPropertyAccessCopyType_MAX                    = 17

};


// Enum  /Script/PropertyAccess.EPropertyAccessObjectType
enum class EPropertyAccessObjectType : uint8_t
{
    None                                           = 0,
    Object                                         = 1,
    WeakObject                                     = 2,
    SoftObject                                     = 3,
    EPropertyAccessObjectType_MAX                  = 4

};


// Enum  /Script/PropertyAccess.EPropertyAccessIndirectionType
enum class EPropertyAccessIndirectionType : uint8_t
{
    Offset                                         = 0,
    Object                                         = 1,
    Array                                          = 2,
    ScriptFunction                                 = 3,
    NativeFunction                                 = 4,
    EPropertyAccessIndirectionType_MAX             = 5

};


// Enum  /Script/PortalServices.EEntitlementCacheLevelRetrieved
enum class EEntitlementCacheLevelRetrieved : uint8_t
{
    None                                           = 0,
    Memory                                         = 1,
    Disk                                           = 2,
    EEntitlementCacheLevelRetrieved_MAX            = 3

};


// Enum  /Script/PortalServices.EEntitlementCacheLevelRequest
enum class EEntitlementCacheLevelRequest : uint8_t
{
    Memory                                         = 1,
    Disk                                           = 2,
    EEntitlementCacheLevelRequest_MAX              = 3

};


// Enum  /Script/EyeTracker.EEyeTrackerStatus
enum class EEyeTrackerStatus : uint8_t
{
    NotConnected                                   = 0,
    NotTracking                                    = 1,
    Tracking                                       = 2,
    EEyeTrackerStatus_MAX                          = 3

};


// Enum  /Script/MediaUtils.EMediaPlayerOptionBooleanOverride
enum class EMediaPlayerOptionBooleanOverride : uint8_t
{
    UseMediaPlayerSetting                          = 0,
    Enabled                                        = 1,
    Disabled                                       = 2,
    EMediaPlayerOptionBooleanOverride_MAX          = 3

};


// Enum  /Script/MediaAssets.EMediaWebcamCaptureDeviceFilter
enum class EMediaWebcamCaptureDeviceFilter : uint8_t
{
    None                                           = 0,
    DepthSensor                                    = 1,
    Front                                          = 2,
    Rear                                           = 4,
    Unknown                                        = 8,
    EMediaWebcamCaptureDeviceFilter_MAX            = 9

};


// Enum  /Script/MediaAssets.EMediaVideoCaptureDeviceFilter
enum class EMediaVideoCaptureDeviceFilter : uint8_t
{
    None                                           = 0,
    Card                                           = 1,
    Software                                       = 2,
    Unknown                                        = 4,
    Webcam                                         = 8,
    EMediaVideoCaptureDeviceFilter_MAX             = 9

};


// Enum  /Script/MediaAssets.EMediaAudioCaptureDeviceFilter
enum class EMediaAudioCaptureDeviceFilter : uint8_t
{
    None                                           = 0,
    Card                                           = 1,
    Microphone                                     = 2,
    Software                                       = 4,
    Unknown                                        = 8,
    EMediaAudioCaptureDeviceFilter_MAX             = 9

};


// Enum  /Script/MediaAssets.EPauseAtStartState
enum class EPauseAtStartState : uint8_t
{
    None                                           = 0,
    WaitSeekComplete                               = 1,
    WaitSampleChange                               = 2,
    EPauseAtStartState_MAX                         = 3

};


// Enum  /Script/MediaAssets.EMediaPlayerTrack
enum class EMediaPlayerTrack : uint8_t
{
    Audio                                          = 0,
    Caption                                        = 1,
    Metadata                                       = 2,
    Script                                         = 3,
    Subtitle                                       = 4,
    Text                                           = 5,
    Video                                          = 6,
    EMediaPlayerTrack_MAX                          = 7

};


// Enum  /Script/MediaAssets.EMediaSoundComponentFFTSize
enum class EMediaSoundComponentFFTSize : uint8_t
{
    Min                                            = 0,
    Small                                          = 1,
    Medium                                         = 2,
    Large                                          = 3,
    EMediaSoundComponentFFTSize_MAX                = 4

};


// Enum  /Script/MediaAssets.EMediaSoundChannels
enum class EMediaSoundChannels : uint8_t
{
    Mono                                           = 0,
    Stereo                                         = 1,
    Surround                                       = 2,
    EMediaSoundChannels_MAX                        = 3

};


// Enum  /Script/MediaAssets.MediaTextureOrientation
enum class MediaTextureOrientation : uint8_t
{
    MTORI_Original                                 = 0,
    MTORI_CW90                                     = 1,
    MTORI_CW180                                    = 2,
    MTORI_CW270                                    = 3,
    MTORI_MAX                                      = 4

};


// Enum  /Script/MediaAssets.MediaTextureOutputFormat
enum class MediaTextureOutputFormat : uint8_t
{
    MTOF_Default                                   = 0,
    MTOF_SRGB_LINOUT                               = 1,
    MTOF_MAX                                       = 2

};


// Enum  /Script/MovieSceneCapture.EHDRCaptureGamut
enum class EHDRCaptureGamut : uint8_t
{
    HCGM_Rec709                                    = 0,
    HCGM_P3DCI                                     = 1,
    HCGM_Rec2020                                   = 2,
    HCGM_ACES                                      = 3,
    HCGM_ACEScg                                    = 4,
    HCGM_Linear                                    = 5,
    HCGM_MAX                                       = 6

};


// Enum  /Script/MovieSceneCapture.EMovieSceneCaptureProtocolState
enum class EMovieSceneCaptureProtocolState : uint8_t
{
    Idle                                           = 0,
    Initialized                                    = 1,
    Capturing                                      = 2,
    Finalizing                                     = 3,
    EMovieSceneCaptureProtocolState_MAX            = 4

};


// Enum  /Script/MoviePlayer.EMoviePlaybackType
enum class EMoviePlaybackType : uint8_t
{
    MT_Normal                                      = 0,
    MT_Looped                                      = 1,
    MT_LoadingLoop                                 = 2,
    MT_MAX                                         = 3

};


// Enum  /Script/Engine.ETickExecuteScriptOnActorStatus
enum class ETickExecuteScriptOnActorStatus : uint8_t
{
    PreSpawning                                    = 0,
    DuringSpawning                                 = 1,
    PostSpawning                                   = 2,
    FinishSpawning                                 = 3,
    ETickExecuteScriptOnActorStatus_MAX            = 4

};


// Enum  /Script/Engine.ETickFinishSpawningStatus
enum class ETickFinishSpawningStatus : uint8_t
{
    PreSpawning                                    = 0,
    DuringSpawning                                 = 1,
    PostSpawning                                   = 2,
    FinishSpawning                                 = 3,
    ETickFinishSpawningStatus_MAX                  = 4

};


// Enum  /Script/Engine.EAlphaBlendOption
enum class EAlphaBlendOption : uint8_t
{
    Linear                                         = 0,
    Cubic                                          = 1,
    HermiteCubic                                   = 2,
    Sinusoidal                                     = 3,
    QuadraticInOut                                 = 4,
    CubicInOut                                     = 5,
    QuarticInOut                                   = 6,
    QuinticInOut                                   = 7,
    CircularIn                                     = 8,
    CircularOut                                    = 9,
    CircularInOut                                  = 10,
    ExpIn                                          = 11,
    ExpOut                                         = 12,
    ExpInOut                                       = 13,
    Custom                                         = 14,
    EAlphaBlendOption_MAX                          = 15

};


// Enum  /Script/Engine.EAnimSyncGroupScope
enum class EAnimSyncGroupScope : uint8_t
{
    Local                                          = 0,
    Component                                      = 1,
    EAnimSyncGroupScope_MAX                        = 2

};


// Enum  /Script/Engine.EAnimGroupRole
enum class EAnimGroupRole : uint8_t
{
    CanBeLeader                                    = 0,
    AlwaysFollower                                 = 1,
    AlwaysLeader                                   = 2,
    TransitionLeader                               = 3,
    TransitionFollower                             = 4,
    EAnimGroupRole_MAX                             = 5

};


// Enum  /Script/Engine.EPreviewAnimationBlueprintApplicationMethod
enum class EPreviewAnimationBlueprintApplicationMethod : uint8_t
{
    LinkedLayers                                   = 0,
    LinkedAnimGraph                                = 1,
    EPreviewAnimationBlueprintApplicationMethod_MAX = 2

};


// Enum  /Script/Engine.AnimationKeyFormat
enum class AnimationKeyFormat : uint8_t
{
    AKF_ConstantKeyLerp                            = 0,
    AKF_VariableKeyLerp                            = 1,
    AKF_PerTrackCompression                        = 2,
    AKF_MAX                                        = 3

};


// Enum  /Script/Engine.ERawCurveTrackTypes
enum class ERawCurveTrackTypes : uint8_t
{
    RCT_Float                                      = 0,
    RCT_Vector                                     = 1,
    RCT_Transform                                  = 2,
    RCT_MAX                                        = 3

};


// Enum  /Script/Engine.EAnimAssetCurveFlags
enum class EAnimAssetCurveFlags : uint8_t
{
    AACF_NONE                                      = 0,
    AACF_DriveMorphTarget_DEPRECATED               = 1,
    AACF_DriveAttribute_DEPRECATED                 = 2,
    AACF_Editable                                  = 4,
    AACF_DriveMaterial_DEPRECATED                  = 8,
    AACF_Metadata                                  = 16,
    AACF_DriveTrack                                = 32,
    AACF_Disabled                                  = 64,
    AACF_MAX                                       = 65

};


// Enum  /Script/Engine.AnimationCompressionFormat
enum class AnimationCompressionFormat : uint8_t
{
    ACF_None                                       = 0,
    ACF_Float96NoW                                 = 1,
    ACF_Fixed48NoW                                 = 2,
    ACF_IntervalFixed32NoW                         = 3,
    ACF_Fixed32NoW                                 = 4,
    ACF_Float32NoW                                 = 5,
    ACF_Identity                                   = 6,
    ACF_MAX                                        = 7

};


// Enum  /Script/Engine.EAdditiveBasePoseType
enum class EAdditiveBasePoseType : uint8_t
{
    ABPT_None                                      = 0,
    ABPT_RefPose                                   = 1,
    ABPT_AnimScaled                                = 2,
    ABPT_AnimFrame                                 = 3,
    ABPT_MAX                                       = 4

};


// Enum  /Script/Engine.ERootMotionMode
enum class ERootMotionMode : uint8_t
{
    NoRootMotionExtraction                         = 0,
    IgnoreRootMotion                               = 1,
    RootMotionFromEverything                       = 2,
    RootMotionFromMontagesOnly                     = 3,
    ERootMotionMode_MAX                            = 4

};


// Enum  /Script/Engine.ERootMotionRootLock
enum class ERootMotionRootLock : uint8_t
{
    RefPose                                        = 0,
    AnimFirstFrame                                 = 1,
    Zero                                           = 2,
    ERootMotionRootLock_MAX                        = 3

};


// Enum  /Script/Engine.EAnimExecutionContextConversionResult
enum class EAnimExecutionContextConversionResult : uint8_t
{
    Succeeded                                      = 1,
    Failed                                         = 0,
    EAnimExecutionContextConversionResult_MAX      = 2

};


// Enum  /Script/Engine.EMontagePlayReturnType
enum class EMontagePlayReturnType : uint8_t
{
    MontageLength                                  = 0,
    Duration                                       = 1,
    EMontagePlayReturnType_MAX                     = 2

};


// Enum  /Script/Engine.EDrawDebugItemType
enum class EDrawDebugItemType : uint8_t
{
    DirectionalArrow                               = 0,
    Sphere                                         = 1,
    Line                                           = 2,
    OnScreenMessage                                = 3,
    CoordinateSystem                               = 4,
    EDrawDebugItemType_MAX                         = 5

};


// Enum  /Script/Engine.EAnimLinkMethod
enum class EAnimLinkMethod : uint8_t
{
    Absolute                                       = 0,
    Relative                                       = 1,
    Proportional                                   = 2,
    EAnimLinkMethod_MAX                            = 3

};


// Enum  /Script/Engine.EMontageSubStepResult
enum class EMontageSubStepResult : uint8_t
{
    Moved                                          = 0,
    NotMoved                                       = 1,
    InvalidSection                                 = 2,
    InvalidMontage                                 = 3,
    EMontageSubStepResult_MAX                      = 4

};


// Enum  /Script/Engine.EAnimNotifyEventType
enum class EAnimNotifyEventType : uint8_t
{
    Begin                                          = 0,
    End                                            = 1,
    EAnimNotifyEventType_MAX                       = 2

};


// Enum  /Script/Engine.EInertializationSpace
enum class EInertializationSpace : uint8_t
{
    Default                                        = 0,
    WorldSpace                                     = 1,
    WorldRotation                                  = 2,
    EInertializationSpace_MAX                      = 3

};


// Enum  /Script/Engine.EInertializationBoneState
enum class EInertializationBoneState : uint8_t
{
    Invalid                                        = 0,
    Valid                                          = 1,
    Excluded                                       = 2,
    EInertializationBoneState_MAX                  = 3

};


// Enum  /Script/Engine.EInertializationState
enum class EInertializationState : uint8_t
{
    Inactive                                       = 0,
    Pending                                        = 1,
    Active                                         = 2,
    EInertializationState_MAX                      = 3

};


// Enum  /Script/Engine.EEvaluatorMode
enum class EEvaluatorMode : uint8_t
{
    EM_Standard                                    = 0,
    EM_Freeze                                      = 1,
    EM_DelayedFreeze                               = 2,
    EM_MAX                                         = 3

};


// Enum  /Script/Engine.EEvaluatorDataSource
enum class EEvaluatorDataSource : uint8_t
{
    EDS_SourcePose                                 = 0,
    EDS_DestinationPose                            = 1,
    EDS_MAX                                        = 2

};


// Enum  /Script/Engine.EPostCopyOperation
enum class EPostCopyOperation : uint8_t
{
    None                                           = 0,
    LogicalNegateBool                              = 1,
    EPostCopyOperation_MAX                         = 2

};


// Enum  /Script/Engine.EPinHidingMode
enum class EPinHidingMode : uint8_t
{
    NeverAsPin                                     = 0,
    PinHiddenByDefault                             = 1,
    PinShownByDefault                              = 2,
    AlwaysAsPin                                    = 3,
    EPinHidingMode_MAX                             = 4

};


// Enum  /Script/Engine.AnimPhysCollisionType
enum class AnimPhysCollisionType : uint8_t
{
    CoM                                            = 0,
    CustomSphere                                   = 1,
    InnerSphere                                    = 2,
    OuterSphere                                    = 3,
    AnimPhysCollisionType_MAX                      = 4

};


// Enum  /Script/Engine.AnimPhysTwistAxis
enum class AnimPhysTwistAxis : uint8_t
{
    AxisX                                          = 0,
    AxisY                                          = 1,
    AxisZ                                          = 2,
    AnimPhysTwistAxis_MAX                          = 3

};


// Enum  /Script/Engine.ETypeAdvanceAnim
enum class ETypeAdvanceAnim : uint8_t
{
    ETAA_Default                                   = 0,
    ETAA_Finished                                  = 1,
    ETAA_Looped                                    = 2,
    ETAA_MAX                                       = 3

};


// Enum  /Script/Engine.ETransitionLogicType
enum class ETransitionLogicType : uint8_t
{
    TLT_StandardBlend                              = 0,
    TLT_Inertialization                            = 1,
    TLT_Custom                                     = 2,
    TLT_MAX                                        = 3

};


// Enum  /Script/Engine.ETransitionBlendMode
enum class ETransitionBlendMode : uint8_t
{
    TBM_Linear                                     = 0,
    TBM_Cubic                                      = 1,
    TBM_MAX                                        = 2

};


// Enum  /Script/Engine.EComponentType
enum class EComponentType : uint8_t
{
    None                                           = 0,
    TranslationX                                   = 1,
    TranslationY                                   = 2,
    TranslationZ                                   = 3,
    RotationX                                      = 4,
    RotationY                                      = 5,
    RotationZ                                      = 6,
    Scale                                          = 7,
    ScaleX                                         = 8,
    ScaleY                                         = 9,
    ScaleZ                                         = 10,
    EComponentType_MAX                             = 11

};


// Enum  /Script/Engine.EAxisOption
enum class EAxisOption : uint8_t
{
    X                                              = 0,
    Y                                              = 1,
    Z                                              = 2,
    X_Neg                                          = 3,
    Y_Neg                                          = 4,
    Z_Neg                                          = 5,
    Custom                                         = 6,
    EAxisOption_MAX                                = 7

};


// Enum  /Script/Engine.EAnimInterpolationType
enum class EAnimInterpolationType : uint8_t
{
    Linear                                         = 0,
    Step                                           = 1,
    EAnimInterpolationType_MAX                     = 2

};


// Enum  /Script/Engine.ECurveBlendOption
enum class ECurveBlendOption : uint8_t
{
    Override                                       = 0,
    DoNotOverride                                  = 1,
    NormalizeByWeight                              = 2,
    BlendByWeight                                  = 3,
    UseBasePose                                    = 4,
    UseMaxValue                                    = 5,
    UseMinValue                                    = 6,
    UseCustomPoseIndex                             = 7,
    ECurveBlendOption_MAX                          = 8

};


// Enum  /Script/Engine.EAdditiveAnimationType
enum class EAdditiveAnimationType : uint8_t
{
    AAT_None                                       = 0,
    AAT_LocalSpaceBase                             = 1,
    AAT_RotationOffsetMeshSpace                    = 2,
    AAT_MAX                                        = 3

};


// Enum  /Script/Engine.ENotifyFilterType
enum class ENotifyFilterType : uint8_t
{
    NoFiltering                                    = 0,
    LOD                                            = 1,
    ENotifyFilterType_MAX                          = 2

};


// Enum  /Script/Engine.EMontageNotifyTickType
enum class EMontageNotifyTickType : uint8_t
{
    Queued                                         = 0,
    BranchingPoint                                 = 1,
    EMontageNotifyTickType_MAX                     = 2

};


// Enum  /Script/Engine.EBoneRotationSource
enum class EBoneRotationSource : uint8_t
{
    BRS_KeepComponentSpaceRotation                 = 0,
    BRS_KeepLocalSpaceRotation                     = 1,
    BRS_CopyFromTarget                             = 2,
    BRS_MAX                                        = 3

};


// Enum  /Script/Engine.EBoneControlSpace
enum class EBoneControlSpace : uint8_t
{
    BCS_WorldSpace                                 = 0,
    BCS_ComponentSpace                             = 1,
    BCS_ParentBoneSpace                            = 2,
    BCS_BoneSpace                                  = 3,
    BCS_MAX                                        = 4

};


// Enum  /Script/Engine.EBoneAxis
enum class EBoneAxis : uint8_t
{
    BA_X                                           = 0,
    BA_Y                                           = 1,
    BA_Z                                           = 2,
    BA_MAX                                         = 3

};


// Enum  /Script/Engine.EPrimaryAssetCookRule
enum class EPrimaryAssetCookRule : uint8_t
{
    Unknown                                        = 0,
    NeverCook                                      = 1,
    DevelopmentCook                                = 2,
    DevelopmentAlwaysCook                          = 3,
    AlwaysCook                                     = 4,
    EPrimaryAssetCookRule_MAX                      = 5

};


// Enum  /Script/Engine.ENaturalSoundFalloffMode
enum class ENaturalSoundFalloffMode : uint8_t
{
    Continues                                      = 0,
    Silent                                         = 1,
    Hold                                           = 2,
    ENaturalSoundFalloffMode_MAX                   = 3

};


// Enum  /Script/Engine.EAttenuationShape
enum class EAttenuationShape : uint8_t
{
    Sphere                                         = 0,
    Capsule                                        = 1,
    Box                                            = 2,
    Cone                                           = 3,
    EAttenuationShape_MAX                          = 4

};


// Enum  /Script/Engine.EAttenuationDistanceModel
enum class EAttenuationDistanceModel : uint8_t
{
    Linear                                         = 0,
    Logarithmic                                    = 1,
    Inverse                                        = 2,
    LogReverse                                     = 3,
    NaturalSound                                   = 4,
    Custom                                         = 5,
    EAttenuationDistanceModel_MAX                  = 6

};


// Enum  /Script/Engine.EAudioBusChannels
enum class EAudioBusChannels : uint8_t
{
    Mono                                           = 0,
    Stereo                                         = 1,
    EAudioBusChannels_MAX                          = 2

};


// Enum  /Script/Engine.EAudioFaderCurve
enum class EAudioFaderCurve : uint8_t
{
    Linear                                         = 0,
    Logarithmic                                    = 1,
    SCurve                                         = 2,
    Sin                                            = 3,
    Count                                          = 4,
    EAudioFaderCurve_MAX                           = 5

};


// Enum  /Script/Engine.EAudioOutputTarget
enum class EAudioOutputTarget : uint8_t
{
    Speaker                                        = 0,
    Controller                                     = 1,
    ControllerFallbackToSpeaker                    = 2,
    EAudioOutputTarget_MAX                         = 3

};


// Enum  /Script/Engine.EMonoChannelUpmixMethod
enum class EMonoChannelUpmixMethod : uint8_t
{
    Linear                                         = 0,
    EqualPower                                     = 1,
    FullVolume                                     = 2,
    EMonoChannelUpmixMethod_MAX                    = 3

};


// Enum  /Script/Engine.EPanningMethod
enum class EPanningMethod : uint8_t
{
    Linear                                         = 0,
    EqualPower                                     = 1,
    EPanningMethod_MAX                             = 2

};


// Enum  /Script/Engine.EVoiceSampleRate
enum class EVoiceSampleRate : uint32_t
{
    Low16000Hz                                     = 16000,
    Normal24000Hz                                  = 24000,
    EVoiceSampleRate_MAX                           = 24001

};


// Enum  /Script/Engine.EAudioVolumeLocationState
enum class EAudioVolumeLocationState : uint8_t
{
    InsideTheVolume                                = 0,
    OutsideTheVolume                               = 1,
    EAudioVolumeLocationState_MAX                  = 2

};


// Enum  /Script/Engine.EBlendableLocation
enum class EBlendableLocation : uint8_t
{
    BL_AfterTonemapping                            = 0,
    BL_BeforeTonemapping                           = 1,
    BL_BeforeTranslucency                          = 2,
    BL_ReplacingTonemapper                         = 3,
    BL_SSRInput                                    = 4,
    BL_MAX                                         = 5

};


// Enum  /Script/Engine.ENotifyTriggerMode
enum class ENotifyTriggerMode : uint8_t
{
    AllAnimations                                  = 0,
    HighestWeightedAnimation                       = 1,
    None                                           = 2,
    ENotifyTriggerMode_MAX                         = 3

};


// Enum  /Script/Engine.EBlendSpaceAxis
enum class EBlendSpaceAxis : uint8_t
{
    BSA_None                                       = 0,
    BSA_X                                          = 1,
    BSA_Y                                          = 2,
    BSA_Max                                        = 3

};


// Enum  /Script/Engine.EBlueprintNativizationFlag
enum class EBlueprintNativizationFlag : uint8_t
{
    Disabled                                       = 0,
    Dependency                                     = 1,
    ExplicitlyEnabled                              = 2,
    EBlueprintNativizationFlag_MAX                 = 3

};


// Enum  /Script/Engine.EBlueprintCompileMode
enum class EBlueprintCompileMode : uint8_t
{
    Default                                        = 0,
    Development                                    = 1,
    FinalRelease                                   = 2,
    EBlueprintCompileMode_MAX                      = 3

};


// Enum  /Script/Engine.EBlueprintType
enum class EBlueprintType : uint8_t
{
    BPTYPE_Normal                                  = 0,
    BPTYPE_Const                                   = 1,
    BPTYPE_MacroLibrary                            = 2,
    BPTYPE_Interface                               = 3,
    BPTYPE_LevelScript                             = 4,
    BPTYPE_FunctionLibrary                         = 5,
    BPTYPE_MAX                                     = 6

};


// Enum  /Script/Engine.EBlueprintStatus
enum class EBlueprintStatus : uint8_t
{
    BS_Unknown                                     = 0,
    BS_Dirty                                       = 1,
    BS_Error                                       = 2,
    BS_UpToDate                                    = 3,
    BS_BeingCreated                                = 4,
    BS_UpToDateWithWarnings                        = 5,
    BS_MAX                                         = 6

};


// Enum  /Script/Engine.EDOFMode
enum class EDOFMode : uint8_t
{
    Default                                        = 0,
    SixDOF                                         = 1,
    YZPlane                                        = 2,
    XZPlane                                        = 3,
    XYPlane                                        = 4,
    CustomPlane                                    = 5,
    None                                           = 6,
    EDOFMode_MAX                                   = 7

};


// Enum  /Script/Engine.EBrushType
enum class EBrushType : uint8_t
{
    Brush_Default                                  = 0,
    Brush_Add                                      = 1,
    Brush_Subtract                                 = 2,
    Brush_MAX                                      = 3

};


// Enum  /Script/Engine.ECsgOper
enum class ECsgOper : uint8_t
{
    CSG_Active                                     = 0,
    CSG_Add                                        = 1,
    CSG_Subtract                                   = 2,
    CSG_Intersect                                  = 3,
    CSG_Deintersect                                = 4,
    CSG_None                                       = 5,
    CSG_MAX                                        = 6

};


// Enum  /Script/Engine.EInitialOscillatorOffset
enum class EInitialOscillatorOffset : uint8_t
{
    EOO_OffsetRandom                               = 0,
    EOO_OffsetZero                                 = 1,
    EOO_MAX                                        = 2

};


// Enum  /Script/Engine.EOscillatorWaveform
enum class EOscillatorWaveform : uint8_t
{
    SineWave                                       = 0,
    PerlinNoise                                    = 1,
    EOscillatorWaveform_MAX                        = 2

};


// Enum  /Script/Engine.ECameraShakeDurationType
enum class ECameraShakeDurationType : uint8_t
{
    Fixed                                          = 0,
    Infinite                                       = 1,
    Custom                                         = 2,
    ECameraShakeDurationType_MAX                   = 3

};


// Enum  /Script/Engine.ECameraShakeUpdateResultFlags
enum class ECameraShakeUpdateResultFlags : uint8_t
{
    ApplyAsAbsolute                                = 1,
    SkipAutoScale                                  = 2,
    SkipAutoPlaySpace                              = 4,
    Default                                        = 0,
    ECameraShakeUpdateResultFlags_MAX              = 5

};


// Enum  /Script/Engine.ECameraShakeAttenuation
enum class ECameraShakeAttenuation : uint8_t
{
    Linear                                         = 0,
    Quadratic                                      = 1,
    ECameraShakeAttenuation_MAX                    = 2

};


// Enum  /Script/Engine.ECameraAlphaBlendMode
enum class ECameraAlphaBlendMode : uint8_t
{
    CABM_Linear                                    = 0,
    CABM_Cubic                                     = 1,
    CABM_MAX                                       = 2

};


// Enum  /Script/Engine.ECameraFOVMode
enum class ECameraFOVMode : uint8_t
{
    HorizontalFOV                                  = 0,
    VerticalFOV                                    = 1,
    FixedAspectVerticalFOV                         = 2,
    ECameraFOVMode_MAX                             = 3

};


// Enum  /Script/Engine.ECameraProjectionMode
enum class ECameraProjectionMode : uint8_t
{
    Perspective                                    = 0,
    Orthographic                                   = 1,
    ECameraProjectionMode_MAX                      = 2

};


// Enum  /Script/Engine.ECharacterMovementStuckReason
enum class ECharacterMovementStuckReason : uint8_t
{
    Undefined                                      = 0,
    MoveAlongFloor                                 = 1,
    StuckInFloor                                   = 2,
    StuckInAir                                     = 3,
    LogOnly                                        = 4,
    LogOnly_MoveAlongFloor_StepUpFailed            = 5,
    LogOnly_MoveAlongFloor_InvalidBlock            = 6,
    ECharacterMovementStuckReason_MAX              = 7

};


// Enum  /Script/Engine.ECloudStorageDelegate
enum class ECloudStorageDelegate : uint8_t
{
    CSD_KeyValueReadComplete                       = 0,
    CSD_KeyValueWriteComplete                      = 1,
    CSD_ValueChanged                               = 2,
    CSD_DocumentQueryComplete                      = 3,
    CSD_DocumentReadComplete                       = 4,
    CSD_DocumentWriteComplete                      = 5,
    CSD_DocumentConflictDetected                   = 6,
    CSD_MAX                                        = 7

};


// Enum  /Script/Engine.EAngularDriveMode
enum class EAngularDriveMode : uint8_t
{
    SLERP                                          = 0,
    TwistAndSwing                                  = 1,
    EAngularDriveMode_MAX                          = 2

};


// Enum  /Script/Engine.ECurveTableMode
enum class ECurveTableMode : uint8_t
{
    Empty                                          = 0,
    SimpleCurves                                   = 1,
    RichCurves                                     = 2,
    ECurveTableMode_MAX                            = 3

};


// Enum  /Script/Engine.ECustomAttributeBlendType
enum class ECustomAttributeBlendType : uint8_t
{
    Override                                       = 0,
    Blend                                          = 1,
    ECustomAttributeBlendType_MAX                  = 2

};


// Enum  /Script/Engine.EEvaluateCurveTableResult
enum class EEvaluateCurveTableResult : uint8_t
{
    RowFound                                       = 0,
    RowNotFound                                    = 1,
    EEvaluateCurveTableResult_MAX                  = 2

};


// Enum  /Script/Engine.EGrammaticalNumber
enum class EGrammaticalNumber : uint8_t
{
    Singular                                       = 0,
    Plural                                         = 1,
    EGrammaticalNumber_MAX                         = 2

};


// Enum  /Script/Engine.EGrammaticalGender
enum class EGrammaticalGender : uint8_t
{
    Neuter                                         = 0,
    Masculine                                      = 1,
    Feminine                                       = 2,
    Mixed                                          = 3,
    EGrammaticalGender_MAX                         = 4

};


// Enum  /Script/Engine.DistributionParamMode
enum class DistributionParamMode : uint8_t
{
    DPM_Normal                                     = 0,
    DPM_Abs                                        = 1,
    DPM_Direct                                     = 2,
    DPM_MAX                                        = 3

};


// Enum  /Script/Engine.EDistributionVectorMirrorFlags
enum class EDistributionVectorMirrorFlags : uint8_t
{
    EDVMF_Same                                     = 0,
    EDVMF_Different                                = 1,
    EDVMF_Mirror                                   = 2,
    EDVMF_MAX                                      = 3

};


// Enum  /Script/Engine.EDistributionVectorLockFlags
enum class EDistributionVectorLockFlags : uint8_t
{
    EDVLF_None                                     = 0,
    EDVLF_XY                                       = 1,
    EDVLF_XZ                                       = 2,
    EDVLF_YZ                                       = 3,
    EDVLF_XYZ                                      = 4,
    EDVLF_MAX                                      = 5

};


// Enum  /Script/Engine.ECanNotMultiNetTickReason
enum class ECanNotMultiNetTickReason : uint8_t
{
    CanNotMultiNetTickReason_FrameIsBusy           = 0,
    CanNotMultiNetTickReason_TimeElapsedIsTooLong  = 1,
    CanNotMultiNetTickReason_TooTimes              = 2,
    CanNotMultiNetTickReason_MAX                   = 3

};


// Enum  /Script/Engine.ENodeEnabledState
enum class ENodeEnabledState : uint8_t
{
    Enabled                                        = 0,
    Disabled                                       = 1,
    DevelopmentOnly                                = 2,
    ENodeEnabledState_MAX                          = 3

};


// Enum  /Script/Engine.ENodeAdvancedPins
enum class ENodeAdvancedPins : uint8_t
{
    NoPins                                         = 0,
    Shown                                          = 1,
    Hidden                                         = 2,
    ENodeAdvancedPins_MAX                          = 3

};


// Enum  /Script/Engine.ENodeTitleType
enum class ENodeTitleType : uint8_t
{
    FullTitle                                      = 0,
    ListView                                       = 1,
    EditableTitle                                  = 2,
    MenuTitle                                      = 3,
    MAX_TitleTypes                                 = 4,
    ENodeTitleType_MAX                             = 5

};


// Enum  /Script/Engine.EPinContainerType
enum class EPinContainerType : uint8_t
{
    None                                           = 0,
    Array                                          = 1,
    Set                                            = 2,
    Map                                            = 3,
    EPinContainerType_MAX                          = 4

};


// Enum  /Script/Engine.EEdGraphPinDirection
enum class EEdGraphPinDirection : uint8_t
{
    EGPD_Input                                     = 0,
    EGPD_Output                                    = 1,
    EGPD_MAX                                       = 2

};


// Enum  /Script/Engine.EBlueprintPinStyleType
enum class EBlueprintPinStyleType : uint8_t
{
    BPST_Original                                  = 0,
    BPST_VariantA                                  = 1,
    BPST_MAX                                       = 2

};


// Enum  /Script/Engine.ECanCreateConnectionResponse
enum class ECanCreateConnectionResponse : uint8_t
{
    CONNECT_RESPONSE_MAKE                          = 0,
    CONNECT_RESPONSE_DISALLOW                      = 1,
    CONNECT_RESPONSE_BREAK_OTHERS_A                = 2,
    CONNECT_RESPONSE_BREAK_OTHERS_B                = 3,
    CONNECT_RESPONSE_BREAK_OTHERS_AB               = 4,
    CONNECT_RESPONSE_MAKE_WITH_CONVERSION_NODE     = 5,
    CONNECT_RESPONSE_MAX                           = 6

};


// Enum  /Script/Engine.EGraphType
enum class EGraphType : uint8_t
{
    GT_Function                                    = 0,
    GT_Ubergraph                                   = 1,
    GT_Macro                                       = 2,
    GT_Animation                                   = 3,
    GT_StateMachine                                = 4,
    GT_MAX                                         = 5

};


// Enum  /Script/Engine.ETransitionType
enum class ETransitionType : uint8_t
{
    None                                           = 0,
    Paused                                         = 1,
    Loading                                        = 2,
    Saving                                         = 3,
    Connecting                                     = 4,
    Precaching                                     = 5,
    WaitingToConnect                               = 6,
    MAX                                            = 7

};


// Enum  /Script/Engine.EFullyLoadPackageType
enum class EFullyLoadPackageType : uint8_t
{
    FULLYLOAD_Map                                  = 0,
    FULLYLOAD_Game_PreLoadClass                    = 1,
    FULLYLOAD_Game_PostLoadClass                   = 2,
    FULLYLOAD_Always                               = 3,
    FULLYLOAD_Mutator                              = 4,
    FULLYLOAD_MAX                                  = 5

};


// Enum  /Script/Engine.EViewModeIndex
enum class EViewModeIndex : uint8_t
{
    VMI_BrushWireframe                             = 0,
    VMI_Wireframe                                  = 1,
    VMI_Unlit                                      = 2,
    VMI_Lit                                        = 3,
    VMI_Lit_DetailLighting                         = 4,
    VMI_LightingOnly                               = 5,
    VMI_LightComplexity                            = 6,
    VMI_ShaderComplexity                           = 8,
    VMI_LightmapDensity                            = 9,
    VMI_LitLightmapDensity                         = 10,
    VMI_ReflectionOverride                         = 11,
    VMI_VisualizeBuffer                            = 12,
    VMI_StationaryLightOverlap                     = 14,
    VMI_CollisionPawn                              = 15,
    VMI_CollisionVisibility                        = 16,
    VMI_LODColoration                              = 18,
    VMI_QuadOverdraw                               = 19,
    VMI_PrimitiveDistanceAccuracy                  = 20,
    VMI_MeshUVDensityAccuracy                      = 21,
    VMI_ShaderComplexityWithQuadOverdraw           = 22,
    VMI_HLODColoration                             = 23,
    VMI_GroupLODColoration                         = 24,
    VMI_MaterialTextureScaleAccuracy               = 25,
    VMI_RequiredTextureResolution                  = 26,
    VMI_PathTracing                                = 27,
    VMI_RayTracingDebug                            = 28,
    VMI_GroupCustom                                = 29,
    VMI_SkyIrradiance                              = 30,
    VMI_SkyBentNormal                              = 31,
    VMI_SkyVisibility                              = 32,
    VMI_PRTIndirectLighting                        = 33,
    VMI_LocalTonemapSkyAverageLuminance            = 34,
    VMI_LocalTonemapFactor                         = 35,
    VMI_LocalTonemapEVDiff                         = 36,
    VMI_LOD1AndLOD0                                = 37,
    VMI_LOD2AndLOD0                                = 38,
    VMI_LPVColor                                   = 39,
    VMI_LPVDebug                                   = 40,
    VMI_Max                                        = 41,
    VMI_Unknown                                    = 255

};


// Enum  /Script/Engine.EDemoPlayFailure
enum class EDemoPlayFailure : uint8_t
{
    Generic                                        = 0,
    DemoNotFound                                   = 1,
    Corrupt                                        = 2,
    InvalidVersion                                 = 3,
    InitBase                                       = 4,
    GameSpecificHeader                             = 5,
    ReplayStreamerInternal                         = 6,
    LoadMap                                        = 7,
    Serialization                                  = 8,
    EDemoPlayFailure_MAX                           = 9

};


// Enum  /Script/Engine.ENetworkLagState
enum class ENetworkLagState : uint8_t
{
    NotLagging                                     = 0,
    Lagging                                        = 1,
    ENetworkLagState_MAX                           = 2

};


// Enum  /Script/Engine.EDSMultiTickingGroup
enum class EDSMultiTickingGroup : uint8_t
{
    DS_MULTI_TG_TickDispatch                       = 0,
    DS_MULTI_TG_PrePhysics                         = 1,
    DS_MULTI_TG_StartPhysics                       = 2,
    DS_MULTI_TG_DuringPhysics                      = 3,
    DS_MULTI_TG_EndPhysics                         = 4,
    DS_MULTI_TG_PostPhysics                        = 5,
    DS_MULTI_TG_PostUpdateWork                     = 6,
    DS_MULTI_TG_LastDemotable                      = 7,
    DS_MULTI_TG_NewlySpawned                       = 8,
    DS_MULTI_TG_MAX                                = 9

};


// Enum  /Script/Engine.EMouseCaptureMode
enum class EMouseCaptureMode : uint8_t
{
    NoCapture                                      = 0,
    CapturePermanently                             = 1,
    CapturePermanently_IncludingInitialMouseDown   = 2,
    CaptureDuringMouseDown                         = 3,
    CaptureDuringRightMouseDown                    = 4,
    EMouseCaptureMode_MAX                          = 5

};


// Enum  /Script/Engine.ECustomTimeStepSynchronizationState
enum class ECustomTimeStepSynchronizationState : uint8_t
{
    Closed                                         = 0,
    Error                                          = 1,
    Synchronized                                   = 2,
    Synchronizing                                  = 3,
    ECustomTimeStepSynchronizationState_MAX        = 4

};


// Enum  /Script/Engine.EMeshBufferAccess
enum class EMeshBufferAccess : uint8_t
{
    Default                                        = 0,
    ForceCPUAndGPU                                 = 1,
    EMeshBufferAccess_MAX                          = 2

};


// Enum  /Script/Engine.EComponentSocketType
enum class EComponentSocketType : uint8_t
{
    Invalid                                        = 0,
    Bone                                           = 1,
    Socket                                         = 2,
    EComponentSocketType_MAX                       = 3

};


// Enum  /Script/Engine.EPhysicalMaterialMaskColor
enum class EPhysicalMaterialMaskColor : uint8_t
{
    Red                                            = 0,
    Green                                          = 1,
    Blue                                           = 2,
    Cyan                                           = 3,
    Magenta                                        = 4,
    Yellow                                         = 5,
    White                                          = 6,
    Black                                          = 7,
    MAX                                            = 8

};


// Enum  /Script/Engine.EWalkableSlopeBehavior
enum class EWalkableSlopeBehavior : uint8_t
{
    WalkableSlope_Default                          = 0,
    WalkableSlope_Increase                         = 1,
    WalkableSlope_Decrease                         = 2,
    WalkableSlope_Unwalkable                       = 3,
    WalkableSlope_Max                              = 4

};


// Enum  /Script/Engine.EAutoPossessAI
enum class EAutoPossessAI : uint8_t
{
    Disabled                                       = 0,
    PlacedInWorld                                  = 1,
    Spawned                                        = 2,
    PlacedInWorldOrSpawned                         = 3,
    EAutoPossessAI_MAX                             = 4

};


// Enum  /Script/Engine.EUpdateRateShiftBucket
enum class EUpdateRateShiftBucket : uint8_t
{
    ShiftBucket0                                   = 0,
    ShiftBucket1                                   = 1,
    ShiftBucket2                                   = 2,
    ShiftBucket3                                   = 3,
    ShiftBucket4                                   = 4,
    ShiftBucket5                                   = 5,
    ShiftBucketMax                                 = 6,
    EUpdateRateShiftBucket_MAX                     = 7

};


// Enum  /Script/Engine.EShadowMapFlags
enum class EShadowMapFlags : uint8_t
{
    SMF_None                                       = 0,
    SMF_Streamed                                   = 1,
    SMF_MAX                                        = 2

};


// Enum  /Script/Engine.ELightMapPaddingType
enum class ELightMapPaddingType : uint8_t
{
    LMPT_NormalPadding                             = 0,
    LMPT_PrePadding                                = 1,
    LMPT_NoPadding                                 = 2,
    LMPT_MAX                                       = 3

};


// Enum  /Script/Engine.ECollisionEnabled
enum class ECollisionEnabled : uint8_t
{
    NoCollision                                    = 0,
    QueryOnly                                      = 1,
    PhysicsOnly                                    = 2,
    QueryAndPhysics                                = 3,
    ECollisionEnabled_MAX                          = 4

};


// Enum  /Script/Engine.ETimelineSigType
enum class ETimelineSigType : uint8_t
{
    ETS_EventSignature                             = 0,
    ETS_FloatSignature                             = 1,
    ETS_VectorSignature                            = 2,
    ETS_LinearColorSignature                       = 3,
    ETS_InvalidSignature                           = 4,
    ETS_MAX                                        = 5

};


// Enum  /Script/Engine.EFilterInterpolationType
enum class EFilterInterpolationType : uint8_t
{
    BSIT_Average                                   = 0,
    BSIT_Linear                                    = 1,
    BSIT_Cubic                                     = 2,
    BSIT_MAX                                       = 3

};


// Enum  /Script/Engine.ECollisionResponse
enum class ECollisionResponse : uint8_t
{
    ECR_Ignore                                     = 0,
    ECR_Overlap                                    = 1,
    ECR_Block                                      = 2,
    ECR_MAX                                        = 3

};


// Enum  /Script/Engine.EOverlapFilterOption
enum class EOverlapFilterOption : uint8_t
{
    OverlapFilter_All                              = 0,
    OverlapFilter_DynamicOnly                      = 1,
    OverlapFilter_StaticOnly                       = 2,
    OverlapFilter_MAX                              = 3

};


// Enum  /Script/Engine.ENetworkSmoothingMode
enum class ENetworkSmoothingMode : uint8_t
{
    Disabled                                       = 0,
    Linear                                         = 1,
    Exponential                                    = 2,
    Replay                                         = 3,
    ENetworkSmoothingMode_MAX                      = 4

};


// Enum  /Script/Engine.ELightingBuildQuality
enum class ELightingBuildQuality : uint8_t
{
    Quality_Preview                                = 0,
    Quality_Medium                                 = 1,
    Quality_High                                   = 2,
    Quality_Production                             = 3,
    Quality_MAX                                    = 4

};


// Enum  /Script/Engine.EMaterialShadingRate
enum class EMaterialShadingRate : uint8_t
{
    MSR_1x1                                        = 0,
    MSR_2x1                                        = 1,
    MSR_1x2                                        = 2,
    MSR_2x2                                        = 3,
    MSR_4x2                                        = 4,
    MSR_2x4                                        = 5,
    MSR_4x4                                        = 6,
    MSR_Count                                      = 7,
    MSR_MAX                                        = 8

};


// Enum  /Script/Engine.EMaterialStencilCompare
enum class EMaterialStencilCompare : uint8_t
{
    MSC_Less                                       = 0,
    MSC_LessEqual                                  = 1,
    MSC_Greater                                    = 2,
    MSC_GreaterEqual                               = 3,
    MSC_Equal                                      = 4,
    MSC_NotEqual                                   = 5,
    MSC_Never                                      = 6,
    MSC_Always                                     = 7,
    MSC_Count                                      = 8,
    MSC_MAX                                        = 9

};


// Enum  /Script/Engine.EMaterialSamplerType
enum class EMaterialSamplerType : uint8_t
{
    SAMPLERTYPE_Color                              = 0,
    SAMPLERTYPE_Grayscale                          = 1,
    SAMPLERTYPE_Alpha                              = 2,
    SAMPLERTYPE_Normal                             = 3,
    SAMPLERTYPE_Masks                              = 4,
    SAMPLERTYPE_DistanceFieldFont                  = 5,
    SAMPLERTYPE_LinearColor                        = 6,
    SAMPLERTYPE_LinearGrayscale                    = 7,
    SAMPLERTYPE_Data                               = 8,
    SAMPLERTYPE_External                           = 9,
    SAMPLERTYPE_VirtualColor                       = 10,
    SAMPLERTYPE_VirtualGrayscale                   = 11,
    SAMPLERTYPE_VirtualAlpha                       = 12,
    SAMPLERTYPE_VirtualNormal                      = 13,
    SAMPLERTYPE_VirtualMasks                       = 14,
    SAMPLERTYPE_VirtualLinearColor                 = 15,
    SAMPLERTYPE_VirtualLinearGrayscale             = 16,
    SAMPLERTYPE_MAX                                = 17

};


// Enum  /Script/Engine.EMaterialTessellationMode
enum class EMaterialTessellationMode : uint8_t
{
    MTM_NoTessellation                             = 0,
    MTM_FlatTessellation                           = 1,
    MTM_PNTriangles                                = 2,
    MTM_MAX                                        = 3

};


// Enum  /Script/Engine.EMaterialShadingModel
enum class EMaterialShadingModel : uint8_t
{
    MSM_Unlit                                      = 0,
    MSM_DefaultLit                                 = 1,
    MSM_Subsurface                                 = 2,
    MSM_PreintegratedSkin                          = 3,
    MSM_ClearCoat                                  = 4,
    MSM_SubsurfaceProfile                          = 5,
    MSM_TwoSidedFoliage                            = 6,
    MSM_Hair                                       = 7,
    MSM_Cloth                                      = 8,
    MSM_Eye                                        = 9,
    MSM_SingleLayerWater                           = 10,
    MSM_MobilePreintegratedSkin                    = 11,
    MSM_ThinTranslucent                            = 12,
    MSM_UAMobileFoliage                            = 13,
    MSM_UAMobileFoliageBillBoard                   = 14,
    MSM_UAMobileHair                               = 15,
    MSM_NUM                                        = 16,
    MSM_FromMaterialExpression                     = 17,
    MSM_MAX                                        = 18

};


// Enum  /Script/Engine.EParticleCollisionMode
enum class EParticleCollisionMode : uint8_t
{
    SceneDepth                                     = 0,
    DistanceField                                  = 1,
    EParticleCollisionMode_MAX                     = 2

};


// Enum  /Script/Engine.ETrailWidthMode
enum class ETrailWidthMode : uint8_t
{
    ETrailWidthMode_FromCentre                     = 0,
    ETrailWidthMode_FromFirst                      = 1,
    ETrailWidthMode_FromSecond                     = 2,
    ETrailWidthMode_MAX                            = 3

};


// Enum  /Script/Engine.EGBufferFormat
enum class EGBufferFormat : uint8_t
{
    Force8BitsPerChannel                           = 0,
    Default                                        = 1,
    HighPrecisionNormals                           = 3,
    Force16BitsPerChannel                          = 5,
    EGBufferFormat_MAX                             = 6

};


// Enum  /Script/Engine.ESceneCaptureCompositeMode
enum class ESceneCaptureCompositeMode : uint8_t
{
    SCCM_Overwrite                                 = 0,
    SCCM_Additive                                  = 1,
    SCCM_Composite                                 = 2,
    SCCM_MAX                                       = 3

};


// Enum  /Script/Engine.ESceneCaptureSource
enum class ESceneCaptureSource : uint8_t
{
    SCS_SceneColorHDR                              = 0,
    SCS_SceneColorHDRNoAlpha                       = 1,
    SCS_FinalColorLDR                              = 2,
    SCS_SceneColorSceneDepth                       = 3,
    SCS_SceneDepth                                 = 4,
    SCS_DeviceDepth                                = 5,
    SCS_Normal                                     = 6,
    SCS_BaseColor                                  = 7,
    SCS_FinalColorHDR                              = 8,
    SCS_FinalToneCurveHDR                          = 9,
    SCS_FinalToneCurveLDR                          = 10,
    SCS_FinalToneCurveLDRAlpha                     = 11,
    SCS_MAX                                        = 12

};


// Enum  /Script/Engine.ETranslucentSortPolicy
enum class ETranslucentSortPolicy : uint8_t
{
    SortByDistance                                 = 0,
    SortByProjectedZ                               = 1,
    SortAlongAxis                                  = 2,
    ETranslucentSortPolicy_MAX                     = 3

};


// Enum  /Script/Engine.ERefractionMode
enum class ERefractionMode : uint8_t
{
    RM_IndexOfRefraction                           = 0,
    RM_PixelNormalOffset                           = 1,
    RM_MAX                                         = 2

};


// Enum  /Script/Engine.EDirLightShadowBiasOverride
enum class EDirLightShadowBiasOverride : uint8_t
{
    DLSBO_NONE                                     = 0,
    DLSBO_CASTER_BIAS                              = 1,
    DLSBO_RECEIVER_BIAS                            = 2,
    DLSBO_MAX                                      = 3

};


// Enum  /Script/Engine.ETranslucencyLightingMode
enum class ETranslucencyLightingMode : uint8_t
{
    TLM_VolumetricNonDirectional                   = 0,
    TLM_VolumetricDirectional                      = 1,
    TLM_VolumetricPerVertexNonDirectional          = 2,
    TLM_VolumetricPerVertexDirectional             = 3,
    TLM_Surface                                    = 4,
    TLM_SurfacePerPixelLighting                    = 5,
    TLM_MAX                                        = 6

};


// Enum  /Script/Engine.ESamplerSourceMode
enum class ESamplerSourceMode : uint8_t
{
    SSM_FromTextureAsset                           = 0,
    SSM_Wrap_WorldGroupSettings                    = 1,
    SSM_Clamp_WorldGroupSettings                   = 2,
    SSM_MAX                                        = 3

};


// Enum  /Script/Engine.EMaterialFloatPrecisionModeVulkanOverride
enum class EMaterialFloatPrecisionModeVulkanOverride : uint8_t
{
    MFPMV_NoOverride                               = 0,
    MFPMV_Half                                     = 1,
    MFPMV_Full_MaterialExpressionOnly              = 2,
    MFPMV_Full                                     = 3,
    MFPMV_Max                                      = 4

};


// Enum  /Script/Engine.EMaterialFloatPrecisionMode
enum class EMaterialFloatPrecisionMode : uint8_t
{
    MFPM_Half                                      = 0,
    MFPM_Full_MaterialExpressionOnly               = 1,
    MFPM_Full                                      = 2,
    MFPM_MAX                                       = 3

};


// Enum  /Script/Engine.EBlendMode
enum class EBlendMode : uint8_t
{
    BLEND_Opaque                                   = 0,
    BLEND_Masked                                   = 1,
    BLEND_Translucent                              = 2,
    BLEND_Additive                                 = 3,
    BLEND_Modulate                                 = 4,
    BLEND_AlphaComposite                           = 5,
    BLEND_AlphaHoldout                             = 6,
    BLEND_MAX                                      = 7

};


// Enum  /Script/Engine.EOcclusionCombineMode
enum class EOcclusionCombineMode : uint8_t
{
    OCM_Minimum                                    = 0,
    OCM_Multiply                                   = 1,
    OCM_MAX                                        = 2

};


// Enum  /Script/Engine.EVolumetricOcclusionMode
enum class EVolumetricOcclusionMode : uint8_t
{
    OcclusionNone                                  = 0,
    AmbientOcclusionOnly                           = 1,
    SkyOcclusionOnly                               = 2,
    AmbientAndSkyOcclusion                         = 3,
    EVolumetricOcclusionMode_MAX                   = 4

};


// Enum  /Script/Engine.EVolumetricLightmapSampleType
enum class EVolumetricLightmapSampleType : uint8_t
{
    Default                                        = 0,
    ForceInteriorVolume                            = 1,
    ForceCullingBackFace                           = 2,
    ForcePrimitiveDistanceField                    = 3,
    EVolumetricLightmapSampleType_MAX              = 4

};


// Enum  /Script/Engine.EUamRemoveLODMapMask
enum class EUamRemoveLODMapMask : uint8_t
{
    NonBattleMap                                   = 0,
    Farmland                                       = 1,
    Valley                                         = 2,
    Lake                                           = 4,
    Armory                                         = 8,
    TVStation                                      = 16,
    Breakout                                       = 32,
    MapNum                                         = 6,
    EUamRemoveLODMapMask_MAX                       = 33

};


// Enum  /Script/Engine.EMpeMoveableType
enum class EMpeMoveableType : uint8_t
{
    Unmoveable                                     = 0,
    Moveable_1P                                    = 1,
    Movaeble_3P                                    = 2,
    EMpeMoveableType_MAX                           = 3

};


// Enum  /Script/Engine.ELightmapType
enum class ELightmapType : uint8_t
{
    Default                                        = 0,
    ForceSurface                                   = 1,
    ForceVolumetric                                = 2,
    ELightmapType_MAX                              = 3

};


// Enum  /Script/Engine.EIndirectLightingCacheQuality
enum class EIndirectLightingCacheQuality : uint8_t
{
    ILCQ_Off                                       = 0,
    ILCQ_Point                                     = 1,
    ILCQ_Volume                                    = 2,
    ILCQ_MAX                                       = 3

};


// Enum  /Script/Engine.ESceneDepthPriorityGroup
enum class ESceneDepthPriorityGroup : uint8_t
{
    SDPG_World                                     = 0,
    SDPG_Foreground                                = 1,
    SDPG_MAX                                       = 2

};


// Enum  /Script/Engine.EAspectRatioAxisConstraint
enum class EAspectRatioAxisConstraint : uint8_t
{
    AspectRatio_MaintainYFOV                       = 0,
    AspectRatio_MaintainXFOV                       = 1,
    AspectRatio_MajorAxisFOV                       = 2,
    AspectRatio_MAX                                = 3

};


// Enum  /Script/Engine.EFontCacheType
enum class EFontCacheType : uint8_t
{
    Offline                                        = 0,
    Runtime                                        = 1,
    EFontCacheType_MAX                             = 2

};


// Enum  /Script/Engine.EFontImportCharacterSet
enum class EFontImportCharacterSet : uint8_t
{
    FontICS_Default                                = 0,
    FontICS_Ansi                                   = 1,
    FontICS_Symbol                                 = 2,
    FontICS_MAX                                    = 3

};


// Enum  /Script/Engine.EStandbyType
enum class EStandbyType : uint8_t
{
    STDBY_Rx                                       = 0,
    STDBY_Tx                                       = 1,
    STDBY_BadPing                                  = 2,
    STDBY_MAX                                      = 3

};


// Enum  /Script/Engine.ESuggestProjVelocityTraceOption
enum class ESuggestProjVelocityTraceOption : uint8_t
{
    DoNotTrace                                     = 0,
    TraceFullPath                                  = 1,
    OnlyTraceWhileAscending                        = 2,
    ESuggestProjVelocityTraceOption_MAX            = 3

};


// Enum  /Script/Engine.EWindowMode
enum class EWindowMode : uint8_t
{
    Fullscreen                                     = 0,
    WindowedFullscreen                             = 1,
    Windowed                                       = 2,
    EWindowMode_MAX                                = 3

};


// Enum  /Script/Engine.EIndirectLightVolumeType
enum class EIndirectLightVolumeType : uint8_t
{
    DawnInterior_Default                           = 0,
    DawnInterior_Exterior                          = 1,
    DawnInterior_Interior1                         = 2,
    DawnInterior_Interior2                         = 3,
    DawnInterior_Interior3                         = 4,
    DawnInterior_Interior4                         = 5,
    DawnInterior_MAX                               = 6

};


// Enum  /Script/Engine.EHitProxyPriority
enum class EHitProxyPriority : uint8_t
{
    HPP_World                                      = 0,
    HPP_Wireframe                                  = 1,
    HPP_Foreground                                 = 2,
    HPP_UI                                         = 3,
    HPP_MAX                                        = 4

};


// Enum  /Script/Engine.ECubemapEncodeType
enum class ECubemapEncodeType : uint8_t
{
    CET_None                                       = 0,
    CET_RGBM                                       = 1,
    CET_Max                                        = 2

};


// Enum  /Script/Engine.EImportanceWeight
enum class EImportanceWeight : uint8_t
{
    Luminance                                      = 0,
    Red                                            = 1,
    Green                                          = 2,
    Blue                                           = 3,
    Alpha                                          = 4,
    EImportanceWeight_MAX                          = 5

};


// Enum  /Script/Engine.EAdManagerDelegate
enum class EAdManagerDelegate : uint8_t
{
    AMD_ClickedBanner                              = 0,
    AMD_UserClosedAd                               = 1,
    AMD_MAX                                        = 2

};


// Enum  /Script/Engine.EAnimAlphaInputType
enum class EAnimAlphaInputType : uint8_t
{
    Float                                          = 0,
    Bool                                           = 1,
    Curve                                          = 2,
    EAnimAlphaInputType_MAX                        = 3

};


// Enum  /Script/Engine.ETrackActiveCondition
enum class ETrackActiveCondition : uint8_t
{
    ETAC_Always                                    = 0,
    ETAC_GoreEnabled                               = 1,
    ETAC_GoreDisabled                              = 2,
    ETAC_MAX                                       = 3

};


// Enum  /Script/Engine.EInterpTrackMoveRotMode
enum class EInterpTrackMoveRotMode : uint8_t
{
    IMR_Keyframed                                  = 0,
    IMR_LookAtGroup                                = 1,
    IMR_Ignore                                     = 2,
    IMR_MAX                                        = 3

};


// Enum  /Script/Engine.EInterpMoveAxis
enum class EInterpMoveAxis : uint8_t
{
    AXIS_TranslationX                              = 0,
    AXIS_TranslationY                              = 1,
    AXIS_TranslationZ                              = 2,
    AXIS_RotationX                                 = 3,
    AXIS_RotationY                                 = 4,
    AXIS_RotationZ                                 = 5,
    AXIS_MAX                                       = 6

};


// Enum  /Script/Engine.ETrackToggleAction
enum class ETrackToggleAction : uint8_t
{
    ETTA_Off                                       = 0,
    ETTA_On                                        = 1,
    ETTA_Toggle                                    = 2,
    ETTA_Trigger                                   = 3,
    ETTA_MAX                                       = 4

};


// Enum  /Script/Engine.EVisibilityTrackCondition
enum class EVisibilityTrackCondition : uint8_t
{
    EVTC_Always                                    = 0,
    EVTC_GoreEnabled                               = 1,
    EVTC_GoreDisabled                              = 2,
    EVTC_MAX                                       = 3

};


// Enum  /Script/Engine.EVisibilityTrackAction
enum class EVisibilityTrackAction : uint8_t
{
    EVTA_Hide                                      = 0,
    EVTA_Show                                      = 1,
    EVTA_Toggle                                    = 2,
    EVTA_MAX                                       = 3

};


// Enum  /Script/Engine.ESlateGesture
enum class ESlateGesture : uint8_t
{
    None                                           = 0,
    Scroll                                         = 1,
    Magnify                                        = 2,
    Swipe                                          = 3,
    Rotate                                         = 4,
    LongPress                                      = 5,
    ESlateGesture_MAX                              = 6

};


// Enum  /Script/Engine.EMIDCreationFlags
enum class EMIDCreationFlags : uint8_t
{
    None                                           = 0,
    Transient                                      = 1,
    EMIDCreationFlags_MAX                          = 2

};


// Enum  /Script/Engine.EMatrixColumns
enum class EMatrixColumns : uint8_t
{
    First                                          = 0,
    Second                                         = 1,
    Third                                          = 2,
    Fourth                                         = 3,
    EMatrixColumns_MAX                             = 4

};


// Enum  /Script/Engine.ELerpInterpolationMode
enum class ELerpInterpolationMode : uint8_t
{
    QuatInterp                                     = 0,
    EulerInterp                                    = 1,
    DualQuatInterp                                 = 2,
    ELerpInterpolationMode_MAX                     = 3

};


// Enum  /Script/Engine.EEasingFunc
enum class EEasingFunc : uint8_t
{
    Linear                                         = 0,
    Step                                           = 1,
    SinusoidalIn                                   = 2,
    SinusoidalOut                                  = 3,
    SinusoidalInOut                                = 4,
    EaseIn                                         = 5,
    EaseOut                                        = 6,
    EaseInOut                                      = 7,
    ExpoIn                                         = 8,
    ExpoOut                                        = 9,
    ExpoInOut                                      = 10,
    CircularIn                                     = 11,
    CircularOut                                    = 12,
    CircularInOut                                  = 13,
    EEasingFunc_MAX                                = 14

};


// Enum  /Script/Engine.ERoundingMode
enum class ERoundingMode : uint8_t
{
    HalfToEven                                     = 0,
    HalfFromZero                                   = 1,
    HalfToZero                                     = 2,
    FromZero                                       = 3,
    ToZero                                         = 4,
    ToNegativeInfinity                             = 5,
    ToPositiveInfinity                             = 6,
    ERoundingMode_MAX                              = 7

};


// Enum  /Script/Engine.EStreamingVolumeUsage
enum class EStreamingVolumeUsage : uint8_t
{
    SVB_Loading                                    = 0,
    SVB_LoadingAndVisibility                       = 1,
    SVB_VisibilityBlockingOnLoad                   = 2,
    SVB_BlockingOnLoad                             = 3,
    SVB_LoadingNotVisible                          = 4,
    SVB_MAX                                        = 5

};


// Enum  /Script/Engine.ESyncOption
enum class ESyncOption : uint8_t
{
    Drive                                          = 0,
    Passive                                        = 1,
    Disabled                                       = 2,
    ESyncOption_MAX                                = 3

};


// Enum  /Script/Engine.EMaterialDecalResponse
enum class EMaterialDecalResponse : uint8_t
{
    MDR_None                                       = 0,
    MDR_ColorNormalRoughness                       = 1,
    MDR_Color                                      = 2,
    MDR_ColorNormal                                = 3,
    MDR_ColorRoughness                             = 4,
    MDR_Normal                                     = 5,
    MDR_NormalRoughness                            = 6,
    MDR_Roughness                                  = 7,
    MDR_MAX                                        = 8

};


// Enum  /Script/Engine.EDecalBlendMode
enum class EDecalBlendMode : uint8_t
{
    DBM_Translucent                                = 0,
    DBM_Stain                                      = 1,
    DBM_Normal                                     = 2,
    DBM_Emissive                                   = 3,
    DBM_DBuffer_ColorNormalRoughness               = 4,
    DBM_DBuffer_Color                              = 5,
    DBM_DBuffer_ColorNormal                        = 6,
    DBM_DBuffer_ColorRoughness                     = 7,
    DBM_DBuffer_Normal                             = 8,
    DBM_DBuffer_NormalRoughness                    = 9,
    DBM_DBuffer_Roughness                          = 10,
    DBM_DBuffer_Emissive                           = 11,
    DBM_DBuffer_AlphaComposite                     = 12,
    DBM_DBuffer_EmissiveAlphaComposite             = 13,
    DBM_Volumetric_DistanceFunction                = 14,
    DBM_AlphaComposite                             = 15,
    DBM_AmbientOcclusion                           = 16,
    DBM_MAX                                        = 17

};


// Enum  /Script/Engine.ETextureColorChannel
enum class ETextureColorChannel : uint8_t
{
    TCC_Red                                        = 0,
    TCC_Green                                      = 1,
    TCC_Blue                                       = 2,
    TCC_Alpha                                      = 3,
    TCC_MAX                                        = 4

};


// Enum  /Script/Engine.EMaterialAttributeBlend
enum class EMaterialAttributeBlend : uint8_t
{
    Blend                                          = 0,
    UseA                                           = 1,
    UseB                                           = 2,
    EMaterialAttributeBlend_MAX                    = 3

};


// Enum  /Script/Engine.EChannelMaskParameterColor
enum class EChannelMaskParameterColor : uint8_t
{
    Red                                            = 0,
    Green                                          = 1,
    Blue                                           = 2,
    Alpha                                          = 3,
    EChannelMaskParameterColor_MAX                 = 4

};


// Enum  /Script/Engine.EClampMode
enum class EClampMode : uint8_t
{
    CMODE_Clamp                                    = 0,
    CMODE_ClampMin                                 = 1,
    CMODE_ClampMax                                 = 2,
    CMODE_MAX                                      = 3

};


// Enum  /Script/Engine.ECustomMaterialOutputType
enum class ECustomMaterialOutputType : uint8_t
{
    CMOT_Float1                                    = 0,
    CMOT_Float2                                    = 1,
    CMOT_Float3                                    = 2,
    CMOT_Float4                                    = 3,
    CMOT_MaterialAttributes                        = 4,
    CMOT_MAX                                       = 5

};


// Enum  /Script/Engine.EDepthOfFieldFunctionValue
enum class EDepthOfFieldFunctionValue : uint8_t
{
    TDOF_NearAndFarMask                            = 0,
    TDOF_NearMask                                  = 1,
    TDOF_FarMask                                   = 2,
    TDOF_CircleOfConfusionRadius                   = 3,
    TDOF_MAX                                       = 4

};


// Enum  /Script/Engine.EFunctionInputType
enum class EFunctionInputType : uint8_t
{
    FunctionInput_Scalar                           = 0,
    FunctionInput_Vector2                          = 1,
    FunctionInput_Vector3                          = 2,
    FunctionInput_Vector4                          = 3,
    FunctionInput_Texture2D                        = 4,
    FunctionInput_TextureCube                      = 5,
    FunctionInput_Texture2DArray                   = 6,
    FunctionInput_VolumeTexture                    = 7,
    FunctionInput_StaticBool                       = 8,
    FunctionInput_MaterialAttributes               = 9,
    FunctionInput_TextureExternal                  = 10,
    FunctionInput_MAX                              = 11

};


// Enum  /Script/Engine.ENoiseFunction
enum class ENoiseFunction : uint8_t
{
    NOISEFUNCTION_SimplexTex                       = 0,
    NOISEFUNCTION_GradientTex                      = 1,
    NOISEFUNCTION_GradientTex3D                    = 2,
    NOISEFUNCTION_GradientALU                      = 3,
    NOISEFUNCTION_ValueALU                         = 4,
    NOISEFUNCTION_VoronoiALU                       = 5,
    NOISEFUNCTION_MAX                              = 6

};


// Enum  /Script/Engine.EDynamicRVTMode
enum class EDynamicRVTMode : uint8_t
{
    WorldHeightDelta                               = 0,
    MipLevelError                                  = 1,
    Distance                                       = 2,
    Custom                                         = 3,
    EDynamicRVTMode_MAX                            = 4

};


// Enum  /Script/Engine.ERuntimeVirtualTextureTextureAddressMode
enum class ERuntimeVirtualTextureTextureAddressMode : uint8_t
{
    RVTTA_Clamp                                    = 0,
    RVTTA_Wrap                                     = 1,
    RVTTA_MAX                                      = 2

};


// Enum  /Script/Engine.ERuntimeVirtualTextureMipValueMode
enum class ERuntimeVirtualTextureMipValueMode : uint8_t
{
    RVTMVM_None                                    = 0,
    RVTMVM_MipLevel                                = 1,
    RVTMVM_MipBias                                 = 2,
    RVTMVM_MAX                                     = 3

};


// Enum  /Script/Engine.EMaterialSceneAttributeInputMode
enum class EMaterialSceneAttributeInputMode : uint8_t
{
    Coordinates                                    = 0,
    OffsetFraction                                 = 1,
    EMaterialSceneAttributeInputMode_MAX           = 2

};


// Enum  /Script/Engine.ESpeedTreeLODType
enum class ESpeedTreeLODType : uint8_t
{
    STLOD_Pop                                      = 0,
    STLOD_Smooth                                   = 1,
    STLOD_MAX                                      = 2

};


// Enum  /Script/Engine.ESpeedTreeWindType
enum class ESpeedTreeWindType : uint8_t
{
    STW_None                                       = 0,
    STW_Fastest                                    = 1,
    STW_Fast                                       = 2,
    STW_Better                                     = 3,
    STW_Best                                       = 4,
    STW_Palm                                       = 5,
    STW_BestPlus                                   = 6,
    STW_MAX                                        = 7

};


// Enum  /Script/Engine.ESpeedTreeGeometryType
enum class ESpeedTreeGeometryType : uint8_t
{
    STG_Branch                                     = 0,
    STG_Frond                                      = 1,
    STG_Leaf                                       = 2,
    STG_FacingLeaf                                 = 3,
    STG_Billboard                                  = 4,
    STG_MAX                                        = 5

};


// Enum  /Script/Engine.EMaterialExposedTextureProperty
enum class EMaterialExposedTextureProperty : uint8_t
{
    TMTM_TextureSize                               = 0,
    TMTM_TexelSize                                 = 1,
    TMTM_MAX                                       = 2

};


// Enum  /Script/Engine.ETextureMipValueMode
enum class ETextureMipValueMode : uint8_t
{
    TMVM_None                                      = 0,
    TMVM_MipLevel                                  = 1,
    TMVM_MipBias                                   = 2,
    TMVM_Derivative                                = 3,
    TMVM_MAX                                       = 4

};


// Enum  /Script/Engine.EMaterialVectorCoordTransform
enum class EMaterialVectorCoordTransform : uint8_t
{
    TRANSFORM_Tangent                              = 0,
    TRANSFORM_Local                                = 1,
    TRANSFORM_World                                = 2,
    TRANSFORM_View                                 = 3,
    TRANSFORM_Camera                               = 4,
    TRANSFORM_ParticleWorld                        = 5,
    TRANSFORM_MAX                                  = 6

};


// Enum  /Script/Engine.EMaterialVectorCoordTransformSource
enum class EMaterialVectorCoordTransformSource : uint8_t
{
    TRANSFORMSOURCE_Tangent                        = 0,
    TRANSFORMSOURCE_Local                          = 1,
    TRANSFORMSOURCE_World                          = 2,
    TRANSFORMSOURCE_View                           = 3,
    TRANSFORMSOURCE_Camera                         = 4,
    TRANSFORMSOURCE_ParticleWorld                  = 5,
    TRANSFORMSOURCE_MAX                            = 6

};


// Enum  /Script/Engine.EMaterialPositionTransformSource
enum class EMaterialPositionTransformSource : uint8_t
{
    TRANSFORMPOSSOURCE_Local                       = 0,
    TRANSFORMPOSSOURCE_World                       = 1,
    TRANSFORMPOSSOURCE_TranslatedWorld             = 2,
    TRANSFORMPOSSOURCE_View                        = 3,
    TRANSFORMPOSSOURCE_Camera                      = 4,
    TRANSFORMPOSSOURCE_Particle                    = 5,
    TRANSFORMPOSSOURCE_MAX                         = 6

};


// Enum  /Script/Engine.EVectorNoiseFunction
enum class EVectorNoiseFunction : uint8_t
{
    VNF_CellnoiseALU                               = 0,
    VNF_VectorALU                                  = 1,
    VNF_GradientALU                                = 2,
    VNF_CurlALU                                    = 3,
    VNF_VoronoiALU                                 = 4,
    VNF_MAX                                        = 5

};


// Enum  /Script/Engine.EMaterialExposedViewProperty
enum class EMaterialExposedViewProperty : uint8_t
{
    MEVP_BufferSize                                = 0,
    MEVP_FieldOfView                               = 1,
    MEVP_TanHalfFieldOfView                        = 2,
    MEVP_ViewSize                                  = 3,
    MEVP_WorldSpaceViewPosition                    = 4,
    MEVP_WorldSpaceCameraPosition                  = 5,
    MEVP_ViewportOffset                            = 6,
    MEVP_TemporalSampleCount                       = 7,
    MEVP_TemporalSampleIndex                       = 8,
    MEVP_TemporalSampleOffset                      = 9,
    MEVP_RuntimeVirtualTextureOutputLevel          = 10,
    MEVP_RuntimeVirtualTextureOutputDerivative     = 11,
    MEVP_PreExposure                               = 12,
    MEVP_RuntimeVirtualTextureMaxLevel             = 13,
    MEVP_MAX                                       = 14

};


// Enum  /Script/Engine.EWorldPositionIncludedOffsets
enum class EWorldPositionIncludedOffsets : uint8_t
{
    WPT_Default                                    = 0,
    WPT_ExcludeAllShaderOffsets                    = 1,
    WPT_CameraRelative                             = 2,
    WPT_CameraRelativeNoOffsets                    = 3,
    WPT_MAX                                        = 4

};


// Enum  /Script/Engine.EMaterialFunctionUsage
enum class EMaterialFunctionUsage : uint8_t
{
    Default                                        = 0,
    MaterialLayer                                  = 1,
    MaterialLayerBlend                             = 2,
    EMaterialFunctionUsage_MAX                     = 3

};


// Enum  /Script/Engine.EDawnSpecialMaterial
enum class EDawnSpecialMaterial : uint8_t
{
    SM_None                                        = 0,
    SM_BlendNormal                                 = 1,
    SM_MAX                                         = 2

};


// Enum  /Script/Engine.EMaterialUsage
enum class EMaterialUsage : uint8_t
{
    MATUSAGE_SkeletalMesh                          = 0,
    MATUSAGE_ParticleSprites                       = 1,
    MATUSAGE_BeamTrails                            = 2,
    MATUSAGE_MeshParticles                         = 3,
    MATUSAGE_StaticLighting                        = 4,
    MATUSAGE_MorphTargets                          = 5,
    MATUSAGE_SplineMesh                            = 6,
    MATUSAGE_InstancedStaticMeshes                 = 7,
    MATUSAGE_MergedInstancedStaticMeshes           = 8,
    MATUSAGE_GeometryCollections                   = 9,
    MATUSAGE_Clothing                              = 10,
    MATUSAGE_NiagaraSprites                        = 11,
    MATUSAGE_NiagaraRibbons                        = 12,
    MATUSAGE_NiagaraMeshParticles                  = 13,
    MATUSAGE_GeometryCache                         = 14,
    MATUSAGE_Water                                 = 15,
    MATUSAGE_HairStrands                           = 16,
    MATUSAGE_LidarPointCloud                       = 17,
    MATUSAGE_VirtualHeightfieldMesh                = 18,
    MATUSAGE_MAX                                   = 19

};


// Enum  /Script/Engine.EMaterialLayerLinkState
enum class EMaterialLayerLinkState : uint8_t
{
    Uninitialized                                  = 0,
    LinkedToParent                                 = 1,
    UnlinkedFromParent                             = 2,
    NotFromParent                                  = 3,
    EMaterialLayerLinkState_MAX                    = 4

};


// Enum  /Script/Engine.EMaterialParameterAssociation
enum class EMaterialParameterAssociation : uint8_t
{
    LayerParameter                                 = 0,
    BlendParameter                                 = 1,
    GlobalParameter                                = 2,
    EMaterialParameterAssociation_MAX              = 3

};


// Enum  /Script/Engine.EMaterialMergeType
enum class EMaterialMergeType : uint8_t
{
    MaterialMergeType_Default                      = 0,
    MaterialMergeType_Simplygon                    = 1,
    MaterialMergeType_MAX                          = 2

};


// Enum  /Script/Engine.ETextureSizingType
enum class ETextureSizingType : uint8_t
{
    TextureSizingType_UseSingleTextureSize         = 0,
    TextureSizingType_UseAutomaticBiasedSizes      = 1,
    TextureSizingType_UseManualOverrideTextureSize = 2,
    TextureSizingType_UseSimplygonAutomaticSizing  = 3,
    TextureSizingType_MAX                          = 4

};


// Enum  /Script/Engine.ESceneTextureId
enum class ESceneTextureId : uint8_t
{
    PPI_SceneColor                                 = 0,
    PPI_SceneDepth                                 = 1,
    PPI_DiffuseColor                               = 2,
    PPI_SpecularColor                              = 3,
    PPI_SubsurfaceColor                            = 4,
    PPI_BaseColor                                  = 5,
    PPI_Specular                                   = 6,
    PPI_Metallic                                   = 7,
    PPI_WorldNormal                                = 8,
    PPI_SeparateTranslucency                       = 9,
    PPI_Opacity                                    = 10,
    PPI_Roughness                                  = 11,
    PPI_MaterialAO                                 = 12,
    PPI_CustomDepth                                = 13,
    PPI_PostProcessInput0                          = 14,
    PPI_PostProcessInput1                          = 15,
    PPI_PostProcessInput2                          = 16,
    PPI_PostProcessInput3                          = 17,
    PPI_PostProcessInput4                          = 18,
    PPI_PostProcessInput5                          = 19,
    PPI_PostProcessInput6                          = 20,
    PPI_DecalMask                                  = 21,
    PPI_ShadingModelColor                          = 22,
    PPI_ShadingModelID                             = 23,
    PPI_AmbientOcclusion                           = 24,
    PPI_CustomStencil                              = 25,
    PPI_StoredBaseColor                            = 26,
    PPI_StoredSpecular                             = 27,
    PPI_Velocity                                   = 28,
    PPI_WorldTangent                               = 29,
    PPI_Anisotropy                                 = 30,
    PPI_PersistentSceneColor                       = 31,
    PPI_MAX                                        = 32

};


// Enum  /Script/Engine.EMaterialDomain
enum class EMaterialDomain : uint8_t
{
    MD_Surface                                     = 0,
    MD_DeferredDecal                               = 1,
    MD_LightFunction                               = 2,
    MD_Volume                                      = 3,
    MD_PostProcess                                 = 4,
    MD_UI                                          = 5,
    MD_RuntimeVirtualTexture                       = 6,
    MD_MAX                                         = 7

};


// Enum  /Script/Engine.EMeshInstancingReplacementMethod
enum class EMeshInstancingReplacementMethod : uint8_t
{
    RemoveOriginalActors                           = 0,
    KeepOriginalActorsAsEditorOnly                 = 1,
    EMeshInstancingReplacementMethod_MAX           = 2

};


// Enum  /Script/Engine.EUVOutput
enum class EUVOutput : uint8_t
{
    DoNotOutputChannel                             = 0,
    OutputChannel                                  = 1,
    EUVOutput_MAX                                  = 2

};


// Enum  /Script/Engine.EMeshMergeType
enum class EMeshMergeType : uint8_t
{
    MeshMergeType_Default                          = 0,
    MeshMergeType_MergeActor                       = 1,
    MeshMergeType_MAX                              = 2

};


// Enum  /Script/Engine.EMeshLODSelectionType
enum class EMeshLODSelectionType : uint8_t
{
    AllLODs                                        = 0,
    SpecificLOD                                    = 1,
    CalculateLOD                                   = 2,
    LowestDetailLOD                                = 3,
    EMeshLODSelectionType_MAX                      = 4

};


// Enum  /Script/Engine.EProxyNormalComputationMethod
enum class EProxyNormalComputationMethod : uint8_t
{
    AngleWeighted                                  = 0,
    AreaWeighted                                   = 1,
    EqualWeighted                                  = 2,
    EProxyNormalComputationMethod_MAX              = 3

};


// Enum  /Script/Engine.ELandscapeCullingPrecision
enum class ELandscapeCullingPrecision : uint8_t
{
    High                                           = 0,
    Medium                                         = 1,
    Low                                            = 2,
    ELandscapeCullingPrecision_MAX                 = 3

};


// Enum  /Script/Engine.EStaticMeshReductionTerimationCriterion
enum class EStaticMeshReductionTerimationCriterion : uint8_t
{
    Triangles                                      = 0,
    Vertices                                       = 1,
    Any                                            = 2,
    EStaticMeshReductionTerimationCriterion_MAX    = 3

};


// Enum  /Script/Engine.EMeshFeatureImportance
enum class EMeshFeatureImportance : uint8_t
{
    Off                                            = 0,
    Lowest                                         = 1,
    Low                                            = 2,
    Normal                                         = 3,
    High                                           = 4,
    Highest                                        = 5,
    EMeshFeatureImportance_MAX                     = 6

};


// Enum  /Script/Engine.EVertexPaintAxis
enum class EVertexPaintAxis : uint8_t
{
    X                                              = 0,
    Y                                              = 1,
    Z                                              = 2,
    EVertexPaintAxis_MAX                           = 3

};


// Enum  /Script/Engine.EMicroTransactionResult
enum class EMicroTransactionResult : uint8_t
{
    MTR_Succeeded                                  = 0,
    MTR_Failed                                     = 1,
    MTR_Canceled                                   = 2,
    MTR_RestoredFromServer                         = 3,
    MTR_MAX                                        = 4

};


// Enum  /Script/Engine.EMicroTransactionDelegate
enum class EMicroTransactionDelegate : uint8_t
{
    MTD_PurchaseQueryComplete                      = 0,
    MTD_PurchaseComplete                           = 1,
    MTD_MAX                                        = 2

};


// Enum  /Script/Engine.FNavigationSystemRunMode
enum class FNavigationSystemRunMode : uint8_t
{
    InvalidMode                                    = 0,
    GameMode                                       = 1,
    EditorMode                                     = 2,
    SimulationMode                                 = 3,
    PIEMode                                        = 4,
    InferFromWorldMode                             = 5,
    FNavigationSystemRunMode_MAX                   = 6

};


// Enum  /Script/Engine.ENavigationQueryResult
enum class ENavigationQueryResult : uint8_t
{
    Invalid                                        = 0,
    Error                                          = 1,
    Fail                                           = 2,
    Success                                        = 3,
    ENavigationQueryResult_MAX                     = 4

};


// Enum  /Script/Engine.ENavPathEvent
enum class ENavPathEvent : uint8_t
{
    Cleared                                        = 0,
    NewPath                                        = 1,
    UpdatedDueToGoalMoved                          = 2,
    UpdatedDueToNavigationChanged                  = 3,
    Invalidated                                    = 4,
    RePathFailed                                   = 5,
    MetaPathUpdate                                 = 6,
    Custom                                         = 7,
    ENavPathEvent_MAX                              = 8

};


// Enum  /Script/Engine.ENavDataGatheringModeConfig
enum class ENavDataGatheringModeConfig : uint8_t
{
    Invalid                                        = 0,
    Instant                                        = 1,
    Lazy                                           = 2,
    ENavDataGatheringModeConfig_MAX                = 3

};


// Enum  /Script/Engine.ENavDataGatheringMode
enum class ENavDataGatheringMode : uint8_t
{
    Default                                        = 0,
    Instant                                        = 1,
    Lazy                                           = 2,
    ENavDataGatheringMode_MAX                      = 3

};


// Enum  /Script/Engine.ENavigationOptionFlag
enum class ENavigationOptionFlag : uint8_t
{
    Default                                        = 0,
    Enable                                         = 1,
    Disable                                        = 2,
    MAX                                            = 3

};


// Enum  /Script/Engine.ENavLinkDirection
enum class ENavLinkDirection : uint8_t
{
    BothWays                                       = 0,
    LeftToRight                                    = 1,
    RightToLeft                                    = 2,
    ENavLinkDirection_MAX                          = 3

};


// Enum  /Script/Engine.EEmitterRenderMode
enum class EEmitterRenderMode : uint8_t
{
    ERM_Normal                                     = 0,
    ERM_Point                                      = 1,
    ERM_Cross                                      = 2,
    ERM_LightsOnly                                 = 3,
    ERM_None                                       = 4,
    ERM_MAX                                        = 5

};


// Enum  /Script/Engine.EParticleSubUVInterpMethod
enum class EParticleSubUVInterpMethod : uint8_t
{
    PSUVIM_None                                    = 0,
    PSUVIM_Linear                                  = 1,
    PSUVIM_Linear_Blend                            = 2,
    PSUVIM_Random                                  = 3,
    PSUVIM_Random_Blend                            = 4,
    PSUVIM_MAX                                     = 5

};


// Enum  /Script/Engine.EParticleBurstMethod
enum class EParticleBurstMethod : uint8_t
{
    EPBM_Instant                                   = 0,
    EPBM_Interpolated                              = 1,
    EPBM_MAX                                       = 2

};


// Enum  /Script/Engine.EParticleSystemInsignificanceReaction
enum class EParticleSystemInsignificanceReaction : uint8_t
{
    Auto                                           = 0,
    Complete                                       = 1,
    DisableTick                                    = 2,
    DisableTickAndKill                             = 3,
    Num                                            = 4,
    EParticleSystemInsignificanceReaction_MAX      = 5

};


// Enum  /Script/Engine.EParticleSignificanceLevel
enum class EParticleSignificanceLevel : uint8_t
{
    Low                                            = 0,
    Medium                                         = 1,
    High                                           = 2,
    Critical                                       = 3,
    Num                                            = 4,
    EParticleSignificanceLevel_MAX                 = 5

};


// Enum  /Script/Engine.EParticleDetailMode
enum class EParticleDetailMode : uint8_t
{
    PDM_Low                                        = 0,
    PDM_Medium                                     = 1,
    PDM_High                                       = 2,
    PDM_MAX                                        = 3

};


// Enum  /Script/Engine.EParticleSourceSelectionMethod
enum class EParticleSourceSelectionMethod : uint8_t
{
    EPSSM_Random                                   = 0,
    EPSSM_Sequential                               = 1,
    EPSSM_MAX                                      = 2

};


// Enum  /Script/Engine.EModuleType
enum class EModuleType : uint8_t
{
    EPMT_General                                   = 0,
    EPMT_TypeData                                  = 1,
    EPMT_Beam                                      = 2,
    EPMT_Trail                                     = 3,
    EPMT_Spawn                                     = 4,
    EPMT_Required                                  = 5,
    EPMT_Event                                     = 6,
    EPMT_Light                                     = 7,
    EPMT_SubUV                                     = 8,
    EPMT_MAX                                       = 9

};


// Enum  /Script/Engine.EAttractorParticleSelectionMethod
enum class EAttractorParticleSelectionMethod : uint8_t
{
    EAPSM_Random                                   = 0,
    EAPSM_Sequential                               = 1,
    EAPSM_MAX                                      = 2

};


// Enum  /Script/Engine.Beam2SourceTargetTangentMethod
enum class Beam2SourceTargetTangentMethod : uint8_t
{
    PEB2STTM_Direct                                = 0,
    PEB2STTM_UserSet                               = 1,
    PEB2STTM_Distribution                          = 2,
    PEB2STTM_Emitter                               = 3,
    PEB2STTM_MAX                                   = 4

};


// Enum  /Script/Engine.Beam2SourceTargetMethod
enum class Beam2SourceTargetMethod : uint8_t
{
    PEB2STM_Default                                = 0,
    PEB2STM_UserSet                                = 1,
    PEB2STM_Emitter                                = 2,
    PEB2STM_Particle                               = 3,
    PEB2STM_Actor                                  = 4,
    PEB2STM_MAX                                    = 5

};


// Enum  /Script/Engine.BeamModifierType
enum class BeamModifierType : uint8_t
{
    PEB2MT_Source                                  = 0,
    PEB2MT_Target                                  = 1,
    PEB2MT_MAX                                     = 2

};


// Enum  /Script/Engine.EParticleCameraOffsetUpdateMethod
enum class EParticleCameraOffsetUpdateMethod : uint8_t
{
    EPCOUM_DirectSet                               = 0,
    EPCOUM_Additive                                = 1,
    EPCOUM_Scalar                                  = 2,
    EPCOUM_MAX                                     = 3

};


// Enum  /Script/Engine.EParticleCollisionComplete
enum class EParticleCollisionComplete : uint8_t
{
    EPCC_Kill                                      = 0,
    EPCC_Freeze                                    = 1,
    EPCC_HaltCollisions                            = 2,
    EPCC_FreezeTranslation                         = 3,
    EPCC_FreezeRotation                            = 4,
    EPCC_FreezeMovement                            = 5,
    EPCC_MAX                                       = 6

};


// Enum  /Script/Engine.EParticleCollisionResponse
enum class EParticleCollisionResponse : uint8_t
{
    Bounce                                         = 0,
    Stop                                           = 1,
    Kill                                           = 2,
    EParticleCollisionResponse_MAX                 = 3

};


// Enum  /Script/Engine.ELocationBoneSocketSelectionMethod
enum class ELocationBoneSocketSelectionMethod : uint8_t
{
    BONESOCKETSEL_Sequential                       = 0,
    BONESOCKETSEL_Random                           = 1,
    BONESOCKETSEL_MAX                              = 2

};


// Enum  /Script/Engine.ELocationBoneSocketSource
enum class ELocationBoneSocketSource : uint8_t
{
    BONESOCKETSOURCE_Bones                         = 0,
    BONESOCKETSOURCE_Sockets                       = 1,
    BONESOCKETSOURCE_MAX                           = 2

};


// Enum  /Script/Engine.ELocationEmitterSelectionMethod
enum class ELocationEmitterSelectionMethod : uint8_t
{
    ELESM_Random                                   = 0,
    ELESM_Sequential                               = 1,
    ELESM_MAX                                      = 2

};


// Enum  /Script/Engine.CylinderHeightAxis
enum class CylinderHeightAxis : uint8_t
{
    PMLPC_HEIGHTAXIS_X                             = 0,
    PMLPC_HEIGHTAXIS_Y                             = 1,
    PMLPC_HEIGHTAXIS_Z                             = 2,
    PMLPC_HEIGHTAXIS_MAX                           = 3

};


// Enum  /Script/Engine.ELocationSkelVertSurfaceSource
enum class ELocationSkelVertSurfaceSource : uint8_t
{
    VERTSURFACESOURCE_Vert                         = 0,
    VERTSURFACESOURCE_Surface                      = 1,
    VERTSURFACESOURCE_MAX                          = 2

};


// Enum  /Script/Engine.EOrbitChainMode
enum class EOrbitChainMode : uint8_t
{
    EOChainMode_Add                                = 0,
    EOChainMode_Scale                              = 1,
    EOChainMode_Link                               = 2,
    EOChainMode_MAX                                = 3

};


// Enum  /Script/Engine.EParticleAxisLock
enum class EParticleAxisLock : uint8_t
{
    EPAL_NONE                                      = 0,
    EPAL_X                                         = 1,
    EPAL_Y                                         = 2,
    EPAL_Z                                         = 3,
    EPAL_NEGATIVE_X                                = 4,
    EPAL_NEGATIVE_Y                                = 5,
    EPAL_NEGATIVE_Z                                = 6,
    EPAL_ROTATE_X                                  = 7,
    EPAL_ROTATE_Y                                  = 8,
    EPAL_ROTATE_Z                                  = 9,
    EPAL_MAX                                       = 10

};


// Enum  /Script/Engine.EEmitterDynamicParameterValue
enum class EEmitterDynamicParameterValue : uint8_t
{
    EDPV_UserSet                                   = 0,
    EDPV_AutoSet                                   = 1,
    EDPV_VelocityX                                 = 2,
    EDPV_VelocityY                                 = 3,
    EDPV_VelocityZ                                 = 4,
    EDPV_VelocityMag                               = 5,
    EDPV_MAX                                       = 6

};


// Enum  /Script/Engine.EEmitterNormalsMode
enum class EEmitterNormalsMode : uint8_t
{
    ENM_CameraFacing                               = 0,
    ENM_Spherical                                  = 1,
    ENM_Cylindrical                                = 2,
    ENM_MAX                                        = 3

};


// Enum  /Script/Engine.EParticleSortMode
enum class EParticleSortMode : uint8_t
{
    PSORTMODE_None                                 = 0,
    PSORTMODE_ViewProjDepth                        = 1,
    PSORTMODE_DistanceToView                       = 2,
    PSORTMODE_Age_OldestFirst                      = 3,
    PSORTMODE_Age_NewestFirst                      = 4,
    PSORTMODE_MAX                                  = 5

};


// Enum  /Script/Engine.EParticleUVFlipMode
enum class EParticleUVFlipMode : uint8_t
{
    None                                           = 0,
    FlipUV                                         = 1,
    FlipUOnly                                      = 2,
    FlipVOnly                                      = 3,
    RandomFlipUV                                   = 4,
    RandomFlipUOnly                                = 5,
    RandomFlipVOnly                                = 6,
    RandomFlipUVIndependent                        = 7,
    EParticleUVFlipMode_MAX                        = 8

};


// Enum  /Script/Engine.ETrail2SourceMethod
enum class ETrail2SourceMethod : uint8_t
{
    PET2SRCM_Default                               = 0,
    PET2SRCM_Particle                              = 1,
    PET2SRCM_Actor                                 = 2,
    PET2SRCM_MAX                                   = 3

};


// Enum  /Script/Engine.EBeamTaperMethod
enum class EBeamTaperMethod : uint8_t
{
    PEBTM_None                                     = 0,
    PEBTM_Full                                     = 1,
    PEBTM_Partial                                  = 2,
    PEBTM_MAX                                      = 3

};


// Enum  /Script/Engine.EBeam2Method
enum class EBeam2Method : uint8_t
{
    PEB2M_Distance                                 = 0,
    PEB2M_Target                                   = 1,
    PEB2M_Branch                                   = 2,
    PEB2M_MAX                                      = 3

};


// Enum  /Script/Engine.EMeshCameraFacingOptions
enum class EMeshCameraFacingOptions : uint8_t
{
    XAxisFacing_NoUp                               = 0,
    XAxisFacing_ZUp                                = 1,
    XAxisFacing_NegativeZUp                        = 2,
    XAxisFacing_YUp                                = 3,
    XAxisFacing_NegativeYUp                        = 4,
    LockedAxis_ZAxisFacing                         = 5,
    LockedAxis_NegativeZAxisFacing                 = 6,
    LockedAxis_YAxisFacing                         = 7,
    LockedAxis_NegativeYAxisFacing                 = 8,
    VelocityAligned_ZAxisFacing                    = 9,
    VelocityAligned_NegativeZAxisFacing            = 10,
    VelocityAligned_YAxisFacing                    = 11,
    VelocityAligned_NegativeYAxisFacing            = 12,
    EMeshCameraFacingOptions_MAX                   = 13

};


// Enum  /Script/Engine.EMeshCameraFacingUpAxis
enum class EMeshCameraFacingUpAxis : uint8_t
{
    CameraFacing_NoneUP                            = 0,
    CameraFacing_ZUp                               = 1,
    CameraFacing_NegativeZUp                       = 2,
    CameraFacing_YUp                               = 3,
    CameraFacing_NegativeYUp                       = 4,
    CameraFacing_MAX                               = 5

};


// Enum  /Script/Engine.EMeshScreenAlignment
enum class EMeshScreenAlignment : uint8_t
{
    PSMA_MeshFaceCameraWithRoll                    = 0,
    PSMA_MeshFaceCameraWithSpin                    = 1,
    PSMA_MeshFaceCameraWithLockedAxis              = 2,
    PSMA_MAX                                       = 3

};


// Enum  /Script/Engine.ETrailsRenderAxisOption
enum class ETrailsRenderAxisOption : uint8_t
{
    Trails_CameraUp                                = 0,
    Trails_SourceUp                                = 1,
    Trails_WorldUp                                 = 2,
    Trails_MAX                                     = 3

};


// Enum  /Script/Engine.EParticleScreenAlignment
enum class EParticleScreenAlignment : uint8_t
{
    PSA_FacingCameraPosition                       = 0,
    PSA_Square                                     = 1,
    PSA_Rectangle                                  = 2,
    PSA_Velocity                                   = 3,
    PSA_AwayFromCenter                             = 4,
    PSA_TypeSpecific                               = 5,
    PSA_FacingCameraDistanceBlend                  = 6,
    PSA_MAX                                        = 7

};


// Enum  /Script/Engine.EParticleSystemOcclusionBoundsMethod
enum class EParticleSystemOcclusionBoundsMethod : uint8_t
{
    EPSOBM_None                                    = 0,
    EPSOBM_ParticleBounds                          = 1,
    EPSOBM_CustomBounds                            = 2,
    EPSOBM_MAX                                     = 3

};


// Enum  /Script/Engine.ParticleSystemLODMethod
enum class ParticleSystemLODMethod : uint8_t
{
    PARTICLESYSTEMLODMETHOD_Automatic              = 0,
    PARTICLESYSTEMLODMETHOD_DirectSet              = 1,
    PARTICLESYSTEMLODMETHOD_ActivateAutomatic      = 2,
    PARTICLESYSTEMLODMETHOD_MAX                    = 3

};


// Enum  /Script/Engine.EParticleSystemUpdateMode
enum class EParticleSystemUpdateMode : uint8_t
{
    EPSUM_RealTime                                 = 0,
    EPSUM_FixedTime                                = 1,
    EPSUM_MAX                                      = 2

};


// Enum  /Script/Engine.EParticleEventType
enum class EParticleEventType : uint8_t
{
    EPET_Any                                       = 0,
    EPET_Spawn                                     = 1,
    EPET_Death                                     = 2,
    EPET_Collision                                 = 3,
    EPET_Burst                                     = 4,
    EPET_Blueprint                                 = 5,
    EPET_MAX                                       = 6

};


// Enum  /Script/Engine.ParticleReplayState
enum class ParticleReplayState : uint8_t
{
    PRS_Disabled                                   = 0,
    PRS_Capturing                                  = 1,
    PRS_Replaying                                  = 2,
    PRS_MAX                                        = 3

};


// Enum  /Script/Engine.EParticleSysParamType
enum class EParticleSysParamType : uint8_t
{
    PSPT_None                                      = 0,
    PSPT_Scalar                                    = 1,
    PSPT_ScalarRand                                = 2,
    PSPT_Vector                                    = 3,
    PSPT_VectorRand                                = 4,
    PSPT_Color                                     = 5,
    PSPT_Actor                                     = 6,
    PSPT_Material                                  = 7,
    PSPT_VectorUnitRand                            = 8,
    PSPT_MAX                                       = 9

};


// Enum  /Script/Engine.ESettingsLockedAxis
enum class ESettingsLockedAxis : uint8_t
{
    None                                           = 0,
    X                                              = 1,
    Y                                              = 2,
    Z                                              = 3,
    Invalid                                        = 4,
    ESettingsLockedAxis_MAX                        = 5

};


// Enum  /Script/Engine.ESettingsDOF
enum class ESettingsDOF : uint8_t
{
    Full3D                                         = 0,
    YZPlane                                        = 1,
    XZPlane                                        = 2,
    XYPlane                                        = 3,
    ESettingsDOF_MAX                               = 4

};


// Enum  /Script/Engine.ERendererStencilMask
enum class ERendererStencilMask : uint8_t
{
    ERSM_Default                                   = 0,
    ERSM                                           = 1,
    ERSM                                           = 2,
    ERSM                                           = 3,
    ERSM                                           = 4,
    ERSM                                           = 5,
    ERSM                                           = 6,
    ERSM                                           = 7,
    ERSM                                           = 8,
    ERSM                                           = 9,
    ERSM_MAX                                       = 10

};


// Enum  /Script/Engine.EHasCustomNavigableGeometry
enum class EHasCustomNavigableGeometry : uint8_t
{
    No                                             = 0,
    Yes                                            = 1,
    EvenIfNotCollidable                            = 2,
    DontExport                                     = 3,
    EHasCustomNavigableGeometry_MAX                = 4

};


// Enum  /Script/Engine.ECanBeCharacterBase
enum class ECanBeCharacterBase : uint8_t
{
    ECB_No                                         = 0,
    ECB_Yes                                        = 1,
    ECB_Owner                                      = 2,
    ECB_MAX                                        = 3

};


// Enum  /Script/Engine.EQuarztQuantizationReference
enum class EQuarztQuantizationReference : uint8_t
{
    BarRelative                                    = 0,
    TransportRelative                              = 1,
    CurrentTimeRelative                            = 2,
    Count                                          = 3,
    EQuarztQuantizationReference_MAX               = 4

};


// Enum  /Script/Engine.EQuartzDelegateType
enum class EQuartzDelegateType : uint8_t
{
    MetronomeTick                                  = 0,
    CommandEvent                                   = 1,
    Count                                          = 2,
    EQuartzDelegateType_MAX                        = 3

};


// Enum  /Script/Engine.EQuartzTimeSignatureQuantization
enum class EQuartzTimeSignatureQuantization : uint8_t
{
    HalfNote                                       = 0,
    QuarterNote                                    = 1,
    EighthNote                                     = 2,
    SixteenthNote                                  = 3,
    ThirtySecondNote                               = 4,
    Count                                          = 5,
    EQuartzTimeSignatureQuantization_MAX           = 6

};


// Enum  /Script/Engine.EMobileReflectionCompression
enum class EMobileReflectionCompression : uint8_t
{
    Default                                        = 0,
    On                                             = 1,
    Off                                            = 2,
    EMobileReflectionCompression_MAX               = 3

};


// Enum  /Script/Engine.EReflectionSourceType
enum class EReflectionSourceType : uint8_t
{
    CapturedScene                                  = 0,
    SpecifiedCubemap                               = 1,
    ComputeData                                    = 2,
    EReflectionSourceType_MAX                      = 3

};


// Enum  /Script/Engine.EAntiPeekMethod
enum class EAntiPeekMethod : uint8_t
{
    APM_None                                       = 0,
    APM_Dynamic                                    = 1,
    APM_Static                                     = 2,
    APM_MAX                                        = 3

};


// Enum  /Script/Engine.ESkyNormalizationMethod
enum class ESkyNormalizationMethod : uint8_t
{
    SNM_Default                                    = 0,
    SNM_BaseOnDiffuseSH                            = 1,
    SNM_Condition                                  = 2,
    SNM_GOW                                        = 3,
    SNM_MAX                                        = 4

};


// Enum  /Script/Engine.EDirLightShadowBiasMethod
enum class EDirLightShadowBiasMethod : uint8_t
{
    DLSBM_Default                                  = 0,
    DLSBM_Receiver                                 = 1,
    DLSBM_MAX                                      = 2

};


// Enum  /Script/Engine.EDefaultBackBufferPixelFormat
enum class EDefaultBackBufferPixelFormat : uint8_t
{
    DBBPF_B8G8R8A8                                 = 0,
    DBBPF_A16B16G16R16_DEPRECATED                  = 1,
    DBBPF_FloatRGB_DEPRECATED                      = 2,
    DBBPF_FloatRGBA                                = 3,
    DBBPF_A2B10G10R10                              = 4,
    DBBPF_MAX                                      = 5

};


// Enum  /Script/Engine.EAutoExposureMethodUI
enum class EAutoExposureMethodUI : uint8_t
{
    AEM_Histogram                                  = 0,
    AEM_Basic                                      = 1,
    AEM_Manual                                     = 2,
    AEM_MAX                                        = 3

};


// Enum  /Script/Engine.EAlphaChannelMode
enum class EAlphaChannelMode : uint8_t
{
    Disabled                                       = 0,
    LinearColorSpaceOnly                           = 1,
    AllowThroughTonemapper                         = 2,
    EAlphaChannelMode_MAX                          = 3

};


// Enum  /Script/Engine.EEarlyZPass
enum class EEarlyZPass : uint8_t
{
    None                                           = 0,
    OpaqueOnly                                     = 1,
    OpaqueAndMasked                                = 2,
    Auto                                           = 3,
    EEarlyZPass_MAX                                = 4

};


// Enum  /Script/Engine.ECustomDepthStencil
enum class ECustomDepthStencil : uint8_t
{
    Disabled                                       = 0,
    Enabled                                        = 1,
    EnabledOnDemand                                = 2,
    EnabledWithStencil                             = 3,
    ECustomDepthStencil_MAX                        = 4

};


// Enum  /Script/Engine.EMobileMSAASampleCount
enum class EMobileMSAASampleCount : uint8_t
{
    One                                            = 1,
    Two                                            = 2,
    Four                                           = 4,
    Eight                                          = 8,
    EMobileMSAASampleCount_MAX                     = 9

};


// Enum  /Script/Engine.ECompositingSampleCount
enum class ECompositingSampleCount : uint8_t
{
    One                                            = 1,
    Two                                            = 2,
    Four                                           = 4,
    Eight                                          = 8,
    ECompositingSampleCount_MAX                    = 9

};


// Enum  /Script/Engine.EClearSceneOptions
enum class EClearSceneOptions : uint8_t
{
    NoClear                                        = 0,
    HardwareClear                                  = 1,
    QuadAtMaxZ                                     = 2,
    EClearSceneOptions_MAX                         = 3

};


// Enum  /Script/Engine.EReporterLineStyle
enum class EReporterLineStyle : uint8_t
{
    Line                                           = 0,
    Dash                                           = 1,
    EReporterLineStyle_MAX                         = 2

};


// Enum  /Script/Engine.ELegendPosition
enum class ELegendPosition : uint8_t
{
    Outside                                        = 0,
    Inside                                         = 1,
    ELegendPosition_MAX                            = 2

};


// Enum  /Script/Engine.EGraphDataStyle
enum class EGraphDataStyle : uint8_t
{
    Lines                                          = 0,
    Filled                                         = 1,
    EGraphDataStyle_MAX                            = 2

};


// Enum  /Script/Engine.EGraphAxisStyle
enum class EGraphAxisStyle : uint8_t
{
    Lines                                          = 0,
    Notches                                        = 1,
    Grid                                           = 2,
    EGraphAxisStyle_MAX                            = 3

};


// Enum  /Script/Engine.ReverbPreset
enum class ReverbPreset : uint8_t
{
    REVERB_Default                                 = 0,
    REVERB_Bathroom                                = 1,
    REVERB_StoneRoom                               = 2,
    REVERB_Auditorium                              = 3,
    REVERB_ConcertHall                             = 4,
    REVERB_Cave                                    = 5,
    REVERB_Hallway                                 = 6,
    REVERB_StoneCorridor                           = 7,
    REVERB_Alley                                   = 8,
    REVERB_Forest                                  = 9,
    REVERB_City                                    = 10,
    REVERB_Mountains                               = 11,
    REVERB_Quarry                                  = 12,
    REVERB_Plain                                   = 13,
    REVERB_ParkingLot                              = 14,
    REVERB_SewerPipe                               = 15,
    REVERB_Underwater                              = 16,
    REVERB_SmallRoom                               = 17,
    REVERB_MediumRoom                              = 18,
    REVERB_LargeRoom                               = 19,
    REVERB_MediumHall                              = 20,
    REVERB_LargeHall                               = 21,
    REVERB_Plate                                   = 22,
    REVERB_MAX                                     = 23

};


// Enum  /Script/Engine.ERichCurveKeyTimeCompressionFormat
enum class ERichCurveKeyTimeCompressionFormat : uint8_t
{
    RCKTCF_uint16                                  = 0,
    RCKTCF_float32                                 = 1,
    RCKTCF_MAX                                     = 2

};


// Enum  /Script/Engine.ERichCurveCompressionFormat
enum class ERichCurveCompressionFormat : uint8_t
{
    RCCF_Empty                                     = 0,
    RCCF_Constant                                  = 1,
    RCCF_Linear                                    = 2,
    RCCF_Cubic                                     = 3,
    RCCF_Mixed                                     = 4,
    RCCF_Weighted                                  = 5,
    RCCF_MAX                                       = 6

};


// Enum  /Script/Engine.EConstraintTransform
enum class EConstraintTransform : uint8_t
{
    Absolute                                       = 0,
    Relative                                       = 1,
    EConstraintTransform_MAX                       = 2

};


// Enum  /Script/Engine.EControlConstraint
enum class EControlConstraint : uint8_t
{
    Orientation                                    = 0,
    Translation                                    = 1,
    MAX                                            = 2

};


// Enum  /Script/Engine.ERootMotionFinishVelocityMode
enum class ERootMotionFinishVelocityMode : uint8_t
{
    MaintainLastRootMotionVelocity                 = 0,
    SetVelocity                                    = 1,
    ClampVelocity                                  = 2,
    ERootMotionFinishVelocityMode_MAX              = 3

};


// Enum  /Script/Engine.ERootMotionSourceSettingsFlags
enum class ERootMotionSourceSettingsFlags : uint8_t
{
    UseSensitiveLiftoffCheck                       = 1,
    DisablePartialEndTick                          = 2,
    IgnoreZAccumulate                              = 4,
    ERootMotionSourceSettingsFlags_MAX             = 5

};


// Enum  /Script/Engine.ERootMotionSourceStatusFlags
enum class ERootMotionSourceStatusFlags : uint8_t
{
    Prepared                                       = 1,
    Finished                                       = 2,
    MarkedForRemoval                               = 4,
    ERootMotionSourceStatusFlags_MAX               = 5

};


// Enum  /Script/Engine.ERootMotionAccumulateMode
enum class ERootMotionAccumulateMode : uint8_t
{
    Override                                       = 0,
    Additive                                       = 1,
    ERootMotionAccumulateMode_MAX                  = 2

};


// Enum  /Script/Engine.ERuntimeVirtualTextureMainPassType
enum class ERuntimeVirtualTextureMainPassType : uint8_t
{
    Never                                          = 0,
    Exclusive                                      = 1,
    Always                                         = 2,
    ERuntimeVirtualTextureMainPassType_MAX         = 3

};


// Enum  /Script/Engine.ERuntimeVirtualTextureMaterialType
enum class ERuntimeVirtualTextureMaterialType : uint8_t
{
    BaseColor                                      = 0,
    BaseColor_Normal_DEPRECATED                    = 1,
    BaseColor_Normal_Specular                      = 2,
    BaseColor_Normal_Specular_YCoCg                = 3,
    BaseColor_Normal_Specular_Mask_YCoCg           = 4,
    WorldHeight                                    = 5,
    BaseColor_Normal_Specular_WorldHeight          = 6,
    Count                                          = 7,
    ERuntimeVirtualTextureMaterialType_MAX         = 8

};


// Enum  /Script/Engine.EMobilePlanarReflectionUsage
enum class EMobilePlanarReflectionUsage : uint8_t
{
    Both                                           = 0,
    PixelProjectedReflectionOnly                   = 1,
    EMobilePlanarReflectionUsage_MAX               = 2

};


// Enum  /Script/Engine.EMobilePixelProjectedReflectionQuality
enum class EMobilePixelProjectedReflectionQuality : uint8_t
{
    Disabled                                       = 0,
    BestPerformance                                = 1,
    BetterQuality                                  = 2,
    BestQuality                                    = 3,
    EMobilePixelProjectedReflectionQuality_MAX     = 4

};


// Enum  /Script/Engine.EMobilePlanarReflectionMode
enum class EMobilePlanarReflectionMode : uint8_t
{
    Usual                                          = 0,
    MobilePPRExclusive                             = 1,
    MobilePPR                                      = 2,
    EMobilePlanarReflectionMode_MAX                = 3

};


// Enum  /Script/Engine.EReflectedAndRefractedRayTracedShadows
enum class EReflectedAndRefractedRayTracedShadows : uint8_t
{
    Disabled                                       = 0,
    Hard_shadows                                   = 1,
    Area_shadows                                   = 2,
    EReflectedAndRefractedRayTracedShadows_MAX     = 3

};


// Enum  /Script/Engine.ERayTracingGlobalIlluminationType
enum class ERayTracingGlobalIlluminationType : uint8_t
{
    Disabled                                       = 0,
    BruteForce                                     = 1,
    FinalGather                                    = 2,
    ERayTracingGlobalIlluminationType_MAX          = 3

};


// Enum  /Script/Engine.ETranslucencyType
enum class ETranslucencyType : uint8_t
{
    Raster                                         = 0,
    RayTracing                                     = 1,
    ETranslucencyType_MAX                          = 2

};


// Enum  /Script/Engine.EReflectionsType
enum class EReflectionsType : uint8_t
{
    ScreenSpace                                    = 0,
    RayTracing                                     = 1,
    EReflectionsType_MAX                           = 2

};


// Enum  /Script/Engine.ELightUnits
enum class ELightUnits : uint8_t
{
    Unitless                                       = 0,
    Candelas                                       = 1,
    Lumens                                         = 2,
    ELightUnits_MAX                                = 3

};


// Enum  /Script/Engine.EBloomMethod
enum class EBloomMethod : uint8_t
{
    BM_SOG                                         = 0,
    BM_FFT                                         = 1,
    BM_MAX                                         = 2

};


// Enum  /Script/Engine.EAutoExposureMethod
enum class EAutoExposureMethod : uint8_t
{
    AEM_Histogram                                  = 0,
    AEM_Basic                                      = 1,
    AEM_Manual                                     = 2,
    AEM_MAX                                        = 3

};


// Enum  /Script/Engine.EAntiAliasingMethod
enum class EAntiAliasingMethod : uint8_t
{
    AAM_None                                       = 0,
    AAM_FXAA                                       = 1,
    AAM_TemporalAA                                 = 2,
    AAM_MSAA                                       = 3,
    AAM_SMAA                                       = 4,
    AAM_MAX                                        = 5

};


// Enum  /Script/Engine.EDepthOfFieldMethod
enum class EDepthOfFieldMethod : uint8_t
{
    DOFM_BokehDOF                                  = 0,
    DOFM_Gaussian                                  = 1,
    DOFM_CircleDOF                                 = 2,
    DOFM_MAX                                       = 3

};


// Enum  /Script/Engine.ESceneCapturePrimitiveRenderMode
enum class ESceneCapturePrimitiveRenderMode : uint8_t
{
    PRM_LegacySceneCapture                         = 0,
    PRM_RenderScenePrimitives                      = 1,
    PRM_UseShowOnlyList                            = 2,
    PRM_MAX                                        = 3

};


// Enum  /Script/Engine.EMaterialProperty
enum class EMaterialProperty : uint8_t
{
    MP_EmissiveColor                               = 0,
    MP_Opacity                                     = 1,
    MP_OpacityMask                                 = 2,
    MP_DiffuseColor                                = 3,
    MP_SpecularColor                               = 4,
    MP_BaseColor                                   = 5,
    MP_Metallic                                    = 6,
    MP_Specular                                    = 7,
    MP_Roughness                                   = 8,
    MP_Anisotropy                                  = 9,
    MP_Normal                                      = 10,
    MP_Tangent                                     = 11,
    MP_WorldPositionOffset                         = 12,
    MP_WorldDisplacement                           = 13,
    MP_TessellationMultiplier                      = 14,
    MP_SubsurfaceColor                             = 15,
    MP_CustomData0                                 = 16,
    MP_CustomData1                                 = 17,
    MP_AmbientOcclusion                            = 18,
    MP_Refraction                                  = 19,
    MP_CustomizedUVs0                              = 20,
    MP_CustomizedUVs1                              = 21,
    MP_CustomizedUVs2                              = 22,
    MP_CustomizedUVs3                              = 23,
    MP_CustomizedUVs4                              = 24,
    MP_CustomizedUVs5                              = 25,
    MP_CustomizedUVs6                              = 26,
    MP_CustomizedUVs7                              = 27,
    MP_PixelDepthOffset                            = 28,
    MP_ShadingModel                                = 29,
    MP_CustomDataVector0                           = 30,
    MP_CustomDataVector1                           = 31,
    MP_CustomDataVector2                           = 32,
    MP_CustomDataVector3                           = 33,
    MP_CustomDataVector4                           = 34,
    MP_CustomDataVector5                           = 35,
    MP_CustomDataVector6                           = 36,
    MP_CustomDataVector7                           = 37,
    MP_MaterialAttributes                          = 38,
    MP_CustomOutput                                = 39,
    MP_MAX                                         = 40

};


// Enum  /Script/Engine.EMaterialDynamicMode
enum class EMaterialDynamicMode : uint8_t
{
    EMDM_Default                                   = 0,
    EMDM_FirstPerson                               = 1,
    EMDM_SimpleLandscape                           = 2,
    EMDM_Count                                     = 3,
    EMDM_MAX                                       = 4

};


// Enum  /Script/Engine.EShadowCaptureLayer
enum class EShadowCaptureLayer : uint8_t
{
    Default                                        = 0,
    Character                                      = 1,
    Foliage                                        = 2,
    Grass                                          = 3,
    ShadowCaptureCustomLayer0                      = 4,
    ShadowCaptureCustomLayer1                      = 5,
    ShadowCaptureCustomLayer2                      = 6,
    ShadowCaptureCustomLayer3                      = 7,
    ShadowCaptureCustomLayer4                      = 8,
    ShadowCaptureCustomLayer5                      = 9,
    ShadowCaptureCustomLayer6                      = 10,
    ShadowCaptureCustomLayer7                      = 11,
    ShadowCaptureCustomLayer8                      = 12,
    ShadowCaptureCustomLayer9                      = 13,
    ShadowCaptureCustomLayer10                     = 14,
    ShadowCaptureCustomLayer11                     = 15,
    ShadowCaptureCustomLayer12                     = 16,
    ShadowCaptureCustomLayer13                     = 17,
    ShadowCaptureCustomLayer14                     = 18,
    ShadowCaptureCustomLayer15                     = 19,
    ShadowCaptureCustomLayer16                     = 20,
    ShadowCaptureCustomLayer17                     = 21,
    ShadowCaptureCustomLayer18                     = 22,
    ShadowCaptureCustomLayer19                     = 23,
    ShadowCaptureCustomLayer20                     = 24,
    ShadowCaptureCustomLayer21                     = 25,
    ShadowCaptureCustomLayer22                     = 26,
    ShadowCaptureCustomLayer23                     = 27,
    ShadowCaptureCustomLayer24                     = 28,
    ShadowCaptureCustomLayer25                     = 29,
    ShadowCaptureLayer_MAX                         = 30,
    EShadowCaptureLayer_MAX                        = 31

};


// Enum  /Script/Engine.ESkinCacheDefaultBehavior
enum class ESkinCacheDefaultBehavior : uint8_t
{
    Exclusive                                      = 0,
    Inclusive                                      = 1,
    ESkinCacheDefaultBehavior_MAX                  = 2

};


// Enum  /Script/Engine.ESkinCacheUsage
enum class ESkinCacheUsage : uint8_t
{
    Auto                                           = 0,
    Disabled                                       = 255,
    Enabled                                        = 1,
    ESkinCacheUsage_MAX                            = 256

};


// Enum  /Script/Engine.EPhysicsTransformUpdateMode
enum class EPhysicsTransformUpdateMode : uint8_t
{
    SimulationUpatesComponentTransform             = 0,
    ComponentTransformIsKinematic                  = 1,
    EPhysicsTransformUpdateMode_MAX                = 2

};


// Enum  /Script/Engine.EAnimationMode
enum class EAnimationMode : uint8_t
{
    AnimationBlueprint                             = 0,
    AnimationSingleNode                            = 1,
    AnimationCustomMode                            = 2,
    EAnimationMode_MAX                             = 3

};


// Enum  /Script/Engine.EKinematicBonesUpdateToPhysics
enum class EKinematicBonesUpdateToPhysics : uint8_t
{
    SkipSimulatingBones                            = 0,
    SkipAllBones                                   = 1,
    EKinematicBonesUpdateToPhysics_MAX             = 2

};


// Enum  /Script/Engine.ECustomBoneAttributeLookup
enum class ECustomBoneAttributeLookup : uint8_t
{
    BoneOnly                                       = 0,
    ImmediateParent                                = 1,
    ParentHierarchy                                = 2,
    ECustomBoneAttributeLookup_MAX                 = 3

};


// Enum  /Script/Engine.EClothMassMode
enum class EClothMassMode : uint8_t
{
    UniformMass                                    = 0,
    TotalMass                                      = 1,
    Density                                        = 2,
    MaxClothMassMode                               = 3,
    EClothMassMode_MAX                             = 4

};


// Enum  /Script/Engine.EAnimCurveType
enum class EAnimCurveType : uint8_t
{
    AttributeCurve                                 = 0,
    MaterialCurve                                  = 1,
    MorphTargetCurve                               = 2,
    MaxAnimCurveType                               = 3,
    EAnimCurveType_MAX                             = 4

};


// Enum  /Script/Engine.ESkeletalMeshSkinningImportVersions
enum class ESkeletalMeshSkinningImportVersions : uint8_t
{
    Before_Versionning                             = 0,
    SkeletalMeshBuildRefactor                      = 1,
    VersionPlusOne                                 = 2,
    LatestVersion                                  = 1,
    ESkeletalMeshSkinningImportVersions_MAX        = 3

};


// Enum  /Script/Engine.ESkeletalMeshGeoImportVersions
enum class ESkeletalMeshGeoImportVersions : uint8_t
{
    Before_Versionning                             = 0,
    SkeletalMeshBuildRefactor                      = 1,
    VersionPlusOne                                 = 2,
    LatestVersion                                  = 1,
    ESkeletalMeshGeoImportVersions_MAX             = 3

};


// Enum  /Script/Engine.EBoneFilterActionOption
enum class EBoneFilterActionOption : uint8_t
{
    Remove                                         = 0,
    Keep                                           = 1,
    Invalid                                        = 2,
    EBoneFilterActionOption_MAX                    = 3

};


// Enum  /Script/Engine.SkeletalMeshOptimizationImportance
enum class SkeletalMeshOptimizationImportance : uint8_t
{
    SMOI_Off                                       = 0,
    SMOI_Lowest                                    = 1,
    SMOI_Low                                       = 2,
    SMOI_Normal                                    = 3,
    SMOI_High                                      = 4,
    SMOI_Highest                                   = 5,
    SMOI_MAX                                       = 6

};


// Enum  /Script/Engine.SkeletalMeshOptimizationType
enum class SkeletalMeshOptimizationType : uint8_t
{
    SMOT_NumOfTriangles                            = 0,
    SMOT_MaxDeviation                              = 1,
    SMOT_TriangleOrDeviation                       = 2,
    SMOT_MAX                                       = 3

};


// Enum  /Script/Engine.SkeletalMeshTerminationCriterion
enum class SkeletalMeshTerminationCriterion : uint8_t
{
    SMTC_NumOfTriangles                            = 0,
    SMTC_NumOfVerts                                = 1,
    SMTC_TriangleOrVert                            = 2,
    SMTC_AbsNumOfTriangles                         = 3,
    SMTC_AbsNumOfVerts                             = 4,
    SMTC_AbsTriangleOrVert                         = 5,
    SMTC_MAX                                       = 6

};


// Enum  /Script/Engine.EBoneTranslationRetargetingMode
enum class EBoneTranslationRetargetingMode : uint8_t
{
    Animation                                      = 0,
    Skeleton                                       = 1,
    AnimationScaled                                = 2,
    AnimationRelative                              = 3,
    OrientAndScale                                 = 4,
    EBoneTranslationRetargetingMode_MAX            = 5

};


// Enum  /Script/Engine.EVertexOffsetUsageType
enum class EVertexOffsetUsageType : uint8_t
{
    None                                           = 0,
    PreSkinningOffset                              = 1,
    PostSkinningOffset                             = 2,
    EVertexOffsetUsageType_MAX                     = 3

};


// Enum  /Script/Engine.EBoneSpaces
enum class EBoneSpaces : uint8_t
{
    WorldSpace                                     = 0,
    ComponentSpace                                 = 1,
    EBoneSpaces_MAX                                = 2

};


// Enum  /Script/Engine.EVisibilityBasedAnimTickOption
enum class EVisibilityBasedAnimTickOption : uint8_t
{
    AlwaysTickPoseAndRefreshBones                  = 0,
    AlwaysTickPose                                 = 1,
    OnlyTickMontagesWhenNotRendered                = 2,
    OnlyTickPoseWhenRendered                       = 3,
    EVisibilityBasedAnimTickOption_MAX             = 4

};


// Enum  /Script/Engine.EPhysBodyOp
enum class EPhysBodyOp : uint8_t
{
    PBO_None                                       = 0,
    PBO_Term                                       = 1,
    PBO_MAX                                        = 2

};


// Enum  /Script/Engine.EBoneVisibilityStatus
enum class EBoneVisibilityStatus : uint8_t
{
    BVS_HiddenByParent                             = 0,
    BVS_Visible                                    = 1,
    BVS_ExplicitlyHidden                           = 2,
    BVS_MAX                                        = 3

};


// Enum  /Script/Engine.ESkyAtmosphereTransformMode
enum class ESkyAtmosphereTransformMode : uint8_t
{
    PlanetTopAtAbsoluteWorldOrigin                 = 0,
    PlanetTopAtComponentTransform                  = 1,
    PlanetCenterAtComponentTransform               = 2,
    ESkyAtmosphereTransformMode_MAX                = 3

};


// Enum  /Script/Engine.ESkyLightSourceType
enum class ESkyLightSourceType : uint8_t
{
    SLS_CapturedScene                              = 0,
    SLS_SpecifiedCubemap                           = 1,
    SLS_ComputedData                               = 2,
    SLS_MAX                                        = 3

};


// Enum  /Script/Engine.EPriorityAttenuationMethod
enum class EPriorityAttenuationMethod : uint8_t
{
    Linear                                         = 0,
    CustomCurve                                    = 1,
    Manual                                         = 2,
    EPriorityAttenuationMethod_MAX                 = 3

};


// Enum  /Script/Engine.ESubmixSendMethod
enum class ESubmixSendMethod : uint8_t
{
    Linear                                         = 0,
    CustomCurve                                    = 1,
    Manual                                         = 2,
    ESubmixSendMethod_MAX                          = 3

};


// Enum  /Script/Engine.EReverbSendMethod
enum class EReverbSendMethod : uint8_t
{
    Linear                                         = 0,
    CustomCurve                                    = 1,
    Manual                                         = 2,
    EReverbSendMethod_MAX                          = 3

};


// Enum  /Script/Engine.EAirAbsorptionMethod
enum class EAirAbsorptionMethod : uint8_t
{
    Linear                                         = 0,
    CustomCurve                                    = 1,
    EAirAbsorptionMethod_MAX                       = 2

};


// Enum  /Script/Engine.ESoundSpatializationAlgorithm
enum class ESoundSpatializationAlgorithm : uint8_t
{
    SPATIALIZATION_Default                         = 0,
    SPATIALIZATION_HRTF                            = 1,
    SPATIALIZATION_MAX                             = 2

};


// Enum  /Script/Engine.ESoundDistanceCalc
enum class ESoundDistanceCalc : uint8_t
{
    SOUNDDISTANCE_Normal                           = 0,
    SOUNDDISTANCE_InfiniteXYPlane                  = 1,
    SOUNDDISTANCE_InfiniteXZPlane                  = 2,
    SOUNDDISTANCE_InfiniteYZPlane                  = 3,
    SOUNDDISTANCE_MAX                              = 4

};


// Enum  /Script/Engine.EVirtualizationMode
enum class EVirtualizationMode : uint8_t
{
    Disabled                                       = 0,
    PlayWhenSilent                                 = 1,
    Restart                                        = 2,
    EVirtualizationMode_MAX                        = 3

};


// Enum  /Script/Engine.EConcurrencyVolumeScaleMode
enum class EConcurrencyVolumeScaleMode : uint8_t
{
    Default                                        = 0,
    Distance                                       = 1,
    Priority                                       = 2,
    EConcurrencyVolumeScaleMode_MAX                = 3

};


// Enum  /Script/Engine.EMaxConcurrentResolutionRule
enum class EMaxConcurrentResolutionRule : uint8_t
{
    PreventNew                                     = 0,
    StopOldest                                     = 1,
    StopFarthestThenPreventNew                     = 2,
    StopFarthestThenOldest                         = 3,
    StopLowestPriority                             = 4,
    StopQuietest                                   = 5,
    StopLowestPriorityThenPreventNew               = 6,
    Count                                          = 7,
    EMaxConcurrentResolutionRule_MAX               = 8

};


// Enum  /Script/Engine.ESoundGroup
enum class ESoundGroup : uint8_t
{
    SOUNDGROUP_Default                             = 0,
    SOUNDGROUP_Effects                             = 1,
    SOUNDGROUP_UI                                  = 2,
    SOUNDGROUP_Music                               = 3,
    SOUNDGROUP_Voice                               = 4,
    SOUNDGROUP_GameSoundGroup1                     = 5,
    SOUNDGROUP_GameSoundGroup2                     = 6,
    SOUNDGROUP_GameSoundGroup3                     = 7,
    SOUNDGROUP_GameSoundGroup4                     = 8,
    SOUNDGROUP_GameSoundGroup5                     = 9,
    SOUNDGROUP_GameSoundGroup6                     = 10,
    SOUNDGROUP_GameSoundGroup7                     = 11,
    SOUNDGROUP_GameSoundGroup8                     = 12,
    SOUNDGROUP_GameSoundGroup9                     = 13,
    SOUNDGROUP_GameSoundGroup10                    = 14,
    SOUNDGROUP_GameSoundGroup11                    = 15,
    SOUNDGROUP_GameSoundGroup12                    = 16,
    SOUNDGROUP_GameSoundGroup13                    = 17,
    SOUNDGROUP_GameSoundGroup14                    = 18,
    SOUNDGROUP_GameSoundGroup15                    = 19,
    SOUNDGROUP_GameSoundGroup16                    = 20,
    SOUNDGROUP_GameSoundGroup17                    = 21,
    SOUNDGROUP_GameSoundGroup18                    = 22,
    SOUNDGROUP_GameSoundGroup19                    = 23,
    SOUNDGROUP_GameSoundGroup20                    = 24,
    SOUNDGROUP_MAX                                 = 25

};


// Enum  /Script/Engine.EModulationRouting
enum class EModulationRouting : uint8_t
{
    Disable                                        = 0,
    Inherit                                        = 1,
    Override                                       = 2,
    EModulationRouting_MAX                         = 3

};


// Enum  /Script/Engine.ModulationParamMode
enum class ModulationParamMode : uint8_t
{
    MPM_Normal                                     = 0,
    MPM_Abs                                        = 1,
    MPM_Direct                                     = 2,
    MPM_MAX                                        = 3

};


// Enum  /Script/Engine.ESourceBusChannels
enum class ESourceBusChannels : uint8_t
{
    Mono                                           = 0,
    Stereo                                         = 1,
    ESourceBusChannels_MAX                         = 2

};


// Enum  /Script/Engine.ESourceBusSendLevelControlMethod
enum class ESourceBusSendLevelControlMethod : uint8_t
{
    Linear                                         = 0,
    CustomCurve                                    = 1,
    Manual                                         = 2,
    ESourceBusSendLevelControlMethod_MAX           = 3

};


// Enum  /Script/Engine.EGainParamMode
enum class EGainParamMode : uint8_t
{
    Linear                                         = 0,
    Decibels                                       = 1,
    EGainParamMode_MAX                             = 2

};


// Enum  /Script/Engine.EAudioSpectrumType
enum class EAudioSpectrumType : uint8_t
{
    MagnitudeSpectrum                              = 0,
    PowerSpectrum                                  = 1,
    Decibel                                        = 2,
    EAudioSpectrumType_MAX                         = 3

};


// Enum  /Script/Engine.EFFTWindowType
enum class EFFTWindowType : uint8_t
{
    None                                           = 0,
    Hamming                                        = 1,
    Hann                                           = 2,
    Blackman                                       = 3,
    EFFTWindowType_MAX                             = 4

};


// Enum  /Script/Engine.EFFTPeakInterpolationMethod
enum class EFFTPeakInterpolationMethod : uint8_t
{
    NearestNeighbor                                = 0,
    Linear                                         = 1,
    Quadratic                                      = 2,
    ConstantQ                                      = 3,
    EFFTPeakInterpolationMethod_MAX                = 4

};


// Enum  /Script/Engine.EFFTSize
enum class EFFTSize : uint8_t
{
    DefaultSize                                    = 0,
    Min                                            = 1,
    Small                                          = 2,
    Medium                                         = 3,
    Large                                          = 4,
    VeryLarge                                      = 5,
    Max                                            = 6

};


// Enum  /Script/Engine.ESubmixSendStage
enum class ESubmixSendStage : uint8_t
{
    PostDistanceAttenuation                        = 0,
    PreDistanceAttenuation                         = 1,
    ESubmixSendStage_MAX                           = 2

};


// Enum  /Script/Engine.ESendLevelControlMethod
enum class ESendLevelControlMethod : uint8_t
{
    Linear                                         = 0,
    CustomCurve                                    = 1,
    Manual                                         = 2,
    ESendLevelControlMethod_MAX                    = 3

};


// Enum  /Script/Engine.EAudioRecordingExportType
enum class EAudioRecordingExportType : uint8_t
{
    SoundWave                                      = 0,
    WavFile                                        = 1,
    EAudioRecordingExportType_MAX                  = 2

};


// Enum  /Script/Engine.EAudioSpectrumBandPresetType
enum class EAudioSpectrumBandPresetType : uint8_t
{
    KickDrum                                       = 0,
    SnareDrum                                      = 1,
    Voice                                          = 2,
    Cymbals                                        = 3,
    EAudioSpectrumBandPresetType_MAX               = 4

};


// Enum  /Script/Engine.ESoundWaveFFTSize
enum class ESoundWaveFFTSize : uint8_t
{
    VerySmall                                      = 0,
    Small                                          = 1,
    Medium                                         = 2,
    Large                                          = 3,
    VeryLarge                                      = 4,
    ESoundWaveFFTSize_MAX                          = 5

};


// Enum  /Script/Engine.EDecompressionType
enum class EDecompressionType : uint8_t
{
    DTYPE_Setup                                    = 0,
    DTYPE_Invalid                                  = 1,
    DTYPE_Preview                                  = 2,
    DTYPE_Native                                   = 3,
    DTYPE_RealTime                                 = 4,
    DTYPE_Procedural                               = 5,
    DTYPE_Xenon                                    = 6,
    DTYPE_Streaming                                = 7,
    DTYPE_MAX                                      = 8

};


// Enum  /Script/Engine.ESoundWaveLoadingBehavior
enum class ESoundWaveLoadingBehavior : uint8_t
{
    Inherited                                      = 0,
    RetainOnLoad                                   = 1,
    PrimeOnLoad                                    = 2,
    LoadOnDemand                                   = 3,
    ForceInline                                    = 4,
    Uninitialized                                  = 255,
    ESoundWaveLoadingBehavior_MAX                  = 256

};


// Enum  /Script/Engine.ESplineCoordinateSpace
enum class ESplineCoordinateSpace : uint8_t
{
    Local                                          = 0,
    World                                          = 1,
    ESplineCoordinateSpace_MAX                     = 2

};


// Enum  /Script/Engine.ESplinePointType
enum class ESplinePointType : uint8_t
{
    Linear                                         = 0,
    Curve                                          = 1,
    Constant                                       = 2,
    CurveClamped                                   = 3,
    CurveCustomTangent                             = 4,
    ESplinePointType_MAX                           = 5

};


// Enum  /Script/Engine.ESplineMeshAxis
enum class ESplineMeshAxis : uint8_t
{
    X                                              = 0,
    Y                                              = 1,
    Z                                              = 2,
    ESplineMeshAxis_MAX                            = 3

};


// Enum  /Script/Engine.EOptimizationType
enum class EOptimizationType : uint8_t
{
    OT_NumOfTriangles                              = 0,
    OT_MaxDeviation                                = 1,
    OT_MAX                                         = 2

};


// Enum  /Script/Engine.EImportanceLevel
enum class EImportanceLevel : uint8_t
{
    IL_Off                                         = 0,
    IL_Lowest                                      = 1,
    IL_Low                                         = 2,
    IL_Normal                                      = 3,
    IL_High                                        = 4,
    IL_Highest                                     = 5,
    TEMP_BROKEN2                                   = 6,
    EImportanceLevel_MAX                           = 7

};


// Enum  /Script/Engine.ENormalMode
enum class ENormalMode : uint8_t
{
    NM_PreserveSmoothingGroups                     = 0,
    NM_RecalculateNormals                          = 1,
    NM_RecalculateNormalsSmooth                    = 2,
    NM_RecalculateNormalsHard                      = 3,
    TEMP_BROKEN                                    = 4,
    ENormalMode_MAX                                = 5

};


// Enum  /Script/Engine.EStereoLayerShape
enum class EStereoLayerShape : uint8_t
{
    SLSH_QuadLayer                                 = 0,
    SLSH_CylinderLayer                             = 1,
    SLSH_CubemapLayer                              = 2,
    SLSH_EquirectLayer                             = 3,
    SLSH_MAX                                       = 4

};


// Enum  /Script/Engine.EStereoLayerType
enum class EStereoLayerType : uint8_t
{
    SLT_WorldLocked                                = 0,
    SLT_TrackerLocked                              = 1,
    SLT_FaceLocked                                 = 2,
    SLT_MAX                                        = 3

};


// Enum  /Script/Engine.EStreamingAssetUseScene
enum class EStreamingAssetUseScene : uint8_t
{
    SAUS_None                                      = 0,
    SAUS_FrontEnd                                  = 1,
    SAUS_InBattle                                  = 2,
    SAUS_MAX                                       = 3

};


// Enum  /Script/Engine.EOpacitySourceMode
enum class EOpacitySourceMode : uint8_t
{
    OSM_Alpha                                      = 0,
    OSM_ColorBrightness                            = 1,
    OSM_RedChannel                                 = 2,
    OSM_GreenChannel                               = 3,
    OSM_BlueChannel                                = 4,
    OSM_MAX                                        = 5

};


// Enum  /Script/Engine.ESubUVBoundingVertexCount
enum class ESubUVBoundingVertexCount : uint8_t
{
    BVC_FourVertices                               = 0,
    BVC_EightVertices                              = 1,
    BVC_MAX                                        = 2

};


// Enum  /Script/Engine.EVerticalTextAligment
enum class EVerticalTextAligment : uint8_t
{
    EVRTA_TextTop                                  = 0,
    EVRTA_TextCenter                               = 1,
    EVRTA_TextBottom                               = 2,
    EVRTA_QuadTop                                  = 3,
    EVRTA_MAX                                      = 4

};


// Enum  /Script/Engine.EHorizTextAligment
enum class EHorizTextAligment : uint8_t
{
    EHTA_Left                                      = 0,
    EHTA_Center                                    = 1,
    EHTA_Right                                     = 2,
    EHTA_MAX                                       = 3

};


// Enum  /Script/Engine.ETextureLossyCompressionAmount
enum class ETextureLossyCompressionAmount : uint8_t
{
    TLCA_Default                                   = 0,
    TLCA_None                                      = 1,
    TLCA_Lowest                                    = 2,
    TLCA_Low                                       = 3,
    TLCA_Medium                                    = 4,
    TLCA_High                                      = 5,
    TLCA_Highest                                   = 6,
    TLCA_MAX                                       = 7

};


// Enum  /Script/Engine.ETextureCompressionQuality
enum class ETextureCompressionQuality : uint8_t
{
    TCQ_Default                                    = 0,
    TCQ_Lowest                                     = 1,
    TCQ_Low                                        = 2,
    TCQ_Medium                                     = 3,
    TCQ_High                                       = 4,
    TCQ_Highest                                    = 5,
    TCQ_MAX                                        = 6

};


// Enum  /Script/Engine.ETextureSourceFormat
enum class ETextureSourceFormat : uint8_t
{
    TSF_Invalid                                    = 0,
    TSF_G8                                         = 1,
    TSF_BGRA8                                      = 2,
    TSF_BGRE8                                      = 3,
    TSF_RGBA16                                     = 4,
    TSF_RGBA16F                                    = 5,
    TSF_RGBA8                                      = 6,
    TSF_RGBE8                                      = 7,
    TSF_G16                                        = 8,
    TSF_MAX                                        = 9

};


// Enum  /Script/Engine.ETextureSourceArtType
enum class ETextureSourceArtType : uint8_t
{
    TSAT_Uncompressed                              = 0,
    TSAT_PNGCompressed                             = 1,
    TSAT_DDSFile                                   = 2,
    TSAT_MAX                                       = 3

};


// Enum  /Script/Engine.ECompositeTextureMode
enum class ECompositeTextureMode : uint8_t
{
    CTM_Disabled                                   = 0,
    CTM_NormalRoughnessToRed                       = 1,
    CTM_NormalRoughnessToGreen                     = 2,
    CTM_NormalRoughnessToBlue                      = 3,
    CTM_NormalRoughnessToAlpha                     = 4,
    CTM_MAX                                        = 5

};


// Enum  /Script/Engine.TextureAddress
enum class TextureAddress : uint8_t
{
    TA_Wrap                                        = 0,
    TA_Clamp                                       = 1,
    TA_Mirror                                      = 2,
    TA_MAX                                         = 3

};


// Enum  /Script/Engine.TextureFilter
enum class TextureFilter : uint8_t
{
    TF_Nearest                                     = 0,
    TF_Bilinear                                    = 1,
    TF_Trilinear                                   = 2,
    TF_Default                                     = 3,
    TF_MAX                                         = 4

};


// Enum  /Script/Engine.NormalXYChannels
enum class NormalXYChannels : uint8_t
{
    NXYC_RG                                        = 0,
    NXYC_GB                                        = 1,
    NXYC_BA                                        = 2,
    NXYC_MAX                                       = 3

};


// Enum  /Script/Engine.TextureCompressionSettings
enum class TextureCompressionSettings : uint8_t
{
    TC_Default                                     = 0,
    TC_Normalmap                                   = 1,
    TC_Masks                                       = 2,
    TC_Grayscale                                   = 3,
    TC_Displacementmap                             = 4,
    TC_VectorDisplacementmap                       = 5,
    TC_HDR                                         = 6,
    TC_EditorIcon                                  = 7,
    TC_Alpha                                       = 8,
    TC_DistanceFieldFont                           = 9,
    TC_HDR_Compressed                              = 10,
    TC_BC7                                         = 11,
    TC_HalfFloat                                   = 12,
    TC_ReflectionCapture                           = 13,
    TC_NormalXYWithOthers                          = 14,
    TC_MAX                                         = 15

};


// Enum  /Script/Engine.ETextureRDOQuality
enum class ETextureRDOQuality : uint8_t
{
    TRQ_FromTextureGroup                           = 0,
    TRQ_None                                       = 1,
    TRQ_Low                                        = 2,
    TRQ_Medium                                     = 3,
    TRQ_High                                       = 4,
    TRQ_MAX                                        = 5

};


// Enum  /Script/Engine.ETextureDownscaleOptions
enum class ETextureDownscaleOptions : uint8_t
{
    Default                                        = 0,
    Unfiltered                                     = 1,
    SimpleAverage                                  = 2,
    Sharpen0                                       = 3,
    Sharpen1                                       = 4,
    Sharpen2                                       = 5,
    Sharpen3                                       = 6,
    Sharpen4                                       = 7,
    Sharpen5                                       = 8,
    Sharpen6                                       = 9,
    Sharpen7                                       = 10,
    Sharpen8                                       = 11,
    Sharpen9                                       = 12,
    Sharpen10                                      = 13,
    ETextureDownscaleOptions_MAX                   = 14

};


// Enum  /Script/Engine.ETextureGroupLODBiasLevel
enum class ETextureGroupLODBiasLevel : uint8_t
{
    TGL_Default                                    = 0,
    TGL_None                                       = 1,
    TGL_FrontEnd                                   = 2,
    TGL_InBattle_1P                                = 3,
    TGL_InBattle_3P                                = 4,
    TGL_MAX                                        = 5

};


// Enum  /Script/Engine.ETextureMipLoadOptions
enum class ETextureMipLoadOptions : uint8_t
{
    Default                                        = 0,
    AllMips                                        = 1,
    OnlyFirstMip                                   = 2,
    ETextureMipLoadOptions_MAX                     = 3

};


// Enum  /Script/Engine.ETextureSamplerFilter
enum class ETextureSamplerFilter : uint8_t
{
    Point                                          = 0,
    Bilinear                                       = 1,
    Trilinear                                      = 2,
    AnisotropicPoint                               = 3,
    AnisotropicLinear                              = 4,
    ETextureSamplerFilter_MAX                      = 5

};


// Enum  /Script/Engine.ETexturePowerOfTwoSetting
enum class ETexturePowerOfTwoSetting : uint8_t
{
    None                                           = 0,
    PadToPowerOfTwo                                = 1,
    PadToSquarePowerOfTwo                          = 2,
    ETexturePowerOfTwoSetting_MAX                  = 3

};


// Enum  /Script/Engine.TextureMipGenSettings
enum class TextureMipGenSettings : uint8_t
{
    TMGS_FromTextureGroup                          = 0,
    TMGS_SimpleAverage                             = 1,
    TMGS_Sharpen0                                  = 2,
    TMGS_Sharpen1                                  = 3,
    TMGS_Sharpen2                                  = 4,
    TMGS_Sharpen3                                  = 5,
    TMGS_Sharpen4                                  = 6,
    TMGS_Sharpen5                                  = 7,
    TMGS_Sharpen6                                  = 8,
    TMGS_Sharpen7                                  = 9,
    TMGS_Sharpen8                                  = 10,
    TMGS_Sharpen9                                  = 11,
    TMGS_Sharpen10                                 = 12,
    TMGS_NoMipmaps                                 = 13,
    TMGS_LeaveExistingMips                         = 14,
    TMGS_Blur1                                     = 15,
    TMGS_Blur2                                     = 16,
    TMGS_Blur3                                     = 17,
    TMGS_Blur4                                     = 18,
    TMGS_Blur5                                     = 19,
    TMGS_Unfiltered                                = 20,
    TMGS_MAX                                       = 21

};


// Enum  /Script/Engine.TextureGroup
enum class TextureGroup : uint8_t
{
    TEXTUREGROUP_World                             = 0,
    TEXTUREGROUP_WorldNormalMap                    = 1,
    TEXTUREGROUP_WorldSpecular                     = 2,
    TEXTUREGROUP_Character                         = 3,
    TEXTUREGROUP_CharacterNormalMap                = 4,
    TEXTUREGROUP_CharacterSpecular                 = 5,
    TEXTUREGROUP_Weapon                            = 6,
    TEXTUREGROUP_WeaponNormalMap                   = 7,
    TEXTUREGROUP_WeaponSpecular                    = 8,
    TEXTUREGROUP_Vehicle                           = 9,
    TEXTUREGROUP_VehicleNormalMap                  = 10,
    TEXTUREGROUP_VehicleSpecular                   = 11,
    TEXTUREGROUP_Cinematic                         = 12,
    TEXTUREGROUP_Effects                           = 13,
    TEXTUREGROUP_EffectsNotFiltered                = 14,
    TEXTUREGROUP_Skybox                            = 15,
    TEXTUREGROUP_UI                                = 16,
    TEXTUREGROUP_Lightmap                          = 17,
    TEXTUREGROUP_RenderTarget                      = 18,
    TEXTUREGROUP_MobileFlattened                   = 19,
    TEXTUREGROUP_ProcBuilding_Face                 = 20,
    TEXTUREGROUP_ProcBuilding_LightMap             = 21,
    TEXTUREGROUP_Shadowmap                         = 22,
    TEXTUREGROUP_ColorLookupTable                  = 23,
    TEXTUREGROUP_Terrain_Heightmap                 = 24,
    TEXTUREGROUP_Terrain_Weightmap                 = 25,
    TEXTUREGROUP_Bokeh                             = 26,
    TEXTUREGROUP_IESLightProfile                   = 27,
    TEXTUREGROUP_Pixels2D                          = 28,
    TEXTUREGROUP_HierarchicalLOD                   = 29,
    TEXTUREGROUP_Impostor                          = 30,
    TEXTUREGROUP_ImpostorNormalDepth               = 31,
    TEXTUREGROUP_8BitData                          = 32,
    TEXTUREGROUP_16BitData                         = 33,
    TEXTUREGROUP_None                              = 34,
    TEXTUREGROUP_WorldDiffuseAndEmissiveOrOpacity  = 35,
    TEXTUREGROUP_WorldNormalAndRoughness           = 36,
    TEXTUREGROUP_WorldMetallicAndAO                = 37,
    TEXTUREGROUP_CharacterDiffuse                  = 38,
    TEXTUREGROUP_CharacterNormalAndRoughness       = 39,
    TEXTUREGROUP_CharacterMetallicAndAO            = 40,
    TEXTUREGROUP_CharacterHightlightShiftRoot      = 41,
    TEXTUREGROUP_WeaponDiffuse                     = 42,
    TEXTUREGROUP_WeaponNormalAndRoughness          = 43,
    TEXTUREGROUP_WeaponMetallicAndAO               = 44,
    TEXTUREGROUP_UIHigh                            = 45,
    TEXTUREGROUP_CubeMap                           = 46,
    TEXTUREGROUP_PCGMask                           = 47,
    TEXTUREGROUP_PCGFlowMap                        = 48,
    TEXTUREGROUP_PCGDiffuseAndEmissiveOrOpacity    = 49,
    TEXTUREGROUP_PCGNormalAndRoughness             = 50,
    TEXTUREGROUP_PCGMetallicAndAO                  = 51,
    TEXTUREGROUP_UINoDownscale                     = 52,
    TEXTUREGROUP_NPCCharacterDiffuse               = 53,
    TEXTUREGROUP_LandscapeDiffuseAndHeight         = 54,
    TEXTUREGROUP_LandscapeNormalAndRoughness       = 55,
    TEXTUREGROUP_CharacterDiffuseHD                = 56,
    TEXTUREGROUP_Project13                         = 57,
    TEXTUREGROUP_Project14                         = 58,
    TEXTUREGROUP_Project15                         = 59,
    TEXTUREGROUP_MAX                               = 60

};


// Enum  /Script/Engine.ETextureRenderTargetFormat
enum class ETextureRenderTargetFormat : uint8_t
{
    RTF_R8                                         = 0,
    RTF_RG8                                        = 1,
    RTF_RGBA8                                      = 2,
    RTF_RGBA8_SRGB                                 = 3,
    RTF_R16f                                       = 4,
    RTF_RG16f                                      = 5,
    RTF_RGBA16f                                    = 6,
    RTF_R32f                                       = 7,
    RTF_RG32f                                      = 8,
    RTF_RGBA32f                                    = 9,
    RTF_RGB10A2                                    = 10,
    RTF_MAX                                        = 11

};


// Enum  /Script/Engine.ETimecodeProviderSynchronizationState
enum class ETimecodeProviderSynchronizationState : uint8_t
{
    Closed                                         = 0,
    Error                                          = 1,
    Synchronized                                   = 2,
    Synchronizing                                  = 3,
    ETimecodeProviderSynchronizationState_MAX      = 4

};


// Enum  /Script/Engine.ETimelineDirection
enum class ETimelineDirection : uint8_t
{
    Forward                                        = 0,
    Backward                                       = 1,
    ETimelineDirection_MAX                         = 2

};


// Enum  /Script/Engine.ETimelineLengthMode
enum class ETimelineLengthMode : uint8_t
{
    TL_TimelineLength                              = 0,
    TL_LastKeyFrame                                = 1,
    TL_MAX                                         = 2

};


// Enum  /Script/Engine.ETimeStretchCurveMapping
enum class ETimeStretchCurveMapping : uint8_t
{
    T_Original                                     = 0,
    T_TargetMin                                    = 1,
    T_TargetMax                                    = 2,
    MAX                                            = 3

};


// Enum  /Script/Engine.ETwitterIntegrationDelegate
enum class ETwitterIntegrationDelegate : uint8_t
{
    TID_AuthorizeComplete                          = 0,
    TID_TweetUIComplete                            = 1,
    TID_RequestComplete                            = 2,
    TID_MAX                                        = 3

};


// Enum  /Script/Engine.ETwitterRequestMethod
enum class ETwitterRequestMethod : uint8_t
{
    TRM_Get                                        = 0,
    TRM_Post                                       = 1,
    TRM_Delete                                     = 2,
    TRM_MAX                                        = 3

};


// Enum  /Script/Engine.EUserDefinedStructureStatus
enum class EUserDefinedStructureStatus : uint8_t
{
    UDSS_UpToDate                                  = 0,
    UDSS_Dirty                                     = 1,
    UDSS_Error                                     = 2,
    UDSS_Duplicate                                 = 3,
    UDSS_MAX                                       = 4

};


// Enum  /Script/Engine.EUIScalingRule
enum class EUIScalingRule : uint8_t
{
    ShortestSide                                   = 0,
    LongestSide                                    = 1,
    Horizontal                                     = 2,
    Vertical                                       = 3,
    ScaleToFit                                     = 4,
    Custom                                         = 5,
    EUIScalingRule_MAX                             = 6

};


// Enum  /Script/Engine.ERenderFocusRule
enum class ERenderFocusRule : uint8_t
{
    Always                                         = 0,
    NonPointer                                     = 1,
    NavigationOnly                                 = 2,
    Never                                          = 3,
    ERenderFocusRule_MAX                           = 4

};


// Enum  /Script/Engine.EVectorFieldConstructionOp
enum class EVectorFieldConstructionOp : uint8_t
{
    VFCO_Extrude                                   = 0,
    VFCO_Revolve                                   = 1,
    VFCO_MAX                                       = 2

};


// Enum  /Script/Engine.EWindSourceType
enum class EWindSourceType : uint8_t
{
    Directional                                    = 0,
    Point                                          = 1,
    EWindSourceType_MAX                            = 2

};


// Enum  /Script/Engine.EStreamType
enum class EStreamType : uint8_t
{
    None                                           = 0,
    StreamToVisibleGrid                            = 1,
    StreamToActiveGrid                             = 2,
    StreamToUnload                                 = 3,
    EStreamType_MAX                                = 4

};


// Enum  /Script/Engine.ECollisionProcessPhase
enum class ECollisionProcessPhase : uint8_t
{
    Mark                                           = 0,
    Streaming                                      = 1,
    ECollisionProcessPhase_MAX                     = 2

};


// Enum  /Script/Engine.EWeaponRangeType
enum class EWeaponRangeType : uint8_t
{
    WeaponRangeType_MainWeapon                     = 0,
    WeaponRangeType_MeleeWeapon                    = 1,
    WeaponRangeType_ThrowWeapon                    = 2,
    WeaponRangeType_MAX                            = 3

};


// Enum  /Script/Engine.EPSCPoolMethod
enum class EPSCPoolMethod : uint8_t
{
    None                                           = 0,
    AutoRelease                                    = 1,
    ManualRelease                                  = 2,
    ManualRelease_OnComplete                       = 3,
    FreeInPool                                     = 4,
    EPSCPoolMethod_MAX                             = 5

};


// Enum  /Script/Engine.EVolumeLightingMethod
enum class EVolumeLightingMethod : uint8_t
{
    VLM_VolumetricLightmap                         = 0,
    VLM_SparseVolumeLightingSamples                = 1,
    VLM_None                                       = 2,
    VLM_MAX                                        = 3

};


// Enum  /Script/Engine.EVisibilityAggressiveness
enum class EVisibilityAggressiveness : uint8_t
{
    VIS_LeastAggressive                            = 0,
    VIS_ModeratelyAggressive                       = 1,
    VIS_MostAggressive                             = 2,
    VIS_Max                                        = 3

};


// Enum  /Script/ClothingSystemRuntimeCommon.EClothingWindMethod_Legacy
enum class EClothingWindMethod_Legacy : uint8_t
{
    Legacy                                         = 0,
    Accurate                                       = 1,
    EClothingWindMethod_MAX                        = 2

};


// Enum  /Script/ClothingSystemRuntimeCommon.EWeightMapTargetCommon
enum class EWeightMapTargetCommon : uint8_t
{
    None                                           = 0,
    MaxDistance                                    = 1,
    BackstopDistance                               = 2,
    BackstopRadius                                 = 3,
    AnimDriveMultiplier                            = 4,
    EWeightMapTargetCommon_MAX                     = 5

};


// Enum  /Script/ClothingSystemRuntimeNv.EClothingWindMethodNv
enum class EClothingWindMethodNv : uint8_t
{
    Legacy                                         = 0,
    Accurate                                       = 1,
    EClothingWindMethodNv_MAX                      = 2

};


// Enum  /Script/AndroidRuntimeSettings.EClangSanitizer
enum class EClangSanitizer : uint8_t
{
    None                                           = 0,
    Address                                        = 1,
    HwAddress                                      = 2,
    UndefinedBehavior                              = 3,
    UndefinedBehaviorMinimal                       = 4,
    EClangSanitizer_MAX                            = 5

};


// Enum  /Script/AndroidRuntimeSettings.EAndroidGraphicsDebugger
enum class EAndroidGraphicsDebugger : uint8_t
{
    None                                           = 0,
    Mali                                           = 1,
    Adreno                                         = 2,
    EAndroidGraphicsDebugger_MAX                   = 3

};


// Enum  /Script/AndroidRuntimeSettings.EGoogleVRCaps
enum class EGoogleVRCaps : uint8_t
{
    Cardboard                                      = 0,
    Daydream33                                     = 1,
    Daydream63                                     = 2,
    Daydream66                                     = 3,
    EGoogleVRCaps_MAX                              = 4

};


// Enum  /Script/AndroidRuntimeSettings.EGoogleVRMode
enum class EGoogleVRMode : uint8_t
{
    Cardboard                                      = 0,
    Daydream                                       = 1,
    DaydreamAndCardboard                           = 2,
    EGoogleVRMode_MAX                              = 3

};


// Enum  /Script/AndroidRuntimeSettings.EAndroidAudio
enum class EAndroidAudio : uint8_t
{
    Default                                        = 0,
    OGG                                            = 1,
    ADPCM                                          = 2,
    EAndroidAudio_MAX                              = 3

};


// Enum  /Script/AndroidRuntimeSettings.EOculusMobileDevice
enum class EOculusMobileDevice : uint8_t
{
    Quest                                          = 1,
    Quest2                                         = 2,
    EOculusMobileDevice_MAX                        = 3

};


// Enum  /Script/AndroidRuntimeSettings.EAndroidInstallLocation
enum class EAndroidInstallLocation : uint8_t
{
    InternalOnly                                   = 0,
    PreferExternal                                 = 1,
    Auto                                           = 2,
    EAndroidInstallLocation_MAX                    = 3

};


// Enum  /Script/AndroidRuntimeSettings.EAndroidDepthBufferPreference
enum class EAndroidDepthBufferPreference : uint8_t
{
    Default                                        = 0,
    Bits16                                         = 16,
    Bits24                                         = 24,
    Bits32                                         = 32,
    EAndroidDepthBufferPreference_MAX              = 33

};


// Enum  /Script/AndroidRuntimeSettings.EAndroidScreenOrientation
enum class EAndroidScreenOrientation : uint8_t
{
    Portrait                                       = 0,
    ReversePortrait                                = 1,
    SensorPortrait                                 = 2,
    Landscape                                      = 3,
    ReverseLandscape                               = 4,
    SensorLandscape                                = 5,
    Sensor                                         = 6,
    FullSensor                                     = 7,
    EAndroidScreenOrientation_MAX                  = 8

};


// Enum  /Script/InteractiveToolsFramework.EInputCaptureState
enum class EInputCaptureState : uint8_t
{
    Begin                                          = 1,
    Continue                                       = 2,
    End                                            = 3,
    Ignore                                         = 4,
    EInputCaptureState_MAX                         = 5

};


// Enum  /Script/InteractiveToolsFramework.EInputCaptureRequestType
enum class EInputCaptureRequestType : uint8_t
{
    Begin                                          = 1,
    Ignore                                         = 2,
    EInputCaptureRequestType_MAX                   = 3

};


// Enum  /Script/InteractiveToolsFramework.EInputCaptureSide
enum class EInputCaptureSide : uint8_t
{
    None                                           = 0,
    Left                                           = 1,
    Right                                          = 2,
    Both                                           = 3,
    Any                                            = 99,
    EInputCaptureSide_MAX                          = 100

};


// Enum  /Script/InteractiveToolsFramework.EInputDevices
enum class EInputDevices : uint32_t
{
    None                                           = 0,
    Keyboard                                       = 1,
    Mouse                                          = 2,
    Gamepad                                        = 4,
    OculusTouch                                    = 8,
    HTCViveWands                                   = 16,
    AnySpatialDevice                               = 24,
    TabletFingers                                  = 1024,
    EInputDevices_MAX                              = 1025

};


// Enum  /Script/InteractiveToolsFramework.ETransformGizmoSubElements
enum class ETransformGizmoSubElements : uint32_t
{
    None                                           = 0,
    TranslateAxisX                                 = 2,
    TranslateAxisY                                 = 4,
    TranslateAxisZ                                 = 8,
    TranslateAllAxes                               = 14,
    TranslatePlaneXY                               = 16,
    TranslatePlaneXZ                               = 32,
    TranslatePlaneYZ                               = 64,
    TranslateAllPlanes                             = 112,
    RotateAxisX                                    = 128,
    RotateAxisY                                    = 256,
    RotateAxisZ                                    = 512,
    RotateAllAxes                                  = 896,
    ScaleAxisX                                     = 1024,
    ScaleAxisY                                     = 2048,
    ScaleAxisZ                                     = 4096,
    ScaleAllAxes                                   = 7168,
    ScalePlaneYZ                                   = 8192,
    ScalePlaneXZ                                   = 16384,
    ScalePlaneXY                                   = 32768,
    ScaleAllPlanes                                 = 57344,
    ScaleUniform                                   = 65536,
    StandardTranslateRotate                        = 1022,
    TranslateRotateUniformScale                    = 66558,
    FullTranslateRotateScale                       = 131070,
    ETransformGizmoSubElements_MAX                 = 131071

};


// Enum  /Script/InteractiveToolsFramework.EToolChangeTrackingMode
enum class EToolChangeTrackingMode : uint8_t
{
    NoChangeTracking                               = 1,
    UndoToExit                                     = 2,
    FullUndoRedo                                   = 3,
    EToolChangeTrackingMode_MAX                    = 4

};


// Enum  /Script/InteractiveToolsFramework.EToolSide
enum class EToolSide : uint8_t
{
    Left                                           = 1,
    Mouse                                          = 1,
    Right                                          = 2,
    EToolSide_MAX                                  = 3

};


// Enum  /Script/InteractiveToolsFramework.EViewInteractionState
enum class EViewInteractionState : uint8_t
{
    None                                           = 0,
    Hovered                                        = 1,
    Focused                                        = 2,
    EViewInteractionState_MAX                      = 3

};


// Enum  /Script/InteractiveToolsFramework.ESelectedObjectsModificationType
enum class ESelectedObjectsModificationType : uint8_t
{
    Replace                                        = 0,
    Add                                            = 1,
    Remove                                         = 2,
    Clear                                          = 3,
    ESelectedObjectsModificationType_MAX           = 4

};


// Enum  /Script/InteractiveToolsFramework.EToolMessageLevel
enum class EToolMessageLevel : uint8_t
{
    Internal                                       = 0,
    UserMessage                                    = 1,
    UserNotification                               = 2,
    UserWarning                                    = 3,
    UserError                                      = 4,
    EToolMessageLevel_MAX                          = 5

};


// Enum  /Script/InteractiveToolsFramework.EToolContextCoordinateSystem
enum class EToolContextCoordinateSystem : uint8_t
{
    World                                          = 0,
    Local                                          = 1,
    EToolContextCoordinateSystem_MAX               = 2

};


// Enum  /Script/InteractiveToolsFramework.EStandardToolContextMaterials
enum class EStandardToolContextMaterials : uint8_t
{
    VertexColorMaterial                            = 1,
    EStandardToolContextMaterials_MAX              = 2

};


// Enum  /Script/InteractiveToolsFramework.ESceneSnapQueryTargetType
enum class ESceneSnapQueryTargetType : uint8_t
{
    None                                           = 0,
    MeshVertex                                     = 1,
    MeshEdge                                       = 2,
    Grid                                           = 4,
    All                                            = 7,
    ESceneSnapQueryTargetType_MAX                  = 8

};


// Enum  /Script/InteractiveToolsFramework.ESceneSnapQueryType
enum class ESceneSnapQueryType : uint8_t
{
    Position                                       = 1,
    Rotation                                       = 2,
    ESceneSnapQueryType_MAX                        = 3

};


// Enum  /Script/VectorVM.EVectorVMOp
enum class EVectorVMOp : uint8_t
{
    done                                           = 0,
    add                                            = 1,
    sub                                            = 2,
    mul                                            = 3,
    div                                            = 4,
    mad                                            = 5,
    lerp                                           = 6,
    rcp                                            = 7,
    rsq                                            = 8,
    sqrt                                           = 9,
    neg                                            = 10,
    abs                                            = 11,
    exp                                            = 12,
    exp2                                           = 13,
    log                                            = 14,
    log2                                           = 15,
    sin                                            = 16,
    cos                                            = 17,
    tan                                            = 18,
    asin                                           = 19,
    acos                                           = 20,
    atan                                           = 21,
    atan2                                          = 22,
    ceil                                           = 23,
    floor                                          = 24,
    fmod                                           = 25,
    frac                                           = 26,
    trunc                                          = 27,
    clamp                                          = 28,
    min                                            = 29,
    max                                            = 30,
    pow                                            = 31,
    round                                          = 32,
    sign                                           = 33,
    step                                           = 34,
    random                                         = 35,
    noise                                          = 36,
    cmplt                                          = 37,
    cmple                                          = 38,
    cmpgt                                          = 39,
    cmpge                                          = 40,
    cmpeq                                          = 41,
    cmpneq                                         = 42,
    select                                         = 43,
    addi                                           = 44,
    subi                                           = 45,
    muli                                           = 46,
    divi                                           = 47,
    clampi                                         = 48,
    mini                                           = 49,
    maxi                                           = 50,
    absi                                           = 51,
    negi                                           = 52,
    signi                                          = 53,
    randomi                                        = 54,
    cmplti                                         = 55,
    cmplei                                         = 56,
    cmpgti                                         = 57,
    cmpgei                                         = 58,
    cmpeqi                                         = 59,
    cmpneqi                                        = 60,
    bit_and                                        = 61,
    bit_or                                         = 62,
    bit_xor                                        = 63,
    bit_not                                        = 64,
    bit_lshift                                     = 65,
    bit_rshift                                     = 66,
    logic_and                                      = 67,
    logic_or                                       = 68,
    logic_xor                                      = 69,
    logic_not                                      = 70,
    f2i                                            = 71,
    i2f                                            = 72,
    f2b                                            = 73,
    b2f                                            = 74,
    i2b                                            = 75,
    b2i                                            = 76,
    inputdata_float                                = 77,
    inputdata_int32                                = 78,
    inputdata_half                                 = 79,
    inputdata_noadvance_float                      = 80,
    inputdata_noadvance_int32                      = 81,
    inputdata_noadvance_half                       = 82,
    outputdata_float                               = 83,
    outputdata_int32                               = 84,
    outputdata_half                                = 85,
    acquireindex                                   = 86,
    external_func_call                             = 87,
    exec_index                                     = 88,
    noise2D                                        = 89,
    noise3D                                        = 90,
    enter_stat_scope                               = 91,
    exit_stat_scope                                = 92,
    update_id                                      = 93,
    acquire_id                                     = 94,
    NumOpcodes                                     = 95

};


// Enum  /Script/VectorVM.EVectorVMOperandLocation
enum class EVectorVMOperandLocation : uint8_t
{
    Register                                       = 0,
    Constant                                       = 1,
    Num                                            = 2,
    EVectorVMOperandLocation_MAX                   = 3

};


// Enum  /Script/VectorVM.EVectorVMBaseTypes
enum class EVectorVMBaseTypes : uint8_t
{
    Float                                          = 0,
    Int                                            = 1,
    Bool                                           = 2,
    Num                                            = 3,
    EVectorVMBaseTypes_MAX                         = 4

};


// Enum  /Script/GameplayTasks.EGameplayTaskState
enum class EGameplayTaskState : uint8_t
{
    Uninitialized                                  = 0,
    AwaitingActivation                             = 1,
    Paused                                         = 2,
    Active                                         = 3,
    Finished                                       = 4,
    EGameplayTaskState_MAX                         = 5

};


// Enum  /Script/NavigationSystem.ERuntimeGenerationType
enum class ERuntimeGenerationType : uint8_t
{
    Static                                         = 0,
    DynamicModifiersOnly                           = 1,
    Dynamic                                        = 2,
    LegacyGeneration                               = 3,
    ERuntimeGenerationType_MAX                     = 4

};


// Enum  /Script/NavigationSystem.ENavCostDisplay
enum class ENavCostDisplay : uint8_t
{
    TotalCost                                      = 0,
    HeuristicOnly                                  = 1,
    RealCostOnly                                   = 2,
    ENavCostDisplay_MAX                            = 3

};


// Enum  /Script/NavigationSystem.ENavSystemOverridePolicy
enum class ENavSystemOverridePolicy : uint8_t
{
    Override                                       = 0,
    Append                                         = 1,
    Skip                                           = 2,
    ENavSystemOverridePolicy_MAX                   = 3

};


// Enum  /Script/NavigationSystem.ERecastPartitioning
enum class ERecastPartitioning : uint8_t
{
    Monotone                                       = 0,
    Watershed                                      = 1,
    ChunkyMonotone                                 = 2,
    ERecastPartitioning_MAX                        = 3

};


// Enum  /Script/AIModule.EAISenseNotifyType
enum class EAISenseNotifyType : uint8_t
{
    OnEveryPerception                              = 0,
    OnPerceptionChange                             = 1,
    EAISenseNotifyType_MAX                         = 2

};


// Enum  /Script/AIModule.EAITaskPriority
enum class EAITaskPriority : uint8_t
{
    Lowest                                         = 0,
    Low                                            = 64,
    AutonomousAI                                   = 127,
    High                                           = 192,
    Ultimate                                       = 254,
    EAITaskPriority_MAX                            = 255

};


// Enum  /Script/AIModule.EGenericAICheck
enum class EGenericAICheck : uint8_t
{
    Less                                           = 0,
    LessOrEqual                                    = 1,
    Equal                                          = 2,
    NotEqual                                       = 3,
    GreaterOrEqual                                 = 4,
    Greater                                        = 5,
    IsTrue                                         = 6,
    MAX                                            = 7

};


// Enum  /Script/AIModule.EAILockSource
enum class EAILockSource : uint8_t
{
    Animation                                      = 0,
    Logic                                          = 1,
    Script                                         = 2,
    Gameplay                                       = 3,
    MAX                                            = 4

};


// Enum  /Script/AIModule.EAIRequestPriority
enum class EAIRequestPriority : uint8_t
{
    SoftScript                                     = 0,
    Logic                                          = 1,
    HardScript                                     = 2,
    Reaction                                       = 3,
    Ultimate                                       = 4,
    MAX                                            = 5

};


// Enum  /Script/AIModule.EPawnActionEventType
enum class EPawnActionEventType : uint8_t
{
    Invalid                                        = 0,
    FailedToStart                                  = 1,
    InstantAbort                                   = 2,
    FinishedAborting                               = 3,
    FinishedExecution                              = 4,
    Push                                           = 5,
    EPawnActionEventType_MAX                       = 6

};


// Enum  /Script/AIModule.EPawnActionResult
enum class EPawnActionResult : uint8_t
{
    NotStarted                                     = 0,
    InProgress                                     = 1,
    Success                                        = 2,
    Failed                                         = 3,
    Aborted                                        = 4,
    EPawnActionResult_MAX                          = 5

};


// Enum  /Script/AIModule.EPawnActionAbortState
enum class EPawnActionAbortState : uint8_t
{
    NeverStarted                                   = 0,
    NotBeingAborted                                = 1,
    MarkPendingAbort                               = 2,
    LatentAbortInProgress                          = 3,
    AbortDone                                      = 4,
    MAX                                            = 5

};


// Enum  /Script/AIModule.FAIDistanceType
enum class FAIDistanceType : uint8_t
{
    Distance3D                                     = 0,
    Distance2D                                     = 1,
    DistanceZ                                      = 2,
    MAX                                            = 3

};


// Enum  /Script/AIModule.EAIOptionFlag
enum class EAIOptionFlag : uint8_t
{
    Default                                        = 0,
    Enable                                         = 1,
    Disable                                        = 2,
    MAX                                            = 3

};


// Enum  /Script/AIModule.EBTFlowAbortMode
enum class EBTFlowAbortMode : uint8_t
{
    None                                           = 0,
    LowerPriority                                  = 1,
    Self                                           = 2,
    Both                                           = 3,
    EBTFlowAbortMode_MAX                           = 4

};


// Enum  /Script/AIModule.EBTNodeResult
enum class EBTNodeResult : uint8_t
{
    Succeeded                                      = 0,
    Failed                                         = 1,
    Aborted                                        = 2,
    InProgress                                     = 3,
    EBTNodeResult_MAX                              = 4

};


// Enum  /Script/AIModule.ETextKeyOperation
enum class ETextKeyOperation : uint8_t
{
    Equal                                          = 0,
    NotEqual                                       = 1,
    Contain                                        = 2,
    NotContain                                     = 3,
    ETextKeyOperation_MAX                          = 4

};


// Enum  /Script/AIModule.EArithmeticKeyOperation
enum class EArithmeticKeyOperation : uint8_t
{
    Equal                                          = 0,
    NotEqual                                       = 1,
    Less                                           = 2,
    LessOrEqual                                    = 3,
    Greater                                        = 4,
    GreaterOrEqual                                 = 5,
    EArithmeticKeyOperation_MAX                    = 6

};


// Enum  /Script/AIModule.EBasicKeyOperation
enum class EBasicKeyOperation : uint8_t
{
    Set                                            = 0,
    NotSet                                         = 1,
    EBasicKeyOperation_MAX                         = 2

};


// Enum  /Script/AIModule.EBTParallelMode
enum class EBTParallelMode : uint8_t
{
    AbortBackground                                = 0,
    WaitForBackground                              = 1,
    EBTParallelMode_MAX                            = 2

};


// Enum  /Script/AIModule.EBTDecoratorLogic
enum class EBTDecoratorLogic : uint8_t
{
    Invalid                                        = 0,
    Test                                           = 1,
    And                                            = 2,
    Or                                             = 3,
    Not                                            = 4,
    EBTDecoratorLogic_MAX                          = 5

};


// Enum  /Script/AIModule.EBTChildIndex
enum class EBTChildIndex : uint8_t
{
    FirstNode                                      = 0,
    TaskNode                                       = 1,
    EBTChildIndex_MAX                              = 2

};


// Enum  /Script/AIModule.EBTBlackboardRestart
enum class EBTBlackboardRestart : uint8_t
{
    ValueChange                                    = 0,
    ResultChange                                   = 1,
    EBTBlackboardRestart_MAX                       = 2

};


// Enum  /Script/AIModule.EBlackBoardEntryComparison
enum class EBlackBoardEntryComparison : uint8_t
{
    Equal                                          = 0,
    NotEqual                                       = 1,
    EBlackBoardEntryComparison_MAX                 = 2

};


// Enum  /Script/AIModule.EPathExistanceQueryType
enum class EPathExistanceQueryType : uint8_t
{
    NavmeshRaycast2D                               = 0,
    HierarchicalQuery                              = 1,
    RegularPathFinding                             = 2,
    EPathExistanceQueryType_MAX                    = 3

};


// Enum  /Script/AIModule.EPointOnCircleSpacingMethod
enum class EPointOnCircleSpacingMethod : uint8_t
{
    BySpaceBetween                                 = 0,
    ByNumberOfPoints                               = 1,
    EPointOnCircleSpacingMethod_MAX                = 2

};


// Enum  /Script/AIModule.EEQSNormalizationType
enum class EEQSNormalizationType : uint8_t
{
    Absolute                                       = 0,
    RelativeToScores                               = 1,
    EEQSNormalizationType_MAX                      = 2

};


// Enum  /Script/AIModule.EEnvTestDistance
enum class EEnvTestDistance : uint8_t
{
    Distance3D                                     = 0,
    Distance2D                                     = 1,
    DistanceZ                                      = 2,
    DistanceAbsoluteZ                              = 3,
    EEnvTestDistance_MAX                           = 4

};


// Enum  /Script/AIModule.EEnvTestDot
enum class EEnvTestDot : uint8_t
{
    Dot3D                                          = 0,
    Dot2D                                          = 1,
    EEnvTestDot_MAX                                = 2

};


// Enum  /Script/AIModule.EEnvTestPathfinding
enum class EEnvTestPathfinding : uint8_t
{
    PathExist                                      = 0,
    PathCost                                       = 1,
    PathLength                                     = 2,
    EEnvTestPathfinding_MAX                        = 3

};


// Enum  /Script/AIModule.EEnvQueryTestClamping
enum class EEnvQueryTestClamping : uint8_t
{
    None                                           = 0,
    SpecifiedValue                                 = 1,
    FilterThreshold                                = 2,
    EEnvQueryTestClamping_MAX                      = 3

};


// Enum  /Script/AIModule.EEnvDirection
enum class EEnvDirection : uint8_t
{
    TwoPoints                                      = 0,
    Rotation                                       = 1,
    EEnvDirection_MAX                              = 2

};


// Enum  /Script/AIModule.EEnvOverlapShape
enum class EEnvOverlapShape : uint8_t
{
    Box                                            = 0,
    Sphere                                         = 1,
    Capsule                                        = 2,
    EEnvOverlapShape_MAX                           = 3

};


// Enum  /Script/AIModule.EEnvTraceShape
enum class EEnvTraceShape : uint8_t
{
    Line                                           = 0,
    Box                                            = 1,
    Sphere                                         = 2,
    Capsule                                        = 3,
    EEnvTraceShape_MAX                             = 4

};


// Enum  /Script/AIModule.EEnvQueryTrace
enum class EEnvQueryTrace : uint8_t
{
    None                                           = 0,
    Navigation                                     = 1,
    Geometry                                       = 2,
    NavigationOverLedges                           = 3,
    EEnvQueryTrace_MAX                             = 4

};


// Enum  /Script/AIModule.EAIParamType
enum class EAIParamType : uint8_t
{
    Float                                          = 0,
    Int                                            = 1,
    Bool                                           = 2,
    MAX                                            = 3

};


// Enum  /Script/AIModule.EEnvQueryParam
enum class EEnvQueryParam : uint8_t
{
    Float                                          = 0,
    Int                                            = 1,
    Bool                                           = 2,
    EEnvQueryParam_MAX                             = 3

};


// Enum  /Script/AIModule.EEnvQueryRunMode
enum class EEnvQueryRunMode : uint8_t
{
    SingleResult                                   = 0,
    RandomBest5Pct                                 = 1,
    RandomBest25Pct                                = 2,
    AllMatching                                    = 3,
    EEnvQueryRunMode_MAX                           = 4

};


// Enum  /Script/AIModule.EEnvTestScoreOperator
enum class EEnvTestScoreOperator : uint8_t
{
    AverageScore                                   = 0,
    MinScore                                       = 1,
    MaxScore                                       = 2,
    Multiply                                       = 3,
    EEnvTestScoreOperator_MAX                      = 4

};


// Enum  /Script/AIModule.EEnvTestFilterOperator
enum class EEnvTestFilterOperator : uint8_t
{
    AllPass                                        = 0,
    AnyPass                                        = 1,
    EEnvTestFilterOperator_MAX                     = 2

};


// Enum  /Script/AIModule.EEnvQueryPriority
enum class EEnvQueryPriority : uint8_t
{
    Normal                                         = 0,
    High                                           = 1,
    EEnvQueryPriority_MAX                          = 2

};


// Enum  /Script/AIModule.EEnvTestCost
enum class EEnvTestCost : uint8_t
{
    Low                                            = 0,
    Medium                                         = 1,
    High                                           = 2,
    EEnvTestCost_MAX                               = 3

};


// Enum  /Script/AIModule.EEnvTestWeight
enum class EEnvTestWeight : uint8_t
{
    None                                           = 0,
    Square                                         = 1,
    Inverse                                        = 2,
    Unused                                         = 3,
    Constant                                       = 4,
    Skip                                           = 5,
    EEnvTestWeight_MAX                             = 6

};


// Enum  /Script/AIModule.EEnvTestScoreEquation
enum class EEnvTestScoreEquation : uint8_t
{
    Linear                                         = 0,
    Square                                         = 1,
    InverseLinear                                  = 2,
    SquareRoot                                     = 3,
    Constant                                       = 4,
    EEnvTestScoreEquation_MAX                      = 5

};


// Enum  /Script/AIModule.EEnvTestFilterType
enum class EEnvTestFilterType : uint8_t
{
    Minimum                                        = 0,
    Maximum                                        = 1,
    Range                                          = 2,
    Match                                          = 3,
    EEnvTestFilterType_MAX                         = 4

};


// Enum  /Script/AIModule.EEnvTestPurpose
enum class EEnvTestPurpose : uint8_t
{
    Filter                                         = 0,
    Score                                          = 1,
    FilterAndScore                                 = 2,
    EEnvTestPurpose_MAX                            = 3

};


// Enum  /Script/AIModule.EEnvQueryHightlightMode
enum class EEnvQueryHightlightMode : uint8_t
{
    All                                            = 0,
    Best5Pct                                       = 1,
    Best25Pct                                      = 2,
    EEnvQueryHightlightMode_MAX                    = 3

};


// Enum  /Script/AIModule.ETeamAttitude
enum class ETeamAttitude : uint8_t
{
    Friendly                                       = 0,
    Neutral                                        = 1,
    Hostile                                        = 2,
    ETeamAttitude_MAX                              = 3

};


// Enum  /Script/AIModule.EPathFollowingAction
enum class EPathFollowingAction : uint8_t
{
    Error                                          = 0,
    NoMove                                         = 1,
    DirectMove                                     = 2,
    PartialPath                                    = 3,
    PathToGoal                                     = 4,
    EPathFollowingAction_MAX                       = 5

};


// Enum  /Script/AIModule.EPathFollowingStatus
enum class EPathFollowingStatus : uint8_t
{
    Idle                                           = 0,
    Waiting                                        = 1,
    Paused                                         = 2,
    Moving                                         = 3,
    EPathFollowingStatus_MAX                       = 4

};


// Enum  /Script/AIModule.EPawnActionFailHandling
enum class EPawnActionFailHandling : uint8_t
{
    RequireSuccess                                 = 0,
    IgnoreFailure                                  = 1,
    EPawnActionFailHandling_MAX                    = 2

};


// Enum  /Script/AIModule.EPawnSubActionTriggeringPolicy
enum class EPawnSubActionTriggeringPolicy : uint8_t
{
    CopyBeforeTriggering                           = 0,
    ReuseInstances                                 = 1,
    EPawnSubActionTriggeringPolicy_MAX             = 2

};


// Enum  /Script/AIModule.EPawnActionMoveMode
enum class EPawnActionMoveMode : uint8_t
{
    UsePathfinding                                 = 0,
    StraightLine                                   = 1,
    EPawnActionMoveMode_MAX                        = 2

};


// Enum  /Script/RigVM.ERigVMParameterType
enum class ERigVMParameterType : uint8_t
{
    Input                                          = 0,
    Output                                         = 1,
    Invalid                                        = 2,
    ERigVMParameterType_MAX                        = 3

};


// Enum  /Script/RigVM.ERigVMOpCode
enum class ERigVMOpCode : uint8_t
{
    Execute_0_Operands                             = 0,
    Execute_1_Operands                             = 1,
    Execute_2_Operands                             = 2,
    Execute_3_Operands                             = 3,
    Execute_4_Operands                             = 4,
    Execute_5_Operands                             = 5,
    Execute_6_Operands                             = 6,
    Execute_7_Operands                             = 7,
    Execute_8_Operands                             = 8,
    Execute_9_Operands                             = 9,
    Execute_10_Operands                            = 10,
    Execute_11_Operands                            = 11,
    Execute_12_Operands                            = 12,
    Execute_13_Operands                            = 13,
    Execute_14_Operands                            = 14,
    Execute_15_Operands                            = 15,
    Execute_16_Operands                            = 16,
    Execute_17_Operands                            = 17,
    Execute_18_Operands                            = 18,
    Execute_19_Operands                            = 19,
    Execute_20_Operands                            = 20,
    Execute_21_Operands                            = 21,
    Execute_22_Operands                            = 22,
    Execute_23_Operands                            = 23,
    Execute_24_Operands                            = 24,
    Execute_25_Operands                            = 25,
    Execute_26_Operands                            = 26,
    Execute_27_Operands                            = 27,
    Execute_28_Operands                            = 28,
    Execute_29_Operands                            = 29,
    Execute_30_Operands                            = 30,
    Execute_31_Operands                            = 31,
    Execute_32_Operands                            = 32,
    Execute_33_Operands                            = 33,
    Execute_34_Operands                            = 34,
    Execute_35_Operands                            = 35,
    Execute_36_Operands                            = 36,
    Execute_37_Operands                            = 37,
    Execute_38_Operands                            = 38,
    Execute_39_Operands                            = 39,
    Execute_40_Operands                            = 40,
    Execute_41_Operands                            = 41,
    Execute_42_Operands                            = 42,
    Execute_43_Operands                            = 43,
    Execute_44_Operands                            = 44,
    Execute_45_Operands                            = 45,
    Execute_46_Operands                            = 46,
    Execute_47_Operands                            = 47,
    Execute_48_Operands                            = 48,
    Execute_49_Operands                            = 49,
    Execute_50_Operands                            = 50,
    Execute_51_Operands                            = 51,
    Execute_52_Operands                            = 52,
    Execute_53_Operands                            = 53,
    Execute_54_Operands                            = 54,
    Execute_55_Operands                            = 55,
    Execute_56_Operands                            = 56,
    Execute_57_Operands                            = 57,
    Execute_58_Operands                            = 58,
    Execute_59_Operands                            = 59,
    Execute_60_Operands                            = 60,
    Execute_61_Operands                            = 61,
    Execute_62_Operands                            = 62,
    Execute_63_Operands                            = 63,
    Execute_64_Operands                            = 64,
    Zero                                           = 65,
    BoolFalse                                      = 66,
    BoolTrue                                       = 67,
    Copy                                           = 68,
    Increment                                      = 69,
    Decrement                                      = 70,
    Equals                                         = 71,
    NotEquals                                      = 72,
    JumpAbsolute                                   = 73,
    JumpForward                                    = 74,
    JumpBackward                                   = 75,
    JumpAbsoluteIf                                 = 76,
    JumpForwardIf                                  = 77,
    JumpBackwardIf                                 = 78,
    ChangeType                                     = 79,
    Exit                                           = 80,
    BeginBlock                                     = 81,
    EndBlock                                       = 82,
    Invalid                                        = 83,
    ERigVMOpCode_MAX                               = 84

};


// Enum  /Script/RigVM.ERigVMPinDirection
enum class ERigVMPinDirection : uint8_t
{
    Input                                          = 0,
    Output                                         = 1,
    IO                                             = 2,
    Visible                                        = 3,
    Hidden                                         = 4,
    Invalid                                        = 5,
    ERigVMPinDirection_MAX                         = 6

};


// Enum  /Script/RigVM.ERigVMRegisterType
enum class ERigVMRegisterType : uint8_t
{
    Plain                                          = 0,
    String                                         = 1,
    Name                                           = 2,
    Struct                                         = 3,
    Invalid                                        = 4,
    ERigVMRegisterType_MAX                         = 5

};


// Enum  /Script/RigVM.ERigVMMemoryType
enum class ERigVMMemoryType : uint8_t
{
    Work                                           = 0,
    Literal                                        = 1,
    External                                       = 2,
    Invalid                                        = 3,
    ERigVMMemoryType_MAX                           = 4

};


// Enum  /Script/MFGlobalEventParameterTags.EMFGlobalEventParameterContainerMatchType
enum class EMFGlobalEventParameterContainerMatchType : uint8_t
{
    Any                                            = 0,
    All                                            = 1,
    EMFGlobalEventParameterContainerMatchType_MAX  = 2

};


// Enum  /Script/MFGlobalEventParameterTags.EMFGlobalEventParameterTagMatchType
enum class EMFGlobalEventParameterTagMatchType : uint8_t
{
    Explicit                                       = 0,
    IncludeParentTags                              = 1,
    EMFGlobalEventParameterTagMatchType_MAX        = 2

};


// Enum  /Script/MFGlobalEventParameterTags.EMFGlobalEventParameterTagSelectionType
enum class EMFGlobalEventParameterTagSelectionType : uint8_t
{
    None                                           = 0,
    NonRestrictedOnly                              = 1,
    RestrictedOnly                                 = 2,
    All                                            = 3,
    EMFGlobalEventParameterTagSelectionType_MAX    = 4

};


// Enum  /Script/MFGlobalEventParameterTags.EMFGlobalEventParameterTagSourceType
enum class EMFGlobalEventParameterTagSourceType : uint8_t
{
    Native                                         = 0,
    DefaultTagList                                 = 1,
    TagList                                        = 2,
    RestrictedTagList                              = 3,
    DataTable                                      = 4,
    Invalid                                        = 5,
    EMFGlobalEventParameterTagSourceType_MAX       = 6

};


// Enum  /Script/MFGlobalEventTags.EMFGlobalEventContainerMatchType
enum class EMFGlobalEventContainerMatchType : uint8_t
{
    Any                                            = 0,
    All                                            = 1,
    EMFGlobalEventContainerMatchType_MAX           = 2

};


// Enum  /Script/MFGlobalEventTags.EMFGlobalEventTagMatchType
enum class EMFGlobalEventTagMatchType : uint8_t
{
    Explicit                                       = 0,
    IncludeParentTags                              = 1,
    EMFGlobalEventTagMatchType_MAX                 = 2

};


// Enum  /Script/MFGlobalEventTags.EMFGlobalEventTagSelectionType
enum class EMFGlobalEventTagSelectionType : uint8_t
{
    None                                           = 0,
    NonRestrictedOnly                              = 1,
    RestrictedOnly                                 = 2,
    All                                            = 3,
    EMFGlobalEventTagSelectionType_MAX             = 4

};


// Enum  /Script/MFGlobalEventTags.EMFGlobalEventTagSourceType
enum class EMFGlobalEventTagSourceType : uint8_t
{
    Native                                         = 0,
    DefaultTagList                                 = 1,
    TagList                                        = 2,
    RestrictedTagList                              = 3,
    DataTable                                      = 4,
    Invalid                                        = 5,
    EMFGlobalEventTagSourceType_MAX                = 6

};


// UserDefinedEnum  /Script/Engine.Default__UserDefinedEnum
enum class Default__UserDefinedEnum : uint8_t
{

};


