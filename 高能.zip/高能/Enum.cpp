																/* Create by 无心 */
																/* B站ID: 无心geigei  */
																/* telegram群@wuxingeigei */
// Enum  /Script/CoreUObject.EInterpCurveMode
enum class EInterpCurveMode : uint8_t
{
    CIM_Linear                                     = 0,
    CIM_CurveAuto                                  = 1,
    CIM_Constant                                   = 2,
    CIM_CurveUser                                  = 3,
    CIM_CurveBreak                                 = 4,
    CIM_CurveAutoClamped                           = 5,
    CIM_MAX                                        = 6

};


// Enum  /Script/CoreUObject.Default__Enum
enum class Default__Enum : uint8_t
{

};


// Enum  /Script/CoreUObject.ERangeBoundTypes
enum class ERangeBoundTypes : uint8_t
{
    Exclusive                                      = 0,
    Inclusive                                      = 1,
    Open                                           = 2,
    ERangeBoundTypes_MAX                           = 3

};


// Enum  /Script/CoreUObject.ELocalizedTextSourceCategory
enum class ELocalizedTextSourceCategory : uint8_t
{
    Game                                           = 0,
    Engine                                         = 1,
    Editor                                         = 2,
    ELocalizedTextSourceCategory_MAX               = 3

};


// Enum  /Script/CoreUObject.EAutomationEventType
enum class EAutomationEventType : uint8_t
{
    Info                                           = 0,
    Warning                                        = 1,
    Error                                          = 2,
    EAutomationEventType_MAX                       = 3

};


// Enum  /Script/FastPicture.EFastPictureCompareType
enum class EFastPictureCompareType : uint8_t
{
    CMP_Equal                                      = 0,
    CMP_Less                                       = 1,
    CMP_LessEqual                                  = 2,
    CMP_Greater                                    = 3,
    CMP_GreaterEqual                               = 4,
    CMP_NotEqual                                   = 5,
    CMP_Regex                                      = 6,
    CMP_MAX                                        = 7

};


// Enum  /Script/FastPicture.EFastPictureSourceType
enum class EFastPictureSourceType : uint8_t
{
    SRC_PreviousRegexMatch                         = 0,
    SRC_GpuFamily                                  = 1,
    SRC_GlVersion                                  = 2,
    SRC_AndroidVersion                             = 3,
    SRC_iOSVersion                                 = 4,
    SRC_DeviceMake                                 = 5,
    SRC_DeviceModel                                = 6,
    SRC_VulkanVersion                              = 7,
    SRC_MemorySizeInGB                             = 8,
    SRC_CPUCoreNum                                 = 9,
    SRC_CPUMaxFreq                                 = 10,
    SRC_ProfileName                                = 11,
    SRC_RenderLevel                                = 12,
    SRC_Platform                                   = 13,
    SRC_Grade                                      = 14,
    SRC_GradeScore                                 = 15,
    SRC_CVarsSwitch                                = 16,
    SRC_Chipset                                    = 17,
    SRC_MainBroadInfo                              = 18,
    SRC_PhyicScreenSize                            = 19,
    SRC_MAX                                        = 20

};


// Enum  /Script/FastPicture.EFastPictureGradeScoreType
enum class EFastPictureGradeScoreType : uint8_t
{
    GST_GPU                                        = 0,
    GST_Memory                                     = 1,
    GST_CPUCore                                    = 2,
    GST_CPUFreq                                    = 3,
    GST_MAX                                        = 4

};


// Enum  /Script/FSMAsset.ETransRule
enum class ETransRule : uint8_t
{
    None                                           = 0,
    Inclusive                                      = 1,
    Exclusive                                      = 2,
    __MAX                                          = 3,
    ETransRule_MAX                                 = 4

};


// Enum  /Script/UIParticle.EUIParticlePropertyType
enum class EUIParticlePropertyType : uint8_t
{
    Float                                          = 0,
    FloatRange                                     = 1,
    FloatCurve                                     = 2,
    FloatCurveRange                                = 3,
    Vector2D                                       = 4,
    Vector2DRange                                  = 5,
    LinearColorCurve                               = 6,
    LinearColorCurveRange                          = 7,
    EUIParticlePropertyType_MAX                    = 8

};


// Enum  /Script/UIParticle.EParticleDrawEffect
enum class EParticleDrawEffect : uint8_t
{
    None                                           = 0,
    NoBlending                                     = 1,
    PreMultipliedAlpha                             = 2,
    NoGamma                                        = 4,
    InvertAlpha                                    = 8,
    NoPixelSnapping                                = 16,
    DisabledEffect                                 = 32,
    IgnoreTextureAlpha                             = 64,
    ReverseGamma                                   = 128,
    EParticleDrawEffect_MAX                        = 129

};


// Enum  /Script/UIParticle.EPositionType
enum class EPositionType : uint8_t
{
    FREE                                           = 0,
    RELATIVE                                       = 1,
    EPositionType_MAX                              = 2

};


// Enum  /Script/UIParticle.EEmitterType
enum class EEmitterType : uint8_t
{
    Gravity                                        = 0,
    Radial                                         = 1,
    Curve                                          = 2,
    EEmitterType_MAX                               = 3

};


// Enum  /Script/UIParticle.ECurveType
enum class ECurveType : uint8_t
{
    ParticleLifePercent                            = 0,
    ParticleLifeTime                               = 1,
    EmitLifeTime                                   = 2,
    ECurveType_MAX                                 = 3

};


// Enum  /Script/Engine.ETextGender
enum class ETextGender : uint8_t
{
    Masculine                                      = 0,
    Feminine                                       = 1,
    Neuter                                         = 2,
    ETextGender_MAX                                = 3

};


// Enum  /Script/Engine.EFormatArgumentType
enum class EFormatArgumentType : uint8_t
{
    Int                                            = 0,
    UInt                                           = 1,
    Float                                          = 2,
    Double                                         = 3,
    Text                                           = 4,
    Gender                                         = 5,
    EFormatArgumentType_MAX                        = 6

};


// Enum  /Script/InputCore.ETouchIndex
enum class ETouchIndex : uint8_t
{
    Touch1                                         = 0,
    Touch2                                         = 1,
    Touch3                                         = 2,
    Touch4                                         = 3,
    Touch5                                         = 4,
    Touch6                                         = 5,
    Touch7                                         = 6,
    Touch8                                         = 7,
    Touch9                                         = 8,
    Touch10                                        = 9,
    CursorPointerIndex                             = 10,
    MAX_TOUCHES                                    = 11,
    ETouchIndex_MAX                                = 12

};


// Enum  /Script/Engine.EEndPlayReason
enum class EEndPlayReason : uint8_t
{
    Destroyed                                      = 0,
    LevelTransition                                = 1,
    EndPlayInEditor                                = 2,
    RemovedFromWorld                               = 3,
    Quit                                           = 4,
    EEndPlayReason_MAX                             = 5

};


// Enum  /Script/Engine.ETickingGroup
enum class ETickingGroup : uint8_t
{
    TG_PrePhysics                                  = 0,
    TG_StartPhysics                                = 1,
    TG_DuringPhysics                               = 2,
    TG_EndPhysics                                  = 3,
    TG_PostPhysics                                 = 4,
    TG_PostUpdateWork                              = 5,
    TG_LastDemotable                               = 6,
    TG_NewlySpawned                                = 7,
    TG_MAX                                         = 8

};


// Enum  /Script/Engine.EComponentCreationMethod
enum class EComponentCreationMethod : uint8_t
{
    Native                                         = 0,
    SimpleConstructionScript                       = 1,
    UserConstructionScript                         = 2,
    Instance                                       = 3,
    EComponentCreationMethod_MAX                   = 4

};


// Enum  /Script/Engine.ETemperatureSeverityType
enum class ETemperatureSeverityType : uint8_t
{
    Unknown                                        = 0,
    Good                                           = 1,
    Bad                                            = 2,
    Serious                                        = 3,
    Critical                                       = 4,
    NumSeverities                                  = 5,
    ETemperatureSeverityType_MAX                   = 6

};


// Enum  /Script/Engine.EPlaneConstraintAxisSetting
enum class EPlaneConstraintAxisSetting : uint8_t
{
    Custom                                         = 0,
    X                                              = 1,
    Y                                              = 2,
    Z                                              = 3,
    UseGlobalPhysicsSetting                        = 4,
    EPlaneConstraintAxisSetting_MAX                = 5

};


// Enum  /Script/Engine.EInterpToBehaviourType
enum class EInterpToBehaviourType : uint8_t
{
    OneShot                                        = 0,
    OneShot_Reverse                                = 1,
    Loop_Reset                                     = 2,
    PingPong                                       = 3,
    EInterpToBehaviourType_MAX                     = 4

};


// Enum  /Script/Engine.ETeleportType
enum class ETeleportType : uint8_t
{
    None                                           = 0,
    TeleportPhysics                                = 1,
    ResetPhysics                                   = 2,
    ETeleportType_MAX                              = 3

};


// Enum  /Script/Engine.EPlatformInterfaceDataType
enum class EPlatformInterfaceDataType : uint8_t
{
    PIDT_None                                      = 0,
    PIDT_Int                                       = 1,
    PIDT_Float                                     = 2,
    PIDT_String                                    = 3,
    PIDT_Object                                    = 4,
    PIDT_Custom                                    = 5,
    PIDT_MAX                                       = 6

};


// Enum  /Script/Engine.EMovementMode
enum class EMovementMode : uint8_t
{
    MOVE_None                                      = 0,
    MOVE_Walking                                   = 1,
    MOVE_NavWalking                                = 2,
    MOVE_Falling                                   = 3,
    MOVE_Swimming                                  = 4,
    MOVE_Flying                                    = 5,
    MOVE_Climbing                                  = 6,
    MOVE_MotionMovement                            = 7,
    MOVE_Custom                                    = 8,
    MOVE_MAX                                       = 9

};


// Enum  /Script/Engine.ENetworkFailure
enum class ENetworkFailure : uint8_t
{
    NetDriverAlreadyExists                         = 0,
    NetDriverCreateFailure                         = 1,
    NetDriverListenFailure                         = 2,
    ConnectionLost                                 = 3,
    ConnectionTimeout                              = 4,
    FailureReceived                                = 5,
    OutdatedClient                                 = 6,
    OutdatedServer                                 = 7,
    PendingConnectionFailure                       = 8,
    NetGuidMismatch                                = 9,
    NetChecksumMismatch                            = 10,
    ENetworkFailure_MAX                            = 11

};


// Enum  /Script/Engine.ETravelFailure
enum class ETravelFailure : uint8_t
{
    NoLevel                                        = 0,
    LoadMapFailure                                 = 1,
    InvalidURL                                     = 2,
    PackageMissing                                 = 3,
    PackageVersion                                 = 4,
    NoDownload                                     = 5,
    TravelFailure                                  = 6,
    CheatCommands                                  = 7,
    PendingNetGameCreateFailure                    = 8,
    CloudSaveFailure                               = 9,
    ServerTravelFailure                            = 10,
    ClientTravelFailure                            = 11,
    ETravelFailure_MAX                             = 12

};


// Enum  /Script/Engine.EScreenOrientation
enum class EScreenOrientation : uint8_t
{
    Unknown                                        = 0,
    Portrait                                       = 1,
    PortraitUpsideDown                             = 2,
    LandscapeLeft                                  = 3,
    LandscapeRight                                 = 4,
    FaceUp                                         = 5,
    FaceDown                                       = 6,
    EScreenOrientation_MAX                         = 7

};


// Enum  /Script/Engine.EApplicationState
enum class EApplicationState : uint8_t
{
    Unknown                                        = 0,
    Inactive                                       = 1,
    Background                                     = 2,
    Active                                         = 3,
    EApplicationState_MAX                          = 4

};


// Enum  /Script/Engine.EObjectTypeQuery
enum class EObjectTypeQuery : uint8_t
{
    ObjectTypeQuery1                               = 0,
    ObjectTypeQuery2                               = 1,
    ObjectTypeQuery3                               = 2,
    ObjectTypeQuery4                               = 3,
    ObjectTypeQuery5                               = 4,
    ObjectTypeQuery6                               = 5,
    ObjectTypeQuery7                               = 6,
    ObjectTypeQuery8                               = 7,
    ObjectTypeQuery9                               = 8,
    ObjectTypeQuery10                              = 9,
    ObjectTypeQuery11                              = 10,
    ObjectTypeQuery12                              = 11,
    ObjectTypeQuery13                              = 12,
    ObjectTypeQuery14                              = 13,
    ObjectTypeQuery15                              = 14,
    ObjectTypeQuery16                              = 15,
    ObjectTypeQuery17                              = 16,
    ObjectTypeQuery18                              = 17,
    ObjectTypeQuery19                              = 18,
    ObjectTypeQuery20                              = 19,
    ObjectTypeQuery21                              = 20,
    ObjectTypeQuery22                              = 21,
    ObjectTypeQuery23                              = 22,
    ObjectTypeQuery24                              = 23,
    ObjectTypeQuery25                              = 24,
    ObjectTypeQuery26                              = 25,
    ObjectTypeQuery27                              = 26,
    ObjectTypeQuery28                              = 27,
    ObjectTypeQuery29                              = 28,
    ObjectTypeQuery30                              = 29,
    ObjectTypeQuery31                              = 30,
    ObjectTypeQuery32                              = 31,
    ObjectTypeQuery_MAX                            = 32,
    EObjectTypeQuery_MAX                           = 33

};


// Enum  /Script/Engine.EDrawDebugTrace
enum class EDrawDebugTrace : uint8_t
{
    None                                           = 0,
    ForOneFrame                                    = 1,
    ForDuration                                    = 2,
    Persistent                                     = 3,
    EDrawDebugTrace_MAX                            = 4

};


// Enum  /Script/Engine.ETraceTypeQuery
enum class ETraceTypeQuery : uint8_t
{
    TraceTypeQuery1                                = 0,
    TraceTypeQuery2                                = 1,
    TraceTypeQuery3                                = 2,
    TraceTypeQuery4                                = 3,
    TraceTypeQuery5                                = 4,
    TraceTypeQuery6                                = 5,
    TraceTypeQuery7                                = 6,
    TraceTypeQuery8                                = 7,
    TraceTypeQuery9                                = 8,
    TraceTypeQuery10                               = 9,
    TraceTypeQuery11                               = 10,
    TraceTypeQuery12                               = 11,
    TraceTypeQuery13                               = 12,
    TraceTypeQuery14                               = 13,
    TraceTypeQuery15                               = 14,
    TraceTypeQuery16                               = 15,
    TraceTypeQuery17                               = 16,
    TraceTypeQuery18                               = 17,
    TraceTypeQuery19                               = 18,
    TraceTypeQuery20                               = 19,
    TraceTypeQuery21                               = 20,
    TraceTypeQuery22                               = 21,
    TraceTypeQuery23                               = 22,
    TraceTypeQuery24                               = 23,
    TraceTypeQuery25                               = 24,
    TraceTypeQuery26                               = 25,
    TraceTypeQuery27                               = 26,
    TraceTypeQuery28                               = 27,
    TraceTypeQuery29                               = 28,
    TraceTypeQuery30                               = 29,
    TraceTypeQuery31                               = 30,
    TraceTypeQuery32                               = 31,
    TraceTypeQuery_MAX                             = 32,
    ETraceTypeQuery_MAX                            = 33

};


// Enum  /Script/Engine.EMoveComponentAction
enum class EMoveComponentAction : uint8_t
{
    Move                                           = 0,
    Stop                                           = 1,
    Return                                         = 2,
    EMoveComponentAction_MAX                       = 3

};


// Enum  /Script/Engine.EQuitPreference
enum class EQuitPreference : uint8_t
{
    Quit                                           = 0,
    Background                                     = 1,
    EQuitPreference_MAX                            = 2

};


// Enum  /Script/Engine.EPhysicalSurface
enum class EPhysicalSurface : uint8_t
{
    SurfaceType_Default                            = 0,
    SurfaceType1                                   = 1,
    SurfaceType2                                   = 2,
    SurfaceType3                                   = 3,
    SurfaceType4                                   = 4,
    SurfaceType5                                   = 5,
    SurfaceType6                                   = 6,
    SurfaceType7                                   = 7,
    SurfaceType8                                   = 8,
    SurfaceType9                                   = 9,
    SurfaceType10                                  = 10,
    SurfaceType11                                  = 11,
    SurfaceType12                                  = 12,
    SurfaceType13                                  = 13,
    SurfaceType14                                  = 14,
    SurfaceType15                                  = 15,
    SurfaceType16                                  = 16,
    SurfaceType17                                  = 17,
    SurfaceType18                                  = 18,
    SurfaceType19                                  = 19,
    SurfaceType20                                  = 20,
    SurfaceType21                                  = 21,
    SurfaceType22                                  = 22,
    SurfaceType23                                  = 23,
    SurfaceType24                                  = 24,
    SurfaceType25                                  = 25,
    SurfaceType26                                  = 26,
    SurfaceType27                                  = 27,
    SurfaceType28                                  = 28,
    SurfaceType29                                  = 29,
    SurfaceType30                                  = 30,
    SurfaceType31                                  = 31,
    SurfaceType32                                  = 32,
    SurfaceType33                                  = 33,
    SurfaceType34                                  = 34,
    SurfaceType35                                  = 35,
    SurfaceType36                                  = 36,
    SurfaceType37                                  = 37,
    SurfaceType38                                  = 38,
    SurfaceType39                                  = 39,
    SurfaceType40                                  = 40,
    SurfaceType41                                  = 41,
    SurfaceType42                                  = 42,
    SurfaceType43                                  = 43,
    SurfaceType44                                  = 44,
    SurfaceType45                                  = 45,
    SurfaceType46                                  = 46,
    SurfaceType47                                  = 47,
    SurfaceType48                                  = 48,
    SurfaceType49                                  = 49,
    SurfaceType50                                  = 50,
    SurfaceType51                                  = 51,
    SurfaceType52                                  = 52,
    SurfaceType53                                  = 53,
    SurfaceType54                                  = 54,
    SurfaceType55                                  = 55,
    SurfaceType56                                  = 56,
    SurfaceType57                                  = 57,
    SurfaceType58                                  = 58,
    SurfaceType59                                  = 59,
    SurfaceType60                                  = 60,
    SurfaceType61                                  = 61,
    SurfaceType62                                  = 62,
    SurfaceType_Max                                = 63,
    EPhysicalSurface_MAX                           = 64

};


// Enum  /Script/Skill.EUTSkillStopReason
enum class EUTSkillStopReason : uint8_t
{
    SkillStopReason_UnKown                         = 0,
    SkillStopReason_Finished                       = 1,
    SkillStopReason_FailedWithSkillInvalid         = 2,
    SkillStopReason_FailedWithPhaseInvalid         = 3,
    SkillStopReason_FailedWithConditionInvalid     = 4,
    SkillStopReason_UserCanceled                   = 5,
    SkillStopReason_Interrupted                    = 6,
    SkillStopReason_Clear                          = 7,
    SkillStopReason_MainHandNoRecoverInterrupted   = 8,
    SkillStopReason_MainHandCanRecoverInterrupted  = 9,
    SkillStopReason_ClientPredictFailed            = 10,
    SkillStopReason_MAX                            = 11

};


// Enum  /Script/Skill.EUTSkillEventType
enum class EUTSkillEventType : uint8_t
{
    SET_KEY_DOWN                                   = 0,
    SET_KEY_UP                                     = 1,
    SET_COLLIDE_TARGET                             = 2,
    SET_MISS_TARGET                                = 3,
    SET_HIT_TARGET                                 = 4,
    SET_KILL_TARGET                                = 5,
    SET_COLLIDE_ACTOR                              = 6,
    SET_FINDPATH_FINISH                            = 7,
    SET_PHASE_START                                = 8,
    SET_PHASE_FINISH                               = 9,
    SET_PHASE_FINISH_EARLY                         = 10,
    SET_PHASE_INTERRUPT                            = 11,
    SET_SKILL_FINISH                               = 12,
    SET_SKILL_CANCEL                               = 13,
    SET_NO_TARGET                                  = 14,
    SET_SKILL_INTERRUPT                            = 15,
    SET_MAX                                        = 16

};


// Enum  /Script/Skill.ESkillAttrOperator
enum class ESkillAttrOperator : uint8_t
{
    Additive                                       = 0,
    Multiplicitive                                 = 1,
    MultiplicitiveScale                            = 2,
    Override                                       = 3,
    Max                                            = 4

};


// Enum  /Script/Skill.EDamageSourceType
enum class EDamageSourceType : uint8_t
{
    NormalDamage                                   = 0,
    TrueDamage                                     = 1,
    Explosion                                      = 2,
    Burns                                          = 3,
    Hero07_                                        = 4,
    EDamageSourceType_MAX                          = 5

};


// Enum  /Script/Skill.ETriggerSkillCondition
enum class ETriggerSkillCondition : uint8_t
{
    Self                                           = 0,
    Teammates                                      = 1,
    Enemy                                          = 2,
    ETriggerSkillCondition_MAX                     = 3

};


// Enum  /Script/Skill.ESkillType
enum class ESkillType : uint8_t
{
    Technical                                      = 0,
    Passive                                        = 1,
    Ultimate                                       = 2,
    ByItem                                         = 3,
    MeleeAttack                                    = 4,
    Others                                         = 5,
    ESkillType_MAX                                 = 6

};


// Enum  /Script/Skill.ESkillCastType
enum class ESkillCastType : uint8_t
{
    Normal                                         = 1,
    Trigger                                        = 2,
    Passive                                        = 3,
    Max                                            = 4

};


// Enum  /Script/Skill.ECDCompare
enum class ECDCompare : uint8_t
{
    CDC_Bigger                                     = 0,
    CDC_Equal                                      = 1,
    CDC_Smaller                                    = 2,
    CDC_MAX                                        = 3

};


// Enum  /Script/Skill.ECDType
enum class ECDType : uint8_t
{
    CDT_Energy                                     = 1,
    CDT_Point                                      = 2,
    CDT_MAX                                        = 3

};


// Enum  /Script/Skill.ESkillCollectResourcesType
enum class ESkillCollectResourcesType : uint8_t
{
    ESCRT_FPP_Only                                 = 0,
    ESCRT_TPP_Only                                 = 1,
    ESCRT_All                                      = 2,
    ESCRT_MAX                                      = 3

};


// Enum  /Script/Skill.ESkillAddForceDirection
enum class ESkillAddForceDirection : uint8_t
{
    ESkillDir_SelfToTarget                         = 0,
    ESkillDir_TargetToSelf                         = 1,
    ESkillDir_SelfDir                              = 2,
    ESkillDir_TargetDir                            = 3,
    ESkillDir_TargetZ                              = 4,
    ESkillDir_SelfZ                                = 5,
    ESkillDir_MAX                                  = 6

};


// Enum  /Script/Skill.ECDSpeedUpType
enum class ECDSpeedUpType : uint8_t
{
    UnUseSpeed                                     = 0,
    TacticalType                                   = 1,
    UltimateType                                   = 2,
    PassiveType                                    = 3,
    None                                           = 4,
    ECDSpeedUpType_MAX                             = 5

};


// Enum  /Script/Skill.UTPickerTargetType
enum class UTPickerTargetType : uint8_t
{
    PTT_FRIEND                                     = 0,
    PTT_ENEMY                                      = 1,
    PTT_ALL                                        = 2,
    PTT_Self                                       = 3,
    PTT_MAX                                        = 4

};


// Enum  /Script/Skill.EUTSkillPhaseJumpResult
enum class EUTSkillPhaseJumpResult : uint8_t
{
    PJR_OK                                         = 0,
    PJR_LIFE_FULL                                  = 1,
    PJR_ARMOR_UNEQUIPPED                           = 2,
    PJR_ARMOR_FULL                                 = 3,
    PJR_LIFE_AND_ARMOR_FULL                        = 4,
    PJR_ULTIMATE_SKILL_READY                       = 5,
    PJR_ITEM_IN_USE                                = 6,
    PJR_IN_DEATH_PROTECT_STATE                     = 7,
    PJR_TOTEM_SPACE_LIMITED                        = 8,
    PJR_NoTarget                                   = 9,
    PJR_MAX                                        = 10

};


// Enum  /Script/Skill.ESkillActionDataNetRole
enum class ESkillActionDataNetRole : uint8_t
{
    TO_CLIENT                                      = 0,
    TO_SERVER                                      = 1,
    TO_MULTICAST                                   = 2,
    TO_MAX                                         = 3

};


// Enum  /Script/Skill.ESkillEndConditionType
enum class ESkillEndConditionType : uint8_t
{
    ESECT_MyHP                                     = 0,
    ESECT_MyHPAndSD                                = 1,
    ESECT_FrinedHP                                 = 2,
    ESECT_ExistsEnemy                              = 3,
    ESECT_ExistsEnemy2                             = 4,
    ESECT_ExistsEnemyAndFriends                    = 5,
    ESECT_AnyTime                                  = 6,
    ESECT_None                                     = 7,
    ESECT_MAX                                      = 8

};


// Enum  /Script/Skill.ESkillConditionType
enum class ESkillConditionType : uint8_t
{
    ESCT_MyHP                                      = 0,
    ESCT_MyHPAndSD                                 = 1,
    ESCT_MyHPAndSDNoEmeny                          = 2,
    ESCT_FrinedHP                                  = 3,
    ESCT_ExistsEnemy                               = 4,
    ESCT_ExistsEnemy2                              = 5,
    ESCT_ExistsEnemyAndFriends                     = 6,
    ESCT_AnyTime                                   = 7,
    ESCT_None                                      = 8,
    ESCT_MAX                                       = 9

};


// Enum  /Script/Skill.UTSkillPhaseType
enum class UTSkillPhaseType : uint8_t
{
    SPT_SEQUENCE                                   = 0,
    SPT_WAIT                                       = 1,
    SPT_FINAL                                      = 2,
    SPT_MAX                                        = 3

};


// Enum  /Script/Skill.UTSkillPickerType
enum class UTSkillPickerType : uint8_t
{
    SPT_SELF                                       = 0,
    SPT_TARGET                                     = 1,
    SPT_VIEWPOINT                                  = 2,
    SPT_VIEWPOINT_STATIC                           = 3,
    SPT_RECT                                       = 4,
    SPT_CIRCLE                                     = 5,
    SPT_FAN                                        = 6,
    SPT_CROSSHAIR                                  = 7,
    SPT_CUSTOM                                     = 8,
    SPT_DESTINATION                                = 9,
    SPT_VIEWPOINT_NORMAL                           = 10,
    SPT_DEFAULT                                    = 11,
    SPT_MAX                                        = 12

};


// Enum  /Script/IdeaDecal.EIdeaDecalParentType
enum class EIdeaDecalParentType : uint8_t
{
    NoParent                                       = 0,
    MovableStaticMesh                              = 1,
    SkeletalMesh                                   = 2,
    DestroyableStaticMesh                          = 3,
    EIdeaDecalParentType_MAX                       = 4

};


// Enum  /Script/RuntimeMeshComponent.ERuntimeMeshThreadingPriority
enum class ERuntimeMeshThreadingPriority : uint8_t
{
    Normal                                         = 0,
    AboveNormal                                    = 1,
    BelowNormal                                    = 2,
    Highest                                        = 3,
    Lowest                                         = 4,
    SlightlyBelowNormal                            = 5,
    TimeCritical                                   = 6,
    ERuntimeMeshThreadingPriority_MAX              = 7

};


// Enum  /Script/RuntimeMeshComponent.ERuntimeMeshCollisionFaceSourceType
enum class ERuntimeMeshCollisionFaceSourceType : uint8_t
{
    Collision                                      = 0,
    Renderable                                     = 1,
    ERuntimeMeshCollisionFaceSourceType_MAX        = 2

};


// Enum  /Script/RuntimeMeshComponent.ERuntimeMeshCollisionCookingMode
enum class ERuntimeMeshCollisionCookingMode : uint8_t
{
    CollisionPerformance                           = 0,
    CookingPerformance                             = 1,
    ERuntimeMeshCollisionCookingMode_MAX           = 2

};


// Enum  /Script/RuntimeMeshComponent.ERuntimeMeshUpdateFrequency
enum class ERuntimeMeshUpdateFrequency : uint8_t
{
    Average                                        = 0,
    Frequent                                       = 1,
    Infrequent                                     = 2,
    ERuntimeMeshUpdateFrequency_MAX                = 3

};


// Enum  /Script/RuntimeMeshComponent.ERuntimeMeshMobility
enum class ERuntimeMeshMobility : uint8_t
{
    Movable                                        = 0,
    Stationary                                     = 1,
    Static                                         = 2,
    ERuntimeMeshMobility_MAX                       = 3

};


// Enum  /Script/AIModule.EPathFollowingResult
enum class EPathFollowingResult : uint8_t
{
    Success                                        = 0,
    Blocked                                        = 1,
    OffPath                                        = 2,
    Aborted                                        = 3,
    Skipped_DEPRECATED                             = 4,
    Invalid                                        = 5,
    EPathFollowingResult_MAX                       = 6

};


// Enum  /Script/AIModule.EEnvQueryStatus
enum class EEnvQueryStatus : uint8_t
{
    Processing                                     = 0,
    Success                                        = 1,
    Failed                                         = 2,
    Aborted                                        = 3,
    OwnerLost                                      = 4,
    MissingParam                                   = 5,
    EEnvQueryStatus_MAX                            = 6

};


// Enum  /Script/UESVON.ESVONPathfindingRequestResult
enum class ESVONPathfindingRequestResult : uint8_t
{
    Failed                                         = 0,
    ReadyToPath                                    = 1,
    AlreadyAtGoal                                  = 2,
    Deferred                                       = 3,
    Success                                        = 4,
    ESVONPathfindingRequestResult_MAX              = 5

};


// Enum  /Script/UESVON.EBuildTrigger
enum class EBuildTrigger : uint8_t
{
    OnEdit                                         = 0,
    Manual                                         = 1,
    EBuildTrigger_MAX                              = 2

};


// Enum  /Script/UESVON.ESVONPathPostProcess
enum class ESVONPathPostProcess : uint8_t
{
    None                                           = 0,
    StringPulling                                  = 1,
    NaiveTrace                                     = 2,
    ESVONPathPostProcess_MAX                       = 3

};


// Enum  /Script/UESVON.ESVONPathCostType
enum class ESVONPathCostType : uint8_t
{
    MANHATTAN                                      = 0,
    EUCLIDEAN                                      = 1,
    ESVONPathCostType_MAX                          = 2

};


// Enum  /Script/Chapter_Runtime.EChapterParamType
enum class EChapterParamType : uint8_t
{
    String                                         = 0,
    Float                                          = 1,
    Number                                         = 2,
    EChapterParamType_MAX                          = 3

};


// Enum  /Script/EntityDispatcher_Runtime.EDispatchableActionState
enum class EDispatchableActionState : uint8_t
{
    Unactived                                      = 0,
    Actived                                        = 1,
    Aborting                                       = 2,
    Finished                                       = 3,
    EDispatchableActionState_MAX                   = 4

};


// Enum  /Script/EntityDispatcher_Runtime.EDispatchableActionAbortState
enum class EDispatchableActionAbortState : uint8_t
{
    Initiative                                     = 0,
    Passive                                        = 1,
    EDispatchableActionAbortState_MAX              = 2

};


// Enum  /Script/EntityDispatcher_Runtime.EDispatchableActionCompatibleType
enum class EDispatchableActionCompatibleType : uint8_t
{
    Abort                                          = 0,
    Coexist                                        = 1,
    Invalid                                        = 2,
    EDispatchableActionCompatibleType_MAX          = 3

};


// Enum  /Script/EntityDispatcher_Runtime.EActionDispatcherState
enum class EActionDispatcherState : uint8_t
{
    Unactived                                      = 0,
    Actived                                        = 1,
    Aborting                                       = 2,
    Finished                                       = 3,
    Finishing                                      = 4,
    EActionDispatcherState_MAX                     = 5

};


// Enum  /Script/EventFlowSystem.EEventFlowState
enum class EEventFlowState : uint8_t
{
    Unactived                                      = 0,
    Actived                                        = 1,
    Finished                                       = 2,
    EEventFlowState_MAX                            = 3

};


// Enum  /Script/EventFlowSystem.EEventFlowElementLogic
enum class EEventFlowElementLogic : uint8_t
{
    And                                            = 0,
    Or                                             = 1,
    EEventFlowElementLogic_MAX                     = 2

};


// Enum  /Script/GameAction_Runtime.EGameActionAnimationTearDownStrategy
enum class EGameActionAnimationTearDownStrategy : uint8_t
{
    Stop                                           = 0,
    PlayToEnd                                      = 1,
    EGameActionAnimationTearDownStrategy_MAX       = 2

};


// Enum  /Script/GameAction_Runtime.EGameActionSpawnOwnership
enum class EGameActionSpawnOwnership : uint8_t
{
    Sequence                                       = 0,
    Instance                                       = 1,
    External                                       = 2,
    EGameActionSpawnOwnership_MAX                  = 3

};


// Enum  /Script/GameAction_Runtime.EGameActionPlayerEndAction
enum class EGameActionPlayerEndAction : uint8_t
{
    Stop                                           = 0,
    Loop                                           = 1,
    Pause                                          = 2,
    EGameActionPlayerEndAction_MAX                 = 3

};


// Enum  /Script/Pandora.EPropertyClass
enum class EPropertyClass : uint8_t
{
    Byte                                           = 0,
    Int8                                           = 1,
    Int16                                          = 2,
    Int                                            = 3,
    Int64                                          = 4,
    UInt16                                         = 5,
    UInt32                                         = 6,
    UInt64                                         = 7,
    UnsizedInt                                     = 8,
    UnsizedUInt                                    = 9,
    Float                                          = 10,
    Double                                         = 11,
    Bool                                           = 12,
    SoftClass                                      = 13,
    WeakObject                                     = 14,
    LazyObject                                     = 15,
    SoftObject                                     = 16,
    Class                                          = 17,
    Object                                         = 18,
    Interface                                      = 19,
    Name                                           = 20,
    Str                                            = 21,
    Array                                          = 22,
    Map                                            = 23,
    Set                                            = 24,
    Struct                                         = 25,
    Delegate                                       = 26,
    MulticastDelegate                              = 27,
    Text                                           = 28,
    Enum                                           = 29,
    EPropertyClass_MAX                             = 30

};


// Enum  /Script/Pandora.EPandoraPanelType
enum class EPandoraPanelType : uint8_t
{
    PDRPT_Pandora                                  = 0,
    PDRPT_Gamelet                                  = 1,
    PDRPT_MAX                                      = 2

};


// Enum  /Script/Pandora.EPandoraCMDType
enum class EPandoraCMDType : uint8_t
{
    PDRCT_Pandora                                  = 0,
    PDRCT_Gamelet                                  = 1,
    PDRCT_Undefined                                = 2,
    PDRCT_MAX                                      = 3

};


// Enum  /Script/Pandora.EPandoraEnv
enum class EPandoraEnv : uint8_t
{
    PDR_Test                                       = 0,
    PDR_Prod                                       = 1,
    PDR_SingaporeTest                              = 2,
    PDR_SingaporeProd                              = 3,
    PDR_NorthAmericaTest                           = 4,
    PDR_NorthAmericaProd                           = 5,
    PDR_EnvMax                                     = 6,
    PDR_MAX                                        = 7

};


// Enum  /Script/Paper2D.EFlipbookCollisionMode
enum class EFlipbookCollisionMode : uint8_t
{
    NoCollision                                    = 0,
    FirstFrameCollision                            = 1,
    EachFrameCollision                             = 2,
    EFlipbookCollisionMode_MAX                     = 3

};


// Enum  /Script/Paper2D.EPaperSpriteAtlasPadding
enum class EPaperSpriteAtlasPadding : uint8_t
{
    DilateBorder                                   = 0,
    PadWithZero                                    = 1,
    EPaperSpriteAtlasPadding_MAX                   = 2

};


// Enum  /Script/Paper2D.ETileMapProjectionMode
enum class ETileMapProjectionMode : uint8_t
{
    Orthogonal                                     = 0,
    IsometricDiamond                               = 1,
    IsometricStaggered                             = 2,
    HexagonalStaggered                             = 3,
    ETileMapProjectionMode_MAX                     = 4

};


// Enum  /Script/Paper2D.ESpritePivotMode
enum class ESpritePivotMode : uint8_t
{
    Top_Left                                       = 0,
    Top_Center                                     = 1,
    Top_Right                                      = 2,
    Center_Left                                    = 3,
    Center_Center                                  = 4,
    Center_Right                                   = 5,
    Bottom_Left                                    = 6,
    Bottom_Center                                  = 7,
    Bottom_Right                                   = 8,
    Custom                                         = 9,
    ESpritePivotMode_MAX                           = 10

};


// Enum  /Script/Paper2D.ESpritePolygonMode
enum class ESpritePolygonMode : uint8_t
{
    SourceBoundingBox                              = 0,
    TightBoundingBox                               = 1,
    ShrinkWrapped                                  = 2,
    FullyCustom                                    = 3,
    Diced                                          = 4,
    ESpritePolygonMode_MAX                         = 5

};


// Enum  /Script/Paper2D.ESpriteShapeType
enum class ESpriteShapeType : uint8_t
{
    Box                                            = 0,
    Circle                                         = 1,
    Polygon                                        = 2,
    ESpriteShapeType_MAX                           = 3

};


// Enum  /Script/Paper2D.ESpriteCollisionMode
enum class ESpriteCollisionMode : uint8_t
{
    None                                           = 0,
    Use2DPhysics                                   = 1,
    Use3DPhysics                                   = 2,
    ESpriteCollisionMode_MAX                       = 3

};


// Enum  /Script/PixUI.EPXKeyboardTypes
enum class EPXKeyboardTypes : uint8_t
{
    em_px_key_board_default                        = 0,
    em_px_key_board_number                         = 1,
    em_px_key_board_password                       = 2,
    em_px_key_board_count                          = 3,
    em_px_key_board_MAX                            = 4

};


// Enum  /Script/PixUI.EPXViewEvent
enum class EPXViewEvent : uint8_t
{
    em_px_event_moveby                             = 0,
    em_px_event_moveto                             = 1,
    em_px_event_resizeby                           = 2,
    em_px_event_resizeto                           = 3,
    em_px_event_scrollby                           = 4,
    em_px_event_scrollto                           = 5,
    em_px_event_count                              = 6,
    em_px_event_MAX                                = 7

};


// Enum  /Script/PixUI.EPXLogLevels
enum class EPXLogLevels : uint8_t
{
    em_px_log_level_log                            = 0,
    em_px_log_level_warning                        = 1,
    em_px_log_level_error                          = 2,
    em_px_log_level_count                          = 3,
    em_px_log_level_MAX                            = 4

};


// Enum  /Script/PixUI.EPXLogTypes
enum class EPXLogTypes : uint8_t
{
    em_px_log_type_core                            = 0,
    em_px_log_type_plugin                          = 1,
    em_px_log_type_trace                           = 2,
    em_px_log_type_script                          = 3,
    em_px_log_type_count                           = 4,
    em_px_log_type_MAX                             = 5

};


// Enum  /Script/Engine.ERelativeTransformSpace
enum class ERelativeTransformSpace : uint8_t
{
    RTS_World                                      = 0,
    RTS_Actor                                      = 1,
    RTS_Component                                  = 2,
    RTS_ParentBoneSpace                            = 3,
    RTS_ViewTranslated                             = 4,
    RTS_MAX                                        = 5

};


// Enum  /Script/Engine.EAttachLocation
enum class EAttachLocation : uint8_t
{
    KeepRelativeOffset                             = 0,
    KeepWorldPosition                              = 1,
    SnapToTarget                                   = 2,
    SnapToTargetIncludingScale                     = 3,
    EAttachLocation_MAX                            = 4

};


// Enum  /Script/Engine.EAttachmentRule
enum class EAttachmentRule : uint8_t
{
    KeepRelative                                   = 0,
    KeepWorld                                      = 1,
    SnapToTarget                                   = 2,
    EAttachmentRule_MAX                            = 3

};


// Enum  /Script/Engine.EDetachmentRule
enum class EDetachmentRule : uint8_t
{
    KeepRelative                                   = 0,
    KeepWorld                                      = 1,
    EDetachmentRule_MAX                            = 2

};


// Enum  /Script/Engine.EComponentMobility
enum class EComponentMobility : uint8_t
{
    Static                                         = 0,
    Stationary                                     = 1,
    Movable                                        = 2,
    EComponentMobility_MAX                         = 3

};


// Enum  /Script/Engine.EDetailMode
enum class EDetailMode : uint8_t
{
    DM_Low                                         = 0,
    DM_Medium                                      = 1,
    DM_High                                        = 2,
    DM_MAX                                         = 3

};


// Enum  /Script/ReplicatedLevelInstance.EReplicatedSubLevelInstanceType
enum class EReplicatedSubLevelInstanceType : uint8_t
{
    Main                                           = 0,
    AlwaysLoaded                                   = 1,
    ScriptLoaded                                   = 2,
    EReplicatedSubLevelInstanceType_MAX            = 3

};


// Enum  /Script/SpinePlugin.ESpineWidgetAreaType
enum class ESpineWidgetAreaType : uint8_t
{
    Bounds                                         = 0,
    Scale                                          = 1,
    ESpineWidgetAreaType_MAX                       = 2

};


// Enum  /Script/ProceduralMeshComponent.EProcMeshSliceCapOption
enum class EProcMeshSliceCapOption : uint8_t
{
    NoCap                                          = 0,
    CreateNewSectionForCap                         = 1,
    UseLastSectionForCap                           = 2,
    EProcMeshSliceCapOption_MAX                    = 3

};


// Enum  /Script/UIControllerRuntime.EControlValueType
enum class EControlValueType : uint8_t
{
    String                                         = 0,
    FText                                          = 1,
    FPath                                          = 2,
    UObject                                        = 3,
    EControlValueType_MAX                          = 4

};


// Enum  /Script/AkAudio.EAkCallbackType
enum class EAkCallbackType : uint8_t
{
    EndOfEvent                                     = 0,
    Marker                                         = 2,
    Duration                                       = 3,
    Starvation                                     = 5,
    MusicPlayStarted                               = 7,
    MusicSyncBeat                                  = 8,
    MusicSyncBar                                   = 9,
    MusicSyncEntry                                 = 10,
    MusicSyncExit                                  = 11,
    MusicSyncGrid                                  = 12,
    MusicSyncUserCue                               = 13,
    MusicSyncPoint                                 = 14,
    MIDIEvent                                      = 16,
    EAkCallbackType_MAX                            = 17

};


// Enum  /Script/AkAudio.EAkResult
enum class EAkResult : uint8_t
{
    NotImplemented                                 = 0,
    Success                                        = 1,
    Fail                                           = 2,
    PartialSuccess                                 = 3,
    NotCompatible                                  = 4,
    AlreadyConnected                               = 5,
    InvalidFile                                    = 7,
    AudioFileHeaderTooLarge                        = 8,
    MaxReached                                     = 9,
    InvalidID                                      = 14,
    IDNotFound                                     = 15,
    InvalidInstanceID                              = 16,
    NoMoreData                                     = 17,
    InvalidStateGroup                              = 20,
    ChildAlreadyHasAParent                         = 21,
    InvalidLanguage                                = 22,
    CannotAddItseflAsAChild                        = 23,
    InvalidParameter                               = 31,
    ElementAlreadyInList                           = 35,
    PathNotFound                                   = 36,
    PathNoVertices                                 = 37,
    PathNotRunning                                 = 38,
    PathNotPaused                                  = 39,
    PathNodeAlreadyInList                          = 40,
    PathNodeNotInList                              = 41,
    DataNeeded                                     = 43,
    NoDataNeeded                                   = 44,
    DataReady                                      = 45,
    NoDataReady                                    = 46,
    InsufficientMemory                             = 52,
    Cancelled                                      = 53,
    UnknownBankID                                  = 54,
    BankReadError                                  = 56,
    InvalidSwitchType                              = 57,
    FormatNotReady                                 = 63,
    WrongBankVersion                               = 64,
    FileNotFound                                   = 66,
    DeviceNotReady                                 = 67,
    BankAlreadyLoaded                              = 69,
    RenderedFX                                     = 71,
    ProcessNeeded                                  = 72,
    ProcessDone                                    = 73,
    MemManagerNotInitialized                       = 74,
    StreamMgrNotInitialized                        = 75,
    SSEInstructionsNotSupported                    = 76,
    Busy                                           = 77,
    UnsupportedChannelConfig                       = 78,
    PluginMediaNotAvailable                        = 79,
    MustBeVirtualized                              = 80,
    CommandTooLarge                                = 81,
    RejectedByFilter                               = 82,
    InvalidCustomPlatformName                      = 83,
    DLLCannotLoad                                  = 84,
    DLLPathNotFound                                = 85,
    NoJavaVM                                       = 86,
    OpenSLError                                    = 87,
    PluginNotRegistered                            = 88,
    DataAlignmentError                             = 89,
    EAkResult_MAX                                  = 90

};


// Enum  /Script/AkAudio.EAkMultiPositionMode
enum class EAkMultiPositionMode : uint8_t
{
    Simple_Mode                                    = 0,
    Large_Mode                                     = 1,
    MultiPosition_Mode                             = 2,
    EAkMultiPositionMode_MAX                       = 3

};


// Enum  /Script/AkAudio.EAkAndroidAudioAPI
enum class EAkAndroidAudioAPI : uint8_t
{
    AAudio                                         = 0,
    OpenSL_ES                                      = 1,
    EAkAndroidAudioAPI_MAX                         = 2

};


// Enum  /Script/AkAudio.EReflectionFilterBits
enum class EReflectionFilterBits : uint8_t
{
    Wall                                           = 0,
    Ceiling                                        = 1,
    Floor                                          = 2,
    EReflectionFilterBits_MAX                      = 3

};


// Enum  /Script/AkAudio.AkCodecId
enum class AkCodecId : uint8_t
{
    Bank                                           = 0,
    PCM                                            = 1,
    ADPCM                                          = 2,
    XMA                                            = 3,
    Vorbis                                         = 4,
    WiiADPCM                                       = 5,
    PCMEX                                          = 7,
    ExternalSource                                 = 8,
    XWMA                                           = 9,
    AAC                                            = 10,
    FilePackage                                    = 11,
    ATRAC9                                         = 12,
    VAG                                            = 13,
    ProfilerCapture                                = 14,
    AnalysisFile                                   = 15,
    MIDI                                           = 16,
    OpusNX                                         = 17,
    CAF                                            = 18,
    AkOpus                                         = 19,
    AkCodecId_MAX                                  = 20

};


// Enum  /Script/AkAudio.EAkMidiCcValues
enum class EAkMidiCcValues : uint8_t
{
    AkMidiCcBankSelectCoarse                       = 0,
    AkMidiCcModWheelCoarse                         = 1,
    AkMidiCcBreathCtrlCoarse                       = 2,
    AkMidiCcCtrl3Coarse                            = 3,
    AkMidiCcFootPedalCoarse                        = 4,
    AkMidiCcPortamentoCoarse                       = 5,
    AkMidiCcDataEntryCoarse                        = 6,
    AkMidiCcVolumeCoarse                           = 7,
    AkMidiCcBalanceCoarse                          = 8,
    AkMidiCcCtrl9Coarse                            = 9,
    AkMidiCcPanPositionCoarse                      = 10,
    AkMidiCcExpressionCoarse                       = 11,
    AkMidiCcEffectCtrl1Coarse                      = 12,
    AkMidiCcEffectCtrl2Coarse                      = 13,
    AkMidiCcCtrl14Coarse                           = 14,
    AkMidiCcCtrl15Coarse                           = 15,
    AkMidiCcGenSlider1                             = 16,
    AkMidiCcGenSlider2                             = 17,
    AkMidiCcGenSlider3                             = 18,
    AkMidiCcGenSlider4                             = 19,
    AkMidiCcCtrl20Coarse                           = 20,
    AkMidiCcCtrl21Coarse                           = 21,
    AkMidiCcCtrl22Coarse                           = 22,
    AkMidiCcCtrl23Coarse                           = 23,
    AkMidiCcCtrl24Coarse                           = 24,
    AkMidiCcCtrl25Coarse                           = 25,
    AkMidiCcCtrl26Coarse                           = 26,
    AkMidiCcCtrl27Coarse                           = 27,
    AkMidiCcCtrl28Coarse                           = 28,
    AkMidiCcCtrl29Coarse                           = 29,
    AkMidiCcCtrl30Coarse                           = 30,
    AkMidiCcCtrl31Coarse                           = 31,
    AkMidiCcBankSelectFine                         = 32,
    AkMidiCcModWheelFine                           = 33,
    AkMidiCcBreathCtrlFine                         = 34,
    AkMidiCcCtrl3Fine                              = 35,
    AkMidiCcFootPedalFine                          = 36,
    AkMidiCcPortamentoFine                         = 37,
    AkMidiCcDataEntryFine                          = 38,
    AkMidiCcVolumeFine                             = 39,
    AkMidiCcBalanceFine                            = 40,
    AkMidiCcCtrl9Fine                              = 41,
    AkMidiCcPanPositionFine                        = 42,
    AkMidiCcExpressionFine                         = 43,
    AkMidiCcEffectCtrl1Fine                        = 44,
    AkMidiCcEffectCtrl2Fine                        = 45,
    AkMidiCcCtrl14Fine                             = 46,
    AkMidiCcCtrl15Fine                             = 47,
    AkMidiCcCtrl20Fine                             = 52,
    AkMidiCcCtrl21Fine                             = 53,
    AkMidiCcCtrl22Fine                             = 54,
    AkMidiCcCtrl23Fine                             = 55,
    AkMidiCcCtrl24Fine                             = 56,
    AkMidiCcCtrl25Fine                             = 57,
    AkMidiCcCtrl26Fine                             = 58,
    AkMidiCcCtrl27Fine                             = 59,
    AkMidiCcCtrl28Fine                             = 60,
    AkMidiCcCtrl29Fine                             = 61,
    AkMidiCcCtrl30Fine                             = 62,
    AkMidiCcCtrl31Fine                             = 63,
    AkMidiCcHoldPedal                              = 64,
    AkMidiCcPortamentoOnOff                        = 65,
    AkMidiCcSustenutoPedal                         = 66,
    AkMidiCcSoftPedal                              = 67,
    AkMidiCcLegatoPedal                            = 68,
    AkMidiCcHoldPedal2                             = 69,
    AkMidiCcSoundVariation                         = 70,
    AkMidiCcSoundTimbre                            = 71,
    AkMidiCcSoundReleaseTime                       = 72,
    AkMidiCcSoundAttackTime                        = 73,
    AkMidiCcSoundBrightness                        = 74,
    AkMidiCcSoundCtrl6                             = 75,
    AkMidiCcSoundCtrl7                             = 76,
    AkMidiCcSoundCtrl8                             = 77,
    AkMidiCcSoundCtrl9                             = 78,
    AkMidiCcSoundCtrl10                            = 79,
    AkMidiCcGeneralButton1                         = 80,
    AkMidiCcGeneralButton2                         = 81,
    AkMidiCcGeneralButton3                         = 82,
    AkMidiCcGeneralButton4                         = 83,
    AkMidiCcReverbLevel                            = 91,
    AkMidiCcTremoloLevel                           = 92,
    AkMidiCcChorusLevel                            = 93,
    AkMidiCcCelesteLevel                           = 94,
    AkMidiCcPhaserLevel                            = 95,
    AkMidiCcDataButtonP1                           = 96,
    AkMidiCcDataButtonM1                           = 97,
    AkMidiCcNonRegisterCoarse                      = 98,
    AkMidiCcNonRegisterFine                        = 99,
    AkMidiCcAllSoundOff                            = 120,
    AkMidiCcAllControllersOff                      = 121,
    AkMidiCcLocalKeyboard                          = 122,
    AkMidiCcAllNotesOff                            = 123,
    AkMidiCcOmniModeOff                            = 124,
    AkMidiCcOmniModeOn                             = 125,
    AkMidiCcOmniMonophonicOn                       = 126,
    AkMidiCcOmniPolyphonicOn                       = 127,
    EAkMidiCcValues_MAX                            = 128

};


// Enum  /Script/AkAudio.EAkMidiEventType
enum class EAkMidiEventType : uint8_t
{
    AkMidiEventTypeInvalid                         = 0,
    AkMidiEventTypeNoteOff                         = 128,
    AkMidiEventTypeNoteOn                          = 144,
    AkMidiEventTypeNoteAftertouch                  = 160,
    AkMidiEventTypeController                      = 176,
    AkMidiEventTypeProgramChange                   = 192,
    AkMidiEventTypeChannelAftertouch               = 208,
    AkMidiEventTypePitchBend                       = 224,
    AkMidiEventTypeSysex                           = 240,
    AkMidiEventTypeEscape                          = 247,
    AkMidiEventTypeMeta                            = 255,
    EAkMidiEventType_MAX                           = 256

};


// Enum  /Script/AkAudio.ERTPCValueType
enum class ERTPCValueType : uint8_t
{
    Default                                        = 0,
    Global                                         = 1,
    GameObject                                     = 2,
    PlayingID                                      = 3,
    Unavailable                                    = 4,
    ERTPCValueType_MAX                             = 5

};


// Enum  /Script/AkAudio.EAkCurveInterpolation
enum class EAkCurveInterpolation : uint8_t
{
    Log3                                           = 0,
    Sine                                           = 1,
    Log1                                           = 2,
    InvSCurve                                      = 3,
    Linear                                         = 4,
    SCurve                                         = 5,
    Exp1                                           = 6,
    SineRecip                                      = 7,
    Exp3                                           = 8,
    LastFadeCurve                                  = 8,
    Constant                                       = 9,
    EAkCurveInterpolation_MAX                      = 10

};


// Enum  /Script/AkAudio.AkActionOnEventType
enum class AkActionOnEventType : uint8_t
{
    Stop                                           = 0,
    Pause                                          = 1,
    Resume                                         = 2,
    Break                                          = 3,
    ReleaseEnvelope                                = 4,
    AkActionOnEventType_MAX                        = 5

};


// Enum  /Script/AkAudio.AkMultiPositionType
enum class AkMultiPositionType : uint8_t
{
    SingleSource                                   = 0,
    MultiSources                                   = 1,
    MultiDirections                                = 2,
    AkMultiPositionType_MAX                        = 3

};


// Enum  /Script/AkAudio.AkSpeakerConfiguration
enum class AkSpeakerConfiguration : uint32_t
{
    Ak_Speaker_Front_Left                          = 1,
    Ak_Speaker_Front_Right                         = 2,
    Ak_Speaker_Front_Center                        = 4,
    Ak_Speaker_Low_Frequency                       = 8,
    Ak_Speaker_Back_Left                           = 16,
    Ak_Speaker_Back_Right                          = 32,
    Ak_Speaker_Back_Center                         = 256,
    Ak_Speaker_Side_Left                           = 512,
    Ak_Speaker_Side_Right                          = 1024,
    Ak_Speaker_Top                                 = 2048,
    Ak_Speaker_Height_Front_Left                   = 4096,
    Ak_Speaker_Height_Front_Center                 = 8192,
    Ak_Speaker_Height_Front_Right                  = 16384,
    Ak_Speaker_Height_Back_Left                    = 32768,
    Ak_Speaker_Height_Back_Center                  = 65536,
    Ak_Speaker_Height_Back_Right                   = 131072,
    Ak_Speaker_MAX                                 = 131073

};


// Enum  /Script/AkAudio.AkChannelConfiguration
enum class AkChannelConfiguration : uint8_t
{
    Ak_Parent                                      = 0,
    Ak_LFE                                         = 1,
    Ak_1                                           = 2,
    Ak_2                                           = 3,
    Ak_2                                           = 4,
    Ak_3                                           = 5,
    Ak_3                                           = 6,
    Ak_4                                           = 7,
    Ak_4                                           = 8,
    Ak_5                                           = 9,
    Ak_5                                           = 10,
    Ak_7                                           = 11,
    Ak_5_1                                         = 12,
    Ak_7_1                                         = 13,
    Ak_7_1                                         = 14,
    Ak_Auro_9                                      = 15,
    Ak_Auro_10                                     = 16,
    Ak_Auro_11                                     = 17,
    Ak_Auro_13                                     = 18,
    Ak_Ambisonics_1st_order                        = 19,
    Ak_Ambisonics_2nd_order                        = 20,
    Ak_Ambisonics_3rd_order                        = 21,
    Ak_MAX                                         = 22

};


// Enum  /Script/AkAudio.AkAcousticPortalState
enum class AkAcousticPortalState : uint8_t
{
    Closed                                         = 0,
    Open                                           = 1,
    AkAcousticPortalState_MAX                      = 2

};


// Enum  /Script/AkAudio.PanningRule
enum class PanningRule : uint8_t
{
    PanningRule_Speakers                           = 0,
    PanningRule_Headphones                         = 1,
    PanningRule_MAX                                = 2

};


// Enum  /Script/AkAudio.EAkChannelMask
enum class EAkChannelMask : uint8_t
{
    FrontLeft                                      = 0,
    FrontRight                                     = 1,
    FrontCenter                                    = 2,
    LowFrequency                                   = 3,
    BackLeft                                       = 4,
    BackRight                                      = 5,
    BackCenter                                     = 8,
    SideLeft                                       = 9,
    SideRight                                      = 10,
    Top                                            = 11,
    HeightFrontLeft                                = 12,
    HeightFrontCenter                              = 13,
    HeightFrontRight                               = 14,
    HeightBackLeft                                 = 15,
    HeightBackCenter                               = 16,
    HeightBackRight                                = 17,
    EAkChannelMask_MAX                             = 18

};


// Enum  /Script/AkAudio.EAkChannelConfigType
enum class EAkChannelConfigType : uint8_t
{
    Anonymous                                      = 0,
    Standard                                       = 1,
    Ambisonic                                      = 2,
    EAkChannelConfigType_MAX                       = 3

};


// Enum  /Script/AkAudio.EAkDiffractionFlags
enum class EAkDiffractionFlags : uint8_t
{
    UseBuiltInParam                                = 0,
    UseObstruction                                 = 1,
    CalcEmitterVirtualPosition                     = 3,
    EAkDiffractionFlags_MAX                        = 4

};


// Enum  /Script/AkAudio.EAkPanningRule
enum class EAkPanningRule : uint8_t
{
    Speakers                                       = 0,
    Headphones                                     = 1,
    EAkPanningRule_MAX                             = 2

};


// Enum  /Script/AkAudio.EAkAudioSessionMode
enum class EAkAudioSessionMode : uint8_t
{
    Default                                        = 0,
    VoiceChat                                      = 1,
    GameChat                                       = 2,
    VideoRecording                                 = 3,
    Measurement                                    = 4,
    MoviePlayback                                  = 5,
    VideoChat                                      = 6,
    EAkAudioSessionMode_MAX                        = 7

};


// Enum  /Script/AkAudio.EAkAudioSessionCategoryOptions
enum class EAkAudioSessionCategoryOptions : uint8_t
{
    MixWithOthers                                  = 0,
    DuckOthers                                     = 1,
    AllowBluetooth                                 = 2,
    DefaultToSpeaker                               = 3,
    EAkAudioSessionCategoryOptions_MAX             = 4

};


// Enum  /Script/AkAudio.EAkAudioSessionCategory
enum class EAkAudioSessionCategory : uint8_t
{
    Ambient                                        = 0,
    SoloAmbient                                    = 1,
    PlayAndRecord                                  = 2,
    EAkAudioSessionCategory_MAX                    = 3

};


// Enum  /Script/AkAudio.EAkWindowsAudioAPI
enum class EAkWindowsAudioAPI : uint8_t
{
    Wasapi                                         = 0,
    XAudio2                                        = 1,
    DirectSound                                    = 2,
    EAkWindowsAudioAPI_MAX                         = 3

};


// Enum  /Script/ZZAnimationLib.EBlendListTransitionType_Component
enum class EBlendListTransitionType_Component : uint8_t
{
    StandardBlend                                  = 0,
    Inertialization                                = 1,
    EBlendListTransitionType_MAX                   = 2

};


// Enum  /Script/ZZAnimationLib.ECollisionLimitType
enum class ECollisionLimitType : uint8_t
{
    None                                           = 0,
    Spherical                                      = 1,
    Capsule                                        = 2,
    Planar                                         = 3,
    ECollisionLimitType_MAX                        = 4

};


// Enum  /Script/ZZAnimationLib.EBoneForwardAxis
enum class EBoneForwardAxis : uint8_t
{
    X_Positive                                     = 0,
    X_Negative                                     = 1,
    Y_Positive                                     = 2,
    Y_Negative                                     = 3,
    Z_Positive                                     = 4,
    Z_Negative                                     = 5,
    EBoneForwardAxis_MAX                           = 6

};


// Enum  /Script/ZZAnimationLib.EPlanarConstraint
enum class EPlanarConstraint : uint8_t
{
    None                                           = 0,
    X                                              = 1,
    Y                                              = 2,
    Z                                              = 3,
    EPlanarConstraint_MAX                          = 4

};


// Enum  /Script/ZZAnimationLib.ELayeredBoneBlendMode
enum class ELayeredBoneBlendMode : uint8_t
{
    BranchFilter                                   = 0,
    BlendMask                                      = 1,
    ELayeredBoneBlendMode_MAX                      = 2

};


// Enum  /Script/ZZAnimationLib.EIKFootRootLocalAxis
enum class EIKFootRootLocalAxis : uint8_t
{
    NONE                                           = 0,
    X                                              = 1,
    Y                                              = 2,
    Z                                              = 3,
    EIKFootRootLocalAxis_MAX                       = 4

};


// Enum  /Script/ZZAnimationLib.EColliderType
enum class EColliderType : uint8_t
{
    Collider_Sphere                                = 0,
    Collider_Capsule                               = 1,
    Collider_MAX                                   = 2

};


// Enum  /Script/ZZAnimationLib.EFindTargetFrameResult
enum class EFindTargetFrameResult : uint8_t
{
    NORMAL                                         = 0,
    CANNOTFIND                                     = 1,
    DIVIDEBYZERO                                   = 2,
    Count                                          = 3,
    EFindTargetFrameResult_MAX                     = 4

};


// Enum  /Script/ZZAnimationLib.ECharacterLocalDirection
enum class ECharacterLocalDirection : uint8_t
{
    NORTH                                          = 0,
    EAST                                           = 1,
    SOUTH                                          = 2,
    WEST                                           = 3,
    Count                                          = 4,
    ECharacterLocalDirection_MAX                   = 5

};


// Enum  /Script/ACLPlugin.StripClusterOption
enum class StripClusterOption : uint8_t
{
    ClusterOption_StripOnly                        = 0,
    ClusterOption_KeepOnly                         = 1,
    ClusterOption_DoNothing                        = 2,
    ClusterOption_MAX                              = 3

};


// Enum  /Script/ACLPlugin.ACLCompressionLevel
enum class ACLCompressionLevel : uint8_t
{
    ACLCL_Lowest                                   = 0,
    ACLCL_Low                                      = 1,
    ACLCL_Medium                                   = 2,
    ACLCL_High                                     = 3,
    ACLCL_Highest                                  = 4,
    ACLCL_MAX                                      = 5

};


// Enum  /Script/ACLPlugin.ACLVectorFormat
enum class ACLVectorFormat : uint8_t
{
    ACLVF_Vector3                                  = 0,
    ACLVF_Vector3_Variable                         = 1,
    ACLVF_Vector3_MAX                              = 2

};


// Enum  /Script/ACLPlugin.ACLRotationFormat
enum class ACLRotationFormat : uint8_t
{
    ACLRF_Quat                                     = 0,
    ACLRF_QuatDropW                                = 1,
    ACLRF_QuatDropW_Variable                       = 2,
    ACLRF_MAX                                      = 3

};


// Enum  /Script/ACLPlugin.ACLVisualFidelityChangeResult
enum class ACLVisualFidelityChangeResult : uint8_t
{
    Dispatched                                     = 0,
    Completed                                      = 1,
    Failed                                         = 2,
    ACLVisualFidelityChangeResult_MAX              = 3

};


// Enum  /Script/ACLPlugin.ACLVisualFidelity
enum class ACLVisualFidelity : uint8_t
{
    Highest                                        = 0,
    Medium                                         = 1,
    Lowest                                         = 2,
    ACLVisualFidelity_MAX                          = 3

};


// Enum  /Script/OnlineSubsystem.EInAppPurchaseState
enum class EInAppPurchaseState : uint8_t
{
    Unknown                                        = 0,
    Success                                        = 1,
    Failed                                         = 2,
    Cancelled                                      = 3,
    Invalid                                        = 4,
    NotAllowed                                     = 5,
    Restored                                       = 6,
    AlreadyOwned                                   = 7,
    EInAppPurchaseState_MAX                        = 8

};


// Enum  /Script/OnlineSubsystem.EMPMatchOutcome
enum class EMPMatchOutcome : uint8_t
{
    None                                           = 0,
    Quit                                           = 1,
    Won                                            = 2,
    Lost                                           = 3,
    Tied                                           = 4,
    TimeExpired                                    = 5,
    First                                          = 6,
    Second                                         = 7,
    Third                                          = 8,
    Fourth                                         = 9,
    EMPMatchOutcome_MAX                            = 10

};


// Enum  /Script/OnlineSubsystemUtils.EBeaconConnectionState
enum class EBeaconConnectionState : uint8_t
{
    Invalid                                        = 0,
    Closed                                         = 1,
    Pending                                        = 2,
    Open                                           = 3,
    EBeaconConnectionState_MAX                     = 4

};


// Enum  /Script/OnlineSubsystemUtils.EClientRequestType
enum class EClientRequestType : uint8_t
{
    NonePending                                    = 0,
    ExistingSessionReservation                     = 1,
    ReservationUpdate                              = 2,
    EmptyServerReservation                         = 3,
    Reconnect                                      = 4,
    Abandon                                        = 5,
    EClientRequestType_MAX                         = 6

};


// Enum  /Script/OnlineSubsystemUtils.EPartyReservationResult
enum class EPartyReservationResult : uint8_t
{
    NoResult                                       = 0,
    RequestPending                                 = 1,
    GeneralError                                   = 2,
    PartyLimitReached                              = 3,
    IncorrectPlayerCount                           = 4,
    RequestTimedOut                                = 5,
    ReservationDuplicate                           = 6,
    ReservationNotFound                            = 7,
    ReservationAccepted                            = 8,
    ReservationDenied                              = 9,
    ReservationDenied_CrossPlayRestriction         = 10,
    ReservationDenied_Banned                       = 11,
    ReservationRequestCanceled                     = 12,
    ReservationInvalid                             = 13,
    BadSessionId                                   = 14,
    ReservationDenied_ContainsExistingPlayers      = 15,
    EPartyReservationResult_MAX                    = 16

};


// Enum  /Script/OnlineSubsystemUtils.ESpectatorClientRequestType
enum class ESpectatorClientRequestType : uint8_t
{
    NonePending                                    = 0,
    ExistingSessionReservation                     = 1,
    ReservationUpdate                              = 2,
    EmptyServerReservation                         = 3,
    Reconnect                                      = 4,
    Abandon                                        = 5,
    ESpectatorClientRequestType_MAX                = 6

};


// Enum  /Script/OnlineSubsystemUtils.ESpectatorReservationResult
enum class ESpectatorReservationResult : uint8_t
{
    NoResult                                       = 0,
    RequestPending                                 = 1,
    GeneralError                                   = 2,
    SpectatorLimitReached                          = 3,
    IncorrectPlayerCount                           = 4,
    RequestTimedOut                                = 5,
    ReservationDuplicate                           = 6,
    ReservationNotFound                            = 7,
    ReservationAccepted                            = 8,
    ReservationDenied                              = 9,
    ReservationDenied_CrossPlayRestriction         = 10,
    ReservationDenied_Banned                       = 11,
    ReservationRequestCanceled                     = 12,
    ReservationInvalid                             = 13,
    BadSessionId                                   = 14,
    ReservationDenied_ContainsExistingPlayers      = 15,
    ESpectatorReservationResult_MAX                = 16

};


// Enum  /Script/GooglePAD.EGooglePADCellularDataConfirmStatus
enum class EGooglePADCellularDataConfirmStatus : uint8_t
{
    AssetPack_CONFIRM_UNKNOWN                      = 0,
    AssetPack_CONFIRM_PENDING                      = 1,
    AssetPack_CONFIRM_USER_APPROVED                = 2,
    AssetPack_CONFIRM_USER_CANCELED                = 3,
    AssetPack_CONFIRM_MAX                          = 4

};


// Enum  /Script/GooglePAD.EGooglePADStorageMethod
enum class EGooglePADStorageMethod : uint8_t
{
    AssetPack_STORAGE_FILES                        = 0,
    AssetPack_STORAGE_APK                          = 1,
    AssetPack_STORAGE_UNKNOWN                      = 2,
    AssetPack_STORAGE_NOT_INSTALLED                = 3,
    AssetPack_STORAGE_MAX                          = 4

};


// Enum  /Script/GooglePAD.EGooglePADDownloadStatus
enum class EGooglePADDownloadStatus : uint8_t
{
    AssetPack_UNKNOWN                              = 0,
    AssetPack_DOWNLOAD_PENDING                     = 1,
    AssetPack_DOWNLOADING                          = 2,
    AssetPack_TRANSFERRING                         = 3,
    AssetPack_DOWNLOAD_COMPLETED                   = 4,
    AssetPack_DOWNLOAD_FAILED                      = 5,
    AssetPack_DOWNLOAD_CANCELED                    = 6,
    AssetPack_WAITING_FOR_WIFI                     = 7,
    AssetPack_NOT_INSTALLED                        = 8,
    AssetPack_INFO_PENDING                         = 9,
    AssetPack_INFO_FAILED                          = 10,
    AssetPack_REMOVAL_PENDING                      = 11,
    AssetPack_REMOVAL_FAILED                       = 12,
    AssetPack_MAX                                  = 13

};


// Enum  /Script/GooglePAD.EGooglePADErrorCode
enum class EGooglePADErrorCode : uint8_t
{
    AssetPack_NO_ERROR                             = 0,
    AssetPack_APP_UNAVAILABLE                      = 1,
    AssetPack_UNAVAILABLE                          = 2,
    AssetPack_INVALID_REQUEST                      = 3,
    AssetPack_DOWNLOAD_NOT_FOUND                   = 4,
    AssetPack_API_NOT_AVAILABLE                    = 5,
    AssetPack_NETWORK_ERROR                        = 6,
    AssetPack_ACCESS_DENIED                        = 7,
    AssetPack_INSUFFICIENT_STORAGE                 = 8,
    AssetPack_PLAY_STORE_NOT_FOUND                 = 9,
    AssetPack_NETWORK_UNRESTRICTED                 = 10,
    AssetPack_INTERNAL_ERROR                       = 11,
    AssetPack_INITIALIZATION_NEEDED                = 12,
    AssetPack_INITIALIZATION_FAILED                = 13,
    AssetPack_MAX                                  = 14

};


// Enum  /Script/AClient.EGameplayViewTargetType
enum class EGameplayViewTargetType : uint8_t
{
    NONE                                           = 0,
    MyPawn                                         = 1,
    OBTarget                                       = 2,
    RespwanTarget                                  = 3,
    GMSet                                          = 4,
    MAX                                            = 32

};


// Enum  /Script/AClient.EPlayerBattleBehState
enum class EPlayerBattleBehState : uint8_t
{
    Normal                                         = 0,
    Dying                                          = 1,
    Rescuing                                       = 2,
    RescuingSelf                                   = 3,
    RescuingOther                                  = 4,
    DoFinisher                                     = 5,
    BeFinisher                                     = 6,
    Respawning                                     = 7,
    RespawnTimeout                                 = 8,
    RespawnTeammate                                = 9,
    Dead                                           = 10,
    EPlayerBattleBehState_MAX                      = 11

};


// Enum  /Script/AClient.EPawnState
enum class EPawnState : uint8_t
{
    Move                                           = 0,
    Sprint                                         = 1,
    Sliding                                        = 2,
    Jump                                           = 3,
    ClimbWall                                      = 4,
    Hanging                                        = 5,
    ClimbOver                                      = 6,
    InAir                                          = 7,
    Flying                                         = 9,
    Stand                                          = 11,
    Crouch                                         = 12,
    Pick                                           = 13,
    Born                                           = 14,
    TransformSuperHero                             = 15,
    Dying                                          = 16,
    Dead                                           = 17,
    GravityCannon                                  = 18,
    InParachute                                    = 19,
    InPlane                                        = 20,
    Eq140_eq140_eq_On                              = 21,
    MagmaRise                                      = 22,
    Rescue                                         = 23,
    Zipline                                        = 24,
    Finisher                                       = 25,
    OnBeacon                                       = 26,
    Runaway                                        = 27,
    ParachuteForceBuilding                         = 28,
    Lock                                           = 29,
    SmallEye                                       = 30,
    GunFire                                        = 31,
    GunReload                                      = 32,
    GunADS                                         = 33,
    HoldingWeapon                                  = 34,
    PutOnWeapon                                    = 35,
    PutOffWeapon                                   = 36,
    RaiseWeapon                                    = 37,
    LowerWeapon                                    = 38,
    EquipAttachment                                = 39,
    WeaponCharge                                   = 40,
    Bolt                                           = 42,
    PlantBomb                                      = 43,
    DefuseBomb                                     = 44,
    BlockWeapon                                    = 45,
    RecoverPropMd110_m                             = 46,
    RecoverPropBattery                             = 47,
    PickBanner                                     = 48,
    DriveVehicle                                   = 49,
    InVehicle                                      = 50,
    OpenFesecretDoor                               = 52,
    PropsWeaponRight                               = 53,
    EmojiAnimation                                 = 54,
    UseFeatustore                                  = 55,
    InspectWeapon                                  = 56,
    AutoPathFinding                                = 57,
    PaladinInvincible                              = 58,
    AutonomousSkillSlot1                           = 59,
    AutonomousSkillSlot2                           = 60,
    AutonomousSkillSlot3                           = 61,
    SkillSlot                                      = 62,
    __MAX                                          = 63,
    OnFeatdeTector                                 = 65,
    MeleeAttackPoint                               = 71,
    SkillLeftHand                                  = 72,
    SkillRightHand                                 = 73,
    SkillTwoHand                                   = 74,
    SkillVoid                                      = 75,
    SkillTwoHandContinue                           = 76,
    SkillGrapplingHook                             = 77,
    SkillZiplineTwoHand                            = 78,
    SkillStimLeftHand                              = 79,
    SkillTunnelOpen                                = 80,
    SkillPreVoid                                   = 81,
    SkillPhaseShift                                = 82,
    HoldGrenade                                    = 83,
    HoldGrenadeAim                                 = 84,
    UseMd110_m                                     = 85,
    UseBattery                                     = 86,
    SkillHoldGastank                               = 87,
    SkillThrowGastank                              = 88,
    Hero10_SkillReady                              = 89,
    SkillHoldGasGrenade                            = 90,
    SkillThrowGasGrenade                           = 91,
    Hero12_hDeathTotem                             = 92,
    Hero11Drone                                    = 93,
    Hero01_he_Skill                                = 94,
    SkillGrapplingHookPulling                      = 95,
    SkillStimOnZipline                             = 96,
    Hero01_he_Ultimate                             = 98,
    PowerJump                                      = 99,
    Hero44Tree                                     = 100,
    Hero42_Void                                    = 102,
    Hero08Tactical                                 = 103,
    Hero42_Void_Enemy                              = 104,
    Hero06_h_CallSmoke                             = 105,
    Hr13BlackMarket                                = 106,
    Hr13Bracelet                                   = 107,
    Hr13BraceletWait                               = 108,
    Hr13BlackMarketUse                             = 109,
    Hero08Ultimate                                 = 110,
    DJTactical                                     = 111,
    DJUltimate                                     = 112,
    Hero02_h_DomeShield                            = 113,
    Hero17_hJetPack                                = 114,
    H19UseDataKnife                                = 115,
    H19UseVoidDoor                                 = 116,
    H19EnterVoidDoor                               = 117,
    H19UseArcBolt                                  = 118,
    Hero17_hTactical                               = 119,
    Hero17_hTacticsRelease                         = 120,
    Hero17_hUltimate                               = 121,
    JoinHero17Ultimate                             = 122,
    Hero50Tactical                                 = 123,
    Hero50Ultimate                                 = 124,
    Hero15_GravityLift                             = 125,
    Hero54Tactical                                 = 126,
    Freeze                                         = 127,
    Hero53_QuantumField                            = 128,
    Hero54Ultimate                                 = 129,
    MeleeAttackBackSwing                           = 130,
    Hero52UltimatePreAnim                          = 131,
    Hero53UltimateSelect                           = 132,
    Hero53UltimateCast                             = 133,
    Hero17UltimateRelease                          = 134,
    Hero52TacticalEnd                              = 135,
    Hero42Tactical                                 = 136,
    Hero13UltimateShift                            = 137,
    Hero08TacticalBigJump                          = 138,
    Hero50TacticalPre                              = 139,
    RobGoldInStealing                              = 140,
    Gliding                                        = 141,
    Hero08UltimateMelee                            = 142,
    Hero12PassiveState                             = 143,
    Hero12PassiveActionState                       = 144,
    ForceDanceState                                = 145,
    Hero14JumpSprint                               = 146,
    EPawnState_Max                                 = 147

};


// Enum  /Script/AClient.EStateRemovedReason
enum class EStateRemovedReason : uint8_t
{
    Manually                                       = 0,
    Interrupted                                    = 1,
    Disabled                                       = 2,
    Replicated                                     = 3,
    EStateRemovedReason_MAX                        = 4

};


// Enum  /Script/AClient.EAttributeCaptureSource
enum class EAttributeCaptureSource : uint8_t
{
    Source                                         = 0,
    Target                                         = 1,
    EAttributeCaptureSource_MAX                    = 2

};


// Enum  /Script/AClient.EAttrOperator
enum class EAttrOperator : uint8_t
{
    Set                                            = 0,
    Plus                                           = 1,
    Multiply                                       = 2,
    EAttrOperator_MAX                              = 3

};


// Enum  /Script/AClient.EGnyxAttrType
enum class EGnyxAttrType : uint8_t
{
    Attr_None                                      = 0,
    Attr_Health                                    = 1,
    Attr_ShieldValue                               = 2,
    Attr_ShieldValueMax                            = 3,
    Attr_SkillSpeedScale                           = 4,
    Attr_KnockdownSpeedScale                       = 5,
    Attr_SkillDamageScale                          = 6,
    Attr_AIDamageScale                             = 7,
    Attr_MoveShowDistanceScale                     = 8,
    Attr_FireShowDistanceScale                     = 9,
    Attr_HealShowDistanceScale                     = 10,
    Attr_PawnBackpackCapacity                      = 11,
    Attr_HeadDamageReduce                          = 12,
    Attr_BodyDamageReduce                          = 13,
    Attr_BodyDuability                             = 14,
    Attr_ShieldLevel                               = 15,
    Attr_HelmetLevel                               = 16,
    Attr_Eq140_eq140_eq_Level                      = 17,
    Attr_BackpackLevel                             = 18,
    Attr_TacticsCDScale                            = 19,
    Attr_UltimateCDScale                           = 20,
    Attr_TreatmentMul                              = 21,
    Attr_WalkSpeed                                 = 22,
    Attr_SkillForbidSprint                         = 23,
    Attr_IsImmuneHitSlowdown                       = 24,
    Attr_RescueMultiplier                          = 25,
    Attr_RescueSelfMultiplier                      = 26,
    Attr_IsIndiviRescue                            = 27,
    Attr_MaxWalkSpeedLimit                         = 28,
    Attr_ViewScrollSpeedScale                      = 29,
    Attr_SpreadScale                               = 30,
    Attr_TacticsCDScaleHero01_he_                  = 31,
    Attr_BaseSpeedScale                            = 32,
    Attr_WeaponSpeedScale                          = 33,
    Attr_JumpHeightScale                           = 34,
    Attr_ParachuteJump                             = 35,
    Attr_ParachuteOpen                             = 36,
    Attr_ClimbVelocityScale                        = 37,
    Attr_FallingAccelScale                         = 38,
    Attr_AirSpeedCapScale                          = 39,
    Attr_HealthMax                                 = 40,
    Attr_ShieldAr302_a_Value                       = 41,
    Attr_ShieldAr302_a_ValueMax                    = 42,
    Attr_BackpackCapacityAdd                       = 43,
    Attr_WeaponDamageAdd                           = 44,
    Attr_WeaponDamageReduce                        = 45,
    Attr_PVEDamageAdd                              = 46,
    Attr_PVEDamageReduce                           = 47,
    Attr_BossDamageAdd                             = 48,
    Attr_SignalDamageReduce                        = 49,
    Attr_MAX                                       = 50

};


// Enum  /Script/AClient.EAttrVariableType
enum class EAttrVariableType : uint8_t
{
    Int                                            = 0,
    Float                                          = 1,
    Resource                                       = 2,
    EAttrVariableType_MAX                          = 3

};


// Enum  /Script/Engine.EFastArraySerializerDeltaFlags
enum class EFastArraySerializerDeltaFlags : uint8_t
{
    None                                           = 0,
    HasBeenSerialized                              = 1,
    HasDeltaBeenRequested                          = 2,
    IsUsingDeltaSerialization                      = 4,
    EFastArraySerializerDeltaFlags_MAX             = 5

};


// Enum  /Script/AClient.EAttrModifyReplicationMode
enum class EAttrModifyReplicationMode : uint8_t
{
    Minimal                                        = 0,
    Mixed                                          = 1,
    Full                                           = 2,
    EAttrModifyReplicationMode_MAX                 = 3

};


// Enum  /Script/AClient.EWeaponAutoAimMode
enum class EWeaponAutoAimMode : uint8_t
{
    None                                           = 1,
    WaitAimFire                                    = 2,
    ImmediatelyFire                                = 3,
    Blend                                          = 4,
    EWeaponAutoAimMode_MAX                         = 5

};


// Enum  /Script/AClient.ESettingConfig
enum class ESettingConfig : uint8_t
{
    Common_AssistOn                                = 0,
    Common_AimSingleShoot                          = 1,
    Common_AimAutoShoot                            = 2,
    Common_AimPostFire                             = 3,
    Common_AimCanRotate                            = 4,
    Common_AutoShooting                            = 5,
    Common_ClampUseTPP                             = 6,
    Common_CrouchControlType                       = 7,
    Common_LeftSliding                             = 8,
    Common_SlidingButtonVeer                       = 9,
    Common_ClimbCancelMode                         = 10,
    Common_SlideJumpMode                           = 11,
    Common_SlideCanStand                           = 12,
    Common_ReleasingJoyStickStopsSliding           = 13,
    Common_AutoRunStopsHealing                     = 14,
    Common_EasyBigJump                             = 15,
    Function_ShowPing                              = 16,
    Function_PingAlphaPercent                      = 17,
    Function_ShowFastRun                           = 18,
    Function_EnableAutoSwitchWeaponOnClipBulletOut = 19,
    Function_AutoSwitchWeaponOnClipBulletOut       = 20,
    Function_AutoSwitchWeaponOnBulletOut           = 21,
    Function_SwitchDrugAutoUse                     = 22,
    Function_DrugRecommend                         = 23,
    Function_DrugLongPressed                       = 24,
    Function_ContinuousUseMd101_Md101_m            = 25,
    Function_ContinuousUseMd111_                   = 26,
    Function_QuickProjectile                       = 27,
    Function_FightTips                             = 28,
    Function_HighScopeColorDefault                 = 29,
    Function_CrossHairColorDefault                 = 30,
    Level_Sensitivity                              = 31,
    Value_FirstPersonLensSensitivity               = 32,
    Value_ThirdPersonLensSensitivity               = 33,
    Value_IronSightSensitivity                     = 34,
    Value_OneMultLensSensitivity                   = 35,
    Value_TwoMultLensSensitivity                   = 36,
    Value_ThreeMultLensSensitivity                 = 37,
    Value_FourMultLensSensitivity                  = 38,
    Value_SixMultLensSensitivity                   = 39,
    Value_EightMultLensSensitivity                 = 40,
    Value_TenMultLensSensitivity                   = 41,
    Value_FirstPersonShootSensitivity              = 42,
    Value_ThirdPersonShootSensitivity              = 43,
    Value_IronSightShootSensitivity                = 44,
    Value_OneMultShootSensitivity                  = 45,
    Value_TwoMultShootSensitivity                  = 46,
    Value_ThreeMultShootSensitivity                = 47,
    Value_FourMultShootSensitivity                 = 48,
    Value_SixMultShootSensitivity                  = 49,
    Value_EightMultShootSensitivity                = 50,
    Value_TenMultShootSensitivity                  = 51,
    Mode_GlobalSensitivity                         = 52,
    Mode_ESliderAccelerated                        = 53,
    Mode_CrossHairDamageFeedback                   = 54,
    Mode_DamageFeedback                            = 55,
    Mode_HarmFeedback                              = 56,
    DrawQuality_BR                                 = 57,
    DrawQuality_TDM                                = 58,
    DrawQuality_PVP                                = 59,
    Value_bQualityMonitorEnabled                   = 60,
    PickupTip                                      = 61,
    EnableDamagePromptBar                          = 62,
    PlayerSetupSkillAssist                         = 63,
    DamageHelmetTips                               = 64,
    ESettingConfig_MAX                             = 65

};


// Enum  /Script/AClient.ECrossHairMode
enum class ECrossHairMode : uint8_t
{
    XCrossHairWithIconOutOfView                    = 1,
    XCrossHairWithIcon                             = 2,
    XCrossHair                                     = 3,
    OFF                                            = 4,
    ECrossHairMode_MAX                             = 5

};


// Enum  /Script/AClient.EDamageFeedbackMode
enum class EDamageFeedbackMode : uint8_t
{
    OFF                                            = 1,
    Overlay                                        = 2,
    Float                                          = 3,
    Merge                                          = 4,
    EDamageFeedbackMode_MAX                        = 5

};


// Enum  /Script/AClient.EDamageTipType
enum class EDamageTipType : uint8_t
{
    NONE                                           = 0,
    TipType2                                       = 1,
    TipType3                                       = 2,
    TipType23                                      = 3,
    EDamageTipType_MAX                             = 4

};


// Enum  /Script/AClient.EScopeFireMode
enum class EScopeFireMode : uint8_t
{
    Classic                                        = 0,
    Shoulder                                       = 1,
    Mix                                            = 2,
    Mode_Max                                       = 3,
    EScopeFireMode_MAX                             = 4

};


// Enum  /Script/AClient.EMainUILeftShootButtonShowMode
enum class EMainUILeftShootButtonShowMode : uint8_t
{
    Always                                         = 1,
    Aim                                            = 2,
    Close                                          = 3,
    EMainUILeftShootButtonShowMode_MAX             = 4

};


// Enum  /Script/AClient.EWeaponItemType
enum class EWeaponItemType : uint8_t
{
    AWT_None                                       = 0,
    AWT_Rifle                                      = 1,
    AWT_Submachine                                 = 2,
    AWT_MachineGun                                 = 3,
    AWT_ShotGun                                    = 4,
    AWT_Sniper                                     = 5,
    AWT_Pistol                                     = 6,
    AWT_Melee                                      = 7,
    AWT_Masksman                                   = 8,
    AWT_Max                                        = 9

};


// Enum  /Script/AClient.EWeaponShotGunFireMode
enum class EWeaponShotGunFireMode : uint8_t
{
    None                                           = 1,
    ReleaseFire                                    = 2,
    AimReleaseFire                                 = 3,
    EWeaponShotGunFireMode_MAX                     = 4

};


// Enum  /Script/AClient.ESliderAcceleratedMode
enum class ESliderAcceleratedMode : uint8_t
{
    Accelerated                                    = 1,
    FixedDistance                                  = 2,
    Fixed                                          = 3,
    ESliderAcceleratedMode_MAX                     = 4

};


// Enum  /Script/AClient.EGnyxSkillEvent
enum class EGnyxSkillEvent : uint8_t
{
    GnyxSkillEvent_None                            = 0,
    Hero07__Dirty_Bomb_Weapon_Extrusion_Destroy    = 1,
    Hero07__Dirty_Bomb_Weapon_Ready                = 2,
    Hero07__Dirty_Bomb_Weapon_PickeUp              = 3,
    Hero07__Dirty_Bomb_Weapon_PickeUp_UI_Show      = 4,
    Hero07__Dirty_Bomb_Weapon_PickeUp_UI_Hide      = 5,
    Hero07__Dirty_Bomb_Weapon_Activate             = 6,
    Hero07__Dirty_Bomb_Weapon_Coerce_Destroy       = 7,
    Hero07__Dirty_Bomb_Weapon_Gas_FadeOut          = 8,
    Hero07__Dirty_Bomb_Weapon_PreDestroy           = 9,
    Hero07__Dirty_Bomb_Weapon_Destroy              = 10,
    Hero07__Dirty_Bomb_Weapon_BeDamaged_Destroy    = 11,
    Hero07__Gas_Grenade_Weapon_Spawn               = 12,
    Hero07__Gas_Grenade_Weapon_Aiming              = 13,
    Hero07__Gas_Grenade_Weapon_Throw               = 14,
    Hero07__Gas_Grenade_Weapon_StartFly            = 15,
    Hero07__Gas_Grenade_Weapon_Bounce              = 16,
    Hero07__Gas_Grenade_Weapon_Land                = 17,
    Hero07__Gas_Grenade_Weapon_Activate            = 18,
    Hero07__Gas_Grenade_Weapon_Target_Leave_Gas    = 19,
    Hero07__Gas_Grenade_Weapon_Target_Enter_Gas    = 20,
    Hero07__Gas_Grenade_Weapon_Interupted          = 21,
    Hero07__Gas_Grenade_Weapon_Destroy             = 22,
    Hero07__Gas_Grenade_Weapon_Activate_Complete   = 23,
    Hero06_h__Smoke_Bomb_Weapon_Spawn              = 24,
    Hero06_h__Smoke_Bomb_Weapon_Throw              = 25,
    Hero06_h__Smoke_Bomb_Weapon_Land               = 26,
    Hero06_h__Smoke_Bomb_Weapon_Deploy             = 27,
    Hero06_h__Smoke_Bomb_Weapon_Ready              = 28,
    Hero06_h__Smoke_Bomb_Weapon_Activate           = 29,
    Hero06_h__Smoke_Bomb_Weapon_Destroy            = 30,
    Hero06_h__Smoke_Bomb_Weapon_TakeDamage         = 31,
    Hero08_Decoy_MoveToScreenCenter                = 32,
    Hero08_Decoy_MoveAhead                         = 33,
    Hero08_Decoy_MoveToScreenCenterWithCtl         = 34,
    Hero08_Decoy_FallingHighToGround               = 35,
    Hero08_Decoy_FallingLowToGround                = 36,
    Hero08_PassiveSkill_Bleedingout                = 37,
    Hero08_PassiveSkill_Rescue                     = 38,
    Hero08_PassiveSkill_RecoverFromInvisible       = 39,
    Hero08_PassiveSkill_BeaconRespawn              = 40,
    Hero08_PassiveSkill                            = 41,
    Hero08_Ultimate_Invisible_Enter                = 42,
    Hero08_Ultimate_Invisible_Leave                = 43,
    Hero08_Decoy_SwitchPlayerControlEnable         = 44,
    Hero08_Decoy_SwitchPlayerControlDisable        = 45,
    Hero08_Decoy_MoveStopped                       = 46,
    Hero08_Decoy_RequestPlayerControlState         = 47,
    Hero08_Tactical_SpawnTeam                      = 48,
    Hero08_CustomEvent                             = 49,
    Hero08_Invisible_Perk                          = 50,
    Hero08_PassiveSkill_Rescue_Perk                = 51,
    Hero08_PassiveSkill_Rescue_Invisible           = 52,
    Hero08_PassiveSkill_BeRescue_Invisible         = 53,
    Hero08_PassiveSkill_BeaconRespawn_Invisible    = 54,
    Hero05_Stop_Tactical_Skill                     = 55,
    Hero05_Start_Transfer                          = 56,
    Hero01_he__Stop_Tactical_Skill                 = 57,
    Hero54_Stop_Tactical_Skill                     = 58,
    UseFeatdeTectorSetPosFinish                    = 59,
    UseFeatdeTectorSuccess                         = 60,
    Hero42_SelfCancelBraid                         = 61,
    Hr13_GanefBestFriend_TeleportSucced            = 62,
    Hr13_GanefBestFriend_TeleportFailed            = 63,
    Hr13_GanefBestFriend_GoDownEvent               = 64,
    Hr13_GanefBestFriend_Bracelet_Spawn            = 65,
    Hr13_Ultimate_BlackMarket_Spawn                = 66,
    Hr13_BlackMarket_StealfromFesecretDoor         = 67,
    Hero09_Stim_Active_Complete                    = 68,
    Hero09_Stim_Active_Begin                       = 69,
    Hero09_Stim_Active_Pause                       = 70,
    Hero09_Stim_Active_Resume                      = 71,
    H19_DataKnife_Begin                            = 72,
    H19_DataKnife_Active                           = 73,
    H19_VoidDoor_Active                            = 74,
    H19_VoidDoor_PreSpawn_VoidDoor                 = 75,
    H19_VoidDoor_Spawn_VoidDoor                    = 76,
    H19_VoidDoor_Pre_Transfer                      = 77,
    H19_VoidDoor_Begin_Transfer                    = 78,
    H19_VoidDoor_Begin_FOVAdjust                   = 79,
    Hero17Ultimate_LaunchPhase1End                 = 80,
    Hero17Ultimate_ReachTop                        = 81,
    Hero17Ultimate_Landing                         = 82,
    Hero53_SelectDomainTarget_Succeed              = 83,
    Hero53_EnterDomain_Succeed                     = 84,
    Hero52_Ultimate_OpenPreCollision               = 85,
    Hero52_Ultimate_ClosePreCollision              = 86,
    Hero50_Tactical_AttachSucc                     = 87,
    Hero50_Tactical_AttachFail                     = 88,
    Hero50_Tactical_AttachEnd                      = 89,
    Hero57_Ultimate_AttackPress                    = 90,
    Hero57_Ultimate_AttackRelease                  = 91,
    Hero57_Ultimate_AttackSuccess                  = 92,
    Hero12_Passive_Action                          = 93,
    BeginOverlap                                   = 94,
    EndOverlap                                     = 95,
    EGnyxSkillEvent_MAX                            = 96

};


// Enum  /Script/AClient.EPickerSignalType
enum class EPickerSignalType : uint8_t
{
    None                                           = 0,
    PickerFinishWithValidTargets                   = 1,
    PickerFinishWithoutValidTargets                = 2,
    MaxNum                                         = 3,
    EPickerSignalType_MAX                          = 4

};


// Enum  /Script/AClient.eOperationSrcType
enum class eOperationSrcType : uint8_t
{
    eNone                                          = 0,
    eClient                                        = 1,
    eServer                                        = 2,
    eOperationSrcType_MAX                          = 3

};


// Enum  /Script/AClient.EWeaponDataSlot
enum class EWeaponDataSlot : uint8_t
{
    Slot1                                          = 0,
    Slot2                                          = 1,
    Slot3                                          = 2,
    SlotMax                                        = 3,
    SlotNone                                       = 4,
    EWeaponDataSlot_MAX                            = 5

};


// Enum  /Script/AClient.EOperationType
enum class EOperationType : uint8_t
{
    EOT_None                                       = 0,
    EOT_Skill                                      = 1,
    EOT_Weapon                                     = 2,
    EOT_Climb                                      = 3,
    EOT_Zipline                                    = 4,
    EOT_PawnState                                  = 5,
    EOT_MainHandThrow                              = 6,
    EOT_PropsWeapon                                = 7,
    EOT_Finish                                     = 8,
    EOT_RecoverProp                                = 9,
    EOT_MeleeWeapon                                = 10,
    EOT_Eq140_eq140_eq_On                          = 11,
    EOT_ForbiddenZone                              = 12,
    EOT_GuardianRange                              = 13,
    EOT_ParachuteForceBuilding                     = 14,
    EOT_HeroArcana                                 = 15,
    EOT_SuperHero                                  = 16,
    EOT_MAX                                        = 17

};


// Enum  /Script/AClient.EMonsterState
enum class EMonsterState : uint8_t
{
    None                                           = 0,
    Dormant                                        = 1,
    Combat                                         = 2,
    Alert                                          = 3,
    Dead                                           = 4,
    EMonsterState_MAX                              = 5

};


// Enum  /Script/AClient.EDamageType
enum class EDamageType : uint32_t
{
    InvalidDamageType                              = 0,
    ShootDamage                                    = 1,
    BombDamage                                     = 2,
    PoisonDamage                                   = 13,
    DrowningDamage                                 = 14,
    FallingDamage                                  = 15,
    MeleeDamage                                    = 16,
    GrenadeRadiusDamage                            = 17,
    BurningDamage                                  = 18,
    AirAttackDamage                                = 19,
    VehicleDamage                                  = 20,
    VehicleExplodeRadiusDamage                     = 21,
    WinnerFakeDeath                                = 23,
    PoisonWaterDamage                              = 24,
    ElectricDamage                                 = 25,
    ZombieDamage                                   = 26,
    LowTemperatureDamage                           = 27,
    TopFiveGaveUpDamage                            = 28,
    Resurrection                                   = 29,
    TyrantMonsterStonedDamage                      = 30,
    DronesBombDamage                               = 31,
    Mi120_mPlungeDamage                            = 32,
    Mi100_mi10_ImpactDamage                        = 33,
    FlyingSkeletonImpactDamage                     = 34,
    Mi140_mPlungeDamage                            = 35,
    DynamicDamage                                  = 36,
    SporeScopeDamage                               = 37,
    BossDamage                                     = 38,
    Mi100_mi10_BombDamage                          = 51,
    Mi110_mi110_mi_BurningDamage                   = 52,
    Mi120_mBombDamage                              = 53,
    Mi130_mi130_mi_BombDamage                      = 54,
    FlyingSkeletonBombDamage                       = 55,
    NewYearFirecrackerBombDamage                   = 56,
    LastBreathWithoutRescue                        = 57,
    FollowTeamDead                                 = 58,
    ExitGameDead                                   = 59,
    BombCoronaDead                                 = 60,
    FinisherDamage                                 = 62,
    MagmaBurningDamage                             = 63,
    LeeWayTrample                                  = 64,
    MagmaRiseDamage                                = 65,
    ActorSelfDestructionDamage                     = 66,
    FireRangeKillAI                                = 67,
    WeaponChargeIgniteDamage                       = 68,
    BulletBombDamage                               = 69,
    SporeBombDamage                                = 70,
    Mi140_mBombDamage                              = 71,
    Buff_BurningDamage                             = 101,
    Buff_HoverBurningDamage                        = 102,
    Buff_VulnerabilityDamage                       = 103,
    Buff_SpocePoisonDamage                         = 104,
    SkillDamageTypeMin                             = 10011,
    SmokeLauncherDamage                            = 60021,
    Hero06UltimateDamage                           = 60031,
    DefensiveBombDamage                            = 20031,
    PerimeterSecurityDamage                        = 100021,
    NoxGasTrapDamage                               = 70021,
    NoxGasGrenadeDamage                            = 70031,
    SilenceDamage                                  = 120021,
    SilenceDoorDamage                              = 120022,
    Hero11DroneEmpDamage                           = 110039,
    Hero11DroneDyingBombDamage                     = 110040,
    Hero11DroneRocketBombDamage                    = 110041,
    Hero11DroneRocketBulletDamage                  = 110042,
    Hero41_AcrossScreenDamage                      = 410031,
    Hero42_BombDamage                              = 420031,
    Hero09StimDamage                               = 90021,
    Hr13BlackMarketDamage                          = 130031,
    Hero17_hMissileDamage                          = 170021,
    H19ArcBoltDamage                               = 190021,
    VampireUltimateDamage                          = 540021,
    Hero53Tactical                                 = 530021,
    Hero52Ultimate                                 = 520021,
    Hero56Ultimate                                 = 560021,
    Hero53UltimateNotFatal                         = 530037,
    Hero08MeleeProDamage                           = 80001,
    Hero08TacticalDamage                           = 80002,
    Hero10TacticalDamage                           = 100001,
    Hero10UltimateDamage                           = 100002,
    Hero57UltimateDamage                           = 570031,
    SkillDamageTypeMax                             = 1000001,
    Hero50UltimateDamage                           = 500003,
    EDamageType_MAX                                = 1000002

};


// Enum  /Script/AClient.ECharacterEquipAttachment
enum class ECharacterEquipAttachment : uint8_t
{
    PropsWeapon                                    = 0,
    ECharacterEquipAttachment_MAX                  = 1

};


// Enum  /Script/AClient.EHealthChangeWithoutRecommendType
enum class EHealthChangeWithoutRecommendType : uint8_t
{
    eOctance_Passive                               = 0,
    eOctance_MAX                                   = 1

};


// Enum  /Script/AClient.ERescuingEndReason
enum class ERescuingEndReason : uint8_t
{
    Normal                                         = 0,
    Break                                          = 1,
    ERescuingEndReason_MAX                         = 2

};


// Enum  /Script/AClient.ECharacterExtraHealthType
enum class ECharacterExtraHealthType : uint8_t
{
    Origin                                         = 0,
    TotemExtraHealth                               = 1,
    QuantumExtraHealth                             = 2,
    SonicExtraHealth                               = 3,
    ECharacterExtraHealthType_MAX                  = 4

};


// Enum  /Script/AClient.EBattleItemPickupReason
enum class EBattleItemPickupReason : uint8_t
{
    Manually                                       = 0,
    Associated                                     = 1,
    AutoPickup                                     = 2,
    Initial                                        = 3,
    Replace                                        = 4,
    DefaultItem                                    = 5,
    EBattleItemPickupReason_MAX                    = 6

};


// Enum  /Script/AClient.EBattleItemOperationFailedReason
enum class EBattleItemOperationFailedReason : uint8_t
{
    PickupFailed_Default                           = 0,
    PickupFailed_CapacityExceeded                  = 1,
    DropFailed_Default                             = 16,
    UseFailed_Default                              = 32,
    UseFailed_CapacityExceeded                     = 33,
    DisuseFailed_Default                           = 48,
    DisuseFailed_CapacityExceeded                  = 49,
    EBattleItemOperationFailedReason_MAX           = 50

};


// Enum  /Script/AClient.EBattleItemOperationType
enum class EBattleItemOperationType : uint8_t
{
    Pickup                                         = 0,
    Drop                                           = 1,
    Use                                            = 2,
    Disuse                                         = 3,
    Enable                                         = 4,
    Disable                                        = 5,
    EBattleItemOperationType_MAX                   = 6

};


// Enum  /Script/Engine.ENetRole
enum class ENetRole : uint8_t
{
    ROLE_None                                      = 0,
    ROLE_SimulatedProxy                            = 1,
    ROLE_AutonomousProxy                           = 2,
    ROLE_Authority                                 = 3,
    ROLE_MAX                                       = 4

};


// Enum  /Script/Engine.ENetDormancy
enum class ENetDormancy : uint8_t
{
    DORM_Never                                     = 0,
    DORM_Awake                                     = 1,
    DORM_DormantAll                                = 2,
    DORM_DormantPartial                            = 3,
    DORM_Initial                                   = 4,
    DORM_MAX                                       = 5

};


// Enum  /Script/Engine.EAutoReceiveInput
enum class EAutoReceiveInput : uint8_t
{
    Disabled                                       = 0,
    Player0                                        = 1,
    Player1                                        = 2,
    Player2                                        = 3,
    Player3                                        = 4,
    Player4                                        = 5,
    Player5                                        = 6,
    Player6                                        = 7,
    Player7                                        = 8,
    EAutoReceiveInput_MAX                          = 9

};


// Enum  /Script/Engine.ESpawnActorCollisionHandlingMethod
enum class ESpawnActorCollisionHandlingMethod : uint8_t
{
    Undefined                                      = 0,
    AlwaysSpawn                                    = 1,
    AdjustIfPossibleButAlwaysSpawn                 = 2,
    AdjustIfPossibleButDontSpawnIfColliding        = 3,
    DontSpawnIfColliding                           = 4,
    ESpawnActorCollisionHandlingMethod_MAX         = 5

};


// Enum  /Script/Engine.ERotatorQuantization
enum class ERotatorQuantization : uint8_t
{
    ByteComponents                                 = 0,
    ShortComponents                                = 1,
    ERotatorQuantization_MAX                       = 2

};


// Enum  /Script/Engine.EVectorQuantization
enum class EVectorQuantization : uint8_t
{
    RoundWholeNumber                               = 0,
    RoundOneDecimal                                = 1,
    RoundTwoDecimals                               = 2,
    EVectorQuantization_MAX                        = 3

};


// Enum  /Script/AClient.EItemAdditionalType
enum class EItemAdditionalType : uint8_t
{
    IAT_None                                       = 0,
    IAT_InitBulletNum                              = 1,
    IAT_WeaponSkinID                               = 2,
    IAT_DeriveId                                   = 3,
    IAT_ExtraBulletNum                             = 4,
    IAT_SpecialBulletNum                           = 5,
    IAT_bUseSpecialBullet                          = 6,
    IAT_AttachList                                 = 7,
    IAT_PlayerKey                                  = 8,
    IAT_ChargeValue                                = 9,
    IAT_RemainingDuability                         = 10,
    IAT_RemainingBattery                           = 11,
    IAT_RemainingExp                               = 12,
    IAT_SkinOwnerKey                               = 13,
    IAT_CumulativeKill                             = 14,
    IAT_SkinCumulativeKill                         = 15,
    IAT_SpawnSource                                = 16,
    IAT_RemainingAr302_a_                          = 17,
    IAT_DropTime                                   = 18,
    IAT_MAX                                        = 19

};


// Enum  /Script/AClient.EPickupLockedReason
enum class EPickupLockedReason : uint8_t
{
    None                                           = 0,
    Duplicator                                     = 1,
    Manually                                       = 2,
    EPickupLockedReason_MAX                        = 3

};


// Enum  /Script/AClient.EPickUpOutLineType
enum class EPickUpOutLineType : uint8_t
{
    POT_Default                                    = 0,
    POT_Aim                                        = 1,
    POT_MAX                                        = 2

};


// Enum  /Script/AClient.EPickupItemRegionType
enum class EPickupItemRegionType : uint8_t
{
    None                                           = 0,
    Static                                         = 1,
    Dynamic                                        = 2,
    CheckOnLand                                    = 3,
    Max                                            = 4

};


// Enum  /Script/CoreUObject.EAxis
enum class EAxis : uint8_t
{
    None                                           = 0,
    X                                              = 1,
    Y                                              = 2,
    Z                                              = 3,
    EAxis_MAX                                      = 4

};


// Enum  /Script/AClient.EBattleItemDropReason
enum class EBattleItemDropReason : uint8_t
{
    Manually                                       = 0,
    Associated                                     = 1,
    AutoEquipAndDrop                               = 2,
    AutoEquipFailed                                = 3,
    CapacityExceeded                               = 4,
    UsedUp                                         = 5,
    Force                                          = 6,
    DropWithWeapon                                 = 7,
    DropUsed                                       = 8,
    PlayerDeaded                                   = 9,
    NoDrop                                         = 10,
    SwapNoDrop                                     = 11,
    AIDrop                                         = 12,
    AllDisableDrop                                 = 13,
    EBattleItemDropReason_MAX                      = 14

};


// Enum  /Script/AClient.EItemSpawnReason
enum class EItemSpawnReason : uint8_t
{
    None                                           = 0,
    Normal                                         = 1,
    Bin                                            = 2,
    FeloOtball                                     = 3,
    PlayerDrop                                     = 4,
    SuppLydrop_                                    = 5,
    AirDrop                                        = 6,
    GunRack                                        = 7,
    KillDrop                                       = 8,
    Upgrade                                        = 9,
    LootBinCreeps                                  = 10,
    GM                                             = 11,
    FesecretDoor                                   = 12,
    BinTreasurePackage                             = 13,
    EnergyShield                                   = 14,
    GamblingMachine                                = 15,
    Featustore                                     = 16,
    IceBin                                         = 17,
    Rowdy                                          = 18,
    Downgrade                                      = 19,
    DJStage                                        = 20,
    GhostBin                                       = 21,
    NewbieScript                                   = 22,
    AIDrop                                         = 23,
    SystemShop                                     = 24,
    TombBoxFlyer                                   = 25,
    TrainBin                                       = 26,
    TrainReplenishment                             = 27,
    BlueBinBottom                                  = 28,
    FatPoiGoldBin                                  = 29,
    TombBoxPlayer                                  = 30,
    TombBoxAI                                      = 31,
    NewYearFirecracker                             = 32,
    HeterochromaticSynthesis                       = 33,
    Max                                            = 34

};


// Enum  /Script/AClient.EPingActionType
enum class EPingActionType : uint8_t
{
    None                                           = 0,
    Add                                            = 1,
    Delete                                         = 2,
    Delay                                          = 3,
    Response                                       = 4,
    CancelReserve                                  = 5,
    Reset                                          = 6,
    ClearByPlayerKey                               = 7,
    EPingActionType_MAX                            = 8

};


// Enum  /Script/AClient.EPingDataReportType
enum class EPingDataReportType : uint8_t
{
    None                                           = 0,
    ScreenClick                                    = 1,
    QuickClick                                     = 2,
    RoundClick                                     = 3,
    ChatClick                                      = 4,
    BubbleClick                                    = 5,
    OtherResponse                                  = 6,
    InGameChat                                     = 7,
    Others                                         = 10,
    EPingDataReportType_MAX                        = 11

};


// Enum  /Script/AClient.EDoorState
enum class EDoorState : uint8_t
{
    Closed                                         = 0,
    ToForward                                      = 1,
    Forward                                        = 2,
    ForwardToClose                                 = 3,
    ToBackend                                      = 4,
    Backend                                        = 5,
    BeckendToClose                                 = 6,
    EDoorState_MAX                                 = 7

};


// Enum  /Script/AClient.EAutoOpenBlockType
enum class EAutoOpenBlockType : uint8_t
{
    CD                                             = 0,
    Lock                                           = 1,
    EAutoOpenBlockType_MAX                         = 2

};


// Enum  /Script/AClient.EDoorDataRepType
enum class EDoorDataRepType : uint8_t
{
    None                                           = 0,
    SingleDoor                                     = 1,
    DoubleDoor                                     = 2,
    OppositeDoor                                   = 3,
    FesecretDoor                                   = 4,
    MoveDoor                                       = 5,
    EDoorDataRepType_MAX                           = 6

};


// Enum  /Script/AClient.EDoorType
enum class EDoorType : uint8_t
{
    None                                           = 0,
    Door                                           = 1,
    Bin                                            = 2,
    FesecretDoor                                   = 3,
    EDoorType_MAX                                  = 4

};


// Enum  /Script/Engine.ECameraAnimPlaySpace
enum class ECameraAnimPlaySpace : uint8_t
{
    CameraLocal                                    = 0,
    World                                          = 1,
    UserDefined                                    = 2,
    ECameraAnimPlaySpace_MAX                       = 3

};


// Enum  /Script/Engine.EViewTargetBlendFunction
enum class EViewTargetBlendFunction : uint8_t
{
    VTBlend_Linear                                 = 0,
    VTBlend_Cubic                                  = 1,
    VTBlend_EaseIn                                 = 2,
    VTBlend_EaseOut                                = 3,
    VTBlend_EaseInOut                              = 4,
    VTBlend_MAX                                    = 5

};


// Enum  /Script/Engine.ETravelType
enum class ETravelType : uint8_t
{
    TRAVEL_Absolute                                = 0,
    TRAVEL_Partial                                 = 1,
    TRAVEL_Relative                                = 2,
    TRAVEL_MAX                                     = 3

};


// Enum  /Script/Engine.ECollisionChannel
enum class ECollisionChannel : uint8_t
{
    ECC_WorldStatic                                = 0,
    ECC_WorldDynamic                               = 1,
    ECC_Pawn                                       = 2,
    ECC_Visibility                                 = 3,
    ECC_Camera                                     = 4,
    ECC_PhysicsBody                                = 5,
    ECC_Vehicle                                    = 6,
    ECC_Destructible                               = 7,
    ECC_EngineTraceChannel1                        = 8,
    ECC_EngineTraceChannel2                        = 9,
    ECC_EngineTraceChannel3                        = 10,
    ECC_EngineTraceChannel4                        = 11,
    ECC_EngineTraceChannel5                        = 12,
    ECC_EngineTraceChannel6                        = 13,
    ECC_GameTraceChannel1                          = 14,
    ECC_GameTraceChannel2                          = 15,
    ECC_GameTraceChannel3                          = 16,
    ECC_GameTraceChannel4                          = 17,
    ECC_GameTraceChannel5                          = 18,
    ECC_GameTraceChannel6                          = 19,
    ECC_GameTraceChannel7                          = 20,
    ECC_GameTraceChannel8                          = 21,
    ECC_GameTraceChannel9                          = 22,
    ECC_GameTraceChannel10                         = 23,
    ECC_GameTraceChannel11                         = 24,
    ECC_GameTraceChannel12                         = 25,
    ECC_GameTraceChannel13                         = 26,
    ECC_GameTraceChannel14                         = 27,
    ECC_GameTraceChannel15                         = 28,
    ECC_GameTraceChannel16                         = 29,
    ECC_GameTraceChannel17                         = 30,
    ECC_GameTraceChannel18                         = 31,
    ECC_OverlapAll_Deprecated                      = 32,
    ECC_MAX                                        = 33

};


// Enum  /Script/Engine.EControllerAnalogStick
enum class EControllerAnalogStick : uint8_t
{
    CAS_LeftStick                                  = 0,
    CAS_RightStick                                 = 1,
    CAS_MAX                                        = 2

};


// Enum  /Script/Engine.EDynamicForceFeedbackAction
enum class EDynamicForceFeedbackAction : uint8_t
{
    Start                                          = 0,
    Update                                         = 1,
    Stop                                           = 2,
    EDynamicForceFeedbackAction_MAX                = 3

};


// Enum  /Script/InputCore.EControllerHand
enum class EControllerHand : uint8_t
{
    Left                                           = 0,
    Right                                          = 1,
    AnyHand                                        = 2,
    Pad                                            = 3,
    ExternalCamera                                 = 4,
    Gun                                            = 5,
    Special                                        = 6,
    Special                                        = 7,
    Special                                        = 8,
    Special                                        = 9,
    Special                                        = 10,
    Special                                        = 11,
    Special                                        = 12,
    Special                                        = 13,
    Special                                        = 14,
    Special                                        = 15,
    Special                                        = 16,
    ControllerHand_Count                           = 17,
    EControllerHand_MAX                            = 18

};


// Enum  /Script/CoreUObject.EMouseCursor
enum class EMouseCursor : uint8_t
{
    None                                           = 0,
    Default                                        = 1,
    TextEditBeam                                   = 2,
    ResizeLeftRight                                = 3,
    ResizeUpDown                                   = 4,
    ResizeSouthEast                                = 5,
    ResizeSouthWest                                = 6,
    CardinalCross                                  = 7,
    Crosshairs                                     = 8,
    Hand                                           = 9,
    GrabHand                                       = 10,
    GrabHandClosed                                 = 11,
    SlashedCircle                                  = 12,
    EyeDropper                                     = 13,
    EMouseCursor_MAX                               = 14

};


// Enum  /Script/AClient.ECharacterUIState
enum class ECharacterUIState : uint8_t
{
    Normal                                         = 1,
    Dying                                          = 2,
    Dead                                           = 3,
    AircraftRespawn                                = 4,
    Hero11Drone                                    = 5,
    OB                                             = 6,
    DoFinisher                                     = 7,
    OnVehicle                                      = 8,
    Freeze                                         = 9,
    Replay                                         = 10,
    BornIsland                                     = 11,
    Hero17UltimateStart                            = 12,
    JoinHero17UltimateTeam                         = 13,
    Hero17UltimateLaunch                           = 14,
    ParachuteForceBuilding                         = 15,
    Hero50AttachState                              = 16,
    Hero13FlyState                                 = 17,
    InPlane                                        = 20,
    InParachute                                    = 21,
    Featustore                                     = 22,
    PureSpectator                                  = 23,
    BattleEnd                                      = 24,
    InVehicle                                      = 25,
    MAX                                            = 255

};


// Enum  /Script/AClient.EStateSourceType
enum class EStateSourceType : uint8_t
{
    StateMachineComponent_StartMachine             = 0,
    StateMachineComponent_FinishMachine            = 1,
    ParachutePointComp_AttachedCharacterStartParachute = 2,
    RecallAircraftCharacter_LoadCharacters1        = 3,
    RecallAircraftCharacter_LoadCharacters2        = 4,
    TriggerAction_StartParachute_Excute            = 5,
    MagmaRiseVolume_NotifyActorBeginOverlap        = 6,
    VoidDoorActor_DoParachuteJum                   = 7,
    ControllerMagmaComponent_PlayerGoToLanding     = 8,
    PlayerControllerStateFollow_FollowOperation    = 9,
    GnyxCharacter_GotoDying                        = 10,
    GnyxCharacter_GotoDie                          = 11,
    GameModeStage_MsgToAllPlayerControllers        = 12,
    GameModeStage_MsgToPlayerController            = 13,
    GnyxCharacter_OnMagmaRiseMoveHit               = 14,
    GameModePlaneComponent_NotifyPlayersEnterPlane = 15,
    ParachutePointComp_OnCharacterAttached_Implementation = 16,
    CharacterParachuteComponent_ServerDoExpression_Implementation = 17,
    GnyxPlayerController_RecoverPlayerState        = 18,
    GnyxPlayerController_DoParachuteExpression     = 19,
    ControllerCheatHelper_SetAIState_Implementation = 20,
    GnyxAIController_SetCurStateType               = 21,
    GnyxGameMode_OnSpawnAI                         = 22,
    MultiplayerRespawnComponent_RespawnRealPlayer  = 23,
    MultiplayerRespawnComponent_RespawnAIPlayer    = 24,
    GameModePlaneComponent_NotifyAIsEnterPlane     = 25,
    UCharacterParachuteComponent_Reconnected       = 26,
    MidfielederJoin_RespawnMidJoinPlayer           = 27,
    MidfielederJoin_OnChooseLegendFinish           = 28,
    RespawnOperateComponent_RespawnCharacter       = 29,
    MultiLevelGameMode_PlayerTimeOver              = 30,
    GnyxPlayerState_NextLifeRespawn                = 31,
    WeekChallenge_Restart                          = 32,
    BornIslandReady_Enter                          = 33,
    EStateSourceType_MAX                           = 34

};


// Enum  /Script/AClient.EMsgType
enum class EMsgType : uint8_t
{
    None                                           = 0,
    EMsg_GMEnterActive                             = 1,
    EMsg_GMExitActive                              = 2,
    EMsg_GMEnterSelect                             = 3,
    EMsg_GMExitSelect                              = 4,
    EMsg_GMEnterReady                              = 5,
    EMsg_GMExitReady                               = 6,
    EMsg_GMEnterFight                              = 7,
    EMsg_GMExitFight                               = 8,
    EMsg_GMEnterFinish                             = 9,
    EMsg_GMExit                                    = 10,
    EMsg_GMEnterMidJoin                            = 11,
    EMsg_PCGotoFight                               = 12,
    EMsg_PCGotoReady                               = 13,
    EMsg_PCDie                                     = 14,
    EMsg_PCDying                                   = 15,
    EMsg_PCRespawn                                 = 16,
    EMsg_PCGotoMagmaRise                           = 17,
    EMsg_PCGotoMidJoin                             = 18,
    EMsgType_MAX                                   = 19

};


// Enum  /Script/AClient.ESignType
enum class ESignType : uint8_t
{
    Default                                        = 1,
    WEStation                                      = 2,
    WETrainArea                                    = 3,
    Hero10_WireHit                                 = 5,
    Hero08_DecoyVanished                           = 6,
    Hero11_EnemyTriangle                           = 7,
    Hero08_DecoyPosTip                             = 8,
    Hero11_DronePlayerPos                          = 9,
    Hero01_he__EnemyTriangle                       = 10,
    PlayerDeadSign                                 = 11,
    FeatustoreSign                                 = 12,
    Hero01_he__Perk                                = 13,
    Hero17_hEnemyTriangle                          = 14,
    Hero41_hTacticalPreCastTriangle                = 15,
    Hero11ScanHealthCountDown                      = 16,
    H19_MarkTombBox                                = 17,
    H19_MarkTombBoxNone                            = 18,
    H19_ArcBoltHit                                 = 19,
    OverWatch_PossessDetecte                       = 20,
    Common_HealthSheild                            = 21,
    OverWatch_DyingIconUI                          = 22,
    Hero17_h_AimAuxiliary                          = 23,
    Vampire_PassiveIcon                            = 24,
    KillerSign                                     = 25,
    Common_Health                                  = 26,
    MVPSign                                        = 27,
    Hero52_GuardianHealthUI                        = 28,
    Prop_Health                                    = 29,
    Hero56_TacticalPreCastTriangle                 = 30,
    Hero53_UltimatePreCastTriangle                 = 31,
    Hero54_EnemySign                               = 32,
    Hero53_PassiveTriangle                         = 33,
    Hero54_Ultimate_EnemySign                      = 34,
    GoldMode_RedEnvelope                           = 35,
    GoldMode_SavingBox                             = 36,
    GoldMode_Currency                              = 37,
    Hero13_TeleportTeammateSign                    = 38,
    Hero08_TacticalHealthUI                        = 39,
    Hero12_Ultimate_Move                           = 40,
    Hero12_Ultimate_Shoot                          = 41,
    Hero14_Tactical                                = 42,
    ESignType_MAX                                  = 43

};


// Enum  /Script/AClient.EPlayerAudioType
enum class EPlayerAudioType : uint8_t
{
    Knockdown                                      = 0,
    Kill                                           = 1,
    TeamKill                                       = 2,
    TeamMateDown                                   = 3,
    TeamMateDeath                                  = 4,
    EPlayerAudioType_MAX                           = 5

};


// Enum  /Script/AClient.EEnterOBReason
enum class EEnterOBReason : uint8_t
{
    None                                           = 0,
    UnDefine                                       = 1,
    TryOBTeammate                                  = 2,
    TryOBAnyOne                                    = 3,
    EEnterOBReason_MAX                             = 4

};


// Enum  /Script/AClient.EExitGameReason
enum class EExitGameReason : uint8_t
{
    Normal                                         = 0,
    WinButExit                                     = 1,
    EExitGameReason_MAX                            = 2

};


// Enum  /Script/AClient.EBanType
enum class EBanType : uint8_t
{
    ReasonNone                                     = 0,
    ReasonOBDeath                                  = 1,
    ReasonOBFriend                                 = 2,
    ReasonChat                                     = 3,
    ReasonNoPerceptionChat                         = 4,
    ReasonVoice                                    = 5,
    EBanType_MAX                                   = 6

};


// Enum  /Script/AClient.EStateType
enum class EStateType : uint8_t
{
    State_None                                     = 0,
    State_Initial                                  = 1,
    State_Ready                                    = 2,
    State_Fight                                    = 3,
    State_ParachuteOpen                            = 4,
    State_Dead                                     = 5,
    State_Finish                                   = 6,
    State_MagmaRise                                = 7,
    State_MidJoin                                  = 8,
    State_MAX                                      = 9

};


// Enum  /Script/AClient.EGameViewType
enum class EGameViewType : uint8_t
{
    ViewTypeNone                                   = 0,
    ViewTypeTPP                                    = 1,
    ViewTypeFPP                                    = 2,
    EGameViewType_MAX                              = 3

};


// Enum  /Script/AClient.EServerPlayerExitReason
enum class EServerPlayerExitReason : uint8_t
{
    Normal                                         = 0,
    GiveUpGame                                     = 1,
    GameInfoErr                                    = 2,
    LobbyGameOverTime                              = 3,
    DeviceChange                                   = 4,
    IsInBlackRoom                                  = 5,
    NewbieNotIsInBattleScene                       = 6,
    IdIpKickOutGame                                = 7,
    NewbieEnterSame                                = 8,
    RangeEnterSame                                 = 9,
    ClientVerNotMatch                              = 10,
    NoLobbyPlayerInfo                              = 11,
    DsDebugForce                                   = 12,
    NotInBattleScene                               = 13,
    HasSettled                                     = 14,
    BanMode                                        = 15,
    AssForceLogout                                 = 16,
    EServerPlayerExitReason_MAX                    = 17

};


// Enum  /Script/AClient.ECharacterViewSide
enum class ECharacterViewSide : uint8_t
{
    NONE                                           = 0,
    Left                                           = 1,
    Right                                          = 2,
    ECharacterViewSide_MAX                         = 3

};


// Enum  /Script/AClient.EPropsWeaponType
enum class EPropsWeaponType : uint8_t
{
    None                                           = 0,
    Map_resPawn_mPistol                            = 1,
    Mi100_mi10_                                    = 2,
    Mi110_mi110_mi_                                = 3,
    Mi120_mGrenade                                 = 4,
    Tp101_tp1_                                     = 5,
    Mi130_mi130_mi_                                = 6,
    SkeletonGrenade                                = 7,
    Firecracker                                    = 8,
    GalaCannon                                     = 9,
    HeterochromaticSummoner                        = 10,
    WindstormEvacuate                              = 11,
    EvacuateGrenadeLevel1                          = 12,
    EvacuateGrenadeLevel2                          = 13,
    EvacuateElectromagneticDartLevel1              = 14,
    EvacuateElectromagneticDartLevel2              = 15,
    EvacuateNapalmBombLevel1                       = 16,
    EvacuateNapalmBombLevel2                       = 17,
    TraditionalSprayPaint                          = 18,
    SporeGrenade                                   = 19,
    DanceGrenade                                   = 20,
    EvacuateSporeLevel1                            = 21,
    EvacuateSporeLevel2                            = 22,
    EvacuateDanceLevel1                            = 23,
    EvacuateDanceLevel2                            = 24,
    Max                                            = 25

};


// Enum  /Script/AClient.EPropsWeaponEndReason
enum class EPropsWeaponEndReason : uint8_t
{
    None                                           = 0,
    UnEquip                                        = 1,
    Fire                                           = 2,
    Dispose                                        = 3,
    Turn                                           = 4,
    AimExplode                                     = 5,
    TempUnEquip                                    = 6,
    EPropsWeaponEndReason_MAX                      = 7

};


// Enum  /Script/AClient.EBroadcastMsgType
enum class EBroadcastMsgType : uint8_t
{
    PropsWeaponAim                                 = 0,
    EBroadcastMsgType_MAX                          = 1

};


// Enum  /Script/UnrealArchExt.EFrontendMapStatus
enum class EFrontendMapStatus : uint8_t
{
    None                                           = 0,
    PreLoad                                        = 1,
    LoadMap                                        = 2,
    InitMap                                        = 3,
    InitLogic                                      = 4,
    Waiting                                        = 5,
    Running                                        = 6,
    Timeout                                        = 7,
    Failed                                         = 8,
    Over                                           = 9,
    EFrontendMapStatus_MAX                         = 10

};


// Enum  /Script/AClient.EMGameModeStage
enum class EMGameModeStage : uint8_t
{
    None                                           = 0,
    Active                                         = 1,
    SelectLegend                                   = 2,
    Ready                                          = 3,
    Fighting                                       = 4,
    Finished                                       = 5,
    Max                                            = 6

};


// Enum  /Script/AClient.EEq140_eq140_eq_OpCode
enum class EEq140_eq140_eq_OpCode : uint8_t
{
    Activation                                     = 0,
    Revive                                         = 1,
    Cancel                                         = 2,
    Release                                        = 3,
    Abandon                                        = 4,
    EEq140_eq140_eq_MAX                            = 5

};


// Enum  /Script/AClient.EKnockdownReviveOpCode
enum class EKnockdownReviveOpCode : uint8_t
{
    ReviveOther                                    = 0,
    ReviveSelf                                     = 1,
    ReviveCancel                                   = 2,
    EKnockdownReviveOpCode_MAX                     = 3

};


// Enum  /Script/AClient.ERespawnTeammateOpCode
enum class ERespawnTeammateOpCode : uint8_t
{
    RespawnTeammate                                = 0,
    RespawnCancel                                  = 1,
    ERespawnTeammateOpCode_MAX                     = 2

};


// Enum  /Script/AClient.EHitPingType
enum class EHitPingType : uint8_t
{
    None                                           = 0,
    Ground                                         = 1,
    Item                                           = 2,
    Emeny                                          = 3,
    Looting                                        = 4,
    Attacking                                      = 5,
    Activity                                       = 6,
    Defending                                      = 7,
    Watching                                       = 8,
    Survive                                        = 9,
    Door                                           = 10,
    SuppLydrop_                                    = 11,
    TiaoSanTa                                      = 12,
    SaveBox                                        = 13,
    Bin_Box                                        = 14,
    Map_respawn_M                                  = 15,
    Loot_Drones                                    = 16,
    Loot_Roller                                    = 17,
    Tomb_Box                                       = 18,
    Survey_Beacon                                  = 19,
    Zip_Line                                       = 20,
    Fly_Dragon                                     = 21,
    Hot_Balloon                                    = 22,
    ForceField                                     = 23,
    Train                                          = 24,
    HealingRobot                                   = 25,
    RecallAircraft                                 = 26,
    RespawnBanner                                  = 27,
    Dynamic_Map_respawn_M                          = 28,
    FirstAid                                       = 29,
    Respawn                                        = 30,
    Gather                                         = 31,
    Retreat                                        = 32,
    VoidDoor                                       = 50,
    Loot_BinCreeps                                 = 52,
    DirtyBomb                                      = 53,
    DeathTotem                                     = 55,
    Hero09LaunchPad                                = 56,
    Hero10_TeslaNode                               = 57,
    LeeWay                                         = 58,
    FlootShip                                      = 60,
    Harvester                                      = 61,
    Featustore                                     = 62,
    GamblingMachine                                = 65,
    Tp101_tp1_Startup                              = 66,
    Tp101_tp1_                                     = 67,
    Hr13Market                                     = 68,
    IceBinLocked                                   = 69,
    IceBinOpend                                    = 70,
    AdvancedVIPBinLocked                           = 71,
    AdvancedVIPBinOpend                            = 72,
    VIPBinLocked                                   = 73,
    VIPBinOpend                                    = 74,
    Loot_VIPBinCreeps                              = 75,
    Hero12_hSilencer                               = 76,
    ReviveEnemy                                    = 77,
    FlyingSkeletonTeammate                         = 78,
    DataKnifeEnemy                                 = 79,
    DataKnifeTombBox                               = 80,
    GhostBinLocked                                 = 81,
    GhostBinOpen                                   = 82,
    ColosseumActor                                 = 83,
    ColosseumLauncherConsoleOpen                   = 84,
    ColosseumLauncherConsoleClose                  = 85,
    ColosseumParachuteCannonActor                  = 86,
    ColosseumParachuteFeloOtball                   = 87,
    Hero17_hUltimateStart                          = 88,
    FlyingSkeletonEnemy                            = 89,
    GravityElevator                                = 90,
    Hero53TacticalDeploy                           = 91,
    HightPoiBinLocked                              = 93,
    HightPoiBinOpened                              = 94,
    BlueBinLocked                                  = 95,
    BlueBinOpened                                  = 96,
    SelfTombBox                                    = 97,
    GravityCannon                                  = 98,
    GoldMode_ATM                                   = 99,
    GoldMode_RedEnvelope                           = 100,
    GoldMode_Currency                              = 101,
    Hero12_PassivePing                             = 107,
    Hero08_UltimatePing                            = 108,
    Others                                         = 255,
    EHitPingType_MAX                               = 256

};


// Enum  /Script/AClient.EWeaponSaveSlot
enum class EWeaponSaveSlot : uint8_t
{
    WSS_None                                       = 0,
    WSS_MainSlot1                                  = 1,
    WSS_MainSlot2                                  = 2,
    WSS_MeleeSlot                                  = 3,
    WSS_Max                                        = 4

};


// Enum  /Script/AClient.EWinContinueOrExit
enum class EWinContinueOrExit : uint8_t
{
    None                                           = 0,
    Exit                                           = 1,
    ClickToContinue                                = 2,
    EWinContinueOrExit_MAX                         = 3

};


// Enum  /Script/AClient.EBattleResultType
enum class EBattleResultType : uint8_t
{
    None                                           = 0,
    Person                                         = 1,
    Team                                           = 2,
    EBattleResultType_MAX                          = 3

};


// Enum  /Script/AClient.EGameEndReason
enum class EGameEndReason : uint8_t
{
    Champion                                       = 0,
    Win                                            = 1,
    Fail                                           = 2,
    Exit                                           = 3,
    EGameEndReason_MAX                             = 4

};


// Enum  /Script/AClient.ELegendType
enum class ELegendType : uint8_t
{
    LegendNone                                     = 0,
    Hero06                                         = 1,
    Hero01                                         = 2,
    Hero07                                         = 3,
    Hero11                                         = 4,
    Hero02                                         = 5,
    Hero03                                         = 6,
    Hero08                                         = 7,
    Hero09                                         = 8,
    Hero04                                         = 9,
    Hero12                                         = 10,
    Hero10                                         = 11,
    Hero13                                         = 12,
    Hero17                                         = 13,
    Hero05                                         = 14,
    Hero41                                         = 15,
    Hero42                                         = 16,
    Hero43                                         = 17,
    Hero99                                         = 18,
    Hero45                                         = 19,
    Hero44                                         = 20,
    Hero47                                         = 21,
    Hero15                                         = 22,
    Hero19                                         = 23,
    Hero50                                         = 24,
    Hero51                                         = 25,
    Hero52                                         = 26,
    Hero53                                         = 27,
    Hero54                                         = 28,
    Hero56                                         = 29,
    Hero57                                         = 30,
    Hero61                                         = 31,
    Hero62                                         = 32,
    Hero63                                         = 33,
    Hero64                                         = 34,
    Elite05                                        = 35,
    Boss01                                         = 36,
    Hero65                                         = 37,
    Hero66                                         = 38,
    Hero67                                         = 39,
    Hero14                                         = 40,
    Hero68                                         = 41,
    Hero69                                         = 42,
    Hero70                                         = 43,
    Hero71                                         = 44,
    Hero72                                         = 45,
    Boss02                                         = 46,
    Hero73                                         = 47,
    Hero74                                         = 48,
    ELegendType_MAX                                = 49

};


// Enum  /Script/AClient.ESignTypeFor
enum class ESignTypeFor : uint8_t
{
    Self                                           = 1,
    Team                                           = 2,
    All                                            = 3,
    ESignTypeFor_MAX                               = 4

};


// Enum  /Script/AClient.EBattleItemUseReason
enum class EBattleItemUseReason : uint8_t
{
    Manually                                       = 0,
    Associated                                     = 1,
    AutoEquipAndDrop                               = 2,
    Swapped                                        = 3,
    Initial                                        = 4,
    BackpackOperate                                = 5,
    Max                                            = 16

};


// Enum  /Script/AClient.EBattleItemDisuseReason
enum class EBattleItemDisuseReason : uint8_t
{
    Manually                                       = 0,
    Associated                                     = 1,
    NotAssociated                                  = 2,
    Excluded                                       = 3,
    Swapped                                        = 4,
    AssociateSwapped                               = 5,
    Dropped                                        = 6,
    Force                                          = 7,
    PlayerDeaded                                   = 8,
    UsedUp                                         = 9,
    Max                                            = 16

};


// Enum  /Script/AClient.EAttachSocketType
enum class EAttachSocketType : uint8_t
{
    None                                           = 0,
    Grip                                           = 1,
    Magazine                                       = 2,
    Gunstock                                       = 3,
    OpticalSight                                   = 4,
    Support                                        = 5,
    GunPoint                                       = 6,
    Ammo                                           = 7,
    Pendant                                        = 8,
    HopUp                                          = 9,
    SniperScope                                    = 10,
    ADSMesh                                        = 11,
    Charge                                         = 12,
    Battery                                        = 13,
    Thermal                                        = 14,
    Max                                            = 15

};


// Enum  /Script/AClient.EVirtualJoyStickHiddenSource
enum class EVirtualJoyStickHiddenSource : uint8_t
{
    NONE                                           = 0,
    HiddenFromUIState                              = 1,
    HiddenFromSelectLegend                         = 2,
    HiddenFromLua                                  = 3,
    HiddenFromParachuteTeamControl                 = 4,
    Simulate                                       = 5,
    RescueSelf                                     = 6,
    MAX                                            = 32

};


// Enum  /Script/AClient.EScreenLeftOperateMode
enum class EScreenLeftOperateMode : uint8_t
{
    Joystick                                       = 1,
    Joystick_Dynamic                               = 2,
    Joystick_AllLeft                               = 3,
    View_AllLeft                                   = 4,
    View_DynamicPosition                           = 5,
    EScreenLeftOperateMode_MAX                     = 6

};


// Enum  /Script/AClient.EScreenRightOperateMode
enum class EScreenRightOperateMode : uint8_t
{
    View_AllRight                                  = 1,
    View_FireFollow                                = 2,
    View_MAX                                       = 3

};


// Enum  /Script/AClient.ERecallOperateDontShowReason
enum class ERecallOperateDontShowReason : uint8_t
{
    None                                           = 0,
    BeaconDontUseAble                              = 1,
    StopSweepBeacon                                = 2,
    VelocityNotZero                                = 3,
    NotAllowState                                  = 4,
    InDomain                                       = 5,
    LineTraceBlock                                 = 6,
    NotAllowInteractive                            = 7,
    NotInFov                                       = 8,
    PlayerStateIsNull                              = 9,
    BattleBehStateError                            = 10,
    TeamMateOperating                              = 11,
    ERecallOperateDontShowReason_MAX               = 12

};


// Enum  /Script/AClient.EScreenOperateMode
enum class EScreenOperateMode : uint8_t
{
    Mode1                                          = 1,
    Mode2                                          = 2,
    Mode3                                          = 3,
    EScreenOperateMode_MAX                         = 4

};


// Enum  /Script/AClient.eInGameRecoverItemGuidType
enum class eInGameRecoverItemGuidType : uint8_t
{
    eShield                                        = 0,
    eHealth                                        = 1,
    eInGameRecoverItemGuidType_MAX                 = 2

};


// Enum  /Script/AClient.EGnyxInteractType
enum class EGnyxInteractType : uint8_t
{
    OpenDoor                                       = 0,
    CloseDoor                                      = 1,
    OpenBin                                        = 2,
    OpenBinBottom                                  = 3,
    ZiplineRide                                    = 4,
    ZiplineDown                                    = 5,
    OpenSuppLydrop_                                = 6,
    EGnyxInteractType_MAX                          = 7

};


// Enum  /Script/AClient.EAvatarDamagePosition
enum class EAvatarDamagePosition : uint8_t
{
    Non                                            = 0,
    BigHead                                        = 1,
    BigThighs                                      = 2,
    BigBody                                        = 3,
    BigHand                                        = 4,
    BigFoot                                        = 5,
    Wheel0                                         = 6,
    Wheel1                                         = 7,
    Wheel2                                         = 8,
    Wheel3                                         = 9,
    MaxNum                                         = 10,
    EAvatarDamagePosition_MAX                      = 11

};


// Enum  /Script/AClient.EParachuteTriggerReason
enum class EParachuteTriggerReason : uint8_t
{
    NONE                                           = 0,
    GM_Instruction                                 = 1,
    JumpFromPlane                                  = 2,
    JumpFromPoint                                  = 3,
    JumpFromHotBalloon                             = 4,
    JumpFromSteamPad                               = 5,
    JumpFromFountain                               = 6,
    JumpFromRespawn                                = 7,
    JumpFromHero17_hUltimate                       = 8,
    JumpFromVoidDoor                               = 9,
    JumpFromParachuteCannon                        = 10,
    EParachuteTriggerReason_MAX                    = 11

};


// Enum  /Script/AClient.EDingType
enum class EDingType : uint8_t
{
    None                                           = 0,
    DingOK                                         = 1,
    ICant                                          = 2,
    DingNO                                         = 3,
    Ding                                           = 4,
    Delete                                         = 5,
    Join                                           = 6,
    CancelDing                                     = 7,
    CantDing                                       = 8,
    CantDelete                                     = 9,
    EDingType_MAX                                  = 10

};


// Enum  /Script/AClient.EKillKingMessageType
enum class EKillKingMessageType : uint8_t
{
    None                                           = 0,
    KillKingAchieved                               = 1,
    KillKillKing                                   = 2,
    KillDefenders                                  = 3,
    Max                                            = 4

};


// Enum  /Script/AClient.ERespawnType
enum class ERespawnType : uint8_t
{
    Normal                                         = 0,
    NextLife                                       = 1,
    ERespawnType_MAX                               = 2

};


// Enum  /Script/AClient.EParachuteState
enum class EParachuteState : uint8_t
{
    PS_None                                        = 0,
    PS_GnglIder                                    = 1,
    PS_Opening                                     = 2,
    PS_Landing                                     = 3,
    PS_MAX                                         = 4

};


// Enum  /Script/AClient.EMHealthSyncInfo
enum class EMHealthSyncInfo : uint8_t
{
    None                                           = 0,
    Health                                         = 1,
    Shield                                         = 2,
    Signal                                         = 3,
    HealthHealing                                  = 4,
    ShieldHealing                                  = 5,
    SignalHealing                                  = 6,
    BatState                                       = 7,
    ProtectedByTotem                               = 8,
    ExtraHealth                                    = 9,
    All                                            = 10,
    Max                                            = 11

};


// Enum  /Script/AClient.EMTeamSyncInfo
enum class EMTeamSyncInfo : uint8_t
{
    Health                                         = 0,
    Shield                                         = 1,
    Signal                                         = 2,
    UpgradeShieldRemain                            = 3,
    ShieldQuality                                  = 4,
    HelmetQuality                                  = 5,
    UpgradeShieldQuality                           = 6,
    TeamIdx                                        = 7,
    Commander                                      = 8,
    ProtectedByTotem                               = 9,
    HealthHealing                                  = 10,
    ShieldHealing                                  = 11,
    SignalHealing                                  = 12,
    IsSingleParachute                              = 13,
    ChooseLegendId                                 = 14,
    ConfirmLegendId                                = 15,
    LegendId                                       = 16,
    LegendSkin                                     = 17,
    ValidSkins                                     = 18,
    BackpackLevel                                  = 19,
    Eq140_eq140_eq_Level                           = 20,
    BatState                                       = 21,
    NetLost                                        = 22,
    BannerState                                    = 23,
    SyncDyingRealTime                              = 24,
    SyncRespawningRealTime                         = 25,
    AIHostPlayerKey                                = 26,
    AIHosting                                      = 27,
    AIHostFunc                                     = 28,
    SecIconChange                                  = 29,
    NextLifeState                                  = 30,
    NextLifeRespawnState                           = 31,
    LegendRune                                     = 32,
    All                                            = 33,
    EMTeamSyncInfo_MAX                             = 34

};


// Enum  /Script/AClient.EPlayerKillMessageType
enum class EPlayerKillMessageType : uint8_t
{
    None                                           = 0,
    ToDying                                        = 1,
    ToDie                                          = 2,
    Finisher                                       = 3,
    Ace                                            = 4,
    KillKing                                       = 5,
    SecondLife                                     = 6,
    EnterSquare                                    = 7,
    Max                                            = 8

};


// Enum  /Script/AClient.ETurnTableType
enum class ETurnTableType : uint8_t
{
    None                                           = 0,
    Emoji                                          = 1,
    Projectile                                     = 2,
    Consumables                                    = 3,
    ETurnTableType_MAX                             = 4

};


// Enum  /Script/AClient.ECancelBtnReason
enum class ECancelBtnReason : uint8_t
{
    Projectile                                     = 0,
    ShootWeapon                                    = 1,
    ECancelBtnReason_MAX                           = 2

};


// Enum  /Script/AClient.ETouchTakeOverType
enum class ETouchTakeOverType : uint8_t
{
    None                                           = 0,
    RightShoot                                     = 1,
    LeftShoot                                      = 2,
    ViceShoot                                      = 3,
    AimButton                                      = 4,
    SmallSkill                                     = 5,
    Crouch                                         = 6,
    Jump                                           = 7,
    Ping                                           = 8,
    Common                                         = 9,
    Max                                            = 10

};


// Enum  /Script/AClient.EPickupPanelPingState
enum class EPickupPanelPingState : uint8_t
{
    None                                           = 0,
    PPPS_SelfPing                                  = 1,
    PPPS_OtherPing                                 = 2,
    PPPS_SelfReserve                               = 3,
    PPPS_OtherReserve                              = 4,
    EPickupPanelPingState_MAX                      = 5

};


// Enum  /Script/AClient.EPickupGroup
enum class EPickupGroup : uint8_t
{
    None                                           = 0,
    PG_ActivityTop                                 = 1,
    PG_Weapon                                      = 2,
    PG_Ammo                                        = 3,
    PG_Equipment                                   = 4,
    PG_Attachment                                  = 5,
    PG_Consumables                                 = 6,
    PG_Grenades                                    = 7,
    PG_Tactics                                     = 8,
    PG_ActivityBottom                              = 9,
    PG_Other                                       = 10,
    PG_Drop                                        = 11,
    EPickupGroup_MAX                               = 12

};


// Enum  /Script/AClient.EChatVoiceUIState
enum class EChatVoiceUIState : uint8_t
{
    OpenAllMic                                     = 0,
    OpenTeamMic                                    = 1,
    OpenAllInterphone                              = 2,
    OpenTeamInterphone                             = 3,
    LongPressInterphone                            = 4,
    OpenAllListener                                = 5,
    OpenTeamListener                               = 6,
    OpenAllTeamMic                                 = 7,
    OpenAllTeamInterphone                          = 8,
    OpenAllTeamListener                            = 9,
    EChatVoiceUIState_MAX                          = 10

};


// Enum  /Script/AClient.EInGameGuideDirection
enum class EInGameGuideDirection : uint8_t
{
    Left                                           = 0,
    Right                                          = 1,
    Top                                            = 2,
    Bottom                                         = 3,
    UpLeft                                         = 4,
    BottomLeft                                     = 5,
    UpRight                                        = 6,
    BottomRight                                    = 7,
    EInGameGuideDirection_MAX                      = 8

};


// Enum  /Script/AClient.EInGameGuideLineType
enum class EInGameGuideLineType : uint8_t
{
    Type1                                          = 0,
    Type2                                          = 1,
    EInGameGuideLineType_MAX                       = 2

};


// Enum  /Script/AClient.EMeleeAttackPose
enum class EMeleeAttackPose : uint8_t
{
    StandAttack                                    = 0,
    SprintAttack                                   = 1,
    CrouchAttack                                   = 2,
    SlidingAttack                                  = 3,
    InAirAttack                                    = 4,
    EMeleeAttackPose_MAX                           = 5

};


// Enum  /Script/AClient.EGnyxSoundType
enum class EGnyxSoundType : uint8_t
{
    GnyxSoundNone                                  = 0,
    GnyxWorldObject                                = 1,
    GnyxWorldBGM                                   = 2,
    GnyxWorldAmb                                   = 3,
    GnyxWorldUI                                    = 4,
    GnyxWorldLegendSound                           = 5,
    GnyxWorldCircle                                = 6,
    GnyxLegendFootStep                             = 7,
    GnyxLegendClimb                                = 8,
    GnyxLegendSlide                                = 9,
    GnyxLegendMainSkill                            = 10,
    GnyxLegendSmallSkill                           = 11,
    GnyxLegendNegativeSkill                        = 12,
    GnyxShootWeaponFire                            = 13,
    GnyxShootWeaponReload                          = 14,
    GnyxGrenade                                    = 15,
    GnyxHealing                                    = 16,
    Broadcast                                      = 17,
    EGnyxSoundType_MAX                             = 18

};


// Enum  /Script/AClient.EPetState
enum class EPetState : uint8_t
{
    Idle                                           = 0,
    WaitAnim                                       = 1,
    Jumping                                        = 2,
    FlyingUp                                       = 3,
    Dying                                          = 4,
    KillCelebrate                                  = 5,
    Rescuing                                       = 6,
    BeingRescued                                   = 7,
    Parachute                                      = 8,
    EPetState_MAX                                  = 9

};


// Enum  /Script/AClient.ECharacterAnimType
enum class ECharacterAnimType : uint8_t
{
    ECharAnim_Move                                 = 0,
    ECharAnim_Aim                                  = 1,
    ECharAnim_ToStand                              = 2,
    ECharAnim_ToCrouch                             = 3,
    ECharAnim_Hurt                                 = 4,
    ECharAnim_Reload                               = 5,
    ECharAnim_TacticsReload                        = 6,
    ECharAnim_Fire_Single                          = 7,
    ECharAnim_Fire_Scope                           = 8,
    ECharAnim_PullingPlug                          = 9,
    ECharAnim_PutUpWeapon                          = 10,
    ECharAnim_PutDownWeapon                        = 11,
    ECharAnim_PickWeapon                           = 12,
    ECharAnim_ForegripAnim                         = 13,
    ECharAnim_WeaponIdle                           = 14,
    ECharAnim_Turn_L                               = 15,
    ECharAnim_Turn_R                               = 16,
    ECharAnim_Shovel                               = 17,
    ECharAnim_Climb                                = 18,
    ECharAnim_Hang                                 = 19,
    ECharAnim_Vault                                = 20,
    ECharAnim_AIM_Move                             = 21,
    ECharAnim_ADSON_MTG                            = 22,
    ECharAnim_ADSOFF_MTG                           = 23,
    ECharAnim_Sprint_BS                            = 24,
    ECharAnim_Breathe_SEQ                          = 25,
    ECharAnim_Death_MTG                            = 26,
    ECharAnim_NormalMoveBack_BS                    = 27,
    ECharAnim_AimMoveBack_BS                       = 28,
    ECharAnim_Frisk_SEQ                            = 29,
    ECharAnim_ShootType_Automatic                  = 30,
    ECharAnim_ShootType_Single                     = 31,
    ECharAnim_ShootType_Multiple                   = 32,
    ECharAnim_Skill_LeftHand                       = 33,
    ECharAnim_Skill_RightHand                      = 34,
    ECharAnim_Skill_BothHands                      = 35,
    ECharAnim_Rescue_Other                         = 36,
    ECharAnim_Rescue_Self                          = 37,
    ECharAnim_Rescue_BeRescue                      = 38,
    ECharAnim_Slide_Start                          = 39,
    ECharAnim_Slide_Loop                           = 40,
    ECharAnim_Slide_End                            = 41,
    ECharAnim_Slide_Aim                            = 42,
    ECharAnim_Pick_Banner                          = 43,
    ECharAnim_ADS_LeftShield                       = 44,
    ECharAnim_ADS_BreatheAdd                       = 45,
    ECharAnim_FoldGun                              = 46,
    ECharAnim_EquipAttachment                      = 47,
    ECharAnim_SprintPutOnWeapon                    = 48,
    ECharAnim_SprintPutOffWeapon                   = 49,
    ECharAnim_SingleRightHandGun                   = 50,
    ECharAnim_SwitchGun                            = 51,
    ECharAnim_ToSingleBothHand                     = 52,
    ECharAnim_GoUpZipline                          = 53,
    ECharAnim_LoopZipline                          = 54,
    ECharAnim_GoDownZipline                        = 55,
    ECharAnim_WeaponCharge                         = 56,
    ECharAnim_Fire_Auto                            = 57,
    ECharAnim_Fire_Burst                           = 58,
    ECharAnim_ADS_Fire_Auto                        = 59,
    ECharAnim_ADS_Fire_Burst                       = 60,
    ECharAnim_UnEquipToUnArm                       = 61,
    ECharAnim_PreFire                              = 62,
    ECharAnim_OrientationWarpingMove_BS            = 63,
    ECharAnim_FakeUnEquipHeirloom                  = 64,
    ECharAnim_OrientationWarpingMoveWhenADS        = 65,
    ECharAnim_PutUpProps                           = 66,
    ECharAnim_PutDownProps                         = 67,
    ECharAnim_SkillAo                              = 68,
    ECharAnim_SkillBs                              = 69,
    ECharAnim_SkillSeq                             = 70,
    ECharAnim_GroundSlideStart                     = 71,
    ECharAnim_Display1                             = 72,
    ECharAnim_AimPullingPlug                       = 73,
    ECharAnim_SniperPullingPlug                    = 74,
    ECharAnim_Display2                             = 75,
    ECharAnim_EnterSprint                          = 76,
    ECharAnim_KeepSprintPose                       = 77,
    ECharAnim_LeaveSprintInStand                   = 78,
    ECharAnim_LeaveSprintInSlide                   = 79,
    ECharAnim_EnterZiplineWeapon                   = 80,
    ECharAnim_KeepZiplineWeaponPose                = 81,
    ECharAnim_LeaveZiplineWeapon                   = 82,
    ECharAnim_MovingUpBodyOverlay                  = 83,
    ECharAnim_MeleeAttackBack                      = 84,
    ECharAnim_SprintMeleeAttackBack                = 85,
    ECharAnim_DownMove                             = 86,
    ECharAnim_TakeMedicineBaseOrAdd                = 87,
    ECharAnim_DownProtectBaseMoveOrIdle            = 88,
    ECharAnim_HoldGunAimAddive                     = 89,
    ECharAnim_ZipLineV_Addtive                     = 90,
    ECharAnim_GrenadeBaseOrAdd                     = 91,
    ECharAnim_SlideStartHoldWeapon                 = 92,
    ECharAnim_ClimbHangingStart                    = 93,
    ECharAnim_JumpFaillingFwd                      = 94,
    ECharAnim_Sliding_SprintStart                  = 95,
    ECharAnim_Sliding_FallingStart                 = 96,
    ECharAnim_Sliding_FallingLoop                  = 97,
    ECharAnim_HitLLOrRLOrHead                      = 98,
    ECharAnim_BeginnerGuideIdle                    = 99,
    ECharAnim_ClimbMoveLoop                        = 100,
    ECharAnim_HangingEnd                           = 101,
    ECharAnim_LeftHandPickup                       = 102,
    ECharAnim_FullBodyPickup                       = 103,
    ECharAnim_Autonomous_ADSON_MTG                 = 104,
    ECharAnim_Autonomous_ADSON_MTG_Sprint          = 105,
    ECharAnim_DestoryWeaponToUnArm                 = 106,
    ECharAnim_Fire_Scope_Optical                   = 107,
    ECharAnim_View                                 = 108,
    ECharAnim_Max                                  = 109

};


// Enum  /Script/AClient.EAnimLayerType
enum class EAnimLayerType : uint8_t
{
    EAnimLayer_Char                                = 0,
    EAnimLayer_Weapon                              = 1,
    EAnimLayer_Skill                               = 2,
    EAnimLayer_Indivi                              = 3,
    EAnimLayer_Inspect                             = 4,
    EAnimLayer_Max                                 = 5

};


// Enum  /Script/AClient.ECharacterPoseType
enum class ECharacterPoseType : uint8_t
{
    ECharPose_Stand                                = 0,
    ECharPose_Crouch                               = 1,
    ECharPose_SingleStand                          = 2,
    ECharPose_SingleCrouch                         = 3,
    ECharPose_Max                                  = 4

};


// Enum  /Script/AClient.EAuraTargetLimitType
enum class EAuraTargetLimitType : uint8_t
{
    None                                           = 0,
    Nearest                                        = 1,
    LessDistanceThenNearestDistToViewDir           = 2,
    EAuraTargetLimitType_MAX                       = 3

};


// Enum  /Script/AClient.EPickerTargetType
enum class EPickerTargetType : uint8_t
{
    None                                           = 0,
    Self                                           = 1,
    TeamMate                                       = 2,
    Group                                          = 3,
    Enemy                                          = 4,
    Other                                          = 5,
    All                                            = 6,
    TeamMateNotSelf                                = 7,
    TeamMateIncludeDecoy                           = 8,
    MaxNum                                         = 9,
    EPickerTargetType_MAX                          = 10

};


// Enum  /Script/AClient.EAuraEvaluateBlockType
enum class EAuraEvaluateBlockType : uint8_t
{
    Default                                        = 0,
    CrossHair                                      = 1,
    EyePos                                         = 2,
    CrossHairLessDistanceThenEyePos                = 3,
    EAuraEvaluateBlockType_MAX                     = 4

};


// Enum  /Script/UMG.ESlateAccessibleBehavior
enum class ESlateAccessibleBehavior : uint8_t
{
    NotAccessible                                  = 0,
    Auto                                           = 1,
    Summary                                        = 2,
    Custom                                         = 3,
    ToolTip                                        = 4,
    ESlateAccessibleBehavior_MAX                   = 5

};


// Enum  /Script/SlateCore.ECheckBoxState
enum class ECheckBoxState : uint8_t
{
    Unchecked                                      = 0,
    Checked                                        = 1,
    Undetermined                                   = 2,
    ECheckBoxState_MAX                             = 3

};


// Enum  /Script/SlateCore.EWidgetClipping
enum class EWidgetClipping : uint8_t
{
    Inherit                                        = 0,
    ClipToBounds                                   = 1,
    ClipToBoundsWithoutIntersecting                = 2,
    ClipToBoundsAlways                             = 3,
    OnDemand                                       = 4,
    EWidgetClipping_MAX                            = 5

};


// Enum  /Script/SlateCore.ESlateBrushImageType
enum class ESlateBrushImageType : uint8_t
{
    NoImage                                        = 0,
    FullColor                                      = 1,
    Linear                                         = 2,
    ESlateBrushImageType_MAX                       = 3

};


// Enum  /Script/SlateCore.ESlateBrushMirrorType
enum class ESlateBrushMirrorType : uint8_t
{
    NoMirror                                       = 0,
    Horizontal                                     = 1,
    Vertical                                       = 2,
    Both                                           = 3,
    ESlateBrushMirrorType_MAX                      = 4

};


// Enum  /Script/SlateCore.ESlateBrushTileType
enum class ESlateBrushTileType : uint8_t
{
    NoTile                                         = 0,
    Horizontal                                     = 1,
    Vertical                                       = 2,
    Both                                           = 3,
    ESlateBrushTileType_MAX                        = 4

};


// Enum  /Script/SlateCore.ESlateBrushDrawType
enum class ESlateBrushDrawType : uint8_t
{
    NoDrawType                                     = 0,
    Box                                            = 1,
    Border                                         = 2,
    Image                                          = 3,
    HorizontalSymmetricalImage                     = 4,
    VerticalSymmetricalImage                       = 5,
    MirrorSymmetricalImage                         = 6,
    ESlateBrushDrawType_MAX                        = 7

};


// Enum  /Script/SlateCore.ESlateColorStylingMode
enum class ESlateColorStylingMode : uint8_t
{
    UseColor_Specified                             = 0,
    UseColor_Specified_Link                        = 1,
    UseColor_Foreground                            = 2,
    UseColor_Foreground_Subdued                    = 3,
    UseColor_MAX                                   = 4

};


// Enum  /Script/UMG.ESlateVisibility
enum class ESlateVisibility : uint8_t
{
    Visible                                        = 0,
    Collapsed                                      = 1,
    Hidden                                         = 2,
    HitTestInvisible                               = 3,
    SelfHitTestInvisible                           = 4,
    ESlateVisibility_MAX                           = 5

};


// Enum  /Script/SlateCore.EUINavigationRule
enum class EUINavigationRule : uint8_t
{
    Escape                                         = 0,
    Explicit                                       = 1,
    Wrap                                           = 2,
    Stop                                           = 3,
    Custom                                         = 4,
    CustomBoundary                                 = 5,
    Invalid                                        = 6,
    EUINavigationRule_MAX                          = 7

};


// Enum  /Script/SlateCore.EUINavigation
enum class EUINavigation : uint8_t
{
    Left                                           = 0,
    Right                                          = 1,
    Up                                             = 2,
    Down                                           = 3,
    Next                                           = 4,
    Previous                                       = 5,
    Num                                            = 6,
    Invalid                                        = 7,
    EUINavigation_MAX                              = 8

};


// Enum  /Script/SlateCore.EFlowDirectionPreference
enum class EFlowDirectionPreference : uint8_t
{
    Inherit                                        = 0,
    Culture                                        = 1,
    LeftToRight                                    = 2,
    RightToLeft                                    = 3,
    EFlowDirectionPreference_MAX                   = 4

};


// Enum  /Script/SlateCore.EColorVisionDeficiency
enum class EColorVisionDeficiency : uint8_t
{
    NormalVision                                   = 0,
    Deuteranope                                    = 1,
    Protanope                                      = 2,
    Tritanope                                      = 3,
    EColorVisionDeficiency_MAX                     = 4

};


// Enum  /Script/Engine.EMouseLockMode
enum class EMouseLockMode : uint8_t
{
    DoNotLock                                      = 0,
    LockOnCapture                                  = 1,
    LockAlways                                     = 2,
    LockInFullscreen                               = 3,
    EMouseLockMode_MAX                             = 4

};


// Enum  /Script/Engine.EWindowTitleBarMode
enum class EWindowTitleBarMode : uint8_t
{
    Overlay                                        = 0,
    VerticalBox                                    = 1,
    EWindowTitleBarMode_MAX                        = 2

};


// Enum  /Script/SlateCore.ESelectInfo
enum class ESelectInfo : uint8_t
{
    OnKeyPress                                     = 0,
    OnNavigation                                   = 1,
    OnMouseClick                                   = 2,
    Direct                                         = 3,
    ESelectInfo_MAX                                = 4

};


// Enum  /Script/SlateCore.ETextCommit
enum class ETextCommit : uint8_t
{
    Default                                        = 0,
    OnEnter                                        = 1,
    OnUserMovedFocus                               = 2,
    OnCleared                                      = 3,
    ETextCommit_MAX                                = 4

};


// Enum  /Script/Slate.ETextFlowDirection
enum class ETextFlowDirection : uint8_t
{
    Auto                                           = 0,
    LeftToRight                                    = 1,
    RightToLeft                                    = 2,
    ETextFlowDirection_MAX                         = 3

};


// Enum  /Script/SlateCore.ETextShapingMethod
enum class ETextShapingMethod : uint8_t
{
    Auto                                           = 0,
    KerningOnly                                    = 1,
    FullShaping                                    = 2,
    ETextShapingMethod_MAX                         = 3

};


// Enum  /Script/Slate.ETextJustify
enum class ETextJustify : uint8_t
{
    Left                                           = 0,
    Center                                         = 1,
    Right                                          = 2,
    ETextJustify_MAX                               = 3

};


// Enum  /Script/Slate.EVirtualKeyboardDismissAction
enum class EVirtualKeyboardDismissAction : uint8_t
{
    TextChangeOnDismiss                            = 0,
    TextCommitOnAccept                             = 1,
    TextCommitOnDismiss                            = 2,
    EVirtualKeyboardDismissAction_MAX              = 3

};


// Enum  /Script/UMG.EVirtualKeyboardType
enum class EVirtualKeyboardType : uint8_t
{
    Default                                        = 0,
    Number                                         = 1,
    Web                                            = 2,
    Email                                          = 3,
    Password                                       = 4,
    AlphaNumeric                                   = 5,
    EVirtualKeyboardType_MAX                       = 6

};


// Enum  /Script/Slate.ETextWrappingPolicy
enum class ETextWrappingPolicy : uint8_t
{
    DefaultWrapping                                = 0,
    AllowPerCharacterWrapping                      = 1,
    NoBreakPerWrapping                             = 2,
    ETextWrappingPolicy_MAX                        = 3

};


// Enum  /Script/Slate.EDescendantScrollDestination
enum class EDescendantScrollDestination : uint8_t
{
    IntoView                                       = 0,
    TopOrLeft                                      = 1,
    Center                                         = 2,
    EDescendantScrollDestination_MAX               = 3

};


// Enum  /Script/SlateCore.EConsumeMouseWheel
enum class EConsumeMouseWheel : uint8_t
{
    WhenScrollingPossible                          = 0,
    Always                                         = 1,
    Never                                          = 2,
    EConsumeMouseWheel_MAX                         = 3

};


// Enum  /Script/SlateCore.EOrientation
enum class EOrientation : uint8_t
{
    Orient_Horizontal                              = 0,
    Orient_Vertical                                = 1,
    Orient_MAX                                     = 2

};


// Enum  /Script/AClient.EFreshWeaponStateType
enum class EFreshWeaponStateType : uint8_t
{
    FreshWeaponStateType_None                      = 0,
    FreshWeaponStateType_Inactive                  = 1,
    FreshWeaponStateType_Idle                      = 2,
    FreshWeaponStateType_IdleToBackpack            = 3,
    FreshWeaponStateType_Backpack                  = 4,
    FreshWeaponStateType_BackpackToIdle            = 5,
    FreshWeaponStateType_Fire                      = 6,
    FreshWeaponStateType_Reload                    = 7,
    FreshWeaponStateType_PreFire                   = 8,
    FreshWeaponStateType_PostFire                  = 9,
    FreshWeaponStateType_PostReload                = 10,
    FreshWeaponStateType_InClimb                   = 11,
    FreshWeaponStateType_View                      = 12,
    Max                                            = 13

};


// Enum  /Script/AClient.EWeaponAttchSocketPosition
enum class EWeaponAttchSocketPosition : uint8_t
{
    None                                           = 0,
    Back_ShortLeft                                 = 1,
    Back_ShortRight                                = 2,
    Back_LongLeft                                  = 3,
    Back_LongRight                                 = 4,
    Hand_Equip                                     = 5,
    Hand_Equip2                                    = 6,
    Back_Melee1                                    = 7,
    Back_Melee2                                    = 8,
    MAX                                            = 9

};


// Enum  /Script/AClient.ECharacterHealthStatus
enum class ECharacterHealthStatus : uint8_t
{
    HealthyAlive                                   = 0,
    HasLastBreath                                  = 1,
    FinishedLastBreath                             = 2,
    MAX                                            = 3

};


// Enum  /Script/AClient.ESwitchPhase
enum class ESwitchPhase : uint8_t
{
    None                                           = 0,
    Equiping                                       = 1,
    UnEquiping                                     = 2,
    ESwitchPhase_MAX                               = 3

};


// Enum  /Script/AClient.EWeaponSpecificType
enum class EWeaponSpecificType : uint8_t
{
    None                                           = 0,
    Q201                                           = 1,
    Q7                                             = 2,
    Q101                                           = 3,
    Ar202_                                         = 4,
    Aq101                                          = 5,
    Q11                                            = 6,
    Smg102_sm_                                     = 7,
    Smg201_                                        = 8,
    Q301                                           = 9,
    Lq21                                           = 10,
    LQ301                                          = 11,
    Lmg302_l                                       = 12,
    Sg402_sg40_                                    = 13,
    Sg403_sg4_                                     = 14,
    SG41                                           = 15,
    Sg404_s                                        = 16,
    Sr501_s                                        = 17,
    SR303                                          = 18,
    Sr502_Sr50_                                    = 19,
    Sr503_s_                                       = 20,
    Sr504_                                         = 21,
    AWM                                            = 22,
    P101_                                          = 23,
    P102                                           = 24,
    P201_p_                                        = 25,
    SR201                                          = 26,
    Lmg202_                                        = 27,
    AR102                                          = 28,
    AR302                                          = 29,
    SMG202                                         = 30,
    SR505                                          = 31,
    AR304                                          = 32,
    SG405                                          = 33,
    P301                                           = 34,
    SR301                                          = 35,
    Lmg302_lWithHu107                              = 36,
    P102WithHammerPoint                            = 37,
    Lmg202_WithThermitGrenade                      = 38,
    EWeaponSpecificType_MAX                        = 39

};


// Enum  /Script/AClient.ESimuWeaponFollowState
enum class ESimuWeaponFollowState : uint8_t
{
    SWFS_None                                      = 0,
    SWFS_Near                                      = 1,
    SWFS_Far                                       = 2,
    SWFS_SuperFar                                  = 3,
    SWFS_MAX                                       = 4

};


// Enum  /Script/Engine.EAutoPossessAI
enum class EAutoPossessAI : uint8_t
{
    Disabled                                       = 0,
    PlacedInWorld                                  = 1,
    Spawned                                        = 2,
    PlacedInWorldOrSpawned                         = 3,
    EAutoPossessAI_MAX                             = 4

};


// Enum  /Script/AClient.EDisplayCharStateMode
enum class EDisplayCharStateMode : uint8_t
{
    None                                           = 0,
    Idle                                           = 1,
    RandomIdle                                     = 2,
    PlayMontage                                    = 3,
    Sprint                                         = 4,
    Fire                                           = 5,
    Reload                                         = 6,
    Switch                                         = 7,
    FireLoop                                       = 8,
    EDisplayCharStateMode_MAX                      = 9

};


// Enum  /Script/AClient.EDisplayCharMeshMode
enum class EDisplayCharMeshMode : uint8_t
{
    Top                                            = 0,
    Mid                                            = 1,
    Low                                            = 2,
    Compressed                                     = 3,
    Default                                        = 4,
    EDisplayCharMeshMode_MAX                       = 5

};


// Enum  /Script/AClient.EDisplaySceneMode
enum class EDisplaySceneMode : uint8_t
{
    Lobby                                          = 0,
    WeaponLib                                      = 1,
    EDisplaySceneMode_MAX                          = 2

};


// Enum  /Script/GameplayTasks.ETaskResourceOverlapPolicy
enum class ETaskResourceOverlapPolicy : uint8_t
{
    StartOnTop                                     = 0,
    StartAtEnd                                     = 1,
    ETaskResourceOverlapPolicy_MAX                 = 2

};


// Enum  /Script/AClient.ESporeMonsterState
enum class ESporeMonsterState : uint8_t
{
    None                                           = 0,
    Growth                                         = 1,
    BudState                                       = 2,
    SwellingState                                  = 3,
    Exploding                                      = 4,
    PostExplosion                                  = 5,
    ESporeMonsterState_MAX                         = 6

};


// Enum  /Script/AClient.EGngameDeathRecallEventType
enum class EGngameDeathRecallEventType : uint8_t
{
    KnockDownEnemy                                 = 0,
    KnockedDown                                    = 1,
    KillEnemy                                      = 2,
    Killed                                         = 3,
    ReleaseSkill                                   = 4,
    EGngameDeathRecallEventType_MAX                = 5

};


// Enum  /Script/AClient.ECharacterType
enum class ECharacterType : uint8_t
{
    None                                           = 0,
    Charector                                      = 1,
    AICharector                                    = 2,
    Boss                                           = 3,
    EliteMonster                                   = 4,
    LittleMonster                                  = 5,
    ECharacterType_MAX                             = 6

};


// Enum  /Script/AClient.EGngameDeathRecallDamageSourceType
enum class EGngameDeathRecallDamageSourceType : uint8_t
{
    Other                                          = 0,
    Player                                         = 1,
    Fall                                           = 2,
    Magma                                          = 3,
    PoisonCircle                                   = 4,
    Melee                                          = 5,
    ForbiddenZone                                  = 6,
    PoisonCloud                                    = 7,
    EGngameDeathRecallDamageSourceType_MAX         = 8

};


// Enum  /Script/AClient.ESuperHeroAddExpReason
enum class ESuperHeroAddExpReason : uint8_t
{
    None                                           = 0,
    Passive                                        = 1,
    KillNormalHero                                 = 2,
    KillSuperHero                                  = 3,
    CauseSuperHeroDamage                           = 4,
    ExpActor                                       = 5,
    OpenBin                                        = 6,
    OpenSuppLydrop                                 = 7,
    CauseNormalHeroDamage                          = 8,
    GM                                             = 9,
    FromNormalAI                                   = 10,
    FromSuperAI                                    = 11,
    ESuperHeroAddExpReason_MAX                     = 12

};


// Enum  /Script/AClient.EPathMoveLoopMode
enum class EPathMoveLoopMode : uint8_t
{
    None                                           = 0,
    LoopFromStart                                  = 1,
    FinishTurnBack                                 = 2,
    EPathMoveLoopMode_MAX                          = 3

};


// Enum  /Script/AClient.EFlootShipMoveType
enum class EFlootShipMoveType : uint8_t
{
    None                                           = 0,
    Normal                                         = 1,
    Landing                                        = 2,
    Parking                                        = 3,
    EFlootShipMoveType_MAX                         = 4

};


// Enum  /Script/AClient.EFlootShipPathPointType
enum class EFlootShipPathPointType : uint8_t
{
    None                                           = 0,
    StartPoint                                     = 1,
    EndPoint                                       = 2,
    StopPoint                                      = 3,
    NormalPoint                                    = 4,
    ZipLinePoint                                   = 5,
    EFlootShipPathPointType_MAX                    = 6

};


// Enum  /Script/AClient.EBreakCaptureAreaStatus
enum class EBreakCaptureAreaStatus : uint8_t
{
    None                                           = 0,
    Empty                                          = 1,
    Fighting                                       = 2,
    Converting                                     = 3,
    Capturing                                      = 4,
    FullCaptured                                   = 5,
    EBreakCaptureAreaStatus_MAX                    = 6

};


// Enum  /Script/AClient.EControllableAreaStatus
enum class EControllableAreaStatus : uint8_t
{
    None                                           = 0,
    Free                                           = 1,
    Releasing                                      = 2,
    Fighting                                       = 3,
    Converting                                     = 4,
    Controlling                                    = 5,
    FullControlled                                 = 6,
    EControllableAreaStatus_MAX                    = 7

};


// Enum  /Script/AClient.EDynamicItemType
enum class EDynamicItemType : uint8_t
{
    Unknown                                        = 0,
    Map_resPawn_m                                  = 1,
    FeatdeTector                                   = 2,
    GunRack                                        = 3,
    CureStage                                      = 4,
    Spore                                          = 5,
    Spore2                                         = 6,
    Spore3                                         = 7,
    Spore4                                         = 8,
    Workbench                                      = 9,
    Harvester                                      = 10,
    WinterWarfareBin                               = 11,
    DiamondCollect                                 = 12,
    Rowdy                                          = 13,
    VIPBin                                         = 14,
    ColosseumLauncherConsole                       = 15,
    HalloweenBin                                   = 16,
    ArmExpHarvester                                = 17,
    HeterochromaticSynthesis                       = 18,
    Ornament                                       = 19,
    EDynamicItemType_MAX                           = 20

};


// Enum  /Script/AClient.EGameModePlaneStageType
enum class EGameModePlaneStageType : uint8_t
{
    None                                           = 0,
    Prepare                                        = 1,
    CreatePlane                                    = 2,
    PlayerEnterPlane                               = 3,
    StartFlight                                    = 4,
    EndFlight                                      = 5,
    EGameModePlaneStageType_MAX                    = 6

};


// Enum  /Script/AClient.ESelectLegendStage
enum class ESelectLegendStage : uint8_t
{
    None                                           = 0,
    ShowCurtain                                    = 1,
    ChooseLegend                                   = 2,
    FreezeLegend                                   = 3,
    QuitChooseLegend                               = 4,
    ChooseSkin                                     = 5,
    ShowSkin                                       = 6,
    ShowTeam                                       = 7,
    ShowDefender                                   = 8,
    ShowEnemy                                      = 9,
    AniCutTo                                       = 10,
    FadeOut                                        = 11,
    Repick                                         = 12,
    Loading                                        = 13,
    ESelectLegendStage_MAX                         = 14

};


// Enum  /Script/AClient.ERespawnStatus
enum class ERespawnStatus : uint8_t
{
    None                                           = 0,
    Requesting                                     = 1,
    Preparing                                      = 2,
    Prepared                                       = 3,
    Pulling                                        = 4,
    Timeout                                        = 5,
    Finished                                       = 6,
    ERespawnStatus_MAX                             = 7

};


// Enum  /Script/AClient.EEvacuateBattleItemSource
enum class EEvacuateBattleItemSource : uint8_t
{
    Unknown                                        = 0,
    Self                                           = 1,
    Teammate                                       = 2,
    Drop                                           = 3,
    Enemy                                          = 4,
    EEvacuateBattleItemSource_MAX                  = 5

};


// Enum  /Script/AClient.EEvacuateMethod
enum class EEvacuateMethod : uint8_t
{
    None                                           = 0,
    Normal                                         = 1,
    Windstorm                                      = 2,
    Kill                                           = 3,
    EEvacuateMethod_MAX                            = 4

};


// Enum  /Script/AClient.ERoundResultReason
enum class ERoundResultReason : uint8_t
{
    None                                           = 0,
    ControlArea                                    = 1,
    RemainOneCamp                                  = 2,
    ERoundResultReason_MAX                         = 3

};


// Enum  /Script/AClient.EGamepadKeyType
enum class EGamepadKeyType : uint8_t
{
    eNone                                          = 0,
    eGamepad_LeftX_Press                           = 1,
    eGamepad_LeftX_Release                         = 2,
    eGamepad_LeftX_Axis                            = 3,
    eGamepad_LeftY_Press                           = 4,
    eGamepad_LeftY_Release                         = 5,
    eGamepad_LeftY_Axis                            = 6,
    eGamepad_RightX_Press                          = 7,
    eGamepad_RightX_Release                        = 8,
    eGamepad_RightX_Axis                           = 9,
    eGamepad_RightY_Press                          = 10,
    eGamepad_RightY_Release                        = 11,
    eGamepad_RightY_Axis                           = 12,
    eGamepad_LeftTriggerAxis_Press                 = 13,
    eGamepad_LeftTriggerAxis_Release               = 14,
    eGamepad_LeftTriggerAxis                       = 15,
    eGamepad_RightTriggerAxis_Press                = 16,
    eGamepad_RightTriggerAxis_Release              = 17,
    eGamepad_RightTriggerAxis                      = 18,
    eGamepad_LeftThumbstick_Press                  = 19,
    eGamepad_LeftThumbstick_Release                = 20,
    eGamepad_RightThumbstick_Press                 = 21,
    eGamepad_RightThumbstick_Release               = 22,
    eGamepad_Special_Left_Press                    = 23,
    eGamepad_Special_Left_Release                  = 24,
    eGamepad_Special_Left_X_Press                  = 25,
    eGamepad_Special_Left_X_Release                = 26,
    eGamepad_Special_Left_Y_Press                  = 27,
    eGamepad_Special_Left_Y_Release                = 28,
    eGamepad_Special_Right_Press                   = 29,
    eGamepad_Special_Right_Release                 = 30,
    eGamepad_FaceButton_Bottom_Press               = 31,
    eGamepad_FaceButton_Bottom_Release             = 32,
    eGamepad_FaceButton_Right_Press                = 33,
    eGamepad_FaceButton_Right_Release              = 34,
    eGamepad_FaceButton_Left_Press                 = 35,
    eGamepad_FaceButton_Left_Release               = 36,
    eGamepad_FaceButton_Top_Press                  = 37,
    eGamepad_FaceButton_Top_Release                = 38,
    eGamepad_LeftShoulder_Press                    = 39,
    eGamepad_LeftShoulder_Release                  = 40,
    eGamepad_RightShoulder_Press                   = 41,
    eGamepad_RightShoulder_Release                 = 42,
    eGamepad_LeftTrigger_Press                     = 43,
    eGamepad_LeftTrigger_Release                   = 44,
    eGamepad_RightTrigger_Press                    = 45,
    eGamepad_RightTrigger_Release                  = 46,
    eGamepad_DPad_Up_Press                         = 47,
    eGamepad_DPad_Up_Release                       = 48,
    eGamepad_DPad_Down_Press                       = 49,
    eGamepad_DPad_Down_Release                     = 50,
    eGamepad_DPad_Right_Press                      = 51,
    eGamepad_DPad_Right_Release                    = 52,
    eGamepad_DPad_Left_Press                       = 53,
    eGamepad_DPad_Left_Release                     = 54,
    eGamepad_LeftStick_Up_Press                    = 55,
    eGamepad_LeftStick_Up_Release                  = 56,
    eGamepad_LeftStick_Down_Press                  = 57,
    eGamepad_LeftStick_Down_Release                = 58,
    eGamepad_LeftStick_Right_Press                 = 59,
    eGamepad_LeftStick_Right_Release               = 60,
    eGamepad_LeftStick_Left_Press                  = 61,
    eGamepad_LeftStick_Left_Release                = 62,
    eGamepad_RightStick_Up_Press                   = 63,
    eGamepad_RightStick_Up_Release                 = 64,
    eGamepad_RightStick_Down_Press                 = 65,
    eGamepad_RightStick_Down_Release               = 66,
    eGamepad_RightStick_Right_Press                = 67,
    eGamepad_RightStick_Right_Release              = 68,
    eGamepad_RightStick_Left_Press                 = 69,
    eGamepad_RightStick_Left_Release               = 70,
    eGamepad_CombineRelease                        = 71,
    eGamepad_CombineRelease                        = 72,
    eGamepad_CombineRelease                        = 73,
    eMax                                           = 74,
    EGamepadKeyType_MAX                            = 75

};


// Enum  /Script/AClient.EGamepadUserKeyType
enum class EGamepadUserKeyType : uint8_t
{
    eSpecialLeft                                   = 0,
    eSpecialRight                                  = 1,
    eLT                                            = 2,
    eRT                                            = 3,
    eLB                                            = 4,
    eRB                                            = 5,
    eLeftJoystick                                  = 6,
    eRightJoystick                                 = 7,
    eCrossUp                                       = 8,
    eCrossDown                                     = 9,
    eCrossLeft                                     = 10,
    eCrossRight                                    = 11,
    eY                                             = 12,
    eB                                             = 13,
    eA                                             = 14,
    eX                                             = 15,
    eMax                                           = 16,
    EGamepadUserKeyType_MAX                        = 17

};


// Enum  /Script/AClient.EGamepadType
enum class EGamepadType : uint8_t
{
    eNone                                          = 0,
    eXBox                                          = 1,
    ePS4                                           = 2,
    eMax                                           = 3,
    EGamepadType_MAX                               = 4

};


// Enum  /Script/AClient.EAniType
enum class EAniType : uint8_t
{
    UpIn                                           = 0,
    UpOut                                          = 1,
    DownOut                                        = 2,
    DownIn                                         = 3,
    FadeIn                                         = 4,
    FadeOut                                        = 5,
    Flicker                                        = 6,
    None                                           = 7,
    EAniType_MAX                                   = 8

};


// Enum  /Script/AClient.TTOColosseumStage
enum class TTOColosseumStage : uint8_t
{
    Default                                        = 0,
    Disable                                        = 1,
    Ready                                          = 2,
    Active                                         = 3,
    Settlement                                     = 4,
    CD                                             = 5,
    Max                                            = 6

};


// Enum  /Script/AClient.EBattleResultModeType
enum class EBattleResultModeType : uint8_t
{
    None                                           = 0,
    BR                                             = 1,
    MP                                             = 2,
    EBattleResultModeType_MAX                      = 3

};


// Enum  /Script/AClient.EReadyCurtainType
enum class EReadyCurtainType : uint8_t
{
    None                                           = 0,
    Ready                                          = 1,
    Enter                                          = 2,
    Leave                                          = 3,
    End                                            = 4,
    EReadyCurtainType_MAX                          = 5

};


// Enum  /Script/UMG.EWidgetAnimationEvent
enum class EWidgetAnimationEvent : uint8_t
{
    Started                                        = 0,
    Finished                                       = 1,
    EWidgetAnimationEvent_MAX                      = 2

};


// Enum  /Script/Engine.EInputEvent
enum class EInputEvent : uint8_t
{
    IE_Pressed                                     = 0,
    IE_Released                                    = 1,
    IE_Repeat                                      = 2,
    IE_DoubleClick                                 = 3,
    IE_Axis                                        = 4,
    IE_MAX                                         = 5

};


// Enum  /Script/UMG.EUMGSequencePlayMode
enum class EUMGSequencePlayMode : uint8_t
{
    Forward                                        = 0,
    Reverse                                        = 1,
    PingPong                                       = 2,
    EUMGSequencePlayMode_MAX                       = 3

};


// Enum  /Script/UMG.EWidgetTickFrequency
enum class EWidgetTickFrequency : uint8_t
{
    Never                                          = 0,
    Auto                                           = 1,
    EWidgetTickFrequency_MAX                       = 2

};


// Enum  /Script/AClient.EGamepadActionType
enum class EGamepadActionType : uint8_t
{
    eNone                                          = 0,
    eBPActionType1                                 = 1,
    eBPActionType2                                 = 2,
    eBPActionType3                                 = 3,
    eBPActionType4                                 = 4,
    eBPActionType5                                 = 5,
    eBPActionType6                                 = 6,
    eBPActionType7                                 = 7,
    eBPActionType8                                 = 8,
    eBPActionType9                                 = 9,
    eBPActionType10                                = 10,
    eBPActionType11                                = 11,
    eBPActionType12                                = 12,
    eBPActionType13                                = 13,
    eBPActionType14                                = 14,
    eBPActionType15                                = 15,
    eBPActionType16                                = 16,
    eBPActionType17                                = 17,
    eBPActionType18                                = 18,
    eBPActionType19                                = 19,
    eBPActionType20                                = 20,
    eBPActionType21                                = 21,
    eBPActionType22                                = 22,
    eBPActionType23                                = 23,
    eBPActionType24                                = 24,
    eBPActionType25                                = 25,
    eBPActionType26                                = 26,
    eBPActionType27                                = 27,
    eBPActionType28                                = 28,
    eBPActionType29                                = 29,
    eBPActionType30                                = 30,
    eBPActionType31                                = 31,
    eBPActionType32                                = 32,
    eBPActionType33                                = 33,
    eBPActionType34                                = 34,
    eBPActionType35                                = 35,
    eBPActionType36                                = 36,
    eBPActionType37                                = 37,
    eBPActionType38                                = 38,
    eBPActionType39                                = 39,
    eBPActionType40                                = 40,
    eBPActionType41                                = 41,
    eBPActionType42                                = 42,
    eBPActionType43                                = 43,
    eBPActionType44                                = 44,
    eBPActionType45                                = 45,
    eBPActionType46                                = 46,
    eBPActionType47                                = 47,
    eBPActionType48                                = 48,
    eBPActionType49                                = 49,
    eBPActionType50                                = 50,
    eBPActionType51                                = 51,
    eBPActionType52                                = 52,
    eBPActionType53                                = 53,
    eBPActionType54                                = 54,
    eBPActionType55                                = 55,
    eBPActionType56                                = 56,
    eBPActionType57                                = 57,
    eBPActionType58                                = 58,
    eBPActionType59                                = 59,
    eBPActionType60                                = 60,
    eBPActionType61                                = 61,
    eBPActionType62                                = 62,
    eBPActionType63                                = 63,
    eBPActionType64                                = 64,
    eBPActionType65                                = 65,
    eBPActionType66                                = 66,
    eBPActionType67                                = 67,
    eBPActionType68                                = 68,
    eBPActionType69                                = 69,
    eBPActionType70                                = 70,
    eBPActionType71                                = 71,
    eBPActionType72                                = 72,
    eBPActionType73                                = 73,
    eBPActionType74                                = 74,
    eBPActionType75                                = 75,
    eBPActionType76                                = 76,
    eBPActionType77                                = 77,
    eBPActionType78                                = 78,
    eBPActionType79                                = 79,
    eBPActionType80                                = 80,
    eBPActionType81                                = 81,
    eBPActionType82                                = 82,
    eBPActionType83                                = 83,
    eBPActionType84                                = 84,
    eBPActionType85                                = 85,
    eBPActionType86                                = 86,
    eBPActionType87                                = 87,
    eBPActionType88                                = 88,
    eBPActionType89                                = 89,
    eBPActionType90                                = 90,
    eBPActionType91                                = 91,
    eBPActionType92                                = 92,
    eBPActionType93                                = 93,
    eBPActionType94                                = 94,
    eBPActionType95                                = 95,
    eBPActionType96                                = 96,
    eBPActionType97                                = 97,
    eBPActionType98                                = 98,
    eBPActionType99                                = 99,
    eBPActionType100                               = 100,
    eOpenDoor                                      = 101,
    eCloseDoor                                     = 102,
    eBin                                           = 103,
    eFesecretDoor                                  = 104,
    eCancelFesecretDoor                            = 105,
    eGravityElevator                               = 106,
    eCancelGravityElevator                         = 107,
    eExtract                                       = 108,
    eFeatustore                                    = 109,
    eFinish                                        = 110,
    eFinishCancel                                  = 111,
    eRescue                                        = 112,
    eRescueCancel                                  = 113,
    eRescueSelf                                    = 114,
    eEq140_eq140_eq_OnOff                          = 115,
    eRespawnTeamMate                               = 116,
    eRespawnTeamMateCancel                         = 117,
    eFeatdeTectorUsed                              = 118,
    eFeatdeTectorCancel                            = 119,
    eHero07_DirtyBombRecycle                       = 120,
    eRideZipline                                   = 121,
    eDownZipline                                   = 122,
    eOpenSuppLydrop_                               = 123,
    eStageSwitch                                   = 124,
    eHero08StageSwitch                             = 125,
    eMoveForward                                   = 126,
    eMoveRight                                     = 127,
    eTurn                                          = 128,
    eTitl                                          = 129,
    eRun                                           = 130,
    eAutoRun                                       = 131,
    eJumpPressed                                   = 132,
    eJumpReleased                                  = 133,
    eCrouchPressed                                 = 134,
    eCrouchReleased                                = 135,
    eOpenMiniMap                                   = 136,
    eOpenBackpack                                  = 137,
    eCloseBackpack                                 = 138,
    eActiveColosseumLauncherConsole                = 139,
    eColosseumJumpConsole                          = 140,
    eMouseMoveHorizontal                           = 141,
    eMouseMoveVertical                             = 142,
    eMouseMoveVerticalReverse                      = 143,
    eMouseDown                                     = 144,
    eMouseUp                                       = 145,
    ePressedPing                                   = 146,
    eReleasedPing                                  = 147,
    eHorizontalMovePing                            = 148,
    eVerticalMovePing                              = 149,
    eTestForceFeedback                             = 150,
    ePressedMedical                                = 151,
    eReleasedMedical                               = 152,
    ePressedProjectile                             = 153,
    eReleasedProjectile                            = 154,
    eHorizontalMoveTurnTable                       = 155,
    eVerticalMoveTurnTable                         = 156,
    ePressedPickUpListUp                           = 157,
    ePressedPickUpListDown                         = 158,
    ePressedPickUpListLeft                         = 159,
    ePressedPickUpListRight                        = 160,
    ePressedPickUp                                 = 161,
    ePressedPickUpPing                             = 162,
    ePressedPickUpSwitch                           = 163,
    ePressedSwitchWeapon                           = 164,
    ePressedPutOutWeapon                           = 165,
    ePressedSwitchWeaponBtn                        = 166,
    eReleasedSwitchWeaponBtn                       = 167,
    ePressedSwitchFireMode                         = 168,
    ePressedWeaponReloadBtn                        = 169,
    ePressedTacticsSkillBtn                        = 170,
    eReleasedTacticsSkillBtn                       = 171,
    eClickedTacticsSkillCancel                     = 172,
    eClickedTacticsSkillUndo                       = 173,
    ePressedUltimateSkillBtn                       = 174,
    eReleasedUltimateSkillBtn                      = 175,
    eClickedUltimateSkillCancel                    = 176,
    eClickedUltimateSkillUndo                      = 177,
    eClickedSkillAncillaryBtn                      = 178,
    eClickedParachuteSkillBtn                      = 179,
    ePressedMeleeAttackBtn                         = 180,
    eReleasedMeleeAttackBtn                        = 181,
    ePressedEmojiBtn                               = 182,
    eReleasedEmojiBtn                              = 183,
    ePressSpecialForBackpackAndSettingUI           = 184,
    eReleaseSpecialForBackpackAndSettingUI         = 185,
    eOpenHr13Blackmark                             = 186,
    eFoldHr13Blackmark                             = 187,
    eHero08ConnectDecoy                            = 188,
    eHero08SendDecoyOnParachute                    = 189,
    eHero02GunShield                               = 190,
    ePressedDroneFlyUp                             = 191,
    eReleasedDroneFlyUp                            = 192,
    ePressedDroneFlyDown                           = 193,
    eReleasedDroneFlyDown                          = 194,
    eDroneCallBack                                 = 195,
    eNotifySquadAround                             = 196,
    eHero11TaticsSkillTurnTableHorizontalMove      = 197,
    eHero11TaticsSkillTurnTableVerticalMove        = 198,
    eDropSi101_si_                                 = 199,
    ePlantSi101_si_                                = 200,
    eCancelPlantSi101_si_                          = 201,
    eDefuseSi101_si_                               = 202,
    eCancelDefuseSi101_si_                         = 203,
    eHero11DroneBeacon                             = 204,
    eHero11DroneRecover                            = 205,
    eHero11DroneBin                                = 206,
    eHero11DroneOpenDoor                           = 207,
    eHero11DroneCloseDoor                          = 208,
    eHero11DroneSupplydrop_                        = 209,
    eHero11DroneRepawn                             = 210,
    eHero11DroneLaunchRocketPressed                = 211,
    eHero11DroneLaunchRocketReleased               = 212,
    eHero03ReviveTeamateCancelPressed              = 213,
    eFeatdeTectorOpenMapPressed                    = 214,
    eH19TacticalSkillAuxiliaryPressed              = 215,
    eH19TacticalSkillAuxiliaryReleased             = 216,
    eH19TacticalSkillHorizontalMove                = 217,
    eH19DataKnife                                  = 218,
    eDamageLock                                    = 219,
    ePressBackpackUI                               = 220,
    eReleaseBackpackUI                             = 221,
    ePressSettingUI                                = 222,
    eReleaseSettingUI                              = 223,
    ePressTransferTeamLeaderToPlayerOne            = 224,
    ePressTransferTeamLeaderToPlayerTwo            = 225,
    eReleaseTransferTeamLeaderToPlayerOne          = 226,
    eReleaseTransferTeamLeaderToPlayerTwo          = 227,
    eJoinHero17Ultimate                            = 228,
    eLeaveHero17Ultimate                           = 229,
    eAutoJoinHero17Ultimate                        = 230,
    eEmptyAction                                   = 231,
    eEmptyAction0                                  = 232,
    eEmptyAction1                                  = 233,
    eEmptyAction2                                  = 234,
    eEmptyAction3                                  = 235,
    eEmptyAction4                                  = 236,
    eEmptyAction5                                  = 237,
    eEmptyAction6                                  = 238,
    eEmptyAction7                                  = 239,
    eEmptyAction8                                  = 240,
    eEmptyAction9                                  = 241,
    eEmptyAction10                                 = 242,
    eEmptyAction11                                 = 243,
    eEmptyAction12                                 = 244,
    eEmptyAction13                                 = 245,
    eEmptyAction14                                 = 246,
    eEmptyAction15                                 = 247,
    eEmptyAction16                                 = 248,
    eEmptyAction17                                 = 249,
    eEmptyAction18                                 = 250,
    eEmptyAction19                                 = 251,
    eMax                                           = 252,
    EGamepadActionType_MAX                         = 253

};


// Enum  /Script/AClient.EForbiddenFunctionType
enum class EForbiddenFunctionType : uint8_t
{
    None                                           = 0,
    Move                                           = 1,
    View                                           = 2,
    MoveAndView                                    = 3,
    EForbiddenFunctionType_MAX                     = 4

};


// Enum  /Script/AClient.EBacktraceState
enum class EBacktraceState : uint8_t
{
    None                                           = 0,
    PreActive                                      = 1,
    Active                                         = 2,
    Deactive                                       = 3,
    Closed                                         = 4,
    EBacktraceState_MAX                            = 5

};


// Enum  /Script/AClient.ETrackingPOIPriority
enum class ETrackingPOIPriority : uint8_t
{
    NONE                                           = 0,
    VERY_LOW                                       = 1,
    LOW                                            = 2,
    NORMAL                                         = 3,
    HIGH                                           = 4,
    VERY_HIGH                                      = 5,
    MAX                                            = 6

};


// Enum  /Script/AClient.ETrackingVisionPOITypes
enum class ETrackingVisionPOITypes : uint8_t
{
    DROPPOD                                        = 0,
    TITANFALL                                      = 1,
    TITAN_EMBARK                                   = 2,
    TITAN_DISEMBARK                                = 3,
    DOOR_USE                                       = 4,
    DOOR_DESTROYED                                 = 5,
    PLAYER_CLASS_DEPLOYABLE                        = 6,
    PLAYER_DEATH                                   = 7,
    PLAYER_KILLER                                  = 8,
    PLAYER_HEAL                                    = 9,
    PLAYER_RELOAD                                  = 10,
    PLAYER_STARTBLEEDOUT                           = 11,
    PLAYER_TOOK_DAMAGE                             = 12,
    PLAYER_FIRE_WEAPON_BULLET                      = 13,
    PLAYER_FIRE_WEAPON_GRENADE                     = 14,
    PLAYER_OPENDROPPOD                             = 15,
    PLAYER_LOOTBIN_USED                            = 16,
    PLAYER_RECOVERBANNER_USED                      = 17,
    PLAYER_TRAVERSAL_ZIPLINE_START                 = 18,
    PLAYER_TRAVERSAL_ZIPLINE_STOP                  = 19,
    PLAYER_TRAVERSAL_FOOTPRINT                     = 20,
    PLAYER_TRAVERSAL_SLIDE                         = 21,
    PLAYER_TRAVERSAL_CLIMB                         = 22,
    PLAYER_TRAVERSAL_MANTLE                        = 23,
    PLAYER_TRAVERSAL_JUMP_DOWN_START               = 24,
    PLAYER_TRAVERSAL_JUMP_DOWN_STOP                = 25,
    PLAYER_TRAVERSAL_LAUNCH_PAD                    = 26,
    PLAYER_ABILITIES_PHASE_DASH_START              = 27,
    PLAYER_ABILITIES_PHASE_DASH_STOP               = 28,
    PLAYER_ABILITIES_SMOKE                         = 29,
    PLAYER_ABILITIES_GAS                           = 30,
    PLAYER_LOOT_PICKUP                             = 31,
    PLAYER_LOOT_PICKUP_AMMO                        = 32,
    PLAYER_LOOT_PICKUP_ARMOR                       = 33,
    PLAYER_LOOT_PICKUP_ATTACHMENT                  = 34,
    PLAYER_LOOT_PICKUP_WEAPON                      = 35,
    PLAYER_LOOT_PICKUP_GRENADE                     = 36,
    PLAYER_LOOT_PICKUP_JUMPKIT                     = 37,
    PLAYER_LOOT_PICKUP_HEALTH                      = 38,
    PLAYER_LOOT_PICKUP_HELMET                      = 39,
    PLAYER_LOOT_PICKUP_BACKPACK                    = 40,
    PLAYER_LOOT_PICKUP_BANDOLIER                   = 41,
    PLAYER_LOOT_PICKUP_INCAPSHIELD                 = 42,
    PLAYER_LOOT_PICKUP_EQ140_EQ140_EQ_             = 43,
    PLAYER_LOOT_PICKUP_DATAKNIFE                   = 44,
    PLAYER_LOOT_EXCHANGE_ARMOR                     = 45,
    PLAYER_LOOT_EXCHANGE_WEAPON                    = 46,
    PLAYER_LOOT_EXCHANGE_JUMPKIT                   = 47,
    PLAYER_LOOT_EXCHANGE_HELMET                    = 48,
    PLAYER_LOOT_EXCHANGE_BACKPACK                  = 49,
    PLAYER_LOOT_EXCHANGE_BANDOLIER                 = 50,
    PLAYER_LOOT_EXCHANGE_INCAPSHIELD               = 51,
    PLAYER_LOOT_EXCHANGE_EQ140_EQ140_EQ_           = 52,
    PLAYER_LOOT_EXCHANGE_AMMO                      = 53,
    PLAYER_LOOT_EXCHANGE_ATTACHMENT                = 54,
    PLAYER_LOOT_EXCHANGE_GRENADE                   = 55,
    PLAYER_LOOT_EXCHANGE_HEALTH                    = 56,
    PLAYER_LOOT_DROP                               = 57,
    PLAYER_LOOT_DROP_AMMO                          = 58,
    PLAYER_LOOT_DROP_ARMOR                         = 59,
    PLAYER_LOOT_DROP_ATTACHMENT                    = 60,
    PLAYER_LOOT_DROP_WEAPON                        = 61,
    PLAYER_LOOT_DROP_GRENADE                       = 62,
    PLAYER_LOOT_DROP_JUMPKIT                       = 63,
    PLAYER_LOOT_DROP_HEALTH                        = 64,
    PLAYER_LOOT_DROP_HELMET                        = 65,
    PLAYER_LOOT_DROP_BACKPACK                      = 66,
    PLAYER_LOOT_DROP_BANDOLIER                     = 67,
    PLAYER_LOOT_DROP_INCAPSHIELD                   = 68,
    PLAYER_LOOT_DROP_EQ140_EQ140_EQ_               = 69,
    PLAYER_LOOT_DROP_DATAKNIFE                     = 70,
    PLAYER_ABILITY_DEPLOYABLE_MEDIC                = 71,
    PLAYER_ABILITY_JUMP_PAD                        = 72,
    PLAYER_ABILITY_BUBBLE_BUNKER                   = 73,
    PLAYER_ABILITY_TESLA_TRAP                      = 74,
    PLAYER_ABILITY_TROPHY_SYSTEM                   = 75,
    PLAYER_ABILITY_DEBRIS_TRAP                     = 76,
    PLAYER_ABILITY_PHASE_ENTER_GATE                = 77,
    PLAYER_ABILITY_PHASE_EXIT_GATE                 = 78,
    PLAYER_ABILITY_PHASE_GATE                      = 79,
    PLAYER_ABILITY_MOTION_SENSOR                   = 80,
    PLAYER_ABILITY_USE_DEATH_TOTEM                 = 81,
    PLAYER_ABILITY_THEDOME_HERO02_H_               = 82,
    PLAYER_ABILITY_BLACKMARKET_HR13                = 83,
    PLAYER_ABILITY_BLACKMARKET_HR13_DESTROYED      = 84,
    PLAYER_ABILITY_BRACELETSTART_HR13              = 85,
    PLAYER_ABILITY_BRACELETSTOP_HR13               = 86,
    PLAYER_ABILITY_ARC_BOLT_DEPLOY                 = 87,
    PLAYER_ABILITY_BLACK_HOLE                      = 88,
    PLAYER_ABILITY_BLACK_HOLE_DESTROYED            = 89,
    PLAYER_ABILITY_GRAVITY_LIFT                    = 90,
    PLAYER_ABILITY_GRAVITY_LIFT_DESTROYED          = 91,
    PLAYER_ABILITY_MISSILE_LAUNCH                  = 92,
    PLAYER_ABILITY_HERO17ULTIMATE_LAUNCH           = 93,
    PLAYER_ABILITY_HERO17ULTIMATE_PARACHUTELANDING = 94,
    PLAYER_ABILITY_HERO53_TACTICAL                 = 95,
    _count                                         = 96,
    ETrackingVisionPOITypes_MAX                    = 97

};


// Enum  /Script/AClient.EUAESkillEvent
enum class EUAESkillEvent : uint8_t
{
    UAESkillEvent_None                             = 0,
    GrenadeModeChange                              = 1,
    GrenadePinPull                                 = 2,
    ThrowGrenade                                   = 3,
    GrenadeTimeOut                                 = 4,
    SkillInterrupt                                 = 5,
    SkillPlayerDieInterrupt                        = 6,
    PickItem                                       = 7,
    MovementActive                                 = 8,
    MovementInactive                               = 9,
    MovementBounce                                 = 10,
    MovementStop                                   = 11,
    MovementCrouch                                 = 12,
    AutoSPrintStart                                = 13,
    RemoveArmor                                    = 14,
    SkillPawnStateLeft                             = 15,
    GrenadeThrowCancel                             = 16,
    DestroyPredictActor                            = 17,
    GrenadeHold                                    = 18,
    GrenadeLand                                    = 19,
    GrenadeDeploy                                  = 20,
    GrenadeReady                                   = 21,
    GrenadeActivate                                = 22,
    GrenadeDestroy                                 = 23,
    Hero42_BraidStart                              = 24,
    Hero42_BraidFinish                             = 25,
    ShowPredictionLine                             = 26,
    ClearPredictionLine                            = 27,
    StartAimStatus                                 = 28,
    EndAimStatus                                   = 29,
    Hero17_MissileAllLaunched                      = 30,
    SkillFinished                                  = 31,
    EUAESkillEvent_MAX                             = 32

};


// Enum  /Script/AClient.EH19ArcBoltState
enum class EH19ArcBoltState : uint8_t
{
    None                                           = 0,
    Flying                                         = 1,
    Deploy                                         = 2,
    Active                                         = 3,
    DeActive                                       = 4,
    EH19ArcBoltState_MAX                           = 5

};


// Enum  /Script/AClient.EMiniMapDynamicType
enum class EMiniMapDynamicType : uint8_t
{
    None                                           = 0,
    Hero07_DirtyBomb                               = 1,
    Hero11Drone                                    = 2,
    Hero10_InterceptionPylon                       = 3,
    Hero10_TeslaNode                               = 4,
    Hero10_TeslaWire                               = 5,
    DeathTotem                                     = 6,
    Hr13BlackMarket                                = 7,
    EnemyArea                                      = 8,
    H19Box                                         = 9,
    DeadLoc                                        = 10,
    TombBox                                        = 11,
    SuperHero                                      = 12,
    HeroRobGoldPickupedCurrency                    = 13,
    HeterochromaticLens                            = 14,
    HeterochromaticSummoner                        = 15,
    EvacuatePoint                                  = 16,
    Hero12DeathMark                                = 17,
    MAX                                            = 18

};


// Enum  /Script/AClient.ECharacterCameraMode
enum class ECharacterCameraMode : uint8_t
{
    NONE                                           = 0,
    TPP                                            = 1,
    FPP                                            = 2,
    PARACHUTE                                      = 3,
    ECharacterCameraMode_MAX                       = 4

};


// Enum  /Script/AClient.EUAESkillUIEvent
enum class EUAESkillUIEvent : uint8_t
{
    UAESkillUIEvent_None                           = 0,
    NotifyHandleUIPopFireBtnStatus_Deprecated      = 1,
    NotifyGrapplingHookAimSightState_Deprecated    = 2,
    NotifyHero02_h_ShieldOpened_Deprecated         = 3,
    NotifyTransmitFeatdeTector_Deprecated          = 4,
    NotifyDirtyBombPickerUpUIShow_Deprecated       = 5,
    NotifyDirtyBombPickerUpUIHide_Deprecated       = 6,
    NotifyGrapplinghookHideAimSight_Deprecated     = 7,
    EUAESkillUIEvent_MAX                           = 8

};


// Enum  /Script/AClient.EGnyxPostSignificanceType
enum class EGnyxPostSignificanceType : uint8_t
{
    None                                           = 0,
    Concurrent                                     = 1,
    Sequential                                     = 2,
    EGnyxPostSignificanceType_MAX                  = 3

};


// Enum  /Script/AClient.EGnyxSignificanceByType
enum class EGnyxSignificanceByType : uint8_t
{
    Distance                                       = 0,
    Distance2D                                     = 1,
    ScreenSize                                     = 2,
    Custom                                         = 3,
    EGnyxSignificanceByType_MAX                    = 4

};


// Enum  /Script/AClient.ESkillActorType
enum class ESkillActorType : uint8_t
{
    None                                           = 0,
    Hero06_h__SmokeGrenade                         = 1,
    Hero06_h__SmokeBomb                            = 2,
    Hero06_h__UltimateGrenade                      = 3,
    Hero06_h__UltimateBomb                         = 4,
    Hero07__DirtyBomb                              = 5,
    Hero07__GasGrenade                             = 6,
    Hero11_Drone                                   = 7,
    Hero11_Drone_RocketBomb                        = 8,
    Hero02_h__DomeGrenade                          = 9,
    Hero02_h__DomeShield                           = 10,
    Hero02_h__GunShield                            = 11,
    Hero02_h__DefenseGrenade                       = 12,
    Hero02_h__DefenseBomb                          = 13,
    Hero03_h_HealingDrone                          = 14,
    Hero03_h_SuppLydrop_                           = 15,
    Hero03_h_ProtectiveShield                      = 16,
    Hero03_HealingShield                           = 17,
    Hero09_JumpPad                                 = 18,
    Hero09_Stim                                    = 19,
    Hero09_ProjectilePad                           = 20,
    Hero09_PadJumpEffect                           = 21,
    Hero08_InvisibleEffect                         = 22,
    Hero04_he__Zipline                             = 23,
    Hero04_he__GrapplingHook                       = 24,
    Hero10__TeslaNode                              = 25,
    Hero10__TeslaWire                              = 26,
    Hero10__InterceptionPylon                      = 27,
    Hero05_VoidDoor                                = 28,
    Hero05_InVoid                                  = 29,
    Hero12_h_DeathTotem                            = 30,
    Hero12_h_SilencerSpawner                       = 31,
    Hero15__GravityLift                            = 32,
    Hero15__BlackHole                              = 33,
    Hr13_Market                                    = 34,
    Hr13_Bracelet                                  = 35,
    Hr13_FlyActor                                  = 36,
    H19_VoidDoor                                   = 37,
    H19_ArcBolt                                    = 38,
    Hero17UltimateActor                            = 39,
    MK_LittleGoldenCudgel                          = 40,
    ML_BigGoldenCudgel                             = 41,
    Hero52GuardianRange                            = 42,
    Hero52UltimateActor                            = 43,
    Hero56_MissleGenerator                         = 44,
    Consumable_APM                                 = 45,
    Consumable_Mi120_m                             = 46,
    Consumable_Battery                             = 47,
    Consumable_BatteryBig                          = 48,
    Consumable_Mi100_mi10_                         = 49,
    Consumable_Md111_                              = 50,
    Consumable_Md120                               = 51,
    Consumable_Md110_m                             = 52,
    Consumable_Mi110_mi110_mi_                     = 53,
    Hero54_TacticalItem                            = 54,
    InvalidType                                    = 55,
    ESkillActorType_MAX                            = 56

};


// Enum  /Script/Engine.ECollisionResponse
enum class ECollisionResponse : uint8_t
{
    ECR_Ignore                                     = 0,
    ECR_Overlap                                    = 1,
    ECR_Block                                      = 2,
    ECR_MAX                                        = 3

};


// Enum  /Script/AClient.ECommonActionBtnType
enum class ECommonActionBtnType : uint8_t
{
    BinBox                                         = 0,
    OpenDoor                                       = 1,
    CloseDoor                                      = 2,
    FesecretDoor                                   = 3,
    SuppLydrop_                                    = 4,
    FloatvcRide                                    = 5,
    FloatvcDrive                                   = 6,
    TrainCtrl                                      = 7,
    RecoverBanner                                  = 8,
    Climb                                          = 9,
    SkillItemPick                                  = 10,
    DamageLock                                     = 11,
    FeatdeTector                                   = 12,
    BigMap                                         = 13,
    Featustore                                     = 14,
    Extract                                        = 15,
    DroneFeatdeTector                              = 16,
    DroneOpenBin                                   = 17,
    DroneOpenDoor                                  = 18,
    DroneCloseDoor                                 = 19,
    DroneOpenFesecretDoor                          = 20,
    DroneSupplyDrop                                = 21,
    DroneRespawnTeammate                           = 22,
    Hero52UltimateRange                            = 23,
    Finisher                                       = 24,
    ReplenishmentMachine                           = 25,
    ParachuteForceLaunch                           = 26,
    ParachuteForceExit                             = 27,
    BinBottomBox                                   = 28,
    TTOPirateShipOpen                              = 29,
    Bunker                                         = 30,
    Hero10_SelfRescue                              = 31,
    Hero10_NodePickup                              = 32,
    Hero13_TeleportToUltimateLocation              = 33,
    GoldMode_OpenRedEnvelope                       = 34,
    GoldMode_ATMStore                              = 35,
    GoldMode_ATMSteal                              = 36,
    HeterochromaticTreasureChest                   = 37,
    Hero12DeathMark                                = 38,
    FloatvcGetOff                                  = 39,
    PetInteractiveAction                           = 40,
    HomeTreasure                                   = 41,
    PetInteractiveActionBanState                   = 42,
    Max                                            = 43

};


// Enum  /Script/AClient.EPingButtonClickType
enum class EPingButtonClickType : uint8_t
{
    Down                                           = 0,
    Up                                             = 1,
    DragEnd                                        = 2,
    EPingButtonClickType_MAX                       = 3

};


// Enum  /Script/AClient.eInGameStageType
enum class eInGameStageType : uint8_t
{
    eReady                                         = 0,
    eRunning                                       = 1,
    eEnd                                           = 2,
    eMax                                           = 3,
    eInGameStageType_MAX                           = 4

};


// Enum  /Script/AClient.EMiniMapStaticType
enum class EMiniMapStaticType : uint8_t
{
    FesecretDoor                                   = 0,
    FeatdeTector                                   = 1,
    Map_resPawn_m                                  = 2,
    CureStage                                      = 3,
    Harvester3V3                                   = 4,
    LootBinCreeps                                  = 5,
    TownTakeOver                                   = 6,
    BinActor                                       = 7,
    Harvester                                      = 8,
    Featustore                                     = 9,
    AirDropFeatustore                              = 10,
    IceBinActor                                    = 11,
    GhostBinActor                                  = 12,
    SporeBinActor                                  = 13,
    BombSite                                       = 14,
    ColosseumActor                                 = 15,
    NewHarvester                                   = 16,
    GravityElevator                                = 17,
    FatPoiCircle                                   = 18,
    AirDrop                                        = 19,
    RobGoldRedEnvelope                             = 20,
    RobGoldATM                                     = 21,
    HeterochromaticTreasureChest                   = 22,
    CowDefenseModeCore                             = 23,
    AirshipSpawnCountdown                          = 24,
    EliteMonsterSpawnCountdown                     = 25,
    EvacuatePoint                                  = 26,
    WindstormEvacuatePoint                         = 27,
    SmallMonsterCountdown                          = 28,
    KillEvacuatePoint                              = 29,
    Hero12DeathMark                                = 30,
    HomeIslandCountdown                            = 31,
    BigGoldenCountdown                             = 32,
    MAX                                            = 33

};


// Enum  /Script/AClient.EMiniMapEnermySubType
enum class EMiniMapEnermySubType : uint8_t
{
    Normal                                         = 0,
    Simple                                         = 1,
    SuperHero                                      = 2,
    EMiniMapEnermySubType_MAX                      = 3

};


// Enum  /Script/AClient.EMiniMapPlayerState
enum class EMiniMapPlayerState : uint8_t
{
    Normal                                         = 0,
    Dying                                          = 1,
    Respawning                                     = 2,
    Dead                                           = 3,
    Dispear                                        = 4,
    EMiniMapPlayerState_MAX                        = 5

};


// Enum  /Script/AClient.EMiniMapPlayerType
enum class EMiniMapPlayerType : uint8_t
{
    Teammate                                       = 0,
    Enermy                                         = 1,
    PureSpectator                                  = 2,
    EMiniMapPlayerType_MAX                         = 3

};


// Enum  /Script/AClient.EOpeningProgressType
enum class EOpeningProgressType : uint8_t
{
    None                                           = 0,
    FesecretDoor                                   = 1,
    SupplyDrop                                     = 2,
    GoldMode_StealATMCurrency                      = 3,
    Hero13_TeleportPre                             = 4,
    SupplyBin                                      = 5,
    EOpeningProgressType_MAX                       = 6

};


// Enum  /Script/AClient.ERaceColorType
enum class ERaceColorType : uint8_t
{
    Golden                                         = 0,
    Blue                                           = 1,
    White                                          = 2,
    Max                                            = 3

};


// Enum  /Script/AClient.EPlayerRespawnState
enum class EPlayerRespawnState : uint8_t
{
    None                                           = 0,
    CanPick                                        = 1,
    Picked                                         = 2,
    Respawning                                     = 3,
    RespawnFail                                    = 4,
    EPlayerRespawnState_MAX                        = 5

};


// Enum  /Script/AClient.EPlayerBannerState
enum class EPlayerBannerState : uint8_t
{
    Normal                                         = 0,
    Dropped                                        = 1,
    BePicked                                       = 2,
    InUsing                                        = 3,
    Invalid                                        = 4,
    EPlayerBannerState_MAX                         = 5

};


// Enum  /Script/AClient.ERespawnTeammateEndReason
enum class ERespawnTeammateEndReason : uint8_t
{
    Normal                                         = 0,
    Break                                          = 1,
    ERespawnTeammateEndReason_MAX                  = 2

};


// Enum  /Script/AClient.EVehcileSeatChangeType
enum class EVehcileSeatChangeType : uint8_t
{
    GetOn                                          = 0,
    GetOff                                         = 1,
    ChangeSeat                                     = 2,
    EVehcileSeatChangeType_MAX                     = 3

};


// Enum  /Script/AClient.EPingButtonVisualType
enum class EPingButtonVisualType : uint8_t
{
    Ping                                           = 1,
    Delete                                         = 2,
    Ding                                           = 3,
    CancelDing                                     = 4,
    CantDing                                       = 5,
    OK                                             = 6,
    HadOK                                          = 7,
    CantDelete                                     = 8,
    EmojiOK                                        = 9,
    FirstAid                                       = 10,
    Respawn                                        = 11,
    JumpPing                                       = 12,
    DingEnemy                                      = 13,
    DingGrould                                     = 14,
    Survive                                        = 15,
    Enemy                                          = 16,
    Activity                                       = 17,
    Watching                                       = 18,
    Looting                                        = 19,
    Defending                                      = 20,
    Attacking                                      = 21,
    EPingButtonVisualType_MAX                      = 22

};


// Enum  /Script/UMG.EDragPivot
enum class EDragPivot : uint8_t
{
    MouseDown                                      = 0,
    TopLeft                                        = 1,
    TopCenter                                      = 2,
    TopRight                                       = 3,
    CenterLeft                                     = 4,
    CenterCenter                                   = 5,
    CenterRight                                    = 6,
    BottomLeft                                     = 7,
    BottomCenter                                   = 8,
    BottomRight                                    = 9,
    EDragPivot_MAX                                 = 10

};


// Enum  /Script/AClient.EChargePhase
enum class EChargePhase : uint8_t
{
    None                                           = 0,
    CantCharge                                     = 1,
    CanCharge                                      = 2,
    ChargeBegin                                    = 3,
    Charging                                       = 4,
    ChargeEnd                                      = 5,
    EChargePhase_MAX                               = 6

};


// Enum  /Script/AClient.EBlackMarketGroupType
enum class EBlackMarketGroupType : uint8_t
{
    EBlackMarketGroupType_None                     = 0,
    EBlackMarketGroupType_Weapon                   = 1,
    EBlackMarketGroupType_Ammunition               = 2,
    EBlackMarketGroupType_Attachment               = 3,
    EBlackMarketGroupType_Special                  = 4,
    EBlackMarketGroupType_Consume                  = 5,
    EBlackMarketGroupType_Equipment                = 6,
    EBlackMarketGroupType_Other                    = 7,
    EBlackMarketGroupType_Recommend                = 8,
    EBlackMarketGroupType_MAX                      = 9

};


// Enum  /Script/AClient.EWeaponFrameEffectEvent
enum class EWeaponFrameEffectEvent : uint8_t
{
    None                                           = 0,
    WFEE_Default                                   = 1,
    WFEE_Fire                                      = 2,
    WFEE_Fire_WithCharge                           = 3,
    WFEE_ADSOn                                     = 4,
    WFEE_ADSOff                                    = 5,
    WFEE_EquipWeapon                               = 6,
    WFEE_EquipChargedWeapon                        = 7,
    WFEE_PostEquipWeapon                           = 8,
    WFEE_PostEquipChargedWeapon                    = 9,
    WFEE_UnEquipWeapon                             = 10,
    WFEE_PickUp                                    = 11,
    WFEE_Drop                                      = 12,
    WFEE_Hit                                       = 13,
    WFEE_BulletTrail                               = 14,
    WFEE_Charge                                    = 15,
    WFEE_ChargeEnd                                 = 16,
    WFEE_HeatDecrease                              = 17,
    WFEE_HeatFull                                  = 18,
    WFEE_HeatNotFull                               = 19,
    WFEE_HeatChange                                = 20,
    WFEE_ReloadStart                               = 21,
    WFEE_ReloadEnd                                 = 22,
    WFEE_AimChargeLevelChange                      = 23,
    WFEE_CumulativeKillChange                      = 24,
    WFEE_LensShoot                                 = 25,
    WFEE_ChargeState_NotCharge                     = 26,
    WFEE_ChargeState_BeginCharge                   = 27,
    WFEE_ChargeState_Charging                      = 28,
    WFEE_ChargeState_HasCharged                    = 29,
    WFEE_Charge_EquipTimeout                       = 30,
    WFEE_Charge_BeInterrupted                      = 31,
    WFEE_Charge_FireEmpty                          = 32,
    WFEE_Charge_BackEmptyThenEquip                 = 33,
    WFEE_Charge_FireEmpty3P                        = 34,
    WFEE_Charge_EquipTimeout3P                     = 35,
    WFEE_Charge_IgniteEnemy                        = 36,
    WFEE_AR304_RefreshEnergy                       = 37,
    WFEE_AIMSCALE                                  = 38,
    EWeaponFrameEffectEvent_MAX                    = 39

};


// Enum  /Script/AClient.EClampVaultNavLinkProxyType
enum class EClampVaultNavLinkProxyType : uint8_t
{
    JumpOrClimb                                    = 0,
    Zipline                                        = 1,
    EClampVaultNavLinkProxyType_MAX                = 2

};


// Enum  /Script/AClient.EPawnActionFilterType
enum class EPawnActionFilterType : uint8_t
{
    eTurn                                          = 0,
    eAutoRun                                       = 1,
    eEnableDamage                                  = 2,
    eEnableCastTechnicalSkill                      = 3,
    eEnableCastUltimateSkill                       = 4,
    eEnableCastPassiveSkill                        = 5,
    eMax                                           = 64,
    EPawnActionFilterType_MAX                      = 65

};


// Enum  /Script/AClient.EFollowType
enum class EFollowType : uint8_t
{
    FollowPlayerControllerState                    = 0,
    FollowParachute                                = 1,
    EFollowType_MAX                                = 2

};


// Enum  /Script/AClient.EAdvanceTrainingTLogType
enum class EAdvanceTrainingTLogType : uint8_t
{
    DoorTutorial                                   = 0,
    ClimbingTutorial                               = 1,
    WeaponTutorial                                 = 2,
    EAdvanceTrainingTLogType_MAX                   = 3

};


// Enum  /Script/AClient.EAdvancedTrainType
enum class EAdvancedTrainType : uint8_t
{
    CLIMBING                                       = 1,
    DOOR                                           = 2,
    WEAPON                                         = 3,
    EAdvancedTrainType_MAX                         = 4

};


// Enum  /Script/AClient.EAIABTestValueType
enum class EAIABTestValueType : uint8_t
{
    None                                           = 0,
    A                                              = 1,
    B                                              = 2,
    EAIABTestValueType_MAX                         = 3

};


// Enum  /Script/AClient.EAIABTestType
enum class EAIABTestType : uint8_t
{
    BRAIBehavior                                   = 2,
    NewBRAISpawnRule                               = 13,
    AIItemGenerate                                 = 29,
    EAIABTestType_MAX                              = 30

};


// Enum  /Script/AClient.EAIGetItemType
enum class EAIGetItemType : uint8_t
{
    None                                           = 0,
    BinActor                                       = 1,
    SuppLydrop_                                    = 2,
    TombBox                                        = 3,
    Item                                           = 4,
    PickObject                                     = 5,
    EAIGetItemType_MAX                             = 6

};


// Enum  /Script/AClient.EShadowHero08TutorialType
enum class EShadowHero08TutorialType : uint8_t
{
    None                                           = 0,
    PoisonRing                                     = 1,
    HotBalloon                                     = 2,
    ZipLine                                        = 3,
    Climb                                          = 4,
    Slide                                          = 5,
    Aid                                            = 6,
    WinCondition                                   = 7,
    Max                                            = 8

};


// Enum  /Script/AClient.EAITLogKillType
enum class EAITLogKillType : uint8_t
{
    Target                                         = 1,
    TargetTeam                                     = 2,
    Player                                         = 3,
    JumperAI                                       = 4,
    NormalAI                                       = 5,
    DeliverAI                                      = 6,
    Circle                                         = 7,
    Magma                                          = 8,
    Forbidden                                      = 9,
    TeamMateAI                                     = 10,
    ScriptAI                                       = 11,
    Default                                        = 100,
    EAITLogKillType_MAX                            = 101

};


// Enum  /Script/AClient.EDebugInfoType
enum class EDebugInfoType : uint8_t
{
    Recycle                                        = 1,
    FakeBroad                                      = 2,
    Active                                         = 3,
    EDebugInfoType_MAX                             = 4

};


// Enum  /Script/AClient.EAIType
enum class EAIType : uint8_t
{
    None                                           = 0,
    JumperAI                                       = 1,
    NormalAI                                       = 2,
    DeliverAI                                      = 3,
    TDMAI                                          = 4,
    TestAI                                         = 5,
    TeamMateAI                                     = 6,
    SkillTestAI                                    = 7,
    ShootTestAI                                    = 8,
    PerformanceTestAI                              = 9,
    ShadowHero08TutorialAI                         = 10,
    BaseLineTestAI                                 = 11,
    TDMTestAI                                      = 12,
    ScriptBRAI                                     = 13,
    AutoTestAI                                     = 14,
    SaveAI                                         = 15,
    SkillPerfTestAI                                = 16,
    EAIType_MAX                                    = 17

};


// Enum  /Script/AClient.AIDeliverSpawnType
enum class AIDeliverSpawnType : uint8_t
{
    Reuse                                          = 1,
    Around                                         = 2,
    Common                                         = 3,
    AIDeliverSpawnType_MAX                         = 4

};


// Enum  /Script/AClient.EAIShapeDataType
enum class EAIShapeDataType : uint8_t
{
    None                                           = 0,
    Boolean_Type                                   = 1,
    Numberic_Type                                  = 2,
    Float_Type                                     = 3,
    String_Type                                    = 4,
    Vector2D_Type                                  = 5,
    Vector_Type                                    = 6,
    EAIShapeDataType_MAX                           = 7

};


// Enum  /Script/AClient.EAIShapeType
enum class EAIShapeType : uint8_t
{
    None                                           = 0,
    Blackboard                                     = 1,
    AliasData                                      = 2,
    HitCurvce                                      = 3,
    EAIShapeType_MAX                               = 4

};


// Enum  /Script/AClient.EDirectorCheckType
enum class EDirectorCheckType : uint32_t
{
    Check_CooldownTime_Failed                      = 64,
    Check_FireTime_Failed                          = 128,
    Check_PlayerStatus_Failed                      = 256,
    Check_SafeLocation_Failed                      = 512,
    Check_Equipment_Failed                         = 1024,
    Check_NoEnemyAround_Failed                     = 2048,
    Check_Pause_Deliver                            = 4096,
    Check_TeamTotalKill_Failed                     = 8192,
    Check_KillMateDeliver_Failed                   = 16384,
    Check_KillOtherDeliver_Failed                  = 32768,
    Check_ValidDeliverTime_Failed                  = 65536,
    Check_AirDropIndex_Failed                      = 131072,
    Check_TeamNum_Failed                           = 262144,
    Check_DistFromAirDrop_Failed                   = 524288,
    Check_TriggerNum_Failed                        = 1048576,
    Check_AirDropZoneValid_Failed                  = 2097152,
    Check_DayLimit_Failed                          = 4194304,
    Check_Mate_NoEnemyAround_Failed                = 8388608,
    Check_NotPrepareRespawnTeammate_Failed         = 16777216,
    Check_NoMateHero17InFlight_Failed              = 33554432,
    Check_SuperHeroMode_DeliverStoped              = 67108864,
    Check_MAX                                      = 67108865

};


// Enum  /Script/AClient.EDynamicDmgCurveType
enum class EDynamicDmgCurveType : uint8_t
{
    AILevelDamage                                  = 0,
    AILevelHit                                     = 1,
    AI2PlayerDamage                                = 2,
    AI2PlayerHit                                   = 3,
    AI2AIDamage                                    = 4,
    AI2AIHit                                       = 5,
    AIVelocityFixHit                               = 6,
    AIDistanceFixHit                               = 7,
    AI2TeammateAIHit                               = 8,
    AI2TeammateAIDamage                            = 9,
    EDynamicDmgCurveType_MAX                       = 10

};


// Enum  /Script/AClient.ENearAttackType
enum class ENearAttackType : uint8_t
{
    MeleeAttack                                    = 0,
    Others                                         = 1,
    ENearAttackType_MAX                            = 2

};


// Enum  /Script/AClient.EFireMode
enum class EFireMode : uint8_t
{
    Single                                         = 0,
    Burst                                          = 1,
    EFireMode_MAX                                  = 2

};


// Enum  /Script/AClient.EAIMovePose
enum class EAIMovePose : uint8_t
{
    Sprint                                         = 0,
    Walk                                           = 1,
    Crouch                                         = 2,
    KeepCurrentPose                                = 3,
    EAIMovePose_MAX                                = 4

};


// Enum  /Script/AClient.EAIMovetoVolume
enum class EAIMovetoVolume : uint8_t
{
    None                                           = 0,
    Moveto                                         = 1,
    BeginSearch                                    = 2,
    EAIMovetoVolume_MAX                            = 3

};


// Enum  /Script/AClient.EAIJumpPhase
enum class EAIJumpPhase : uint8_t
{
    Init                                           = 0,
    PrepareJump                                    = 1,
    GnglIdering                                    = 2,
    OpenParachute                                  = 3,
    Landing                                        = 4,
    EAIJumpPhase_MAX                               = 5

};


// Enum  /Script/AClient.EAIPhase
enum class EAIPhase : uint8_t
{
    Born                                           = 0,
    InPlane                                        = 1,
    GnglIder                                       = 2,
    InFighting                                     = 3,
    NearDeath                                      = 4,
    Death                                          = 5,
    EAIPhase_MAX                                   = 6

};


// Enum  /Script/AClient.EAirdropWorkbenchState
enum class EAirdropWorkbenchState : uint8_t
{
    Landing                                        = 0,
    Idle                                           = 1,
    EAirdropWorkbenchState_MAX                     = 2

};


// Enum  /Script/AClient.EAIItemScoreType
enum class EAIItemScoreType : uint8_t
{
    ItemType_Weapon                                = 1,
    ItemType_Ammo                                  = 2,
    ItemType_Grenades                              = 3,
    ItemType_Helmet                                = 4,
    ItemType_Armor                                 = 5,
    ItemType_Eq140_eq140_eq_                       = 6,
    ItemType_Backpack                              = 7,
    ItemType_Consumable                            = 8,
    ItemType_WeaponAttachment                      = 9,
    ItemType_Specific                              = 16,
    ItemType_Activity                              = 17,
    ItemType_MAX                                   = 18

};


// Enum  /Script/AClient.EEQSTestActorType
enum class EEQSTestActorType : uint8_t
{
    AllPawn                                        = 0,
    HumanPlayer                                    = 1,
    Enemy                                          = 2,
    EEQSTestActorType_MAX                          = 3

};


// Enum  /Script/AClient.EPerkInitPlatform
enum class EPerkInitPlatform : uint8_t
{
    Authority                                      = 0,
    Autonomous                                     = 1,
    Simulated                                      = 2,
    EPerkInitPlatform_MAX                          = 3

};


// Enum  /Script/AClient.EPerkRecoverType
enum class EPerkRecoverType : uint8_t
{
    NONE                                           = 0,
    RecoverHealth                                  = 1,
    RecoverShield                                  = 2,
    RecoverHealthThenShield                        = 3,
    RecoverShieldThenHealth                        = 4,
    RecoverAllShield                               = 5,
    EPerkRecoverType_MAX                           = 6

};


// Enum  /Script/AClient.ERecoverSkillBoolOperator
enum class ERecoverSkillBoolOperator : uint8_t
{
    None                                           = 0,
    Or                                             = 1,
    And                                            = 2,
    ERecoverSkillBoolOperator_MAX                  = 3

};


// Enum  /Script/AClient.EInGausticGasType
enum class EInGausticGasType : uint8_t
{
    Enemy                                          = 0,
    Teammate                                       = 1,
    All                                            = 2,
    EInGausticGasType_MAX                          = 3

};


// Enum  /Script/AClient.Trigger_ParaChuteType
enum class Trigger_ParaChuteType : uint8_t
{
    NotParaChute                                   = 0,
    ParaChuteTower                                 = 1,
    Geyser                                         = 2,
    Plane                                          = 3,
    VoidDoor                                       = 4,
    Skill                                          = 5,
    Trigger_MAX                                    = 6

};


// Enum  /Script/AClient.Trigger_RadiationCircleProgress
enum class Trigger_RadiationCircleProgress : uint8_t
{
    Equal                                          = 0,
    Greater                                        = 1,
    Less                                           = 2,
    GreaterEqual                                   = 3,
    LessEqual                                      = 4,
    Trigger_MAX                                    = 5

};


// Enum  /Script/AClient.Trigger_RadiationCircleType
enum class Trigger_RadiationCircleType : uint8_t
{
    InRadiationCircle                              = 0,
    OutRadiationCircle                             = 1,
    Trigger_MAX                                    = 2

};


// Enum  /Script/AClient.ETeamColorIndex
enum class ETeamColorIndex : uint8_t
{
    None                                           = 0,
    Green                                          = 1,
    Blue                                           = 2,
    Violet                                         = 3,
    Orange                                         = 4,
    TDMGreen                                       = 5,
    TDMBlue                                        = 6,
    GoldModeCamp1                                  = 7,
    GoldModeCamp2                                  = 8,
    GoldModeCamp3                                  = 9,
    GoldModeCamp4                                  = 10,
    Max                                            = 11

};


// Enum  /Script/AClient.EMLastTimeCharDataSaveReason
enum class EMLastTimeCharDataSaveReason : uint8_t
{
    None                                           = 0,
    Respawn                                        = 1,
    RoundRestart                                   = 2,
    ChangeLegend                                   = 3,
    MAX                                            = 64

};


// Enum  /Script/AClient.EMColorInTeam
enum class EMColorInTeam : uint8_t
{
    None                                           = 0,
    White                                          = 0,
    Green                                          = 1,
    Orange                                         = 2,
    Blue                                           = 3,
    Max                                            = 4

};


// Enum  /Script/AClient.EModifyAttributeNetExecutionPolicy
enum class EModifyAttributeNetExecutionPolicy : uint8_t
{
    LocalPredicted                                 = 0,
    ServerInitiated                                = 1,
    EModifyAttributeNetExecutionPolicy_MAX         = 2

};


// Enum  /Script/AClient.EVariableCompareType
enum class EVariableCompareType : uint8_t
{
    None                                           = 0,
    Bigger                                         = 1,
    Smaller                                        = 2,
    Equal                                          = 3,
    BiggerOrEqual                                  = 4,
    SmallerOrEqual                                 = 5,
    EVariableCompareType_MAX                       = 6

};


// Enum  /Script/AClient.EAttributeBasedFloatCalculationType
enum class EAttributeBasedFloatCalculationType : uint8_t
{
    AttributeMagnitude                             = 0,
    AttributeBaseValue                             = 1,
    AttributeBonusMagnitude                        = 2,
    AttributeMagnitudeEvaluatedUpToChannel         = 3,
    EAttributeBasedFloatCalculationType_MAX        = 4

};


// Enum  /Script/AClient.EAttributeModifyMagnitudeCalculation
enum class EAttributeModifyMagnitudeCalculation : uint8_t
{
    ScalableFloat                                  = 0,
    AttributeBased                                 = 1,
    CustomCalculationClass                         = 2,
    SetByCaller                                    = 3,
    SetByLevel                                     = 4,
    EAttributeModifyMagnitudeCalculation_MAX       = 5

};


// Enum  /Script/AClient.EModifyByPawnState
enum class EModifyByPawnState : uint8_t
{
    Default                                        = 0,
    PoseState                                      = 1,
    MoveDir                                        = 2,
    ADS                                            = 3,
    Sprint                                         = 4,
    Combination                                    = 5,
    EModifyByPawnState_MAX                         = 6

};


// Enum  /Script/AClient.EChangeType
enum class EChangeType : uint8_t
{
    None                                           = 0,
    Time                                           = 1,
    DistanceFromSourceToTarget                     = 2,
    InitDistanceFromSourceToTarget                 = 3,
    Hero07PoisonValue                              = 4,
    EChangeType_MAX                                = 5

};


// Enum  /Script/AClient.EDurationType
enum class EDurationType : uint8_t
{
    Infinite                                       = 0,
    HasDuration                                    = 1,
    EDurationType_MAX                              = 2

};


// Enum  /Script/AClient.EAttributeSumOperator
enum class EAttributeSumOperator : uint8_t
{
    Additive                                       = 0,
    Multiplicitive                                 = 1,
    Minimum                                        = 2,
    Maxnimum                                       = 3,
    Dynamic                                        = 4,
    Count                                          = 5,
    EAttributeSumOperator_MAX                      = 6

};


// Enum  /Script/AClient.EAttributeModifyOperator
enum class EAttributeModifyOperator : uint8_t
{
    Additive                                       = 0,
    Multiplicitive                                 = 1,
    Division                                       = 2,
    Override                                       = 3,
    Count                                          = 4,
    EAttributeModifyOperator_MAX                   = 5

};


// Enum  /Script/AClient.EModifyEvaluationChannel
enum class EModifyEvaluationChannel : uint8_t
{
    Channel0                                       = 0,
    Channel1                                       = 1,
    Channel2                                       = 2,
    Channel3                                       = 3,
    Channel4                                       = 4,
    Channel5                                       = 5,
    Channel6                                       = 6,
    Channel7                                       = 7,
    Channel8                                       = 8,
    Channel9                                       = 9,
    Channel_MAX                                    = 10,
    EModifyEvaluationChannel_MAX                   = 11

};


// Enum  /Script/AClient.EMAudioAttachMode
enum class EMAudioAttachMode : uint8_t
{
    Owner                                          = 0,
    PlayerCameraManager                            = 1,
    Character                                      = 2,
    EMAudioAttachMode_MAX                          = 3

};


// Enum  /Script/AClient.EAudioRegionEventType
enum class EAudioRegionEventType : uint8_t
{
    Enter                                          = 0,
    Exit                                           = 1,
    EAudioRegionEventType_MAX                      = 2

};


// Enum  /Script/AClient.AudioRegionProcessorType
enum class AudioRegionProcessorType : uint8_t
{
    AudioRegion                                    = 1,
    AudioRegionEnemy                               = 2,
    RiverAmbient                                   = 3,
    MagmaAmbient                                   = 4,
    RemoteWeapon                                   = 5,
    AudioRegionProcessorType_MAX                   = 6

};


// Enum  /Script/AClient.ESyncOperation
enum class ESyncOperation : uint8_t
{
    PutOn                                          = 0,
    PutOff                                         = 1,
    ApplyHead                                      = 2,
    ESyncOperation_MAX                             = 3

};


// Enum  /Script/AClient.EGnyxMeshType
enum class EGnyxMeshType : uint8_t
{
    Skeletal                                       = 0,
    Static                                         = 1,
    SkeletalWithSocket                             = 2,
    EGnyxMeshType_MAX                              = 3

};


// Enum  /Script/AClient.EAvatarAttachmentSlot
enum class EAvatarAttachmentSlot : uint8_t
{
    NONE                                           = 0,
    Magazine                                       = 1,
    MAX                                            = 2

};


// Enum  /Script/AClient.EReplaceSlot
enum class EReplaceSlot : uint8_t
{
    EReplaceType_NONE                              = 0,
    EReplaceType_HeadEquipemtSlot                  = 1,
    EReplaceType_HairEquipemtSlot                  = 2,
    EReplaceType_HatEquipemtSlot                   = 3,
    EReplaceType_FaceEquipemtSlot                  = 4,
    EReplaceType_ClothesEquipemtSlot               = 5,
    EReplaceType_PantsEquipemtSlot                 = 6,
    EReplaceType_ShoesEquipemtSlot                 = 7,
    EReplaceType_BackpackEquipemtSlot              = 8,
    EReplaceType_HelmetEquipemtSlot                = 9,
    EReplaceType_ArmorEquipemtSlot                 = 10,
    EReplaceType_ParachuteEquipemtSlot             = 11,
    ESubSlot_HairOrnament                          = 65,
    EReplaceType_VeilSlot                          = 70,
    EReplaceType_HoodSlot                          = 75,
    EReplaceType_SilkStockingSlot                  = 80,
    EReplaceType_StockingSlot                      = 85,
    EReplaceType_BootsSlot                         = 86,
    EReplaceSlot_MAX                               = 87

};


// Enum  /Script/AClient.EAvatarSubSlot
enum class EAvatarSubSlot : uint8_t
{
    ESubSlot_None                                  = 0,
    ESubSlot_HairOrnament                          = 65,
    ESubSlot_VeilSlot                              = 70,
    ESubSlot_HoodSlot                              = 75,
    ESubSlot_SilkStockingSlot                      = 80,
    ESubSlot_StockingSlot                          = 85,
    ESubSlot_BootsSlot                             = 86,
    ESubSlot_MAX                                   = 87

};


// Enum  /Script/AClient.EAvatarSlotType
enum class EAvatarSlotType : uint8_t
{
    EAvatarSlotType_NONE                           = 0,
    EAvatarSlotType_HeadEquipemtSlot               = 1,
    EAvatarSlotType_HairEquipemtSlot               = 2,
    EAvatarSlotType_HatEquipemtSlot                = 3,
    EAvatarSlotType_FaceEquipemtSlot               = 4,
    EAvatarSlotType_ClothesEquipemtSlot            = 5,
    EAvatarSlotType_PantsEquipemtSlot              = 6,
    EAvatarSlotType_ShoesEquipemtSlot              = 7,
    EAvatarSlotType_BackpackEquipemtSlot           = 8,
    EAvatarSlotType_HelmetEquipemtSlot             = 9,
    EAvatarSlotType_ArmorEquipemtSlot              = 10,
    EAvatarSlotType_ParachuteEquipemtSlot          = 11,
    EAvatarSlotType_GlassEquipemtSlot              = 12,
    EAvatarSlotType_NightVisionEquipemtSlot        = 13,
    EAvatarSlotType_WingClothesDataEquipemtSlot    = 14,
    EAvatarSlotType_BackPack_PendantSlot           = 15,
    EAvatarSlotType_Hand_HostileTipsLSlot          = 16,
    EAvatarSlotType_Hand_HostileTipsRSlot          = 17,
    EAvatarSlotType_FacePainting                   = 18,
    EAvatarSlotType_Ornament                       = 19,
    EAvatarSlotType_Max                            = 20

};


// Enum  /Script/AClient.EBackpackCapacityTipItemState
enum class EBackpackCapacityTipItemState : uint8_t
{
    Normal                                         = 1,
    AlmostFull                                     = 2,
    Full                                           = 3,
    Empty                                          = 4,
    EBackpackCapacityTipItemState_MAX              = 5

};


// Enum  /Script/AClient.EBackpackItemType
enum class EBackpackItemType : uint8_t
{
    BackpackItem_Normal                            = 0,
    BackpackItem_Weapon                            = 1,
    BackpackItem_Attachment                        = 2,
    BackpackItem_MAX                               = 3

};


// Enum  /Script/AClient.EBackpackPointState
enum class EBackpackPointState : uint8_t
{
    Empty                                          = 0,
    NonEmpty                                       = 1,
    Full                                           = 2,
    EBackpackPointState_MAX                        = 3

};


// Enum  /Script/AClient.EBackpackDragState
enum class EBackpackDragState : uint8_t
{
    None                                           = 0,
    DragBegin                                      = 1,
    DragEnd                                        = 2,
    EBackpackDragState_MAX                         = 3

};


// Enum  /Script/AClient.EWeaponUISocket
enum class EWeaponUISocket : uint8_t
{
    None                                           = 0,
    Muzzle                                         = 1,
    Upper                                          = 2,
    Magazine                                       = 3,
    Stock                                          = 4,
    HopUp                                          = 5,
    EWeaponUISocket_MAX                            = 6

};


// Enum  /Script/AClient.EBackpackPartItemType
enum class EBackpackPartItemType : uint8_t
{
    None                                           = 0,
    Helmet                                         = 1,
    Armor                                          = 2,
    Shield                                         = 3,
    Bag                                            = 4,
    Tactics                                        = 5,
    Respawn                                        = 6,
    VaultKey                                       = 7,
    HeterochromaticSummoner                        = 8,
    HeterochromaticLens                            = 9,
    WindstormEvacuate                              = 10,
    WindstormEnergyCrystalLens                     = 11,
    Ornament                                       = 12,
    EBackpackPartItemType_MAX                      = 13

};


// Enum  /Script/AClient.EMeshTypes
enum class EMeshTypes : uint8_t
{
    Skeletal                                       = 0,
    Static                                         = 1,
    SkeletalWithSocket                             = 2,
    EMeshTypes_MAX                                 = 3

};


// Enum  /Script/AClient.EDragState
enum class EDragState : uint8_t
{
    Normal                                         = 0,
    Active                                         = 1,
    Focus                                          = 2,
    EDragState_MAX                                 = 3

};


// Enum  /Script/AClient.EOpticalSocketType
enum class EOpticalSocketType : uint8_t
{
    OpticalDefault                                 = 0,
    Optical1X                                      = 1,
    Optical2X                                      = 2,
    Optical3X                                      = 3,
    Optical4X                                      = 4,
    Optical6X                                      = 6,
    Optical8X                                      = 8,
    Optical10X                                     = 10,
    EOpticalSocketType_MAX                         = 11

};


// Enum  /Script/AClient.EBacktraceStatrtupRule
enum class EBacktraceStatrtupRule : uint8_t
{
    BeginPlay                                      = 0,
    FirstOne                                       = 1,
    EBacktraceStatrtupRule_MAX                     = 2

};


// Enum  /Script/AClient.EBarrageItemRunPhase
enum class EBarrageItemRunPhase : uint8_t
{
    Initially                                      = 0,
    BeginEnter                                     = 1,
    EndEnter                                       = 2,
    BeginLeave                                     = 3,
    EndLeave                                       = 4,
    EBarrageItemRunPhase_MAX                       = 5

};


// Enum  /Script/AClient.EBarrageLoopMode
enum class EBarrageLoopMode : uint8_t
{
    None                                           = 0,
    Compact                                        = 1,
    Chapter                                        = 2,
    EBarrageLoopMode_MAX                           = 3

};


// Enum  /Script/AClient.EBarrageDirection
enum class EBarrageDirection : uint8_t
{
    LeftToRight                                    = 0,
    RightToLeft                                    = 1,
    EBarrageDirection_MAX                          = 2

};


// Enum  /Script/AClient.EPedestalType
enum class EPedestalType : uint8_t
{
    None                                           = 0,
    Hero                                           = 1,
    Weapon                                         = 2,
    Treasure                                       = 3,
    Trophy                                         = 4,
    Pet                                            = 5,
    Vehicle                                        = 6,
    Building                                       = 7,
    Chest                                          = 8,
    Decor                                          = 9,
    EPedestalType_MAX                              = 10

};


// Enum  /Script/AClient.ECitiaoAttrType
enum class ECitiaoAttrType : uint8_t
{
    CAT_None                                       = 0,
    CAT_ShootSpeedFactor                           = 1,
    CAT_HeadDamageFactor                           = 2,
    CAT_BodyDamageFactor                           = 3,
    CAT_ThighsDamageFactor                         = 4,
    CAT_PVEDamageAdd                               = 5,
    CAT_BossDamageAdd                              = 6,
    CAT_ExtDamageBuff                              = 7,
    CAT_PoisonDamageBuff                           = 8,
    CAT_TargetBoomOnDeath                          = 9,
    CAT_LowHealthSpeedFactor                       = 10,
    CAT_ADSMoveFactor                              = 11,
    CAT_FillBulletWhenKillTarget                   = 12,
    CAT_BulletReloadSave                           = 13,
    CAT_MagReloadTimeFactor                        = 14,
    CAT_BoltWaitFactor                             = 15,
    CAT_PitchRecoilForceFactor                     = 16,
    CAT_YawRecoilForceFactor                       = 17,
    CAT_QuickerADSFactor                           = 18,
    CAT_NoADSRecoilForceFactor                     = 19,
    CAT_ADSRecoilForceFactor                       = 20,
    CAT_BulletSpeedFactor                          = 21,
    CAT_ExtraAddMagBulletNum                       = 22,
    CAT_SlidingAutoReload                          = 23,
    CAT_SlidingNoADSRecoilFactor                   = 24,
    CAT_EquipWeaponFactor                          = 25,
    CAT_NoShieldDamageFactor                       = 26,
    CAT_BulletDistanceFactor                       = 27,
    CAT_ChargeEnergySpeedFactor                    = 28,
    CAT_NearEnemyDamageFactor                      = 29,
    CAT_LowBulletDamageFactor                      = 30,
    CAT_RandomRecoilForceFactor                    = 31,
    CAT_ShotgunCollectScaleFactor                  = 32,
    CAT_ShieldDamageFactor                         = 33,
    CAT_FireRecoveryFactor                         = 34,
    CAT_StandADSMoveFactor                         = 35,
    CAT_CrouchADSMoveFactor                        = 36,
    CAT_MAX                                        = 37

};


// Enum  /Script/AClient.EBattleItemQuality
enum class EBattleItemQuality : uint8_t
{
    White                                          = 0,
    Blue                                           = 1,
    Purple                                         = 2,
    Gold                                           = 3,
    EBattleItemQuality_MAX                         = 4

};


// Enum  /Script/AClient.EBattleKillMessageType
enum class EBattleKillMessageType : uint8_t
{
    Kill                                           = 0,
    Assist                                         = 1,
    Dying                                          = 2,
    EBattleKillMessageType_MAX                     = 3

};


// Enum  /Script/AClient.EBattleResultGameEndReason
enum class EBattleResultGameEndReason : uint8_t
{
    None                                           = 0,
    Normal                                         = 1,
    TimeOut                                        = 2,
    CampLeave                                      = 3,
    EBattleResultGameEndReason_MAX                 = 4

};


// Enum  /Script/AClient.EMBGMType
enum class EMBGMType : uint8_t
{
    None                                           = 0,
    Basic                                          = 1,
    RoleSelect                                     = 2,
    SelfTeamFlag                                   = 3,
    Parachute                                      = 4,
    PlayerInFight                                  = 5,
    PlayerInDie                                    = 6,
    EMBGMType_MAX                                  = 7

};


// Enum  /Script/AClient.EBinShieldState
enum class EBinShieldState : uint8_t
{
    None                                           = 0,
    NotDisappearing                                = 1,
    Disappearing                                   = 2,
    Disappeared                                    = 3,
    EBinShieldState_MAX                            = 4

};


// Enum  /Script/AClient.EBinOpenReason
enum class EBinOpenReason : uint8_t
{
    Normal                                         = 0,
    PickUpTrigger                                  = 1,
    EBinOpenReason_MAX                             = 2

};


// Enum  /Script/AClient.ESetIDReason
enum class ESetIDReason : uint8_t
{
    None                                           = 0,
    Generate                                       = 1,
    DynamicItemBin                                 = 2,
    ESetIDReason_MAX                               = 3

};


// Enum  /Script/AClient.EBinOpenState
enum class EBinOpenState : uint8_t
{
    Closed                                         = 0,
    Openning                                       = 1,
    Openned                                        = 2,
    Closing                                        = 3,
    Reading                                        = 4,
    EBinOpenState_MAX                              = 5

};


// Enum  /Script/AClient.EAddtionalEffect
enum class EAddtionalEffect : uint8_t
{
    None                                           = 0,
    SuperHero                                      = 1,
    EAddtionalEffect_MAX                           = 2

};


// Enum  /Script/AClient.EBinType
enum class EBinType : uint8_t
{
    Normal                                         = 0,
    IceBin                                         = 1,
    VIPBin                                         = 2,
    AdvancedVIPBin                                 = 3,
    GhostBin                                       = 4,
    HighPoiBin                                     = 5,
    BlueBin                                        = 6,
    SporeBin                                       = 7,
    EBinType_MAX                                   = 8

};


// Enum  /Script/AClient.EValueComparer
enum class EValueComparer : uint8_t
{
    VE_E                                           = 0,
    VE_NE                                          = 1,
    VE_LT                                          = 2,
    VE_LTE                                         = 3,
    VE_GT                                          = 4,
    VE_GTE                                         = 5,
    VE_IN                                          = 6,
    VE_MAX                                         = 7

};


// Enum  /Script/AClient.EBlackboardValueType
enum class EBlackboardValueType : uint8_t
{
    Int                                            = 0,
    Float                                          = 1,
    Bool                                           = 2,
    String                                         = 3,
    Object                                         = 4,
    Vector                                         = 5,
    Rotator                                        = 6,
    Class                                          = 7,
    Name                                           = 8,
    Max                                            = 9

};


// Enum  /Script/AClient.EShowStandPlayerType
enum class EShowStandPlayerType : uint8_t
{
    None                                           = 0,
    LastBestPlayer                                 = 1,
    Collectable                                    = 2,
    EShowStandPlayerType_MAX                       = 3

};


// Enum  /Script/AClient.EBoss01SpawnnerState
enum class EBoss01SpawnnerState : uint8_t
{
    None                                           = 0,
    Deploy                                         = 1,
    Deploying                                      = 2,
    DeployComplete                                 = 3,
    End                                            = 4,
    EBoss01SpawnnerState_MAX                       = 5

};


// Enum  /Script/AClient.ELaserActionType
enum class ELaserActionType : uint8_t
{
    None                                           = 0,
    FlyOut                                         = 1,
    Move                                           = 2,
    Charge                                         = 3,
    Attack                                         = 4,
    FlyIn                                          = 5,
    Died                                           = 6,
    Destroy                                        = 7,
    ELaserActionType_MAX                           = 8

};


// Enum  /Script/AClient.ELaserDir
enum class ELaserDir : uint8_t
{
    None                                           = 0,
    Left                                           = 1,
    Right                                          = 2,
    Up                                             = 3,
    Bottom                                         = 4,
    ELaserDir_MAX                                  = 5

};


// Enum  /Script/AClient.ELaserType
enum class ELaserType : uint8_t
{
    None                                           = 0,
    Horizontal                                     = 1,
    Vertical                                       = 2,
    ELaserType_MAX                                 = 3

};


// Enum  /Script/AClient.EBoss01LaunchPhase
enum class EBoss01LaunchPhase : uint8_t
{
    None                                           = 0,
    Phase1                                         = 1,
    Phase2                                         = 2,
    Explode                                        = 3,
    END                                            = 4,
    EBoss01LaunchPhase_MAX                         = 5

};


// Enum  /Script/AClient.EScriptType
enum class EScriptType : uint8_t
{
    ENone                                          = 0,
    EGroupFight                                    = 1,
    EDoubleKill                                    = 2,
    ESnatchAirdrop                                 = 3,
    ESuperHeroScript                               = 4,
    EScriptType_MAX                                = 5

};


// Enum  /Script/AClient.EAIRetCode
enum class EAIRetCode : uint8_t
{
    SUCCESS                                        = 0,
    EQS_FAILED                                     = 1,
    AI_NOT_ENOUGH                                  = 2,
    EAIRetCode_MAX                                 = 3

};


// Enum  /Script/AClient.EBackpackMetric
enum class EBackpackMetric : uint8_t
{
    ItemCount                                      = 0,
    ItemPile                                       = 1,
    Max                                            = 2

};


// Enum  /Script/AClient.EBackpackType
enum class EBackpackType : uint8_t
{
    Any                                            = 0,
    Real                                           = 1,
    Cheat                                          = 2,
    EBackpackType_MAX                              = 3

};


// Enum  /Script/AClient.EMLTagName
enum class EMLTagName : uint8_t
{
    NewbieGamePerformance                          = 0,
    EMLTagName_MAX                                 = 1

};


// Enum  /Script/AClient.EMLTagType
enum class EMLTagType : uint8_t
{
    Integer                                        = 0,
    Float                                          = 1,
    Boolean                                        = 2,
    String                                         = 3,
    EMLTagType_MAX                                 = 4

};


// Enum  /Script/AClient.ECheckWeaponSlot
enum class ECheckWeaponSlot : uint8_t
{
    VE_Main                                        = 0,
    VE_Secondary                                   = 1,
    VE_Current                                     = 2,
    VE_MAX                                         = 3

};


// Enum  /Script/AClient.EExpressionForceResult
enum class EExpressionForceResult : uint8_t
{
    Nop                                            = 0,
    Succeeded                                      = 1,
    Failed                                         = 2,
    EExpressionForceResult_MAX                     = 3

};


// Enum  /Script/AClient.EResultOverwrite
enum class EResultOverwrite : uint8_t
{
    VE_AlwaysSuccess                               = 0,
    VE_AlwaysFail                                  = 1,
    VE_MAX                                         = 2

};


// Enum  /Script/AClient.EHoldLastRangeSight
enum class EHoldLastRangeSight : uint8_t
{
    Fist                                           = 0,
    LastWeapon                                     = 1,
    LongestWeapon                                  = 2,
    EHoldLastRangeSight_MAX                        = 3

};


// Enum  /Script/AClient.ESelfDamageType
enum class ESelfDamageType : uint8_t
{
    EShieldDamage                                  = 0,
    EHPDamage                                      = 1,
    ENormalDamage                                  = 2,
    ESelfDamageType_MAX                            = 3

};


// Enum  /Script/AClient.EFindNearMeshMode
enum class EFindNearMeshMode : uint8_t
{
    VE_Extent                                      = 0,
    VE_Area                                        = 1,
    VE_MAX                                         = 2

};


// Enum  /Script/AClient.ESafeAreaType
enum class ESafeAreaType : uint8_t
{
    VE_WhiteCircle                                 = 0,
    VE_BlueCircle                                  = 1,
    VE_MAX                                         = 2

};


// Enum  /Script/AClient.EEQSMoveStat
enum class EEQSMoveStat : uint8_t
{
    Init                                           = 0,
    EnterEQSRange                                  = 1,
    LeaveEQSRange                                  = 2,
    EEQSMoveStat_MAX                               = 3

};


// Enum  /Script/AClient.ECheckSafeAreaMode
enum class ECheckSafeAreaMode : uint8_t
{
    CheckSafeAreaMode_Strict                       = 0,
    CheckSafeAreaMode_Priotity                     = 1,
    CheckSafeAreaMode_None                         = 2,
    CheckSafeAreaMode_MAX                          = 3

};


// Enum  /Script/AClient.EGetRandLocDirectedMode
enum class EGetRandLocDirectedMode : uint8_t
{
    VE_Raycast                                     = 0,
    VE_Reachable                                   = 1,
    VE_Any                                         = 2,
    VE_MAX                                         = 3

};


// Enum  /Script/AClient.EATMOperateType
enum class EATMOperateType : uint8_t
{
    EATM_OP_STORE                                  = 0,
    EATM_OP_STEAL                                  = 1,
    EATM_OP_MAX                                    = 2

};


// Enum  /Script/AClient.EOperateTargetType
enum class EOperateTargetType : uint8_t
{
    EMap_resPawn_m                                 = 0,
    EMap_ATM_m                                     = 1,
    EMap_RedEnvelope_m                             = 2,
    EMap_MAX                                       = 3

};


// Enum  /Script/AClient.ESpawnState
enum class ESpawnState : uint8_t
{
    Stand                                          = 0,
    KnockDown                                      = 1,
    ESpawnState_MAX                                = 2

};


// Enum  /Script/AClient.ESpawnTeam
enum class ESpawnTeam : uint8_t
{
    TeamMate                                       = 0,
    Enemy                                          = 1,
    PlayerTeamMate                                 = 2,
    ESpawnTeam_MAX                                 = 3

};


// Enum  /Script/AClient.EAirNavMethod
enum class EAirNavMethod : uint8_t
{
    Voxel                                          = 0,
    NavMesh                                        = 1,
    EAirNavMethod_MAX                              = 2

};


// Enum  /Script/AClient.EAnimState
enum class EAnimState : uint8_t
{
    VE_NotSet                                      = 63,
    VE_Stand                                       = 11,
    VE_Crouch                                      = 12,
    VE_Sprint                                      = 1,
    VE_MAX                                         = 64

};


// Enum  /Script/AClient.ESwitchWeaponSlot
enum class ESwitchWeaponSlot : uint8_t
{
    VE_Main                                        = 0,
    VE_Secondary                                   = 1,
    VE_Throw                                       = 2,
    VE_Empty                                       = 3,
    VE_Alternative                                 = 4,
    VE_AUTO                                        = 5,
    VE_MAX                                         = 6

};


// Enum  /Script/AClient.EMedicineItem
enum class EMedicineItem : uint8_t
{
    VE_Md110_m                                     = 0,
    VE_1stAidBox                                   = 1,
    VE_Md100_Md1_                                  = 2,
    VE_Md101_Md101_m                               = 3,
    VE_Md120_mD1_                                  = 4,
    VE_InfMd110_m                                  = 5,
    VE_InfMd100_Md1_                               = 6,
    VE_MAX                                         = 7

};


// Enum  /Script/AClient.ETimeCounterMode
enum class ETimeCounterMode : uint8_t
{
    Default                                        = 0,
    OneShot                                        = 1,
    DefaultInverted                                = 2,
    OneShotInverted                                = 3,
    ETimeCounterMode_MAX                           = 4

};


// Enum  /Script/AClient.EVoxCheckSafeAreaMode
enum class EVoxCheckSafeAreaMode : uint8_t
{
    CheckSafeAreaMode_Strict                       = 0,
    CheckSafeAreaMode_Priotity                     = 1,
    CheckSafeAreaMode_None                         = 2,
    CheckSafeAreaMode_MAX                          = 3

};


// Enum  /Script/AClient.EVoxGetRandLocDirectedMode
enum class EVoxGetRandLocDirectedMode : uint8_t
{
    Vox_Raycast                                    = 0,
    Vox_Reachable                                  = 1,
    Vox_Any                                        = 2,
    Vox_MAX                                        = 3

};


// Enum  /Script/AClient.EBunckerType
enum class EBunckerType : uint8_t
{
    None                                           = 0,
    HorizontalDoor                                 = 1,
    VerticalDoor                                   = 2,
    DoorConsole                                    = 3,
    EBunckerType_MAX                               = 4

};


// Enum  /Script/AClient.ECameraEffectAxisType
enum class ECameraEffectAxisType : uint8_t
{
    InDeformable_Y                                 = 0,
    InDeformable_Z                                 = 1,
    InDeformable_YZ                                = 2,
    Deformable                                     = 3,
    ECameraEffectAxisType_MAX                      = 4

};


// Enum  /Script/AClient.ECameraEffectType
enum class ECameraEffectType : uint8_t
{
    FullScreen                                     = 0,
    Smoke                                          = 1,
    Other                                          = 2,
    ALL                                            = 3,
    ECameraEffectType_MAX                          = 4

};


// Enum  /Script/AClient.ECameraEffectLayerType
enum class ECameraEffectLayerType : uint8_t
{
    Blend                                          = 0,
    NoBlend                                        = 1,
    ECameraEffectLayerType_MAX                     = 2

};


// Enum  /Script/AClient.ECameraEffectViewType
enum class ECameraEffectViewType : uint8_t
{
    None                                           = 0,
    Normal                                         = 1,
    Drones                                         = 2,
    BannerShow                                     = 3,
    ECameraEffectViewType_MAX                      = 4

};


// Enum  /Script/AClient.ECPProgressChangeCondition
enum class ECPProgressChangeCondition : uint8_t
{
    OnlyOneCamp                                    = 0,
    MostMemers                                     = 1,
    ECPProgressChangeCondition_MAX                 = 2

};


// Enum  /Script/AClient.ECPAddHealthCondition
enum class ECPAddHealthCondition : uint8_t
{
    Capturing                                      = 0,
    Captured                                       = 1,
    ECPAddHealthCondition_MAX                      = 2

};


// Enum  /Script/AClient.EAnimDataLoadRequestFlag
enum class EAnimDataLoadRequestFlag : uint8_t
{
    AnimDataMap                                    = 0,
    EAnimDataLoadRequestFlag_MAX                   = 1

};


// Enum  /Script/AClient.ERotateType
enum class ERotateType : uint8_t
{
    ERotateWithMaxSpeed                            = 0,
    ERotateNextFrame                               = 1,
    ERotateDynamic                                 = 2,
    ERotateType_MAX                                = 3

};


// Enum  /Script/AClient.EAutoPathFindState
enum class EAutoPathFindState : uint8_t
{
    ENone                                          = 0,
    ETrigger                                       = 1,
    EWaitForPath                                   = 2,
    EPathFollowing                                 = 3,
    EAutoPathFindState_MAX                         = 4

};


// Enum  /Script/AClient.EMBuffOverlapType
enum class EMBuffOverlapType : uint8_t
{
    NoOverlap                                      = 0,
    SingleEffect                                   = 1,
    OverlapEffect                                  = 2,
    OverlapEffect_Individual                       = 3,
    EMBuffOverlapType_MAX                          = 4

};


// Enum  /Script/AClient.EBattleItemUseEventType
enum class EBattleItemUseEventType : uint8_t
{
    None                                           = 0,
    USE_Start                                      = 1,
    USE_Interrupt                                  = 2,
    USE_End                                        = 3,
    EBattleItemUseEventType_MAX                    = 4

};


// Enum  /Script/AClient.ECircleInfo
enum class ECircleInfo : uint8_t
{
    None                                           = 0,
    PreInitBlueCircle                              = 1,
    SafeZoneTips                                   = 2,
    BlueCirclePreWarning                           = 3,
    BlueCircleRun                                  = 4,
    CurWaveOver                                    = 5,
    AllCircleEnd                                   = 6,
    ECircleInfo_MAX                                = 7

};


// Enum  /Script/AClient.UCircleType
enum class UCircleType : uint8_t
{
    Normal                                         = 0,
    ABLine                                         = 1,
    WidgetMap                                      = 2,
    UCircleType_MAX                                = 3

};


// Enum  /Script/AClient.ColosseumInvincibleStage
enum class ColosseumInvincibleStage : uint8_t
{
    WaitActive                                     = 0,
    Active                                         = 1,
    CD                                             = 2,
    ColosseumInvincibleStage_MAX                   = 3

};


// Enum  /Script/AClient.ECommDiscardMagSkeletalMeshType
enum class ECommDiscardMagSkeletalMeshType : uint8_t
{
    Q7                                             = 0,
    Triple                                         = 1,
    ECommDiscardMagSkeletalMeshType_MAX            = 2

};


// Enum  /Script/AClient.EGenerateObjectType
enum class EGenerateObjectType : uint8_t
{
    Bin                                            = 0,
    FeloOtball                                     = 1,
    EGenerateObjectType_MAX                        = 2

};


// Enum  /Script/AClient.ESignHandleType
enum class ESignHandleType : uint8_t
{
    Create                                         = 1,
    Delete                                         = 2,
    ESignHandleType_MAX                            = 3

};


// Enum  /Script/AClient.ECommonSignDirection
enum class ECommonSignDirection : uint8_t
{
    None                                           = 0,
    Top                                            = 1,
    Bottom                                         = 2,
    Left                                           = 3,
    Right                                          = 4,
    ECommonSignDirection_MAX                       = 5

};


// Enum  /Script/AClient.EConditionPoseType
enum class EConditionPoseType : uint8_t
{
    HoldWeapon                                     = 0,
    SkillBothHands                                 = 1,
    SkillLeftHand                                  = 2,
    SkillRightHand                                 = 3,
    Sliding                                        = 4,
    ZipLine                                        = 5,
    EConditionPoseType_MAX                         = 6

};


// Enum  /Script/AClient.EConditionCharAnimOp
enum class EConditionCharAnimOp : uint8_t
{
    Or                                             = 0,
    And                                            = 1,
    OrNot                                          = 2,
    AndNot                                         = 3,
    EConditionCharAnimOp_MAX                       = 4

};


// Enum  /Script/AClient.ECountDownTimerRepMode
enum class ECountDownTimerRepMode : uint8_t
{
    None                                           = 0,
    Broadcast                                      = 1,
    Client                                         = 2,
    ECountDownTimerRepMode_MAX                     = 3

};


// Enum  /Script/AClient.ECustomCollisionType
enum class ECustomCollisionType : uint8_t
{
    EventClosed                                    = 0,
    EventReceiver                                  = 1,
    EventGenerator                                 = 2,
    EventGeneratorAndReceiver                      = 3,
    ECustomCollisionType_MAX                       = 4

};


// Enum  /Script/AClient.ECustomVectorOP
enum class ECustomVectorOP : uint8_t
{
    Add                                            = 0,
    Sub                                            = 1,
    Cross                                          = 2,
    Dot                                            = 3,
    Distance                                       = 4,
    Dist2D                                         = 5,
    ECustomVectorOP_MAX                            = 6

};


// Enum  /Script/AClient.EDebugArrowDrawMode
enum class EDebugArrowDrawMode : uint8_t
{
    straight                                       = 0,
    smooth                                         = 1,
    EDebugArrowDrawMode_MAX                        = 2

};


// Enum  /Script/AClient.ECustomWidgetVisual
enum class ECustomWidgetVisual : uint8_t
{
    None                                           = 0,
    HiddenInGame                                   = 1,
    HiddenInBasic                                  = 2,
    HiddenInCustom                                 = 3,
    HiddenInGM                                     = 4,
    MaxIndex                                       = 63,
    ECustomWidgetVisual_MAX                        = 64

};


// Enum  /Script/AClient.EDamageLockSource
enum class EDamageLockSource : uint8_t
{
    AttackDamage                                   = 0,
    TakeDamage                                     = 1,
    AttackDamage_Teammate                          = 2,
    TakeDamage_Teammate                            = 3,
    __MAX                                          = 4,
    EDamageLockSource_MAX                          = 5

};


// Enum  /Script/AClient.EDamageNumShowType
enum class EDamageNumShowType : uint8_t
{
    DamageNumShowType_None                         = 0,
    DamageNumShowType_Add                          = 1,
    DamageNumShowType_Float                        = 2,
    DamageNumShowType_Both                         = 3,
    DamageNumShowType_MAX                          = 4

};


// Enum  /Script/AClient.EReportMode
enum class EReportMode : uint8_t
{
    Immediately                                    = 0,
    OnPlayerExit                                   = 1,
    OnGameEnd                                      = 2,
    EReportMode_MAX                                = 3

};


// Enum  /Script/AClient.EReportType
enum class EReportType : uint8_t
{
    NONE                                           = 0,
    GameStatisticsReport                           = 1,
    TrackerManager                                 = 2,
    EReportType_MAX                                = 3

};


// Enum  /Script/AClient.EDTShootEffectEvent
enum class EDTShootEffectEvent : uint8_t
{
    IDChange                                       = 1,
    WeaponChange                                   = 2,
    EDTShootEffectEvent_MAX                        = 3

};


// Enum  /Script/AClient.EDecorationType
enum class EDecorationType : uint8_t
{
    EDT_Deco                                       = 1,
    EDT_Deco                                       = 2,
    EDT_Deco                                       = 3,
    EDT_Deco                                       = 4,
    EDT_Deco                                       = 5,
    EDT_Deco                                       = 6,
    EDT_Deco                                       = 7,
    EDT_Deco                                       = 8,
    EDT_Deco                                       = 9,
    EDT_Deco                                       = 10,
    EDT_Deco                                       = 11,
    EDT_Deco                                       = 12,
    EDT_Deco                                       = 13,
    EDT_Deco                                       = 14,
    EDT_Deco                                       = 15,
    EDT_Deco                                       = 16,
    EDT_Deco                                       = 17,
    EDT_Deco                                       = 18,
    EDT_Deco                                       = 19,
    EDT_Deco                                       = 20,
    EDT_Deco_MAX                                   = 21

};


// Enum  /Script/AClient.EGnyxMoveGait
enum class EGnyxMoveGait : uint8_t
{
    Walk                                           = 0,
    Sprint                                         = 1,
    EGnyxMoveGait_MAX                              = 2

};


// Enum  /Script/AClient.EBlockDoorType
enum class EBlockDoorType : uint8_t
{
    BlockAll                                       = 0,
    MoveDoubleDoorBlockToDestroy                   = 1,
    MoveDoorBlockToDestroy                         = 2,
    DoubleDoorBlockToDestroy                       = 4,
    SingleDoorBlockToDestroy                       = 8,
    OnlyBlockRotateDoor                            = 16,
    OnlyBlockMoveDoor                              = 32,
    EBlockDoorType_MAX                             = 33

};


// Enum  /Script/AClient.EDoorBlockType
enum class EDoorBlockType : uint8_t
{
    Block                                          = 0,
    Push                                           = 1,
    EDoorBlockType_MAX                             = 2

};


// Enum  /Script/AClient.EDoorTranslateType
enum class EDoorTranslateType : uint8_t
{
    X                                              = 0,
    Y                                              = 1,
    Z                                              = 2,
    EDoorTranslateType_MAX                         = 3

};


// Enum  /Script/AClient.EDoorRotateType
enum class EDoorRotateType : uint8_t
{
    Yaw                                            = 0,
    Roll                                           = 1,
    Pitch                                          = 2,
    EDoorRotateType_MAX                            = 3

};


// Enum  /Script/AClient.EDoorMoveType
enum class EDoorMoveType : uint8_t
{
    Rotate                                         = 0,
    Translate                                      = 1,
    EDoorMoveType_MAX                              = 2

};


// Enum  /Script/AClient.EDrugRecommendShieldType
enum class EDrugRecommendShieldType : uint8_t
{
    eNotEquipShield                                = 0,
    eEquipNormalShield                             = 1,
    eEquipGoldShield                               = 2,
    EDrugRecommendShieldType_MAX                   = 3

};


// Enum  /Script/AClient.EDrugRecommendType
enum class EDrugRecommendType : uint8_t
{
    Health                                         = 0,
    Shield                                         = 1,
    Both                                           = 2,
    EDrugRecommendType_MAX                         = 3

};


// Enum  /Script/AClient.EDynamicItemSpawnType
enum class EDynamicItemSpawnType : uint8_t
{
    None                                           = 0,
    Region                                         = 1,
    FullCreate                                     = 2,
    EDynamicItemSpawnType_MAX                      = 3

};


// Enum  /Script/AClient.EGnyxLightType
enum class EGnyxLightType : uint8_t
{
    LightNone                                      = 0,
    DirLight                                       = 1,
    SkyLight                                       = 2,
    SpotLight                                      = 3,
    EGnyxLightType_MAX                             = 4

};


// Enum  /Script/AClient.EPathMoveFindPathMode
enum class EPathMoveFindPathMode : uint8_t
{
    None                                           = 0,
    Dir                                            = 1,
    Location                                       = 2,
    Spline                                         = 3,
    MultiSplinePath                                = 4,
    EPathMoveFindPathMode_MAX                      = 5

};


// Enum  /Script/AClient.EMultiPathType
enum class EMultiPathType : uint8_t
{
    PrePath                                        = 0,
    CurrentPath                                    = 1,
    NextPath                                       = 2,
    EMultiPathType_MAX                             = 3

};


// Enum  /Script/AClient.EPathMoveDir
enum class EPathMoveDir : uint8_t
{
    Forward                                        = 0,
    Reverse                                        = 1,
    EPathMoveDir_MAX                               = 2

};


// Enum  /Script/AClient.EMovableMode
enum class EMovableMode : uint8_t
{
    Follow                                         = 0,
    Stay                                           = 1,
    EMovableMode_MAX                               = 2

};


// Enum  /Script/AClient.ERebasedMode
enum class ERebasedMode : uint8_t
{
    Drop                                           = 0,
    Destroy                                        = 1,
    ERebasedMode_MAX                               = 2

};


// Enum  /Script/AClient.EEffectLoaderPickerType
enum class EEffectLoaderPickerType : uint8_t
{
    EELP_Functionality                             = 0,
    EELP_NoFunctionality                           = 1,
    EELP_MAX                                       = 2

};


// Enum  /Script/AClient.EEncomyExchangeType
enum class EEncomyExchangeType : uint8_t
{
    None                                           = 0,
    WeaponSet                                      = 1,
    Item                                           = 2,
    Skill                                          = 3,
    EEncomyExchangeType_MAX                        = 4

};


// Enum  /Script/AClient.EEncomyCostReason
enum class EEncomyCostReason : uint8_t
{
    None                                           = 0,
    Exchange                                       = 1,
    Featustore                                     = 2,
    EEncomyCostReason_MAX                          = 3

};


// Enum  /Script/AClient.EEncomyAddReason
enum class EEncomyAddReason : uint8_t
{
    None                                           = 0,
    SupplyBin                                      = 1,
    MaterialStation                                = 2,
    Kill                                           = 3,
    Assist                                         = 4,
    Start                                          = 5,
    Victory                                        = 6,
    Defeat                                         = 7,
    Return                                         = 8,
    Residue                                        = 9,
    Round                                          = 10,
    GM                                             = 11,
    PlantSuccess                                   = 12,
    DesualSuccess                                  = 13,
    BombBlast                                      = 14,
    NewMaterialStation                             = 15,
    MAX                                            = 16

};


// Enum  /Script/AClient.EShieldMode
enum class EShieldMode : uint8_t
{
    Unknown                                        = 0,
    Hero02                                         = 1,
    Gun                                            = 2,
    Hero02Gun                                      = 3,
    Max                                            = 4

};


// Enum  /Script/AClient.EShieldState
enum class EShieldState : uint8_t
{
    Unknown                                        = 0,
    NormalOpened                                   = 1,
    NormalClosed                                   = 2,
    Recover                                        = 3,
    Broken                                         = 4,
    Max                                            = 5

};


// Enum  /Script/AClient.EEnmityType
enum class EEnmityType : uint8_t
{
    eWeapon                                        = 0,
    eSkill                                         = 1,
    EEnmityType_MAX                                = 2

};


// Enum  /Script/AClient.EEQSBallGeneratorMethod
enum class EEQSBallGeneratorMethod : uint8_t
{
    Random                                         = 0,
    MeshGrid                                       = 1,
    Sphere                                         = 2,
    Isotropy                                       = 3,
    Poisson                                        = 4,
    EEQSBallGeneratorMethod_MAX                    = 5

};


// Enum  /Script/AClient.EEQSCubeGeneratorMethod
enum class EEQSCubeGeneratorMethod : uint8_t
{
    Random                                         = 0,
    MeshGrid                                       = 1,
    Poisson                                        = 2,
    EEQSCubeGeneratorMethod_MAX                    = 3

};


// Enum  /Script/AClient.CircleTypeEnum
enum class CircleTypeEnum : uint8_t
{
    WhiteCircle                                    = 0,
    BlueCircle                                     = 1,
    CircleTypeEnum_MAX                             = 2

};


// Enum  /Script/AClient.EEq140_eq140_eq_BtnOperateType
enum class EEq140_eq140_eq_BtnOperateType : uint8_t
{
    Open                                           = 0,
    Cancel                                         = 1,
    EEq140_eq140_eq_MAX                            = 2

};


// Enum  /Script/AClient.EEvacuateCountDownTipItemBorderType
enum class EEvacuateCountDownTipItemBorderType : uint8_t
{
    Default                                        = 0,
    BorderType2                                    = 1,
    BorderType3                                    = 2,
    EEvacuateCountDownTipItemBorderType_MAX        = 3

};


// Enum  /Script/AClient.EEventType
enum class EEventType : uint8_t
{
    BigEvent                                       = 0,
    SmallEvent                                     = 1,
    SmallMonster                                   = 2,
    HomeIsland                                     = 3,
    BigGolden                                      = 4,
    EEventType_MAX                                 = 5

};


// Enum  /Script/AClient.EEventTriggerMode
enum class EEventTriggerMode : uint8_t
{
    CDTrigger                                      = 0,
    TimedTrigger                                   = 1,
    EEventTriggerMode_MAX                          = 2

};


// Enum  /Script/AClient.EEvacuateGuideEvent
enum class EEvacuateGuideEvent : uint8_t
{
    None                                           = 0,
    PostLogin                                      = 1,
    SafeLanding                                    = 2,
    EnterBoxItemRange                              = 3,
    BoxItemPickedUp                                = 4,
    WindstormPickedUp                              = 5,
    NoEnemiesNearby                                = 6,
    EliteOrBossSpawned                             = 7,
    EvacuatePointRefreshed                         = 8,
    KillEvacuatePointRefreshed                     = 9,
    PlayerDeathWithHighValueLoot                   = 10,
    DifficultyLevelEnterReady                      = 11,
    MAX                                            = 12

};


// Enum  /Script/AClient.EDropOrder
enum class EDropOrder : uint8_t
{
    Random                                         = 0,
    Sequential                                     = 1,
    EDropOrder_MAX                                 = 2

};


// Enum  /Script/AClient.EPatrolModeType
enum class EPatrolModeType : uint8_t
{
    Cycle                                          = 0,
    Reverse                                        = 1,
    EPatrolModeType_MAX                            = 2

};


// Enum  /Script/AClient.EInitModeType
enum class EInitModeType : uint8_t
{
    Idle                                           = 0,
    Patrol                                         = 1,
    EInitModeType_MAX                              = 2

};


// Enum  /Script/AClient.EBrushModeType
enum class EBrushModeType : uint8_t
{
    Fixed                                          = 0,
    FixedSingle                                    = 1,
    Random                                         = 2,
    EBrushModeType_MAX                             = 3

};


// Enum  /Script/AClient.EMonsterInitFightMode
enum class EMonsterInitFightMode : uint8_t
{
    V1                                             = 0,
    V2                                             = 1,
    V3                                             = 2,
    V4                                             = 3,
    EMonsterInitFightMode_MAX                      = 4

};


// Enum  /Script/AClient.EFeLootBallQualityType
enum class EFeLootBallQualityType : uint8_t
{
    None                                           = 0,
    Golden                                         = 1,
    Blue                                           = 2,
    Violet                                         = 3,
    EFeLootBallQualityType_MAX                     = 4

};


// Enum  /Script/AClient.ELootType
enum class ELootType : uint8_t
{
    Default                                        = 0,
    Hero08Static                                   = 1,
    Hero08Dynamic                                  = 2,
    ELootType_MAX                                  = 3

};


// Enum  /Script/AClient.EFireRangeGameType
enum class EFireRangeGameType : uint8_t
{
    None                                           = 0,
    ShootGame                                      = 1,
    SingleTarget                                   = 2,
    GuardWarGame                                   = 3,
    EFireRangeGameType_MAX                         = 4

};


// Enum  /Script/AClient.EFireRangeTargetAttackFrequency
enum class EFireRangeTargetAttackFrequency : uint8_t
{
    Negative                                       = 0,
    Hardly                                         = 1,
    Sometime                                       = 2,
    Often                                          = 3,
    EFireRangeTargetAttackFrequency_MAX            = 4

};


// Enum  /Script/AClient.EFireRangeShootGameType
enum class EFireRangeShootGameType : uint8_t
{
    None                                           = 0,
    Simple                                         = 1,
    Common                                         = 2,
    Miserable                                      = 3,
    Custom                                         = 4,
    SingleTarget                                   = 5,
    Drone                                          = 6,
    SupplyBox                                      = 7,
    Combat                                         = 8,
    Cover                                          = 9,
    GuardWar                                       = 10,
    TargetPractice                                 = 11,
    TargetPractice2                                = 12,
    ChasingPractice                                = 13,
    ChasingPractice2                               = 14,
    TransferPractice                               = 15,
    TransferPractice2                              = 16,
    EFireRangeShootGameType_MAX                    = 17

};


// Enum  /Script/AClient.EFireRangeTargetType
enum class EFireRangeTargetType : uint8_t
{
    SquareTarget                                   = 0,
    Character                                      = 1,
    LootDrone                                      = 2,
    Hero11Drone                                    = 3,
    EFireRangeTargetType_MAX                       = 4

};


// Enum  /Script/AClient.EFireRangeEndCondition
enum class EFireRangeEndCondition : uint8_t
{
    CountdownEnd                                   = 1,
    PlayerDie                                      = 2,
    AchieveEnoughScore                             = 4,
    ShootEnoughTarget                              = 8,
    EFireRangeEndCondition_MAX                     = 9

};


// Enum  /Script/AClient.EFireRangeTargetPostureType
enum class EFireRangeTargetPostureType : uint8_t
{
    Stand                                          = 0,
    Crouch                                         = 1,
    Sliding                                        = 2,
    ADS                                            = 3,
    PostureRand                                    = 4,
    EFireRangeTargetPostureType_MAX                = 5

};


// Enum  /Script/AClient.EFireRangeTargetHealthType
enum class EFireRangeTargetHealthType : uint8_t
{
    Default                                        = 0,
    Unlimited                                      = 1,
    EFireRangeTargetHealthType_MAX                 = 2

};


// Enum  /Script/AClient.EFireRangeTargetGaitType
enum class EFireRangeTargetGaitType : uint8_t
{
    Idle                                           = 0,
    ADS                                            = 1,
    Walk                                           = 2,
    Run                                            = 3,
    EFireRangeTargetGaitType_MAX                   = 4

};


// Enum  /Script/AClient.EInGameFloatvcUI
enum class EInGameFloatvcUI : uint8_t
{
    Joystick                                       = 0,
    KeyMode                                        = 1,
    EInGameFloatvcUI_MAX                           = 2

};


// Enum  /Script/AClient.EFlootShipZiplineType
enum class EFlootShipZiplineType : uint8_t
{
    None                                           = 0,
    Left                                           = 1,
    Right                                          = 2,
    Back                                           = 3,
    EFlootShipZiplineType_MAX                      = 4

};


// Enum  /Script/AClient.EFlootShipAnimationState
enum class EFlootShipAnimationState : uint8_t
{
    None                                           = 0,
    Horizontal                                     = 1,
    Convert                                        = 2,
    Landing                                        = 3,
    EFlootShipAnimationState_MAX                   = 4

};


// Enum  /Script/AClient.EFlyingSkeletonState
enum class EFlyingSkeletonState : uint8_t
{
    Init                                           = 0,
    RiseUp                                         = 1,
    PrePatrol                                      = 2,
    Patrol                                         = 3,
    Chase                                          = 4,
    Fall                                           = 5,
    PreExplosion                                   = 6,
    End                                            = 7,
    EFlyingSkeletonState_MAX                       = 8

};


// Enum  /Script/AClient.EFollowState
enum class EFollowState : uint8_t
{
    None                                           = 0,
    Leader                                         = 1,
    Follower                                       = 2,
    EFollowState_MAX                               = 3

};


// Enum  /Script/AClient.EGamblingMachineMesType
enum class EGamblingMachineMesType : uint8_t
{
    Succeed                                        = 0,
    NoSpawableItems                                = 1,
    NoUseTimes                                     = 2,
    PlayerNoUseTimes                               = 3,
    InUse                                          = 4,
    CDCooling                                      = 5,
    Error                                          = 6,
    EGamblingMachineMesType_MAX                    = 7

};


// Enum  /Script/AClient.EAirDropAreaType
enum class EAirDropAreaType : uint8_t
{
    None                                           = 0,
    RoundStart                                     = 1,
    RoundLessen                                    = 2,
    Max                                            = 3

};


// Enum  /Script/AClient.EAirDropActorType
enum class EAirDropActorType : uint8_t
{
    None                                           = 0,
    Normal                                         = 1,
    Featustore                                     = 2,
    Beacon                                         = 3,
    Max                                            = 4

};


// Enum  /Script/AClient.EAirDropType
enum class EAirDropType : uint8_t
{
    None                                           = 0,
    RoundStart                                     = 1,
    RoundLessen                                    = 2,
    Max                                            = 3

};


// Enum  /Script/AClient.EBreakCaptureCamp
enum class EBreakCaptureCamp : uint8_t
{
    None                                           = 0,
    Attacker                                       = 1,
    Defender                                       = 2,
    EBreakCaptureCamp_MAX                          = 3

};


// Enum  /Script/AClient.EGameModeType
enum class EGameModeType : uint8_t
{
    None                                           = 0,
    BR_Mode                                        = 1,
    TDM_Mode                                       = 2,
    Break_Mode                                     = 3,
    Evacuate_Mode                                  = 4,
    CowDefense_Mode                                = 5,
    EGameModeType_MAX                              = 6

};


// Enum  /Script/AClient.EPlayerExitMode
enum class EPlayerExitMode : uint8_t
{
    RPCExit                                        = 0,
    SyncOrTimeOutExit                              = 1,
    EPlayerExitMode_MAX                            = 2

};


// Enum  /Script/AClient.EPlayerExitHealthState
enum class EPlayerExitHealthState : uint8_t
{
    Normal                                         = 0,
    Dying                                          = 1,
    Respawing                                      = 2,
    Dead                                           = 3,
    EPlayerExitHealthState_MAX                     = 4

};


// Enum  /Script/AClient.EPlayerExitState
enum class EPlayerExitState : uint8_t
{
    BornIsLand                                     = 0,
    PlaneAndParachute                              = 1,
    Fighting                                       = 2,
    EPlayerExitState_MAX                           = 3

};


// Enum  /Script/AClient.EBanHandleType
enum class EBanHandleType : uint8_t
{
    QuitGame                                       = 1,
    NotifyTips                                     = 2,
    ReturnLaunch                                   = 3,
    ReturnLobby                                    = 4,
    EndGame                                        = 5,
    EBanHandleType_MAX                             = 6

};


// Enum  /Script/AClient.EGameMatchType
enum class EGameMatchType : uint8_t
{
    None                                           = 0,
    Match                                          = 1,
    Rating                                         = 2,
    PrivateRoom                                    = 3,
    EGameMatchType_MAX                             = 4

};


// Enum  /Script/AClient.EPerspectiveType
enum class EPerspectiveType : uint8_t
{
    Fpp                                            = 1,
    Tpp                                            = 2,
    EPerspectiveType_MAX                           = 3

};


// Enum  /Script/AClient.EDsFunctionId
enum class EDsFunctionId : uint8_t
{
    ShadowHero08                                   = 1,
    NaviGuide                                      = 2,
    MLAILevel                                      = 3,
    AutoPathFinding                                = 4,
    AIDirector                                     = 5,
    EDsFunctionId_MAX                              = 6

};


// Enum  /Script/AClient.EWeaponPartSlot
enum class EWeaponPartSlot : uint8_t
{
    None                                           = 0,
    Muzzle                                         = 1,
    Magazine                                       = 2,
    Optic                                          = 3,
    Stock                                          = 4,
    HopUp                                          = 5,
    EWeaponPartSlot_MAX                            = 6

};


// Enum  /Script/AClient.EBattleItemSlot
enum class EBattleItemSlot : uint8_t
{
    None                                           = 0,
    Weapon                                         = 1,
    Weapon                                         = 2,
    Backpack                                       = 3,
    Helmet                                         = 4,
    Armor                                          = 5,
    EBattleItemSlot_MAX                            = 6

};


// Enum  /Script/AClient.EDSPlayerExitParams
enum class EDSPlayerExitParams : uint8_t
{
    Normal                                         = 0,
    BornIsland                                     = 1,
    ExitTeamNotFull                                = 2,
    EDSPlayerExitParams_MAX                        = 3

};


// Enum  /Script/AClient.EFlootShipAreaType
enum class EFlootShipAreaType : uint8_t
{
    None                                           = 0,
    SafeZone                                       = 1,
    InsideSafeZone                                 = 2,
    OutSideSafeZone                                = 3,
    All                                            = 4,
    Max                                            = 5

};


// Enum  /Script/AClient.ENewbieScriptReportType
enum class ENewbieScriptReportType : uint8_t
{
    None                                           = 0,
    StartScript                                    = 1,
    EndScript                                      = 2,
    Max                                            = 3

};


// Enum  /Script/AClient.EOperateStatisticsCountType
enum class EOperateStatisticsCountType : uint8_t
{
    RescueTeamMate                                 = 0,
    PickTeamMateBanner                             = 1,
    UseMap_resPawn_m                               = 2,
    UseMap_resPawn_mSuccess                        = 3,
    UseDynamicMap_resPawn_m                        = 4,
    UseDynamicMap_resPawn_mSuccess                 = 5,
    InstallDynamicMap_resPawn_m                    = 6,
    EOperateStatisticsCountType_MAX                = 7

};


// Enum  /Script/AClient.EMPMateNameCampRole
enum class EMPMateNameCampRole : uint8_t
{
    Normal                                         = 0,
    BombCarrier                                    = 1,
    EMPMateNameCampRole_MAX                        = 2

};


// Enum  /Script/AClient.EGamepadMainUIType
enum class EGamepadMainUIType : uint8_t
{
    eNone                                          = 0,
    eLobbyMain                                     = 1,
    eInGameMain                                    = 2,
    eDisableProcessor                              = 3,
    EGamepadMainUIType_MAX                         = 4

};


// Enum  /Script/AClient.EGamepadMouseVisibility
enum class EGamepadMouseVisibility : uint8_t
{
    eNone                                          = 0,
    eVisible                                       = 1,
    eHidden                                        = 2,
    EGamepadMouseVisibility_MAX                    = 3

};


// Enum  /Script/AClient.EGamepadButtonEventType
enum class EGamepadButtonEventType : uint8_t
{
    ePressed                                       = 0,
    eReleased                                      = 1,
    eClicked                                       = 2,
    EGamepadButtonEventType_MAX                    = 3

};


// Enum  /Script/AClient.EGamepadPlayerStateType
enum class EGamepadPlayerStateType : uint8_t
{
    eNone                                          = 0,
    eNormal                                        = 1,
    eDying                                         = 2,
    eRescuing                                      = 3,
    eRescuingSelf                                  = 4,
    eRescuingOther                                 = 5,
    eDoFinisher                                    = 6,
    eBeFinisher                                    = 7,
    eRespawning                                    = 8,
    eRespawnTimeout                                = 9,
    eRespawnTeammate                               = 10,
    eDead                                          = 11,
    eMax                                           = 12,
    eUnknown                                       = 13,
    EGamepadPlayerStateType_MAX                    = 14

};


// Enum  /Script/AClient.EGamepadProcessorType
enum class EGamepadProcessorType : uint8_t
{
    eNone                                          = 0,
    eMain                                          = 1,
    eBackpack                                      = 2,
    eMouseControl                                  = 3,
    ePing                                          = 4,
    eTurnTable                                     = 5,
    ePickUp                                        = 6,
    eMax                                           = 7,
    EGamepadProcessorType_MAX                      = 8

};


// Enum  /Script/AClient.EReplayType
enum class EReplayType : uint8_t
{
    EReplay_None                                   = 0,
    EReplay_Death                                  = 1,
    EReplay_Complete                               = 2,
    EReplay_Http                                   = 3,
    EReplay_MAX                                    = 4

};


// Enum  /Script/AClient.InGameRegionType
enum class InGameRegionType : uint8_t
{
    None                                           = 0,
    PickUpItem                                     = 1,
    TombBox                                        = 2,
    TrainSupply                                    = 3,
    Max                                            = 4

};


// Enum  /Script/AClient.EMultiplayerUIStatus
enum class EMultiplayerUIStatus : uint8_t
{
    None                                           = 0,
    RoundBegin                                     = 1,
    LoadoutChoose                                  = 2,
    ReadyCountdown                                 = 3,
    EMultiplayerUIStatus_MAX                       = 4

};


// Enum  /Script/AClient.ESelectExtraType
enum class ESelectExtraType : uint8_t
{
    None                                           = 0,
    ExtraSlot                                      = 1,
    ExtraSlot1                                     = 2,
    ExtraSlot2                                     = 3,
    ExtraSlot3                                     = 4,
    ESelectExtraType_MAX                           = 5

};


// Enum  /Script/AClient.ESelectLegendRandomMode
enum class ESelectLegendRandomMode : uint8_t
{
    Off                                            = 0,
    AllSame                                        = 1,
    AllDifferent                                   = 2,
    TeamDifferent                                  = 3,
    ESelectLegendRandomMode_MAX                    = 4

};


// Enum  /Script/AClient.EColosseumTipsAreaType
enum class EColosseumTipsAreaType : uint8_t
{
    TotalArea                                      = 0,
    InBounding                                     = 1,
    InTriggerArea                                  = 2,
    EColosseumTipsAreaType_MAX                     = 3

};


// Enum  /Script/AClient.ColosseumTipsType
enum class ColosseumTipsType : uint8_t
{
    Tips                                           = 0,
    CountDownType                                  = 1,
    ColosseumTipsType_MAX                          = 2

};


// Enum  /Script/AClient.EWinterWarfareActivateState
enum class EWinterWarfareActivateState : uint8_t
{
    None                                           = 0,
    WaitForActivate                                = 1,
    Activate                                       = 2,
    Max                                            = 3

};


// Enum  /Script/AClient.EScoringReason
enum class EScoringReason : uint8_t
{
    Default                                        = 0,
    RoundEnd                                       = 1,
    Kill                                           = 2,
    Ace                                            = 3,
    Destroy                                        = 4,
    Defuse                                         = 5,
    CapturePoint                                   = 6,
    NoEnmey                                        = 7,
    EScoringReason_MAX                             = 8

};


// Enum  /Script/AClient.EDataStatisticsType
enum class EDataStatisticsType : uint8_t
{
    None                                           = 0,
    SecAntiData                                    = 1,
    SecAtackFlow                                   = 2,
    SecHurtFlow                                    = 3,
    SecReviveFlow                                  = 4,
    SecPlayerWatchBattleFlow                       = 5,
    SecWatchSpectatingFlow                         = 6,
    SecGameEndWatchFlow                            = 7,
    SecCircleFlow                                  = 8,
    SecJumpFlow                                    = 9,
    SecClientNetworkFlow                           = 10,
    SecPlayerMoveRouteFlow                         = 11,
    SecMrpcsFlow                                   = 12,
    SecRoundLeftFlow                               = 13,
    BotFlow                                        = 14,
    OP_TutorialFlow                                = 15,
    RandomFightResult                              = 16,
    PlayerRangeEndFlow                             = 17,
    ItemPickDropFlow                               = 18,
    ZoneLootFlow                                   = 19,
    ZoneLootCombineFlow                            = 20,
    DSFPSFlow                                      = 21,
    PlayerReconnectBattleFlow                      = 22,
    AirlineFlow                                    = 23,
    CircleDataFlow                                 = 24,
    PlayerJumpFlow                                 = 25,
    PingFlow                                       = 26,
    WeaponFlow                                     = 27,
    WeaponDetailAttachFlow                         = 28,
    DSPlayerChatFlow                               = 29,
    DSEventChatEndFlow                             = 30,
    DSVoiceReportFlow                              = 31,
    ItemUseFlow                                    = 32,
    ThrowingFlow                                   = 33,
    SignalChangeFlow                               = 34,
    PickBeaconFlow                                 = 35,
    BackpackItemFlow                               = 36,
    MapRespawFlow                                  = 37,
    LegendAddendaDsFlow                            = 38,
    BRChooseLegendFlow                             = 39,
    TrainRunFlow                                   = 40,
    TrainOperationFlow                             = 41,
    PlayerTrainFlow                                = 42,
    PlayerMove                                     = 43,
    PlayerStateFlow                                = 44,
    AIMonitorFlow                                  = 45,
    AISystemFlow                                   = 46,
    ZipLineFlow                                    = 47,
    Hero11DroneFlow                                = 48,
    AirDropFlow                                    = 49,
    AirDropDataFlow                                = 50,
    FatPoiBinFlow                                  = 51,
    FatPoiPlayerFlow                               = 52,
    PlayerExitGame                                 = 53,
    Hero04Flow                                     = 54,
    LegendSkillGuideFlow                           = 55,
    SkillFlow                                      = 56,
    Hero05Flow                                     = 57,
    DimensionalRiftFlow                            = 58,
    IntoVoidFlow                                   = 59,
    GameStat                                       = 60,
    DronesFlow                                     = 61,
    RollerFlow                                     = 62,
    PawnStateStatistics                            = 63,
    MPRoundEndFlow                                 = 64,
    MPRoundFlow                                    = 65,
    SecurityScoreFlow                              = 66,
    ApplyMidJoinFlow                               = 67,
    EachHarvesterFlow                              = 68,
    LootBinFlow                                    = 69,
    EQ200Flow                                      = 70,
    RoundEquipFlow                                 = 71,
    AIEventFlow                                    = 72,
    GameReplayFlow                                 = 73,
    Hero13UltimateFlow                             = 74,
    VoiceEventState                                = 75,
    RespawnNextLifeFlow                            = 76,
    Hero41Flow                                     = 77,
    WeaponUseTimeFlow                              = 78,
    PlayerScriptGameFlow                           = 79,
    Hero17Flow                                     = 80,
    Hero15Flow                                     = 81,
    BattleBehaviorFlow                             = 82,
    TTKBehaviorFlow                                = 83,
    DirectorSpawnFlow                              = 84,
    DirectorAICareerFlow                           = 85,
    DirectorTargetCareerFlow                       = 86,
    FireRateFlow                                   = 87,
    AISystemEventFlow                              = 88,
    Hero53Flow                                     = 89,
    AITestAlarmFlow                                = 90,
    SingleShotCollectFlow                          = 91,
    ActionBehaviorFlow                             = 92,
    TrainLotteryFlow                               = 93,
    GlobalBehaviorFlow                             = 94,
    Hero54Flow                                     = 95,
    Hero52Flow                                     = 96,
    Hero02Flow                                     = 97,
    Hero09Flow                                     = 98,
    EnterBirthIslandFlow                           = 99,
    LevelBirthIslandFlow                           = 100,
    PlayerCheatReportFlow                          = 101,
    AntigravityTowerFlow                           = 102,
    ContestPersonalInformation                     = 103,
    DetectCoverDamageFlow                          = 104,
    DelayMoveStatistics                            = 105,
    RescueFlow                                     = 106,
    Hero11UltimateFlow                             = 107,
    Hero02UltimateFlow                             = 108,
    Hero06Flow                                     = 109,
    Hero03TacticalFlow                             = 110,
    MatchCircleDataFlow                            = 111,
    GravityCannonFlow                              = 112,
    MeleeAttackFlow                                = 113,
    PacketSizeFlow                                 = 114,
    SaveMoneyTargetCareerFlow                      = 115,
    CharacterBlockFlow                             = 116,
    SuperHeroExpFlow                               = 117,
    BunkerFlow                                     = 118,
    Hero07UltimateFlow                             = 119,
    Hero07TacticalFlow                             = 120,
    SaveMoneyWalletFlow                            = 121,
    SaveMoneyATMFlow                               = 122,
    CameraModeFlow                                 = 123,
    FPPFlow                                        = 124,
    VehicleFlow                                    = 125,
    VehicleEnergyUseUpFlow                         = 126,
    DecorationFlow                                 = 127,
    Hero14Flow                                     = 128,
    RaceVehicleFlow                                = 129,
    Max                                            = 130

};


// Enum  /Script/AClient.EReportFilterStage
enum class EReportFilterStage : uint8_t
{
    None                                           = 0,
    BirthIsland                                    = 1,
    EReportFilterStage_MAX                         = 2

};


// Enum  /Script/AClient.EGeneralPosWidgetState
enum class EGeneralPosWidgetState : uint8_t
{
    None                                           = 0,
    RangeTrigger                                   = 1,
    ScopeOpenedAndRangeTriger                      = 2,
    Normal                                         = 3,
    Invisible                                      = 4,
    Covered                                        = 5,
    OutViewport                                    = 6,
    EGeneralPosWidgetState_MAX                     = 7

};


// Enum  /Script/AClient.EGNBlackboardValueType
enum class EGNBlackboardValueType : uint8_t
{
    EValueType_Invalid                             = 0,
    EValueType_Bool                                = 1,
    EValueType_Class                               = 2,
    EValueType_Enum                                = 3,
    EValueType_Float                               = 4,
    EValueType_Int                                 = 5,
    EValueType_Name                                = 6,
    EValueType_Object                              = 7,
    EValueType_Rotator                             = 8,
    EValueType_String                              = 9,
    EValueType_Vector                              = 10,
    EValueType_MAX                                 = 11

};


// Enum  /Script/AClient.EAsyncLoadPriority
enum class EAsyncLoadPriority : uint8_t
{
    EDefault                                       = 0,
    EAboveLevelStream                              = 1,
    EOtherAvatar                                   = 99,
    ELeadingAvatar                                 = 100,
    EUImage                                        = 101,
    EAsyncLoadPriority_MAX                         = 102

};


// Enum  /Script/AClient.EAdaptationModuleType
enum class EAdaptationModuleType : uint8_t
{
    Common                                         = 0,
    Particle                                       = 1,
    HDRParticle                                    = 2,
    UMGAni                                         = 3,
    CommonBtnUMGAni                                = 4,
    EAdaptationModuleType_MAX                      = 5

};


// Enum  /Script/AClient.EGngameSkinMemMgrSkinType
enum class EGngameSkinMemMgrSkinType : uint8_t
{
    Unknown                                        = 0,
    Hero                                           = 1,
    Weapon                                         = 2,
    Pickup                                         = 3,
    WeaponAttachment                               = 4,
    SuperweapOn_su_                                = 5,
    MaxType                                        = 6,
    EGngameSkinMemMgrSkinType_MAX                  = 7

};


// Enum  /Script/AClient.EGngameSignatureDynamicSoundType
enum class EGngameSignatureDynamicSoundType : uint8_t
{
    Attack                                         = 0,
    Inspect                                        = 1,
    Other                                          = 2,
    EGngameSignatureDynamicSoundType_MAX           = 3

};


// Enum  /Script/AClient.EGngameSignatureDynamicPSCType
enum class EGngameSignatureDynamicPSCType : uint8_t
{
    AttackTail                                     = 0,
    Attack                                         = 1,
    Other                                          = 2,
    EGngameSignatureDynamicPSCType_MAX             = 3

};


// Enum  /Script/AClient.EPawnStateOP
enum class EPawnStateOP : uint8_t
{
    CancelSprint                                   = 0,
    EPawnStateOP_MAX                               = 1

};


// Enum  /Script/AClient.EAIChangeMoveStateReason
enum class EAIChangeMoveStateReason : uint8_t
{
    LowArea                                        = 0,
    Slide                                          = 1,
    Attack                                         = 2,
    SwitchAnimState                                = 3,
    FuncMoveto                                     = 4,
    SCC                                            = 5,
    Max                                            = 6

};


// Enum  /Script/AClient.EAIMaxShieldMode
enum class EAIMaxShieldMode : uint8_t
{
    MaxShield_CurShield                            = 0,
    MaxShield_MaxLevel                             = 1,
    MaxShield_SetValue                             = 2,
    MaxShield_MAX                                  = 3

};


// Enum  /Script/AClient.EAIHearingType
enum class EAIHearingType : uint8_t
{
    None                                           = 0,
    Weapon                                         = 1,
    Footstep                                       = 2,
    Ballistic                                      = 3,
    EAIHearingType_MAX                             = 4

};


// Enum  /Script/AClient.EIndiviAnimContainerType
enum class EIndiviAnimContainerType : uint8_t
{
    None                                           = 0,
    Rescue                                         = 1,
    BeRescued                                      = 2,
    EIndiviAnimContainerType_MAX                   = 3

};


// Enum  /Script/AClient.EWeaponAnimationType
enum class EWeaponAnimationType : uint8_t
{
    WeaponAnimationType_Reload_Charge              = 0,
    WeaponAnimationType_Reload_Tactical            = 1,
    WeaponAnimationType_Pickup                     = 2,
    WeaponAnimationType_Idle                       = 3,
    WeaponAnimationType_DisruptorCharging          = 4,
    WeaponAnimationType_DisruptorChargedLoop       = 5,
    WeaponAnimationType_DisruptorMagazine          = 6,
    WeaponAnimationType_DisruptorMagazineIdle      = 7,
    WeaponAnimationType_Bolt                       = 8,
    WeaponAnimationType_AimBolt                    = 9,
    WeaponAnimationType_SniperBolt                 = 10,
    WeaponAnimationType_Inspect                    = 11,
    WeaponAnimationType_KeepIdlePose               = 12,
    WeaponAnimationType_EnterSprint                = 13,
    WeaponAnimationType_KeepSprintPose             = 14,
    WeaponAnimationType_LeaveSprintInStand         = 15,
    WeaponAnimationType_LeaveSprintInSlide         = 16,
    WeaponAnimationType_EnterZiplineWeapon         = 17,
    WeaponAnimationType_KeepZiplineWeaponPose      = 18,
    WeaponAnimationType_LeaveZiplineWeapon         = 19,
    WeaponAnimationType_PutOn                      = 20,
    WeaponAnimationType_SprintPutOn                = 21,
    WeaponAnimationType_BackIdlePose               = 22,
    WeaponAnimationType_MeleeAttackBack            = 23,
    WeaponAnimationType_SprintMeleeAttackBack      = 24,
    WeaponAnimationType_SwitchToStand              = 25,
    WeaponAnimationType_SwitchToCrouch             = 26,
    WeaponAnimationType_Slide_Loop                 = 27,
    WeaponAnimationType_GunFire                    = 28,
    WeaponAnimationType_Max                        = 29

};


// Enum  /Script/AClient.ECharAnimClimbOverType
enum class ECharAnimClimbOverType : uint8_t
{
    Below                                          = 0,
    Level                                          = 1,
    Above                                          = 2,
    High                                           = 3,
    Hanging                                        = 4,
    ECharAnimClimbOverType_MAX                     = 5

};


// Enum  /Script/AClient.ECharAnimRescueType
enum class ECharAnimRescueType : uint8_t
{
    None                                           = 0,
    Rescuing                                       = 1,
    RescuingOther                                  = 2,
    RescuingSelf                                   = 3,
    ECharAnimRescueType_MAX                        = 4

};


// Enum  /Script/AClient.ECharAnimDeadType
enum class ECharAnimDeadType : uint8_t
{
    Normal                                         = 0,
    DyingDead                                      = 1,
    ECharAnimDeadType_MAX                          = 2

};


// Enum  /Script/AClient.ECharAnimSkillHandType
enum class ECharAnimSkillHandType : uint8_t
{
    None                                           = 0,
    Left                                           = 1,
    Right                                          = 2,
    Both                                           = 3,
    ECharAnimSkillHandType_MAX                     = 4

};


// Enum  /Script/AClient.ECharParachuteAnimType
enum class ECharParachuteAnimType : uint8_t
{
    ECharParachuteAnimType_XGnglIdering            = 0,
    ECharParachuteAnimType_YGnglIdering            = 1,
    ECharParachuteAnimType_PreOpen                 = 2,
    ECharParachuteAnimType_PostOpen                = 3,
    ECharParachuteAnimType_Land                    = 4,
    ECharParachuteAnimType_Wing                    = 5,
    ECharParachuteAnimType_OpenAirCraft            = 6,
    ECharParachuteAnimType_CloseAirCraft           = 7,
    ECharParachuteAnimType_OverrideXGnglIdering    = 8,
    ECharParachuteAnimType_OverrideYGnglIdering    = 9,
    ECharParachuteAnimType_Max                     = 10

};


// Enum  /Script/AClient.ECharAnimEventType
enum class ECharAnimEventType : uint8_t
{
    ECharAnimEvent_PoseChange                      = 0,
    ECharAnimEvent_PickUp                          = 1,
    ECharAnimEvent_Fire                            = 2,
    ECharAnimEvent_Reload                          = 3,
    ECharAnimEvent_Switch                          = 4,
    ECharAnimEvent_Bolt                            = 7,
    ECharAnimEvent_Max                             = 8

};


// Enum  /Script/AClient.EVehicleSeatType
enum class EVehicleSeatType : uint8_t
{
    EVehSeatType_Driver                            = 0,
    EVehSeatType_Left                              = 1,
    EVehSeatType_Right                             = 2,
    EVehSeatType_Max                               = 3

};


// Enum  /Script/AClient.EVehicleType
enum class EVehicleType : uint8_t
{
    EVehType_Buggy                                 = 0,
    EVehType_UAZ                                   = 1,
    EVehType_Motorcycle                            = 2,
    EVehType_Dacia                                 = 3,
    EVehType_PG                                    = 4,
    EVehType_Max                                   = 5

};


// Enum  /Script/AClient.ECharacterJumpType
enum class ECharacterJumpType : uint8_t
{
    ECharJump_ADSForward                           = 0,
    ECharJump_Forward                              = 1,
    ECharJump_Back                                 = 2,
    ECharJump_SprintForward                        = 3,
    ECharJump_CrouchForward                        = 4,
    ECharJump_CrouchBackward                       = 5,
    ECharJump_SightADSForward                      = 6,
    ECharJump_Max                                  = 7

};


// Enum  /Script/AClient.ECharacterJumpPhase
enum class ECharacterJumpPhase : uint8_t
{
    EJumpPhase_PreJump                             = 0,
    EJumpPhase_FallLoop0                           = 1,
    EJumpPhase_Land0                               = 2,
    EJumpPhase_Land1                               = 3,
    EJumpPhase_LandingStiffly                      = 4,
    EJumpPhase_Max                                 = 5

};


// Enum  /Script/AClient.ECharacterCameraPoseType
enum class ECharacterCameraPoseType : uint8_t
{
    Stand                                          = 0,
    Crouch                                         = 1,
    Dying                                          = 2,
    Sliding                                        = 3,
    AirCrouch                                      = 4,
    InCatMode                                      = 5,
    Max                                            = 6

};


// Enum  /Script/AClient.EWeaponAnimListType
enum class EWeaponAnimListType : uint8_t
{
    WeaponTPP                                      = 1,
    WeaponFPP                                      = 2,
    SecondaryWeaponTPP                             = 3,
    SecondaryWeaponFPP                             = 4,
    WeaponJumpTPP                                  = 5,
    WeaponJumpFPP                                  = 6,
    SecondaryWeaponJumpTPP                         = 7,
    SecondaryWeaponJumpFPP                         = 8,
    WeaponViewTPP                                  = 9,
    WeaponViewFPP                                  = 10,
    Max                                            = 11

};


// Enum  /Script/AClient.ECharaAnimListType
enum class ECharaAnimListType : uint8_t
{
    ECharaAnimListType_TPP                         = 1,
    ECharaAnimListType_FPP                         = 2,
    ECharaAnimListType_Jump                        = 3,
    ECharaAnimListType_JumpFPP                     = 4,
    ECharaAnimListType_Parachute                   = 5,
    ECharaAnimListType_WeaponView_TPP              = 6,
    ECharaAnimListType_WeaponView_FPP              = 7,
    ECharaAnimListType_PlayerView_TPP              = 8,
    ECharaAnimListType_PlayerView_FPP              = 9,
    ECharaAnimListType_Max                         = 10

};


// Enum  /Script/AClient.EGnyxAnimBPType
enum class EGnyxAnimBPType : uint8_t
{
    EGnyxAnimBP_None                               = 0,
    EGnyxAnimBP_TPP                                = 1,
    EGnyxAnimBP_FPP                                = 2,
    EGnyxAnimBP_Max                                = 3

};


// Enum  /Script/AClient.ESightType
enum class ESightType : uint8_t
{
    SightIron                                      = 0,
    SightX1                                        = 1,
    SightX2                                        = 2,
    SightX3                                        = 3,
    SightX4                                        = 4,
    SightX6                                        = 6,
    SightX8                                        = 8,
    SightX10                                       = 10,
    SightMax                                       = 99,
    ESightType_MAX                                 = 100

};


// Enum  /Script/AClient.EAnimSignificanceType
enum class EAnimSignificanceType : uint8_t
{
    Level                                          = 0,
    Level                                          = 1,
    Level                                          = 2,
    Level_MAX                                      = 3

};


// Enum  /Script/AClient.ECharPostSkillAOType
enum class ECharPostSkillAOType : uint8_t
{
    None                                           = 0,
    SkillCastInCommon                              = 1,
    SkillCastInHero04_he_                          = 2,
    SkillAoInStand                                 = 3,
    SkillAoInCrouch                                = 4,
    SkillAoInZiplineHorizontal                     = 5,
    SkillAoInZiplineVertical                       = 6,
    ECharPostSkillAOType_MAX                       = 7

};


// Enum  /Script/AClient.ECharZipLineState
enum class ECharZipLineState : uint8_t
{
    None                                           = 0,
    ZiplineVertical                                = 1,
    ZiplineNotLeftHand                             = 2,
    NearWallRootOffset                             = 3,
    ECharZipLineState_MAX                          = 4

};


// Enum  /Script/AClient.ECharAnimSpecicalState
enum class ECharAnimSpecicalState : uint8_t
{
    Normal                                         = 0,
    Rescuing                                       = 1,
    Parachute                                      = 2,
    Climb                                          = 3,
    NearDeath                                      = 4,
    Zipline                                        = 5,
    ECharAnimSpecicalState_MAX                     = 6

};


// Enum  /Script/AClient.EPawnHoldWeaponType
enum class EPawnHoldWeaponType : uint8_t
{
    Unarmed                                        = 0,
    Pistol                                         = 1,
    LongGun                                        = 2,
    EPawnHoldWeaponType_MAX                        = 3

};


// Enum  /Script/AClient.ELODDeviceGrade
enum class ELODDeviceGrade : uint8_t
{
    VeryLow                                        = 0,
    Low                                            = 1,
    Middle                                         = 2,
    High                                           = 3,
    ELODDeviceGrade_MAX                            = 4

};


// Enum  /Script/AClient.ESimulateSequenceNotifyType
enum class ESimulateSequenceNotifyType : uint8_t
{
    HumanMove                                      = 0,
    HumanSprint                                    = 1,
    AndroidMove                                    = 2,
    AndroidSprint                                  = 3,
    ESimulateSequenceNotifyType_MAX                = 4

};


// Enum  /Script/AClient.EGnyxFootprintsType
enum class EGnyxFootprintsType : uint8_t
{
    Footprints_None                                = 0,
    Footprints_LeftFoot                            = 1,
    Footprints_RightFoot                           = 2,
    Footprints_LeftKnee                            = 3,
    Footprints_RightKnee                           = 4,
    Footprints_MAX                                 = 5

};


// Enum  /Script/AClient.EAnimNotifySoundGroupType
enum class EAnimNotifySoundGroupType : uint8_t
{
    None                                           = 0,
    Default                                        = 1,
    FPP                                            = 2,
    TPP                                            = 3,
    EAnimNotifySoundGroupType_MAX                  = 4

};


// Enum  /Script/AClient.EAnimNotifySoundPlayType
enum class EAnimNotifySoundPlayType : uint8_t
{
    EANSP_FPP                                      = 0,
    EANSP_TPP                                      = 1,
    EANSP_MAX                                      = 2

};


// Enum  /Script/AClient.ESoundModuleEffectType
enum class ESoundModuleEffectType : uint8_t
{
    None                                           = 0,
    GunFire                                        = 1,
    UnGunFire                                      = 2,
    ESoundModuleEffectType_MAX                     = 3

};


// Enum  /Script/AClient.EAssetsPreLoadMode
enum class EAssetsPreLoadMode : uint8_t
{
    eNone                                          = 0,
    eLogin                                         = 1,
    eLobby                                         = 2,
    eLoading                                       = 3,
    eFightting                                     = 4,
    eMax                                           = 5,
    EAssetsPreLoadMode_MAX                         = 6

};


// Enum  /Script/AClient.EAudioAmbientZoneAction
enum class EAudioAmbientZoneAction : uint8_t
{
    In                                             = 0,
    Out                                            = 1,
    EAudioAmbientZoneAction_MAX                    = 2

};


// Enum  /Script/AClient.EHouseSoundType
enum class EHouseSoundType : uint8_t
{
    None                                           = 0,
    Small_Dull                                     = 1,
    Small_Bright                                   = 2,
    Med_Dull                                       = 3,
    Med_Bright                                     = 4,
    Large_Dull                                     = 5,
    Large_Bright                                   = 6,
    EHouseSoundType_MAX                            = 7

};


// Enum  /Script/AClient.EStateSound
enum class EStateSound : uint8_t
{
    None                                           = 0,
    PlaySlide                                      = 1,
    StopSlide                                      = 2,
    RideZipline                                    = 3,
    DownZipline                                    = 4,
    LoopZipline                                    = 5,
    RushZipline                                    = 6,
    PlayStand                                      = 7,
    PlayCrouch                                     = 8,
    LandingLight                                   = 9,
    LandingHard                                    = 10,
    PlayClimb                                      = 11,
    PlayFallingDown                                = 12,
    StopFallingDown                                = 13,
    Jump                                           = 14,
    ClimbBigJump                                   = 15,
    Hanging                                        = 16,
    ClimbOver                                      = 17,
    PlaySlideBoxDropIn                             = 18,
    StopSlideBoxDropIn                             = 19,
    PlaySlideBoxAir                                = 20,
    EStateSound_MAX                                = 21

};


// Enum  /Script/AClient.EValidityTimeScaleChangeType
enum class EValidityTimeScaleChangeType : uint8_t
{
    None                                           = 0,
    ApplyNum                                       = 1,
    EValidityTimeScaleChangeType_MAX               = 2

};


// Enum  /Script/AClient.EViewTargetAddBuffRole
enum class EViewTargetAddBuffRole : uint8_t
{
    Disabled                                       = 0,
    ViewTarget_Self                                = 1,
    ViewTarget_Enemy                               = 2,
    ViewTarget_Friend                              = 3,
    ViewTarget_Monster                             = 4,
    EViewTargetAddBuffRole_MAX                     = 5

};


// Enum  /Script/AClient.ESimulateAddBuffRole
enum class ESimulateAddBuffRole : uint8_t
{
    AddBuffRole_All                                = 0,
    AddBuffRole_Self                               = 1,
    AddBuffRole_Firend                             = 2,
    AddBuffRole_Enermy                             = 3,
    AddBuffRole_Monster                            = 4,
    AddBuffRole_MAX                                = 5

};


// Enum  /Script/AClient.EActionActiveRole
enum class EActionActiveRole : uint8_t
{
    ACTIVE_ALL                                     = 0,
    ACTIVE_SELF                                    = 1,
    ACTIVE_TEAM                                    = 2,
    ACTIVE_ENEMY                                   = 3,
    ACTIVE_MONSTER                                 = 4,
    ACTIVE_MAX                                     = 5

};


// Enum  /Script/AClient.EAirJumpStatusForMk
enum class EAirJumpStatusForMk : uint8_t
{
    None                                           = 0,
    Pre                                            = 1,
    Real                                           = 2,
    EAirJumpStatusForMk_MAX                        = 3

};


// Enum  /Script/AClient.EAirJumpStatus
enum class EAirJumpStatus : uint8_t
{
    None                                           = 0,
    Pre                                            = 1,
    Real                                           = 2,
    EAirJumpStatus_MAX                             = 3

};


// Enum  /Script/AClient.EFormulaType
enum class EFormulaType : uint8_t
{
    FORMULA_CURVE_DISTANCE_BETWEEN_OWNER_AND_TARGET = 0,
    FORMULA_CURVE_TIME                             = 1,
    FORMULA_TIME_DELTA                             = 2,
    FORMULA_MAX                                    = 3

};


// Enum  /Script/AClient.EAttrType
enum class EAttrType : uint8_t
{
    ATTR_STEPBYSTEP                                = 0,
    ATTR_INSTANT                                   = 1,
    ATTR_FORMULA                                   = 2,
    ATTR_MAX                                       = 3

};


// Enum  /Script/AClient.EModifyCDType
enum class EModifyCDType : uint8_t
{
    Reduce_MaxEnergy                               = 0,
    Reduce_Threshold                               = 1,
    ReduceTo_MaxEnergy                             = 2,
    ReduceTo_Threshold                             = 3,
    Reset                                          = 4,
    EModifyCDType_MAX                              = 5

};


// Enum  /Script/AClient.EPlayUIEffectParamsType
enum class EPlayUIEffectParamsType : uint8_t
{
    EPT_ScalarParameter                            = 0,
    EPT_VectorParameter                            = 1,
    EPT_MAX                                        = 2

};


// Enum  /Script/AClient.ERecoveryEffectType
enum class ERecoveryEffectType : uint8_t
{
    None                                           = 0,
    RecoveryShieldEffect                           = 1,
    ERecoveryEffectType_MAX                        = 2

};


// Enum  /Script/AClient.ERecoveryValuePerSecondChangeType
enum class ERecoveryValuePerSecondChangeType : uint8_t
{
    None                                           = 0,
    ByDefault                                      = 1,
    ByInitDistanceSquared                          = 2,
    ByDistanceSquared                              = 3,
    RecoveryToMax                                  = 4,
    ERecoveryValuePerSecondChangeType_MAX          = 5

};


// Enum  /Script/AClient.EAPBuffRegistEvent
enum class EAPBuffRegistEvent : uint8_t
{
    None                                           = 0,
    TakeDamage                                     = 1,
    EAPBuffRegistEvent_MAX                         = 2

};


// Enum  /Script/AClient.EReloadWeapon
enum class EReloadWeapon : uint8_t
{
    AllWeapon                                      = 0,
    LastWeapon                                     = 1,
    EReloadWeapon_MAX                              = 2

};


// Enum  /Script/AClient.ELegendGenius
enum class ELegendGenius : uint8_t
{
    None                                           = 0,
    Scout                                          = 1,
    Default                                        = 0,
    ELegendGenius_MAX                              = 2

};


// Enum  /Script/AClient.ECameraLerpID
enum class ECameraLerpID : uint8_t
{
    Hunting                                        = 127,
    ECameraLerpID_MAX                              = 128

};


// Enum  /Script/AClient.EViewInputType
enum class EViewInputType : uint8_t
{
    NONE                                           = 0,
    InputFromScreen                                = 1,
    InputFromGyroscope                             = 2,
    InputFromMotionController                      = 3,
    InputFromSimulator                             = 4,
    EViewInputType_MAX                             = 5

};


// Enum  /Script/AClient.EViewControlLimitType
enum class EViewControlLimitType : uint8_t
{
    None                                           = 0,
    LeftRight                                      = 1,
    ViewUp                                         = 2,
    EViewControlLimitType_MAX                      = 3

};


// Enum  /Script/AClient.EViewControlType
enum class EViewControlType : uint8_t
{
    NormalSpeed                                    = 0,
    SpeedupByDistance                              = 1,
    SpeedupBySpeed                                 = 2,
    EViewControlType_MAX                           = 3

};


// Enum  /Script/AClient.EPhoneOrientationControlType
enum class EPhoneOrientationControlType : uint8_t
{
    NONE                                           = 0,
    OnlyAiming                                     = 1,
    Always                                         = 2,
    EPhoneOrientationControlType_MAX               = 3

};


// Enum  /Script/AClient.EButtonPassType
enum class EButtonPassType : uint8_t
{
    None                                           = 0,
    Normal                                         = 1,
    Forbidden                                      = 2,
    EButtonPassType_MAX                            = 3

};


// Enum  /Script/AClient.EMonsterBattlegroundType
enum class EMonsterBattlegroundType : uint8_t
{
    None                                           = 0,
    Evacuate                                       = 1,
    Cow                                            = 2,
    Guide                                          = 3,
    EMonsterBattlegroundType_MAX                   = 4

};


// Enum  /Script/AClient.EMonsterCreateType
enum class EMonsterCreateType : uint8_t
{
    None                                           = 0,
    MonsterSpawnBox                                = 1,
    RuneSkill                                      = 2,
    EMonsterCreateType_MAX                         = 3

};


// Enum  /Script/AClient.EIconType
enum class EIconType : uint8_t
{
    IconNone                                       = 0,
    IconGunFire                                    = 1,
    IconMove                                       = 2,
    IconConsume                                    = 3,
    IconSmallMove                                  = 4,
    IconDJUltimateItem                             = 5,
    IconAndroid                                    = 6,
    IconMove2                                      = 7,
    IconMove3                                      = 8,
    IconMove4                                      = 9,
    IconConsume2                                   = 10,
    IconConsume3                                   = 11,
    IconConsume4                                   = 12,
    MAX_                                           = 13,
    EIconType_MAX                                  = 14

};


// Enum  /Script/AClient.EBuildingType
enum class EBuildingType : uint8_t
{
    BuildingNone                                   = 0,
    BuildingExhibition                             = 1,
    BuildingPet                                    = 2,
    BuildingVehicle                                = 3,
    Max                                            = 4

};


// Enum  /Script/AClient.EPetType
enum class EPetType : uint8_t
{
    PetNone                                        = 0,
    Pet01                                          = 1,
    Pet02                                          = 2,
    Pet03                                          = 3,
    Pet04                                          = 4,
    Pet05                                          = 5,
    EPetType_MAX                                   = 6

};


// Enum  /Script/AClient.EGnyxCameraLerpType
enum class EGnyxCameraLerpType : uint8_t
{
    None                                           = 0,
    CameraRelativeLocation                         = 1,
    CameraRelativeRotation                         = 2,
    SpringArmRelativeLocation                      = 3,
    SpringArmLength                                = 4,
    Fov                                            = 5,
    SeparateFov                                    = 6,
    _Max                                           = 7,
    EGnyxCameraLerpType_MAX                        = 8

};


// Enum  /Script/AClient.EGnyxCameraModifyType
enum class EGnyxCameraModifyType : uint8_t
{
    None                                           = 0,
    Add                                            = 1,
    Multiply                                       = 2,
    MultiplicativeAdd                              = 3,
    Override                                       = 4,
    EGnyxCameraModifyType_MAX                      = 5

};


// Enum  /Script/AClient.ESTECharacterType
enum class ESTECharacterType : uint8_t
{
    Player                                         = 1,
    Zombie                                         = 2,
    ESTECharacterType_MAX                          = 3

};


// Enum  /Script/AClient.EGnyxCharacterShieldLevel
enum class EGnyxCharacterShieldLevel : uint8_t
{
    NONE                                           = 0,
    WhiteArmor                                     = 1,
    BlueArmor                                      = 2,
    PurpleArmor                                    = 3,
    GoldArmor                                      = 4,
    RedArmor                                       = 5,
    GunShield                                      = 6,
    Level7Armor                                    = 7,
    EGnyxCharacterShieldLevel_MAX                  = 8

};


// Enum  /Script/AClient.ESTEScopeType
enum class ESTEScopeType : uint8_t
{
    Normal                                         = 0,
    ProneMove                                      = 1,
    InFold                                         = 2,
    AutoCollapsed                                  = 3,
    ESTEScopeType_MAX                              = 4

};


// Enum  /Script/AClient.ESTEScopeState
enum class ESTEScopeState : uint8_t
{
    ScopeOut                                       = 0,
    ScopeIn                                        = 1,
    ESTEScopeState_MAX                             = 2

};


// Enum  /Script/AClient.ESTEPoseState
enum class ESTEPoseState : uint8_t
{
    Stand                                          = 0,
    Crouch                                         = 1,
    Prone                                          = 2,
    Sprint                                         = 3,
    CrouchSprint                                   = 4,
    Crawl                                          = 5,
    Swim                                           = 6,
    SwimSprint                                     = 7,
    Dying                                          = 8,
    ESTEPoseState_MAX                              = 9

};


// Enum  /Script/AClient.EGnyxCharacterComponentKey
enum class EGnyxCharacterComponentKey : uint8_t
{
    AnimationComponent                             = 2,
    AnimationListComponent                         = 3,
    WeaponAnimationListComponent                   = 4,
    StateManagerComponent                          = 5,
    PropertyComponent                              = 6,
    GnyxCharacterMovementComponent                 = 7,
    EGnyxCharacterComponentKey_MAX                 = 8

};


// Enum  /Script/AClient.EChildNodeTag
enum class EChildNodeTag : uint8_t
{
    EChildNodeTag_None                             = 0,
    EChildNodeTag_WarningNode                      = 1,
    EChildNodeTag_MAX                              = 2

};


// Enum  /Script/AClient.ECharacterSensitivityType
enum class ECharacterSensitivityType : uint8_t
{
    NONE                                           = 0,
    Ability                                        = 1,
    Throw                                          = 2,
    GrappleHookAim                                 = 3,
    GrappleHookMove                                = 4,
    ECharacterSensitivityType_MAX                  = 5

};


// Enum  /Script/AClient.EFPPMeshFreeSource
enum class EFPPMeshFreeSource : uint8_t
{
    NONE                                           = 0,
    SmallEye                                       = 1,
    Hanging                                        = 2,
    Climb                                          = 3,
    ClimbOver                                      = 4,
    Skill                                          = 5,
    EFPPMeshFreeSource_MAX                         = 6

};


// Enum  /Script/AClient.EFreeCameraSource
enum class EFreeCameraSource : uint8_t
{
    NONE                                           = 0,
    SmallEye                                       = 1,
    Movement                                       = 2,
    Skill                                          = 3,
    Rescue                                         = 4,
    BombHandle                                     = 5,
    Hero42_Braid                                   = 6,
    Emoji                                          = 7,
    Parachute                                      = 8,
    Hero50_Attachment                              = 9,
    EFreeCameraSource_MAX                          = 10

};


// Enum  /Script/AClient.ECharacterMoveDir
enum class ECharacterMoveDir : uint8_t
{
    NONE                                           = 0,
    Forward                                        = 1,
    Right                                          = 2,
    Back                                           = 3,
    ECharacterMoveDir_MAX                          = 4

};


// Enum  /Script/AClient.EAnimationParamMovementMode
enum class EAnimationParamMovementMode : uint8_t
{
    EAnimationParamMovementMode_None               = 0,
    EAnimationParamMovementMode_Walking            = 1,
    EAnimationParamMovementMode_NavWalking         = 2,
    EAnimationParamMovementMode_Falling            = 3,
    EAnimationParamMovementMode_Swimming           = 4,
    EAnimationParamMovementMode_Flying             = 5,
    EAnimationParamMovementMode_Climbing           = 6,
    EAnimationParamMovementMode_ClimbingOver       = 7,
    EAnimationParamMovementMode_Hanging            = 8,
    EAnimationParamMovementMode_Sliding            = 9,
    EAnimationParamMovementMode_Custom             = 10,
    EAnimationParamMovementMode_MAX                = 11

};


// Enum  /Script/AClient.ECustomMoveModeType
enum class ECustomMoveModeType : uint8_t
{
    ECustomMoveMode_None                           = 0,
    ECustomMoveMode_Hang                           = 1,
    ECustomMoveMode_ClimbOver                      = 2,
    ECustomMoveMode_Slide                          = 3,
    ECustomMoveMode_GnyxFlying                     = 4,
    ECustomMoveMode_Max                            = 5

};


// Enum  /Script/AClient.EClimbOverFrom
enum class EClimbOverFrom : uint8_t
{
    EClimbOverFrom_Falling                         = 0,
    EClimbOverFrom_Climbing                        = 1,
    EClimbOverFrom_Hanging                         = 2,
    EClimbOverFrom_Max                             = 3

};


// Enum  /Script/AClient.ESlidingFormula
enum class ESlidingFormula : uint8_t
{
    Gravity                                        = 1,
    ExpDecay                                       = 2,
    ConstDecay                                     = 3,
    WantToStopDecay                                = 4,
    PlayerControlAcceleration                      = 5,
    PlayerControlAccelerationAffectDir             = 6,
    ESlidingFormula_MAX                            = 7

};


// Enum  /Script/AClient.EViewControlReason
enum class EViewControlReason : uint8_t
{
    PlayerInput                                    = 1,
    FireRecoil                                     = 2,
    FireSpring                                     = 3,
    AutoAim                                        = 4,
    AutoControl                                    = 5,
    GrappleHook                                    = 6,
    EViewControlReason_MAX                         = 7

};


// Enum  /Script/AClient.EMotionMovementWarpingType
enum class EMotionMovementWarpingType : uint8_t
{
    EMotionMovementWarpingType_None                = 0,
    EMotionMovementWarpingType_EndWarping          = 1,
    EMotionMovementWarpingType_PathWarping         = 2,
    EMotionMovementWarpingType_MAX                 = 3

};


// Enum  /Script/AClient.EMotionMovementLocationProcessingType
enum class EMotionMovementLocationProcessingType : uint8_t
{
    EMotionMovementLocationProcessingType_UseMotionLocation = 0,
    EMotionMovementLocationProcessingType_AddtiveLocation = 1,
    EMotionMovementLocationProcessingType_MAX      = 2

};


// Enum  /Script/AClient.EMotionMovementSimulateMode
enum class EMotionMovementSimulateMode : uint8_t
{
    EMotionMovementSimulateMode_MotionSimulate     = 0,
    EMotionMovementSimulateMode_DRSimulate         = 1,
    EMotionMovementSimulateMode_MAX                = 2

};


// Enum  /Script/AClient.EMotionMovementWarpingNetMode
enum class EMotionMovementWarpingNetMode : uint8_t
{
    EMotionMovementWarpingNetMode_MovementMode     = 0,
    EMotionMovementWarpingNetMode_LocalMotionMode  = 1,
    EMotionMovementWarpingNetMode_MAX              = 2

};


// Enum  /Script/AClient.EAutoCrouchEnter
enum class EAutoCrouchEnter : uint8_t
{
    None                                           = 0,
    Walking                                        = 1,
    EAutoCrouchEnter_MAX                           = 2

};


// Enum  /Script/AClient.EConvertLocationMode
enum class EConvertLocationMode : uint8_t
{
    None                                           = 0,
    ServerToClient                                 = 1,
    ClientToServer                                 = 2,
    EConvertLocationMode_MAX                       = 3

};


// Enum  /Script/AClient.EUploadDebugMsgType
enum class EUploadDebugMsgType : uint8_t
{
    GravityError                                   = 0,
    ErrorFunction                                  = 1,
    SetExternalLocationEveryFrame                  = 2,
    ClientResetPredictionData                      = 3,
    PawnClientRestart                              = 4,
    TrainError                                     = 5,
    LogMsg_Movement                                = 6,
    LogMsg_Weapon                                  = 7,
    EUploadDebugMsgType_MAX                        = 8

};


// Enum  /Script/AClient.EGnyxPostProcessType
enum class EGnyxPostProcessType : uint8_t
{
    None                                           = 0,
    GreyScreen                                     = 1,
    Arc                                            = 2,
    Max                                            = 3

};


// Enum  /Script/AClient.EJoystickUIState
enum class EJoystickUIState : uint8_t
{
    Close                                          = 1,
    Open                                           = 2,
    Auto                                           = 3,
    Lock                                           = 4,
    EJoystickUIState_MAX                           = 5

};


// Enum  /Script/AClient.EGnyxControllerComponentKey
enum class EGnyxControllerComponentKey : uint8_t
{
    DefaultComponent                               = 1,
    StateMachineComp                               = 2,
    BackpackComp                                   = 3,
    LoadoutComp                                    = 4,
    ParachuteComp                                  = 5,
    PlaneComp                                      = 6,
    MagmaRiseComp                                  = 7,
    EGnyxControllerComponentKey_MAX                = 8

};


// Enum  /Script/AClient.EDisplayWeaponStateMode
enum class EDisplayWeaponStateMode : uint8_t
{
    None                                           = 0,
    Idle                                           = 1,
    Fire                                           = 2,
    Reload                                         = 3,
    MagazineMontage                                = 4,
    EDisplayWeaponStateMode_MAX                    = 5

};


// Enum  /Script/AClient.EDynamicMap_resPawn_mState
enum class EDynamicMap_resPawn_mState : uint8_t
{
    Landing                                        = 0,
    Idle                                           = 1,
    Dispose                                        = 2,
    EDynamicMap_resPawn_MAX                        = 3

};


// Enum  /Script/AClient.EEmojiFlowAddendaOpType
enum class EEmojiFlowAddendaOpType : uint8_t
{
    None                                           = 0,
    EmojiUse                                       = 1,
    EmojiLike                                      = 2,
    EmojiLiked                                     = 3,
    EEmojiFlowAddendaOpType_MAX                    = 4

};


// Enum  /Script/AClient.EEmojiFlowAddendaType
enum class EEmojiFlowAddendaType : uint8_t
{
    None                                           = 0,
    EmojiAnimation                                 = 13,
    Emoji3DPaint                                   = 14,
    Emoji2DSprite                                  = 15,
    EEmojiFlowAddendaType_MAX                      = 16

};


// Enum  /Script/AClient.EEmojiType
enum class EEmojiType : uint8_t
{
    NONE                                           = 0,
    Emoji2D                                        = 1,
    EmojiDecal                                     = 2,
    Emoji3D                                        = 3,
    EmojiAnimation                                 = 4,
    DisplayAnimation                               = 5,
    TraditionalSprayPaint                          = 6,
    MAX                                            = 16

};


// Enum  /Script/AClient.EFesecretDoorState
enum class EFesecretDoorState : uint8_t
{
    Break                                          = 0,
    Opening                                        = 1,
    Active                                         = 2,
    EFesecretDoorState_MAX                         = 3

};


// Enum  /Script/AClient.EFesecretGateState
enum class EFesecretGateState : uint8_t
{
    Close                                          = 0,
    Opening                                        = 1,
    Opened                                         = 2,
    EFesecretGateState_MAX                         = 3

};


// Enum  /Script/AClient.ECreditTactics
enum class ECreditTactics : uint8_t
{
    None                                           = 0,
    AddCredit                                      = 1,
    PickUpDistance                                 = 2,
    PickUpCount                                    = 3,
    WeapnBullet                                    = 4,
    WeaponAttachments                              = 5,
    Shoot_ClipBulletNum                            = 10,
    Shoot_FireInterval                             = 11,
    Shoot_FireStartPos                             = 12,
    Shoot_FireEndPos                               = 13,
    Shoot_BulletObstacle                           = 14,
    Shoot_ShootDistance                            = 15,
    Shoot_NoInputViewMove                          = 16,
    Shoot_ChargeLens                               = 17,
    Shoot_TotalBulletNum                           = 18,
    Shoot_BulletID                                 = 19,
    Shoot_DataTimeOut                              = 20,
    Shoot_OverMaxUploadHitNum                      = 21,
    Shoot_BulletPosToImpact                        = 22,
    Shoot_WeaponDistanceToPlayer                   = 23,
    Shoot_CharacterScale                           = 24,
    Shoot_GunThroughWall                           = 25,
    Shoot_ViewDiffBulletDirection                  = 26,
    Shoot_BulletFall                               = 27,
    Shoot_BulletMaxDistance                        = 28,
    Shoot_NoRecoil                                 = 29,
    Shoot_ImPactPointSame                          = 30,
    Shoot_FakeChargeLens                           = 31,
    Shoot_ShootEndBaseInValid                      = 32,
    Shoot_BulletVelocityDiff                       = 33,
    Shoot_AvoidCoverDamage                         = 34,
    Shoot_ShootEndDiffCharacter                    = 35,
    Shoot_ReloadTimeDiff                           = 36,
    Shoot_PowerCheat                               = 37,
    Shoot_PenetrateCharacter                       = 38,
    Shoot_UploadNumNoSame                          = 39,
    Move_SimpleMoveCheat                           = 100,
    Move_ZMoveDistanceCheat                        = 101,
    Move_FallingCheat                              = 102,
    Move_TimeSpeedCheat                            = 103,
    Move_TimeSpeedResetCheat                       = 104,
    Move_PowerCheat                                = 105,
    Move_GrapplingHookCheat                        = 106,
    Move_SyncLaunchCheat                           = 107,
    Move_FlyingCheat                               = 108,
    Move_ExternalForceCheat                        = 109,
    Move_ServerAdjustDistanceError                 = 110,
    Move_LongTimeDiff                              = 111,
    Move_ShootBlock                                = 112,
    Move_SpeedCheat                                = 113,
    Move_AirStagnantCheck                          = 114,
    Parachute_WholeLocationCheckZOver              = 150,
    Parachute_WholeLocationCheckSizeOver           = 151,
    Parachute_DistanceCheckOver                    = 152,
    Parachute_DistanceCheckUp                      = 153,
    Parachute_ClientDistanceCheckLarge             = 154,
    Parachute_ClientDistanceCheckSmall             = 155,
    Parachute_VelocityCheck                        = 156,
    Parachute_PowerA                               = 157,
    Parachute_PowerB                               = 158,
    Parachute_PowerC                               = 159,
    Parachute_PowerD                               = 160,
    View_FOV                                       = 200,
    View_TeamID                                    = 201,
    View_UnNormalSwitchCameraMode                  = 202,
    LogReport_Movement                             = 203,
    LogReport_Weapon                               = 204,
    Max                                            = 205

};


// Enum  /Script/AClient.ECreditScoreType
enum class ECreditScoreType : uint8_t
{
    None                                           = 0,
    Movement                                       = 1,
    Weapon                                         = 2,
    Pickup                                         = 3,
    Max                                            = 4

};


// Enum  /Script/AClient.EGameFlowProcessor
enum class EGameFlowProcessor : uint8_t
{
    eNone                                          = 0,
    eAppInit                                       = 1,
    eGameFlowWorld                                 = 2,
    eInGame                                        = 3,
    eLobby                                         = 4,
    eLaunch                                        = 5,
    eMax                                           = 6,
    EGameFlowProcessor_MAX                         = 7

};


// Enum  /Script/AClient.EGameflowProcessorCreateType
enum class EGameflowProcessorCreateType : uint8_t
{
    eOnlyDS                                        = 0,
    eOnlyClient                                    = 1,
    eAll                                           = 2,
    EGameflowProcessorCreateType_MAX               = 3

};


// Enum  /Script/AClient.EGameFlowMangerPhase
enum class EGameFlowMangerPhase : uint8_t
{
    eLoadTable                                     = 0,
    eInitData                                      = 1,
    eMax                                           = 2,
    EGameFlowMangerPhase_MAX                       = 3

};


// Enum  /Script/AClient.EGameFlowPhase
enum class EGameFlowPhase : uint8_t
{
    eNone                                          = 0,
    eAppInit                                       = 1,
    eGameFlowWorld                                 = 2,
    eLaunch                                        = 3,
    eUpdate                                        = 4,
    eLogin                                         = 5,
    eLobby                                         = 6,
    eInGame                                        = 7,
    eMax                                           = 8,
    EGameFlowPhase_MAX                             = 9

};


// Enum  /Script/AClient.EGameHUDItemType
enum class EGameHUDItemType : uint8_t
{
    None                                           = 0,
    Zone                                           = 1,
    EGameHUDItemType_MAX                           = 2

};


// Enum  /Script/AClient.EGNGameDeviceQualityLevel
enum class EGNGameDeviceQualityLevel : uint8_t
{
    QUALITY_LEVEL_LOW                              = 0,
    QUALITY_LEVEL_MID                              = 1,
    QUALITY_LEVEL_HIGH                             = 2,
    QUALITY_LEVEL_MAX                              = 3

};


// Enum  /Script/AClient.EChatQuickMsgType
enum class EChatQuickMsgType : uint8_t
{
    None                                           = 0,
    Command                                        = 1,
    InfoTrans                                      = 2,
    SocialContact                                  = 3,
    Other                                          = 4,
    EChatQuickMsgType_MAX                          = 5

};


// Enum  /Script/AClient.EHero08DecoyDieReasonType
enum class EHero08DecoyDieReasonType : uint8_t
{
    EHero08DecoyDieType_None                       = 0,
    EHero08DecoyDieType_Crushed                    = 1,
    EHero08DecoyDieType_Killed                     = 2,
    EHero08DecoyDieType_OverTime                   = 3,
    EHero08DecoyDieType_MAX                        = 4

};


// Enum  /Script/AClient.EHero08DecoyEndType
enum class EHero08DecoyEndType : uint8_t
{
    Default                                        = 0,
    Kill                                           = 1,
    Overtime                                       = 2,
    EHero08DecoyEndType_MAX                        = 3

};


// Enum  /Script/AClient.EHero08_DecoySourceType
enum class EHero08_DecoySourceType : uint8_t
{
    DecoySourceType_None                           = 0,
    DecoySourceType_Tactics                        = 1,
    DecoySourceType_Ultimate                       = 2,
    DecoySourceType_Passive                        = 3,
    DecoySourceType_Perk                           = 4,
    AirParachuteTactics                            = 5,
    EHero08_MAX                                    = 6

};


// Enum  /Script/AClient.EHero08_InvisibleType
enum class EHero08_InvisibleType : uint8_t
{
    InvisibleType_None                             = 0,
    InvisibleType_Passive                          = 1,
    InvisibleType_Rescue                           = 2,
    InvisibleType_BeaconRespawn                    = 3,
    InvisibleType_Ultimate                         = 4,
    InvisibleType_Perk                             = 5,
    InvisibleType_MAX                              = 6

};


// Enum  /Script/AClient.EInspectCategory
enum class EInspectCategory : uint8_t
{
    InspectNone                                    = 0,
    InspectForCharacter                            = 1,
    InspectForWeapon                               = 2,
    InspectForHeroArcana                           = 3,
    EInspectCategory_MAX                           = 4

};


// Enum  /Script/AClient.EScreenSlideType
enum class EScreenSlideType : uint8_t
{
    LeftSlide                                      = 0,
    RightSlide                                     = 1,
    None                                           = 2,
    EScreenSlideType_MAX                           = 3

};


// Enum  /Script/AClient.EGnyxRegionEnum
enum class EGnyxRegionEnum : uint8_t
{
    ROW                                            = 0,
    PDCC                                           = 1,
    All                                            = 2,
    Unknown                                        = 3,
    EGnyxRegionEnum_MAX                            = 4

};


// Enum  /Script/AClient.EGnyxNavLinkEndType
enum class EGnyxNavLinkEndType : uint8_t
{
    Default                                        = 0,
    AllowEndInvalid                                = 1,
    EGnyxNavLinkEndType_MAX                        = 2

};


// Enum  /Script/AClient.EAnchorLinkBehavior
enum class EAnchorLinkBehavior : uint8_t
{
    Walk                                           = 0,
    Jump                                           = 1,
    Climb                                          = 2,
    EAnchorLinkBehavior_MAX                        = 3

};


// Enum  /Script/AClient.EGnyxNavLinkProxyType
enum class EGnyxNavLinkProxyType : uint8_t
{
    Walk                                           = 0,
    Jump                                           = 1,
    Climb                                          = 2,
    Zipline                                        = 3,
    Door                                           = 4,
    Anchor                                         = 5,
    Portal                                         = 6,
    Banned                                         = 7,
    HotBalloonZipline                              = 8,
    Fly                                            = 9,
    IceSlide                                       = 10,
    BunckerDoor                                    = 11,
    Max                                            = 12,
    Invalid                                        = 255

};


// Enum  /Script/AClient.EGnyxNavMeshDynamicObstacleCalculateType
enum class EGnyxNavMeshDynamicObstacleCalculateType : uint8_t
{
    Stop                                           = 0,
    TriggerMove                                    = 1,
    EGnyxNavMeshDynamicObstacleCalculateType_MAX   = 2

};


// Enum  /Script/AClient.EGnyxNavMeshDynamicObstacleMoveStatus
enum class EGnyxNavMeshDynamicObstacleMoveStatus : uint8_t
{
    Stop                                           = 0,
    Move                                           = 1,
    EGnyxNavMeshDynamicObstacleMoveStatus_MAX      = 2

};


// Enum  /Script/AClient.EGnyxNavMeshModifierShape
enum class EGnyxNavMeshModifierShape : uint8_t
{
    Box                                            = 0,
    Cylinder                                       = 1,
    EGnyxNavMeshModifierShape_MAX                  = 2

};


// Enum  /Script/AClient.EGnyxRepathReason
enum class EGnyxRepathReason : uint8_t
{
    Block                                          = 0,
    RecalculateNavMesh                             = 1,
    FollowActor                                    = 2,
    GoalChange                                     = 3,
    ShiftPath                                      = 4,
    EGnyxRepathReason_MAX                          = 5

};


// Enum  /Script/AClient.EHeroPet_MoveState
enum class EHeroPet_MoveState : uint8_t
{
    Defaule                                        = 0,
    Follow_Fly                                     = 1,
    ShowMode                                       = 2,
    EHeroPet_MAX                                   = 3

};


// Enum  /Script/AClient.EGnyxRaycastResult
enum class EGnyxRaycastResult : uint8_t
{
    Raycast_Success                                = 0,
    Raycast_SysErr                                 = 1,
    Raycast_StartLoc_Invalid                       = 2,
    Raycast_MAX                                    = 3

};


// Enum  /Script/AClient.EPlayerStartType
enum class EPlayerStartType : uint8_t
{
    Common                                         = 0,
    Start                                          = 1,
    Respawn                                        = 2,
    Init                                           = 3,
    EPlayerStartType_MAX                           = 4

};


// Enum  /Script/AClient.EClassRepNodeMapping
enum class EClassRepNodeMapping : uint8_t
{
    NotRouted                                      = 0,
    RelevantAllConnections                         = 1,
    RelevantOwnerConnection                        = 2,
    Dependent                                      = 3,
    Spatialize_Static                              = 4,
    Spatialize_Dynamic                             = 5,
    Spatialize_Dormancy                            = 6,
    PickUp                                         = 7,
    EClassRepNodeMapping_MAX                       = 8

};


// Enum  /Script/AClient.EPerkTriggerTarget
enum class EPerkTriggerTarget : uint8_t
{
    None                                           = 0,
    Myself                                         = 1,
    Teammate                                       = 2,
    Others                                         = 3,
    EPerkTriggerTarget_MAX                         = 4

};


// Enum  /Script/AClient.ESkillPickerSortPolicy
enum class ESkillPickerSortPolicy : uint8_t
{
    None                                           = 0,
    SortByDistance                                 = 1,
    ESkillPickerSortPolicy_MAX                     = 2

};


// Enum  /Script/AClient.ESkillShapeType
enum class ESkillShapeType : uint8_t
{
    None                                           = 0,
    Line                                           = 1,
    Box                                            = 2,
    Sphere                                         = 3,
    Capsule                                        = 4,
    Cylinder                                       = 5,
    SkillPicker                                    = 6,
    ESkillShapeType_MAX                            = 7

};


// Enum  /Script/AClient.EPickerDescriptionType
enum class EPickerDescriptionType : uint8_t
{
    None                                           = 0,
    EPickerDescriptionType_MAX                     = 1

};


// Enum  /Script/AClient.ECheckLandFailedReason
enum class ECheckLandFailedReason : uint8_t
{
    None                                           = 0,
    GroundNormalInvalid                            = 1,
    GroundActorInvalid                             = 2,
    NoGround                                       = 3,
    CollisionBlock                                 = 4,
    AboveCollisionBlock                            = 5,
    GroundSpaceTooSmall                            = 6,
    GroundTooCliff                                 = 7,
    MaxNone                                        = 8,
    ECheckLandFailedReason_MAX                     = 9

};


// Enum  /Script/AClient.ESkillConfigKey
enum class ESkillConfigKey : uint8_t
{
    Hero07_DirtyBombMaxNum                         = 0,
    Hero07_DirtyBombClearOnTDMRespawn              = 1,
    Hero07_GrenadeClearOnTDMRespawn                = 2,
    Hero07_DirtyBombClearOnTDMLegendChange         = 3,
    Hero07_GrenadeClearOnTDMLegendChange           = 4,
    Hero52_Anim_Snapping                           = 5,
    Hero03_UltimateMaxNum                          = 6,
    Hero04_UltimateMaxNum                          = 7,
    Hero05_UltimateMaxNum                          = 8,
    Hero06_TacticalMaxNum                          = 9,
    Hero53_TacticalMaxNum                          = 10,
    ESkillConfigKey_MAX                            = 11

};


// Enum  /Script/AClient.EImpactType
enum class EImpactType : uint8_t
{
    SelfFppView                                    = 0,
    SelfTppView                                    = 1,
    EnemyFppView                                   = 2,
    EnemyTppView                                   = 3,
    AllyFppView                                    = 4,
    AllyTppView                                    = 5,
    EnemyAndCauserEnemyFppView                     = 6,
    EnemyAndCauserEnemyTppView                     = 7,
    EnemyAndCauserAllyFppView                      = 8,
    EnemyAndCauserAllyTppView                      = 9,
    AllyAndCauserEnemyFppView                      = 10,
    AllyAndCauserEnemyTppView                      = 11,
    AllyAndCauserAllyFppView                       = 12,
    AllyAndCauserAllyTppView                       = 13,
    AllyAndCauserSelfFppView                       = 14,
    AllyAndCauserSelfTppView                       = 15,
    EnemyAndCauserSelfFppView                      = 16,
    EnemyAndCauserSelfTppView                      = 17,
    SelfAndCauserSelfFppView                       = 18,
    SelfAndCauserSelfTppView                       = 19,
    Default                                        = 63,
    EImpactType_MAX                                = 64

};


// Enum  /Script/AClient.EGnyxTp101_tp1_State
enum class EGnyxTp101_tp1_State : uint8_t
{
    Init                                           = 0,
    Startup                                        = 1,
    AtWork                                         = 2,
    Destroy                                        = 3,
    EGnyxTp101_tp1_MAX                             = 4

};


// Enum  /Script/AClient.ETrainStartUpType
enum class ETrainStartUpType : uint8_t
{
    Still                                          = 0,
    StartUpWithSpecificRail                        = 1,
    StartUpWithRandomRail                          = 2,
    ETrainStartUpType_MAX                          = 3

};


// Enum  /Script/AClient.EUIAnimType
enum class EUIAnimType : uint8_t
{
    None                                           = 0,
    EALPHA                                         = 1,
    ESCALE                                         = 2,
    ESCALE_VECTOR                                  = 3,
    EPOSITION                                      = 4,
    EUIAnimType_MAX                                = 5

};


// Enum  /Script/AClient.EFlameDirection
enum class EFlameDirection : uint8_t
{
    Forward                                        = 0,
    Back                                           = 1,
    Left                                           = 2,
    Right                                          = 3,
    EFlameDirection_MAX                            = 4

};


// Enum  /Script/AClient.EVehicleShowMode
enum class EVehicleShowMode : uint8_t
{
    Normal                                         = 0,
    Home                                           = 1,
    BR_Home                                        = 2,
    EVehicleShowMode_MAX                           = 3

};


// Enum  /Script/AClient.EVehicleUIReportType
enum class EVehicleUIReportType : uint8_t
{
    GetOn                                          = 0,
    GetOff                                         = 1,
    SpeedUp                                        = 2,
    Brake                                          = 3,
    Call                                           = 4,
    Speaker                                        = 5,
    Skin                                           = 6,
    EVehicleUIReportType_MAX                       = 7

};


// Enum  /Script/AClient.EVehicleSpeedLevel
enum class EVehicleSpeedLevel : uint8_t
{
    Stop                                           = 0,
    Low                                            = 1,
    Medium                                         = 2,
    High                                           = 3,
    EVehicleSpeedLevel_MAX                         = 4

};


// Enum  /Script/AClient.ELODTransmitSource
enum class ELODTransmitSource : uint8_t
{
    NONE                                           = 0,
    SLIDE                                          = 1,
    Hunting                                        = 2,
    MaxIndex                                       = 3,
    ELODTransmitSource_MAX                         = 4

};


// Enum  /Script/AClient.SetEnableViewInputSource
enum class SetEnableViewInputSource : uint8_t
{
    NONE                                           = 0,
    Featustore                                     = 1,
    SkillAction                                    = 2,
    Finisher                                       = 3,
    MaxIndex                                       = 4,
    SetEnableViewInputSource_MAX                   = 5

};


// Enum  /Script/AClient.EGoldModeNotifySoundType
enum class EGoldModeNotifySoundType : uint8_t
{
    None                                           = 0,
    OpenRedEnvelope                                = 1,
    StartStore                                     = 2,
    StoreSuccess                                   = 3,
    Max                                            = 4

};


// Enum  /Script/AClient.EGravityCannonEffectPart
enum class EGravityCannonEffectPart : uint8_t
{
    VFX_LightCross                                 = 0,
    VFX_Arrow                                      = 1,
    VFX_TeleportTurret                             = 2,
    VFX_MAX                                        = 3

};


// Enum  /Script/AClient.EGravityElevatorState
enum class EGravityElevatorState : uint8_t
{
    Normal                                         = 0,
    Handled                                        = 1,
    Activated                                      = 2,
    CoolDown                                       = 3,
    EGravityElevatorState_MAX                      = 4

};


// Enum  /Script/AClient.ELastKillerFrom
enum class ELastKillerFrom : uint8_t
{
    TombBox                                        = 0,
    Statistics                                     = 1,
    ELastKillerFrom_MAX                            = 2

};


// Enum  /Script/AClient.ERobotEffectiveTargetType
enum class ERobotEffectiveTargetType : uint8_t
{
    Self                                           = 0,
    Teammate                                       = 1,
    Enemy                                          = 2,
    ERobotEffectiveTargetType_MAX                  = 3

};


// Enum  /Script/AClient.EHealingRobotShieldState
enum class EHealingRobotShieldState : uint8_t
{
    Normal                                         = 0,
    HalfBroken                                     = 1,
    AlmostBroken                                   = 2,
    Destroyed                                      = 3,
    Finished                                       = 4,
    EHealingRobotShieldState_MAX                   = 5

};


// Enum  /Script/AClient.EHealthAndShieldSource
enum class EHealthAndShieldSource : uint8_t
{
    None                                           = 0,
    Damage                                         = 1,
    Hero54                                         = 2,
    Hero11                                         = 3,
    EHealthAndShieldSource_MAX                     = 4

};


// Enum  /Script/AClient.EHealthAndShieldLossAnimType
enum class EHealthAndShieldLossAnimType : uint8_t
{
    LossHealth                                     = 0,
    LossShield                                     = 1,
    BrokenShield                                   = 2,
    EHealthAndShieldLossAnimType_MAX               = 3

};


// Enum  /Script/AClient.EHealthAndShieldPromptBarType
enum class EHealthAndShieldPromptBarType : uint8_t
{
    HealthAndShield                                = 0,
    DownShield                                     = 1,
    VampireHealth                                  = 2,
    EHealthAndShieldPromptBarType_MAX              = 3

};


// Enum  /Script/AClient.EGnyxHero04_he_MonitorPawnStateType
enum class EGnyxHero04_he_MonitorPawnStateType : uint8_t
{
    PawnState_Sprint_Forward                       = 0,
    PawnState_Move_Backward                        = 1,
    PawnState_Crouch                               = 2,
    PawnState_Move                                 = 3,
    PawnState_PropsWeaponRight                     = 4,
    PawnState_Max                                  = 5

};


// Enum  /Script/AClient.EGnyxHero04_he_MonitorType
enum class EGnyxHero04_he_MonitorType : uint8_t
{
    Display_Default                                = 0,
    Display_Happy                                  = 1,
    Display_Angry                                  = 2,
    Display_Sad                                    = 3,
    Display_Surprised                              = 4,
    Display_Question                               = 5,
    Display_GlitchOne                              = 6,
    Display_GlitchTwo                              = 7,
    Display_GlitchThree                            = 8,
    Display_Num                                    = 9,
    Display_Idle                                   = 10,
    Display_MAX                                    = 11

};


// Enum  /Script/AClient.EGrapplingHookRole
enum class EGrapplingHookRole : uint8_t
{
    NotDefine                                      = 0,
    Caster                                         = 1,
    Victim                                         = 2,
    EGrapplingHookRole_MAX                         = 3

};


// Enum  /Script/AClient.EGrapplingHookStringType
enum class EGrapplingHookStringType : uint8_t
{
    Linear_Bezier_Curves                           = 0,
    Quadratic_Bezier_Curves                        = 1,
    Cubic_Bezier_Curves                            = 2,
    EGrapplingHookStringType_MAX                   = 3

};


// Enum  /Script/AClient.EGrapplingHookProjectileEndReason
enum class EGrapplingHookProjectileEndReason : uint8_t
{
    None                                           = 0,
    Blocking                                       = 1,
    Overlaping                                     = 2,
    Reach_Target                                   = 3,
    Interupting                                    = 4,
    EGrapplingHookProjectileEndReason_MAX          = 5

};


// Enum  /Script/AClient.EGrapplingHookState
enum class EGrapplingHookState : uint8_t
{
    INVALID_STATE                                  = 0,
    Not_Ready                                      = 1,
    Preparing                                      = 2,
    Targeting                                      = 3,
    Launching                                      = 4,
    Pulling                                        = 5,
    Withdrawing                                    = 6,
    Finishing                                      = 7,
    STATE_NUM                                      = 8,
    EGrapplingHookState_MAX                        = 9

};


// Enum  /Script/AClient.EGrapplingHookTargetStatus
enum class EGrapplingHookTargetStatus : uint8_t
{
    TargetNotFound                                 = 0,
    TargetInvalid                                  = 1,
    TargetValid                                    = 2,
    SubTargetValid                                 = 3,
    TargetStatusNum                                = 4,
    EGrapplingHookTargetStatus_MAX                 = 5

};


// Enum  /Script/AClient.Hero07_BombStatus
enum class Hero07_BombStatus : uint8_t
{
    Deploy                                         = 0,
    WaitTrigger                                    = 1,
    Trigger                                        = 2,
    TriggerFadeOut                                 = 3,
    Destroy                                        = 4,
    Hero07_MAX                                     = 5

};


// Enum  /Script/AClient.Hero07_ExternalEvent
enum class Hero07_ExternalEvent : uint8_t
{
    Deploy                                         = 0,
    Active                                         = 1,
    PickedUp                                       = 2,
    DestroyByDamage                                = 3,
    Hero07_MAX                                     = 4

};


// Enum  /Script/AClient.ESpikeCheckFailReasonType
enum class ESpikeCheckFailReasonType : uint8_t
{
    None                                           = 0,
    UpFail                                         = 1,
    ForwardFail                                    = 2,
    DownFail                                       = 3,
    OtherFail                                      = 4,
    ESpikeCheckFailReasonType_MAX                  = 5

};


// Enum  /Script/AClient.EHero08State
enum class EHero08State : uint8_t
{
    Normal                                         = 0,
    Party                                          = 1,
    None                                           = 2,
    EHero08State_MAX                               = 3

};


// Enum  /Script/AClient.EHero09StimActiveState
enum class EHero09StimActiveState : uint8_t
{
    None                                           = 0,
    Active                                         = 1,
    Completed                                      = 2,
    EHero09StimActiveState_MAX                     = 3

};


// Enum  /Script/AClient.ELandingStateType
enum class ELandingStateType : uint8_t
{
    ELandingState_None                             = 0,
    ELandingState_LandTwoAndConnect                = 1,
    ELandingState_LandOneAndConnect                = 2,
    ELandingState_NoLandAndConnect                 = 3,
    ELandingState_MAX                              = 4

};


// Enum  /Script/AClient.EHero10TacticalPlacedState
enum class EHero10TacticalPlacedState : uint8_t
{
    None                                           = 0,
    Deploy                                         = 1,
    Pursuit                                        = 2,
    Explode                                        = 3,
    BeDestroy                                      = 4,
    EHero10TacticalPlacedState_MAX                 = 5

};


// Enum  /Script/AClient.EHero10TacticalProjectileState
enum class EHero10TacticalProjectileState : uint8_t
{
    None                                           = 0,
    Flying                                         = 1,
    Spread                                         = 2,
    Deploy                                         = 3,
    NodeDestructed                                 = 4,
    EHero10TacticalProjectileState_MAX             = 5

};


// Enum  /Script/AClient.EHero11Drone_AutoMode
enum class EHero11Drone_AutoMode : uint8_t
{
    Hover                                          = 0,
    Auto                                           = 1,
    Follow                                         = 2,
    FollowToAuto                                   = 3,
    EHero11Drone_MAX                               = 4

};


// Enum  /Script/AClient.EHero11DroneUIState
enum class EHero11DroneUIState : uint8_t
{
    None                                           = 0,
    Normal                                         = 1,
    Normal_Zero                                    = 2,
    DroneEnter                                     = 3,
    DroneTrace                                     = 4,
    EMP                                            = 5,
    Recall                                         = 6,
    EHero11DroneUIState_MAX                        = 7

};


// Enum  /Script/AClient.EHero14TacticalProjectileState
enum class EHero14TacticalProjectileState : uint8_t
{
    None                                           = 0,
    Flying                                         = 1,
    Deploy                                         = 2,
    EHero14TacticalProjectileState_MAX             = 3

};


// Enum  /Script/AClient.EHero17UltimatePhase
enum class EHero17UltimatePhase : uint8_t
{
    CaptainGetReady                                = 0,
    Wait                                           = 1,
    Launch                                         = 2,
    EnterParachute                                 = 3,
    Max                                            = 4

};


// Enum  /Script/AClient.ETeamPosSlot
enum class ETeamPosSlot : uint8_t
{
    Left                                           = 0,
    Right                                          = 1,
    Front                                          = 2,
    Max                                            = 3

};


// Enum  /Script/AClient.EScreenDirection
enum class EScreenDirection : uint8_t
{
    Left                                           = 0,
    Right                                          = 1,
    EScreenDirection_MAX                           = 2

};


// Enum  /Script/AClient.EScreenModelSize
enum class EScreenModelSize : uint8_t
{
    SizeSmall                                      = 1,
    SizeMedium                                     = 2,
    SizeLarge                                      = 3,
    NumSizes                                       = 4,
    EScreenModelSize_MAX                           = 5

};


// Enum  /Script/AClient.EHero42_RecordStatus
enum class EHero42_RecordStatus : uint8_t
{
    EHERO42_RECORDSTATUS_UNKOWN                    = 0,
    EHERO42_RECORDSTATUS_RECORDING                 = 1,
    EHERO42_RECORDSTATUS_BRAID                     = 2,
    EHERO42_RECORDSTATUS_MAX                       = 3

};


// Enum  /Script/AClient.EHero50LaunchPhase
enum class EHero50LaunchPhase : uint8_t
{
    None                                           = 0,
    StartUp                                        = 1,
    NormalFly                                      = 2,
    TraceWait                                      = 3,
    Trace                                          = 4,
    EHero50LaunchPhase_MAX                         = 5

};


// Enum  /Script/AClient.EHero53TacticalProjectileState
enum class EHero53TacticalProjectileState : uint8_t
{
    None                                           = 0,
    Flying                                         = 1,
    Deploy                                         = 2,
    EHero53TacticalProjectileState_MAX             = 3

};


// Enum  /Script/AClient.EHeroArcanaDialogueType
enum class EHeroArcanaDialogueType : uint8_t
{
    Idle                                           = 0,
    Land                                           = 1,
    Inspection                                     = 2,
    EHeroArcanaDialogueType_MAX                    = 3

};


// Enum  /Script/AClient.EHeroArcanaLoadPriority
enum class EHeroArcanaLoadPriority : uint8_t
{
    VeryHigh                                       = 0,
    High                                           = 1,
    Middle                                         = 2,
    Low                                            = 3,
    VeryLow                                        = 4,
    EHeroArcanaLoadPriority_MAX                    = 5

};


// Enum  /Script/AClient.EHeroArcanaAnimType
enum class EHeroArcanaAnimType : uint8_t
{
    EHeroArcanaAnim_StandAttack                    = 0,
    EHeroArcanaAnim_CrouchAttack                   = 1,
    EHeroArcanaAnim_AirAttack                      = 2,
    EHeroArcanaAnim_DestroydoorAttack              = 3,
    EHeroArcanaAnim_SrpintAttack                   = 4,
    EHeroArcanaAnim_SlideAttack                    = 5,
    EHeroArcanaAnim_FirstPutOn                     = 6,
    EHeroArcanaAnim_PutOn                          = 7,
    EHeroArcanaAnim_PutOff                         = 8,
    EHeroArcanaAnim_Idle                           = 9,
    EHeroArcanaAnim_LandingSwitchArcana            = 10,
    EHeroArcanaAnim_CheckingArcana                 = 11,
    EHeroArcanaAnim_MeleeChargeUp                  = 12,
    EHeroArcanaAnim_MAX                            = 13

};


// Enum  /Script/AClient.EHeroSize
enum class EHeroSize : uint8_t
{
    EHeroSize_Small                                = 0,
    EHeroSize_Medium                               = 1,
    EHeroSize_Big                                  = 2,
    EHeroSize_MAX                                  = 3

};


// Enum  /Script/AClient.EHeroArcanaCharParticleSocket
enum class EHeroArcanaCharParticleSocket : uint8_t
{
    EHeroArcanaCharParticleSocket_Use1             = 0,
    EHeroArcanaCharParticleSocket_MAX              = 1

};


// Enum  /Script/AClient.EHeroArcanaParticleSocket
enum class EHeroArcanaParticleSocket : uint8_t
{
    EHeroArcanaParticleSocket_Use1                 = 0,
    EHeroArcanaParticleSocket_Use2                 = 1,
    EHeroArcanaParticleSocket_MAX                  = 2

};


// Enum  /Script/AClient.EHeroArcanaSocket
enum class EHeroArcanaSocket : uint8_t
{
    EHeroArcanaSocket_Use                          = 0,
    EHeroArcanaSocket_Idle                         = 1,
    EHeroArcanaSocket_MAX                          = 2

};


// Enum  /Script/AClient.EHeroArcanaResLoadTag
enum class EHeroArcanaResLoadTag : uint8_t
{
    None                                           = 0,
    AutoBornIslandRes                              = 1,
    AutoInGameRes                                  = 2,
    EHeroArcanaResLoadTag_MAX                      = 3

};


// Enum  /Script/AClient.EHeroArcanaResLoadState
enum class EHeroArcanaResLoadState : uint8_t
{
    UnLoad                                         = 0,
    Loading                                        = 1,
    Loaded                                         = 2,
    EHeroArcanaResLoadState_MAX                    = 3

};


// Enum  /Script/AClient.EHeterochromatic_OpenReason
enum class EHeterochromatic_OpenReason : uint8_t
{
    Normal                                         = 0,
    PickUpTrigger                                  = 1,
    EHeterochromatic_MAX                           = 2

};


// Enum  /Script/AClient.EHeterochromatic_DoorType
enum class EHeterochromatic_DoorType : uint8_t
{
    TableItemRandom                                = 0,
    Invalid                                        = 1,
    EHeterochromatic_MAX                           = 2

};


// Enum  /Script/AClient.EHeterochromatic_LootType
enum class EHeterochromatic_LootType : uint8_t
{
    None                                           = 0,
    ItemTableRandom                                = 1,
    ItemTableRandomAE                              = 2,
    DropList                                       = 3,
    EachDoorCustom                                 = 4,
    ExternalSet                                    = 5,
    Max                                            = 6

};


// Enum  /Script/AClient.EHomeDecorationType
enum class EHomeDecorationType : uint8_t
{
    None                                           = 0,
    DecorationType1                                = 1,
    DecorationType2                                = 2,
    DecorationType3                                = 3,
    DecorationType4                                = 4,
    DecorationType5                                = 5,
    DecorationType6                                = 6,
    DecorationType7                                = 7,
    DecorationType8                                = 8,
    DecorationType9                                = 9,
    DecorationType10                               = 10,
    DecorationType11                               = 11,
    DecorationType12                               = 12,
    MAX                                            = 13

};


// Enum  /Script/AClient.ETeleportState
enum class ETeleportState : uint8_t
{
    ETeleportState_None                            = 0,
    ETeleportState_Failed                          = 1,
    ETeleportState_Succed                          = 2,
    ETeleportState_MAX                             = 3

};


// Enum  /Script/AClient.EHUDType
enum class EHUDType : uint8_t
{
    KnocKout_kAchievedTip                          = 0,
    KnocKout_kKilledTip                            = 1,
    ExplosionTimeTips                              = 2,
    HUDHealthAndShieldPromptBar                    = 3,
    EHUDType_MAX                                   = 4

};


// Enum  /Script/AClient.ETextVertPos
enum class ETextVertPos : uint8_t
{
    Top                                            = 0,
    Center                                         = 1,
    Bottom                                         = 2,
    MAX                                            = 3

};


// Enum  /Script/AClient.ETextHorzPos
enum class ETextHorzPos : uint8_t
{
    Left                                           = 0,
    Center                                         = 1,
    Right                                          = 2,
    MAX                                            = 3

};


// Enum  /Script/AClient.EIndiviAnimDimension
enum class EIndiviAnimDimension : uint8_t
{
    Light                                          = 0,
    Medium                                         = 1,
    Heavy                                          = 2,
    EIndiviAnimDimension_MAX                       = 3

};


// Enum  /Script/AClient.EActivityItemDropReason
enum class EActivityItemDropReason : uint8_t
{
    None                                           = 0,
    SelfPlayerDrop                                 = 1,
    SelfPlayerDeadDrop                             = 2,
    Max                                            = 3

};


// Enum  /Script/AClient.EActivityItemPickupReason
enum class EActivityItemPickupReason : uint8_t
{
    Normal                                         = 0,
    PickupEnemyPlayerItem                          = 1,
    PickupTeamPlayerDropItem                       = 2,
    Max                                            = 3

};


// Enum  /Script/AClient.EPickupActivityItemServerResult
enum class EPickupActivityItemServerResult : uint8_t
{
    Max                                            = 0,
    MaxGame                                        = 1,
    MaxDay                                         = 2,
    MaxWeek                                        = 3,
    MaxTotal                                       = 4

};


// Enum  /Script/AClient.EPickupActivityItemResult
enum class EPickupActivityItemResult : uint8_t
{
    Sucess                                         = 0,
    CD                                             = 1,
    Max                                            = 2,
    NotActivityItem                                = 7

};


// Enum  /Script/AClient.EInGameActivityType
enum class EInGameActivityType : uint8_t
{
    None                                           = 0,
    LootItem                                       = 1,
    TreasurePackage                                = 2,
    Max                                            = 3

};


// Enum  /Script/AClient.EInGameSendType
enum class EInGameSendType : uint8_t
{
    Team                                           = 1,
    All                                            = 2,
    Camp                                           = 3,
    EInGameSendType_MAX                            = 4

};


// Enum  /Script/AClient.EInGameChatFromType
enum class EInGameChatFromType : uint8_t
{
    Normal                                         = 1,
    Pings                                          = 2,
    Parachuting                                    = 3,
    CustomChat                                     = 4,
    SelectLegend                                   = 5,
    System                                         = 6,
    ShortSelectLegend                              = 7,
    Require                                        = 8,
    QuickMsg                                       = 9,
    ChangeLegendMsg                                = 10,
    BombRequst                                     = 11,
    Skill                                          = 12,
    Others                                         = 20,
    EInGameChatFromType_MAX                        = 21

};


// Enum  /Script/AClient.EInGameEventChatType
enum class EInGameEventChatType : uint8_t
{
    NonConversational                              = 1,
    Conversational                                 = 2,
    EInGameEventChatType_MAX                       = 3

};


// Enum  /Script/AClient.EInGameEventChatID
enum class EInGameEventChatID : uint8_t
{
    Revenge                                        = 101,
    EInGameEventChatID_MAX                         = 102

};


// Enum  /Script/AClient.EInGameGuideReportType
enum class EInGameGuideReportType : uint8_t
{
    Trigger                                        = 1,
    Appear                                         = 2,
    Finished                                       = 3,
    EInGameGuideReportType_MAX                     = 4

};


// Enum  /Script/AClient.EUILayerType
enum class EUILayerType : uint8_t
{
    BackGround                                     = 1,
    Low                                            = 2,
    Dock                                           = 3,
    Exclusive                                      = 4,
    LowWindow                                      = 5,
    Window                                         = 6,
    HighWindow                                     = 7,
    TopestWindow                                   = 8,
    Dialog                                         = 9,
    Top                                            = 10,
    TopShow                                        = 11,
    Guide                                          = 12,
    Tips                                           = 13,
    Loading                                        = 14,
    HighLoading                                    = 15,
    ReplayLoading                                  = 16,
    TopTips                                        = 17,
    ErrorTips                                      = 18,
    EUILayerType_MAX                               = 19

};


// Enum  /Script/AClient.EInGameGuideFailReason
enum class EInGameGuideFailReason : uint8_t
{
    None                                           = 0,
    NotInGuideList                                 = 1,
    IsHadExec                                      = 2,
    MaxNumIsFail                                   = 3,
    MaxExecNumFail                                 = 4,
    LegendUsedNumFail                              = 5,
    MaxGameNumFail                                 = 6,
    LevelLimitFail                                 = 7,
    DurationNumStartFail                           = 8,
    DurationNumEndFail                             = 9,
    NotInProgressList                              = 10,
    PCFail                                         = 11,
    PSFail                                         = 12,
    DailyLimitFail                                 = 13,
    EInGameGuideFailReason_MAX                     = 14

};


// Enum  /Script/AClient.EInGameGuideType
enum class EInGameGuideType : uint8_t
{
    None                                           = 0,
    GlobalGuide                                    = 1,
    ActionGuide                                    = 2,
    PictureGuide                                   = 3,
    NormalPictureGuide                             = 4,
    GroundHighLight                                = 5,
    NavigatorLine                                  = 6,
    EInGameGuideType_MAX                           = 7

};


// Enum  /Script/AClient.EInGameGuideID
enum class EInGameGuideID : uint32_t
{
    PARACHUTE                                      = 1001,
    PickEq200_eQ200_                               = 1027,
    GetEq200_eQ200_Exp                             = 1028,
    PickEq140_eq140_eq_                            = 1029,
    UseEq140_eq140_eq_                             = 1030,
    UseGrenade                                     = 1035,
    Guide_PingGroundWhenJump                       = 1036,
    Guide_PingItem                                 = 1037,
    Guide_PingEnemy                                = 1038,
    Guide_PingBubble                               = 1039,
    AmmoNotEnough                                  = 1046,
    PackupWeapon                                   = 1052,
    ReplaceOptical1                                = 1053,
    ReplaceOptical2                                = 1054,
    StrengthenSr503_s_                             = 1055,
    StrengthenBaozou                               = 1056,
    FindTombBox                                    = 1057,
    RescueTeamMate                                 = 1060,
    PickTeamMateRespawnBanner                      = 1061,
    PingMyRespawnBanner                            = 1062,
    TipMap_resPawn_m                               = 1063,
    FindMap_resPawn_m                              = 1064,
    PingMap_resPawn_m                              = 1065,
    PackupWeaponSlot1WithHUD1                      = 1069,
    PackupWeaponSlot2WithHUD1                      = 1070,
    PackupWeaponSlotWithHUD2                       = 1071,
    DiamondGuide                                   = 1073,
    StrengthenSr503_s_1WithHUD1                    = 1074,
    StrengthenSr503_s_2WithHUD1                    = 1075,
    OpenMedicalTurnTable                           = 1077,
    OpenProjectileTurnTable                        = 1078,
    Guide_FriendPingItem                           = 1079,
    Guide_Sg403_sg4_                               = 1080,
    Guide_PingSg403_sg4_                           = 1081,
    RequireBullet                                  = 1082,
    RequireConsumable                              = 1083,
    RequireBackpack                                = 1084,
    RequireEq200_eQ200_                            = 1085,
    DrugRecommend                                  = 1094,
    ScriptRescueTeamMate                           = 1100,
    ScriptPickTeamMateRespawnBanner                = 1101,
    ScriptTipMap_resPawn_m                         = 1102,
    ScriptTipEq140_eq140_eq_                       = 1103,
    AmmoNotEnough1WithHUD1                         = 1104,
    AmmoNotEnough2WithHUD1                         = 1105,
    BatteryRecommend                               = 1107,
    TacticalSkill                                  = 5001,
    SelectLegend                                   = 5002,
    OpenVoice                                      = 5003,
    PARACHUTE                                      = 5004,
    Rush                                           = 5005,
    Crouch                                         = 5006,
    Climb                                          = 5007,
    LootBox                                        = 5008,
    SmallMap                                       = 5009,
    PoisonCircle                                   = 5010,
    UseZipline                                     = 5011,
    UseJumpTower                                   = 5012,
    UseMedicine                                    = 5013,
    LiftUpTeammates                                = 5014,
    EInGameGuideID_MAX                             = 5015

};


// Enum  /Script/AClient.EInGameLodRegionType
enum class EInGameLodRegionType : uint8_t
{
    NoneRegion                                     = 0,
    WeaponWrapper                                  = 1,
    Character                                      = 2,
    EInGameLodRegionType_MAX                       = 3

};


// Enum  /Script/AClient.EDragContentUsingType
enum class EDragContentUsingType : uint8_t
{
    LeftPing                                       = 1,
    RightPing                                      = 2,
    SmallEye                                       = 3,
    Emoji                                          = 4,
    Projectile                                     = 5,
    Consumable                                     = 6,
    Hero11Drone                                    = 7,
    EDragContentUsingType_MAX                      = 8

};


// Enum  /Script/AClient.EItemContrainerType
enum class EItemContrainerType : uint8_t
{
    None                                           = 0,
    Ground                                         = 1,
    TombBox                                        = 2,
    AirDrop                                        = 3,
    SuppLydrop_                                    = 4,
    BackPack                                       = 5,
    TrainBin                                       = 5,
    Max                                            = 6

};


// Enum  /Script/AClient.EJumpUIModeFlags
enum class EJumpUIModeFlags : uint8_t
{
    JumpUIMode_None                                = 0,
    JumpUIMode_DoubleJumpMode                      = 1,
    JumpUIMode_Hero17_hJetpackMode                 = 2,
    JumpUIMode_AccumulatUIMode                     = 4,
    JumpUIMode_ParachuteForceBuildingUIMode        = 8,
    CharacterActionState_Last                      = 16,
    EJumpUIModeFlags_MAX                           = 17

};


// Enum  /Script/AClient.EKillDropItemType
enum class EKillDropItemType : uint8_t
{
    None                                           = 0,
    Weapon                                         = 1,
    WeaponAttachment                               = 2,
    Ammo                                           = 3,
    Grenades                                       = 4,
    Equipped                                       = 5,
    Consumable                                     = 6,
    Special                                        = 7,
    Max                                            = 8

};


// Enum  /Script/AClient.EDropMethod
enum class EDropMethod : uint8_t
{
    Scatter                                        = 0,
    DropBox                                        = 1,
    FixedChest                                     = 2,
    EDropMethod_MAX                                = 3

};


// Enum  /Script/AClient.ESelectLegendUIType
enum class ESelectLegendUIType : uint8_t
{
    None                                           = 0,
    LobbyScene                                     = 1,
    BRSelect                                       = 2,
    TDMSelect                                      = 3,
    RePick                                         = 4,
    ESelectLegendUIType_MAX                        = 5

};


// Enum  /Script/AClient.ELockLootType
enum class ELockLootType : uint8_t
{
    None                                           = 0,
    PickUp                                         = 1,
    AirdropPickUp                                  = 2,
    DynamicBinPickUp                               = 3,
    AirdropPoint                                   = 4,
    Circle                                         = 5,
    PlaneRoute                                     = 6,
    TrainStartStation                              = 7,
    LootDronePickUp                                = 8,
    LootDronePoint                                 = 9,
    Max                                            = 10

};


// Enum  /Script/AClient.EVIPLootCreepsRegion
enum class EVIPLootCreepsRegion : uint8_t
{
    None                                           = 0,
    Hero08Ship                                     = 1,
    Airport                                        = 2,
    EVIPLootCreepsRegion_MAX                       = 3

};


// Enum  /Script/AClient.ELootCreepsSpecialType
enum class ELootCreepsSpecialType : uint8_t
{
    NormalCreeps                                   = 0,
    VIPCreeps                                      = 1,
    ELootCreepsSpecialType_MAX                     = 2

};


// Enum  /Script/AClient.ELootCreepsType
enum class ELootCreepsType : uint8_t
{
    HERO47                                         = 0,
    INFECTED                                       = 1,
    ELootCreepsType_MAX                            = 2

};


// Enum  /Script/AClient.ELootZoneQualityType
enum class ELootZoneQualityType : uint8_t
{
    None                                           = 0,
    Low                                            = 1,
    Mid                                            = 2,
    High                                           = 3,
    FatPoi                                         = 4,
    Max                                            = 5

};


// Enum  /Script/AClient.ELowAmmoTextState
enum class ELowAmmoTextState : uint8_t
{
    General                                        = 1,
    NeedReload                                     = 2,
    LowAmmo                                        = 3,
    LowAmmoRed                                     = 4,
    Empty                                          = 5,
    ELowAmmoTextState_MAX                          = 6

};


// Enum  /Script/AClient.ELowGravityControllerState
enum class ELowGravityControllerState : uint8_t
{
    Start                                          = 0,
    AlreadyWillOpen                                = 1,
    AlreadyOpen                                    = 2,
    AlreadyWillClose                               = 3,
    AlreadyClose                                   = 4,
    ELowGravityControllerState_MAX                 = 5

};


// Enum  /Script/AClient.ELuaLaunchEventType
enum class ELuaLaunchEventType : uint8_t
{
    EVENTID_GAMEUPDATE_INIT                        = 0,
    EVENTID_GAMEUPDATE_PROGRESS                    = 1,
    EVENTID_GAMEUPDATE_SUCCESS                     = 2,
    EVENTID_GAMEUPDATE_FAILED                      = 3,
    EVENTID_GAMEUPDATE_START                       = 4,
    EVENTID_GAMEUPDATE_OPENAPPSTORE                = 5,
    EVENTID_GAMEUPDATE_INSTALLAPK                  = 7,
    EVENTID_GAMEUPDATE_INIT_FAIL                   = 8,
    EVENTID_GAMEUPDATE_CHECK                       = 9,
    EVENTID_RESUPDATE_CHECK                        = 10,
    EVENTID_RESUPDATE_START                        = 11,
    EVENTID_RESUPDATE_STOP                         = 12,
    EVENTID_RESUPDATE_NOTUPDATE                    = 13,
    EVENTID_RESUPDATE_SUCCESS                      = 14,
    EVENTID_RESUPDATE_FAIL                         = 15,
    EVENTID_PSO_PRECOMPILE_END                     = 16,
    EVENTID_BACKGROUND_DOWNLOAD_START              = 17,
    EVENTID_BACKGROUND_DOWNLOAD_END                = 18,
    EVENTID_FRAME_MOUNT_END                        = 19,
    EVENTID_FRAME_MOUNT_PROGRESS                   = 20,
    EVENTID_LAUNCH_MOUNT_RES_FAIL                  = 21,
    EVENTID_LAUNCH_MOUNT_RES_FINISH                = 22,
    EVENTID_LAUNCH_MOUNT_PUFFER_FAIL               = 23,
    EVENTID_LAUNCH_MOUNT_PUFFER_FINISH             = 24,
    EVENTID_PSO_PRECOMPILE_FAILED                  = 25,
    EVENTID_LAUNCH_DOLPHIN_APP_FINISH              = 30,
    EVENTID_LAUNCH_DOLPHIN_SRC_FINISH              = 31,
    EVENTID_LAUNCH_DOLPHIN_REPAIR_FINISH           = 32,
    EVENTID_GAMEUPDATE_ACTION_MSG                  = 33,
    EVENTID_GAMEUPDATE_TGPA_MSG                    = 34,
    EVENTID_PUFFER_DIFF_INIT                       = 101,
    EVENTID_PUFFER_DIFF_START                      = 102,
    EVENTID_PUFFER_DIFF_PROGRESS                   = 103,
    EVENTID_PUFFER_DIFF_RESULT                     = 104,
    EVENTID_PUFFER_DIFF_FINISHONE                  = 105,
    EVENTID_PUFFER_DIFF_MERGERETURN                = 106,
    EVENTID_PUFFER_DIFF_MERGE                      = 110,
    EVENTID_START_LAUNCH_UPDATE                    = 111,
    EVENTID_PUFFER_INIT_TIMEOUT                    = 112,
    EVENTID_MAX                                    = 113

};


// Enum  /Script/AClient.ELuaLobbyEventType
enum class ELuaLobbyEventType : uint8_t
{
    EVENTID_GAMEUPDATE_INIT                        = 0,
    EVENTID_GAMEUPDATE_PROGRESS                    = 1,
    EVENTID_GAMEUPDATE_SUCCESS                     = 2,
    EVENTID_GAMEUPDATE_FAILED                      = 3,
    EVENTID_GAMEUPDATE_START                       = 4,
    EVENTID_GAMEUPDATE_OPENAPPSTORE                = 5,
    EVENTID_STORESEQUENCE_FINISH                   = 6,
    EVENTID_GAMEUPDATE_INSTALLAPK                  = 7,
    EVENTID_GAMEUPDATE_INIT_FAIL                   = 8,
    EVENTID_GAMEUPDATE_CHECK                       = 9,
    EVENTID_RESUPDATE_CHECK                        = 10,
    EVENTID_RESUPDATE_START                        = 11,
    EVENTID_RESUPDATE_STOP                         = 12,
    EVENTID_RESUPDATE_NOTUPDATE                    = 13,
    EVENTID_RESUPDATE_SUCCESS                      = 14,
    EVENTID_RESUPDATE_FAIL                         = 15,
    EVENTTD_TRANSLATION_RESULT                     = 20,
    EVENTID_PUFFER_DIFF_MERGE                      = 110,
    EVENTID_HTTP_RSP                               = 140,
    EVENTID_WECHAT_HTTPRSP                         = 145,
    EVENTID_TGPA_DOWNCLOCK                         = 200,
    ELuaLobbyEventType_MAX                         = 201

};


// Enum  /Script/AClient.ELuaInGameNetEventType
enum class ELuaInGameNetEventType : uint8_t
{
    InGameNetEvent_RemoteHostResolved              = 1,
    InGameNetEvent_NetworkEstablished              = 2,
    InGameNetEvent_NetworkRecovered                = 3,
    InGameNetEvent_LongTimeBadPing                 = 4,
    InGameNetEvent_PingRecovered                   = 5,
    InGameNetException_EngineNetworkFailure        = 6,
    InGameNetException_EngineTravelFailure         = 7,
    InGameNetException_CriticalSocketError         = 8,
    InGameNetException_ConnectingTimeout           = 9,
    InGameNetException_ConnectionClosed            = 10,
    InGameNetException_ConnectionLongTimeNoReceived = 11,
    InGameNetException_ActorChannelError           = 12,
    InGameNetException_ServerKickPlayer            = 13,
    ELuaInGameNetEventType_MAX                     = 14

};


// Enum  /Script/AClient.ELuaApplicationEventType
enum class ELuaApplicationEventType : uint8_t
{
    EVENTID_APP_Will_Deactivate                    = 1,
    EVENTID_APP_Has_Reactivated                    = 2,
    EVENTID_APP_Will_Enter_Background              = 3,
    EVENTID_APP_Has_Entered_Foreground             = 4,
    EVENTID_APP_Will_Terminate                     = 5,
    EVENTID_APP_Should_Unload_Resources            = 6,
    EVENTID_APP_AudioSession_InterruptionBegan     = 7,
    EVENTID_APP_AudioSession_InterruptionEnded     = 8,
    EVENTID_APP_MAX                                = 9

};


// Enum  /Script/AClient.ELuaCppEventType
enum class ELuaCppEventType : uint32_t
{
    EVENTID_NONE                                   = 1,
    EVENTID_FIGHTING_STAGE_CHANGED                 = 2,
    EVENTID_FIGHTING_TEAMID_CHANGED                = 3,
    EVENTID_SHIELD_VALUE                           = 4,
    EVENTID_HEALTH_VALUE                           = 5,
    EVENTID_SHOOT_TYPE                             = 7,
    EVENTID_SHOOT_TYPE_UNLOCK                      = 8,
    EVENTID_EQUIP_WEAPON                           = 9,
    EVENTID_TEAMINFO_SYNC                          = 10,
    EVENTID_AIM_CHANGE                             = 11,
    EVENTID_ENERGY_SHIELD                          = 12,
    EVENTID_HEALTH_HEALING                         = 13,
    EVENTID_LAND_SELECTION                         = 14,
    EVENTID_PACKAGE_SERVER_LANDING                 = 16,
    EVENTID_TEAMINFO_USEITEM                       = 17,
    EVENTID_AUTO_SPRINT_CHANGE                     = 18,
    EVENTID_TEAMMATELIST_UPDATE                    = 19,
    EVENTID_CAMPMATELIST_UPDATE                    = 20,
    EVNETID_SKILL_START                            = 21,
    EVNETID_SKILL_STOP                             = 22,
    EVNETID_SKILL_RELEASED                         = 23,
    EVNETID_SKILL_CD                               = 24,
    EVNETID_HERO06_H__PASSIVE_ENABLE               = 25,
    EVNETID_HERO06_H__PASSIVE_DISABLE              = 26,
    EVENTID_SCREEN_RIGHT_OPERATE_STATE             = 27,
    EVENTID_SCREEN_RIGHT_DRAG_BEGIN                = 29,
    EVENTID_SCREEN_RIGHT_DRAG_MOVING               = 30,
    EVENTID_SCREEN_RIGHT_DRAG_END                  = 31,
    EVENTID_ATTACH_SKILL_UI                        = 32,
    EVENTID_ATTACH_ALL_SKILL_UI                    = 33,
    EVENTID_DETACH_ALL_SKILL_UI                    = 34,
    EVENTID_PLAYER_STATE_CHANGE                    = 38,
    EVENTID_MOVEMENT_PLAYER_STATE_CHANGE           = 39,
    EVENTID_DAMAGETip2D                            = 40,
    EVENTID_USEMD110_MHEALTH                       = 41,
    EVENTID_USEBATTERY                             = 42,
    EVENTID_ZIPLINEGUN_SELECTION                   = 43,
    EVENTID_SKILL_START_GUNADS                     = 44,
    EVENTID_SKILL_STOP_GUNADS                      = 45,
    EVENTID_SHIELD_FILL                            = 46,
    EVENTID_HERO43_HE__TACTICAL_LAND               = 47,
    EVENTID_SWITCH_CAMERAMODE                      = 53,
    EVENTID_TPP_OR_FPP                             = 54,
    EVENTID_CAMERAMODE_CHANGE                      = 55,
    EVENTID_PICK_WEAPON                            = 56,
    EVENTID_CHANGE_LEGEND                          = 57,
    EVENTID_GUN_ADS                                = 58,
    EVENTID_USE_ARCANA                             = 59,
    EVENTID_CONTROLMONITOR                         = 60,
    EVENTID_ChangeMONITORTXT                       = 61,
    EVENTID_CLICKMONITORFORGAMEPAD                 = 62,
    EVENTID_PUTOFF_WEAPON                          = 63,
    EVENTID_MAINHANDSTACK_CHANGED                  = 64,
    EVENTID_ARCANA_CHANGED                         = 65,
    EVENTID_SHOWRECOVERBANNERBTN                   = 86,
    EVENTID_HIDERECOVERBANNERBTN                   = 87,
    EVENTID_SHOWCROSSHAIRTEXTTIP                   = 91,
    EVENTID_HIDECROSSHAIRTEXTTIP                   = 92,
    EVENTID_SHOWFINISHERBTN                        = 95,
    EVENTID_HIDEFINISHERBTN                        = 96,
    EVENTID_SHOWCANCELFINISHERBTN                  = 97,
    EVENTID_HIDECANCELFINISHERBTN                  = 98,
    EVENTID_SHOWOPENBIGMAPBTN                      = 99,
    EVENTID_SHOW_MAINSUBUI                         = 100,
    EVENTID_HIDE_MAINSUBUI                         = 101,
    EVENTID_PICKUP_UI_MOVE                         = 107,
    EVENTID_PICKUP_BOX_SELECT                      = 110,
    EVENTID_OPEN_BIG_MAP                           = 118,
    EVENTID_SPRINT_UI_STATE                        = 120,
    EVENTID_DELETE_SKILL                           = 130,
    EVENTID_INIT_OB_SKILL_UI                       = 131,
    EVENTID_SKILL_PAUSE                            = 132,
    EVENTID_SKILL_RESUME                           = 133,
    EVENTID_SKILL_JUMP_PHASE                       = 134,
    EVENTID_DRUG_RECOMMEND                         = 140,
    EVENTID_SKILL_COMMON_TIPS                      = 141,
    EVENTID_PLAYER_START_PARACHUTE                 = 200,
    EVENTID_PLAYER_UPDATE_PARACHUTE                = 201,
    EVENTID_PLAYER_STOP_PARACHUTE                  = 202,
    EVENTID_CIRCLE_SAVEZONE_APPRER                 = 203,
    EVENTID_CIRCLE_BLUE_WARNING                    = 204,
    EVENTID_CIRCLE_BLUE_RUN                        = 205,
    EVENTID_PARACHUTE_ENTER_PLANE                  = 206,
    EVENTID_PARACHUTE_CAN_JUMP                     = 207,
    EVENTID_PLANE_START                            = 208,
    EVENTID_PLANE_UPDATE                           = 209,
    EVENTID_PLANE_END                              = 210,
    EVENTID_CIRCLE_BACK_TO_SAVE_AREA_TIPS          = 211,
    EVENTID_CIRCLE_ARRIVE_IN_SAVE_AREA_TIPS        = 212,
    EVENTID_CIRCLE_PLAYER_TO_WHITE_CIRCLE_LINE     = 213,
    EVENTID_CIRCLE_HIDE_PLAYER_TO_WHITE_CIRCLE_LINE = 214,
    EVENTID_PARACHUTE_TEAM_REFRESH_LEADER          = 215,
    EVENTID_PARACHUTE_TEAM_REFRESH_IN_TEAM_STATUS  = 216,
    EVENTID_PLANE_COUNT_DOWN_TIME                  = 220,
    EVENTID_PLANE_REMAINING_PLAYER_NUM             = 221,
    EVENTID_CIRCLE_BLUE_TICK_TIP                   = 223,
    EVENTID_CIRCLE_BLUE_RUN_END                    = 224,
    EVENTID_RESET_MINIMAP_SCALE                    = 225,
    EVENTID_PLAYER_START_MAGMARISE                 = 226,
    EVENTID_PLAYER_STOP_MAGMARISE                  = 227,
    EVENTID_CIRCLE_FINISHED                        = 228,
    EVENTID_GM_SET_BIGMAP_DRAG_MINDST              = 229,
    EVENTID_CIRCLE_PRE_INIT_BLUE_CIRCLE            = 231,
    EVENTID_MINIMAP_STATICITEM_VISIBLE             = 232,
    EVENTID_MINIMAP_STATICITEM_STATE               = 233,
    EVENTID_PLAYER_GOTO_LAND                       = 234,
    EVENTID_PLANE_EXPRESSION_SHOWORHIDE            = 235,
    EVENTID_PLAYER_JUMP_FORM_PLANE                 = 236,
    EVENTID_PLAYER_JUMP_UI_ICON_FLYOVER            = 237,
    EVENTID_WONDERFUL_MOMENT_RECORD_START          = 238,
    EVENTID_WONDERFUL_MOMENT_RECORD_STOP           = 239,
    EVENTID_PLAYER_JUMP_UI_ICON_WORKBENCH_MARK     = 240,
    EVENTID_BUG_REPORT_GET_PHOTO                   = 250,
    EVENTID_BUG_REPORT_ON_PUT_RESULT               = 251,
    EVENTID_OPEN_RENDERSETTING_UI                  = 301,
    EVENTID_HIDE_RENDERSETTING_UI                  = 302,
    EVENTID_APPLY_SETTING                          = 303,
    EVENTID_NOTIFICATION_SETTING                   = 305,
    EVENTID_FORBIDDENZONETIME_ONREP                = 311,
    EVENTID_AVATARSERVERLIST_RETURN                = 312,
    EVENTID_MSDK_GROUP_DELIVERMESSAGE              = 329,
    EVENTID_MSDK_NOTICE_NOTICEINFO                 = 330,
    EVENTID_MSDK_FRIEND_DELIVERMESSAGE             = 331,
    EVENTID_PUFFER_INIT_RETURN                     = 332,
    EVENTID_PUFFER_DOWNLOAD_RETURN                 = 333,
    EVENTID_PUFFER_DOWNLOAD_PROGRESS               = 334,
    EVENTID_PUFFER_RESTORE_RETURN                  = 335,
    EVENTID_PUFFER_RESTORE_PROGRESS                = 336,
    EVENTID_PUFFER_BATCH_RETURN                    = 337,
    EVENTID_PUFFER_BATCH_PROGRESS                  = 338,
    EVENTID_PUFFER_DOWNLOAD_IOSBACKGROUND          = 339,
    EVENTID_POSTLOWBLOOD_EFFECT                    = 340,
    EVENTID_POPUPDEATHRESPAWNTIME                  = 345,
    EVENTID_SHOWTOPBOTTOMBLACK                     = 346,
    EVENTID_HIDE_PING_ITEM                         = 353,
    EVENTID_PING_AIMED                             = 355,
    EVENTID_PING_AIMED_RESET                       = 356,
    EVENTID_RESPONSE_PING_ITEM                     = 357,
    EVENTID_CREATE_PING_ITEM_FROM_PICKUP           = 358,
    EVENTID_CREATE_TEMP_PING_ITEM                  = 359,
    EVENTID_MARK_PING_REVERSE                      = 360,
    EVENTID_TOUCH_MOVING                           = 361,
    EVENTID_PING_CREATE_UNAVALIBLE                 = 362,
    EVENTID_PING_AIMED_STATE_CHANGE                = 363,
    EVENTID_RESET_PING_ITEM_TIME                   = 365,
    EVENTID_SMALLEYE_MOVE_EVENT                    = 370,
    EVENTID_SMALLEYE_ENABLE                        = 371,
    EVENTID_LEFTPING_VISIBLE_CHANGE                = 376,
    EVENTID_SKILL_CONDITION_ERROR                  = 377,
    EVENTID_BACKPACK_REFRESHCAPACITY               = 402,
    EVENTID_BACKPACK_COMPONENTMODIFY               = 403,
    EVENTID_BACKPACK_USESKILLITEMFAILED            = 412,
    EVENTID_BACKPACK_ITEMUSEFINISHED               = 413,
    EVENTID_BACKPACK_OnDropItemSuccess             = 414,
    EVENTID_BACKPACK_OnUseItem                     = 460,
    EVENTID_INGAME_HUDSchemeChange                 = 417,
    EVENTID_INGAME_PREMAINUICLOSE                  = 418,
    EVENTID_BACKPACK_DropALL                       = 423,
    EVENTID_BACKPACK_RequestPartItem               = 430,
    EVENTID_BACKPACK_ShowOperationMenu             = 431,
    EVENTID_BACKPACK_FullTip                       = 432,
    EVENTID_USE_PROJECTILE                         = 433,
    EVENTID_BACKPACK_OPENCLOSE                     = 434,
    EVENTID_BACKPACK_OPEN                          = 435,
    EVENTID_BACKPACK_CLOSE                         = 436,
    EVENTID_INGAME_BroadCast_Show                  = 451,
    EVENTID_INGAME_BroadCast_Hide                  = 452,
    EVENTID_INGAME_THUNERDOMESCREEN                = 470,
    EVENTID_INGAME_CHATMSG_NEW_ITEM                = 500,
    EVENTID_INGAME_BROADCAST_UPDATE_CHATMSG        = 501,
    EVENTID_START_SENDMSG_COOLING                  = 502,
    EVENTID_INGAME_BROADCAST_SELECT_LEGEND         = 503,
    EVENTID_INGAME_CHATCONTENT_FILTER              = 504,
    EVENTID_INGAME_SENDMSG_GETITEM                 = 505,
    EVENTID_STAGE_CHANGE                           = 550,
    EVENTID_VALIDLEGEND_CHANGE                     = 551,
    EVENTID_UDP_PING_ONE_FINISHED                  = 560,
    EVENTID_UDP_PING_ALL_FINISHED                  = 561,
    EVENTID_BATTERY_POWER_CHANGE                   = 571,
    EVENTID_BOXSDK_CALLBACK                        = 581,
    EVENTID_LIKE_NEW_MSG                           = 591,
    EVENTID_LIKE_REPLY_MSG                         = 592,
    EVENTID_REQUEST_RESPAWN                        = 593,
    EVENTID_THX_FOR_RESPAWN                        = 594,
    EVENTID_CELABRATE                              = 595,
    EVENTID_TDM_CAMPSCORING                        = 600,
    EVENTID_TDM_UPDATE_GAMESCORE                   = 601,
    EVENTID_TDM_START_RESPAWN_TIMER                = 602,
    EVENTID_TDM_UPDATE_GAMEPROPERTIES              = 603,
    EVENTID_TDM_CHOOSE_EQUIP                       = 604,
    EVENTID_LOADOUT_UPDATE_CHOOSEWEAPONLIST        = 605,
    EVENTID_MULTIPLAYER_UI_STATUS                  = 606,
    EVENTID_LOADOUT_UPDATE_LOADOUTTABLE            = 607,
    EVENTID_CAMPROLE_SWITCH                        = 608,
    EVENTID_BD_ATTACKER_STATUS_CHANGED             = 609,
    EVENTID_BD_DEFENDER_STATUS_CHANGED             = 610,
    EVENTID_BD_BOMBSITE_INCREASE                   = 611,
    EVENTID_BD_BOMBSITE_DECREASE                   = 612,
    EVENTID_BD_BOMBWRAPPER_INCREASE                = 613,
    EVENTID_BD_BOMBWRAPPER_DECREASE                = 614,
    EVENTID_BD_SI101_SI__INCREASE                  = 615,
    EVENTID_BD_SI101_SI__DECREASE                  = 616,
    EVENTID_BD_SI101_SI__CHANGED                   = 617,
    EVENTID_BD_BOMBCARRIER_CHANGED                 = 618,
    EVENTID_MP_SELECTLEGEND_STAGECHANGED           = 619,
    EVENTID_VEHICLE_RIDE_SWITCH                    = 620,
    EVENTID_VEHICLE_DRIVER_SWITCH                  = 621,
    EVENTID_TDM_UPDATE_MPWEAPONINFO                = 622,
    EVENTID_LOADOUT_UPDATE_SHOW_SELECT_LOADOUT     = 623,
    EVENTID_ARMSRACE_UPDATE_WEAPON_LV              = 624,
    EVENTID_ARMSRACE_SET_LEVEL_ICON                = 625,
    EVENTID_ARMSRACE_UPDATE_CAMP_MAX_SCORE         = 626,
    EVENTID_NETWORK_STATE_CHANGE_NOTIFY            = 627,
    EVENTID_ASSETS_PRELOAD_NOTIFY                  = 628,
    EVENTID_COLOSSEUM_SHOWTIPS                     = 630,
    EVENTID_COLOSSEUM_SHOW_COUNTDOWNTIPS           = 631,
    EVENTID_GOLDMODE_TEAM_SET_CD                   = 632,
    EVENTID_GOLDMODE_REDENVELOPE_DATA_CHANGE       = 633,
    EVENTID_INBATTLECOMMON_TargetPonit_INCREASE    = 700,
    EVENTID_INBATTLECOMMON_TargetPonit_DECREASE    = 701,
    EVENTID_NETWORKMISMATCHL                       = 801,
    EVENTID_NETWORK_UDPPing_RESULT                 = 802,
    EVENTID_BIGMAP_PING_CLICK                      = 903,
    EVENTID_MINIMAP_ADD_ACTOR_ITEM                 = 914,
    EVENTID_MINIMAP_REMOVE_ACTOR_ITEM              = 915,
    EVENTID_MINIMAP_UPDATE_ACTOR_ITEM              = 916,
    EVENTID_MINIMAP_GM_SHOW_AI_LOC                 = 919,
    EVENTID_MINIMAP_GM_REMOVE_AI_LOC               = 920,
    EVENTID_MINIMAP_RED_CIRCLE_SHOW                = 921,
    EVENTID_MINIMAP_WHITE_CIRCLE_SHOW              = 922,
    EVENTID_MINIMAP_RED_CIRCLE_SHRINKING           = 923,
    EVENTID_MINIMAP_RED_CIRCLE_SHRINKING_PLAYER_UPDATE = 924,
    EVENTID_FIGHTSTATICS_KILLNUM                   = 1001,
    EVENTID_FIGHTSTATICS_SURVIVE_CHANGE            = 1002,
    EVENTID_FIGHTSTATICS_VISITOR_CHANGE            = 1003,
    EVENTID_FIGHTSTATICS_RATINGKILLASSISTSCORE_CHANGE = 1004,
    EVENTID_FIGHTSTATICS_DAMAGE                    = 1005,
    EVENTID_FIGHTSTATICS_DEATH                     = 1006,
    EVENTID_PAWN_RECEIVE                           = 1100,
    EVENTID_GAMESTATE_END                          = 1101,
    EVENTID_PLAYER_DEAD                            = 1102,
    EVENTID_PLAYER_DESTROY                         = 1103,
    EVENTID_PAWN_CHANGE                            = 1104,
    EVENTID_GAMESTATE_START                        = 1105,
    EVENTID_OPEN_RESULT_WINDOW                     = 1106,
    EVENTID_NOTIFY_WINTEAM                         = 1107,
    EVENTID_NOTIFY_BATTLERESULT                    = 1108,
    EVENTID_TEST_OPEN_REWARD_WINDOW                = 1109,
    EVENTID_NOTIFY_SIMPLE_RESULTDATA               = 1110,
    EVENTID_LBSIPINFORET                           = 1990,
    EVENTID_LBS_LOCATION                           = 1991,
    EVENTID_LBS_RELATION                           = 1992,
    EVENTID_LBS_BASERET                            = 1993,
    EVENTID_PINCHGESTURE                           = 2001,
    EVENTID_PINCHGESTURE_START                     = 2002,
    EVENTID_PINCHGESTURE_END                       = 2003,
    EVENTID_LOBBY_WEAPON_MOVE                      = 2004,
    EVENTID_LOBBY_WEAPON_MOVE_END                  = 2005,
    EVENTID_LOBBY_LEGEND_CLICK                     = 2006,
    EVENTID_LOBBY_TOUCH_NONE_MOVE                  = 2007,
    EVENTID_LOBBY_TOUCH_NONE_MOVE_END              = 2008,
    EVENTID_LOBBY_CONTAINER_TOUCH_END              = 2009,
    EVENTID_UISTATE_CHANGE                         = 2050,
    EVENTID_GUNSHIELD_ENDPLAY                      = 2069,
    EVENTID_ZIPLINE_CHANGE                         = 2070,
    EVENTID_INGAME_JUMP_PRESSED                    = 2072,
    EVENTID_INGAME_JUMP_RELEASED                   = 2073,
    EVENTID_OPEN_SURVEY_BEACON                     = 2074,
    EVENTID_TESLA_TRAP_LAND                        = 2075,
    EVENTID_TESLA_TRAP_PICK                        = 2076,
    EVENTID_DIRTY_BOMB_PICK_UI_SHOW                = 2077,
    EVENTID_HERO11_DRONE_INTO_MODE                 = 2079,
    EVENTID_CLOSE_HERO08_DECOY_CONTROL_BTN         = 2080,
    EVENTID_HERO11_DRONE_EXIT_MODE                 = 2081,
    EVENTID_HERO11_DRONE_INTO_MODE_START           = 2082,
    EVENTID_HERO11_DRONE_EXIT_MODE_START           = 2083,
    EVENTID_HERO11_DRONE_TRIANGLE_UI               = 2084,
    EVENTID_HERO11_DRONE_ENEMY_BEGIN               = 2085,
    EVENTID_HERO11_DRONE_ENEMY_END                 = 2086,
    EVENTID_HERO11_DRONE_RELOAD_WEAPON             = 2087,
    EVENTID_OPEN_HERO08_DECOY_CONTROL_BTN          = 2088,
    EVENTID_REOPEN_HERO08_DECOY_CONTROL_BTN        = 2089,
    EVENTID_REOPEN_HERO08_DECOY_UNCONTROL_BTN      = 2090,
    EVENTID_Hero03_RESCUE_ROBOTS_CHANGED           = 2091,
    EVENTID_HERO11_DRONE_DYING_BOMB                = 2092,
    EVENTID_HERO11_DRONE_ROCKET_BOMB               = 2093,
    EVENTID_RUNNING_RELOAD_WEAPON                  = 2094,
    EVENTID_PlayerState_Changed                    = 2100,
    EVENTID_PLAYERSTATE_RECEIVED                   = 2101,
    EVENTID_PLAYERSTATE_INCREASE                   = 2102,
    EVENTID_PLAYERSTATE_DECREASE                   = 2103,
    EVENTID_PLAYERSTATE_CONFIRMLEGEND              = 2104,
    EVENTID_PLAYERSTATE_CHOOSE_LEGEND              = 2105,
    EVENTID_PLAYER_CHANGE_SKIN                     = 2210,
    EVENTID_PLAYER_RANGE_SKIN                      = 2211,
    EVENTID_PLAYER_RANGE_WEAPON_SKIN               = 2212,
    EVENTID_PLAYER_CHANGE_RUNE                     = 2213,
    EVENTID_DATA_REPORT                            = 2310,
    EVENTID_TSS_REPORT_DATA                        = 2311,
    EVENTID_BATTLE_RESULT_DATA                     = 2312,
    EVENTID_BATTLE_RESULT_TEAMDATA                 = 2313,
    EVENTID_BATTLE_RESULT_GNPIN                    = 2324,
    EVENTID_NOTIFY_SKILL_UI_EVENT                  = 2400,
    EVENTID_INGAME_Hero10_TESLA_DAMAGE             = 2409,
    EVENTID_Hero10_PLACE_PYLON                     = 2412,
    EVENTID_Hero10_PLACE_PYLON_FAILED              = 2413,
    EVENTID_HERO05_TPP_EFFECT_START                = 2414,
    EVENTID_HERO05_TPP_EFFECT_LOOP                 = 2415,
    EVENTID_HERO05_TPP_EFFECT_END                  = 2416,
    EVENTID_SHOW_SURVEY_BEACON_PROGRASS            = 2420,
    EVENTID_HR13_BLACKMARKET_INITUI                = 2435,
    EVENTID_HR13_BLACKMARKET_ITEMCLICK             = 2437,
    EVENTID_OPEN_CAMERASWITCHBUTTON                = 2439,
    EVENTID_EVACUATE_RAGE_EXP_CHANGE               = 2501,
    EVENTID_EVACUATE_RAGE_LEVEL_CHANGE             = 2502,
    EVENTID_HEROO8_CROSSHAIRS_INTO_MODE            = 2601,
    EVENTID_HERO08_CROSSHAIRS_EXIT_MODE            = 2602,
    EVENTID_MINIMAP_ADDSTATICITEM                  = 3101,
    EVENTID_MINIMAP_REMOVESTATICITEM               = 3102,
    EVENTID_TARGET_POINT_UPDATE                    = 3105,
    EVENTID_OB_NEW_TARGET                          = 3201,
    EVENTID_OB_END                                 = 3202,
    EVENTID_OB_ENTER_RESULT                        = 3203,
    EVENTID_OB_CANOBCAMERA_CHANGE                  = 3204,
    EVENTID_OB_TARGET_TEAMMATE_NUMBER_CHANGE       = 3303,
    EVENTID_OB_CHARACTER_STATE_CHANGE              = 3301,
    EVENTID_NEXTLIFE_30S_TIP                       = 3402,
    EVENTID_NEXTLIFE_EXPIRED_TIP                   = 3403,
    EVENTID_NEXTLIFE_120S_TIP                      = 3404,
    EVENTID_NEXTLIFE_10S_TIP                       = 3405,
    EVENTID_OB_FREE_CAMERA_SWITCH                  = 3406,
    EVENTID_OB_FIRE_STATE_UPDATE                   = 3407,
    EVENTID_OB_BANNER_DATA                         = 3408,
    EVENTID_OB_TRANSITION                          = 3409,
    EVENTID_OB_CHARACTER_BACKPACK_UPDATE           = 3410,
    EVENTID_REPLAY_START                           = 3501,
    EVENTID_REPLAY_END                             = 3502,
    EVENTID_REPLAY_VIEWTARGET_CHANGE               = 3503,
    EVENTID_REPLAY_RESET_UI                        = 3504,
    EVENTID_REPLAY_LOADING_UI                      = 3505,
    EVENTID_GHOST_CHANGE                           = 4000,
    EVENTID_SPRINTSLIDE_CHANGE                     = 4201,
    EVENTID_SPRINTDIVE_CHANGE                      = 4202,
    EVENTID_DEATH_TOTEM_PROTECT                    = 4203,
    EVENTID_COMMONSIGN_CREATE                      = 4500,
    EVENTID_COMMONSIGN_DELETE                      = 4501,
    EVENTID_SETAIMBUTTON_VISIBLE                   = 4510,
    EVENTID_CONTROLAREA_ACTIVATETIME_UPDATE        = 5001,
    EVENTID_CONTROLAREA_CONTROLCAMP_CHNAGED        = 5002,
    EVENTID_CONTROLAREA_CONTROLLINGCAMPS_CHANGED   = 5003,
    EVENTID_CONTROLAREA_AREASTATUS_CHANGED         = 5004,
    EVENTID_WE_UPDATE_CAMP_STATE                   = 5103,
    EVENTID_WE_UPDATE_OVERTIME                     = 5104,
    EVENTID_WE_SHOW_ROUND_RESULT                   = 5105,
    EVENTID_LOOTZONE_SHOWAREANAME                  = 5200,
    EVENTID_LOOTZONE_SetFatPoiEffect               = 5201,
    EVENTID_AIRDROP_SHOWAIRDROPEFFECT              = 5210,
    EVENTID_AIRDROP_HIDEAIRDROPEFFECT              = 5211,
    EVENTID_AIRDROP_SHOWAIRDROPAREAEFFECT          = 5212,
    EVENTID_AIRDROP_SHOWAIRDROPAREAFIRSTEFFECT     = 5213,
    EVENTID_FLOOTSHIP_ADDICON                      = 5230,
    EVENTID_FLOOTSHIP_REMOVEICON                   = 5231,
    EVENTID_UPDATE_ACTIONBUTTONSTATE               = 5232,
    EVENTID_UPDATE_ACTIONBUTTON_RENDEROPACITY      = 5233,
    EVENTID_SCOPEZOOM_OPEN                         = 6100,
    EVENTID_SCOPEZOOM_CLOSE                        = 6101,
    EVENTID_EQUIPSCOPESHORTCUT                     = 6102,
    EVENTID_CLOSEEQUIPSCOPESHORTCUT                = 6103,
    EVENTID_PAWNSTATE_ENTER                        = 6104,
    EVENTID_UPDATEWEAPONCHARGEBAR                  = 6105,
    EVENTID_PLAY_SOUND                             = 7001,
    EVENTID_Hero01_INITIAL_DETECT_COUNT            = 7002,
    EVENTID_Hero01_DETECT_ANYONE                   = 7003,
    EVENTID_BEEN_REVEALED_BY_Hero01                = 7004,
    EVENTID_TARGET_BEEN_REVEALED_BY_US_Hero01      = 7005,
    EVENTID_Hero01_IS_DETECTING                    = 7006,
    EVENTID_Hero01_IS_HUNTING                      = 7007,
    EVENTID_Hero01_LEAVE_HUNTING                   = 7008,
    EVENTID_Hero01_SHOW_TRACKING_VISION_DETAIL     = 7009,
    EVENTID_HERO54_INITIAL_DETECT_COUNT            = 7012,
    EVENTID_HERO54_DETECT_ANYONE                   = 7013,
    EVENTID_BEEN_REVEALED_BY_HERO54                = 7014,
    EVENTID_TARGET_BEEN_REVEALED_BY_US_HERO54      = 7015,
    EVENTID_HERO54_IS_DETECTING                    = 7016,
    EVENTID_HERO54_IS_HUNTING                      = 7017,
    EVENTID_HERO54_LEAVE_HUNTING                   = 7018,
    EVENTID_HERO54_SHOW_TRACKING_VISION_DETAIL     = 7019,
    EVENTID_AUDIO_QUALITY_CHANGE                   = 7100,
    EVENTID_AUDIO_VOICE_MY_VOLUME_CHANGE           = 7200,
    EVENTID_AUDIO_VOICE_TEAMMATE_VOLUME_CHANGE     = 7201,
    EVENTID_SHOW_EMOTE_TIP                         = 7301,
    EVENTID_BUFF_DJ_TECTICAL_SPEEDUP_ADD           = 7900,
    EVENTID_BUFF_DJ_TECTICAL_SPEEDUP_REMOVE        = 7901,
    EVENTID_BUFF_DJ_ULTIMATE_SPEEDDOWN_ADD         = 7902,
    EVENTID_BUFF_DJ_ULTIMATE_SPEEDDOWN_REMOVE      = 7903,
    EVENTID_BUFF_DJ_ULTIMATE_VIEWSCROLL_SPEEDDOWN_ADD = 7904,
    EVENTID_BUFF_DJ_ULTIMATE_VIEWSCROLL_SPEEDDOWN_REMOVE = 7905,
    EVENTID_SKILL_POST_MESSAGE_ITEM                = 8000,
    EVENTID_BUFF_Hero07_POISON_ADD                 = 8001,
    EVENTID_BUFF_Hero07_POISON_REMOVE              = 8002,
    EVENTID_BUFF_SMOKE_EFFECT_ADD                  = 8003,
    EVENTID_BUFF_SMOKE_EFFECT_REMOVE               = 8004,
    EVENTID_BUFF_HERO11_DRONE_EMP_ATTACT_EFFECT    = 8009,
    EVENTID_BUFF_HERO11_DRONE_EMP_ALERT_EFFECT     = 8010,
    EVENTID_BUFF_SNOWBALL_SCREEN_HURT_START        = 8013,
    EVENTID_BUFF_SNOWBALL_SCREEN_HURT_END          = 8014,
    EVENTID_INGAME_DOUBLEJUMP_START                = 7011,
    EVENTID_INGAME_DOUBLEJUMP_END                  = 7012,
    EVENTID_INGAME_Hero09_Q_EFFECT_START           = 7013,
    EVENTID_TIME_TRAVEL_START_DECOY_VANISH         = 7014,
    EVENTID_TIME_TRAVEL_STOP_DECOY_VANISH          = 7015,
    EVENTID_H19_SHOW_KILLER_DETAIL                 = 7016,
    EVENTID_DAMAGE_LOCK_SHOW                       = 7017,
    EVENTID_DAMAGE_LOCK_TICK                       = 7018,
    EVENTID_DAMAGE_LOCK_HIDE                       = 7019,
    EVENTID_DAMAGE_LOCK_CLICK                      = 7020,
    EVENTID_GOLDMODE_STEAL_ATMCURRENCY_SHOW        = 7021,
    EVENTID_GOLDMODE_PROGRESSTIP_SHOW              = 7022,
    EVENTID_FESECRETDOOR_PROGRESSTIP_SHOW          = 7023,
    EVENTID_SUPPLYBIN_PROGRESSTIP_SHOW             = 7024,
    EVENTID_SCREEN_BLUR_ADD                        = 7025,
    EVENTID_SCREEN_BLUR_REMOVE                     = 7026,
    EVENTID_SHOW_UI                                = 7027,
    EVENTID_REFRESH_PLAYER_HUD                     = 7028,
    EVENTID_COUNTDOWN_START                        = 7029,
    EVENTID_COUNTDOWN_INTERVAL                     = 7030,
    EVENTID_COUNTDOWN_STOP                         = 7031,
    EVENTID_COUNTDOWN_FINISH                       = 7032,
    EVENTID_CIRCLE_REFRESH                         = 7033,
    EVENTID_CIRCLE_SYNCTIME                        = 7034,
    EVENTID_NEWSTOREITEM_UPDATE                    = 7035,
    EVENTID_TEAMMATE_KILL_CHANGED                  = 7036,
    EVENTID_TEAMMATE_DAMAGE_CHANGED                = 7037,
    EVENTID_TEAMMATE_ASSIST_CHANGED                = 7038,
    EVENTID_INIT_JOYTICK_FINISH                    = 7039,
    EVENTID_MANIFIER_CHANGE_COMPLETE               = 7040,
    EVENTID_COMMONSIGN_CREATE_LOCAL                = 7041,
    EVENTID_COMMONSIGN_DELETE_LOCAL                = 7042,
    EVENTID_SCENE_CAM_MOVE_OVER                    = 7043,
    EVENTID_SWITCHHUD                              = 7044,
    EVENTID_RESETUI                                = 7045,
    EVENTID_SELF_TRACKER_DATA_INIT                 = 7046,
    EVENTID_SELF_TRACKER_DATA_REPORT               = 7047,
    EVENTID_BD_BOMB_PLANT                          = 7048,
    EVENTID_BD_BOMB_DEFUSE                         = 7049,
    EVENTID_BORNISLAND_UI                          = 7050,
    EVENTID_BORNISLAND_StopRepickTimeChange        = 7051,
    EVENTID_BORNISLAND_SELECTDATA_REFRESH          = 7052,
    EVENTID_BORNISLAND_FIREWORKSBTNVISIBILITY      = 7053,
    EVENTID_INGAME_DISPLAYCHARACTER_SKIN_LOAD      = 7054,
    EVENTID_SKILL_UI_DISABLED_BY_PAWNSTATE         = 7055,
    EVENTID_FINISHER_WHITE_LIGHT_STAR              = 7056,
    EVENTID_FINISHER_WHITE_LIGHT_END               = 7057,
    EVENTID_FINISHER_LOBBY_SEQUENCE                = 7058,
    EVENTID_INGAMEGUIDE_EVENT                      = 7059,
    EVENTID_INGAMEGUIDE_START_STEP                 = 7060,
    EVENTID_INGAMEGUIDE_END_STEP                   = 7061,
    EVENTID_INGAMEGUIDE_FINISH                     = 7062,
    EVENTID_INGAMEGUIDE_START                      = 7063,
    EVENTID_INGAMEGUIDE_EXECLUA                    = 7064,
    EVENTID_INGAMEGUIDE_DATAINIT                   = 7065,
    EVENTID_INGAMEGUIDE_HIDECURRENTSTEPEFFECT      = 7066,
    EVENTID_BAN_DS                                 = 7067,
    EVENTID_BAN_NOTIFY_CLIENT                      = 7068,
    EVENTID_PSO_PRECOMPILE_END                     = 7069,
    EVENTID_PSO_PRECOMPILE_FAILED                  = 7070,
    EVENTID_PLAYER_BEHSTATE_CHANGE                 = 7071,
    EVENTID_ENCOMY_EXCHANGER_OPEN                  = 7072,
    EVENTID_ENCOMY_CURRENCY_CHANGE                 = 7073,
    EVENTID_ENCOMY_CURRENCY_GET                    = 7074,
    EVENTID_ENCOMY_CURRENCY_ClOSEUI                = 7075,
    EVENTID_ENCOMY_EXCHANGERREWARD_RESULT          = 7076,
    EVENTID_ENCOMY_RETURNRREWARD_RESULT            = 7077,
    EVENTID_ENCOMY_REQUSTCALLBACK                  = 7078,
    EVENTID_ENCOMY_REQUSTBUYRESULT                 = 7079,
    EVENTID_ENCOMY_REQUSTCALLBACK_BYOTHER          = 7080,
    EVENTID_ENCOMY_BUYTOMATE_CALLBACK              = 7081,
    EVENTID_ENCOMY_PLAYERINFO_CALLBACK             = 7082,
    AutonomousProxy_INVINCIBLE_CHANGE              = 7083,
    EVENTID_QUALITY_MONITOR_INIT                   = 7084,
    EVENTID_TUTORIAL_GUIDE_VISIBLE                 = 7085,
    EVENTID_TUTORIAL_GUIDE_START_OR_FINISH         = 7086,
    EVENTID_SCREENT_POSION_START                   = 7087,
    EVENTID_SCREENT_POSION_END                     = 7088,
    EVENTID_PLAYERSTATE_ROLLBACK_UPDATE_HISTORY    = 7089,
    EVENTID_GAMESHOTSCREEN_CAPTURE                 = 7090,
    EVENTID_RECEIVE_DEATHRECALL_RECORD_BEFORE_BATTLERESULT = 7091,
    EVENTID_LOBBY_WEAPON_MONTAGE_END               = 7092,
    EVENTID_PERK_PUT_ON_ID_CHANGED                 = 7093,
    EVENTID_PERK_ACTIVATE                          = 7094,
    EVENTID_PERK_TIPS_DATA_CHANGED                 = 7095,
    EVENTID_CG_MOVIECLIP_FINISHED                  = 7096,
    EVENTID_CG_MOVIEPLAYBACK_FINISHED              = 7097,
    EVENTID_INGAMEGUIDE_DATAINIT_GETLEGENDUSENUM   = 7098,
    EVENTID_AVATAR_SKIN_LOADED                     = 7099,
    EVENTID_TARGET_CHARACTER_GEN                   = 7100,
    EVENTID_TARGET_CHARACTER_DESTROY               = 7101,
    EVENTID_TARGET_HIDDENSTATECHANGE               = 7102,
    EVENTID_DELETE_DOCUMENT_AND_PAK                = 7103,
    EVENTID_LOBBY_WEAPON_SKIN_MONTAGE_FINISH       = 7104,
    EVENTID_SUBJOIN_OB                             = 7105,
    EVENTID_SUBJOIN                                = 7106,
    EVENTID_SUBJOIN_STATE                          = 7107,
    EVENTID_CP_CAPTUREPOINT_INCREASE               = 7108,
    EVENTID_CP_CAPTUREPOINT_DECREASE               = 7109,
    EVENTID_CP_CAPTURE_START                       = 7110,
    EVENTID_CP_CAPTURE_END                         = 7111,
    EVENTID_FIGHTING_REPORT_START                  = 7112,
    EVENTID_FIGHTING_REPORT_ENDED                  = 7113,
    EVENTID_TRACEROUTE_DONE                        = 7114,
    EVENTID_SPAWN_ACTOR_FINISH_LOBBY               = 7115,
    EVENTID_GUNFIGHT_ROUNDITEMID                   = 7116,
    EVENTID_GUNFIGHT_CLOSEREADYUI                  = 7117,
    EVENTID_FOH_OPENUI                             = 7118,
    EVENTID_GAMEPAD_BUTTON_CHANGE                  = 7119,
    EVENTID_GAMEPAD_ATTACH_CHANGE                  = 7120,
    EVENTID_SLIDEJUMP_BEGIN                        = 7121,
    EVENTID_MP_SELECT_INGAME                       = 7122,
    EVENTID_MAINUI_PRELOAD                         = 7123,
    EVENTID_CREATE_MAINUI                          = 7124,
    EVENTID_OPEN_BIGMAP                            = 7125,
    EVENTID_OVERWATCH_PROCESS_SELF_EFFECT          = 7126,
    EVENTID_LIKECHANGE                             = 7127,
    EVENTID_LBS_HTTP_WEBSERVER                     = 7128,
    EVENTID_Hero56_ULTIMATE_GRENADENUM_CHANGED     = 7129,
    EVENTID_CUSTOM_LOGIC_SINGLETON_OVERRIDES       = 7130,
    EVENTID_GM_CHANGE_GAMESTATETIM                 = 7131,
    EVENTID_BATTLEEND_FINISH_STAGE                 = 7132,
    EVENTID_SAVEDPHOTOSALBUM_STATUS                = 7133,
    EVENTID_UPDATE_PRAISE_RECORD                   = 7134,
    EVENTID_BR_COMMANDER_CHANGE                    = 7135,
    EVENTID_BR_COMMANDER_REQUEST                   = 7136,
    EVENTID_BR_WINGAME_CONTINUE                    = 7137,
    EVENTID_HERO11_DRONE_PLAY_ANIM_IN              = 7138,
    EVENTID_MEMORY_MONITOR_NOTIFY_OPEN_LLM         = 7139,
    EVENTID_INGAMEGUIDE_DAILY_DATARECORD           = 7140,
    EVENTID_FIRERANGE_UPDATE_AI_SETTING            = 7141,
    EVENTID_PLAYER_IS_MARK_BLACK                   = 7142,
    EVENTID_TELEPORT_ULTIMATE_OPEN                 = 7143,
    EVENTID_TELEPORT_ULTIMATE_CLOSE                = 7144,
    EVENTID_CLOSE_GMBUTTON                         = 7145,
    EVENTID_OPEN_GMBUTTON                          = 7146,
    EVENTID_DISPLAY_METRICE_CHANGED                = 7147,
    EVENTID_HERO13PRETELEPORT_SHOW                 = 7148,
    EVENTID_INGAMEEVENTCHAT_DATAINIT               = 7149,
    EVENTID_INGAMEEVENTCHAT_DATARECORD             = 7150,
    EVENTID_INSPECT_CHANGE                         = 7151,
    EVENTID_BULLETNUM_CHANGE                       = 7152,
    EVENTID_BULLETDATA_CHANGE                      = 7153,
    EVENTID_BULLETDATANUM_CHANGE                   = 7154,
    EVENTID_EVACUATE_RESPAWN_RESPOND               = 7155,
    EVENTID_EVACUATE_RESPAWN_COUNT_CHANGED         = 7156,
    EVENTID_EVACUATE_RESPAWN_DATA_CHANGED          = 7157,
    EVENTID_EVACUATE_PLAYER_BATTLE_RESULT_DATA_NOTIFY = 7158,
    EVENTID_EVACUATE_GAME_STAGE_CHANGED            = 7159,
    EVENTID_EVACUATE_GAME_STAGE_DATA_CHANGED       = 7160,
    EVENTID_EVACUATE_READINESS_CURRENCIES_CHANGED  = 7161,
    EVENTID_EVACUATE_EVACUATE_POINTS_CHANGED       = 7162,
    EVENTID_EVACUATE_ACTIVITY_EVACUATE_POINTS_CHANGED = 7163,
    EVENTID_EVACUATE_ACTIVITY_DELAY_TIME_CHANGED   = 7164,
    EVENTID_WINDSTORM_EVACUAT_ACTIVE               = 7165,
    EVENTID_WINDSTORM_EVACUAT_END                  = 7166,
    EVENTID_INGAME_DECORATIONJUMP                  = 7167,
    EVENTID_VEHICLE_GETOFF                         = 7168,
    ELuaCppEventType_MAX                           = 8015

};


// Enum  /Script/AClient.ELuaNetworkRemoteContentType
enum class ELuaNetworkRemoteContentType : uint8_t
{
    None                                           = 0,
    TraditionalRPC                                 = 1,
    UnrealRPC                                      = 2,
    ELuaNetworkRemoteContentType_MAX               = 3

};


// Enum  /Script/AClient.EFileArchiveMode
enum class EFileArchiveMode : uint8_t
{
    Read                                           = 0,
    Write                                          = 1,
    Append                                         = 2,
    EFileArchiveMode_MAX                           = 3

};


// Enum  /Script/AClient.EMainHandActionType
enum class EMainHandActionType : uint8_t
{
    ePush                                          = 0,
    ePop                                           = 1,
    eInsert                                        = 2,
    eClear                                         = 3,
    EMainHandActionType_MAX                        = 4

};


// Enum  /Script/AClient.EMainHandConnectStage
enum class EMainHandConnectStage : uint8_t
{
    eActive                                        = 0,
    eLost                                          = 1,
    eSendStack                                     = 2,
    EMainHandConnectStage_MAX                      = 3

};


// Enum  /Script/AClient.EFreeBattleModeType
enum class EFreeBattleModeType : uint8_t
{
    Mode                                           = 0,
    Mode                                           = 1,
    Mode                                           = 2,
    Mode                                           = 3,
    Mode                                           = 4,
    Mode                                           = 5,
    Mode                                           = 6,
    Mode_MAX                                       = 7

};


// Enum  /Script/AClient.EFireRangePlayerOperatorType
enum class EFireRangePlayerOperatorType : uint8_t
{
    ClickMenu                                      = 1,
    ChangeSensitivity                              = 2,
    ChangeLegend                                   = 3,
    EnableReloadNotReduceAmmo                      = 4,
    DisableReloadNotReduceAmmo                     = 5,
    EnableShowDistance                             = 6,
    DisableShowDistance                            = 7,
    EnableShowHp                                   = 8,
    DisableShowHp                                  = 9,
    EnableShowDamage                               = 10,
    DisableShowDamage                              = 11,
    Exit                                           = 12,
    Help                                           = 13,
    ToolbarCollapse                                = 14,
    TargetDistanceCollapse                         = 15,
    DragMenu                                       = 16,
    EnableViewAssist                               = 17,
    DisableViewAssist                              = 18,
    EnableArmorAddExp                              = 19,
    DisableArmorAddExp                             = 20,
    EFireRangePlayerOperatorType_MAX               = 21

};


// Enum  /Script/AClient.EMainTownGameType
enum class EMainTownGameType : uint8_t
{
    None                                           = 0,
    FreeBattle                                     = 1,
    ShootGame                                      = 2,
    AdvancedGame                                   = 3,
    EMainTownGameType_MAX                          = 4

};


// Enum  /Script/AClient.EMaptraIn_map_PlayerStartType
enum class EMaptraIn_map_PlayerStartType : uint8_t
{
    WinTeam                                        = 0,
    FailTeamA                                      = 1,
    FailTeamB                                      = 2,
    EMaptraIn_map_MAX                              = 3

};


// Enum  /Script/AClient.EMeleeAttackType
enum class EMeleeAttackType : uint8_t
{
    EMAT_Left                                      = 0,
    EMAT_Right                                     = 1,
    EMAT_Waist                                     = 2,
    EMAT_Small                                     = 3,
    EMAT_Joystick                                  = 4,
    EMAT_MAX                                       = 5

};


// Enum  /Script/AClient.EMapItemType
enum class EMapItemType : uint8_t
{
    Dynamic                                        = 0,
    Static                                         = 1,
    EMapItemType_MAX                               = 2

};


// Enum  /Script/AClient.EMapPlayerInfoMask
enum class EMapPlayerInfoMask : uint8_t
{
    Default                                        = 0,
    Hero17_hScan                                   = 1,
    VampirePassiveServer                           = 2,
    VampirePassiveClient                           = 3,
    ParachuteAdd                                   = 4,
    GnyxBuffAction_Add                             = 5,
    Hero01PerkShowOutlineAdd                       = 6,
    Hero01TacticalSkillAdd                         = 7,
    GM                                             = 8,
    SuperHeroTransform                             = 9,
    EMapPlayerInfoMask_MAX                         = 10

};


// Enum  /Script/AClient.EMapVehicleState
enum class EMapVehicleState : uint8_t
{
    Normal                                         = 0,
    OnDriver                                       = 1,
    EMapVehicleState_MAX                           = 2

};


// Enum  /Script/AClient.EMiniMapVehicleState
enum class EMiniMapVehicleState : uint8_t
{
    Normal                                         = 0,
    Dispear                                        = 1,
    EMiniMapVehicleState_MAX                       = 2

};


// Enum  /Script/AClient.EMiniMapHero11DroneState
enum class EMiniMapHero11DroneState : uint8_t
{
    DeActive                                       = 0,
    Active                                         = 1,
    EMiniMapHero11DroneState_MAX                   = 2

};


// Enum  /Script/AClient.EMiniMapHero07_DirtyBombState
enum class EMiniMapHero07_DirtyBombState : uint8_t
{
    DeActive                                       = 0,
    Active                                         = 1,
    EMiniMapHero07_MAX                             = 2

};


// Enum  /Script/AClient.EMiniMapAirDropState
enum class EMiniMapAirDropState : uint8_t
{
    Landing                                        = 0,
    Normal                                         = 1,
    Opened                                         = 2,
    EMiniMapAirDropState_MAX                       = 3

};


// Enum  /Script/AClient.EMiniMapColosseumActorState
enum class EMiniMapColosseumActorState : uint8_t
{
    Default                                        = 0,
    ActiveOpen                                     = 1,
    ActiveClose                                    = 2,
    Settlment                                      = 3,
    End                                            = 4,
    EMiniMapColosseumActorState_MAX                = 5

};


// Enum  /Script/AClient.EMiniMapIceBinActorState
enum class EMiniMapIceBinActorState : uint8_t
{
    Freezing                                       = 0,
    UnFreezed                                      = 1,
    EMiniMapIceBinActorState_MAX                   = 2

};


// Enum  /Script/AClient.EMiniMapRobGoldActorState
enum class EMiniMapRobGoldActorState : uint8_t
{
    Normal                                         = 0,
    Recommand                                      = 1,
    EMiniMapRobGoldActorState_MAX                  = 2

};


// Enum  /Script/AClient.EMiniMapHarvesterState
enum class EMiniMapHarvesterState : uint8_t
{
    Normal                                         = 0,
    Extracted                                      = 1,
    EMiniMapHarvesterState_MAX                     = 2

};


// Enum  /Script/AClient.EMiniMapFesecretDoorState
enum class EMiniMapFesecretDoorState : uint8_t
{
    Locked                                         = 0,
    Open                                           = 1,
    EMiniMapFesecretDoorState_MAX                  = 2

};


// Enum  /Script/AClient.EMapPlayerOutDir
enum class EMapPlayerOutDir : uint8_t
{
    Top                                            = 0,
    Left                                           = 1,
    Bottom                                         = 2,
    Right                                          = 3,
    EMapPlayerOutDir_MAX                           = 4

};


// Enum  /Script/AClient.EMinimapPlayerWidgetType
enum class EMinimapPlayerWidgetType : uint8_t
{
    Self                                           = 0,
    Other                                          = 1,
    PureSpectator                                  = 2,
    Enemy                                          = 3,
    SimpleEnemy                                    = 4,
    PureSpectatorFreeCamera                        = 5,
    SuperHero                                      = 6,
    EMinimapPlayerWidgetType_MAX                   = 7

};


// Enum  /Script/AClient.EMonsterSporeType
enum class EMonsterSporeType : uint8_t
{
    None                                           = 0,
    Ordinary                                       = 1,
    Fire                                           = 2,
    Ice                                            = 3,
    Posion                                         = 4,
    EMonsterSporeType_MAX                          = 5

};


// Enum  /Script/AClient.EPatrolDirectionType
enum class EPatrolDirectionType : uint8_t
{
    Forward                                        = 0,
    Reverse                                        = 1,
    Unknown                                        = 2,
    EPatrolDirectionType_MAX                       = 3

};


// Enum  /Script/AClient.ECommercializeSlideEffectFlag
enum class ECommercializeSlideEffectFlag : uint8_t
{
    Self                                           = 1,
    Teammate                                       = 2,
    Enemy                                          = 4,
    Observer                                       = 8,
    ECommercializeSlideEffectFlag_MAX              = 9

};


// Enum  /Script/AClient.ECommercializeSlideEffectFlagBluePrint
enum class ECommercializeSlideEffectFlagBluePrint : uint8_t
{
    Self                                           = 0,
    Teammate                                       = 1,
    Enemy                                          = 2,
    Observer                                       = 3,
    ECommercializeSlideEffectFlagBluePrint_MAX     = 4

};


// Enum  /Script/AClient.EHangingOperatingMode
enum class EHangingOperatingMode : uint8_t
{
    NoHanging                                      = 0,
    CrouchEnterHanging                             = 1,
    DownJoystickEnterHanging                       = 2,
    EHangingOperatingMode_MAX                      = 3

};


// Enum  /Script/AClient.EBaseHangingMode
enum class EBaseHangingMode : uint8_t
{
    NoHanging                                      = 0,
    PressJumpEnterClimbOver                        = 1,
    EBaseHangingMode_MAX                           = 2

};


// Enum  /Script/AClient.EMovementAttribute
enum class EMovementAttribute : uint8_t
{
    BaseSpeedScale                                 = 0,
    WeaponSpeedScale                               = 1,
    BaseSpeedScale_OnlyStand                       = 2,
    WeaponSpeedScale_OnlyStand                     = 3,
    WeaponSpeedScale_OnlyCrouch                    = 4,
    Max                                            = 5

};


// Enum  /Script/AClient.EClimbFailedType
enum class EClimbFailedType : uint8_t
{
    None                                           = 0,
    CancelOrHit                                    = 1,
    NoWall                                         = 2,
    EClimbFailedType_MAX                           = 3

};


// Enum  /Script/AClient.EMovementExternalForceAction
enum class EMovementExternalForceAction : uint8_t
{
    None                                           = 0,
    ParachuteForceBuildingUp                       = 1,
    ParachuteForceBuildingOut                      = 2,
    GravityCannon                                  = 3,
    Glide                                          = 4,
    EMovementExternalForceAction_MAX               = 5

};


// Enum  /Script/AClient.EMovementFallingAction
enum class EMovementFallingAction : uint8_t
{
    None                                           = 0,
    Default                                        = 1,
    Jump                                           = 2,
    SlidingJump                                    = 3,
    ClimbBigJump                                   = 4,
    JumpPadPreJump                                 = 5,
    JumpPadRealJump                                = 6,
    JumpPadAirJump                                 = 7,
    JumpPadLandJump                                = 8,
    GrapplingHook                                  = 9,
    ZipLine                                        = 10,
    Fountain                                       = 11,
    VoidMover                                      = 12,
    ParachuteCannon                                = 13,
    GravityLift                                    = 14,
    Hero17_hJetFly                                 = 15,
    AirJump                                        = 16,
    ServerCallSyncLaunch                           = 17,
    GravityCannon                                  = 18,
    VerticlaJumper                                 = 19,
    Hr13FlyActor                                   = 20,
    Hero08BigJump                                  = 21,
    Glide                                          = 22,
    EMovementFallingAction_MAX                     = 23

};


// Enum  /Script/AClient.EMPMateNameStatus
enum class EMPMateNameStatus : uint8_t
{
    None                                           = 0,
    Normal                                         = 1,
    Invisible                                      = 2,
    OverDistance                                   = 3,
    OutViewport                                    = 4,
    EMPMateNameStatus_MAX                          = 5

};


// Enum  /Script/AClient.EVOSoundType
enum class EVOSoundType : uint8_t
{
    Bc                                             = 0,
    Ping                                           = 1,
    System                                         = 2,
    QueueEX1                                       = 3,
    QueueEX2                                       = 4,
    QueueEX3                                       = 5,
    QueueCount                                     = 6,
    Other                                          = 7,
    EVOSoundType_MAX                               = 8

};


// Enum  /Script/AClient.EMsgPlayer
enum class EMsgPlayer : uint8_t
{
    System                                         = 0,
    Trigger                                        = 1,
    Receiver                                       = 2,
    Relevantor                                     = 3,
    Enemy                                          = 4,
    EMsgPlayer_MAX                                 = 5

};


// Enum  /Script/AClient.EBroadcastType
enum class EBroadcastType : uint8_t
{
    Owner                                          = 0,
    Team                                           = 1,
    All                                            = 2,
    Range                                          = 3,
    Default                                        = 4,
    EBroadcastType_MAX                             = 5

};


// Enum  /Script/AClient.EMsgTriggerConditionType
enum class EMsgTriggerConditionType : uint8_t
{
    None                                           = 0,
    InRange                                        = 1,
    EMsgTriggerConditionType_MAX                   = 2

};


// Enum  /Script/AClient.EMsgReceiverType
enum class EMsgReceiverType : uint8_t
{
    Owner                                          = 0,
    Specific                                       = 1,
    Team                                           = 2,
    All                                            = 3,
    Condition                                      = 4,
    Enemy                                          = 5,
    Teammate                                       = 6,
    EMsgReceiverType_MAX                           = 7

};


// Enum  /Script/AClient.EMsgTriggerType
enum class EMsgTriggerType : uint8_t
{
    None                                           = 0,
    Specific                                       = 1,
    RandOneEachTeam                                = 2,
    RandOneInTeammate                              = 3,
    Condition                                      = 4,
    RandOneEachTeamExclude                         = 5,
    RandOneInTeammateExclude                       = 6,
    EMsgTriggerType_MAX                            = 7

};


// Enum  /Script/AClient.EStateNetType
enum class EStateNetType : uint8_t
{
    Loacal                                         = 0,
    Server                                         = 1,
    Client                                         = 2,
    EStateNetType_MAX                              = 3

};


// Enum  /Script/AClient.ENewYearFirecrackerState
enum class ENewYearFirecrackerState : uint8_t
{
    Init                                           = 0,
    Rise                                           = 1,
    Explosion                                      = 2,
    Destroy                                        = 3,
    ENewYearFirecrackerState_MAX                   = 4

};


// Enum  /Script/AClient.ESporeSpawnSource
enum class ESporeSpawnSource : uint8_t
{
    ZoneAutoSpawn                                  = 0,
    Skill                                          = 1,
    ESporeSpawnSource_MAX                          = 2

};


// Enum  /Script/AClient.EBeaconMsgType
enum class EBeaconMsgType : uint8_t
{
    None                                           = 0,
    PingBanner                                     = 1,
    PingBeacon                                     = 2,
    EBeaconMsgType_MAX                             = 3

};


// Enum  /Script/AClient.ECharacterInfoUIType
enum class ECharacterInfoUIType : uint8_t
{
    Replay                                         = 0,
    Spectator                                      = 1,
    ECharacterInfoUIType_MAX                       = 2

};


// Enum  /Script/AClient.EPureOBTargetState
enum class EPureOBTargetState : uint8_t
{
    None                                           = 0,
    Controller                                     = 1,
    BornIslandActor                                = 2,
    PawnState                                      = 3,
    Finish                                         = 4,
    EPureOBTargetState_MAX                         = 5

};


// Enum  /Script/AClient.EOBKeyEventType
enum class EOBKeyEventType : uint8_t
{
    None                                           = 0,
    OpenMinimap                                    = 1,
    MinimapZoomInOut                               = 2,
    TeamChangeTarget                               = 3,
    TeammateChangeTarget                           = 4,
    HideAllUI                                      = 5,
    ShowMouse                                      = 6,
    PlayerPenetrate                                = 7,
    EOBKeyEventType_MAX                            = 8

};


// Enum  /Script/AClient.EOutlineEffectType
enum class EOutlineEffectType : uint8_t
{
    EOT_Invalid                                    = 0,
    EOT_CharacterFriendly                          = 1,
    EOT_Hero07_DirtyBombYellow                     = 3,
    EOT_Hero01_he_Reveal                           = 4,
    EOT_Hero01_he_Hunting                          = 5,
    EOT_Hero11DroneSelf                            = 11,
    EOT_Hero11SpyOn                                = 12,
    EOT_VampireOutline                             = 13,
    EOT_CommonPing                                 = 20,
    EOT_Hero01_he_RevealAndHunting                 = 25,
    EOT_ItemFriendly                               = 26,
    EOT_Hero01_he_Sonar                            = 32,
    EOT_Hero01_he_SelfHunting                      = 33,
    EOT_CasticPoisionYellow                        = 34,
    EOT_Hero07_DirtyBombRed                        = 35,
    EOT_CasticPoisionRed                           = 36,
    EOT_ItemEnemy                                  = 38,
    EOT_CharacterEnemy                             = 59,
    EOT_Hero08Ultimate                             = 62,
    EOT_Hero11DronePlayer                          = 63,
    EOT_Hero42_VoidEnemy                           = 67,
    EOT_Hero42_VoidTeammate                        = 73,
    EOT_BinActor                                   = 75,
    EOT_Hero11DroneSpyBin                          = 76,
    EOT_TPPHero07_InGasEffect                      = 83,
    EOT_CasticPoisionRed_Perk                      = 87,
    EOT_CasticPoisionYellow_Perk                   = 88,
    EOT_ReplayTargetEnemy                          = 93,
    EOT_TPPAddSmokeEffect                          = 97,
    EOT_FirstPlayer                                = 99,
    EOT_GuardianRange                              = 107,
    EOT_TDMKillerSign                              = 108,
    EOT_BuildHouseOBTeammatePlayer                 = 110,
    EOT_Hero11ADSPlayer                            = 111,
    EOT_BuildHouseOBEnemyPlayer                    = 112,
    EOT_MAX                                        = 113

};


// Enum  /Script/AClient.EOutlineSourceType
enum class EOutlineSourceType : uint8_t
{
    EOST_Friendly                                  = 0,
    EOST_Enemy                                     = 1,
    EOST_Hero10_                                   = 2,
    EOST_Ping                                      = 3,
    EOST_SmokeBomb                                 = 4,
    EOST_Hero07_Posion                             = 5,
    EOST_Hero11Drone                               = 6,
    EOST_Hero01_he_                                = 7,
    EOST_SiWangHe                                  = 8,
    EOST_PickupItem                                = 9,
    EOST_Hero08Ultimate                            = 10,
    EOST_Hero42_Ultimate                           = 11,
    EOST_Map_resPawn_m                             = 12,
    EOST_LoaPassive                                = 13,
    EOST_H19Tactical                               = 14,
    EOST_Hero15_BlackHole                          = 15,
    EOST_Vehicle                                   = 16,
    EOST_Hero17_hTaticsAuxillary                   = 17,
    EOST_Hero17_hPerk                              = 18,
    EOST_Vampire                                   = 19,
    EOST_GuardianRange                             = 20,
    EOST_Hero53                                    = 21,
    EOST_Hero54                                    = 22,
    EOST_BuildHouseOB                              = 23,
    EOST_MAX                                       = 32

};


// Enum  /Script/AClient.EParachuteForceInteractiveMode
enum class EParachuteForceInteractiveMode : uint8_t
{
    ManualInteraction                              = 0,
    AutomaticInteraction                           = 1,
    SemiAutomaticInteraction                       = 2,
    EParachuteForceInteractiveMode_MAX             = 3

};


// Enum  /Script/AClient.EParachuteForceState
enum class EParachuteForceState : uint8_t
{
    Up                                             = 0,
    LaunchOut                                      = 1,
    EParachuteForceState_MAX                       = 2

};


// Enum  /Script/AClient.EParachuteForceBuildingPart
enum class EParachuteForceBuildingPart : uint8_t
{
    VFX_Jiantou                                    = 0,
    VFX_Dingzuo1                                   = 1,
    VFX_Dizuo                                      = 2,
    VFX_Guangzhu                                   = 3,
    vfx_changzhuguangzhu                           = 4,
    SM_Jump_06                                     = 5,
    EParachuteForceBuildingPart_MAX                = 6

};


// Enum  /Script/AClient.EParachuteTeamBtnType
enum class EParachuteTeamBtnType : uint8_t
{
    Leave                                          = 0,
    Join                                           = 1,
    EParachuteTeamBtnType_MAX                      = 2

};


// Enum  /Script/AClient.PartycleBoxKillType
enum class PartycleBoxKillType : uint8_t
{
    KillInside                                     = 0,
    KillOutside                                    = 1,
    PartycleBoxKillType_MAX                        = 2

};


// Enum  /Script/AClient.ESingleType
enum class ESingleType : uint8_t
{
    None                                           = 0,
    Shoot                                          = 1,
    Sight                                          = 2,
    Max                                            = 3

};


// Enum  /Script/AClient.ERoleType
enum class ERoleType : uint8_t
{
    None                                           = 0,
    SimulatedProxy                                 = 1,
    AutonomousProxy                                = 2,
    Max                                            = 3

};


// Enum  /Script/AClient.EPersonalType
enum class EPersonalType : uint8_t
{
    None                                           = 0,
    FPP                                            = 1,
    TPP                                            = 2,
    Max                                            = 3

};


// Enum  /Script/AClient.EParticleSystemContainerType
enum class EParticleSystemContainerType : uint8_t
{
    None                                           = 0,
    OpenFire                                       = 1,
    Max                                            = 2

};


// Enum  /Script/AClient.EPartyStageMeterialParamType
enum class EPartyStageMeterialParamType : uint8_t
{
    ELinearColorType                               = 0,
    EScalarValueType                               = 1,
    EPartyStageMeterialParamType_MAX               = 2

};


// Enum  /Script/AClient.EPartyStageType
enum class EPartyStageType : uint8_t
{
    DJPartyStage                                   = 0,
    EPartyStageType_MAX                            = 1

};


// Enum  /Script/AClient.EStageDeactiveReason
enum class EStageDeactiveReason : uint8_t
{
    NormalPhaseAllOver                             = 0,
    ForceDeactive                                  = 1,
    EStageDeactiveReason_MAX                       = 2

};


// Enum  /Script/AClient.EStageActionType
enum class EStageActionType : uint8_t
{
    Animation                                      = 0,
    MaterialChange                                 = 1,
    MaterialColor                                  = 2,
    StartStageSound                                = 3,
    StopStageSound                                 = 4,
    ParticleShow                                   = 5,
    SpawnSomeActor                                 = 6,
    AddBuff                                        = 7,
    RemoveBuff                                     = 8,
    AddCureSelfBuff                                = 9,
    AddCureSelfBuffVolume                          = 10,
    RemoveCureSelfBuff                             = 11,
    ShowComponent                                  = 12,
    HideComponent                                  = 13,
    SpawnLoot                                      = 14,
    Dither                                         = 15,
    LevelSequence                                  = 16,
    StopAnimation                                  = 17,
    PlaySoundAtLoc                                 = 18,
    MAX                                            = 19

};


// Enum  /Script/AClient.EPerkTipType
enum class EPerkTipType : uint8_t
{
    None                                           = 0,
    Perk                                           = 1,
    Hero06_h_Passive                               = 2,
    Hero05Passive                                  = 3,
    Hero10_Ultimate                                = 4,
    Hr13Tactics                                    = 5,
    EPerkTipType_MAX                               = 6

};


// Enum  /Script/AClient.EVehicleCollisionForceLimit
enum class EVehicleCollisionForceLimit : uint8_t
{
    None                                           = 0,
    UseLimit                                       = 1,
    UseNeg                                         = 2,
    EVehicleCollisionForceLimit_MAX                = 3

};


// Enum  /Script/AClient.EVehicleCollisionResponse
enum class EVehicleCollisionResponse : uint8_t
{
    Bouncy                                         = 0,
    ModifySpeed                                    = 1,
    EVehicleCollisionResponse_MAX                  = 2

};


// Enum  /Script/AClient.EForbiddenDropItemReason
enum class EForbiddenDropItemReason : uint8_t
{
    None                                           = 0,
    ExcerciseMode                                  = 1,
    EForbiddenDropItemReason_MAX                   = 2

};


// Enum  /Script/AClient.EForbiddenPickupReason
enum class EForbiddenPickupReason : uint8_t
{
    None                                           = 0,
    ExcerciseMode                                  = 1,
    Hero17Ultimate                                 = 2,
    EForbiddenPickupReason_MAX                     = 3

};


// Enum  /Script/AClient.EPickupCheckType
enum class EPickupCheckType : uint8_t
{
    PCT_None                                       = 0,
    PCT_CheckActor                                 = 1,
    PCT_CheckActorBox                              = 2,
    PCT_ActorEffect                                = 3,
    PCT_PickupUI                                   = 4,
    PCT_AutoPickup                                 = 5,
    PCT_CombData                                   = 6,
    PCT_ReLocation                                 = 7,
    PCT_TrainSupply                                = 8,
    PCT_MAX                                        = 9

};


// Enum  /Script/AClient.EPickupDistType
enum class EPickupDistType : uint8_t
{
    PDT_None                                       = 0,
    PDT_AroundActor                                = 1,
    PDT_EffectActor                                = 2,
    PDT_AroundActorBox                             = 3,
    PDT_NotInTeam                                  = 4,
    PDT_TrainSupply                                = 5,
    PDT_MAX                                        = 6

};


// Enum  /Script/AClient.EItemPickUpableState
enum class EItemPickUpableState : uint8_t
{
    None                                           = 0,
    Disable                                        = 1,
    Click                                          = 2,
    LongClick                                      = 3,
    All                                            = 4,
    EItemPickUpableState_MAX                       = 5

};


// Enum  /Script/AClient.EPickUpReqSource
enum class EPickUpReqSource : uint8_t
{
    Default                                        = 0,
    Hr13Market                                     = 1,
    TrainSupply                                    = 2,
    EPickUpReqSource_MAX                           = 3

};


// Enum  /Script/AClient.EPickUpClientErrorCode
enum class EPickUpClientErrorCode : uint8_t
{
    HaveBetterArmor                                = 1,
    HaveThisEquipped                               = 2,
    HaveBetterHelmet                               = 3,
    HaveBetterBackpack                             = 4,
    HaveBetterEq140_eq140_eq_                      = 5,
    EPickUpClientErrorCode_MAX                     = 6

};


// Enum  /Script/AClient.EPickupShowState
enum class EPickupShowState : uint8_t
{
    PSS_Hide                                       = 0,
    PSS_ShowTop                                    = 1,
    PSS_ShowNear                                   = 2,
    PSS_ShowTom                                    = 3,
    PSS_MAX                                        = 4

};


// Enum  /Script/AClient.ELootZoneReplaceType
enum class ELootZoneReplaceType : uint8_t
{
    None                                           = 0,
    Weapon                                         = 1,
    Max                                            = 2

};


// Enum  /Script/AClient.EWeaponAttahBulletType
enum class EWeaponAttahBulletType : uint8_t
{
    Normal                                         = 0,
    Bin                                            = 1,
    Featustore                                     = 2,
    Max                                            = 3

};


// Enum  /Script/AClient.FBuildingType
enum class FBuildingType : uint8_t
{
    BT_Normal                                      = 0,
    BT_Bin                                         = 1,
    BT_Max                                         = 2

};


// Enum  /Script/AClient.FLootZoneType
enum class FLootZoneType : uint8_t
{
    None                                           = 0,
    HighZone                                       = 1,
    MediumZone                                     = 2,
    LowZone                                        = 3,
    Custom                                         = 4,
    FLootZoneType_MAX                              = 5

};


// Enum  /Script/AClient.EPickupOutlineRenderLevel
enum class EPickupOutlineRenderLevel : uint8_t
{
    Rough                                          = 0,
    Smooth                                         = 1,
    Balance                                        = 2,
    HD                                             = 3,
    UltraHD                                        = 4,
    ExtremeHD                                      = 5,
    Original                                       = 6,
    EPickupOutlineRenderLevel_MAX                  = 7

};


// Enum  /Script/AClient.EPickupItemReportType
enum class EPickupItemReportType : uint8_t
{
    None                                           = 0,
    FlootShip                                      = 1,
    LootBinDynamic                                 = 2,
    LootBinDrawer                                  = 3,
    TTOColosseum                                   = 4,
    KillExtraDrop                                  = 5,
    Treasure                                       = 6,
    GunRack                                        = 6,
    TrainBin                                       = 7,
    TrainLottery                                   = 8,
    BunckerLoot                                    = 9,
    Max                                            = 10

};


// Enum  /Script/AClient.EPickUpPoolType
enum class EPickUpPoolType : uint8_t
{
    None                                           = 0,
    AroundPickUpPool                               = 1,
    TombBoxPickUpPool                              = 2,
    Hero45PickupPool                               = 3,
    EPickUpPoolType_MAX                            = 4

};


// Enum  /Script/AClient.EQuickReplaceItem
enum class EQuickReplaceItem : uint8_t
{
    BackPack                                       = 0,
    Weapon1                                        = 1,
    Weapon2                                        = 2,
    EQuickReplaceItem_MAX                          = 3

};


// Enum  /Script/AClient.EPingDataReportObjectType
enum class EPingDataReportObjectType : uint8_t
{
    None                                           = 0,
    Grould                                         = 1,
    Enemy                                          = 2,
    Item                                           = 3,
    SceneObject                                    = 4,
    Hero01_he_                                     = 5,
    Others                                         = 6,
    EPingDataReportObjectType_MAX                  = 7

};


// Enum  /Script/AClient.EPingUIActionType
enum class EPingUIActionType : uint8_t
{
    Open                                           = 1,
    Back                                           = 2,
    Hover                                          = 3,
    Conform                                        = 4,
    EPingUIActionType_MAX                          = 5

};


// Enum  /Script/AClient.EFromMakeType
enum class EFromMakeType : uint8_t
{
    None                                           = 0,
    Normal                                         = 1,
    Jump                                           = 2,
    BigMap                                         = 3,
    AttackEnemy                                    = 4,
    InGameChat                                     = 5,
    EFromMakeType_MAX                              = 6

};


// Enum  /Script/AClient.EPingVisualType
enum class EPingVisualType : uint8_t
{
    Normal                                         = 1,
    Item                                           = 2,
    Weapon                                         = 3,
    BigMap                                         = 4,
    MiniMap                                        = 5,
    Skill                                          = 6,
    SkillCD                                        = 7,
    EPingVisualType_MAX                            = 8

};


// Enum  /Script/AClient.EAxisType
enum class EAxisType : uint8_t
{
    None                                           = 0,
    X                                              = 1,
    Y                                              = 2,
    Z                                              = 3,
    EAxisType_MAX                                  = 4

};


// Enum  /Script/AClient.EMakeDamageType
enum class EMakeDamageType : uint8_t
{
    Normal                                         = 0,
    IgnoreArmor                                    = 1,
    Signal                                         = 2,
    EMakeDamageType_MAX                            = 3

};


// Enum  /Script/AClient.EHitPositionDetailed
enum class EHitPositionDetailed : uint8_t
{
    None                                           = 0,
    Head                                           = 1,
    Body                                           = 2,
    LeftArm                                        = 3,
    RightArm                                       = 4,
    LeftThigh                                      = 5,
    RightThigh                                     = 6,
    EHitPositionDetailed_MAX                       = 7

};


// Enum  /Script/AClient.EHitDamagePositionAI
enum class EHitDamagePositionAI : uint8_t
{
    Non                                            = 0,
    Head                                           = 1,
    Body                                           = 2,
    LeftArm                                        = 3,
    RightArm                                       = 4,
    LeftThigh                                      = 5,
    RightThigh                                     = 6,
    EHitDamagePositionAI_MAX                       = 7

};


// Enum  /Script/AClient.EPlayerLoadoutStatus
enum class EPlayerLoadoutStatus : uint8_t
{
    None                                           = 0,
    ChooseLoadout                                  = 1,
    ChooseWeapon                                   = 2,
    ChooseOver                                     = 3,
    EPlayerLoadoutStatus_MAX                       = 4

};


// Enum  /Script/AClient.EPlayerPrepareFlag
enum class EPlayerPrepareFlag : uint8_t
{
    None                                           = 0,
    PrepareCharacter                               = 1,
    PreparePlayerState                             = 2,
    EPlayerPrepareFlag_MAX                         = 3

};


// Enum  /Script/AClient.EPlayerTombBoxSecLifeState
enum class EPlayerTombBoxSecLifeState : uint8_t
{
    Hide                                           = 0,
    ShowEffect                                     = 1,
    ShowIcon                                       = 2,
    EPlayerTombBoxSecLifeState_MAX                 = 3

};


// Enum  /Script/AClient.EPlayerTombBoxSpawnReason
enum class EPlayerTombBoxSpawnReason : uint8_t
{
    Normal                                         = 0,
    FallingOutDeath                                = 1,
    LeeWayTrample                                  = 2,
    ReSpawn                                        = 3,
    EPlayerTombBoxSpawnReason_MAX                  = 4

};


// Enum  /Script/AClient.ETranformHeroActionType
enum class ETranformHeroActionType : uint8_t
{
    eTransformStart                                = 0,
    eTransformEnd                                  = 1,
    eStartTimeAlignError                           = 2,
    eEndTimeAlignError                             = 3,
    eStartFailed                                   = 4,
    eInterrupt                                     = 5,
    ETranformHeroActionType_MAX                    = 6

};


// Enum  /Script/AClient.ETransformHeroStage
enum class ETransformHeroStage : uint8_t
{
    eNone                                          = 0,
    eTransforming                                  = 1,
    eWaitServer                                    = 2,
    ETransformHeroStage_MAX                        = 3

};


// Enum  /Script/AClient.ESetSignalValueReason
enum class ESetSignalValueReason : uint8_t
{
    None                                           = 0,
    Dying                                          = 1,
    DyingReset                                     = 2,
    AutoRepair                                     = 3,
    Rescue                                         = 4,
    Recover                                        = 5,
    PoisonDamage                                   = 6,
    GM                                             = 7,
    AIActive                                       = 8,
    ESetSignalValueReason_MAX                      = 9

};


// Enum  /Script/AClient.EKillType
enum class EKillType : uint8_t
{
    KnockDown                                      = 0,
    Death                                          = 1,
    BeKnockDown                                    = 2,
    BeDeath                                        = 3,
    AssistKill                                     = 4,
    EKillType_MAX                                  = 5

};


// Enum  /Script/AClient.EPlayerABTagValue
enum class EPlayerABTagValue : uint8_t
{
    ENone                                          = 0,
    EGroupA                                        = 1,
    EGroupB                                        = 2,
    EPlayerABTagValue_MAX                          = 3

};


// Enum  /Script/AClient.EPlayerABTagType
enum class EPlayerABTagType : uint8_t
{
    AutoPathFinding                                = 30,
    EPlayerABTagType_MAX                           = 31

};


// Enum  /Script/AClient.EHealingSelfType
enum class EHealingSelfType : uint8_t
{
    OnlyHp                                         = 0,
    OnlyShield                                     = 1,
    HpFirst                                        = 2,
    ShieldFirst                                    = 3,
    OnlyHpWithShieldBreak                          = 4,
    OnlyShieldWithShieldBreak                      = 5,
    HpFirstWithShieldBreak                         = 6,
    ShieldFirstWithShieldBreak                     = 7,
    EHealingSelfType_MAX                           = 8

};


// Enum  /Script/AClient.EOutUseFeatustoreReason
enum class EOutUseFeatustoreReason : uint8_t
{
    Normal                                         = 0,
    ByRepByNoUsing                                 = 1,
    ByTakeDamage                                   = 2,
    ByLeaveState                                   = 3,
    ByNetLost                                      = 4,
    ByPlayerMoving                                 = 5,
    ByCantEnterState                               = 6,
    ByConfigError                                  = 7,
    EOutUseFeatustoreReason_MAX                    = 8

};


// Enum  /Script/AClient.EUseFeatustoreState
enum class EUseFeatustoreState : uint8_t
{
    NoUsing                                        = 0,
    ReadyToUsing                                   = 1,
    Using                                          = 2,
    EUseFeatustoreState_MAX                        = 3

};


// Enum  /Script/AClient.EPlayerAddForceType
enum class EPlayerAddForceType : uint8_t
{
    OneDirection                                   = 0,
    FromOnePoint                                   = 1,
    EPlayerAddForceType_MAX                        = 2

};


// Enum  /Script/AClient.EInOutTp101_tp1_Reason
enum class EInOutTp101_tp1_Reason : uint8_t
{
    Tp101_tp1_                                     = 0,
    DomeShield                                     = 1,
    EInOutTp101_tp1_MAX                            = 2

};


// Enum  /Script/AClient.ELutUseSource
enum class ELutUseSource : uint8_t
{
    None                                           = 0,
    UseFromGamePlay                                = 1,
    UseFromSkill                                   = 2,
    UseFromHero05Tac                               = 3,
    UseFromTransfer                                = 4,
    UseFromHero42_Tac                              = 5,
    UseFromHero42_Ult                              = 6,
    MaxIndex                                       = 63,
    ELutUseSource_MAX                              = 64

};


// Enum  /Script/AClient.EMeshCollisionResponseSource
enum class EMeshCollisionResponseSource : uint8_t
{
    None                                           = 0,
    EMeshCollisionResponseSource_MAX               = 1

};


// Enum  /Script/AClient.EMeshDitherSource
enum class EMeshDitherSource : uint8_t
{
    None                                           = 0,
    FromNearWall                                   = 1,
    SkillAction                                    = 2,
    VoidMover                                      = 3,
    InvisibleEffect                                = 4,
    Hero42_Void                                    = 5,
    Hero11DronePerk                                = 6,
    GM                                             = 7,
    MaxIndex                                       = 32,
    EMeshDitherSource_MAX                          = 33

};


// Enum  /Script/AClient.EMeshUseSource
enum class EMeshUseSource : uint8_t
{
    None                                           = 0,
    UseFromCameraMode                              = 1,
    UseFromBombDefender                            = 2,
    UseFromEmoji                                   = 3,
    UseFromCharacterMovement                       = 4,
    UseFromEnterVoid                               = 5,
    UseFromUseDrone                                = 6,
    UseFromHero42_                                 = 7,
    UseFromRescue                                  = 8,
    UseFromParachute                               = 9,
    UseFromSequencer                               = 10,
    UseFromAiming                                  = 11,
    UseFromRespawn                                 = 12,
    UseFromDeath                                   = 13,
    UseFromInspectWeapon                           = 14,
    UseFromUseFeatustore                           = 15,
    UseFromSkillAction                             = 16,
    UseFromHero50Tactical                          = 17,
    UseFromWeaponView                              = 18,
    UseFromVehicleView                             = 19,
    UseFromForceDance                              = 20,
    UseFromNotViewTarget                           = 21,
    MaxIndex                                       = 63,
    EMeshUseSource_MAX                             = 64

};


// Enum  /Script/AClient.EMeshHiddenSource
enum class EMeshHiddenSource : uint8_t
{
    None                                           = 0,
    HiddenFromCameraMode                           = 1,
    HiddenFromDistance                             = 2,
    HiddenFromGM                                   = 3,
    HiddenFromGuide                                = 4,
    HiddenFromHero11Skill                          = 5,
    HiddenFromFinisherLobby                        = 6,
    HiddenFromFinisher                             = 7,
    HiddenFromFinisherDeath                        = 8,
    HiddenFromHero42_                              = 9,
    HiddenFromHero13Skill                          = 10,
    HiddenFromClimbing                             = 11,
    HiddenFromActorHidden                          = 12,
    HiddenFormJumpPlane                            = 13,
    HiddenFromAntiPeek                             = 14,
    HiddenFromShadowTutorial                       = 15,
    HiddenFromTeamMate                             = 16,
    HiddenFromSkillAction                          = 17,
    HiddenFromShowStand                            = 18,
    HiddenFromHero50Dying                          = 19,
    HiddenFormPlayerDying                          = 20,
    MaxIndex                                       = 63,
    EMeshHiddenSource_MAX                          = 64

};


// Enum  /Script/AClient.EBattleCharacterType
enum class EBattleCharacterType : uint32_t
{
    None                                           = 0,
    BC_megaKill                                    = 1001,
    BC_anotherSquadAttackingUs                     = 1002,
    BC_mi120_m                                     = 1003,
    BC_championEliminated                          = 1004,
    BC_congratsKill                                = 1005,
    BC_damageEnemy                                 = 1006,
    BC_enemyGrenade                                = 1007,
    BC_engagingEnemy                               = 1008,
    BC_firstBlood                                  = 1009,
    BC_frag                                        = 1010,
    BC_gotFriendlyBanner                           = 1011,
    BC_healing                                     = 1012,
    BC_iBecomeKnocKout_k                           = 1013,
    BC_iDownedAnEnemy                              = 1014,
    BC_iDownedAnotherEnemy                         = 1015,
    BC_iDownedMultiple                             = 1016,
    BC_iKilledAnEnemy                              = 1017,
    BC_iKilledAnEnemyWithHeirloom                  = 1018,
    BC_imDown                                      = 1019,
    BC_knocKout_kNew                               = 1020,
    BC_legendsLeft2_solo                           = 1021,
    BC_legendsLeft3_solo                           = 1022,
    BC_legendsLeftHalf_solo                        = 1023,
    BC_reload                                      = 1024,
    BC_returnFromRespawn                           = 1025,
    BC_reviveSelf                                  = 1026,
    BC_reviveThanks                                = 1027,
    BC_revivingPlayer                              = 1028,
    BC_squadKill                                   = 1029,
    BC_squadmateBecomesKnocKout_k                  = 1030,
    BC_squadsLeft2                                 = 1031,
    BC_squadsLeft3                                 = 1032,
    BC_squadsLeftHalf                              = 1033,
    BC_squadTeamWipe                               = 1034,
    BC_takingDamage                                = 1035,
    BC_takingFire                                  = 1036,
    BC_Combustion                                  = 1037,
    BC_twoSquaddiesLeft                            = 1038,
    BC_usingMd100_Md1_                             = 1039,
    BC_weKilledChampion                            = 1040,
    BC_weKilledKnocKout_k                          = 1041,
    BC_weTookFirstBlood                            = 1042,
    BC_effort_land                                 = 1043,
    BC_effort_landhigh                             = 1044,
    BC_effort_wallmantlebelow                      = 1045,
    BC_effort_climb                                = 1046,
    BC_effort_pain                                 = 1047,
    BC_effort_death                                = 1048,
    BC_effort_cough                                = 1049,
    BC_effort_melee                                = 1050,
    BC_effort_meleestrong                          = 1051,
    BC_map_resPawn_mDeploy                         = 1052,
    BC_revivingPlayerInBubble                      = 1053,
    BC_tp101_tp1_Deploy                            = 1054,
    BC_propsMI140Grenade                           = 1055,
    BC_ForceDance                                  = 1056,
    EBattleCharacterType_MAX                       = 1057

};


// Enum  /Script/AClient.EThrowablePropsPhase
enum class EThrowablePropsPhase : uint8_t
{
    Init                                           = 0,
    HighAim                                        = 1,
    LowAim                                         = 2,
    Launch                                         = 3,
    EThrowablePropsPhase_MAX                       = 4

};


// Enum  /Script/AClient.EFinisherEndState
enum class EFinisherEndState : uint8_t
{
    NoEnd                                          = 0,
    Normal                                         = 1,
    Interrupt                                      = 2,
    SourceDead                                     = 3,
    TargetDead                                     = 4,
    InterruptByDamage                              = 5,
    EFinisherEndState_MAX                          = 6

};


// Enum  /Script/AClient.ERespawnOperateAudio
enum class ERespawnOperateAudio : uint8_t
{
    Begin                                          = 0,
    End                                            = 1,
    Success                                        = 2,
    ERespawnOperateAudio_MAX                       = 3

};


// Enum  /Script/AClient.ERescueSelfSource
enum class ERescueSelfSource : uint8_t
{
    GoldShield                                     = 0,
    Skill                                          = 1,
    ERescueSelfSource_MAX                          = 2

};


// Enum  /Script/AClient.EPlayerNextLifeRespawnState
enum class EPlayerNextLifeRespawnState : uint8_t
{
    Normal                                         = 0,
    WaitRespawn                                    = 1,
    CanRespawn                                     = 2,
    RespawnEnd                                     = 3,
    EPlayerNextLifeRespawnState_MAX                = 4

};


// Enum  /Script/AClient.EGrenadeType
enum class EGrenadeType : uint8_t
{
    UnknownGrenade                                 = 0,
    StunGrenade                                    = 1,
    FireGrenade                                    = 2,
    SmokeGrenade                                   = 3,
    Mi100_mi10_                                    = 4,
    AppleGrenade                                   = 5,
    MagicDanceGrenade                              = 6,
    RainforcementGrenade                           = 7,
    CG_StunGrenade                                 = 8,
    CG_FireGrenade                                 = 9,
    CG_SmokeGrenade                                = 10,
    CG_Mi100_mi10_                                 = 11,
    CG_StinkGrenade                                = 12,
    CG_FireWorksGrenade                            = 13,
    CG_ToyApple                                    = 14,
    CG_SingerDoll                                  = 15,
    Mi130_mi130_mi_                                = 16,
    PumpkinGrenade                                 = 17,
    ReservedGrenade1                               = 18,
    ReservedGrenade2                               = 19,
    ReservedGrenade3                               = 20,
    ReservedGrenade4                               = 21,
    GrenadeMax                                     = 22,
    EGrenadeType_MAX                               = 23

};


// Enum  /Script/AClient.EThrowGrenadeMode
enum class EThrowGrenadeMode : uint8_t
{
    HighThrowMode                                  = 0,
    LowThrowMode                                   = 1,
    EThrowGrenadeMode_MAX                          = 2

};


// Enum  /Script/AClient.EParachuteEffectType
enum class EParachuteEffectType : uint8_t
{
    None                                           = 0,
    Body                                           = 1,
    BodySideL                                      = 2,
    BodySideR                                      = 3,
    LongTrail                                      = 4,
    NormalTrailL                                   = 5,
    NormalTrailR                                   = 6,
    MAX                                            = 7

};


// Enum  /Script/AClient.EMParticleEffectType
enum class EMParticleEffectType : uint32_t
{
    None                                           = 4294967295,
    NoneScriptType                                 = 0,
    CameraEffect_InCirclePoison                    = 1,
    CameraEffect_Max                               = 500,
    Max                                            = 5000

};


// Enum  /Script/AClient.EPropUseTipType
enum class EPropUseTipType : uint8_t
{
    None                                           = 0,
    FesecretDoor                                   = 1,
    SupplyDrop                                     = 2,
    Recoverprop                                    = 3,
    FeatdeTector                                   = 4,
    GravityElevator                                = 5,
    EPropUseTipType_MAX                            = 6

};


// Enum  /Script/AClient.EProvingState
enum class EProvingState : uint8_t
{
    Ready                                          = 0,
    Proving                                        = 1,
    Finished                                       = 2,
    Prohibit                                       = 3,
    EProvingState_MAX                              = 4

};


// Enum  /Script/AClient.EInterctType
enum class EInterctType : uint8_t
{
    None                                           = 0,
    TimeCD                                         = 1,
    AddSpeed                                       = 2,
    DecSpeed                                       = 3,
    RaceAddTime                                    = 4,
    Colorful                                       = 5,
    EInterctType_MAX                               = 6

};


// Enum  /Script/AClient.ERespawnCharacterState
enum class ERespawnCharacterState : uint8_t
{
    None                                           = 0,
    AttachAircraft                                 = 1,
    ExitHatch                                      = 2,
    ERespawnCharacterState_MAX                     = 3

};


// Enum  /Script/AClient.ERecallAircraftState
enum class ERecallAircraftState : uint8_t
{
    Init                                           = 0,
    Hover                                          = 1,
    Exit                                           = 2,
    Destroy                                        = 3,
    ERecallAircraftState_MAX                       = 4

};


// Enum  /Script/AClient.ERecoverPropRecoveryReasonType
enum class ERecoverPropRecoveryReasonType : uint8_t
{
    eMedicine                                      = 0,
    eEnergy                                        = 1,
    eRescueByTeammate                              = 2,
    eRevival                                       = 3,
    eFinisher                                      = 4,
    eMax                                           = 5,
    ERecoverPropRecoveryReasonType_MAX             = 6

};


// Enum  /Script/AClient.ERecoverPropRecoverType
enum class ERecoverPropRecoverType : uint8_t
{
    eHealth                                        = 0,
    eShield                                        = 1,
    eSignal                                        = 2,
    ERecoverPropRecoverType_MAX                    = 3

};


// Enum  /Script/AClient.ERecoverPropBuffType
enum class ERecoverPropBuffType : uint8_t
{
    eDirectly                                      = 0,
    eExtraPercent                                  = 1,
    ERecoverPropBuffType_MAX                       = 2

};


// Enum  /Script/AClient.ERecoverPropStage
enum class ERecoverPropStage : uint8_t
{
    eNone                                          = 0,
    eUsing                                         = 1,
    eWaitServer                                    = 2,
    ERecoverPropStage_MAX                          = 3

};


// Enum  /Script/AClient.ERecoverPropExecuteEnd
enum class ERecoverPropExecuteEnd : uint8_t
{
    eAll                                           = 0,
    eClient                                        = 1,
    eServer                                        = 2,
    eAutonomous                                    = 3,
    eSimulated                                     = 4,
    eAutonomousAndServer                           = 5,
    ERecoverPropExecuteEnd_MAX                     = 6

};


// Enum  /Script/AClient.ERecoverProgress
enum class ERecoverProgress : uint8_t
{
    eNone                                          = 0,
    ePartial                                       = 1,
    eFull                                          = 2,
    ERecoverProgress_MAX                           = 3

};


// Enum  /Script/AClient.ERecoverPropPhaseType
enum class ERecoverPropPhaseType : uint8_t
{
    eNone                                          = 0,
    eNormal                                        = 1,
    eCancel                                        = 2,
    ERecoverPropPhaseType_MAX                      = 3

};


// Enum  /Script/AClient.ERecoverPropUseType
enum class ERecoverPropUseType : uint8_t
{
    eUsingNew                                      = 0,
    eUsingEnd                                      = 1,
    eCancel                                        = 2,
    eStartTimeAlignError                           = 3,
    eEndTimeAlignError                             = 4,
    eStartFailed                                   = 5,
    eInterrupt                                     = 6,
    eServerStartNew                                = 7,
    ERecoverPropUseType_MAX                        = 8

};


// Enum  /Script/AClient.ERecoverPropErrorCode
enum class ERecoverPropErrorCode : uint8_t
{
    eOK                                            = 0,
    eFullHealth                                    = 1,
    eUnequiped                                     = 2,
    eFullArmor                                     = 3,
    eHealthAndArmorFull                            = 4,
    eUltimateSkillReady                            = 5,
    eRecoverInUsing                                = 6,
    eInDeathProjectState                           = 7,
    eTotemSpaceLimited                             = 8,
    eInterrupt                                     = 9,
    eTimeAlignError                                = 10,
    eEndTimeAlignError                             = 11,
    eCommonErrorTip1                               = 12,
    eCommonErrorTip2                               = 13,
    eCommonErrorTip3                               = 14,
    eCommonErrorTip4                               = 15,
    eCommonErrorTip5                               = 16,
    eCommonErrorTip6                               = 17,
    eCommonErrorTip7                               = 18,
    eCommonErrorTip8                               = 19,
    eError                                         = 20,
    ERecoverPropErrorCode_MAX                      = 21

};


// Enum  /Script/AClient.EResCachePoolType
enum class EResCachePoolType : uint8_t
{
    Normal                                         = 0,
    UIBP                                           = 1,
    Weapon                                         = 2,
    Skill                                          = 3,
    EResCachePoolType_MAX                          = 4

};


// Enum  /Script/AClient.EAsyncLoadReason
enum class EAsyncLoadReason : uint8_t
{
    HandleIsInvalid                                = 0,
    AssetsIsInvalid                                = 1,
    WasCanceled                                    = 2,
    WasReleased                                    = 3,
    WasFinished                                    = 4,
    UserCanceled                                   = 5,
    EAsyncLoadReason_MAX                           = 6

};


// Enum  /Script/AClient.EExtractState
enum class EExtractState : uint8_t
{
    NoExtract                                      = 0,
    Extracting                                     = 1,
    Extracted                                      = 2,
    EExtractState_MAX                              = 3

};


// Enum  /Script/AClient.EBannerSpawnMethod
enum class EBannerSpawnMethod : uint8_t
{
    DoNotSpawn                                     = 0,
    SpawnStatic                                    = 1,
    SpawnDynamic                                   = 2,
    EBannerSpawnMethod_MAX                         = 3

};


// Enum  /Script/AClient.EQueryAINumType
enum class EQueryAINumType : uint8_t
{
    CanActiveScriptAICount                         = 1,
    ActiveAICount                                  = 2,
    TotalRemainAICount                             = 3,
    EQueryAINumType_MAX                            = 4

};


// Enum  /Script/AClient.EWeaponHitFlowType
enum class EWeaponHitFlowType : uint8_t
{
    WHFT_None                                      = 0,
    WHFT_Shoot                                     = 1,
    WHFT_ShootBullet                               = 2,
    WHFT_ShootCost                                 = 3,
    WHFT_Hit                                       = 4,
    WHFT_HitHead                                   = 5,
    WHFT_MAX                                       = 6

};


// Enum  /Script/AClient.ESelectLegendMode
enum class ESelectLegendMode : uint8_t
{
    Sequence                                       = 0,
    Parallel                                       = 1,
    ESelectLegendMode_MAX                          = 2

};


// Enum  /Script/AClient.ESelectCatagory
enum class ESelectCatagory : uint8_t
{
    None                                           = 0,
    SelectLegend                                   = 1,
    Skin                                           = 2,
    Show                                           = 3,
    ESelectCatagory_MAX                            = 4

};


// Enum  /Script/AClient.ESkillOperationMode
enum class ESkillOperationMode : uint8_t
{
    StandardMode                                   = 0,
    SimpleModel                                    = 1,
    Mode_Max                                       = 2,
    ESkillOperationMode_MAX                        = 3

};


// Enum  /Script/AClient.ESettingSensitivityLevel
enum class ESettingSensitivityLevel : uint8_t
{
    Low                                            = 1,
    Middle                                         = 2,
    Hight                                          = 3,
    Custom                                         = 4,
    ESettingSensitivityLevel_MAX                   = 5

};


// Enum  /Script/AClient.ESettingGroup
enum class ESettingGroup : uint8_t
{
    Basic                                          = 0,
    Fuc                                            = 1,
    Sensitivity                                    = 2,
    Control                                        = 3,
    Scope                                          = 4,
    PickUp                                         = 5,
    DrawQuality                                    = 6,
    Languange                                      = 7,
    Others                                         = 8,
    Privacy                                        = 9,
    Sound                                          = 10,
    ESettingGroup_MAX                              = 11

};


// Enum  /Script/AClient.GlobalSensitivityMode
enum class GlobalSensitivityMode : uint8_t
{
    Low                                            = 1,
    Mid                                            = 2,
    High                                           = 3,
    Custom                                         = 4,
    GlobalSensitivityMode_MAX                      = 5

};


// Enum  /Script/AClient.EJoystickIsInside
enum class EJoystickIsInside : uint8_t
{
    EJII_LeftAndVisualSize                         = 0,
    EJII_VisualSize                                = 1,
    EJII_DynamicSize                               = 2,
    EJII_DynamicPosition                           = 3,
    EJII_MAX                                       = 4

};


// Enum  /Script/AClient.EMForceFieldFalloff
enum class EMForceFieldFalloff : uint8_t
{
    Constant                                       = 0,
    Liner                                          = 1,
    Curve                                          = 2,
    Max                                            = 3

};


// Enum  /Script/AClient.EMVectorComp
enum class EMVectorComp : uint8_t
{
    X                                              = 0,
    Y                                              = 1,
    Z                                              = 2,
    EMVectorComp_MAX                               = 3

};


// Enum  /Script/AClient.EMShapeTriggerStatus
enum class EMShapeTriggerStatus : uint8_t
{
    None                                           = 0,
    Enter                                          = 1,
    In                                             = 2,
    Exit                                           = 3,
    EMShapeTriggerStatus_MAX                       = 4

};


// Enum  /Script/AClient.EMShapeTriggerType
enum class EMShapeTriggerType : uint8_t
{
    None                                           = 0,
    GoToParachute                                  = 1,
    Force                                          = 2,
    EMShapeTriggerType_MAX                         = 3

};


// Enum  /Script/AClient.ECommonBaseAnimDataAssetIndex
enum class ECommonBaseAnimDataAssetIndex : uint8_t
{
    NoWeaponCharacter                              = 0,
    WeaponCharacter                                = 1,
    ECommonBaseAnimDataAssetIndex_MAX              = 2

};


// Enum  /Script/AClient.EFireBtnDataId
enum class EFireBtnDataId : uint32_t
{
    Fire                                           = 10005,
    PropsWeapon                                    = 10006,
    EFireBtnDataId_MAX                             = 10007

};


// Enum  /Script/AClient.EStoredBtnState
enum class EStoredBtnState : uint8_t
{
    None                                           = 0,
    ShootWeapon                                    = 1,
    Projectile                                     = 2,
    EStoredBtnState_MAX                            = 3

};


// Enum  /Script/AClient.EFireBtnType
enum class EFireBtnType : uint8_t
{
    Left                                           = 0,
    Waist                                          = 1,
    Right                                          = 2,
    Default                                        = 3,
    EFireBtnType_MAX                               = 4

};


// Enum  /Script/AClient.EBombStatus
enum class EBombStatus : uint8_t
{
    None                                           = 0,
    Timing                                         = 1,
    Defusing                                       = 2,
    Defused                                        = 3,
    Blasted                                        = 4,
    Idle                                           = 5,
    Planting                                       = 6,
    EBombStatus_MAX                                = 7

};


// Enum  /Script/AClient.EMsgTipType
enum class EMsgTipType : uint8_t
{
    None                                           = 0,
    Normal                                         = 1,
    ShieldExp                                      = 2,
    EMsgTipType_MAX                                = 3

};


// Enum  /Script/AClient.ECountDownTipItemBorderType
enum class ECountDownTipItemBorderType : uint8_t
{
    Default                                        = 0,
    BorderType2                                    = 1,
    BorderType3                                    = 2,
    ECountDownTipItemBorderType_MAX                = 3

};


// Enum  /Script/AClient.ESkillUIStatus
enum class ESkillUIStatus : uint8_t
{
    ESKILL_UI_CD                                   = 0,
    ESKILL_UI_READY                                = 1,
    ESKILL_UI_ACTIVE                               = 2,
    ESKILL_UI_DURATION                             = 3,
    ESKILL_UI_DISABLED                             = 4,
    ESKILL_UI_SILENCED                             = 5,
    ESKILL_UI_BOXINGRING                           = 6,
    ESKILL_UI_READY                                = 7,
    ESKILL_UI_MAX                                  = 8

};


// Enum  /Script/AClient.EAPReplicationSettingType
enum class EAPReplicationSettingType : uint8_t
{
    ERST_UpdateFrequency                           = 0,
    ERST_CullDistance                              = 1,
    ERST_MAX                                       = 2

};


// Enum  /Script/AClient.ESkillCmdType
enum class ESkillCmdType : uint8_t
{
    ECmd_None                                      = 0,
    ECmd_OnDisconnected                            = 1,
    ECmd_OnRecoverConnect                          = 2,
    ECmd_TriggerEvent                              = 3,
    ECmd_StopSkillWithID                           = 4,
    ECmd_StopSkillSafely                           = 5,
    ECmd_StopSkillPhaseAttack                      = 6,
    ECmd_TriggerCurSkillString                     = 7,
    ECmd_TriggerCurSkillEvent                      = 8,
    ECmd_JumpToPhase                               = 9,
    ECmd_SetPreLocInfo                             = 10,
    ECmd_MAX                                       = 11

};


// Enum  /Script/AClient.EBuildingSkinAssetType
enum class EBuildingSkinAssetType : uint8_t
{
    None                                           = 0,
    StaticMesh                                     = 1,
    SkeletalMesh                                   = 2,
    BPActor                                        = 3,
    EBuildingSkinAssetType_MAX                     = 4

};


// Enum  /Script/AClient.EBuildingSkinEffectType
enum class EBuildingSkinEffectType : uint8_t
{
    Particle                                       = 0,
    Animation                                      = 1,
    MeshOrMat                                      = 2,
    MatParams                                      = 3,
    Audio                                          = 4,
    Any                                            = 5,
    EBuildingSkinEffectType_MAX                    = 6

};


// Enum  /Script/AClient.ESkillSkinEffectType
enum class ESkillSkinEffectType : uint8_t
{
    Particle                                       = 0,
    Animation                                      = 1,
    MeshOrMat                                      = 2,
    MatParams                                      = 3,
    Audio                                          = 4,
    CameraEffect                                   = 5,
    Color                                          = 6,
    Curve                                          = 7,
    Any                                            = 8,
    ESkillSkinEffectType_MAX                       = 9

};


// Enum  /Script/AClient.ETestCaseStatus
enum class ETestCaseStatus : uint8_t
{
    EStatus_None                                   = 0,
    EStatus_Doing                                  = 1,
    EStatus_Failed                                 = 2,
    EStatus_MAX                                    = 3

};


// Enum  /Script/AClient.ETestCaseResult
enum class ETestCaseResult : uint8_t
{
    EResult_Wait                                   = 0,
    EResult_Succeed                                = 1,
    EResult_Failed                                 = 2,
    EResult_MAX                                    = 3

};


// Enum  /Script/AClient.ESlapFacePageType
enum class ESlapFacePageType : uint8_t
{
    eSingle                                        = 0,
    eDouble                                        = 1,
    eTriple                                        = 2,
    ESlapFacePageType_MAX                          = 3

};


// Enum  /Script/AClient.EBreathState
enum class EBreathState : uint8_t
{
    None                                           = 0,
    Charge                                         = 1,
    ContinuousAttack                               = 2,
    End                                            = 3,
    EBreathState_MAX                               = 4

};


// Enum  /Script/AClient.EMissileState
enum class EMissileState : uint8_t
{
    None                                           = 0,
    Normal                                         = 1,
    Deploying                                      = 2,
    EMissileState_MAX                              = 3

};


// Enum  /Script/AClient.EEarthquakeState
enum class EEarthquakeState : uint8_t
{
    None                                           = 0,
    Charge                                         = 1,
    ContinuousAttack                               = 2,
    End                                            = 3,
    EEarthquakeState_MAX                           = 4

};


// Enum  /Script/AClient.ETracingPhase
enum class ETracingPhase : uint8_t
{
    PreTracking                                    = 0,
    Float                                          = 1,
    TrackingTransition                             = 2,
    FullTracking                                   = 3,
    ETracingPhase_MAX                              = 4

};


// Enum  /Script/AClient.ESporeType
enum class ESporeType : uint8_t
{
    Ice                                            = 0,
    Poison                                         = 1,
    Fire                                           = 2,
    ESporeType_MAX                                 = 3

};


// Enum  /Script/AClient.EStageSwitchState
enum class EStageSwitchState : uint8_t
{
    On                                             = 0,
    Off                                            = 1,
    Error                                          = 2,
    EStageSwitchState_MAX                          = 3

};


// Enum  /Script/AClient.EStatusHeadMapFlags
enum class EStatusHeadMapFlags : uint8_t
{
    Aid                                            = 0,
    Retrieve                                       = 1,
    Finisher                                       = 2,
    EStatusHeadMapFlags_MAX                        = 3

};


// Enum  /Script/AClient.EStopBinState
enum class EStopBinState : uint8_t
{
    Sleep                                          = 0,
    Active                                         = 1,
    Rising                                         = 2,
    Decilining                                     = 3,
    EStopBinState_MAX                              = 4

};


// Enum  /Script/AClient.ESupensionStatus
enum class ESupensionStatus : uint8_t
{
    Stop                                           = 0,
    Rising                                         = 1,
    Stable                                         = 2,
    Stalled                                        = 3,
    ESupensionStatus_MAX                           = 4

};


// Enum  /Script/AClient.ESuppLydrop_OpenReason
enum class ESuppLydrop_OpenReason : uint8_t
{
    Normal                                         = 0,
    PickUpTrigger                                  = 1,
    ESuppLydrop_MAX                                = 2

};


// Enum  /Script/AClient.ESuppLydrop_DoorType
enum class ESuppLydrop_DoorType : uint8_t
{
    TableItemRandom                                = 0,
    Hero03_hBetterShield                           = 1,
    Hero03_hBetterEquip                            = 2,
    Hero03_hBetterGun                              = 3,
    Hero03_hPreferenceBetterShield                 = 4,
    Hero03_hPreferenceBetterEquip                  = 5,
    Hero03_hPreferenceBetterGun                    = 6,
    Hero03_hPreferenceBetterShieldOrGun            = 7,
    Hero03_hPreferenceBetterEquiporMoveableEvocator = 8,
    Invalid                                        = 9,
    ESuppLydrop_MAX                                = 10

};


// Enum  /Script/AClient.ESuppLydrop_LootType
enum class ESuppLydrop_LootType : uint8_t
{
    None                                           = 0,
    ItemTableRandom                                = 1,
    ItemTableRandomAE                              = 2,
    Hero03_hTeamBetter                             = 3,
    DropList                                       = 4,
    EachDoorCustom                                 = 5,
    ExternalSet                                    = 6,
    Max                                            = 7

};


// Enum  /Script/AClient.ETokenState
enum class ETokenState : uint8_t
{
    ReadyToUse                                     = 0,
    NowUsing                                       = 1,
    OverUsed                                       = 2,
    ETokenState_MAX                                = 3

};


// Enum  /Script/AClient.ETeamConditionType
enum class ETeamConditionType : uint8_t
{
    TeamNum                                        = 1,
    PlayerNum                                      = 2,
    KillNum                                        = 3,
    AssistNum                                      = 4,
    DamageNum                                      = 5,
    ComBackTips                                    = 6,
    MPPlayerScore                                  = 7,
    EvacuateCurrency                               = 8,
    ETeamConditionType_MAX                         = 9

};


// Enum  /Script/AClient.EPawnStateChangeWay
enum class EPawnStateChangeWay : uint8_t
{
    Logic                                          = 0,
    Interrupted                                    = 1,
    Sync                                           = 2,
    TimeOut                                        = 3,
    BlockExit                                      = 4,
    RollBack                                       = 5,
    EPawnStateChangeWay_MAX                        = 6

};


// Enum  /Script/AClient.EGNGameMoveMaskFilter
enum class EGNGameMoveMaskFilter : uint8_t
{
    None                                           = 0,
    AI                                             = 1,
    EGNGameMoveMaskFilter_MAX                      = 2

};


// Enum  /Script/AClient.EPawnStateAllowCheckType
enum class EPawnStateAllowCheckType : uint8_t
{
    BackpackDropItem                               = 0,
    RobGoldATMStoreCurrency                        = 1,
    RobGoldOpenRedEnvelope                         = 2,
    RobGoldATMStealCurrency                        = 3,
    Max                                            = 4

};


// Enum  /Script/AClient.EOverheadReportType
enum class EOverheadReportType : uint8_t
{
    None                                           = 0,
    LaunchGame                                     = 1,
    Login                                          = 2,
    Lobby                                          = 3,
    BattleLoading                                  = 4,
    InGame                                         = 5,
    RoleSelect                                     = 6,
    EnterFighting                                  = 7,
    Plane                                          = 8,
    Parachute                                      = 9,
    EndParachute                                   = 10,
    FinalPoisonCircle                              = 11,
    EnterObserve                                   = 12,
    GameOver                                       = 13,
    CircleBegin                                    = 14,
    EnterBirthIsland                               = 15,
    ReBirth                                        = 16,
    GameFlowMax                                    = 17,
    MachineScope                                   = 18,
    MagnifierOne                                   = 19,
    MagnifierTwo                                   = 20,
    MagnifierThree                                 = 21,
    MagnifierFour                                  = 22,
    MagnifierSix                                   = 23,
    MagnifierEight                                 = 24,
    MagnifierTen                                   = 25,
    MinorSkill                                     = 26,
    MajorSkill                                     = 27,
    PassiveSkill                                   = 28,
    Slide                                          = 29,
    Climb                                          = 30,
    Zipline                                        = 31,
    OpenBox                                        = 32,
    PickUp                                         = 33,
    Fire                                           = 34,
    HeavyFire                                      = 35,
    KnockedDown                                    = 36,
    Drive                                          = 37,
    OpenBigMap                                     = 38,
    Backpack                                       = 39,
    OpenSettingUI                                  = 40,
    EOverheadReportType_MAX                        = 41

};


// Enum  /Script/AClient.EScreenState
enum class EScreenState : uint8_t
{
    KillKing                                       = 1,
    Defenders                                      = 2,
    FireRangeRankEmpty                             = 3,
    FireRangeRankThree                             = 4,
    FireRangeRankList                              = 5,
    EScreenState_MAX                               = 6

};


// Enum  /Script/AClient.ETimerType
enum class ETimerType : uint8_t
{
    Once                                           = 0,
    Loop                                           = 1,
    ETimerType_MAX                                 = 2

};


// Enum  /Script/AClient.ETimeTrackType
enum class ETimeTrackType : uint8_t
{
    UI                                             = 0,
    Logic                                          = 1,
    Battle                                         = 2,
    UIAnim                                         = 3,
    Effect                                         = 4,
    UeOrigin                                       = 5,
    TickOnWorldPostActor                           = 6,
    FrameCount                                     = 7,
    Max                                            = 8

};


// Enum  /Script/AClient.ETrackerOperateType
enum class ETrackerOperateType : uint8_t
{
    Add                                            = 0,
    Set                                            = 1,
    Delete                                         = 2,
    ETrackerOperateType_MAX                        = 3

};


// Enum  /Script/AClient.ETrackTriggerType
enum class ETrackTriggerType : uint8_t
{
    Enter                                          = 1,
    Exit                                           = 2,
    Execute                                        = 3,
    Custom                                         = 4,
    ETrackTriggerType_MAX                          = 5

};


// Enum  /Script/AClient.ETrainingFieldAnimState
enum class ETrainingFieldAnimState : uint8_t
{
    None                                           = 0,
    Opening                                        = 1,
    OpenIdle                                       = 2,
    Closing                                        = 3,
    CloseIdle                                      = 4,
    ETrainingFieldAnimState_MAX                    = 5

};


// Enum  /Script/AClient.ETrainStateType
enum class ETrainStateType : uint8_t
{
    None                                           = 0,
    Departure                                      = 1,
    Running                                        = 2,
    Brake                                          = 3,
    Parking                                        = 4,
    ETrainStateType_MAX                            = 5

};


// Enum  /Script/AClient.ETutorialTLogType
enum class ETutorialTLogType : uint8_t
{
    None                                           = 0,
    OP_Tutorial                                    = 1,
    ETutorialTLogType_MAX                          = 2

};


// Enum  /Script/AClient.ECharacterAnimTypeAsynLoaded
enum class ECharacterAnimTypeAsynLoaded : uint8_t
{
    ECharAnimAsyn_Swim_Up                          = 0,
    ECharAnimAsyn_Swim_Down                        = 1,
    ECharAnimAsyn_Max                              = 2

};


// Enum  /Script/AClient.ECharacterViewType
enum class ECharacterViewType : uint8_t
{
    ECharacterView_TPPandFPP                       = 0,
    ECharacterView_TPP                             = 1,
    ECharacterView_FPP                             = 2,
    ECharacterView_Max                             = 3

};


// Enum  /Script/AClient.ESALCNavigate
enum class ESALCNavigate : uint8_t
{
    ESALCNavigate_Forward                          = 0,
    ESALCNavigate_Target                           = 1,
    ESALCNavigate_Caster                           = 2,
    ESALCNavigate_MAX                              = 3

};


// Enum  /Script/AClient.ESALCSpeedBlendMode
enum class ESALCSpeedBlendMode : uint8_t
{
    ESALCSpeedBlend_Override                       = 0,
    ESALCSpeedBlend_Additive                       = 1,
    ESALCSpeedBlend_MAX                            = 2

};


// Enum  /Script/AClient.ERecoveryReasonType
enum class ERecoveryReasonType : uint8_t
{
    ERecoveryReason_Medicine                       = 0,
    ERecoveryReason_Energy                         = 1,
    ERecoveryReason_RescueByTeammate               = 2,
    ERecoveryReason_Revival                        = 3,
    ERecoveryReason_Finisher                       = 4,
    ERecoveryReason_Max                            = 5

};


// Enum  /Script/AClient.ESkillPawnState
enum class ESkillPawnState : uint8_t
{
    ESPS_Slot1                                     = 0,
    ESPS_Slot2                                     = 1,
    ESPS_Slot3                                     = 2,
    ESPS_MAX                                       = 3

};


// Enum  /Script/AClient.ESkillMontageType
enum class ESkillMontageType : uint8_t
{
    SMT_None                                       = 0,
    SMT_Stand                                      = 1,
    SMT_Crouch                                     = 2,
    SMT_Slide                                      = 3,
    SMT_Sprint                                     = 4,
    SMT_Jump                                       = 5,
    SMT_Dying                                      = 6,
    SMT_Max                                        = 7

};


// Enum  /Script/AClient.ESkillPreloadPlatform
enum class ESkillPreloadPlatform : uint8_t
{
    Simulated                                      = 2,
    Autonomous                                     = 4,
    Server                                         = 8,
    Client                                         = 6,
    All                                            = 14,
    ESkillPreloadPlatform_MAX                      = 15

};


// Enum  /Script/AClient.EVelocityChangeType
enum class EVelocityChangeType : uint8_t
{
    ESpeed_Up                                      = 0,
    ESpeed_Down                                    = 1,
    ESpeed_Both                                    = 2,
    ESpeed_MAX                                     = 3

};


// Enum  /Script/AClient.ESkillConditionCheckType
enum class ESkillConditionCheckType : uint8_t
{
    ECheck_Once                                    = 0,
    ECheck_Continuous                              = 1,
    ECheck_MAX                                     = 2

};


// Enum  /Script/AClient.ERecoveryType
enum class ERecoveryType : uint8_t
{
    ERecovery_AddDirectly                          = 0,
    ERecovery_AddTo                                = 1,
    ERecovery_MAX                                  = 2

};


// Enum  /Script/AClient.EValueType
enum class EValueType : uint8_t
{
    EValueType_Percentage                          = 0,
    EValueType_Absolute                            = 1,
    EValueType_MAX                                 = 2

};


// Enum  /Script/AClient.EOperatorType
enum class EOperatorType : uint8_t
{
    EOperator_Equal                                = 0,
    EOperator_Greater                              = 1,
    EOperator_Less                                 = 2,
    EOperator_GreaterEqual                         = 3,
    EOperator_LessEqual                            = 4,
    EOperator_MAX                                  = 5

};


// Enum  /Script/AClient.EUTSkillEntry
enum class EUTSkillEntry : uint8_t
{
    SkillEntry_None                                = 0,
    SkillEntry_Grenade_Down                        = 1,
    SkillEntry_Grenade_Up                          = 2,
    SkillEntry_Flash_Down                          = 3,
    SkillEntry_Flash_Up                            = 4,
    SkillEntry_Smoke_Down                          = 5,
    SkillEntry_Smoke_Up                            = 6,
    SkillEntry_Molotov_Down                        = 7,
    SkillEntry_Molotov_Up                          = 8,
    SkillEntry_Melee_Fist_Down                     = 9,
    SkillEntry_Melee_Fist_Up                       = 10,
    SkillEntry_Melee_Weapon_1_Down                 = 11,
    SkillEntry_Melee_Weapon_1_Up                   = 12,
    SkillEntry_Melee_Weapon_2_Down                 = 13,
    SkillEntry_Melee_Weapon_2_Up                   = 14,
    SkillEntry_Melee_Weapon_3_Down                 = 15,
    SkillEntry_Melee_Weapon_3_Up                   = 16,
    SkillEntry_Melee_Weapon_4_Down                 = 17,
    SkillEntry_Melee_Weapon_4_Up                   = 18,
    SkillEntry_Bandage_Down                        = 19,
    SkillEntry_EnergyDrink_Down                    = 20,
    SkillEntry_Painkiller_Down                     = 21,
    SkillEntry_AdrenalineMd110_m_Down              = 22,
    SkillEntry_FirstAidKit_Down                    = 23,
    SkillEntry_Md111__Down                         = 24,
    SkillEntry_GasCan_Down                         = 25,
    SkillEntry_GrenadeApple_Down                   = 26,
    SkillEntry_GrenadeApple_Up                     = 27,
    SkillEntry_GrenadeDance_Down                   = 28,
    SkillEntry_GrenadeDance_Up                     = 29,
    SkillEntry_GrenadeRnfc_Down                    = 30,
    SkillEntry_GrenadeRnfc_Up                      = 31,
    SkillEntry_Melee_Weapon_5_Down                 = 32,
    SkillEntry_Melee_Weapon_5_Up                   = 33,
    SkillEntry_Melee_Weapon_6_Down                 = 34,
    SkillEntry_Melee_Weapon_6_Up                   = 35,
    SkillEntry_Melee_Weapon_7_Down                 = 36,
    SkillEntry_Melee_Weapon_7_Up                   = 37,
    SkillEntry_Melee_Weapon_8_Down                 = 38,
    SkillEntry_Melee_Weapon_8_Up                   = 39,
    SkillEntry_Melee_Weapon_9_Down                 = 40,
    SkillEntry_Melee_Weapon_9_Up                   = 41,
    SkillEntry_Melee_Weapon_10_Down                = 42,
    SkillEntry_Melee_Weapon_10_Up                  = 43,
    SkillEntry_Bandage_Down_CG                     = 44,
    SkillEntry_EnergyDrink_Down_CG                 = 45,
    SkillEntry_Painkiller_Down_CG                  = 46,
    SkillEntry_AdrenalineMd110_m_Down_CG           = 47,
    SkillEntry_FirstAidKit_Down_CG                 = 48,
    SkillEntry_Md111__Down_CG                      = 49,
    SkillEntry_GasCan_Down_CG                      = 50,
    SkillEntry_Grenade_Down_CG                     = 51,
    SkillEntry_Grenade_Up_CG                       = 52,
    SkillEntry_Flash_Down_CG                       = 53,
    SkillEntry_Flash_Up_CG                         = 54,
    SkillEntry_Smoke_Down_CG                       = 55,
    SkillEntry_Smoke_Up_CG                         = 56,
    SkillEntry_Molotov_Down_CG                     = 57,
    SkillEntry_Molotov_Up_CG                       = 58,
    SkillEntry_ShieldStun_Down                     = 59,
    SkillEntry_ShieldStun_Up                       = 60,
    SkillEntry_Shield_Melee_Down                   = 61,
    SkillEntry_Shield_Melee_Up                     = 62,
    SkillEntry_SmellyEgg_Down_CG                   = 63,
    SkillEntry_SmellyEgg_Up_CG                     = 64,
    SkillEntry_Fireworks_Down_CG                   = 65,
    SkillEntry_Fireworks_Up_CG                     = 66,
    SkillEntry_FirstAidKitFast_Down_CG             = 67,
    SkillEntry_FirstAidKitFast_Up_CG               = 68,
    SkillEntry_ToyApple_Down_CG                    = 69,
    SkillEntry_ToyApple_Up_CG                      = 70,
    SkillEntry_SingerDoll_Down_CG                  = 71,
    SkillEntry_SingerDoll_Up_CG                    = 72,
    SkillEntry_Snowball_Down                       = 73,
    SkillEntry_Snowball_Up                         = 74,
    SkillEntry_Pumpkin_Down                        = 75,
    SkillEntry_Pumpkin_Up                          = 76,
    SkillEntry_ReserveGrenade1_Down                = 77,
    SkillEntry_ReserveGrenade1_Up                  = 78,
    SkillEntry_ReserveGrenade2_Down                = 79,
    SkillEntry_ReserveGrenade2_Up                  = 80,
    SkillEntry_ReserveGrenade3_Down                = 81,
    SkillEntry_ReserveGrenade3_Up                  = 82,
    SkillEntry_ReserveGrenade4_Down                = 83,
    SkillEntry_ReserveGrenade4_Up                  = 84,
    SkillEntry_RapidAid_Down                       = 85,
    SkillEntry_Max                                 = 86

};


// Enum  /Script/AClient.ESkillUIBtnStatus
enum class ESkillUIBtnStatus : uint8_t
{
    All                                            = 0,
    CD                                             = 1,
    ESkillUIBtnStatus_MAX                          = 2

};


// Enum  /Script/AClient.ESkillOperationType
enum class ESkillOperationType : uint8_t
{
    Click                                          = 0,
    Drag                                           = 1,
    Switch                                         = 2,
    SimpleSwitch                                   = 3,
    ESkillOperationType_MAX                        = 4

};


// Enum  /Script/AClient.ESkillUISlot
enum class ESkillUISlot : uint8_t
{
    None                                           = 0,
    SkillMeleeSlot                                 = 1,
    SkillTacticalSlot                              = 2,
    SkillUltimateSlot                              = 3,
    SkillCancelSlot                                = 4,
    SkillUndoSlot                                  = 5,
    ESkillUISlot_MAX                               = 6

};


// Enum  /Script/AClient.ETableLoadPhase
enum class ETableLoadPhase : uint8_t
{
    eSelfControl                                   = 0,
    eLaunch                                        = 1,
    eLobby                                         = 2,
    eEnterBattle                                   = 3,
    eDSBattle                                      = 4,
    ETableLoadPhase_MAX                            = 5

};


// Enum  /Script/AClient.EColosseumFeloOtballSpawnStage
enum class EColosseumFeloOtballSpawnStage : uint8_t
{
    Disable                                        = 0,
    Default                                        = 1,
    Settlement                                     = 2,
    EColosseumFeloOtballSpawnStage_MAX             = 3

};


// Enum  /Script/AClient.EUpdatableCoreDataGroupType
enum class EUpdatableCoreDataGroupType : uint8_t
{
    ENone                                          = 0,
    BlueprintCDOData                               = 1,
    BlueprintComponentData                         = 2,
    EUpdatableCoreDataGroupType_MAX                = 3

};


// Enum  /Script/AClient.EExpNotDamageFromType
enum class EExpNotDamageFromType : uint8_t
{
    None                                           = 0,
    MaterialStation                                = 1,
    OpenBinBox                                     = 2,
    Round                                          = 3,
    EExpNotDamageFromType_MAX                      = 4

};


// Enum  /Script/AClient.EEq200_eQ200_ExpFromType
enum class EEq200_eQ200_ExpFromType : uint8_t
{
    TrueRole                                       = 0,
    AI                                             = 1,
    NPC                                            = 2,
    Perk                                           = 3,
    EEq200_eQ200_MAX                               = 4

};


// Enum  /Script/AClient.EUpGradeableArmorExpResult
enum class EUpGradeableArmorExpResult : uint8_t
{
    Create                                         = 0,
    NoUpGrade                                      = 1,
    UpGrade                                        = 2,
    EUpGradeableArmorExpResult_MAX                 = 3

};


// Enum  /Script/AClient.EVehiclePartType
enum class EVehiclePartType : uint8_t
{
    None                                           = 0,
    Head                                           = 1,
    Limbs                                          = 2,
    MainBody                                       = 3,
    Seats                                          = 4,
    SeatBase                                       = 5,
    SeatItem                                       = 6,
    DriveItem                                      = 7,
    JetItem                                        = 8,
    JetParticle                                    = 9,
    RoundParticle                                  = 10,
    Sticker                                        = 11,
    Decoration1                                    = 21,
    Decoration2                                    = 22,
    Decoration3                                    = 23,
    Decoration4                                    = 24,
    Decoration5                                    = 25,
    EVehiclePartType_MAX                           = 26

};


// Enum  /Script/AClient.EVehicleRecordType
enum class EVehicleRecordType : uint8_t
{
    RaceTotalTime                                  = 0,
    AddSpeed                                       = 1,
    PropAddSpeed                                   = 2,
    PropDecSpeed                                   = 3,
    PropAddTime                                    = 4,
    PropDecTimeCD                                  = 5,
    Max                                            = 6

};


// Enum  /Script/AClient.EVehicleSkinEffectType
enum class EVehicleSkinEffectType : uint8_t
{
    Particle                                       = 0,
    Animation                                      = 1,
    Mesh                                           = 2,
    Mat                                            = 3,
    Audio                                          = 4,
    UI                                             = 5,
    Coefficient                                    = 6,
    Any                                            = 7,
    EVehicleSkinEffectType_MAX                     = 8

};


// Enum  /Script/AClient.EVehicleResLoadState
enum class EVehicleResLoadState : uint8_t
{
    UnLoad                                         = 0,
    Loading                                        = 1,
    Loaded                                         = 2,
    EVehicleResLoadState_MAX                       = 3

};


// Enum  /Script/AClient.EVehicleEffectType
enum class EVehicleEffectType : uint8_t
{
    None                                           = 0,
    Idle                                           = 1,
    MovementJet                                    = 2,
    Boost                                          = 3,
    TurnTrail                                      = 4,
    Impact                                         = 5,
    Hit                                            = 6,
    HitDecal                                       = 7,
    Breakdown                                      = 8,
    EVehicleEffectType_MAX                         = 9

};


// Enum  /Script/AClient.EVehicleMoveMode
enum class EVehicleMoveMode : uint8_t
{
    MOVE_OnGround                                  = 0,
    MOVE_InTheAir                                  = 1

};


// Enum  /Script/AClient.EVehicleMotorDirectionType
enum class EVehicleMotorDirectionType : uint8_t
{
    Up                                             = 0,
    Forward                                        = 1,
    Back                                           = 2,
    Left                                           = 3,
    Right                                          = 4,
    EVehicleMotorDirectionType_MAX                 = 5

};


// Enum  /Script/AClient.EVehicleVoiceType
enum class EVehicleVoiceType : uint8_t
{
    None                                           = 0,
    SummonTeammates                                = 1,
    GetOn                                          = 2,
    GetOff                                         = 3,
    Boost                                          = 4,
    EVehicleVoiceType_MAX                          = 5

};


// Enum  /Script/AClient.EVehicleAudioType
enum class EVehicleAudioType : uint8_t
{
    None                                           = 0,
    SummonTeammates                                = 1,
    Speaker                                        = 2,
    EVehicleAudioType_MAX                          = 3

};


// Enum  /Script/AClient.ESeatDetailType
enum class ESeatDetailType : uint8_t
{
    None                                           = 0,
    Driver                                         = 1,
    LeftPassenger                                  = 2,
    RightPassenger                                 = 3,
    BackPassenger                                  = 4,
    ESeatDetailType_MAX                            = 5

};


// Enum  /Script/AClient.ECharacterOnVehicleType
enum class ECharacterOnVehicleType : uint8_t
{
    None                                           = 0,
    Driver                                         = 1,
    Passenger                                      = 2,
    ECharacterOnVehicleType_MAX                    = 3

};


// Enum  /Script/AClient.ECharacterOnVehicleStage
enum class ECharacterOnVehicleStage : uint8_t
{
    None                                           = 0,
    GettingOn                                      = 1,
    OnVehicle                                      = 2,
    GettingOff                                     = 3,
    ChangeSeat                                     = 4,
    Popup                                          = 5,
    Max                                            = 6

};


// Enum  /Script/AClient.EGnyxVehicleAudioType
enum class EGnyxVehicleAudioType : uint8_t
{
    GetOn                                          = 0,
    GetOff                                         = 1,
    SummonTeammate                                 = 2,
    EnterDriver                                    = 3,
    EnterPassenger                                 = 4,
    RandomChat                                     = 5,
    CallTeammate                                   = 6,
    Boost                                          = 7,
    EGnyxVehicleAudioType_MAX                      = 8

};


// Enum  /Script/AClient.EGnyxVehicleType
enum class EGnyxVehicleType : uint8_t
{
    None                                           = 0,
    PhysicSimulationFloatvc                        = 1,
    LogicSimulationFloatvc                         = 2,
    ForceFloatvc                                   = 3,
    Max                                            = 4

};


// Enum  /Script/AClient.ECharacterVehicleState
enum class ECharacterVehicleState : uint8_t
{
    None                                           = 0,
    GetingOn                                       = 1,
    OnVehicle                                      = 2,
    GetingOff                                      = 3,
    ECharacterVehicleState_MAX                     = 4

};


// Enum  /Script/AClient.EViewAssistTriggerType
enum class EViewAssistTriggerType : uint8_t
{
    None                                           = 0,
    TouchScreen                                    = 1,
    AdsTouchScreen                                 = 2,
    GunFire                                        = 3,
    OneTouchAdsAndFire                             = 4,
    Ads                                            = 5,
    Touch                                          = 6,
    EViewAssistTriggerType_MAX                     = 7

};


// Enum  /Script/AClient.EViewAssistType
enum class EViewAssistType : uint8_t
{
    None                                           = 0,
    ProjectileReticle                              = 1,
    ProjectileLandingPoint                         = 2,
    MagnetismSnapping                              = 3,
    CrossHairSnapping                              = 4,
    DoubleCircleAdsSnapping                        = 5,
    QuickSnapping                                  = 6,
    WeaponFire                                     = 7,
    WeaponAim                                      = 8,
    TickSnapping                                   = 9,
    EdgePushing                                    = 10,
    EViewAssistType_MAX                            = 11

};


// Enum  /Script/AClient.ERecordStatus
enum class ERecordStatus : uint8_t
{
    ERECORDSTATUS_UNKOWN                           = 0,
    ERECORDSTATUS_RECORDING                        = 1,
    ERECORDSTATUS_COMPLETED                        = 2,
    ERECORDSTATUS_SUCCEED                          = 3,
    ERECORDSTATUS_FAILURE                          = 4,
    ERECORDSTATUS_EFFICIENT                        = 5,
    ERECORDSTATUS_WAITDESTORY                      = 6,
    ERECORDSTATUS_MAX                              = 7

};


// Enum  /Script/AClient.E3DUILockType
enum class E3DUILockType : uint8_t
{
    None                                           = 0,
    GunADS                                         = 1,
    Jump                                           = 2,
    Land                                           = 3,
    E3DUILockType_MAX                              = 4

};


// Enum  /Script/AClient.EGngameAimChargeStage
enum class EGngameAimChargeStage : uint8_t
{
    Stop                                           = 0,
    WaitUpConditions                               = 1,
    WaitToUp                                       = 2,
    Up                                             = 3,
    Full                                           = 4,
    WaitToDown                                     = 5,
    Down                                           = 6,
    EGngameAimChargeStage_MAX                      = 7

};


// Enum  /Script/AClient.EWeaponOrOwnerCondition
enum class EWeaponOrOwnerCondition : uint8_t
{
    NONE                                           = 0,
    PlayerWithGoldArmor                            = 1,
    EWeaponOrOwnerCondition_MAX                    = 2

};


// Enum  /Script/AClient.EWeaponReloadStage
enum class EWeaponReloadStage : uint8_t
{
    None                                           = 0,
    MagOut                                         = 1,
    MagIn                                          = 2,
    PullBolt                                       = 3,
    FirstOneBulletCharge                           = 4,
    FirstOneBullet                                 = 5,
    CirculateOneBullet                             = 6,
    ReloadEnd                                      = 7,
    RandomOneBullet                                = 8,
    EWeaponReloadStage_MAX                         = 9

};


// Enum  /Script/AClient.EFillBulletWeapon
enum class EFillBulletWeapon : uint8_t
{
    AllWeapon                                      = 0,
    LastWeapon                                     = 1,
    EFillBulletWeapon_MAX                          = 2

};


// Enum  /Script/AClient.ESpringType
enum class ESpringType : uint8_t
{
    None                                           = 0,
    Soft                                           = 1,
    Hard                                           = 2,
    Immediately                                    = 3,
    ESpringType_MAX                                = 4

};


// Enum  /Script/AClient.ERecoilType
enum class ERecoilType : uint8_t
{
    None                                           = 0,
    Soft                                           = 1,
    Hard                                           = 2,
    ERecoilType_MAX                                = 3

};


// Enum  /Script/AClient.ECrossHairSpreadType
enum class ECrossHairSpreadType : uint8_t
{
    ECHST_Offset                                   = 0,
    ECHST_Scale                                    = 1,
    ECHST_Damage                                   = 2,
    ECHST_Rotate                                   = 3,
    ECHST_Kill                                     = 4,
    ECHST_MAX                                      = 5

};


// Enum  /Script/AClient.EWeaponADSShoulderConfig
enum class EWeaponADSShoulderConfig : uint8_t
{
    None                                           = 0,
    Shoulder                                       = 1,
    ADS                                            = 2,
    EWeaponADSShoulderConfig_MAX                   = 3

};


// Enum  /Script/AClient.EAq101EnergyState
enum class EAq101EnergyState : uint8_t
{
    HES_None                                       = 0,
    HES_Up                                         = 1,
    HES_Down                                       = 2,
    HES_MAX                                        = 3

};


// Enum  /Script/AClient.EChargeShootPhase
enum class EChargeShootPhase : uint8_t
{
    None                                           = 0,
    Lens                                           = 1,
    Final                                          = 2,
    EChargeShootPhase_MAX                          = 3

};


// Enum  /Script/AClient.ETempWeaponEntityData
enum class ETempWeaponEntityData : uint8_t
{
    BaseImpactDamage                               = 0,
    BulletFireSpeed                                = 201,
    LaunchGravityScale                             = 202,
    MagMaxNum_Base                                 = 203,
    MagMaxNum_1L                                   = 204,
    MagMaxNum_2L                                   = 205,
    MagMaxNum_3L                                   = 206,
    WeaponHitPartCoff_Head                         = 1,
    WeaponHitPartCoff_Thighs                       = 2,
    Single_ShootInterval                           = 3,
    Single_FireInterval                            = 4,
    Single_LinkInterval                            = 5,
    Single_AutoAimShootWaitTime                    = 6,
    Multi_ShootInterval                            = 7,
    Multi_FireInterval                             = 8,
    Multi_LinkInterval                             = 9,
    Multi_AutoAimShootWaitTime                     = 10,
    Auto_ShootInterval                             = 11,
    Auto_FireInterval                              = 12,
    Auto_LinkInterval                              = 13,
    Auto_AutoAimShootWaitTime                      = 14,
    FirstPickupToIdleTime                          = 15,
    SwitchFromIdleToBackpackTime                   = 16,
    SwitchFromBackpackToIdleTime                   = 17,
    MaxRaiseWeaponTime                             = 18,
    MaxLowerWeaponTime                             = 19,
    AdsStartTime_NoAim                             = 20,
    AdsStartTime_1X                                = 21,
    AdsStartTime_2X                                = 22,
    AdsStartTime_3X                                = 23,
    AdsStartTime_4X                                = 24,
    AdsStartTime_6X                                = 25,
    AdsStartTime_8X                                = 26,
    AdsStartTime_10X                               = 27,
    AdsEndTime_NoAim                               = 28,
    AdsEndTime_1X                                  = 29,
    AdsEndTime_2X                                  = 30,
    AdsEndTime_3X                                  = 31,
    AdsEndTime_4X                                  = 32,
    AdsEndTime_6X                                  = 33,
    AdsEndTime_8X                                  = 34,
    AdsEndTime_10X                                 = 35,
    EnableViewAssist                               = 36,
    EnableViewAssistDebug                          = 37,
    MaxViewAssistDistance                          = 38,
    BaseAccelerateSpeed                            = 39,
    AimingAccelerateFactor                         = 40,
    BaseDecelerateSpeed                            = 41,
    EnableAimSnapping                              = 42,
    EnableAimSnappingDebug                         = 43,
    BaseAimSnappingSpeed_Iron                      = 44,
    BaseAimSnappingSpeed_1X                        = 45,
    BaseAimSnappingSpeed_2X                        = 46,
    BaseAimSnappingSpeed_3X                        = 47,
    BaseAimSnappingSpeed_4X                        = 48,
    BaseAimSnappingSpeed_6X                        = 49,
    BaseAimSnappingSpeed_8X                        = 50,
    BaseAimSnappingSpeed_10X                       = 51,
    MaxAimSnappingDistance                         = 52,
    AimSnappingTime                                = 53,
    EnableFireSnapping                             = 54,
    EnableFireSnappingDebug                        = 55,
    BaseFireSnappingSpeed_Iron                     = 56,
    BaseFireSnappingSpeed_1X                       = 57,
    BaseFireSnappingSpeed_2X                       = 58,
    BaseFireSnappingSpeed_3X                       = 59,
    BaseFireSnappingSpeed_4X                       = 60,
    BaseFireSnappingSpeed_6X                       = 61,
    BaseFireSnappingSpeed_8X                       = 62,
    BaseFireSnappingSpeed_10X                      = 63,
    NoAimFireSnappingSpeed                         = 64,
    MaxFireSnappingDistance                        = 65,
    FireSnappingTime                               = 66,
    HitRecoilFactor                                = 67,
    RecoilFactorX_StandIdle_ADS                    = 68,
    RecoilFactorY_StandIdle_ADS                    = 69,
    RecoilRandomX_StandIdle_ADS                    = 70,
    RecoilRandomY_StandIdle_ADS                    = 71,
    RecoilFactorX_StandIdle_NoADS                  = 72,
    RecoilFactorY_StandIdle_NoADS                  = 73,
    RecoilRandomX_StandIdle_NoADS                  = 74,
    RecoilRandomY_StandIdle_NoADS                  = 75,
    RecoilFactorX_StandMove_ADS                    = 76,
    RecoilFactorY_StandMove_ADS                    = 77,
    RecoilRandomX_StandMove_ADS                    = 78,
    RecoilRandomY_StandMove_ADS                    = 79,
    RecoilFactorX_StandMove_NoADS                  = 80,
    RecoilFactorY_StandMove_NoADS                  = 81,
    RecoilRandomX_StandMove_NoADS                  = 82,
    RecoilRandomY_StandMove_NoADS                  = 83,
    RecoilFactorX_CrouchIdle_ADS                   = 84,
    RecoilFactorY_CrouchIdle_ADS                   = 85,
    RecoilRandomX_CrouchIdle_ADS                   = 86,
    RecoilRandomY_CrouchIdle_ADS                   = 87,
    RecoilFactorX_CrouchIdle_NoADS                 = 88,
    RecoilFactorY_CrouchIdle_NoADS                 = 89,
    RecoilRandomX_CrouchIdle_NoADS                 = 90,
    RecoilRandomY_CrouchIdle_NoADS                 = 91,
    RecoilFactorX_CrouchMove_ADS                   = 92,
    RecoilFactorY_CrouchMove_ADS                   = 93,
    RecoilRandomX_CrouchMove_ADS                   = 94,
    RecoilRandomY_CrouchMove_ADS                   = 95,
    RecoilFactorX_CrouchMove_NoADS                 = 96,
    RecoilFactorY_CrouchMove_NoADS                 = 97,
    RecoilRandomX_CrouchMove_NoADS                 = 98,
    RecoilRandomY_CrouchMove_NoADS                 = 99,
    RecoilFactorX_Jump_ADS                         = 100,
    RecoilFactorY_Jump_ADS                         = 101,
    RecoilRandomX_Jump_ADS                         = 102,
    RecoilRandomY_Jump_ADS                         = 103,
    RecoilFactorX_Jump_NoADS                       = 104,
    RecoilFactorY_Jump_NoADS                       = 105,
    RecoilRandomX_Jump_NoADS                       = 106,
    RecoilRandomY_Jump_NoADS                       = 107,
    RecoilFactorX_Fall_ADS                         = 108,
    RecoilFactorY_Fall_ADS                         = 109,
    RecoilRandomX_Fall_ADS                         = 110,
    RecoilRandomY_Fall_ADS                         = 111,
    RecoilFactorX_Fall_NoADS                       = 112,
    RecoilFactorY_Fall_NoADS                       = 113,
    RecoilRandomX_Fall_NoADS                       = 114,
    RecoilRandomY_Fall_NoADS                       = 115,
    RecoilFactorX_Sliding_ADS                      = 116,
    RecoilFactorY_Sliding_ADS                      = 117,
    RecoilRandomX_Sliding_ADS                      = 118,
    RecoilRandomY_Sliding_ADS                      = 119,
    RecoilFactorX_Sliding_NoADS                    = 120,
    RecoilFactorY_Sliding_NoADS                    = 121,
    RecoilRandomX_Sliding_NoADS                    = 122,
    RecoilRandomY_Sliding_NoADS                    = 123,
    EnableFireViewAssist                           = 124,
    EnableFireViewAssistDebug                      = 125,
    FireDecelerateRadius                           = 126,
    FireAccelerateRadius                           = 127,
    FireMaxDistance                                = 128,
    FireAccelerateFactor                           = 129,
    FireBaseDecelerateSpeed                        = 130,
    FireEdgeDecelerateWidth                        = 131,
    FireDecelerateTime                             = 132,
    EnableEdgePushing                              = 133,
    EnablePitchEdgePushing                         = 134,
    EnableDebugEdgePushing                         = 135,
    EdgePushingRadius                              = 136,
    EdgePushingWidth                               = 137,
    EdgePushingMaxDistance                         = 138,
    EdgePushingMinSpeed                            = 139,
    BaseEdgePushingSpeed                           = 140,
    EdgePushingTime                                = 141,
    EdgePushingCD                                  = 142,
    KeepEdgePushingEvenAttach                      = 143,
    EnableMagnetismSnapping                        = 144,
    MagnetismSnappingTime                          = 145,
    MaxMagnetismSnappingDistance                   = 146,
    EnableMagnetismSnappingDebug                   = 147,
    EnableCrossHairSnapping                        = 148,
    CrossHairSnappingTime                          = 149,
    MaxCrossHairSnappingDistance                   = 150,
    EnableCrossHairSnappingDebug                   = 151,
    EnableDoubleCircleAdsSnapping                  = 152,
    DoubleCircleAdsSnappingTime                    = 153,
    MaxDoubleCircleAdsSnappingDistance             = 154,
    EnableDoubleCircleAdsSnappingDebug             = 155,
    ETempWeaponEntityData_MAX                      = 207

};


// Enum  /Script/AClient.EWeaponFrameAudioEventType
enum class EWeaponFrameAudioEventType : uint8_t
{
    None                                           = 0,
    PostEvent                                      = 1,
    SetRTPC                                        = 2,
    SetSwitch                                      = 3,
    EWeaponFrameAudioEventType_MAX                 = 4

};


// Enum  /Script/AClient.EFireSection
enum class EFireSection : uint8_t
{
    None                                           = 0,
    Start                                          = 1,
    Loop                                           = 2,
    End                                            = 3,
    EFireSection_MAX                               = 4

};


// Enum  /Script/AClient.EAutoCrossHiarBehavior
enum class EAutoCrossHiarBehavior : uint8_t
{
    None                                           = 0,
    Show                                           = 1,
    Waiting                                        = 2,
    Shooting                                       = 3,
    Tips                                           = 4,
    EAutoCrossHiarBehavior_MAX                     = 5

};


// Enum  /Script/AClient.EWeaponAutoShootState
enum class EWeaponAutoShootState : uint8_t
{
    Check                                          = 0,
    WaitBegin                                      = 1,
    Shooting                                       = 2,
    WaitEnd                                        = 3,
    End                                            = 4,
    EWeaponAutoShootState_MAX                      = 5

};


// Enum  /Script/AClient.EBulletImpactDir
enum class EBulletImpactDir : uint8_t
{
    ImpactNormal                                   = 1,
    ImpactShootDir                                 = 2,
    EBulletImpactDir_MAX                           = 3

};


// Enum  /Script/AClient.EWeaponReloadMethod
enum class EWeaponReloadMethod : uint8_t
{
    ALL                                            = 0,
    Tactical                                       = 1,
    EWeaponReloadMethod_MAX                        = 2

};


// Enum  /Script/AClient.ESpecialBulletChange
enum class ESpecialBulletChange : uint8_t
{
    Init                                           = 0,
    Mag_EquipAutoFill                              = 1,
    Reload                                         = 2,
    Shoot                                          = 3,
    StartFire                                      = 4,
    StopFire                                       = 5,
    Sync_Simulated                                 = 6,
    ESpecialBulletChange_MAX                       = 7

};


// Enum  /Script/AClient.EBulletChangeReason
enum class EBulletChangeReason : uint8_t
{
    Init                                           = 0,
    Mag_UnEquip                                    = 1,
    Mag_EquipAutoFill                              = 2,
    Reload                                         = 3,
    Shoot                                          = 4,
    StartFire                                      = 5,
    StopFire                                       = 6,
    Sync_Simulated                                 = 7,
    Item_Update                                    = 8,
    EBulletChangeReason_MAX                        = 9

};


// Enum  /Script/AClient.EWeaponReloadType
enum class EWeaponReloadType : uint8_t
{
    Magzine                                        = 0,
    OneByOne                                       = 1,
    OneByOneAndClip                                = 2,
    EWeaponReloadType_MAX                          = 3

};


// Enum  /Script/AClient.EWeaponAction
enum class EWeaponAction : uint8_t
{
    WA_None                                        = 0,
    WA_FirstPick                                   = 1,
    WA_Equip                                       = 2,
    WA_UnEquip                                     = 3,
    WA_Raise                                       = 4,
    WA_Lower                                       = 5,
    WA_Shoot                                       = 6,
    WA_AutoShoot                                   = 7,
    WA_AutoFireStart                               = 8,
    WA_AutoFireEnd                                 = 9,
    WA_EmptyShoot                                  = 10,
    WA_ShellDrop                                   = 11,
    WA_Reload                                      = 12,
    WA_ShootTypeSwitch                             = 13,
    WA_ScopeOn                                     = 14,
    WA_ScopeOff                                    = 15,
    WA_ChargeIn                                    = 16,
    WA_ChargeOut                                   = 17,
    WA_ChargeFire                                  = 18,
    WA_AimChargeUp                                 = 19,
    WA_AimChargeDown                               = 20,
    WA_AimChargeLevel1                             = 21,
    WA_AimChargeLevel2                             = 22,
    WA_AimChargeLevel3                             = 23,
    WA_LensShoot                                   = 24,
    WA_AimChargeFullDown                           = 25,
    WA_AimChargeStart                              = 26,
    WA_AimChargeFull                               = 27,
    WA_AimChargeShoot                              = 28,
    WA_ChargeAutoFireStart                         = 29,
    WA_ChargeAutoFireEnd                           = 30,
    WA_LightBeamFire                               = 31,
    WA_TraceOK                                     = 32,
    WA_AimChargeLevel1_UP                          = 33,
    WA_AimChargeLevel2_UP                          = 34,
    WA_AimChargeLevel3_UP                          = 35,
    WA_MAX                                         = 36

};


// Enum  /Script/AClient.EShootWeaponShootMode
enum class EShootWeaponShootMode : uint8_t
{
    SWST_MuzzleDirection                           = 0,
    SWST_TargetDirection                           = 1,
    SWST_AimDirection                              = 2,
    SWST_MAX                                       = 3

};


// Enum  /Script/AClient.EWeaponUIScheme
enum class EWeaponUIScheme : uint8_t
{
    WUS_Normal                                     = 0,
    WUS_Integrate                                  = 1,
    WUS_MAX                                        = 2

};


// Enum  /Script/AClient.ERecoilPose
enum class ERecoilPose : uint8_t
{
    InAir                                          = 0,
    Sliding                                        = 1,
    StandMove                                      = 2,
    StandIdle                                      = 3,
    CrouchMove                                     = 4,
    CrouchIdle                                     = 5,
    InGravityLift                                  = 6,
    InSprint                                       = 7,
    Hero08UpArea                                   = 8,
    Max                                            = 9

};


// Enum  /Script/AClient.EWeaponFireMode
enum class EWeaponFireMode : uint8_t
{
    None                                           = 0,
    OneBullet                                      = 1,
    MultiBullets                                   = 2,
    Auto                                           = 3,
    Charge                                         = 4,
    LightBeam                                      = 5,
    EWeaponFireMode_MAX                            = 6

};


// Enum  /Script/AClient.ESTEWeaponHoldType
enum class ESTEWeaponHoldType : uint8_t
{
    Hand                                           = 0,
    Rifle                                          = 1,
    Pistol                                         = 2,
    Melee                                          = 3,
    ESTEWeaponHoldType_MAX                         = 4

};


// Enum  /Script/AClient.EGngameWeaponStopFireCheckResult
enum class EGngameWeaponStopFireCheckResult : uint8_t
{
    Ok                                             = 0,
    FireMode                                       = 1,
    WeaponState                                    = 2,
    Unknown                                        = 3,
    EGngameWeaponStopFireCheckResult_MAX           = 4

};


// Enum  /Script/AClient.EGngameWeaponStartFireCheckResult
enum class EGngameWeaponStartFireCheckResult : uint8_t
{
    Ok                                             = 0,
    FailedStoredReloadStage                        = 1,
    Reloading                                      = 2,
    NoFireMode                                     = 3,
    NoAmmo                                         = 4,
    TooShortFireInterval                           = 5,
    Unknown                                        = 6,
    EGngameWeaponStartFireCheckResult_MAX          = 7

};


// Enum  /Script/AClient.EWeaponChargeIgniteShareType
enum class EWeaponChargeIgniteShareType : uint8_t
{
    Personal                                       = 0,
    Teammate                                       = 1,
    Global                                         = 2,
    EWeaponChargeIgniteShareType_MAX               = 3

};


// Enum  /Script/AClient.EWeaponChargeDropKeepType
enum class EWeaponChargeDropKeepType : uint8_t
{
    Clear                                          = 0,
    SelfKeep                                       = 1,
    PublicKeep                                     = 2,
    EWeaponChargeDropKeepType_MAX                  = 3

};


// Enum  /Script/AClient.EWeaponChargeBuffType
enum class EWeaponChargeBuffType : uint8_t
{
    NONE                                           = 0,
    ShootInterval                                  = 1,
    DamageDoor                                     = 2,
    BreakShield                                    = 3,
    BulletSpeed                                    = 4,
    BulletRange                                    = 5,
    BulletGravity                                  = 6,
    DamageFactor                                   = 7,
    ShieldDamageFactor                             = 8,
    MeshDamageFactor                               = 9,
    ThighsDamageFactor                             = 10,
    HeadDamageFactor                               = 11,
    BodyDamageFactor                               = 12,
    ShieldAr302_a_                                 = 13,
    EWeaponChargeBuffType_MAX                      = 14

};


// Enum  /Script/AClient.EWeapon3DUIType
enum class EWeapon3DUIType : uint8_t
{
    W3T_WeaponFPP                                  = 0,
    W3T_WeaponTPP                                  = 1,
    W3T_AttachFPP                                  = 2,
    W3T_AttachTPP                                  = 3,
    W3T_Sniper                                     = 4,
    W3T_SpecialWeapon                              = 5,
    W3T_KillNumFPP                                 = 6,
    W3T_KillNumTPP                                 = 7,
    W3T_KillNumLeftFPP                             = 8,
    W3T_KillNumLeftTPP                             = 9,
    W3T_Max                                        = 10

};


// Enum  /Script/AClient.EAttachToCharacterMode
enum class EAttachToCharacterMode : uint8_t
{
    NONE                                           = 0,
    FPP                                            = 1,
    TPP                                            = 2,
    EAttachToCharacterMode_MAX                     = 3

};


// Enum  /Script/AClient.ELowAmmoShowState
enum class ELowAmmoShowState : uint8_t
{
    None                                           = 0,
    Low                                            = 1,
    Empty                                          = 2,
    ELowAmmoShowState_MAX                          = 3

};


// Enum  /Script/AClient.EGngamePawnStartFireCheckResult
enum class EGngamePawnStartFireCheckResult : uint8_t
{
    Ok                                             = 0,
    NotLocalControlled                             = 1,
    PawnStateNotAllow                              = 2,
    ForbidFireState                                = 3,
    FailedShootTypeSwitching                       = 4,
    Reloading                                      = 5,
    NotUsingShootWeapon                            = 6,
    AIClimbingWall                                 = 7,
    Unknown                                        = 8,
    EGngamePawnStartFireCheckResult_MAX            = 9

};


// Enum  /Script/AClient.ERechargeGunType
enum class ERechargeGunType : uint8_t
{
    Red                                            = 0,
    Blue                                           = 1,
    Blue                                           = 2,
    ERechargeGunType_MAX                           = 3

};


// Enum  /Script/AClient.EReplicatingState
enum class EReplicatingState : uint8_t
{
    NoReplicating                                  = 0,
    Replicating                                    = 1,
    Opening                                        = 2,
    EReplicatingState_MAX                          = 3

};


// Enum  /Script/AClient.EFeatustoreType
enum class EFeatustoreType : uint8_t
{
    Normal                                         = 0,
    AirDrop                                        = 1,
    EFeatustoreType_MAX                            = 2

};


// Enum  /Script/AClient.ECantReplicateReason
enum class ECantReplicateReason : uint8_t
{
    None                                           = 0,
    NoEnoughMatrial                                = 1,
    NoWeapon                                       = 2,
    NoUpgradeShield                                = 3,
    ECantReplicateReason_MAX                       = 4

};


// Enum  /Script/AClient.EReplicateType
enum class EReplicateType : uint8_t
{
    OneDayRound                                    = 0,
    OneWeekRound                                   = 1,
    LockItem                                       = 2,
    WeaponType                                     = 3,
    UpGrade                                        = 4,
    LockWeaponType                                 = 5,
    EReplicateType_MAX                             = 6

};


// Enum  /Script/AClient.EControllerMappingPriority
enum class EControllerMappingPriority : uint8_t
{
    NONE                                           = 0,
    BackGround                                     = 1,
    BaseInput                                      = 2,
    UpBaseInput                                    = 3,
    Window                                         = 4,
    HighWindow                                     = 5,
    TOP                                            = 6,
    EControllerMappingPriority_MAX                 = 7

};


// Enum  /Script/AClient.EParachuteReportEvent
enum class EParachuteReportEvent : uint8_t
{
    Leave                                          = 0,
    Join                                           = 1,
    Transfer                                       = 2,
    ShowWorkbenchMark                              = 3,
    UseCameraZoom                                  = 4,
    UseSmallEye                                    = 5,
    EParachuteReportEvent_MAX                      = 6

};


// Enum  /Script/AClient.EZiplineDirectionMode
enum class EZiplineDirectionMode : uint8_t
{
    BothSide                                       = 0,
    OnlyToBegin                                    = 1,
    OnlyToEnd                                      = 2,
    EZiplineDirectionMode_MAX                      = 3

};


// Enum  /Script/AClient.EZiplinePhysicsMode
enum class EZiplinePhysicsMode : uint8_t
{
    LengthMode                                     = 0,
    SpringMode                                     = 1,
    MiddleMode                                     = 2,
    NewLength                                      = 3,
    EZiplinePhysicsMode_MAX                        = 4

};


// Enum  /Script/AClient.EZiplineDownPreset
enum class EZiplineDownPreset : uint8_t
{
    None                                           = 0,
    Hero15__Init                                   = 1,
    Hero15__Auto                                   = 2,
    Vertical_Init                                  = 3,
    Vertical_Auto_Down                             = 4,
    Vertical_Auto_Up                               = 5,
    Custom                                         = 6,
    EZiplineDownPreset_MAX                         = 7

};


// Enum  /Script/AClient.EZiplineDirH
enum class EZiplineDirH : uint8_t
{
    SlideDir                                       = 0,
    ViewDir                                        = 1,
    ConstDir                                       = 2,
    EZiplineDirH_MAX                               = 3

};


// Enum  /Script/AClient.EZiplineType
enum class EZiplineType : uint8_t
{
    ZiplineHero15_                                 = 0,
    ZiplineVertical                                = 1,
    EZiplineType_MAX                               = 2

};


// Enum  /Script/AClient.EHolderType
enum class EHolderType : uint8_t
{
    Long                                           = 0,
    Medium                                         = 1,
    Short                                          = 2,
    EHolderType_MAX                                = 3

};


// Enum  /Script/AClient.EZiplineState
enum class EZiplineState : uint8_t
{
    EZiplineState_Static                           = 0,
    EZiplineState_Dynamic                          = 1,
    EZiplineState_Ride                             = 3,
    EZiplineState_MAX                              = 4

};


// Enum  /Script/UnrealArchExt.EUserWidgetFadingStatus
enum class EUserWidgetFadingStatus : uint8_t
{
    UserWidgetFadingStatus_None                    = 0,
    UserWidgetFadingStatus_FadingIn                = 1,
    UserWidgetFadingStatus_FadingOut               = 2,
    UserWidgetFadingStatus_MAX                     = 3

};


// Enum  /Script/PureClient.EMountType
enum class EMountType : uint8_t
{
    None                                           = 0,
    Src                                            = 1,
    Puffer                                         = 2,
    EMountType_MAX                                 = 3

};


// Enum  /Script/PureClient.EUpdateEnum
enum class EUpdateEnum : uint8_t
{
    App                                            = 0,
    Src                                            = 1,
    Repair                                         = 2,
    Finish                                         = 3,
    EUpdateEnum_MAX                                = 4

};


// Enum  /Script/PureClient.EGameRepairMode
enum class EGameRepairMode : uint8_t
{
    NonRepair                                      = 0,
    AllRepair                                      = 1,
    ResRepair                                      = 2,
    DlcRepair                                      = 3,
    EGameRepairMode_MAX                            = 4

};


// Enum  /Script/PureClient.EPufferInitEnum
enum class EPufferInitEnum : uint8_t
{
    None                                           = 0,
    InitStart                                      = 1,
    InitFinish                                     = 2,
    DownloadVerStart                               = 3,
    DownloadVerFinish                              = 4,
    FinishInit                                     = 5,
    EPufferInitEnum_MAX                            = 6

};


// Enum  /Script/PureClient.ETaskState
enum class ETaskState : uint8_t
{
    eReady                                         = 0,
    eDownloading                                   = 1,
    eSuccees                                       = 2,
    eRetry                                         = 3,
    eFailed                                        = 4,
    ETaskState_MAX                                 = 5

};


// Enum  /Script/CoreUObject.ELifetimeCondition
enum class ELifetimeCondition : uint8_t
{
    COND_None                                      = 0,
    COND_InitialOnly                               = 1,
    COND_OwnerOnly                                 = 2,
    COND_SkipOwner                                 = 3,
    COND_SimulatedOnly                             = 4,
    COND_AutonomousOnly                            = 5,
    COND_SimulatedOrPhysics                        = 6,
    COND_InitialOrOwner                            = 7,
    COND_Custom                                    = 8,
    COND_ReplayOrOwner                             = 9,
    COND_ReplayOnly                                = 10,
    COND_SimulatedOnlyNoReplay                     = 11,
    COND_SimulatedOrPhysicsNoReplay                = 12,
    COND_SkipReplay                                = 13,
    COND_ObserverOrOwner                           = 14,
    COND_ObserverOnly                              = 15,
    COND_SimulatedOnlyNoObserver                   = 16,
    COND_SimulatedOrPhysicsNoObserver              = 17,
    COND_SkipObserver                              = 18,
    COND_ObserveSelfOrOwner                        = 19,
    COND_ObserveSelfOnly                           = 20,
    COND_SimulatedOnlyNoObserveSelf                = 21,
    COND_SimulatedOrPhysicsNoObserveSelf           = 22,
    COND_SkipObserveSelf                           = 23,
    COND_InitialOrSimulated                        = 25,
    COND_InitialOrReplay                           = 26,
    COND_Never                                     = 27,
    COND_Max                                       = 28

};


// Enum  /Script/CoreUObject.EDataValidationResult
enum class EDataValidationResult : uint8_t
{
    Invalid                                        = 0,
    Valid                                          = 1,
    NotValidated                                   = 2,
    EDataValidationResult_MAX                      = 3

};


// Enum  /Script/CoreUObject.EUnit
enum class EUnit : uint8_t
{
    Micrometers                                    = 0,
    Millimeters                                    = 1,
    Centimeters                                    = 2,
    Meters                                         = 3,
    Kilometers                                     = 4,
    Inches                                         = 5,
    Feet                                           = 6,
    Yards                                          = 7,
    Miles                                          = 8,
    Lightyears                                     = 9,
    Degrees                                        = 10,
    Radians                                        = 11,
    MetersPerSecond                                = 12,
    KilometersPerHour                              = 13,
    MilesPerHour                                   = 14,
    Celsius                                        = 15,
    Farenheit                                      = 16,
    Kelvin                                         = 17,
    Micrograms                                     = 18,
    Milligrams                                     = 19,
    Grams                                          = 20,
    Kilograms                                      = 21,
    MetricTons                                     = 22,
    Ounces                                         = 23,
    Pounds                                         = 24,
    Stones                                         = 25,
    Newtons                                        = 26,
    PoundsForce                                    = 27,
    KilogramsForce                                 = 28,
    Hertz                                          = 29,
    Kilohertz                                      = 30,
    Megahertz                                      = 31,
    Gigahertz                                      = 32,
    RevolutionsPerMinute                           = 33,
    Bytes                                          = 34,
    Kilobytes                                      = 35,
    Megabytes                                      = 36,
    Gigabytes                                      = 37,
    Terabytes                                      = 38,
    Lumens                                         = 39,
    Milliseconds                                   = 43,
    Seconds                                        = 44,
    Minutes                                        = 45,
    Hours                                          = 46,
    Days                                           = 47,
    Months                                         = 48,
    Years                                          = 49,
    Multiplier                                     = 52,
    Percentage                                     = 51,
    Unspecified                                    = 53,
    EUnit_MAX                                      = 54

};


// Enum  /Script/CoreUObject.EPixelFormat
enum class EPixelFormat : uint8_t
{
    PF_Unknown                                     = 0,
    PF_A32B32G32R32F                               = 1,
    PF_B8G8R8A8                                    = 2,
    PF_G8                                          = 3,
    PF_G16                                         = 4,
    PF_DXT1                                        = 5,
    PF_DXT3                                        = 6,
    PF_DXT5                                        = 7,
    PF_UYVY                                        = 8,
    PF_FloatRGB                                    = 9,
    PF_FloatRGBA                                   = 10,
    PF_DepthStencil                                = 11,
    PF_ShadowDepth                                 = 12,
    PF_R32_FLOAT                                   = 13,
    PF_G16R16                                      = 14,
    PF_G16R16F                                     = 15,
    PF_G16R16F_FILTER                              = 16,
    PF_G32R32F                                     = 17,
    PF_A2B10G10R10                                 = 18,
    PF_A16B16G16R16                                = 19,
    PF_D24                                         = 20,
    PF_R16F                                        = 21,
    PF_R16F_FILTER                                 = 22,
    PF_BC5                                         = 23,
    PF_V8U8                                        = 24,
    PF_A1                                          = 25,
    PF_FloatR11G11B10                              = 26,
    PF_A8                                          = 27,
    PF_R32_UINT                                    = 28,
    PF_R32_SINT                                    = 29,
    PF_PVRTC2                                      = 30,
    PF_PVRTC4                                      = 31,
    PF_R16_UINT                                    = 32,
    PF_R16_SINT                                    = 33,
    PF_R16G16B16A16_UINT                           = 34,
    PF_R16G16B16A16_SINT                           = 35,
    PF_R5G6B5_UNORM                                = 36,
    PF_R8G8B8A8                                    = 37,
    PF_A8R8G8B8                                    = 38,
    PF_BC4                                         = 39,
    PF_R8G8                                        = 40,
    PF_ATC_RGB                                     = 41,
    PF_ATC_RGBA_E                                  = 42,
    PF_ATC_RGBA_I                                  = 43,
    PF_X24_G8                                      = 44,
    PF_ETC1                                        = 45,
    PF_ETC2_RGB                                    = 46,
    PF_ETC2_RGBA                                   = 47,
    PF_R32G32B32A32_UINT                           = 48,
    PF_R16G16_UINT                                 = 49,
    PF_ASTC_4x4                                    = 50,
    PF_ASTC_6x6                                    = 51,
    PF_ASTC_8x8                                    = 52,
    PF_ASTC_10x10                                  = 53,
    PF_ASTC_12x12                                  = 54,
    PF_BC6H                                        = 55,
    PF_BC7                                         = 56,
    PF_R8_UINT                                     = 57,
    PF_L8                                          = 58,
    PF_XGXR8                                       = 59,
    PF_R8G8B8A8_UINT                               = 60,
    PF_R8G8B8A8_SNORM                              = 61,
    PF_R16G16B16A16_UNORM                          = 62,
    PF_R16G16B16A16_SNORM                          = 63,
    PF_PLATFORM_HDR                                = 64,
    PF_PLATFORM_HDR                                = 65,
    PF_PLATFORM_HDR                                = 66,
    PF_NV12                                        = 67,
    PF_R32G32_UINT                                 = 68,
    PF_MAX                                         = 71

};


// Enum  /Script/CoreUObject.ELogTimes
enum class ELogTimes : uint8_t
{
    None                                           = 0,
    UTC                                            = 1,
    SinceGStartTime                                = 2,
    Local                                          = 3,
    ELogTimes_MAX                                  = 4

};


// Enum  /Script/CoreUObject.ESearchDir
enum class ESearchDir : uint8_t
{
    FromStart                                      = 0,
    FromEnd                                        = 1,
    ESearchDir_MAX                                 = 2

};


// Enum  /Script/CoreUObject.ESearchCase
enum class ESearchCase : uint8_t
{
    CaseSensitive                                  = 0,
    IgnoreCase                                     = 1,
    ESearchCase_MAX                                = 2

};


// Enum  /Script/InputCore.ETouchType
enum class ETouchType : uint8_t
{
    Began                                          = 0,
    Moved                                          = 1,
    Stationary                                     = 2,
    ForceChanged                                   = 3,
    FirstMove                                      = 4,
    Ended                                          = 5,
    NumTypes                                       = 6,
    ETouchType_MAX                                 = 7

};


// Enum  /Script/InputCore.EConsoleForGamepadLabels
enum class EConsoleForGamepadLabels : uint8_t
{
    None                                           = 0,
    XBoxOne                                        = 1,
    PS4                                            = 2,
    EConsoleForGamepadLabels_MAX                   = 3

};


// Enum  /Script/SlateCore.EFontLayoutMethod
enum class EFontLayoutMethod : uint8_t
{
    Metrics                                        = 0,
    BoundingBox                                    = 1,
    EFontLayoutMethod_MAX                          = 2

};


// Enum  /Script/SlateCore.EFontLoadingPolicy
enum class EFontLoadingPolicy : uint8_t
{
    LazyLoad                                       = 0,
    Stream                                         = 1,
    Inline                                         = 2,
    EFontLoadingPolicy_MAX                         = 3

};


// Enum  /Script/SlateCore.EFontHinting
enum class EFontHinting : uint8_t
{
    Default                                        = 0,
    Auto                                           = 1,
    AutoLight                                      = 2,
    Monochrome                                     = 3,
    None                                           = 4,
    EFontHinting_MAX                               = 5

};


// Enum  /Script/SlateCore.EFocusCause
enum class EFocusCause : uint8_t
{
    Mouse                                          = 0,
    Navigation                                     = 1,
    SetDirectly                                    = 2,
    Cleared                                        = 3,
    OtherWidgetLostFocus                           = 4,
    WindowActivate                                 = 5,
    EFocusCause_MAX                                = 6

};


// Enum  /Script/SlateCore.ESlateDebuggingFocusEvent
enum class ESlateDebuggingFocusEvent : uint8_t
{
    FocusChanging                                  = 0,
    FocusLost                                      = 1,
    FocusReceived                                  = 2,
    ESlateDebuggingFocusEvent_MAX                  = 3

};


// Enum  /Script/SlateCore.ESlateDebuggingNavigationMethod
enum class ESlateDebuggingNavigationMethod : uint8_t
{
    Unknown                                        = 0,
    Explicit                                       = 1,
    CustomDelegateBound                            = 2,
    CustomDelegateUnbound                          = 3,
    NextOrPrevious                                 = 4,
    HitTestGrid                                    = 5,
    ESlateDebuggingNavigationMethod_MAX            = 6

};


// Enum  /Script/SlateCore.ESlateDebuggingStateChangeEvent
enum class ESlateDebuggingStateChangeEvent : uint8_t
{
    MouseCaptureGained                             = 0,
    MouseCaptureLost                               = 1,
    ESlateDebuggingStateChangeEvent_MAX            = 2

};


// Enum  /Script/SlateCore.ESlateDebuggingInputEvent
enum class ESlateDebuggingInputEvent : uint8_t
{
    MouseMove                                      = 0,
    MouseEnter                                     = 1,
    MouseLeave                                     = 2,
    MouseButtonDown                                = 3,
    MouseButtonUp                                  = 4,
    MouseButtonDoubleClick                         = 5,
    MouseWheel                                     = 6,
    TouchStart                                     = 7,
    TouchEnd                                       = 8,
    DragDetected                                   = 9,
    DragEnter                                      = 10,
    DragLeave                                      = 11,
    DragOver                                       = 12,
    DragDrop                                       = 13,
    DropMessage                                    = 14,
    KeyDown                                        = 15,
    KeyUp                                          = 16,
    KeyChar                                        = 17,
    AnalogInput                                    = 18,
    TouchGesture                                   = 19,
    COUNT                                          = 20,
    ESlateDebuggingInputEvent_MAX                  = 21

};


// Enum  /Script/SlateCore.EScrollDirection
enum class EScrollDirection : uint8_t
{
    Scroll_Down                                    = 0,
    Scroll_Up                                      = 1,
    Scroll_MAX                                     = 2

};


// Enum  /Script/SlateCore.EMenuPlacement
enum class EMenuPlacement : uint8_t
{
    MenuPlacement_BelowAnchor                      = 0,
    MenuPlacement_CenteredBelowAnchor              = 1,
    MenuPlacement_BelowRightAnchor                 = 2,
    MenuPlacement_ComboBox                         = 3,
    MenuPlacement_ComboBoxRight                    = 4,
    MenuPlacement_MenuRight                        = 5,
    MenuPlacement_AboveAnchor                      = 6,
    MenuPlacement_CenteredAboveAnchor              = 7,
    MenuPlacement_AboveRightAnchor                 = 8,
    MenuPlacement_MenuLeft                         = 9,
    MenuPlacement_Center                           = 10,
    MenuPlacement_RightLeftCenter                  = 11,
    MenuPlacement_MatchBottomLeft                  = 12,
    MenuPlacement_MAX                              = 13

};


// Enum  /Script/SlateCore.EVerticalAlignment
enum class EVerticalAlignment : uint8_t
{
    VAlign_Fill                                    = 0,
    VAlign_Top                                     = 1,
    VAlign_Center                                  = 2,
    VAlign_Bottom                                  = 3,
    VAlign_MAX                                     = 4

};


// Enum  /Script/SlateCore.EHorizontalAlignment
enum class EHorizontalAlignment : uint8_t
{
    HAlign_Fill                                    = 0,
    HAlign_Left                                    = 1,
    HAlign_Center                                  = 2,
    HAlign_Right                                   = 3,
    HAlign_MAX                                     = 4

};


// Enum  /Script/SlateCore.ENavigationGenesis
enum class ENavigationGenesis : uint8_t
{
    Keyboard                                       = 0,
    Controller                                     = 1,
    User                                           = 2,
    ENavigationGenesis_MAX                         = 3

};


// Enum  /Script/SlateCore.ENavigationSource
enum class ENavigationSource : uint8_t
{
    FocusedWidget                                  = 0,
    WidgetUnderCursor                              = 1,
    ENavigationSource_MAX                          = 2

};


// Enum  /Script/SlateCore.EUINavigationAction
enum class EUINavigationAction : uint8_t
{
    Accept                                         = 0,
    Back                                           = 1,
    Num                                            = 2,
    Invalid                                        = 3,
    EUINavigationAction_MAX                        = 4

};


// Enum  /Script/SlateCore.EButtonPressMethod
enum class EButtonPressMethod : uint8_t
{
    DownAndUp                                      = 0,
    ButtonPress                                    = 1,
    ButtonRelease                                  = 2,
    EButtonPressMethod_MAX                         = 3

};


// Enum  /Script/SlateCore.EButtonTouchMethod
enum class EButtonTouchMethod : uint8_t
{
    DownAndUp                                      = 0,
    Down                                           = 1,
    Up                                             = 2,
    PreciseTap                                     = 3,
    EButtonTouchMethod_MAX                         = 4

};


// Enum  /Script/SlateCore.EButtonClickMethod
enum class EButtonClickMethod : uint8_t
{
    DownAndUp                                      = 0,
    MouseDown                                      = 1,
    MouseUp                                        = 2,
    PreciseClick                                   = 3,
    EButtonClickMethod_MAX                         = 4

};


// Enum  /Script/SlateCore.EFontFallback
enum class EFontFallback : uint8_t
{
    FF_NoFallback                                  = 0,
    FF_LocalizedFallback                           = 1,
    FF_LastResortFallback                          = 2,
    FF_Max                                         = 3

};


// Enum  /Script/SlateCore.EWidgetBlendMode
enum class EWidgetBlendMode : uint8_t
{
    Opaque                                         = 0,
    Masked                                         = 1,
    Transparent                                    = 2,
    EWidgetBlendMode_MAX                           = 3

};


// Enum  /Script/SlateCore.ESlateCheckBoxType
enum class ESlateCheckBoxType : uint8_t
{
    CheckBox                                       = 0,
    ToggleButton                                   = 1,
    ESlateCheckBoxType_MAX                         = 2

};


// Enum  /Script/SlateCore.ESlateParentWindowSearchMethod
enum class ESlateParentWindowSearchMethod : uint8_t
{
    ActiveWindow                                   = 0,
    MainWindow                                     = 1,
    ESlateParentWindowSearchMethod_MAX             = 2

};


// Enum  /Script/ImageWrapper.EBitmapCSType
enum class EBitmapCSType : uint32_t
{
    BCST_BLCS_CALIBRATED_RGB                       = 0,
    BCST_LCS_sRGB                                  = 1934772034,
    BCST_LCS_WINDOWS_COLOR_SPACE                   = 1466527264,
    BCST_PROFILE_LINKED                            = 1279872587,
    BCST_PROFILE_EMBEDDED                          = 1296188740,
    BCST_MAX                                       = 1934772035

};


// Enum  /Script/ImageWrapper.EBitmapHeaderVersion
enum class EBitmapHeaderVersion : uint8_t
{
    BHV_BITMAPINFOHEADER                           = 0,
    BHV_BITMAPV2INFOHEADER                         = 1,
    BHV_BITMAPV3INFOHEADER                         = 2,
    BHV_BITMAPV4HEADER                             = 3,
    BHV_BITMAPV5HEADER                             = 4,
    BHV_MAX                                        = 5

};


// Enum  /Script/Slate.ETableViewMode
enum class ETableViewMode : uint8_t
{
    List                                           = 0,
    Tile                                           = 1,
    Tree                                           = 2,
    ETableViewMode_MAX                             = 3

};


// Enum  /Script/Slate.ESelectionMode
enum class ESelectionMode : uint8_t
{
    None                                           = 0,
    Single                                         = 1,
    SingleToggle                                   = 2,
    Multi                                          = 3,
    ESelectionMode_MAX                             = 4

};


// Enum  /Script/Slate.EMultiBlockType
enum class EMultiBlockType : uint8_t
{
    None                                           = 0,
    ButtonRow                                      = 1,
    EditableText                                   = 2,
    Heading                                        = 3,
    MenuEntry                                      = 4,
    MenuSeparator                                  = 5,
    ToolBarButton                                  = 6,
    ToolBarComboButton                             = 7,
    ToolBarSeparator                               = 8,
    Widget                                         = 9,
    EMultiBlockType_MAX                            = 10

};


// Enum  /Script/Slate.EMultiBoxType
enum class EMultiBoxType : uint8_t
{
    MenuBar                                        = 0,
    ToolBar                                        = 1,
    VerticalToolBar                                = 2,
    Menu                                           = 3,
    ButtonRow                                      = 4,
    ToolMenuBar                                    = 5,
    EMultiBoxType_MAX                              = 6

};


// Enum  /Script/Slate.EProgressBarFillType
enum class EProgressBarFillType : uint8_t
{
    LeftToRight                                    = 0,
    RightToLeft                                    = 1,
    FillFromCenter                                 = 2,
    TopToBottom                                    = 3,
    BottomToTop                                    = 4,
    EProgressBarFillType_MAX                       = 5

};


// Enum  /Script/Slate.EStretch
enum class EStretch : uint8_t
{
    None                                           = 0,
    Fill                                           = 1,
    ScaleToFit                                     = 2,
    ScaleToFitX                                    = 3,
    ScaleToFitY                                    = 4,
    ScaleToFill                                    = 5,
    ScaleBySafeZone                                = 6,
    UserSpecified                                  = 7,
    EStretch_MAX                                   = 8

};


// Enum  /Script/Slate.EStretchDirection
enum class EStretchDirection : uint8_t
{
    Both                                           = 0,
    DownOnly                                       = 1,
    UpOnly                                         = 2,
    EStretchDirection_MAX                          = 3

};


// Enum  /Script/Slate.EListItemAlignment
enum class EListItemAlignment : uint8_t
{
    EvenlyDistributed                              = 0,
    EvenlySize                                     = 1,
    EvenlyWide                                     = 2,
    LeftAligned                                    = 3,
    RightAligned                                   = 4,
    CenterAligned                                  = 5,
    Fill                                           = 6,
    EListItemAlignment_MAX                         = 7

};


// Enum  /Script/Slate.EMultipleKeyBindingIndex
enum class EMultipleKeyBindingIndex : uint8_t
{
    Primary                                        = 0,
    Secondary                                      = 1,
    NumChords                                      = 2,
    EMultipleKeyBindingIndex_MAX                   = 3

};


// Enum  /Script/Slate.EUserInterfaceActionType
enum class EUserInterfaceActionType : uint8_t
{
    None                                           = 0,
    Button                                         = 1,
    ToggleButton                                   = 2,
    RadioButton                                    = 3,
    Check                                          = 4,
    CollapsedButton                                = 5,
    EUserInterfaceActionType_MAX                   = 6

};


// Enum  /Script/ImageWriteQueue.EDesiredImageFormat
enum class EDesiredImageFormat : uint8_t
{
    PNG                                            = 0,
    JPG                                            = 1,
    BMP                                            = 2,
    EXR                                            = 3,
    EDesiredImageFormat_MAX                        = 4

};


// Enum  /Script/MaterialShaderQualitySettings.EMobileFogQuality
enum class EMobileFogQuality : uint8_t
{
    High                                           = 0,
    Normal                                         = 1,
    Low                                            = 2,
    EMobileFogQuality_MAX                          = 3

};


// Enum  /Script/MaterialShaderQualitySettings.EMobileCSMCascadeCount
enum class EMobileCSMCascadeCount : uint8_t
{
    CSM_Cascade1                                   = 0,
    CSM_Cascade2                                   = 1,
    CSM_Cascade3                                   = 2,
    CSM_Cascade4                                   = 3,
    CSM_MAX                                        = 4

};


// Enum  /Script/MaterialShaderQualitySettings.EMobileCSMQuality
enum class EMobileCSMQuality : uint8_t
{
    NoFiltering                                    = 0,
    PCF_1x1                                        = 1,
    PCF_2x2                                        = 2,
    PCF_2x2_spot                                   = 3,
    EMobileCSMQuality_MAX                          = 4

};


// Enum  /Script/EngineSettings.ESubLevelStripMode
enum class ESubLevelStripMode : uint8_t
{
    ExactClass                                     = 0,
    IsChildOf                                      = 1,
    ESubLevelStripMode_MAX                         = 2

};


// Enum  /Script/EngineSettings.EFourPlayerSplitScreenType
enum class EFourPlayerSplitScreenType : uint8_t
{
    Grid                                           = 0,
    Vertical                                       = 1,
    Horizontal                                     = 2,
    EFourPlayerSplitScreenType_MAX                 = 3

};


// Enum  /Script/EngineSettings.EThreePlayerSplitScreenType
enum class EThreePlayerSplitScreenType : uint8_t
{
    FavorTop                                       = 0,
    FavorBottom                                    = 1,
    Vertical                                       = 2,
    Horizontal                                     = 3,
    EThreePlayerSplitScreenType_MAX                = 4

};


// Enum  /Script/EngineSettings.ETwoPlayerSplitScreenType
enum class ETwoPlayerSplitScreenType : uint8_t
{
    Horizontal                                     = 0,
    Vertical                                       = 1,
    ETwoPlayerSplitScreenType_MAX                  = 2

};


// Enum  /Script/PhysicsCore.EChaosBufferMode
enum class EChaosBufferMode : uint8_t
{
    Double                                         = 0,
    Triple                                         = 1,
    Num                                            = 2,
    Invalid                                        = 3,
    EChaosBufferMode_MAX                           = 4

};


// Enum  /Script/PhysicsCore.EChaosThreadingMode
enum class EChaosThreadingMode : uint8_t
{
    DedicatedThread                                = 0,
    TaskGraph                                      = 1,
    SingleThread                                   = 2,
    Num                                            = 3,
    Invalid                                        = 4,
    EChaosThreadingMode_MAX                        = 5

};


// Enum  /Script/PhysicsCore.EChaosSolverTickMode
enum class EChaosSolverTickMode : uint8_t
{
    Fixed                                          = 0,
    Variable                                       = 1,
    VariableCapped                                 = 2,
    VariableCappedWithTarget                       = 3,
    EChaosSolverTickMode_MAX                       = 4

};


// Enum  /Script/MRMesh.EMeshTrackerVertexColorMode
enum class EMeshTrackerVertexColorMode : uint8_t
{
    None                                           = 0,
    Confidence                                     = 1,
    Block                                          = 2,
    EMeshTrackerVertexColorMode_MAX                = 3

};


// Enum  /Script/AugmentedReality.EARTrackingState
enum class EARTrackingState : uint8_t
{
    Unknown                                        = 0,
    Tracking                                       = 1,
    NotTracking                                    = 2,
    StoppedTracking                                = 3,
    EARTrackingState_MAX                           = 4

};


// Enum  /Script/AugmentedReality.EARSessionTrackingFeature
enum class EARSessionTrackingFeature : uint8_t
{
    None                                           = 0,
    PoseDetection2D                                = 1,
    PersonSegmentation                             = 2,
    PersonSegmentationWithDepth                    = 3,
    EARSessionTrackingFeature_MAX                  = 4

};


// Enum  /Script/AugmentedReality.EARFaceTrackingUpdate
enum class EARFaceTrackingUpdate : uint8_t
{
    CurvesAndGeo                                   = 0,
    CurvesOnly                                     = 1,
    EARFaceTrackingUpdate_MAX                      = 2

};


// Enum  /Script/AugmentedReality.EAREnvironmentCaptureProbeType
enum class EAREnvironmentCaptureProbeType : uint8_t
{
    None                                           = 0,
    Manual                                         = 1,
    Automatic                                      = 2,
    EAREnvironmentCaptureProbeType_MAX             = 3

};


// Enum  /Script/AugmentedReality.EARFrameSyncMode
enum class EARFrameSyncMode : uint8_t
{
    SyncTickWithCameraImage                        = 0,
    SyncTickWithoutCameraImage                     = 1,
    EARFrameSyncMode_MAX                           = 2

};


// Enum  /Script/AugmentedReality.EARLightEstimationMode
enum class EARLightEstimationMode : uint8_t
{
    None                                           = 0,
    AmbientLightEstimate                           = 1,
    DirectionalLightEstimate                       = 2,
    EARLightEstimationMode_MAX                     = 3

};


// Enum  /Script/AugmentedReality.EARPlaneDetectionMode
enum class EARPlaneDetectionMode : uint8_t
{
    None                                           = 0,
    HorizontalPlaneDetection                       = 1,
    VerticalPlaneDetection                         = 2,
    EARPlaneDetectionMode_MAX                      = 3

};


// Enum  /Script/AugmentedReality.EARSessionType
enum class EARSessionType : uint8_t
{
    None                                           = 0,
    Orientation                                    = 1,
    World                                          = 2,
    Face                                           = 3,
    Image                                          = 4,
    ObjectScanning                                 = 5,
    PoseTracking                                   = 6,
    EARSessionType_MAX                             = 7

};


// Enum  /Script/AugmentedReality.EARWorldAlignment
enum class EARWorldAlignment : uint8_t
{
    Gravity                                        = 0,
    GravityAndHeading                              = 1,
    Camera                                         = 2,
    EARWorldAlignment_MAX                          = 3

};


// Enum  /Script/AugmentedReality.EARDepthAccuracy
enum class EARDepthAccuracy : uint8_t
{
    Unkown                                         = 0,
    Approximate                                    = 1,
    Accurate                                       = 2,
    EARDepthAccuracy_MAX                           = 3

};


// Enum  /Script/AugmentedReality.EARDepthQuality
enum class EARDepthQuality : uint8_t
{
    Unkown                                         = 0,
    Low                                            = 1,
    High                                           = 2,
    EARDepthQuality_MAX                            = 3

};


// Enum  /Script/AugmentedReality.EARTextureType
enum class EARTextureType : uint8_t
{
    CameraImage                                    = 0,
    CameraDepth                                    = 1,
    EnvironmentCapture                             = 2,
    EARTextureType_MAX                             = 3

};


// Enum  /Script/AugmentedReality.EAREye
enum class EAREye : uint8_t
{
    LeftEye                                        = 0,
    RightEye                                       = 1,
    EAREye_MAX                                     = 2

};


// Enum  /Script/AugmentedReality.EARFaceBlendShape
enum class EARFaceBlendShape : uint8_t
{
    EyeBlinkLeft                                   = 0,
    EyeLookDownLeft                                = 1,
    EyeLookInLeft                                  = 2,
    EyeLookOutLeft                                 = 3,
    EyeLookUpLeft                                  = 4,
    EyeSquintLeft                                  = 5,
    EyeWideLeft                                    = 6,
    EyeBlinkRight                                  = 7,
    EyeLookDownRight                               = 8,
    EyeLookInRight                                 = 9,
    EyeLookOutRight                                = 10,
    EyeLookUpRight                                 = 11,
    EyeSquintRight                                 = 12,
    EyeWideRight                                   = 13,
    JawForward                                     = 14,
    JawLeft                                        = 15,
    JawRight                                       = 16,
    JawOpen                                        = 17,
    MouthClose                                     = 18,
    MouthFunnel                                    = 19,
    MouthPucker                                    = 20,
    MouthLeft                                      = 21,
    MouthRight                                     = 22,
    MouthSmileLeft                                 = 23,
    MouthSmileRight                                = 24,
    MouthFrownLeft                                 = 25,
    MouthFrownRight                                = 26,
    MouthDimpleLeft                                = 27,
    MouthDimpleRight                               = 28,
    MouthStretchLeft                               = 29,
    MouthStretchRight                              = 30,
    MouthRollLower                                 = 31,
    MouthRollUpper                                 = 32,
    MouthShrugLower                                = 33,
    MouthShrugUpper                                = 34,
    MouthPressLeft                                 = 35,
    MouthPressRight                                = 36,
    MouthLowerDownLeft                             = 37,
    MouthLowerDownRight                            = 38,
    MouthUpperUpLeft                               = 39,
    MouthUpperUpRight                              = 40,
    BrowDownLeft                                   = 41,
    BrowDownRight                                  = 42,
    BrowInnerUp                                    = 43,
    BrowOuterUpLeft                                = 44,
    BrowOuterUpRight                               = 45,
    CheekPuff                                      = 46,
    CheekSquintLeft                                = 47,
    CheekSquintRight                               = 48,
    NoseSneerLeft                                  = 49,
    NoseSneerRight                                 = 50,
    TongueOut                                      = 51,
    HeadYaw                                        = 52,
    HeadPitch                                      = 53,
    HeadRoll                                       = 54,
    LeftEyeYaw                                     = 55,
    LeftEyePitch                                   = 56,
    LeftEyeRoll                                    = 57,
    RightEyeYaw                                    = 58,
    RightEyePitch                                  = 59,
    RightEyeRoll                                   = 60,
    MAX                                            = 61

};


// Enum  /Script/AugmentedReality.EARFaceTrackingDirection
enum class EARFaceTrackingDirection : uint8_t
{
    FaceRelative                                   = 0,
    FaceMirrored                                   = 1,
    EARFaceTrackingDirection_MAX                   = 2

};


// Enum  /Script/AugmentedReality.EARCandidateImageOrientation
enum class EARCandidateImageOrientation : uint8_t
{
    Landscape                                      = 0,
    Portrait                                       = 1,
    EARCandidateImageOrientation_MAX               = 2

};


// Enum  /Script/AugmentedReality.EARJointTransformSpace
enum class EARJointTransformSpace : uint8_t
{
    Model                                          = 0,
    ParentJoint                                    = 1,
    EARJointTransformSpace_MAX                     = 2

};


// Enum  /Script/AugmentedReality.EARObjectClassification
enum class EARObjectClassification : uint8_t
{
    NotApplicable                                  = 0,
    Unknown                                        = 1,
    Wall                                           = 2,
    Ceiling                                        = 3,
    Floor                                          = 4,
    Table                                          = 5,
    Seat                                           = 6,
    Face                                           = 7,
    Image                                          = 8,
    World                                          = 9,
    SceneObject                                    = 10,
    EARObjectClassification_MAX                    = 11

};


// Enum  /Script/AugmentedReality.EARPlaneOrientation
enum class EARPlaneOrientation : uint8_t
{
    Horizontal                                     = 0,
    Vertical                                       = 1,
    Diagonal                                       = 2,
    EARPlaneOrientation_MAX                        = 3

};


// Enum  /Script/AugmentedReality.EARWorldMappingState
enum class EARWorldMappingState : uint8_t
{
    NotAvailable                                   = 0,
    StillMappingNotRelocalizable                   = 1,
    StillMappingRelocalizable                      = 2,
    Mapped                                         = 3,
    EARWorldMappingState_MAX                       = 4

};


// Enum  /Script/AugmentedReality.EARSessionStatus
enum class EARSessionStatus : uint8_t
{
    NotStarted                                     = 0,
    Running                                        = 1,
    NotSupported                                   = 2,
    FatalError                                     = 3,
    PermissionNotGranted                           = 4,
    UnsupportedConfiguration                       = 5,
    Other                                          = 6,
    EARSessionStatus_MAX                           = 7

};


// Enum  /Script/AugmentedReality.EARTrackingQualityReason
enum class EARTrackingQualityReason : uint8_t
{
    None                                           = 0,
    Initializing                                   = 1,
    Relocalizing                                   = 2,
    ExcessiveMotion                                = 3,
    InsufficientFeatures                           = 4,
    EARTrackingQualityReason_MAX                   = 5

};


// Enum  /Script/AugmentedReality.EARTrackingQuality
enum class EARTrackingQuality : uint8_t
{
    NotTracking                                    = 0,
    OrientationOnly                                = 1,
    OrientationAndPosition                         = 2,
    EARTrackingQuality_MAX                         = 3

};


// Enum  /Script/AugmentedReality.EARLineTraceChannels
enum class EARLineTraceChannels : uint8_t
{
    None                                           = 0,
    FeaturePoint                                   = 1,
    GroundPlane                                    = 2,
    PlaneUsingExtent                               = 4,
    PlaneUsingBoundaryPolygon                      = 8,
    EARLineTraceChannels_MAX                       = 9

};


// Enum  /Script/HeadMountedDisplay.EXRTrackedDeviceType
enum class EXRTrackedDeviceType : uint8_t
{
    HeadMountedDisplay                             = 0,
    Controller                                     = 1,
    TrackingReference                              = 2,
    Other                                          = 3,
    Invalid                                        = 254,
    Any                                            = 255,
    EXRTrackedDeviceType_MAX                       = 256

};


// Enum  /Script/HeadMountedDisplay.ESpectatorScreenMode
enum class ESpectatorScreenMode : uint8_t
{
    Disabled                                       = 0,
    SingleEyeLetterboxed                           = 1,
    Undistorted                                    = 2,
    Distorted                                      = 3,
    SingleEye                                      = 4,
    SingleEyeCroppedToFill                         = 5,
    Texture                                        = 6,
    TexturePlusEye                                 = 7,
    ESpectatorScreenMode_MAX                       = 8

};


// Enum  /Script/HeadMountedDisplay.EHMDWornState
enum class EHMDWornState : uint8_t
{
    Unknown                                        = 0,
    Worn                                           = 1,
    NotWorn                                        = 2,
    EHMDWornState_MAX                              = 3

};


// Enum  /Script/HeadMountedDisplay.EHMDTrackingOrigin
enum class EHMDTrackingOrigin : uint8_t
{
    Floor                                          = 0,
    Eye                                            = 1,
    Stage                                          = 2,
    EHMDTrackingOrigin_MAX                         = 3

};


// Enum  /Script/HeadMountedDisplay.EOrientPositionSelector
enum class EOrientPositionSelector : uint8_t
{
    Orientation                                    = 0,
    Position                                       = 1,
    OrientationAndPosition                         = 2,
    EOrientPositionSelector_MAX                    = 3

};


// Enum  /Script/HeadMountedDisplay.ETrackingStatus
enum class ETrackingStatus : uint8_t
{
    NotTracked                                     = 0,
    InertialOnly                                   = 1,
    Tracked                                        = 2,
    ETrackingStatus_MAX                            = 3

};


// Enum  /Script/Foliage.EFoliageScaling
enum class EFoliageScaling : uint8_t
{
    Uniform                                        = 0,
    Free                                           = 1,
    LockXY                                         = 2,
    LockXZ                                         = 3,
    LockYZ                                         = 4,
    EFoliageScaling_MAX                            = 5

};


// Enum  /Script/Foliage.EVertexColorMaskChannel
enum class EVertexColorMaskChannel : uint8_t
{
    Red                                            = 0,
    Green                                          = 1,
    Blue                                           = 2,
    Alpha                                          = 3,
    MAX_None                                       = 4,
    EVertexColorMaskChannel_MAX                    = 5

};


// Enum  /Script/Foliage.FoliageVertexColorMask
enum class FoliageVertexColorMask : uint8_t
{
    FOLIAGEVERTEXCOLORMASK_Disabled                = 0,
    FOLIAGEVERTEXCOLORMASK_Red                     = 1,
    FOLIAGEVERTEXCOLORMASK_Green                   = 2,
    FOLIAGEVERTEXCOLORMASK_Blue                    = 3,
    FOLIAGEVERTEXCOLORMASK_Alpha                   = 4,
    FOLIAGEVERTEXCOLORMASK_MAX                     = 5

};


// Enum  /Script/Foliage.ESimulationQuery
enum class ESimulationQuery : uint8_t
{
    CollisionOverlap                               = 1,
    ShadeOverlap                                   = 2,
    AnyOverlap                                     = 3,
    ESimulationQuery_MAX                           = 4

};


// Enum  /Script/Foliage.ESimulationOverlap
enum class ESimulationOverlap : uint8_t
{
    CollisionOverlap                               = 0,
    ShadeOverlap                                   = 1,
    None                                           = 2,
    ESimulationOverlap_MAX                         = 3

};


// Enum  /Script/Landscape.ELandscapeBlendMode
enum class ELandscapeBlendMode : uint8_t
{
    LSBM_AdditiveBlend                             = 0,
    LSBM_AlphaBlend                                = 1,
    LSBM_MAX                                       = 2

};


// Enum  /Script/Landscape.ELandscapeSetupErrors
enum class ELandscapeSetupErrors : uint8_t
{
    LSE_None                                       = 0,
    LSE_NoLandscapeInfo                            = 1,
    LSE_CollsionXY                                 = 2,
    LSE_NoLayerInfo                                = 3,
    LSE_MAX                                        = 4

};


// Enum  /Script/Landscape.ELandscapeClearMode
enum class ELandscapeClearMode : uint8_t
{
    Clear_Weightmap                                = 1,
    Clear_Heightmap                                = 2,
    Clear_All                                      = 3,
    Clear_MAX                                      = 4

};


// Enum  /Script/Landscape.ELandscapeGizmoType
enum class ELandscapeGizmoType : uint8_t
{
    LGT_None                                       = 0,
    LGT_Height                                     = 1,
    LGT_Weight                                     = 2,
    LGT_MAX                                        = 3

};


// Enum  /Script/Landscape.EGrassScaling
enum class EGrassScaling : uint8_t
{
    Uniform                                        = 0,
    Free                                           = 1,
    LockXY                                         = 2,
    EGrassScaling_MAX                              = 3

};


// Enum  /Script/Landscape.ELandscapeLODFalloff
enum class ELandscapeLODFalloff : uint8_t
{
    Linear                                         = 0,
    SquareRoot                                     = 1,
    ELandscapeLODFalloff_MAX                       = 2

};


// Enum  /Script/Landscape.ELandscapeLayerDisplayMode
enum class ELandscapeLayerDisplayMode : uint8_t
{
    Default                                        = 0,
    Alphabetical                                   = 1,
    UserSpecific                                   = 2,
    ELandscapeLayerDisplayMode_MAX                 = 3

};


// Enum  /Script/Landscape.ELandscapeLayerPaintingRestriction
enum class ELandscapeLayerPaintingRestriction : uint8_t
{
    None                                           = 0,
    UseMaxLayers                                   = 1,
    ExistingOnly                                   = 2,
    UseComponentWhitelist                          = 3,
    ELandscapeLayerPaintingRestriction_MAX         = 4

};


// Enum  /Script/Landscape.ELandscapeImportAlphamapType
enum class ELandscapeImportAlphamapType : uint8_t
{
    Additive                                       = 0,
    Layered                                        = 1,
    ELandscapeImportAlphamapType_MAX               = 2

};


// Enum  /Script/Landscape.LandscapeSplineMeshOrientation
enum class LandscapeSplineMeshOrientation : uint8_t
{
    LSMO_XUp                                       = 0,
    LSMO_YUp                                       = 1,
    LSMO_MAX                                       = 2

};


// Enum  /Script/Landscape.ELandscapeLayerBlendType
enum class ELandscapeLayerBlendType : uint8_t
{
    LB_WeightBlend                                 = 0,
    LB_AlphaBlend                                  = 1,
    LB_HeightBlend                                 = 2,
    LB_MAX                                         = 3

};


// Enum  /Script/Landscape.ELandscapeCustomizedCoordType
enum class ELandscapeCustomizedCoordType : uint8_t
{
    LCCT_None                                      = 0,
    LCCT_CustomUV0                                 = 1,
    LCCT_CustomUV1                                 = 2,
    LCCT_CustomUV2                                 = 3,
    LCCT_WeightMapUV                               = 4,
    LCCT_MAX                                       = 5

};


// Enum  /Script/Landscape.ETerrainCoordMappingType
enum class ETerrainCoordMappingType : uint8_t
{
    TCMT_Auto                                      = 0,
    TCMT_XY                                        = 1,
    TCMT_XZ                                        = 2,
    TCMT_YZ                                        = 3,
    TCMT_MAX                                       = 4

};


// Enum  /Script/TimeManagement.EFrameNumberDisplayFormats
enum class EFrameNumberDisplayFormats : uint8_t
{
    NonDropFrameTimecode                           = 0,
    DropFrameTimecode                              = 1,
    Seconds                                        = 2,
    Frames                                         = 3,
    MAX_Count                                      = 4,
    EFrameNumberDisplayFormats_MAX                 = 5

};


// Enum  /Script/MovieScene.EMovieSceneKeyInterpolation
enum class EMovieSceneKeyInterpolation : uint8_t
{
    Auto                                           = 0,
    User                                           = 1,
    Break                                          = 2,
    Linear                                         = 3,
    Constant                                       = 4,
    EMovieSceneKeyInterpolation_MAX                = 5

};


// Enum  /Script/MovieScene.EMovieSceneBlendType
enum class EMovieSceneBlendType : uint8_t
{
    Absolute                                       = 1,
    Additive                                       = 2,
    Relative                                       = 4,
    EMovieSceneBlendType_MAX                       = 5

};


// Enum  /Script/MovieScene.EMovieSceneBuiltInEasing
enum class EMovieSceneBuiltInEasing : uint8_t
{
    Linear                                         = 0,
    SinIn                                          = 1,
    SinOut                                         = 2,
    SinInOut                                       = 3,
    QuadIn                                         = 4,
    QuadOut                                        = 5,
    QuadInOut                                      = 6,
    CubicIn                                        = 7,
    CubicOut                                       = 8,
    CubicInOut                                     = 9,
    QuartIn                                        = 10,
    QuartOut                                       = 11,
    QuartInOut                                     = 12,
    QuintIn                                        = 13,
    QuintOut                                       = 14,
    QuintInOut                                     = 15,
    ExpoIn                                         = 16,
    ExpoOut                                        = 17,
    ExpoInOut                                      = 18,
    CircIn                                         = 19,
    CircOut                                        = 20,
    CircInOut                                      = 21,
    EMovieSceneBuiltInEasing_MAX                   = 22

};


// Enum  /Script/MovieScene.EEvaluationMethod
enum class EEvaluationMethod : uint8_t
{
    Static                                         = 0,
    Swept                                          = 1,
    EEvaluationMethod_MAX                          = 2

};


// Enum  /Script/MovieScene.EUpdateClockSource
enum class EUpdateClockSource : uint8_t
{
    Tick                                           = 0,
    Platform                                       = 1,
    Audio                                          = 2,
    Timecode                                       = 3,
    EUpdateClockSource_MAX                         = 4

};


// Enum  /Script/MovieScene.EMovieSceneEvaluationType
enum class EMovieSceneEvaluationType : uint8_t
{
    FrameLocked                                    = 0,
    WithSubFrames                                  = 1,
    EMovieSceneEvaluationType_MAX                  = 2

};


// Enum  /Script/MovieScene.EMovieScenePlayerStatus
enum class EMovieScenePlayerStatus : uint8_t
{
    Stopped                                        = 0,
    Playing                                        = 1,
    Recording                                      = 2,
    Scrubbing                                      = 3,
    Jumping                                        = 4,
    Stepping                                       = 5,
    Paused                                         = 6,
    MAX                                            = 7

};


// Enum  /Script/MovieScene.EMovieSceneObjectBindingSpace
enum class EMovieSceneObjectBindingSpace : uint8_t
{
    Local                                          = 0,
    Root                                           = 1,
    EMovieSceneObjectBindingSpace_MAX              = 2

};


// Enum  /Script/MovieScene.EMovieSceneCompletionMode
enum class EMovieSceneCompletionMode : uint8_t
{
    KeepState                                      = 0,
    RestoreState                                   = 1,
    ProjectDefault                                 = 2,
    EMovieSceneCompletionMode_MAX                  = 3

};


// Enum  /Script/MovieScene.ESectionEvaluationFlags
enum class ESectionEvaluationFlags : uint8_t
{
    None                                           = 0,
    PreRoll                                        = 1,
    PostRoll                                       = 2,
    ESectionEvaluationFlags_MAX                    = 3

};


// Enum  /Script/MovieScene.EUpdatePositionMethod
enum class EUpdatePositionMethod : uint8_t
{
    Play                                           = 0,
    Jump                                           = 1,
    Scrub                                          = 2,
    EUpdatePositionMethod_MAX                      = 3

};


// Enum  /Script/MovieScene.ESpawnOwnership
enum class ESpawnOwnership : uint8_t
{
    InnerSequence                                  = 0,
    MasterSequence                                 = 1,
    External                                       = 2,
    ESpawnOwnership_MAX                            = 3

};


// Enum  /Script/AnimationCore.ETransformConstraintType
enum class ETransformConstraintType : uint8_t
{
    Translation                                    = 0,
    Rotation                                       = 1,
    Scale                                          = 2,
    Parent                                         = 3,
    ETransformConstraintType_MAX                   = 4

};


// Enum  /Script/AnimationCore.EConstraintType
enum class EConstraintType : uint8_t
{
    Transform                                      = 0,
    Aim                                            = 1,
    MAX                                            = 2

};


// Enum  /Script/FieldSystemCore.EFieldPhysicsDefaultFields
enum class EFieldPhysicsDefaultFields : uint8_t
{
    Field_RadialIntMask                            = 0,
    Field_RadialFalloff                            = 1,
    Field_UniformVector                            = 2,
    Field_RadialVector                             = 3,
    Field_RadialVectorFalloff                      = 4,
    Field_EFieldPhysicsDefaultFields_Max           = 5,
    Field_MAX                                      = 6

};


// Enum  /Script/FieldSystemCore.EFieldPhysicsType
enum class EFieldPhysicsType : uint8_t
{
    Field_DynamicState                             = 0,
    Field_LinearForce                              = 1,
    Field_ExternalClusterStrain                    = 2,
    Field_Kill                                     = 3,
    Field_LinearVelocity                           = 4,
    Field_AngularVelociy                           = 5,
    Field_AngularTorque                            = 6,
    Field_InternalClusterStrain                    = 7,
    Field_DisableThreshold                         = 8,
    Field_SleepingThreshold                        = 9,
    Field_PositionStatic                           = 10,
    Field_PositionAnimated                         = 11,
    Field_PositionTarget                           = 12,
    Field_DynamicConstraint                        = 13,
    Field_CollisionGroup                           = 14,
    Field_ActivateDisabled                         = 15,
    Field_PhysicsType_Max                          = 16

};


// Enum  /Script/FieldSystemCore.EFieldFalloffType
enum class EFieldFalloffType : uint8_t
{
    Field_FallOff_None                             = 0,
    Field_Falloff_Linear                           = 1,
    Field_Falloff_Inverse                          = 2,
    Field_Falloff_Squared                          = 3,
    Field_Falloff_Logarithmic                      = 4,
    Field_Falloff_Max                              = 5

};


// Enum  /Script/FieldSystemCore.EFieldResolutionType
enum class EFieldResolutionType : uint8_t
{
    Field_Resolution_Minimal                       = 0,
    Field_Resolution_DisabledParents               = 1,
    Field_Resolution_Maximum                       = 2,
    Field_Resolution_Max                           = 3

};


// Enum  /Script/FieldSystemCore.EFieldCullingOperationType
enum class EFieldCullingOperationType : uint8_t
{
    Field_Culling_Inside                           = 0,
    Field_Culling_Outside                          = 1,
    Field_Culling_Operation_Max                    = 2,
    Field_Culling_MAX                              = 3

};


// Enum  /Script/FieldSystemCore.EFieldOperationType
enum class EFieldOperationType : uint8_t
{
    Field_Multiply                                 = 0,
    Field_Divide                                   = 1,
    Field_Add                                      = 2,
    Field_Substract                                = 3,
    Field_Operation_Max                            = 4

};


// Enum  /Script/FieldSystemCore.ESetMaskConditionType
enum class ESetMaskConditionType : uint8_t
{
    Field_Set_Always                               = 0,
    Field_Set_IFF_NOT_Interior                     = 1,
    Field_Set_IFF_NOT_Exterior                     = 2,
    Field_MaskCondition_Max                        = 3

};


// Enum  /Script/GeometryCollectionCore.EGeometryCollectionCacheType
enum class EGeometryCollectionCacheType : uint8_t
{
    None                                           = 0,
    Record                                         = 1,
    Play                                           = 2,
    RecordAndPlay                                  = 3,
    EGeometryCollectionCacheType_MAX               = 4

};


// Enum  /Script/GeometryCollectionSimulationCore.EEmissionPatternTypeEnum
enum class EEmissionPatternTypeEnum : uint8_t
{
    Chaos_Emission_Pattern_First_Frame             = 0,
    Chaos_Emission_Pattern_On_Demand               = 1,
    Chaos_Max                                      = 2

};


// Enum  /Script/GeometryCollectionSimulationCore.EInitialVelocityTypeEnum
enum class EInitialVelocityTypeEnum : uint8_t
{
    Chaos_Initial_Velocity_User_Defined            = 0,
    Chaos_Initial_Velocity_None                    = 1,
    Chaos_Max                                      = 2

};


// Enum  /Script/GeometryCollectionSimulationCore.EGeometryCollectionPhysicsTypeEnum
enum class EGeometryCollectionPhysicsTypeEnum : uint8_t
{
    Chaos_AngularVelocity                          = 0,
    Chaos_DynamicState                             = 1,
    Chaos_LinearVelocity                           = 2,
    Chaos_InitialAngularVelocity                   = 3,
    Chaos_InitialLinearVelocity                    = 4,
    Chaos_CollisionGroup                           = 5,
    Chaos_LinearForce                              = 6,
    Chaos_AngularTorque                            = 7,
    Chaos_Max                                      = 8

};


// Enum  /Script/GeometryCollectionSimulationCore.EObjectStateTypeEnum
enum class EObjectStateTypeEnum : uint8_t
{
    Chaos_Object_Sleeping                          = 1,
    Chaos_Object_Kinematic                         = 2,
    Chaos_Object_Static                            = 3,
    Chaos_Object_Dynamic                           = 4,
    Chaos_Object_UserDefined                       = 100,
    Chaos_Max                                      = 101

};


// Enum  /Script/GeometryCollectionSimulationCore.EImplicitTypeEnum
enum class EImplicitTypeEnum : uint8_t
{
    Chaos_Implicit_Box                             = 0,
    Chaos_Implicit_Sphere                          = 1,
    Chaos_Implicit_Capsule                         = 2,
    Chaos_Implicit_LevelSet                        = 3,
    Chaos_Implicit_None                            = 4,
    Chaos_Max                                      = 5

};


// Enum  /Script/GeometryCollectionSimulationCore.ECollisionTypeEnum
enum class ECollisionTypeEnum : uint8_t
{
    Chaos_Volumetric                               = 0,
    Chaos_Surface_Volumetric                       = 1,
    Chaos_Max                                      = 2

};


// Enum  /Script/ChaosSolverEngine.EClusterConnectionTypeEnum
enum class EClusterConnectionTypeEnum : uint8_t
{
    Chaos_PointImplicit                            = 1,
    Chaos_DelaunayTriangulation                    = 2,
    Chaos_MinimalSpanningSubsetDelaunayTriangulation = 3,
    Chaos_PointImplicitAugmentedWithMinimalDelaunay = 4,
    Chaos_None                                     = 0,
    Chaos_EClsuterCreationParameters_Max           = 1,
    Chaos_MAX                                      = 5

};


// Enum  /Script/Engine.ERadialImpulseFalloff
enum class ERadialImpulseFalloff : uint8_t
{
    RIF_Constant                                   = 0,
    RIF_Linear                                     = 1,
    RIF_MAX                                        = 2

};


// Enum  /Script/Engine.ECollisionEnabled
enum class ECollisionEnabled : uint8_t
{
    NoCollision                                    = 0,
    QueryOnly                                      = 1,
    PhysicsOnly                                    = 2,
    QueryAndPhysics                                = 3,
    ECollisionEnabled_MAX                          = 4

};


// Enum  /Script/Engine.EWalkableSlopeBehavior
enum class EWalkableSlopeBehavior : uint8_t
{
    WalkableSlope_Default                          = 0,
    WalkableSlope_Increase                         = 1,
    WalkableSlope_Decrease                         = 2,
    WalkableSlope_Unwalkable                       = 3,
    WalkableSlope_Max                              = 4

};


// Enum  /Script/Engine.EDOFMode
enum class EDOFMode : uint8_t
{
    Default                                        = 0,
    SixDOF                                         = 1,
    YZPlane                                        = 2,
    XZPlane                                        = 3,
    XYPlane                                        = 4,
    CustomPlane                                    = 5,
    None                                           = 6,
    EDOFMode_MAX                                   = 7

};


// Enum  /Script/Engine.ERendererStencilMask
enum class ERendererStencilMask : uint8_t
{
    ERSM_Default                                   = 0,
    ERSM                                           = 1,
    ERSM                                           = 2,
    ERSM                                           = 3,
    ERSM                                           = 4,
    ERSM                                           = 5,
    ERSM                                           = 6,
    ERSM                                           = 7,
    ERSM                                           = 8,
    ERSM                                           = 9,
    ERSM_MAX                                       = 10

};


// Enum  /Script/Engine.EExtraRenderPassID
enum class EExtraRenderPassID : uint8_t
{
    None                                           = 0,
    ExtraRenderPass0                               = 1,
    ExtraRenderPass1                               = 2,
    ExtraRenderPass2                               = 3,
    ExtraRenderPass3                               = 4,
    EExtraRenderPassID_MAX                         = 5

};


// Enum  /Script/Engine.EAPRenderPass
enum class EAPRenderPass : uint8_t
{
    BasePass                                       = 0,
    PostOpaque                                     = 1,
    AfterPostProcessing                            = 2,
    AfterTransparent                               = 3,
    CameraEffect                                   = 4,
    EAPRenderPass_MAX                              = 5

};


// Enum  /Script/Engine.EPhysicalMode
enum class EPhysicalMode : uint8_t
{
    Build                                          = 0,
    Ground                                         = 1,
    EPhysicalMode_MAX                              = 2

};


// Enum  /Script/Engine.ESleepFamily
enum class ESleepFamily : uint8_t
{
    Normal                                         = 0,
    Sensitive                                      = 1,
    Custom                                         = 2,
    ESleepFamily_MAX                               = 3

};


// Enum  /Script/Engine.ERuntimeVirtualTextureMainPassType
enum class ERuntimeVirtualTextureMainPassType : uint8_t
{
    Never                                          = 0,
    Exclusive                                      = 1,
    Always                                         = 2,
    ERuntimeVirtualTextureMainPassType_MAX         = 3

};


// Enum  /Script/Engine.ECanBeCharacterBase
enum class ECanBeCharacterBase : uint8_t
{
    ECB_No                                         = 0,
    ECB_Yes                                        = 1,
    ECB_Owner                                      = 2,
    ECB_MAX                                        = 3

};


// Enum  /Script/Engine.EHasCustomNavigableGeometry
enum class EHasCustomNavigableGeometry : uint8_t
{
    No                                             = 0,
    Yes                                            = 1,
    EvenIfNotCollidable                            = 2,
    DontExport                                     = 3,
    EHasCustomNavigableGeometry_MAX                = 4

};


// Enum  /Script/Engine.ELightmapType
enum class ELightmapType : uint8_t
{
    Default                                        = 0,
    ForceSurface                                   = 1,
    ForceVolumetric                                = 2,
    ELightmapType_MAX                              = 3

};


// Enum  /Script/Engine.EIndirectLightingCacheQuality
enum class EIndirectLightingCacheQuality : uint8_t
{
    ILCQ_Off                                       = 0,
    ILCQ_Point                                     = 1,
    ILCQ_Volume                                    = 2,
    ILCQ_MAX                                       = 3

};


// Enum  /Script/Engine.ESceneDepthPriorityGroup
enum class ESceneDepthPriorityGroup : uint8_t
{
    SDPG_World                                     = 0,
    SDPG_Foreground                                = 1,
    SDPG_MAX                                       = 2

};


// Enum  /Script/GeometryCollectionEngine.EChaosBreakingSortMethod
enum class EChaosBreakingSortMethod : uint8_t
{
    SortNone                                       = 0,
    SortByHighestMass                              = 1,
    SortByHighestSpeed                             = 2,
    SortByNearestFirst                             = 3,
    Count                                          = 4,
    EChaosBreakingSortMethod_MAX                   = 5

};


// Enum  /Script/GeometryCollectionEngine.EChaosCollisionSortMethod
enum class EChaosCollisionSortMethod : uint8_t
{
    SortNone                                       = 0,
    SortByHighestMass                              = 1,
    SortByHighestSpeed                             = 2,
    SortByHighestImpulse                           = 3,
    SortByNearestFirst                             = 4,
    Count                                          = 5,
    EChaosCollisionSortMethod_MAX                  = 6

};


// Enum  /Script/GeometryCollectionEngine.EChaosTrailingSortMethod
enum class EChaosTrailingSortMethod : uint8_t
{
    SortNone                                       = 0,
    SortByHighestMass                              = 1,
    SortByHighestSpeed                             = 2,
    SortByNearestFirst                             = 3,
    Count                                          = 4,
    EChaosTrailingSortMethod_MAX                   = 5

};


// Enum  /Script/GeometryCollectionEngine.EGeometryCollectionDebugDrawActorHideGeometry
enum class EGeometryCollectionDebugDrawActorHideGeometry : uint8_t
{
    HideNone                                       = 0,
    HideWithCollision                              = 1,
    HideSelected                                   = 2,
    HideWholeCollection                            = 3,
    HideAll                                        = 4,
    EGeometryCollectionDebugDrawActorHideGeometry_MAX = 5

};


// Enum  /Script/GeometryCollectionEngine.ECollectionGroupEnum
enum class ECollectionGroupEnum : uint8_t
{
    Chaos_Traansform                               = 0,
    Chaos_Max                                      = 1

};


// Enum  /Script/GeometryCollectionEngine.ECollectionAttributeEnum
enum class ECollectionAttributeEnum : uint8_t
{
    Chaos_Active                                   = 0,
    Chaos_DynamicState                             = 1,
    Chaos_CollisionGroup                           = 2,
    Chaos_Max                                      = 3

};


// Enum  /Script/AnimGraphRuntime.ESphericalLimitType
enum class ESphericalLimitType : uint8_t
{
    Inner                                          = 0,
    Outer                                          = 1,
    ESphericalLimitType_MAX                        = 2

};


// Enum  /Script/AnimGraphRuntime.AnimPhysSimSpaceType
enum class AnimPhysSimSpaceType : uint8_t
{
    Component                                      = 0,
    Actor                                          = 1,
    World                                          = 2,
    RootRelative                                   = 3,
    BoneRelative                                   = 4,
    AnimPhysSimSpaceType_MAX                       = 5

};


// Enum  /Script/AnimGraphRuntime.AnimPhysLinearConstraintType
enum class AnimPhysLinearConstraintType : uint8_t
{
    Free                                           = 0,
    Limited                                        = 1,
    AnimPhysLinearConstraintType_MAX               = 2

};


// Enum  /Script/AnimGraphRuntime.AnimPhysAngularConstraintType
enum class AnimPhysAngularConstraintType : uint8_t
{
    Angular                                        = 0,
    Cone                                           = 1,
    AnimPhysAngularConstraintType_MAX              = 2

};


// Enum  /Script/AnimGraphRuntime.EBlendListTransitionType
enum class EBlendListTransitionType : uint8_t
{
    StandardBlend                                  = 0,
    Inertialization                                = 1,
    EBlendListTransitionType_MAX                   = 2

};


// Enum  /Script/AnimGraphRuntime.EBlendCrossFadeOption
enum class EBlendCrossFadeOption : uint8_t
{
    EBCFO_None                                     = 0,
    EBCFO_BlendSpace                               = 1,
    EBCFO_BlendPose                                = 2,
    EBCFO_MAX                                      = 3

};


// Enum  /Script/AnimGraphRuntime.EDrivenDestinationMode
enum class EDrivenDestinationMode : uint8_t
{
    Bone                                           = 0,
    MorphTarget                                    = 1,
    MaterialParameter                              = 2,
    EDrivenDestinationMode_MAX                     = 3

};


// Enum  /Script/AnimGraphRuntime.EDrivenBoneModificationMode
enum class EDrivenBoneModificationMode : uint8_t
{
    AddToInput                                     = 0,
    ReplaceComponent                               = 1,
    AddToRefPose                                   = 2,
    EDrivenBoneModificationMode_MAX                = 3

};


// Enum  /Script/AnimGraphRuntime.EConstraintOffsetOption
enum class EConstraintOffsetOption : uint8_t
{
    None                                           = 0,
    Offset_RefPose                                 = 1,
    EConstraintOffsetOption_MAX                    = 2

};


// Enum  /Script/AnimGraphRuntime.CopyBoneDeltaMode
enum class CopyBoneDeltaMode : uint8_t
{
    Accumulate                                     = 0,
    Copy                                           = 1,
    CopyBoneDeltaMode_MAX                          = 2

};


// Enum  /Script/AnimGraphRuntime.EInterpolationBlend
enum class EInterpolationBlend : uint8_t
{
    Linear                                         = 0,
    Cubic                                          = 1,
    Sinusoidal                                     = 2,
    EaseInOutExponent2                             = 3,
    EaseInOutExponent3                             = 4,
    EaseInOutExponent4                             = 5,
    EaseInOutExponent5                             = 6,
    MAX                                            = 7

};


// Enum  /Script/AnimGraphRuntime.EBoneModificationMode
enum class EBoneModificationMode : uint8_t
{
    BMM_Ignore                                     = 0,
    BMM_Replace                                    = 1,
    BMM_Additive                                   = 2,
    BMM_MAX                                        = 3

};


// Enum  /Script/AnimGraphRuntime.EModifyCurveApplyMode
enum class EModifyCurveApplyMode : uint8_t
{
    Add                                            = 0,
    Scale                                          = 1,
    Blend                                          = 2,
    WeightedMovingAverage                          = 3,
    RemapCurve                                     = 4,
    EModifyCurveApplyMode_MAX                      = 5

};


// Enum  /Script/AnimGraphRuntime.EPoseDriverOutput
enum class EPoseDriverOutput : uint8_t
{
    DrivePoses                                     = 0,
    DriveCurves                                    = 1,
    EPoseDriverOutput_MAX                          = 2

};


// Enum  /Script/AnimGraphRuntime.EPoseDriverSource
enum class EPoseDriverSource : uint8_t
{
    Rotation                                       = 0,
    Translation                                    = 1,
    EPoseDriverSource_MAX                          = 2

};


// Enum  /Script/AnimGraphRuntime.EPoseDriverType
enum class EPoseDriverType : uint8_t
{
    SwingAndTwist                                  = 0,
    SwingOnly                                      = 1,
    Translation                                    = 2,
    EPoseDriverType_MAX                            = 3

};


// Enum  /Script/AnimGraphRuntime.ESnapshotSourceMode
enum class ESnapshotSourceMode : uint8_t
{
    NamedSnapshot                                  = 0,
    SnapshotPin                                    = 1,
    ESnapshotSourceMode_MAX                        = 2

};


// Enum  /Script/AnimGraphRuntime.ERefPoseType
enum class ERefPoseType : uint8_t
{
    EIT_LocalSpace                                 = 0,
    EIT_Additive                                   = 1,
    EIT_MAX                                        = 2

};


// Enum  /Script/AnimGraphRuntime.ESimulationSpace
enum class ESimulationSpace : uint8_t
{
    ComponentSpace                                 = 0,
    WorldSpace                                     = 1,
    BaseBoneSpace                                  = 2,
    ESimulationSpace_MAX                           = 3

};


// Enum  /Script/AnimGraphRuntime.EScaleChainInitialLength
enum class EScaleChainInitialLength : uint8_t
{
    FixedDefaultLengthValue                        = 0,
    Distance                                       = 1,
    ChainLength                                    = 2,
    EScaleChainInitialLength_MAX                   = 3

};


// Enum  /Script/AnimGraphRuntime.ESequenceEvalReinit
enum class ESequenceEvalReinit : uint8_t
{
    NoReset                                        = 0,
    StartPosition                                  = 1,
    ExplicitTime                                   = 2,
    ESequenceEvalReinit_MAX                        = 3

};


// Enum  /Script/AnimGraphRuntime.ESplineBoneAxis
enum class ESplineBoneAxis : uint8_t
{
    X                                              = 1,
    Y                                              = 2,
    Z                                              = 3,
    ESplineBoneAxis_MAX                            = 4

};


// Enum  /Script/AnimGraphRuntime.ERotationComponent
enum class ERotationComponent : uint8_t
{
    EulerX                                         = 0,
    EulerY                                         = 1,
    EulerZ                                         = 2,
    QuaternionAngle                                = 3,
    SwingAngle                                     = 4,
    TwistAngle                                     = 5,
    ERotationComponent_MAX                         = 6

};


// Enum  /Script/AnimGraphRuntime.EEasingFuncType
enum class EEasingFuncType : uint8_t
{
    Linear                                         = 0,
    Sinusoidal                                     = 1,
    Cubic                                          = 2,
    QuadraticInOut                                 = 3,
    CubicInOut                                     = 4,
    HermiteCubic                                   = 5,
    QuarticInOut                                   = 6,
    QuinticInOut                                   = 7,
    CircularIn                                     = 8,
    CircularOut                                    = 9,
    CircularInOut                                  = 10,
    ExpIn                                          = 11,
    ExpOut                                         = 12,
    ExpInOut                                       = 13,
    CustomCurve                                    = 14,
    EEasingFuncType_MAX                            = 15

};


// Enum  /Script/AnimGraphRuntime.ERBFNormalizeMethod
enum class ERBFNormalizeMethod : uint8_t
{
    OnlyNormalizeAboveOne                          = 0,
    AlwaysNormalize                                = 1,
    NormalizeWithinMedian                          = 2,
    ERBFNormalizeMethod_MAX                        = 3

};


// Enum  /Script/AnimGraphRuntime.ERBFDistanceMethod
enum class ERBFDistanceMethod : uint8_t
{
    Euclidean                                      = 0,
    Quaternion                                     = 1,
    SwingAngle                                     = 2,
    DefaultMethod                                  = 3,
    ERBFDistanceMethod_MAX                         = 4

};


// Enum  /Script/AnimGraphRuntime.ERBFFunctionType
enum class ERBFFunctionType : uint8_t
{
    Gaussian                                       = 0,
    Exponential                                    = 1,
    Linear                                         = 2,
    Cubic                                          = 3,
    Quintic                                        = 4,
    DefaultFunction                                = 5,
    ERBFFunctionType_MAX                           = 6

};


// Enum  /Script/MovieSceneTracks.MovieScene3DPathSection_Axis
enum class MovieScene3DPathSection_Axis : uint8_t
{
    X                                              = 0,
    Y                                              = 1,
    Z                                              = 2,
    NEG_X                                          = 3,
    NEG_Y                                          = 4,
    NEG_Z                                          = 5,
    MovieScene3DPathSection_MAX                    = 6

};


// Enum  /Script/MovieSceneTracks.EFireEventsAtPosition
enum class EFireEventsAtPosition : uint8_t
{
    AtStartOfEvaluation                            = 0,
    AtEndOfEvaluation                              = 1,
    AfterSpawn                                     = 2,
    EFireEventsAtPosition_MAX                      = 3

};


// Enum  /Script/MovieSceneTracks.ELevelVisibility
enum class ELevelVisibility : uint8_t
{
    Visible                                        = 0,
    Hidden                                         = 1,
    ELevelVisibility_MAX                           = 2

};


// Enum  /Script/MovieSceneTracks.EParticleKey
enum class EParticleKey : uint8_t
{
    Activate                                       = 0,
    Deactivate                                     = 1,
    Trigger                                        = 2,
    EParticleKey_MAX                               = 3

};


// Enum  /Script/UMG.EDynamicBoxType
enum class EDynamicBoxType : uint8_t
{
    Horizontal                                     = 0,
    Vertical                                       = 1,
    Wrap                                           = 2,
    Overlay                                        = 3,
    EDynamicBoxType_MAX                            = 4

};


// Enum  /Script/UMG.ESlateSizeRule
enum class ESlateSizeRule : uint8_t
{
    Automatic                                      = 0,
    Fill                                           = 1,
    ESlateSizeRule_MAX                             = 2

};


// Enum  /Script/UMG.EWidgetDesignFlags
enum class EWidgetDesignFlags : uint8_t
{
    None                                           = 0,
    Designing                                      = 1,
    ShowOutline                                    = 2,
    ExecutePreConstruct                            = 4,
    EWidgetDesignFlags_MAX                         = 5

};


// Enum  /Script/UMG.EBindingKind
enum class EBindingKind : uint8_t
{
    Function                                       = 0,
    Property                                       = 1,
    EBindingKind_MAX                               = 2

};


// Enum  /Script/UMG.EWindowVisibility
enum class EWindowVisibility : uint8_t
{
    Visible                                        = 0,
    SelfHitTestInvisible                           = 1,
    EWindowVisibility_MAX                          = 2

};


// Enum  /Script/UMG.EWidgetGeometryMode
enum class EWidgetGeometryMode : uint8_t
{
    Plane                                          = 0,
    Cylinder                                       = 1,
    EWidgetGeometryMode_MAX                        = 2

};


// Enum  /Script/UMG.EWidgetTimingPolicy
enum class EWidgetTimingPolicy : uint8_t
{
    RealTime                                       = 0,
    GameTime                                       = 1,
    EWidgetTimingPolicy_MAX                        = 2

};


// Enum  /Script/UMG.EWidgetSpace
enum class EWidgetSpace : uint8_t
{
    World                                          = 0,
    Screen                                         = 1,
    EWidgetSpace_MAX                               = 2

};


// Enum  /Script/UMG.EWidgetInteractionSource
enum class EWidgetInteractionSource : uint8_t
{
    World                                          = 0,
    Mouse                                          = 1,
    CenterScreen                                   = 2,
    Custom                                         = 3,
    EWidgetInteractionSource_MAX                   = 4

};


// Enum  /Script/CinematicCamera.ECameraFocusMethod
enum class ECameraFocusMethod : uint8_t
{
    None                                           = 0,
    Manual                                         = 1,
    Tracking                                       = 2,
    ECameraFocusMethod_MAX                         = 3

};


// Enum  /Script/AudioMixer.EFFTWindowType
enum class EFFTWindowType : uint8_t
{
    None                                           = 0,
    Hamming                                        = 1,
    Hann                                           = 2,
    Blackman                                       = 3,
    EFFTWindowType_MAX                             = 4

};


// Enum  /Script/AudioMixer.EFFTPeakInterpolationMethod
enum class EFFTPeakInterpolationMethod : uint8_t
{
    NearestNeighbor                                = 0,
    Linear                                         = 1,
    Quadratic                                      = 2,
    EFFTPeakInterpolationMethod_MAX                = 3

};


// Enum  /Script/AudioMixer.EFFTSize
enum class EFFTSize : uint8_t
{
    DefaultSize                                    = 0,
    Min                                            = 1,
    Small                                          = 2,
    Medium                                         = 3,
    Large                                          = 4,
    Max                                            = 5

};


// Enum  /Script/AudioMixer.ESubmixEffectDynamicsPeakMode
enum class ESubmixEffectDynamicsPeakMode : uint8_t
{
    MeanSquared                                    = 0,
    RootMeanSquared                                = 1,
    Peak                                           = 2,
    Count                                          = 3,
    ESubmixEffectDynamicsPeakMode_MAX              = 4

};


// Enum  /Script/AudioMixer.ESubmixEffectDynamicsProcessorType
enum class ESubmixEffectDynamicsProcessorType : uint8_t
{
    Compressor                                     = 0,
    Limiter                                        = 1,
    Expander                                       = 2,
    Gate                                           = 3,
    Count                                          = 4,
    ESubmixEffectDynamicsProcessorType_MAX         = 5

};


// Enum  /Script/AudioPlatformConfiguration.ESoundwaveSampleRateSettings
enum class ESoundwaveSampleRateSettings : uint8_t
{
    Max                                            = 0,
    High                                           = 1,
    Medium                                         = 2,
    Low                                            = 3,
    Min                                            = 4,
    MatchDevice                                    = 5

};


// Enum  /Script/AndroidRuntimeSettings.EAndroidGraphicsDebugger
enum class EAndroidGraphicsDebugger : uint8_t
{
    None                                           = 0,
    Mali                                           = 1,
    Adreno                                         = 2,
    EAndroidGraphicsDebugger_MAX                   = 3

};


// Enum  /Script/AndroidRuntimeSettings.EGoogleVRCaps
enum class EGoogleVRCaps : uint8_t
{
    Cardboard                                      = 0,
    Daydream33                                     = 1,
    Daydream63                                     = 2,
    Daydream66                                     = 3,
    EGoogleVRCaps_MAX                              = 4

};


// Enum  /Script/AndroidRuntimeSettings.EGoogleVRMode
enum class EGoogleVRMode : uint8_t
{
    Cardboard                                      = 0,
    Daydream                                       = 1,
    DaydreamAndCardboard                           = 2,
    EGoogleVRMode_MAX                              = 3

};


// Enum  /Script/AndroidRuntimeSettings.EAndroidAudio
enum class EAndroidAudio : uint8_t
{
    Default                                        = 0,
    OGG                                            = 1,
    ADPCM                                          = 2,
    EAndroidAudio_MAX                              = 3

};


// Enum  /Script/AndroidRuntimeSettings.EOculusMobileDevice
enum class EOculusMobileDevice : uint8_t
{
    GearGo                                         = 0,
    Quest                                          = 1,
    EOculusMobileDevice_MAX                        = 2

};


// Enum  /Script/AndroidRuntimeSettings.EAndroidInstallLocation
enum class EAndroidInstallLocation : uint8_t
{
    InternalOnly                                   = 0,
    PreferExternal                                 = 1,
    Auto                                           = 2,
    EAndroidInstallLocation_MAX                    = 3

};


// Enum  /Script/AndroidRuntimeSettings.EAndroidDepthBufferPreference
enum class EAndroidDepthBufferPreference : uint8_t
{
    Default                                        = 0,
    Bits16                                         = 16,
    Bits24                                         = 24,
    Bits32                                         = 32,
    EAndroidDepthBufferPreference_MAX              = 33

};


// Enum  /Script/AndroidRuntimeSettings.EAndroidScreenOrientation
enum class EAndroidScreenOrientation : uint8_t
{
    Portrait                                       = 0,
    ReversePortrait                                = 1,
    SensorPortrait                                 = 2,
    Landscape                                      = 3,
    ReverseLandscape                               = 4,
    SensorLandscape                                = 5,
    Sensor                                         = 6,
    FullSensor                                     = 7,
    EAndroidScreenOrientation_MAX                  = 8

};


// Enum  /Script/AndroidRuntimeSettings.EAndroidAntVerbosity
enum class EAndroidAntVerbosity : uint8_t
{
    Quiet                                          = 0,
    Normal                                         = 1,
    Verbose                                        = 2,
    EAndroidAntVerbosity_MAX                       = 3

};


// Enum  /Script/GameplayTags.EGameplayTagQueryExprType
enum class EGameplayTagQueryExprType : uint8_t
{
    Undefined                                      = 0,
    AnyTagsMatch                                   = 1,
    AllTagsMatch                                   = 2,
    NoTagsMatch                                    = 3,
    AnyExprMatch                                   = 4,
    AllExprMatch                                   = 5,
    NoExprMatch                                    = 6,
    EGameplayTagQueryExprType_MAX                  = 7

};


// Enum  /Script/GameplayTags.EGameplayContainerMatchType
enum class EGameplayContainerMatchType : uint8_t
{
    Any                                            = 0,
    All                                            = 1,
    EGameplayContainerMatchType_MAX                = 2

};


// Enum  /Script/GameplayTags.EGameplayTagMatchType
enum class EGameplayTagMatchType : uint8_t
{
    Explicit                                       = 0,
    IncludeParentTags                              = 1,
    EGameplayTagMatchType_MAX                      = 2

};


// Enum  /Script/GameplayTags.EGameplayTagSelectionType
enum class EGameplayTagSelectionType : uint8_t
{
    None                                           = 0,
    NonRestrictedOnly                              = 1,
    RestrictedOnly                                 = 2,
    All                                            = 3,
    EGameplayTagSelectionType_MAX                  = 4

};


// Enum  /Script/GameplayTags.EGameplayTagSourceType
enum class EGameplayTagSourceType : uint8_t
{
    Native                                         = 0,
    DefaultTagList                                 = 1,
    TagList                                        = 2,
    RestrictedTagList                              = 3,
    DataTable                                      = 4,
    Invalid                                        = 5,
    EGameplayTagSourceType_MAX                     = 6

};


// Enum  /Script/MeshDescription.EComputeNTBsOptions
enum class EComputeNTBsOptions : uint8_t
{
    None                                           = 0,
    Normals                                        = 1,
    Tangents                                       = 2,
    WeightedNTBs                                   = 4,
    EComputeNTBsOptions_MAX                        = 5

};


// Enum  /Script/EyeTracker.EEyeTrackerStatus
enum class EEyeTrackerStatus : uint8_t
{
    NotConnected                                   = 0,
    NotTracking                                    = 1,
    Tracking                                       = 2,
    EEyeTrackerStatus_MAX                          = 3

};


// Enum  /Script/MovieSceneCapture.EHDRCaptureGamut
enum class EHDRCaptureGamut : uint8_t
{
    HCGM_Rec709                                    = 0,
    HCGM_P3DCI                                     = 1,
    HCGM_Rec2020                                   = 2,
    HCGM_ACES                                      = 3,
    HCGM_ACEScg                                    = 4,
    HCGM_Linear                                    = 5,
    HCGM_MAX                                       = 6

};


// Enum  /Script/MovieSceneCapture.EMovieSceneCaptureProtocolState
enum class EMovieSceneCaptureProtocolState : uint8_t
{
    Idle                                           = 0,
    Initialized                                    = 1,
    Capturing                                      = 2,
    Finalizing                                     = 3,
    EMovieSceneCaptureProtocolState_MAX            = 4

};


// Enum  /Script/MoviePlayer.EMoviePlaybackType
enum class EMoviePlaybackType : uint8_t
{
    MT_Normal                                      = 0,
    MT_Looped                                      = 1,
    MT_LoadingLoop                                 = 2,
    MT_MAX                                         = 3

};


// Enum  /Script/Engine.EAlphaBlendOption
enum class EAlphaBlendOption : uint8_t
{
    Linear                                         = 0,
    Cubic                                          = 1,
    HermiteCubic                                   = 2,
    Sinusoidal                                     = 3,
    QuadraticInOut                                 = 4,
    CubicInOut                                     = 5,
    QuarticInOut                                   = 6,
    QuinticInOut                                   = 7,
    CircularIn                                     = 8,
    CircularOut                                    = 9,
    CircularInOut                                  = 10,
    ExpIn                                          = 11,
    ExpOut                                         = 12,
    ExpInOut                                       = 13,
    Custom                                         = 14,
    EAlphaBlendOption_MAX                          = 15

};


// Enum  /Script/Engine.EAnimGroupRole
enum class EAnimGroupRole : uint8_t
{
    CanBeLeader                                    = 0,
    AlwaysFollower                                 = 1,
    AlwaysLeader                                   = 2,
    TransitionLeader                               = 3,
    TransitionFollower                             = 4,
    EAnimGroupRole_MAX                             = 5

};


// Enum  /Script/Engine.AnimationKeyFormat
enum class AnimationKeyFormat : uint8_t
{
    AKF_ConstantKeyLerp                            = 0,
    AKF_VariableKeyLerp                            = 1,
    AKF_PerTrackCompression                        = 2,
    AKF_ACLDefault                                 = 3,
    AKF_ACLCustom                                  = 4,
    AKF_ACLSafe                                    = 5,
    AKF_MAX                                        = 6

};


// Enum  /Script/Engine.ERawCurveTrackTypes
enum class ERawCurveTrackTypes : uint8_t
{
    RCT_Float                                      = 0,
    RCT_Vector                                     = 1,
    RCT_Transform                                  = 2,
    RCT_MAX                                        = 3

};


// Enum  /Script/Engine.EAnimAssetCurveFlags
enum class EAnimAssetCurveFlags : uint8_t
{
    AACF_DriveMorphTarget_DEPRECATED               = 1,
    AACF_DriveAttribute_DEPRECATED                 = 2,
    AACF_Editable                                  = 4,
    AACF_DriveMaterial_DEPRECATED                  = 8,
    AACF_Metadata                                  = 16,
    AACF_DriveTrack                                = 32,
    AACF_Disabled                                  = 64,
    AACF_MAX                                       = 65

};


// Enum  /Script/Engine.AnimationCompressionFormat
enum class AnimationCompressionFormat : uint8_t
{
    ACF_None                                       = 0,
    ACF_Float96NoW                                 = 1,
    ACF_Fixed48NoW                                 = 2,
    ACF_IntervalFixed32NoW                         = 3,
    ACF_Fixed32NoW                                 = 4,
    ACF_Float32NoW                                 = 5,
    ACF_Identity                                   = 6,
    ACF_MAX                                        = 7

};


// Enum  /Script/Engine.EAdditiveBasePoseType
enum class EAdditiveBasePoseType : uint8_t
{
    ABPT_None                                      = 0,
    ABPT_RefPose                                   = 1,
    ABPT_AnimScaled                                = 2,
    ABPT_AnimFrame                                 = 3,
    ABPT_MAX                                       = 4

};


// Enum  /Script/Engine.ERootMotionMode
enum class ERootMotionMode : uint8_t
{
    NoRootMotionExtraction                         = 0,
    IgnoreRootMotion                               = 1,
    RootMotionFromEverything                       = 2,
    RootMotionFromMontagesOnly                     = 3,
    ERootMotionMode_MAX                            = 4

};


// Enum  /Script/Engine.ERootMotionRootLock
enum class ERootMotionRootLock : uint8_t
{
    RefPose                                        = 0,
    AnimFirstFrame                                 = 1,
    Zero                                           = 2,
    ERootMotionRootLock_MAX                        = 3

};


// Enum  /Script/Engine.EMontagePlayReturnType
enum class EMontagePlayReturnType : uint8_t
{
    MontageLength                                  = 0,
    Duration                                       = 1,
    EMontagePlayReturnType_MAX                     = 2

};


// Enum  /Script/Engine.EDrawDebugItemType
enum class EDrawDebugItemType : uint8_t
{
    DirectionalArrow                               = 0,
    Sphere                                         = 1,
    Line                                           = 2,
    OnScreenMessage                                = 3,
    CoordinateSystem                               = 4,
    EDrawDebugItemType_MAX                         = 5

};


// Enum  /Script/Engine.EAnimLinkMethod
enum class EAnimLinkMethod : uint8_t
{
    Absolute                                       = 0,
    Relative                                       = 1,
    Proportional                                   = 2,
    EAnimLinkMethod_MAX                            = 3

};


// Enum  /Script/Engine.EMontageSubStepResult
enum class EMontageSubStepResult : uint8_t
{
    Moved                                          = 0,
    NotMoved                                       = 1,
    InvalidSection                                 = 2,
    InvalidMontage                                 = 3,
    EMontageSubStepResult_MAX                      = 4

};


// Enum  /Script/Engine.EAnimNotifyEventType
enum class EAnimNotifyEventType : uint8_t
{
    Begin                                          = 0,
    End                                            = 1,
    EAnimNotifyEventType_MAX                       = 2

};


// Enum  /Script/Engine.EInertializationSpace
enum class EInertializationSpace : uint8_t
{
    Default                                        = 0,
    WorldSpace                                     = 1,
    WorldRotation                                  = 2,
    EInertializationSpace_MAX                      = 3

};


// Enum  /Script/Engine.EInertializationBoneState
enum class EInertializationBoneState : uint8_t
{
    Invalid                                        = 0,
    Valid                                          = 1,
    Excluded                                       = 2,
    EInertializationBoneState_MAX                  = 3

};


// Enum  /Script/Engine.EInertializationState
enum class EInertializationState : uint8_t
{
    Inactive                                       = 0,
    Pending                                        = 1,
    Active                                         = 2,
    EInertializationState_MAX                      = 3

};


// Enum  /Script/Engine.EEvaluatorMode
enum class EEvaluatorMode : uint8_t
{
    EM_Standard                                    = 0,
    EM_Freeze                                      = 1,
    EM_DelayedFreeze                               = 2,
    EM_MAX                                         = 3

};


// Enum  /Script/Engine.EEvaluatorDataSource
enum class EEvaluatorDataSource : uint8_t
{
    EDS_SourcePose                                 = 0,
    EDS_DestinationPose                            = 1,
    EDS_MAX                                        = 2

};


// Enum  /Script/Engine.ECopyType
enum class ECopyType : uint8_t
{
    MemCopy                                        = 0,
    BoolProperty                                   = 1,
    StructProperty                                 = 2,
    ObjectProperty                                 = 3,
    ECopyType_MAX                                  = 4

};


// Enum  /Script/Engine.EPostCopyOperation
enum class EPostCopyOperation : uint8_t
{
    None                                           = 0,
    LogicalNegateBool                              = 1,
    EPostCopyOperation_MAX                         = 2

};


// Enum  /Script/Engine.EPinHidingMode
enum class EPinHidingMode : uint8_t
{
    NeverAsPin                                     = 0,
    PinHiddenByDefault                             = 1,
    PinShownByDefault                              = 2,
    AlwaysAsPin                                    = 3,
    EPinHidingMode_MAX                             = 4

};


// Enum  /Script/Engine.AnimPhysCollisionType
enum class AnimPhysCollisionType : uint8_t
{
    CoM                                            = 0,
    CustomSphere                                   = 1,
    InnerSphere                                    = 2,
    OuterSphere                                    = 3,
    AnimPhysCollisionType_MAX                      = 4

};


// Enum  /Script/Engine.AnimPhysTwistAxis
enum class AnimPhysTwistAxis : uint8_t
{
    AxisX                                          = 0,
    AxisY                                          = 1,
    AxisZ                                          = 2,
    AnimPhysTwistAxis_MAX                          = 3

};


// Enum  /Script/Engine.BuildInDatabaseVisualFidelity
enum class BuildInDatabaseVisualFidelity : uint8_t
{
    Highest                                        = 0,
    Medium                                         = 1,
    Lowest                                         = 2,
    BuildInDatabaseVisualFidelity_MAX              = 3

};


// Enum  /Script/Engine.ETypeAdvanceAnim
enum class ETypeAdvanceAnim : uint8_t
{
    ETAA_Default                                   = 0,
    ETAA_Finished                                  = 1,
    ETAA_Looped                                    = 2,
    ETAA_MAX                                       = 3

};


// Enum  /Script/Engine.ETransitionLogicType
enum class ETransitionLogicType : uint8_t
{
    TLT_StandardBlend                              = 0,
    TLT_Inertialization                            = 1,
    TLT_Custom                                     = 2,
    TLT_MAX                                        = 3

};


// Enum  /Script/Engine.ETransitionBlendMode
enum class ETransitionBlendMode : uint8_t
{
    TBM_Linear                                     = 0,
    TBM_Cubic                                      = 1,
    TBM_MAX                                        = 2

};


// Enum  /Script/Engine.EComponentType
enum class EComponentType : uint8_t
{
    None                                           = 0,
    TranslationX                                   = 1,
    TranslationY                                   = 2,
    TranslationZ                                   = 3,
    RotationX                                      = 4,
    RotationY                                      = 5,
    RotationZ                                      = 6,
    Scale                                          = 7,
    ScaleX                                         = 8,
    ScaleY                                         = 9,
    ScaleZ                                         = 10,
    EComponentType_MAX                             = 11

};


// Enum  /Script/Engine.EAxisOption
enum class EAxisOption : uint8_t
{
    X                                              = 0,
    Y                                              = 1,
    Z                                              = 2,
    X_Neg                                          = 3,
    Y_Neg                                          = 4,
    Z_Neg                                          = 5,
    Custom                                         = 6,
    EAxisOption_MAX                                = 7

};


// Enum  /Script/Engine.EAnimInterpolationType
enum class EAnimInterpolationType : uint8_t
{
    Linear                                         = 0,
    Step                                           = 1,
    EAnimInterpolationType_MAX                     = 2

};


// Enum  /Script/Engine.ECurveBlendOption
enum class ECurveBlendOption : uint8_t
{
    MaxWeight                                      = 0,
    NormalizeByWeight                              = 1,
    BlendByWeight                                  = 2,
    UseBasePose                                    = 3,
    UseMaxValue                                    = 4,
    UseMinValue                                    = 5,
    ECurveBlendOption_MAX                          = 6

};


// Enum  /Script/Engine.EAdditiveAnimationType
enum class EAdditiveAnimationType : uint8_t
{
    AAT_None                                       = 0,
    AAT_LocalSpaceBase                             = 1,
    AAT_RotationOffsetMeshSpace                    = 2,
    AAT_MAX                                        = 3

};


// Enum  /Script/Engine.ENotifyFilterType
enum class ENotifyFilterType : uint8_t
{
    NoFiltering                                    = 0,
    LOD                                            = 1,
    ENotifyFilterType_MAX                          = 2

};


// Enum  /Script/Engine.EMontageNotifyTickType
enum class EMontageNotifyTickType : uint8_t
{
    Queued                                         = 0,
    BranchingPoint                                 = 1,
    EMontageNotifyTickType_MAX                     = 2

};


// Enum  /Script/Engine.EBoneRotationSource
enum class EBoneRotationSource : uint8_t
{
    BRS_KeepComponentSpaceRotation                 = 0,
    BRS_KeepLocalSpaceRotation                     = 1,
    BRS_CopyFromTarget                             = 2,
    BRS_MAX                                        = 3

};


// Enum  /Script/Engine.EBoneControlSpace
enum class EBoneControlSpace : uint8_t
{
    BCS_WorldSpace                                 = 0,
    BCS_ComponentSpace                             = 1,
    BCS_ParentBoneSpace                            = 2,
    BCS_BoneSpace                                  = 3,
    BCS_MAX                                        = 4

};


// Enum  /Script/Engine.EBoneAxis
enum class EBoneAxis : uint8_t
{
    BA_X                                           = 0,
    BA_Y                                           = 1,
    BA_Z                                           = 2,
    BA_MAX                                         = 3

};


// Enum  /Script/Engine.EPrimaryAssetCookRule
enum class EPrimaryAssetCookRule : uint8_t
{
    Unknown                                        = 0,
    NeverCook                                      = 1,
    DevelopmentCook                                = 2,
    DevelopmentAlwaysCook                          = 3,
    AlwaysCook                                     = 4,
    EPrimaryAssetCookRule_MAX                      = 5

};


// Enum  /Script/Engine.ETexCompressCompatible
enum class ETexCompressCompatible : uint8_t
{
    AG_TCC_DEFAULT                                 = 0,
    AG_TCC_ASTC_LOWER                              = 1,
    AG_TCC_ASTC_HIGHER                             = 2,
    AG_TCC_MAX                                     = 3

};


// Enum  /Script/Engine.EMeshDensity
enum class EMeshDensity : uint8_t
{
    AG_MD_BOX_COVERAGE                             = 0,
    AG_MD_SPHERE_RADIUS                            = 1,
    AG_MD_MAX                                      = 2

};


// Enum  /Script/Engine.EAttenuationShape
enum class EAttenuationShape : uint8_t
{
    Sphere                                         = 0,
    Capsule                                        = 1,
    Box                                            = 2,
    Cone                                           = 3,
    EAttenuationShape_MAX                          = 4

};


// Enum  /Script/Engine.EAttenuationDistanceModel
enum class EAttenuationDistanceModel : uint8_t
{
    Linear                                         = 0,
    Logarithmic                                    = 1,
    Inverse                                        = 2,
    LogReverse                                     = 3,
    NaturalSound                                   = 4,
    Custom                                         = 5,
    EAttenuationDistanceModel_MAX                  = 6

};


// Enum  /Script/Engine.EMonoChannelUpmixMethod
enum class EMonoChannelUpmixMethod : uint8_t
{
    Linear                                         = 0,
    EqualPower                                     = 1,
    FullVolume                                     = 2,
    EMonoChannelUpmixMethod_MAX                    = 3

};


// Enum  /Script/Engine.EPanningMethod
enum class EPanningMethod : uint8_t
{
    Linear                                         = 0,
    EqualPower                                     = 1,
    EPanningMethod_MAX                             = 2

};


// Enum  /Script/Engine.EVoiceSampleRate
enum class EVoiceSampleRate : uint32_t
{
    Low16000Hz                                     = 16000,
    Normal24000Hz                                  = 24000,
    EVoiceSampleRate_MAX                           = 24001

};


// Enum  /Script/Engine.ReverbPreset
enum class ReverbPreset : uint8_t
{
    REVERB_Default                                 = 0,
    REVERB_Bathroom                                = 1,
    REVERB_StoneRoom                               = 2,
    REVERB_Auditorium                              = 3,
    REVERB_ConcertHall                             = 4,
    REVERB_Cave                                    = 5,
    REVERB_Hallway                                 = 6,
    REVERB_StoneCorridor                           = 7,
    REVERB_Alley                                   = 8,
    REVERB_Forest                                  = 9,
    REVERB_City                                    = 10,
    REVERB_Mountains                               = 11,
    REVERB_Quarry                                  = 12,
    REVERB_Plain                                   = 13,
    REVERB_ParkingLot                              = 14,
    REVERB_SewerPipe                               = 15,
    REVERB_Underwater                              = 16,
    REVERB_SmallRoom                               = 17,
    REVERB_MediumRoom                              = 18,
    REVERB_LargeRoom                               = 19,
    REVERB_MediumHall                              = 20,
    REVERB_LargeHall                               = 21,
    REVERB_Plate                                   = 22,
    REVERB_MAX                                     = 23

};


// Enum  /Script/Engine.EBlendableLocation
enum class EBlendableLocation : uint8_t
{
    BL_AfterTonemapping                            = 0,
    BL_BeforeTonemapping                           = 1,
    BL_BeforeTranslucency                          = 2,
    BL_ReplacingTonemapper                         = 3,
    BL_SSRInput                                    = 4,
    BL_MAX                                         = 5

};


// Enum  /Script/Engine.ENotifyTriggerMode
enum class ENotifyTriggerMode : uint8_t
{
    AllAnimations                                  = 0,
    HighestWeightedAnimation                       = 1,
    None                                           = 2,
    ENotifyTriggerMode_MAX                         = 3

};


// Enum  /Script/Engine.EBlendSpaceAxis
enum class EBlendSpaceAxis : uint8_t
{
    BSA_None                                       = 0,
    BSA_X                                          = 1,
    BSA_Y                                          = 2,
    BSA_Max                                        = 3

};


// Enum  /Script/Engine.EBlueprintNativizationFlag
enum class EBlueprintNativizationFlag : uint8_t
{
    Disabled                                       = 0,
    Dependency                                     = 1,
    ExplicitlyEnabled                              = 2,
    EBlueprintNativizationFlag_MAX                 = 3

};


// Enum  /Script/Engine.EBlueprintCompileMode
enum class EBlueprintCompileMode : uint8_t
{
    Default                                        = 0,
    Development                                    = 1,
    FinalRelease                                   = 2,
    EBlueprintCompileMode_MAX                      = 3

};


// Enum  /Script/Engine.EBlueprintType
enum class EBlueprintType : uint8_t
{
    BPTYPE_Normal                                  = 0,
    BPTYPE_Const                                   = 1,
    BPTYPE_MacroLibrary                            = 2,
    BPTYPE_Interface                               = 3,
    BPTYPE_LevelScript                             = 4,
    BPTYPE_FunctionLibrary                         = 5,
    BPTYPE_MAX                                     = 6

};


// Enum  /Script/Engine.EBlueprintStatus
enum class EBlueprintStatus : uint8_t
{
    BS_Unknown                                     = 0,
    BS_Dirty                                       = 1,
    BS_Error                                       = 2,
    BS_UpToDate                                    = 3,
    BS_BeingCreated                                = 4,
    BS_UpToDateWithWarnings                        = 5,
    BS_MAX                                         = 6

};


// Enum  /Script/Engine.EBodyCollisionResponse
enum class EBodyCollisionResponse : uint8_t
{
    BodyCollision_Enabled                          = 0,
    BodyCollision_Disabled                         = 1,
    BodyCollision_MAX                              = 2

};


// Enum  /Script/Engine.EPhysicsType
enum class EPhysicsType : uint8_t
{
    PhysType_Default                               = 0,
    PhysType_Kinematic                             = 1,
    PhysType_Simulated                             = 2,
    PhysType_MAX                                   = 3

};


// Enum  /Script/Engine.ECollisionTraceFlag
enum class ECollisionTraceFlag : uint8_t
{
    CTF_UseDefault                                 = 0,
    CTF_UseSimpleAndComplex                        = 1,
    CTF_UseSimpleAsComplex                         = 2,
    CTF_UseComplexAsSimple                         = 3,
    CTF_MAX                                        = 4

};


// Enum  /Script/Engine.EBrushType
enum class EBrushType : uint8_t
{
    Brush_Default                                  = 0,
    Brush_Add                                      = 1,
    Brush_Subtract                                 = 2,
    Brush_MAX                                      = 3

};


// Enum  /Script/Engine.ECsgOper
enum class ECsgOper : uint8_t
{
    CSG_Active                                     = 0,
    CSG_Add                                        = 1,
    CSG_Subtract                                   = 2,
    CSG_Intersect                                  = 3,
    CSG_Deintersect                                = 4,
    CSG_None                                       = 5,
    CSG_MAX                                        = 6

};


// Enum  /Script/Engine.EInitialOscillatorOffset
enum class EInitialOscillatorOffset : uint8_t
{
    EOO_OffsetRandom                               = 0,
    EOO_OffsetZero                                 = 1,
    EOO_MAX                                        = 2

};


// Enum  /Script/Engine.EOscillatorWaveform
enum class EOscillatorWaveform : uint8_t
{
    SineWave                                       = 0,
    PerlinNoise                                    = 1,
    EOscillatorWaveform_MAX                        = 2

};


// Enum  /Script/Engine.ECameraAlphaBlendMode
enum class ECameraAlphaBlendMode : uint8_t
{
    CABM_Linear                                    = 0,
    CABM_Cubic                                     = 1,
    CABM_MAX                                       = 2

};


// Enum  /Script/Engine.ECameraProjectionMode
enum class ECameraProjectionMode : uint8_t
{
    Perspective                                    = 0,
    Orthographic                                   = 1,
    ECameraProjectionMode_MAX                      = 2

};


// Enum  /Script/Engine.ECloudStorageDelegate
enum class ECloudStorageDelegate : uint8_t
{
    CSD_KeyValueReadComplete                       = 0,
    CSD_KeyValueWriteComplete                      = 1,
    CSD_ValueChanged                               = 2,
    CSD_DocumentQueryComplete                      = 3,
    CSD_DocumentReadComplete                       = 4,
    CSD_DocumentWriteComplete                      = 5,
    CSD_DocumentConflictDetected                   = 6,
    CSD_MAX                                        = 7

};


// Enum  /Script/Engine.EAngularDriveMode
enum class EAngularDriveMode : uint8_t
{
    SLERP                                          = 0,
    TwistAndSwing                                  = 1,
    EAngularDriveMode_MAX                          = 2

};


// Enum  /Script/Engine.ELinearConstraintMotion
enum class ELinearConstraintMotion : uint8_t
{
    LCM_Free                                       = 0,
    LCM_Limited                                    = 1,
    LCM_Locked                                     = 2,
    LCM_MAX                                        = 3

};


// Enum  /Script/Engine.ECurveTableMode
enum class ECurveTableMode : uint8_t
{
    Empty                                          = 0,
    SimpleCurves                                   = 1,
    RichCurves                                     = 2,
    ECurveTableMode_MAX                            = 3

};


// Enum  /Script/Engine.EEvaluateCurveTableResult
enum class EEvaluateCurveTableResult : uint8_t
{
    RowFound                                       = 0,
    RowNotFound                                    = 1,
    EEvaluateCurveTableResult_MAX                  = 2

};


// Enum  /Script/Engine.EGrammaticalNumber
enum class EGrammaticalNumber : uint8_t
{
    Singular                                       = 0,
    Plural                                         = 1,
    EGrammaticalNumber_MAX                         = 2

};


// Enum  /Script/Engine.EGrammaticalGender
enum class EGrammaticalGender : uint8_t
{
    Neuter                                         = 0,
    Masculine                                      = 1,
    Feminine                                       = 2,
    Mixed                                          = 3,
    EGrammaticalGender_MAX                         = 4

};


// Enum  /Script/Engine.DistributionParamMode
enum class DistributionParamMode : uint8_t
{
    DPM_Normal                                     = 0,
    DPM_Abs                                        = 1,
    DPM_Direct                                     = 2,
    DPM_MAX                                        = 3

};


// Enum  /Script/Engine.EDistributionVectorMirrorFlags
enum class EDistributionVectorMirrorFlags : uint8_t
{
    EDVMF_Same                                     = 0,
    EDVMF_Different                                = 1,
    EDVMF_Mirror                                   = 2,
    EDVMF_MAX                                      = 3

};


// Enum  /Script/Engine.EDistributionVectorLockFlags
enum class EDistributionVectorLockFlags : uint8_t
{
    EDVLF_None                                     = 0,
    EDVLF_XY                                       = 1,
    EDVLF_XZ                                       = 2,
    EDVLF_YZ                                       = 3,
    EDVLF_XYZ                                      = 4,
    EDVLF_MAX                                      = 5

};


// Enum  /Script/Engine.ENodeEnabledState
enum class ENodeEnabledState : uint8_t
{
    Enabled                                        = 0,
    Disabled                                       = 1,
    DevelopmentOnly                                = 2,
    ENodeEnabledState_MAX                          = 3

};


// Enum  /Script/Engine.ENodeAdvancedPins
enum class ENodeAdvancedPins : uint8_t
{
    NoPins                                         = 0,
    Shown                                          = 1,
    Hidden                                         = 2,
    ENodeAdvancedPins_MAX                          = 3

};


// Enum  /Script/Engine.ENodeTitleType
enum class ENodeTitleType : uint8_t
{
    FullTitle                                      = 0,
    ListView                                       = 1,
    EditableTitle                                  = 2,
    MenuTitle                                      = 3,
    MAX_TitleTypes                                 = 4,
    ENodeTitleType_MAX                             = 5

};


// Enum  /Script/Engine.EPinContainerType
enum class EPinContainerType : uint8_t
{
    None                                           = 0,
    Array                                          = 1,
    Set                                            = 2,
    Map                                            = 3,
    EPinContainerType_MAX                          = 4

};


// Enum  /Script/Engine.EEdGraphPinDirection
enum class EEdGraphPinDirection : uint8_t
{
    EGPD_Input                                     = 0,
    EGPD_Output                                    = 1,
    EGPD_MAX                                       = 2

};


// Enum  /Script/Engine.EBlueprintPinStyleType
enum class EBlueprintPinStyleType : uint8_t
{
    BPST_Original                                  = 0,
    BPST_VariantA                                  = 1,
    BPST_MAX                                       = 2

};


// Enum  /Script/Engine.ECanCreateConnectionResponse
enum class ECanCreateConnectionResponse : uint8_t
{
    CONNECT_RESPONSE_MAKE                          = 0,
    CONNECT_RESPONSE_DISALLOW                      = 1,
    CONNECT_RESPONSE_BREAK_OTHERS_A                = 2,
    CONNECT_RESPONSE_BREAK_OTHERS_B                = 3,
    CONNECT_RESPONSE_BREAK_OTHERS_AB               = 4,
    CONNECT_RESPONSE_MAKE_WITH_CONVERSION_NODE     = 5,
    CONNECT_RESPONSE_MAX                           = 6

};


// Enum  /Script/Engine.EGraphType
enum class EGraphType : uint8_t
{
    GT_Function                                    = 0,
    GT_Ubergraph                                   = 1,
    GT_Macro                                       = 2,
    GT_Animation                                   = 3,
    GT_StateMachine                                = 4,
    GT_MAX                                         = 5

};


// Enum  /Script/Engine.EConsoleType
enum class EConsoleType : uint8_t
{
    Any                                            = 0,
    Mobile                                         = 1,
    MAX                                            = 2

};


// Enum  /Script/Engine.ETransitionType
enum class ETransitionType : uint8_t
{
    None                                           = 0,
    Paused                                         = 1,
    Loading                                        = 2,
    Saving                                         = 3,
    Connecting                                     = 4,
    Precaching                                     = 5,
    WaitingToConnect                               = 6,
    MAX                                            = 7

};


// Enum  /Script/Engine.EFullyLoadPackageType
enum class EFullyLoadPackageType : uint8_t
{
    FULLYLOAD_Map                                  = 0,
    FULLYLOAD_Game_PreLoadClass                    = 1,
    FULLYLOAD_Game_PostLoadClass                   = 2,
    FULLYLOAD_Always                               = 3,
    FULLYLOAD_Mutator                              = 4,
    FULLYLOAD_MAX                                  = 5

};


// Enum  /Script/Engine.EViewModeIndex
enum class EViewModeIndex : uint8_t
{
    VMI_BrushWireframe                             = 0,
    VMI_Wireframe                                  = 1,
    VMI_Unlit                                      = 2,
    VMI_Lit                                        = 3,
    VMI_Lit_DetailLighting                         = 4,
    VMI_LightingOnly                               = 5,
    VMI_LightComplexity                            = 6,
    VMI_ShaderComplexity                           = 8,
    VMI_LightmapDensity                            = 9,
    VMI_LitLightmapDensity                         = 10,
    VMI_ReflectionOverride                         = 11,
    VMI_VisualizeBuffer                            = 12,
    VMI_StationaryLightOverlap                     = 14,
    VMI_CollisionPawn                              = 15,
    VMI_CollisionVisibility                        = 16,
    VMI_LODColoration                              = 18,
    VMI_QuadOverdraw                               = 19,
    VMI_PrimitiveDistanceAccuracy                  = 20,
    VMI_MeshUVDensityAccuracy                      = 21,
    VMI_ShaderComplexityWithQuadOverdraw           = 22,
    VMI_HLODColoration                             = 23,
    VMI_GroupLODColoration                         = 24,
    VMI_MaterialTextureScaleAccuracy               = 25,
    VMI_RequiredTextureResolution                  = 26,
    VMI_PathTracing                                = 27,
    VMI_RayTracingDebug                            = 28,
    VMI_DrawCall                                   = 29,
    VMI_Max                                        = 30,
    VMI_Unknown                                    = 255

};


// Enum  /Script/Engine.EDemoPlayFailure
enum class EDemoPlayFailure : uint8_t
{
    Generic                                        = 0,
    DemoNotFound                                   = 1,
    Corrupt                                        = 2,
    InvalidVersion                                 = 3,
    InitBase                                       = 4,
    GameSpecificHeader                             = 5,
    ReplayStreamerInternal                         = 6,
    LoadMap                                        = 7,
    Serialization                                  = 8,
    EDemoPlayFailure_MAX                           = 9

};


// Enum  /Script/Engine.ENetworkLagState
enum class ENetworkLagState : uint8_t
{
    NotLagging                                     = 0,
    Lagging                                        = 1,
    ENetworkLagState_MAX                           = 2

};


// Enum  /Script/Engine.EMouseCaptureMode
enum class EMouseCaptureMode : uint8_t
{
    NoCapture                                      = 0,
    CapturePermanently                             = 1,
    CapturePermanently_IncludingInitialMouseDown   = 2,
    CaptureDuringMouseDown                         = 3,
    CaptureDuringRightMouseDown                    = 4,
    EMouseCaptureMode_MAX                          = 5

};


// Enum  /Script/Engine.ECustomTimeStepSynchronizationState
enum class ECustomTimeStepSynchronizationState : uint8_t
{
    Closed                                         = 0,
    Error                                          = 1,
    Synchronized                                   = 2,
    Synchronizing                                  = 3,
    ECustomTimeStepSynchronizationState_MAX        = 4

};


// Enum  /Script/Engine.EMeshBufferAccess
enum class EMeshBufferAccess : uint8_t
{
    Default                                        = 0,
    ForceCPUAndGPU                                 = 1,
    EMeshBufferAccess_MAX                          = 2

};


// Enum  /Script/Engine.EConstraintFrame
enum class EConstraintFrame : uint8_t
{
    Frame1                                         = 0,
    Frame2                                         = 1,
    EConstraintFrame_MAX                           = 2

};


// Enum  /Script/Engine.EAngularConstraintMotion
enum class EAngularConstraintMotion : uint8_t
{
    ACM_Free                                       = 0,
    ACM_Limited                                    = 1,
    ACM_Locked                                     = 2,
    ACM_MAX                                        = 3

};


// Enum  /Script/Engine.EComponentSocketType
enum class EComponentSocketType : uint8_t
{
    Invalid                                        = 0,
    Bone                                           = 1,
    Socket                                         = 2,
    EComponentSocketType_MAX                       = 3

};


// Enum  /Script/Engine.EUpdateRateShiftBucket
enum class EUpdateRateShiftBucket : uint8_t
{
    ShiftBucket0                                   = 0,
    ShiftBucket1                                   = 1,
    ShiftBucket2                                   = 2,
    ShiftBucket3                                   = 3,
    ShiftBucket4                                   = 4,
    ShiftBucket5                                   = 5,
    ShiftBucketMax                                 = 6,
    EUpdateRateShiftBucket_MAX                     = 7

};


// Enum  /Script/Engine.EShadowMapFlags
enum class EShadowMapFlags : uint8_t
{
    SMF_None                                       = 0,
    SMF_Streamed                                   = 1,
    SMF_MAX                                        = 2

};


// Enum  /Script/Engine.ELightMapPaddingType
enum class ELightMapPaddingType : uint8_t
{
    LMPT_NormalPadding                             = 0,
    LMPT_PrePadding                                = 1,
    LMPT_NoPadding                                 = 2,
    LMPT_MAX                                       = 3

};


// Enum  /Script/Engine.ETimelineSigType
enum class ETimelineSigType : uint8_t
{
    ETS_EventSignature                             = 0,
    ETS_FloatSignature                             = 1,
    ETS_VectorSignature                            = 2,
    ETS_LinearColorSignature                       = 3,
    ETS_InvalidSignature                           = 4,
    ETS_MAX                                        = 5

};


// Enum  /Script/Engine.EFilterInterpolationType
enum class EFilterInterpolationType : uint8_t
{
    BSIT_Average                                   = 0,
    BSIT_Linear                                    = 1,
    BSIT_Cubic                                     = 2,
    BSIT_MAX                                       = 3

};


// Enum  /Script/Engine.EOverlapFilterOption
enum class EOverlapFilterOption : uint8_t
{
    OverlapFilter_All                              = 0,
    OverlapFilter_DynamicOnly                      = 1,
    OverlapFilter_StaticOnly                       = 2,
    OverlapFilter_MAX                              = 3

};


// Enum  /Script/Engine.EUseDomainType
enum class EUseDomainType : uint8_t
{
    UseParentDomain                                = 0,
    UseNeutralDomain                               = 1,
    UseSpawnedDomain                               = 2,
    EUseDomainType_MAX                             = 3

};


// Enum  /Script/Engine.ENetworkSmoothingMode
enum class ENetworkSmoothingMode : uint8_t
{
    Disabled                                       = 0,
    Linear                                         = 1,
    Exponential                                    = 2,
    Replay                                         = 3,
    ENetworkSmoothingMode_MAX                      = 4

};


// Enum  /Script/Engine.ELightingBuildQuality
enum class ELightingBuildQuality : uint8_t
{
    Quality_Preview                                = 0,
    Quality_Medium                                 = 1,
    Quality_High                                   = 2,
    Quality_Production                             = 3,
    Quality_MAX                                    = 4

};


// Enum  /Script/Engine.EMaterialShadingRate
enum class EMaterialShadingRate : uint8_t
{
    MSR_1x1                                        = 0,
    MSR_2x1                                        = 1,
    MSR_1x2                                        = 2,
    MSR_2x2                                        = 3,
    MSR_4x2                                        = 4,
    MSR_2x4                                        = 5,
    MSR_4x4                                        = 6,
    MSR_Count                                      = 7,
    MSR_MAX                                        = 8

};


// Enum  /Script/Engine.EMaterialStencilCompare
enum class EMaterialStencilCompare : uint8_t
{
    MSC_Less                                       = 0,
    MSC_LessEqual                                  = 1,
    MSC_Greater                                    = 2,
    MSC_GreaterEqual                               = 3,
    MSC_Equal                                      = 4,
    MSC_NotEqual                                   = 5,
    MSC_Never                                      = 6,
    MSC_Always                                     = 7,
    MSC_Count                                      = 8,
    MSC_MAX                                        = 9

};


// Enum  /Script/Engine.EMaterialSamplerType
enum class EMaterialSamplerType : uint8_t
{
    SAMPLERTYPE_Color                              = 0,
    SAMPLERTYPE_Grayscale                          = 1,
    SAMPLERTYPE_Alpha                              = 2,
    SAMPLERTYPE_Normal                             = 3,
    SAMPLERTYPE_Masks                              = 4,
    SAMPLERTYPE_DistanceFieldFont                  = 5,
    SAMPLERTYPE_LinearColor                        = 6,
    SAMPLERTYPE_LinearGrayscale                    = 7,
    SAMPLERTYPE_Data                               = 8,
    SAMPLERTYPE_External                           = 9,
    SAMPLERTYPE_VirtualColor                       = 10,
    SAMPLERTYPE_VirtualGrayscale                   = 11,
    SAMPLERTYPE_VirtualAlpha                       = 12,
    SAMPLERTYPE_VirtualNormal                      = 13,
    SAMPLERTYPE_VirtualMasks                       = 14,
    SAMPLERTYPE_VirtualLinearColor                 = 15,
    SAMPLERTYPE_VirtualLinearGrayscale             = 16,
    SAMPLERTYPE_MAX                                = 17

};


// Enum  /Script/Engine.EMaterialIBLQualityLevel
enum class EMaterialIBLQualityLevel : uint8_t
{
    IBLQL_Low                                      = 0,
    IBLQL_Medium                                   = 1,
    IBLQL_High                                     = 2,
    IBLQL_Ultra                                    = 3,
    IBLQL_MAX                                      = 4

};


// Enum  /Script/Engine.EMaterialTessellationMode
enum class EMaterialTessellationMode : uint8_t
{
    MTM_NoTessellation                             = 0,
    MTM_FlatTessellation                           = 1,
    MTM_PNTriangles                                = 2,
    MTM_MAX                                        = 3

};


// Enum  /Script/Engine.EMaterialShadingModel
enum class EMaterialShadingModel : uint8_t
{
    MSM_Unlit                                      = 0,
    MSM_DefaultLit                                 = 1,
    MSM_Subsurface                                 = 2,
    MSM_PreintegratedSkin                          = 3,
    MSM_ClearCoat                                  = 4,
    MSM_SubsurfaceProfile                          = 5,
    MSM_TwoSidedFoliage                            = 6,
    MSM_Hair                                       = 7,
    MSM_Cloth                                      = 8,
    MSM_Eye                                        = 9,
    MSM_IdeaLitS3                                  = 10,
    MSM_IdeaLitS2                                  = 11,
    MSM_IdeaLitS1                                  = 12,
    MSM_IdeaLitS1D                                 = 13,
    MSM_NUM                                        = 14,
    MSM_FromMaterialExpression                     = 15,
    MSM_MAX                                        = 16

};


// Enum  /Script/Engine.EParticleCollisionMode
enum class EParticleCollisionMode : uint8_t
{
    SceneDepth                                     = 0,
    DistanceField                                  = 1,
    EParticleCollisionMode_MAX                     = 2

};


// Enum  /Script/Engine.ETrailWidthMode
enum class ETrailWidthMode : uint8_t
{
    ETrailWidthMode_FromCentre                     = 0,
    ETrailWidthMode_FromFirst                      = 1,
    ETrailWidthMode_FromSecond                     = 2,
    ETrailWidthMode_MAX                            = 3

};


// Enum  /Script/Engine.EGBufferFormat
enum class EGBufferFormat : uint8_t
{
    Force8BitsPerChannel                           = 0,
    Default                                        = 1,
    HighPrecisionNormals                           = 3,
    Force16BitsPerChannel                          = 5,
    EGBufferFormat_MAX                             = 6

};


// Enum  /Script/Engine.ESceneCaptureCompositeMode
enum class ESceneCaptureCompositeMode : uint8_t
{
    SCCM_Overwrite                                 = 0,
    SCCM_Additive                                  = 1,
    SCCM_Composite                                 = 2,
    SCCM_MAX                                       = 3

};


// Enum  /Script/Engine.ESceneCaptureSource
enum class ESceneCaptureSource : uint8_t
{
    SCS_SceneColorHDR                              = 0,
    SCS_SceneColorHDRNoAlpha                       = 1,
    SCS_FinalColorLDR                              = 2,
    SCS_SceneColorSceneDepth                       = 3,
    SCS_SceneDepth                                 = 4,
    SCS_DeviceDepth                                = 5,
    SCS_Normal                                     = 6,
    SCS_BaseColor                                  = 7,
    SCS_FinalColorHDR                              = 8,
    SCS_FinalColorLDRAlpha                         = 9,
    SCS_MAX                                        = 10

};


// Enum  /Script/Engine.ETranslucentSortPolicy
enum class ETranslucentSortPolicy : uint8_t
{
    SortByDistance                                 = 0,
    SortByProjectedZ                               = 1,
    SortAlongAxis                                  = 2,
    ETranslucentSortPolicy_MAX                     = 3

};


// Enum  /Script/Engine.ERefractionMode
enum class ERefractionMode : uint8_t
{
    RM_IndexOfRefraction                           = 0,
    RM_PixelNormalOffset                           = 1,
    RM_MAX                                         = 2

};


// Enum  /Script/Engine.ETranslucencyLightingMode
enum class ETranslucencyLightingMode : uint8_t
{
    TLM_VolumetricNonDirectional                   = 0,
    TLM_VolumetricDirectional                      = 1,
    TLM_VolumetricPerVertexNonDirectional          = 2,
    TLM_VolumetricPerVertexDirectional             = 3,
    TLM_Surface                                    = 4,
    TLM_SurfacePerPixelLighting                    = 5,
    TLM_MAX                                        = 6

};


// Enum  /Script/Engine.ESamplerSourceMode
enum class ESamplerSourceMode : uint8_t
{
    SSM_FromTextureAsset                           = 0,
    SSM_Wrap_WorldGroupSettings                    = 1,
    SSM_Clamp_WorldGroupSettings                   = 2,
    SSM_MAX                                        = 3

};


// Enum  /Script/Engine.EBlendMode
enum class EBlendMode : uint8_t
{
    BLEND_Opaque                                   = 0,
    BLEND_Masked                                   = 1,
    BLEND_Translucent                              = 2,
    BLEND_Additive                                 = 3,
    BLEND_Modulate                                 = 4,
    BLEND_AlphaComposite                           = 5,
    BLEND_AlphaHoldout                             = 6,
    BLEND_MAX                                      = 7

};


// Enum  /Script/Engine.EOcclusionCombineMode
enum class EOcclusionCombineMode : uint8_t
{
    OCM_Minimum                                    = 0,
    OCM_Multiply                                   = 1,
    OCM_MAX                                        = 2

};


// Enum  /Script/Engine.EAspectRatioAxisConstraint
enum class EAspectRatioAxisConstraint : uint8_t
{
    AspectRatio_MaintainYFOV                       = 0,
    AspectRatio_MaintainXFOV                       = 1,
    AspectRatio_MajorAxisFOV                       = 2,
    AspectRatio_MAX                                = 3

};


// Enum  /Script/Engine.EExtraMaterialFlags
enum class EExtraMaterialFlags : uint8_t
{
    DisableWriteStencil                            = 0,
    WriteMaskedStencil_Group1                      = 1,
    FillHide_MarkVisibleStencil                    = 2,
    FillHide_ReplaceStencil                        = 3,
    FillAll_ReplaceStencil                         = 4,
    FillVisible                                    = 5,
    DepthEqual                                     = 6,
    DepthGreater                                   = 7,
    ForceWriteStencil                              = 8,
    LineAll                                        = 9,
    LineVisible                                    = 10,
    LineHide_MarkVisibleStencil                    = 11,
    LineHide_ReplaceStencil                        = 12,
    Enemy_Mask                                     = 13,
    Enemy_Test                                     = 14,
    Mark_Hide                                      = 15,
    Better_Fill_Visible                            = 16,
    Better_Fill_Visible_Only                       = 17,
    Better_Fill_Hide                               = 18,
    Better_Fill_Hide_Only                          = 19,
    Better_Fill_All                                = 20,
    Better_Mark_Visible                            = 21,
    Better_Mark_Hide                               = 22,
    Better_Mark_All                                = 23,
    Better_Line_Visible                            = 24,
    Better_Line_Visible_Combine                    = 25,
    Better_Line_Hide                               = 26,
    Better_Line_All                                = 27,
    Better_Line_All_Combine                        = 28,
    Better_Enemy_Test                              = 29,
    Better_Fill_Hide_Transparent                   = 30,
    Better_Enemy_Test_DepthTest_On                 = 31,
    Num                                            = 32,
    EExtraMaterialFlags_MAX                        = 33

};


// Enum  /Script/Engine.EExtraRenderPassFlags
enum class EExtraRenderPassFlags : uint8_t
{
    AfterTransparent_BeforeMarkPass                = 0,
    AfterTransparent_MarkVisiblePass               = 1,
    AfterTransparent_OutLinePass                   = 2,
    AfterTransParent_LastPass                      = 3,
    BeforeTransparent_BeforeMarkPass               = 4,
    BeforeTransparent_MarkVisiblePass              = 5,
    BeforeTransparent_OutLinePass                  = 6,
    BeforeTransParent_LastPass                     = 7,
    MainPass                                       = 8,
    SkipMainPass                                   = 9,
    __MAX_CONFIGURABLE_RELEVANCE_FLAG              = 10,
    __MESH_FLAG_BEGIN                              = 16,
    Front                                          = 16,
    Front                                          = 17,
    Back                                           = 18,
    Back                                           = 19,
    __MAX_CONFIGURABLE_FLAG                        = 20,
    Num                                            = 32,
    EExtraRenderPassFlags_MAX                      = 33

};


// Enum  /Script/Engine.EExtraRenderPassConfigFlags
enum class EExtraRenderPassConfigFlags : uint8_t
{
    Front                                          = 0,
    Front                                          = 1,
    Back                                           = 2,
    Back                                           = 3,
    EExtraRenderPassConfigFlags_MAX                = 4

};


// Enum  /Script/Engine.EFontCacheType
enum class EFontCacheType : uint8_t
{
    Offline                                        = 0,
    Runtime                                        = 1,
    EFontCacheType_MAX                             = 2

};


// Enum  /Script/Engine.EFontImportCharacterSet
enum class EFontImportCharacterSet : uint8_t
{
    FontICS_Default                                = 0,
    FontICS_Ansi                                   = 1,
    FontICS_Symbol                                 = 2,
    FontICS_MAX                                    = 3

};


// Enum  /Script/Engine.EStandbyType
enum class EStandbyType : uint8_t
{
    STDBY_Rx                                       = 0,
    STDBY_Tx                                       = 1,
    STDBY_BadPing                                  = 2,
    STDBY_MAX                                      = 3

};


// Enum  /Script/Engine.ESuggestProjVelocityTraceOption
enum class ESuggestProjVelocityTraceOption : uint8_t
{
    DoNotTrace                                     = 0,
    TraceFullPath                                  = 1,
    OnlyTraceWhileAscending                        = 2,
    ESuggestProjVelocityTraceOption_MAX            = 3

};


// Enum  /Script/Engine.EWindowMode
enum class EWindowMode : uint8_t
{
    Fullscreen                                     = 0,
    WindowedFullscreen                             = 1,
    Windowed                                       = 2,
    EWindowMode_MAX                                = 3

};


// Enum  /Script/Engine.EImportanceWeight
enum class EImportanceWeight : uint8_t
{
    Luminance                                      = 0,
    Red                                            = 1,
    Green                                          = 2,
    Blue                                           = 3,
    Alpha                                          = 4,
    EImportanceWeight_MAX                          = 5

};


// Enum  /Script/Engine.EAdManagerDelegate
enum class EAdManagerDelegate : uint8_t
{
    AMD_ClickedBanner                              = 0,
    AMD_UserClosedAd                               = 1,
    AMD_MAX                                        = 2

};


// Enum  /Script/Engine.EAnimAlphaInputType
enum class EAnimAlphaInputType : uint8_t
{
    Float                                          = 0,
    Bool                                           = 1,
    Curve                                          = 2,
    EAnimAlphaInputType_MAX                        = 3

};


// Enum  /Script/Engine.ETrackActiveCondition
enum class ETrackActiveCondition : uint8_t
{
    ETAC_Always                                    = 0,
    ETAC_GoreEnabled                               = 1,
    ETAC_GoreDisabled                              = 2,
    ETAC_MAX                                       = 3

};


// Enum  /Script/Engine.EInterpTrackMoveRotMode
enum class EInterpTrackMoveRotMode : uint8_t
{
    IMR_Keyframed                                  = 0,
    IMR_LookAtGroup                                = 1,
    IMR_Ignore                                     = 2,
    IMR_MAX                                        = 3

};


// Enum  /Script/Engine.EInterpMoveAxis
enum class EInterpMoveAxis : uint8_t
{
    AXIS_TranslationX                              = 0,
    AXIS_TranslationY                              = 1,
    AXIS_TranslationZ                              = 2,
    AXIS_RotationX                                 = 3,
    AXIS_RotationY                                 = 4,
    AXIS_RotationZ                                 = 5,
    AXIS_MAX                                       = 6

};


// Enum  /Script/Engine.ETrackToggleAction
enum class ETrackToggleAction : uint8_t
{
    ETTA_Off                                       = 0,
    ETTA_On                                        = 1,
    ETTA_Toggle                                    = 2,
    ETTA_Trigger                                   = 3,
    ETTA_MAX                                       = 4

};


// Enum  /Script/Engine.EVisibilityTrackCondition
enum class EVisibilityTrackCondition : uint8_t
{
    EVTC_Always                                    = 0,
    EVTC_GoreEnabled                               = 1,
    EVTC_GoreDisabled                              = 2,
    EVTC_MAX                                       = 3

};


// Enum  /Script/Engine.EVisibilityTrackAction
enum class EVisibilityTrackAction : uint8_t
{
    EVTA_Hide                                      = 0,
    EVTA_Show                                      = 1,
    EVTA_Toggle                                    = 2,
    EVTA_MAX                                       = 3

};


// Enum  /Script/Engine.ESlateGesture
enum class ESlateGesture : uint8_t
{
    None                                           = 0,
    Scroll                                         = 1,
    Magnify                                        = 2,
    Swipe                                          = 3,
    Rotate                                         = 4,
    LongPress                                      = 5,
    ESlateGesture_MAX                              = 6

};


// Enum  /Script/Engine.ELerpInterpolationMode
enum class ELerpInterpolationMode : uint8_t
{
    QuatInterp                                     = 0,
    EulerInterp                                    = 1,
    DualQuatInterp                                 = 2,
    ELerpInterpolationMode_MAX                     = 3

};


// Enum  /Script/Engine.EEasingFunc
enum class EEasingFunc : uint8_t
{
    Linear                                         = 0,
    Step                                           = 1,
    SinusoidalIn                                   = 2,
    SinusoidalOut                                  = 3,
    SinusoidalInOut                                = 4,
    EaseIn                                         = 5,
    EaseOut                                        = 6,
    EaseInOut                                      = 7,
    ExpoIn                                         = 8,
    ExpoOut                                        = 9,
    ExpoInOut                                      = 10,
    CircularIn                                     = 11,
    CircularOut                                    = 12,
    CircularInOut                                  = 13,
    EEasingFunc_MAX                                = 14

};


// Enum  /Script/Engine.ERoundingMode
enum class ERoundingMode : uint8_t
{
    HalfToEven                                     = 0,
    HalfFromZero                                   = 1,
    HalfToZero                                     = 2,
    FromZero                                       = 3,
    ToZero                                         = 4,
    ToNegativeInfinity                             = 5,
    ToPositiveInfinity                             = 6,
    ERoundingMode_MAX                              = 7

};


// Enum  /Script/Engine.ELevelBoundsCalculateType
enum class ELevelBoundsCalculateType : uint8_t
{
    NonVolume                                      = 1,
    ForceVolume                                    = 2,
    IncludeVolumeIfEmpty                           = 3,
    ELevelBoundsCalculateType_MAX                  = 4

};


// Enum  /Script/Engine.EStreamingVolumeUsage
enum class EStreamingVolumeUsage : uint8_t
{
    SVB_Loading                                    = 0,
    SVB_LoadingAndVisibility                       = 1,
    SVB_VisibilityBlockingOnLoad                   = 2,
    SVB_BlockingOnLoad                             = 3,
    SVB_LoadingNotVisible                          = 4,
    SVB_MAX                                        = 5

};


// Enum  /Script/Engine.EMaterialDecalResponse
enum class EMaterialDecalResponse : uint8_t
{
    MDR_None                                       = 0,
    MDR_ColorNormalRoughness                       = 1,
    MDR_Color                                      = 2,
    MDR_ColorNormal                                = 3,
    MDR_ColorRoughness                             = 4,
    MDR_Normal                                     = 5,
    MDR_NormalRoughness                            = 6,
    MDR_Roughness                                  = 7,
    MDR_MAX                                        = 8

};


// Enum  /Script/Engine.EDecalBlendMode
enum class EDecalBlendMode : uint8_t
{
    DBM_Translucent                                = 0,
    DBM_Stain                                      = 1,
    DBM_Normal                                     = 2,
    DBM_Emissive                                   = 3,
    DBM_DBuffer_ColorNormalRoughness               = 4,
    DBM_DBuffer_Color                              = 5,
    DBM_DBuffer_ColorNormal                        = 6,
    DBM_DBuffer_ColorRoughness                     = 7,
    DBM_DBuffer_Normal                             = 8,
    DBM_DBuffer_NormalRoughness                    = 9,
    DBM_DBuffer_Roughness                          = 10,
    DBM_DBuffer_Emissive                           = 11,
    DBM_DBuffer_AlphaComposite                     = 12,
    DBM_DBuffer_EmissiveAlphaComposite             = 13,
    DBM_Volumetric_DistanceFunction                = 14,
    DBM_AlphaComposite                             = 15,
    DBM_AmbientOcclusion                           = 16,
    DBM_MAX                                        = 17

};


// Enum  /Script/Engine.ETextureColorChannel
enum class ETextureColorChannel : uint8_t
{
    TCC_Red                                        = 0,
    TCC_Green                                      = 1,
    TCC_Blue                                       = 2,
    TCC_Alpha                                      = 3,
    TCC_MAX                                        = 4

};


// Enum  /Script/Engine.EMaterialAttributeBlend
enum class EMaterialAttributeBlend : uint8_t
{
    Blend                                          = 0,
    UseA                                           = 1,
    UseB                                           = 2,
    EMaterialAttributeBlend_MAX                    = 3

};


// Enum  /Script/Engine.EChannelMaskParameterColor
enum class EChannelMaskParameterColor : uint8_t
{
    Red                                            = 0,
    Green                                          = 1,
    Blue                                           = 2,
    Alpha                                          = 3,
    EChannelMaskParameterColor_MAX                 = 4

};


// Enum  /Script/Engine.EClampMode
enum class EClampMode : uint8_t
{
    CMODE_Clamp                                    = 0,
    CMODE_ClampMin                                 = 1,
    CMODE_ClampMax                                 = 2,
    CMODE_MAX                                      = 3

};


// Enum  /Script/Engine.ECustomMaterialOutputType
enum class ECustomMaterialOutputType : uint8_t
{
    CMOT_Float1                                    = 0,
    CMOT_Float2                                    = 1,
    CMOT_Float3                                    = 2,
    CMOT_Float4                                    = 3,
    CMOT_MAX                                       = 4

};


// Enum  /Script/Engine.EDepthOfFieldFunctionValue
enum class EDepthOfFieldFunctionValue : uint8_t
{
    TDOF_NearAndFarMask                            = 0,
    TDOF_NearMask                                  = 1,
    TDOF_FarMask                                   = 2,
    TDOF_CircleOfConfusionRadius                   = 3,
    TDOF_MAX                                       = 4

};


// Enum  /Script/Engine.EFunctionInputType
enum class EFunctionInputType : uint8_t
{
    FunctionInput_Scalar                           = 0,
    FunctionInput_Vector2                          = 1,
    FunctionInput_Vector3                          = 2,
    FunctionInput_Vector4                          = 3,
    FunctionInput_Texture2D                        = 4,
    FunctionInput_TextureCube                      = 5,
    FunctionInput_VolumeTexture                    = 6,
    FunctionInput_StaticBool                       = 7,
    FunctionInput_MaterialAttributes               = 8,
    FunctionInput_TextureExternal                  = 9,
    FunctionInput_Texture2DArray                   = 10,
    FunctionInput_MAX                              = 11

};


// Enum  /Script/Engine.ENoiseFunction
enum class ENoiseFunction : uint8_t
{
    NOISEFUNCTION_SimplexTex                       = 0,
    NOISEFUNCTION_GradientTex                      = 1,
    NOISEFUNCTION_GradientTex3D                    = 2,
    NOISEFUNCTION_GradientALU                      = 3,
    NOISEFUNCTION_ValueALU                         = 4,
    NOISEFUNCTION_VoronoiALU                       = 5,
    NOISEFUNCTION_MAX                              = 6

};


// Enum  /Script/Engine.EMaterialSceneAttributeInputMode
enum class EMaterialSceneAttributeInputMode : uint8_t
{
    Coordinates                                    = 0,
    OffsetFraction                                 = 1,
    EMaterialSceneAttributeInputMode_MAX           = 2

};


// Enum  /Script/Engine.ESpeedTreeLODType
enum class ESpeedTreeLODType : uint8_t
{
    STLOD_Pop                                      = 0,
    STLOD_Smooth                                   = 1,
    STLOD_MAX                                      = 2

};


// Enum  /Script/Engine.ESpeedTreeWindType
enum class ESpeedTreeWindType : uint8_t
{
    STW_None                                       = 0,
    STW_Fastest                                    = 1,
    STW_Fast                                       = 2,
    STW_Better                                     = 3,
    STW_Best                                       = 4,
    STW_Palm                                       = 5,
    STW_BestPlus                                   = 6,
    STW_MAX                                        = 7

};


// Enum  /Script/Engine.ESpeedTreeGeometryType
enum class ESpeedTreeGeometryType : uint8_t
{
    STG_Branch                                     = 0,
    STG_Frond                                      = 1,
    STG_Leaf                                       = 2,
    STG_FacingLeaf                                 = 3,
    STG_Billboard                                  = 4,
    STG_MAX                                        = 5

};


// Enum  /Script/Engine.EMaterialExposedTextureProperty
enum class EMaterialExposedTextureProperty : uint8_t
{
    TMTM_TextureSize                               = 0,
    TMTM_TexelSize                                 = 1,
    TMTM_MAX                                       = 2

};


// Enum  /Script/Engine.ETextureMipValueMode
enum class ETextureMipValueMode : uint8_t
{
    TMVM_None                                      = 0,
    TMVM_MipLevel                                  = 1,
    TMVM_MipBias                                   = 2,
    TMVM_Derivative                                = 3,
    TMVM_MAX                                       = 4

};


// Enum  /Script/Engine.EMaterialVectorCoordTransform
enum class EMaterialVectorCoordTransform : uint8_t
{
    TRANSFORM_Tangent                              = 0,
    TRANSFORM_Local                                = 1,
    TRANSFORM_World                                = 2,
    TRANSFORM_View                                 = 3,
    TRANSFORM_Camera                               = 4,
    TRANSFORM_ParticleWorld                        = 5,
    TRANSFORM_MAX                                  = 6

};


// Enum  /Script/Engine.EMaterialVectorCoordTransformSource
enum class EMaterialVectorCoordTransformSource : uint8_t
{
    TRANSFORMSOURCE_Tangent                        = 0,
    TRANSFORMSOURCE_Local                          = 1,
    TRANSFORMSOURCE_World                          = 2,
    TRANSFORMSOURCE_View                           = 3,
    TRANSFORMSOURCE_Camera                         = 4,
    TRANSFORMSOURCE_ParticleWorld                  = 5,
    TRANSFORMSOURCE_MAX                            = 6

};


// Enum  /Script/Engine.EMaterialPositionTransformSource
enum class EMaterialPositionTransformSource : uint8_t
{
    TRANSFORMPOSSOURCE_Local                       = 0,
    TRANSFORMPOSSOURCE_World                       = 1,
    TRANSFORMPOSSOURCE_TranslatedWorld             = 2,
    TRANSFORMPOSSOURCE_View                        = 3,
    TRANSFORMPOSSOURCE_Camera                      = 4,
    TRANSFORMPOSSOURCE_Particle                    = 5,
    TRANSFORMPOSSOURCE_MAX                         = 6

};


// Enum  /Script/Engine.EVectorNoiseFunction
enum class EVectorNoiseFunction : uint8_t
{
    VNF_CellnoiseALU                               = 0,
    VNF_VectorALU                                  = 1,
    VNF_GradientALU                                = 2,
    VNF_CurlALU                                    = 3,
    VNF_VoronoiALU                                 = 4,
    VNF_MAX                                        = 5

};


// Enum  /Script/Engine.EMaterialExposedViewProperty
enum class EMaterialExposedViewProperty : uint8_t
{
    MEVP_BufferSize                                = 0,
    MEVP_FieldOfView                               = 1,
    MEVP_TanHalfFieldOfView                        = 2,
    MEVP_ViewSize                                  = 3,
    MEVP_WorldSpaceViewPosition                    = 4,
    MEVP_WorldSpaceCameraPosition                  = 5,
    MEVP_ViewportOffset                            = 6,
    MEVP_TemporalSampleCount                       = 7,
    MEVP_TemporalSampleIndex                       = 8,
    MEVP_TemporalSampleOffset                      = 9,
    MEVP_RuntimeVirtualTextureOutputLevel          = 10,
    MEVP_RuntimeVirtualTextureOutputDerivative     = 11,
    MEVP_IsOpenSight                               = 12,
    MEVP_OpenRatio                                 = 13,
    MEVP_InShadowRim                               = 14,
    MEVP_OutShadowRim                              = 15,
    MEVP_MAX                                       = 16

};


// Enum  /Script/Engine.EWorldPositionIncludedOffsets
enum class EWorldPositionIncludedOffsets : uint8_t
{
    WPT_Default                                    = 0,
    WPT_ExcludeAllShaderOffsets                    = 1,
    WPT_CameraRelative                             = 2,
    WPT_CameraRelativeNoOffsets                    = 3,
    WPT_MAX                                        = 4

};


// Enum  /Script/Engine.EMaterialFunctionUsage
enum class EMaterialFunctionUsage : uint8_t
{
    Default                                        = 0,
    MaterialLayer                                  = 1,
    MaterialLayerBlend                             = 2,
    EMaterialFunctionUsage_MAX                     = 3

};


// Enum  /Script/Engine.EMaterialUsage
enum class EMaterialUsage : uint8_t
{
    MATUSAGE_SkeletalMesh                          = 0,
    MATUSAGE_ParticleSprites                       = 1,
    MATUSAGE_BeamTrails                            = 2,
    MATUSAGE_MeshParticles                         = 3,
    MATUSAGE_StaticLighting                        = 4,
    MATUSAGE_MorphTargets                          = 5,
    MATUSAGE_SplineMesh                            = 6,
    MATUSAGE_InstancedStaticMeshes                 = 7,
    MATUSAGE_GeometryCollections                   = 8,
    MATUSAGE_Clothing                              = 9,
    MATUSAGE_NiagaraSprites                        = 10,
    MATUSAGE_NiagaraRibbons                        = 11,
    MATUSAGE_NiagaraMeshParticles                  = 12,
    MATUSAGE_GeometryCache                         = 13,
    MATUSAGE_MultiProbe                            = 14,
    MATUSAGE_ILC                                   = 15,
    MATUSAGE_MAX                                   = 16

};


// Enum  /Script/Engine.EMaterialParameterAssociation
enum class EMaterialParameterAssociation : uint8_t
{
    LayerParameter                                 = 0,
    BlendParameter                                 = 1,
    GlobalParameter                                = 2,
    EMaterialParameterAssociation_MAX              = 3

};


// Enum  /Script/Engine.EMaterialMergeType
enum class EMaterialMergeType : uint8_t
{
    MaterialMergeType_Default                      = 0,
    MaterialMergeType_Simplygon                    = 1,
    MaterialMergeType_MAX                          = 2

};


// Enum  /Script/Engine.ETextureSizingType
enum class ETextureSizingType : uint8_t
{
    TextureSizingType_UseSingleTextureSize         = 0,
    TextureSizingType_UseAutomaticBiasedSizes      = 1,
    TextureSizingType_UseManualOverrideTextureSize = 2,
    TextureSizingType_UseSimplygonAutomaticSizing  = 3,
    TextureSizingType_MAX                          = 4

};


// Enum  /Script/Engine.ESceneTextureId
enum class ESceneTextureId : uint8_t
{
    PPI_SceneColor                                 = 0,
    PPI_SceneDepth                                 = 1,
    PPI_DiffuseColor                               = 2,
    PPI_SpecularColor                              = 3,
    PPI_SubsurfaceColor                            = 4,
    PPI_BaseColor                                  = 5,
    PPI_Specular                                   = 6,
    PPI_Metallic                                   = 7,
    PPI_WorldNormal                                = 8,
    PPI_SeparateTranslucency                       = 9,
    PPI_Opacity                                    = 10,
    PPI_Roughness                                  = 11,
    PPI_MaterialAO                                 = 12,
    PPI_CustomDepth                                = 13,
    PPI_PostProcessInput0                          = 14,
    PPI_PostProcessInput1                          = 15,
    PPI_PostProcessInput2                          = 16,
    PPI_PostProcessInput3                          = 17,
    PPI_PostProcessInput4                          = 18,
    PPI_PostProcessInput5                          = 19,
    PPI_PostProcessInput6                          = 20,
    PPI_DecalMask                                  = 21,
    PPI_ShadingModelColor                          = 22,
    PPI_ShadingModelID                             = 23,
    PPI_AmbientOcclusion                           = 24,
    PPI_CustomStencil                              = 25,
    PPI_StoredBaseColor                            = 26,
    PPI_StoredSpecular                             = 27,
    PPI_Velocity                                   = 28,
    PPI_MAX                                        = 29

};


// Enum  /Script/Engine.EMaterialDomain
enum class EMaterialDomain : uint8_t
{
    MD_Surface                                     = 0,
    MD_DeferredDecal                               = 1,
    MD_LightFunction                               = 2,
    MD_Volume                                      = 3,
    MD_PostProcess                                 = 4,
    MD_UI                                          = 5,
    MD_RuntimeVirtualTexture                       = 6,
    MD_MAX                                         = 7

};


// Enum  /Script/Engine.EMeshInstancingReplacementMethod
enum class EMeshInstancingReplacementMethod : uint8_t
{
    RemoveOriginalActors                           = 0,
    KeepOriginalActorsAsEditorOnly                 = 1,
    EMeshInstancingReplacementMethod_MAX           = 2

};


// Enum  /Script/Engine.EUVOutput
enum class EUVOutput : uint8_t
{
    DoNotOutputChannel                             = 0,
    OutputChannel                                  = 1,
    EUVOutput_MAX                                  = 2

};


// Enum  /Script/Engine.EMeshMergeType
enum class EMeshMergeType : uint8_t
{
    MeshMergeType_Default                          = 0,
    MeshMergeType_MergeActor                       = 1,
    MeshMergeType_MAX                              = 2

};


// Enum  /Script/Engine.EMeshLODSelectionType
enum class EMeshLODSelectionType : uint8_t
{
    AllLODs                                        = 0,
    SpecificLOD                                    = 1,
    CalculateLOD                                   = 2,
    LowestDetailLOD                                = 3,
    EMeshLODSelectionType_MAX                      = 4

};


// Enum  /Script/Engine.EProxyNormalComputationMethod
enum class EProxyNormalComputationMethod : uint8_t
{
    AngleWeighted                                  = 0,
    AreaWeighted                                   = 1,
    EqualWeighted                                  = 2,
    EProxyNormalComputationMethod_MAX              = 3

};


// Enum  /Script/Engine.ELandscapeCullingPrecision
enum class ELandscapeCullingPrecision : uint8_t
{
    High                                           = 0,
    Medium                                         = 1,
    Low                                            = 2,
    ELandscapeCullingPrecision_MAX                 = 3

};


// Enum  /Script/Engine.EStaticMeshReductionTerimationCriterion
enum class EStaticMeshReductionTerimationCriterion : uint8_t
{
    Triangles                                      = 0,
    Vertices                                       = 1,
    Any                                            = 2,
    EStaticMeshReductionTerimationCriterion_MAX    = 3

};


// Enum  /Script/Engine.EMeshFeatureImportance
enum class EMeshFeatureImportance : uint8_t
{
    Off                                            = 0,
    Lowest                                         = 1,
    Low                                            = 2,
    Normal                                         = 3,
    High                                           = 4,
    Highest                                        = 5,
    EMeshFeatureImportance_MAX                     = 6

};


// Enum  /Script/Engine.EVertexPaintAxis
enum class EVertexPaintAxis : uint8_t
{
    X                                              = 0,
    Y                                              = 1,
    Z                                              = 2,
    EVertexPaintAxis_MAX                           = 3

};


// Enum  /Script/Engine.EMicroTransactionResult
enum class EMicroTransactionResult : uint8_t
{
    MTR_Succeeded                                  = 0,
    MTR_Failed                                     = 1,
    MTR_Canceled                                   = 2,
    MTR_RestoredFromServer                         = 3,
    MTR_MAX                                        = 4

};


// Enum  /Script/Engine.EMicroTransactionDelegate
enum class EMicroTransactionDelegate : uint8_t
{
    MTD_PurchaseQueryComplete                      = 0,
    MTD_PurchaseComplete                           = 1,
    MTD_MAX                                        = 2

};


// Enum  /Script/Engine.FNavigationSystemRunMode
enum class FNavigationSystemRunMode : uint8_t
{
    InvalidMode                                    = 0,
    GameMode                                       = 1,
    EditorMode                                     = 2,
    SimulationMode                                 = 3,
    PIEMode                                        = 4,
    FNavigationSystemRunMode_MAX                   = 5

};


// Enum  /Script/Engine.ENavigationQueryResult
enum class ENavigationQueryResult : uint8_t
{
    Invalid                                        = 0,
    Error                                          = 1,
    Fail                                           = 2,
    Success                                        = 3,
    ENavigationQueryResult_MAX                     = 4

};


// Enum  /Script/Engine.ENavPathEvent
enum class ENavPathEvent : uint8_t
{
    Cleared                                        = 0,
    NewPath                                        = 1,
    UpdatedDueToGoalMoved                          = 2,
    UpdatedDueToNavigationChanged                  = 3,
    Invalidated                                    = 4,
    RePathFailed                                   = 5,
    MetaPathUpdate                                 = 6,
    Custom                                         = 7,
    ENavPathEvent_MAX                              = 8

};


// Enum  /Script/Engine.ENavDataGatheringModeConfig
enum class ENavDataGatheringModeConfig : uint8_t
{
    Invalid                                        = 0,
    Instant                                        = 1,
    Lazy                                           = 2,
    ENavDataGatheringModeConfig_MAX                = 3

};


// Enum  /Script/Engine.ENavDataGatheringMode
enum class ENavDataGatheringMode : uint8_t
{
    Default                                        = 0,
    Instant                                        = 1,
    Lazy                                           = 2,
    ENavDataGatheringMode_MAX                      = 3

};


// Enum  /Script/Engine.ENavigationOptionFlag
enum class ENavigationOptionFlag : uint8_t
{
    Default                                        = 0,
    Enable                                         = 1,
    Disable                                        = 2,
    MAX                                            = 3

};


// Enum  /Script/Engine.ENavLinkDirection
enum class ENavLinkDirection : uint8_t
{
    BothWays                                       = 0,
    LeftToRight                                    = 1,
    RightToLeft                                    = 2,
    ENavLinkDirection_MAX                          = 3

};


// Enum  /Script/Engine.EEmitterRenderMode
enum class EEmitterRenderMode : uint8_t
{
    ERM_Normal                                     = 0,
    ERM_Point                                      = 1,
    ERM_Cross                                      = 2,
    ERM_LightsOnly                                 = 3,
    ERM_None                                       = 4,
    ERM_MAX                                        = 5

};


// Enum  /Script/Engine.EParticleSubUVInterpMethod
enum class EParticleSubUVInterpMethod : uint8_t
{
    PSUVIM_None                                    = 0,
    PSUVIM_Linear                                  = 1,
    PSUVIM_Linear_Blend                            = 2,
    PSUVIM_Random                                  = 3,
    PSUVIM_Random_Blend                            = 4,
    PSUVIM_MAX                                     = 5

};


// Enum  /Script/Engine.EParticleBurstMethod
enum class EParticleBurstMethod : uint8_t
{
    EPBM_Instant                                   = 0,
    EPBM_Interpolated                              = 1,
    EPBM_MAX                                       = 2

};


// Enum  /Script/Engine.EParticleSystemInsignificanceReaction
enum class EParticleSystemInsignificanceReaction : uint8_t
{
    Auto                                           = 0,
    Complete                                       = 1,
    DisableTick                                    = 2,
    DisableTickAndKill                             = 3,
    Num                                            = 4,
    EParticleSystemInsignificanceReaction_MAX      = 5

};


// Enum  /Script/Engine.EParticleSignificanceLevel
enum class EParticleSignificanceLevel : uint8_t
{
    Low                                            = 0,
    Medium                                         = 1,
    High                                           = 2,
    Critical                                       = 3,
    Num                                            = 4,
    EParticleSignificanceLevel_MAX                 = 5

};


// Enum  /Script/Engine.EParticleDetailMode
enum class EParticleDetailMode : uint8_t
{
    PDM_Low                                        = 0,
    PDM_Medium                                     = 1,
    PDM_High                                       = 2,
    PDM_MAX                                        = 3

};


// Enum  /Script/Engine.EParticleSourceSelectionMethod
enum class EParticleSourceSelectionMethod : uint8_t
{
    EPSSM_Random                                   = 0,
    EPSSM_Sequential                               = 1,
    EPSSM_MAX                                      = 2

};


// Enum  /Script/Engine.EModuleType
enum class EModuleType : uint8_t
{
    EPMT_General                                   = 0,
    EPMT_TypeData                                  = 1,
    EPMT_Beam                                      = 2,
    EPMT_Trail                                     = 3,
    EPMT_Spawn                                     = 4,
    EPMT_Required                                  = 5,
    EPMT_Event                                     = 6,
    EPMT_Light                                     = 7,
    EPMT_SubUV                                     = 8,
    EPMT_MAX                                       = 9

};


// Enum  /Script/Engine.EAttractorParticleSelectionMethod
enum class EAttractorParticleSelectionMethod : uint8_t
{
    EAPSM_Random                                   = 0,
    EAPSM_Sequential                               = 1,
    EAPSM_MAX                                      = 2

};


// Enum  /Script/Engine.Beam2SourceTargetTangentMethod
enum class Beam2SourceTargetTangentMethod : uint8_t
{
    PEB2STTM_Direct                                = 0,
    PEB2STTM_UserSet                               = 1,
    PEB2STTM_Distribution                          = 2,
    PEB2STTM_Emitter                               = 3,
    PEB2STTM_MAX                                   = 4

};


// Enum  /Script/Engine.Beam2SourceTargetMethod
enum class Beam2SourceTargetMethod : uint8_t
{
    PEB2STM_Default                                = 0,
    PEB2STM_UserSet                                = 1,
    PEB2STM_Emitter                                = 2,
    PEB2STM_Particle                               = 3,
    PEB2STM_Actor                                  = 4,
    PEB2STM_MAX                                    = 5

};


// Enum  /Script/Engine.BeamModifierType
enum class BeamModifierType : uint8_t
{
    PEB2MT_Source                                  = 0,
    PEB2MT_Target                                  = 1,
    PEB2MT_MAX                                     = 2

};


// Enum  /Script/Engine.EParticleCameraOffsetUpdateMethod
enum class EParticleCameraOffsetUpdateMethod : uint8_t
{
    EPCOUM_DirectSet                               = 0,
    EPCOUM_Additive                                = 1,
    EPCOUM_Scalar                                  = 2,
    EPCOUM_MAX                                     = 3

};


// Enum  /Script/Engine.EParticleCollisionComplete
enum class EParticleCollisionComplete : uint8_t
{
    EPCC_Kill                                      = 0,
    EPCC_Freeze                                    = 1,
    EPCC_HaltCollisions                            = 2,
    EPCC_FreezeTranslation                         = 3,
    EPCC_FreezeRotation                            = 4,
    EPCC_FreezeMovement                            = 5,
    EPCC_MAX                                       = 6

};


// Enum  /Script/Engine.EParticleCollisionResponse
enum class EParticleCollisionResponse : uint8_t
{
    Bounce                                         = 0,
    Stop                                           = 1,
    Kill                                           = 2,
    EParticleCollisionResponse_MAX                 = 3

};


// Enum  /Script/Engine.ELocationBoneSocketSelectionMethod
enum class ELocationBoneSocketSelectionMethod : uint8_t
{
    BONESOCKETSEL_Sequential                       = 0,
    BONESOCKETSEL_Random                           = 1,
    BONESOCKETSEL_MAX                              = 2

};


// Enum  /Script/Engine.ELocationBoneSocketSource
enum class ELocationBoneSocketSource : uint8_t
{
    BONESOCKETSOURCE_Bones                         = 0,
    BONESOCKETSOURCE_Sockets                       = 1,
    BONESOCKETSOURCE_MAX                           = 2

};


// Enum  /Script/Engine.ELocationEmitterSelectionMethod
enum class ELocationEmitterSelectionMethod : uint8_t
{
    ELESM_Random                                   = 0,
    ELESM_Sequential                               = 1,
    ELESM_MAX                                      = 2

};


// Enum  /Script/Engine.CylinderHeightAxis
enum class CylinderHeightAxis : uint8_t
{
    PMLPC_HEIGHTAXIS_X                             = 0,
    PMLPC_HEIGHTAXIS_Y                             = 1,
    PMLPC_HEIGHTAXIS_Z                             = 2,
    PMLPC_HEIGHTAXIS_MAX                           = 3

};


// Enum  /Script/Engine.ELocationSkelVertSurfaceSource
enum class ELocationSkelVertSurfaceSource : uint8_t
{
    VERTSURFACESOURCE_Vert                         = 0,
    VERTSURFACESOURCE_Surface                      = 1,
    VERTSURFACESOURCE_MAX                          = 2

};


// Enum  /Script/Engine.EOrbitChainMode
enum class EOrbitChainMode : uint8_t
{
    EOChainMode_Add                                = 0,
    EOChainMode_Scale                              = 1,
    EOChainMode_Link                               = 2,
    EOChainMode_MAX                                = 3

};


// Enum  /Script/Engine.EParticleAxisLock
enum class EParticleAxisLock : uint8_t
{
    EPAL_NONE                                      = 0,
    EPAL_X                                         = 1,
    EPAL_Y                                         = 2,
    EPAL_Z                                         = 3,
    EPAL_NEGATIVE_X                                = 4,
    EPAL_NEGATIVE_Y                                = 5,
    EPAL_NEGATIVE_Z                                = 6,
    EPAL_ROTATE_X                                  = 7,
    EPAL_ROTATE_Y                                  = 8,
    EPAL_ROTATE_Z                                  = 9,
    EPAL_MAX                                       = 10

};


// Enum  /Script/Engine.EEmitterDynamicParameterValue
enum class EEmitterDynamicParameterValue : uint8_t
{
    EDPV_UserSet                                   = 0,
    EDPV_AutoSet                                   = 1,
    EDPV_VelocityX                                 = 2,
    EDPV_VelocityY                                 = 3,
    EDPV_VelocityZ                                 = 4,
    EDPV_VelocityMag                               = 5,
    EDPV_MAX                                       = 6

};


// Enum  /Script/Engine.EEmitterNormalsMode
enum class EEmitterNormalsMode : uint8_t
{
    ENM_CameraFacing                               = 0,
    ENM_Spherical                                  = 1,
    ENM_Cylindrical                                = 2,
    ENM_MAX                                        = 3

};


// Enum  /Script/Engine.EParticleSortMode
enum class EParticleSortMode : uint8_t
{
    PSORTMODE_None                                 = 0,
    PSORTMODE_ViewProjDepth                        = 1,
    PSORTMODE_DistanceToView                       = 2,
    PSORTMODE_Age_OldestFirst                      = 3,
    PSORTMODE_Age_NewestFirst                      = 4,
    PSORTMODE_MAX                                  = 5

};


// Enum  /Script/Engine.EParticleUVFlipMode
enum class EParticleUVFlipMode : uint8_t
{
    None                                           = 0,
    FlipUV                                         = 1,
    FlipUOnly                                      = 2,
    FlipVOnly                                      = 3,
    RandomFlipUV                                   = 4,
    RandomFlipUOnly                                = 5,
    RandomFlipVOnly                                = 6,
    RandomFlipUVIndependent                        = 7,
    EParticleUVFlipMode_MAX                        = 8

};


// Enum  /Script/Engine.ETrail2SourceMethod
enum class ETrail2SourceMethod : uint8_t
{
    PET2SRCM_Default                               = 0,
    PET2SRCM_Particle                              = 1,
    PET2SRCM_Actor                                 = 2,
    PET2SRCM_MAX                                   = 3

};


// Enum  /Script/Engine.EBeamTaperMethod
enum class EBeamTaperMethod : uint8_t
{
    PEBTM_None                                     = 0,
    PEBTM_Full                                     = 1,
    PEBTM_Partial                                  = 2,
    PEBTM_MAX                                      = 3

};


// Enum  /Script/Engine.EBeam2Method
enum class EBeam2Method : uint8_t
{
    PEB2M_Distance                                 = 0,
    PEB2M_Target                                   = 1,
    PEB2M_Branch                                   = 2,
    PEB2M_MAX                                      = 3

};


// Enum  /Script/Engine.EMeshCameraFacingOptions
enum class EMeshCameraFacingOptions : uint8_t
{
    XAxisFacing_NoUp                               = 0,
    XAxisFacing_ZUp                                = 1,
    XAxisFacing_NegativeZUp                        = 2,
    XAxisFacing_YUp                                = 3,
    XAxisFacing_NegativeYUp                        = 4,
    LockedAxis_ZAxisFacing                         = 5,
    LockedAxis_NegativeZAxisFacing                 = 6,
    LockedAxis_YAxisFacing                         = 7,
    LockedAxis_NegativeYAxisFacing                 = 8,
    VelocityAligned_ZAxisFacing                    = 9,
    VelocityAligned_NegativeZAxisFacing            = 10,
    VelocityAligned_YAxisFacing                    = 11,
    VelocityAligned_NegativeYAxisFacing            = 12,
    EMeshCameraFacingOptions_MAX                   = 13

};


// Enum  /Script/Engine.EMeshCameraFacingUpAxis
enum class EMeshCameraFacingUpAxis : uint8_t
{
    CameraFacing_NoneUP                            = 0,
    CameraFacing_ZUp                               = 1,
    CameraFacing_NegativeZUp                       = 2,
    CameraFacing_YUp                               = 3,
    CameraFacing_NegativeYUp                       = 4,
    CameraFacing_MAX                               = 5

};


// Enum  /Script/Engine.EMeshScreenAlignment
enum class EMeshScreenAlignment : uint8_t
{
    PSMA_MeshFaceCameraWithRoll                    = 0,
    PSMA_MeshFaceCameraWithSpin                    = 1,
    PSMA_MeshFaceCameraWithLockedAxis              = 2,
    PSMA_MAX                                       = 3

};


// Enum  /Script/Engine.ETrailsRenderAxisOption
enum class ETrailsRenderAxisOption : uint8_t
{
    Trails_CameraUp                                = 0,
    Trails_SourceUp                                = 1,
    Trails_WorldUp                                 = 2,
    Trails_MAX                                     = 3

};


// Enum  /Script/Engine.EParticleScreenAlignment
enum class EParticleScreenAlignment : uint8_t
{
    PSA_FacingCameraPosition                       = 0,
    PSA_Square                                     = 1,
    PSA_Rectangle                                  = 2,
    PSA_Velocity                                   = 3,
    PSA_AwayFromCenter                             = 4,
    PSA_TypeSpecific                               = 5,
    PSA_FacingCameraDistanceBlend                  = 6,
    PSA_MAX                                        = 7

};


// Enum  /Script/Engine.EParticleSystemOcclusionBoundsMethod
enum class EParticleSystemOcclusionBoundsMethod : uint8_t
{
    EPSOBM_None                                    = 0,
    EPSOBM_ParticleBounds                          = 1,
    EPSOBM_CustomBounds                            = 2,
    EPSOBM_MAX                                     = 3

};


// Enum  /Script/Engine.ParticleSystemLODMethod
enum class ParticleSystemLODMethod : uint8_t
{
    PARTICLESYSTEMLODMETHOD_Automatic              = 0,
    PARTICLESYSTEMLODMETHOD_DirectSet              = 1,
    PARTICLESYSTEMLODMETHOD_ActivateAutomatic      = 2,
    PARTICLESYSTEMLODMETHOD_MAX                    = 3

};


// Enum  /Script/Engine.EParticleSystemUpdateMode
enum class EParticleSystemUpdateMode : uint8_t
{
    EPSUM_RealTime                                 = 0,
    EPSUM_FixedTime                                = 1,
    EPSUM_MAX                                      = 2

};


// Enum  /Script/Engine.EParticleEventType
enum class EParticleEventType : uint8_t
{
    EPET_Any                                       = 0,
    EPET_Spawn                                     = 1,
    EPET_Death                                     = 2,
    EPET_Collision                                 = 3,
    EPET_Burst                                     = 4,
    EPET_Blueprint                                 = 5,
    EPET_MAX                                       = 6

};


// Enum  /Script/Engine.ParticleReplayState
enum class ParticleReplayState : uint8_t
{
    PRS_Disabled                                   = 0,
    PRS_Capturing                                  = 1,
    PRS_Replaying                                  = 2,
    PRS_MAX                                        = 3

};


// Enum  /Script/Engine.EParticleSysParamType
enum class EParticleSysParamType : uint8_t
{
    PSPT_None                                      = 0,
    PSPT_Scalar                                    = 1,
    PSPT_ScalarRand                                = 2,
    PSPT_Vector                                    = 3,
    PSPT_VectorRand                                = 4,
    PSPT_Color                                     = 5,
    PSPT_Actor                                     = 6,
    PSPT_Material                                  = 7,
    PSPT_MAX                                       = 8

};


// Enum  /Script/Engine.ESettingsLockedAxis
enum class ESettingsLockedAxis : uint8_t
{
    None                                           = 0,
    X                                              = 1,
    Y                                              = 2,
    Z                                              = 3,
    Invalid                                        = 4,
    ESettingsLockedAxis_MAX                        = 5

};


// Enum  /Script/Engine.ESettingsDOF
enum class ESettingsDOF : uint8_t
{
    Full3D                                         = 0,
    YZPlane                                        = 1,
    XZPlane                                        = 2,
    XYPlane                                        = 3,
    ESettingsDOF_MAX                               = 4

};


// Enum  /Script/Engine.EFrictionCombineMode
enum class EFrictionCombineMode : uint8_t
{
    Average                                        = 0,
    Min                                            = 1,
    Multiply                                       = 2,
    Max                                            = 3

};


// Enum  /Script/Engine.ERichCurveExtrapolation
enum class ERichCurveExtrapolation : uint8_t
{
    RCCE_Cycle                                     = 0,
    RCCE_CycleWithOffset                           = 1,
    RCCE_Oscillate                                 = 2,
    RCCE_Linear                                    = 3,
    RCCE_Constant                                  = 4,
    RCCE_None                                      = 5,
    RCCE_MAX                                       = 6

};


// Enum  /Script/Engine.ERichCurveInterpMode
enum class ERichCurveInterpMode : uint8_t
{
    RCIM_Linear                                    = 0,
    RCIM_Constant                                  = 1,
    RCIM_Cubic                                     = 2,
    RCIM_None                                      = 3,
    RCIM_MAX                                       = 4

};


// Enum  /Script/Engine.EReflectionSourceType
enum class EReflectionSourceType : uint8_t
{
    CapturedScene                                  = 0,
    SpecifiedCubemap                               = 1,
    EReflectionSourceType_MAX                      = 2

};


// Enum  /Script/Engine.ELightmapEncodeMode
enum class ELightmapEncodeMode : uint8_t
{
    Default                                        = 0,
    LQT_HDR                                        = 1,
    LQT_LDR                                        = 2,
    ELightmapEncodeMode_MAX                        = 3

};


// Enum  /Script/Engine.EDefaultBackBufferPixelFormat
enum class EDefaultBackBufferPixelFormat : uint8_t
{
    DBBPF_B8G8R8A8                                 = 0,
    DBBPF_A16B16G16R16_DEPRECATED                  = 1,
    DBBPF_FloatRGB_DEPRECATED                      = 2,
    DBBPF_FloatRGBA                                = 3,
    DBBPF_A2B10G10R10                              = 4,
    DBBPF_RGB565                                   = 5,
    DBBPF_R8G8B8A8                                 = 6,
    DBBPF_MAX                                      = 7

};


// Enum  /Script/Engine.EAutoExposureMethodUI
enum class EAutoExposureMethodUI : uint8_t
{
    AEM_Histogram                                  = 0,
    AEM_Basic                                      = 1,
    AEM_Manual                                     = 2,
    AEM_MAX                                        = 3

};


// Enum  /Script/Engine.EAlphaChannelMode
enum class EAlphaChannelMode : uint8_t
{
    Disabled                                       = 0,
    LinearColorSpaceOnly                           = 1,
    AllowThroughTonemapper                         = 2,
    EAlphaChannelMode_MAX                          = 3

};


// Enum  /Script/Engine.EEarlyZPass
enum class EEarlyZPass : uint8_t
{
    None                                           = 0,
    OpaqueOnly                                     = 1,
    OpaqueAndMasked                                = 2,
    Auto                                           = 3,
    EEarlyZPass_MAX                                = 4

};


// Enum  /Script/Engine.ECustomDepthStencil
enum class ECustomDepthStencil : uint8_t
{
    Disabled                                       = 0,
    Enabled                                        = 1,
    EnabledOnDemand                                = 2,
    EnabledWithStencil                             = 3,
    ECustomDepthStencil_MAX                        = 4

};


// Enum  /Script/Engine.EMobileMSAASampleCount
enum class EMobileMSAASampleCount : uint8_t
{
    One                                            = 1,
    Two                                            = 2,
    Four                                           = 4,
    Eight                                          = 8,
    EMobileMSAASampleCount_MAX                     = 9

};


// Enum  /Script/Engine.ECompositingSampleCount
enum class ECompositingSampleCount : uint8_t
{
    One                                            = 1,
    Two                                            = 2,
    Four                                           = 4,
    Eight                                          = 8,
    ECompositingSampleCount_MAX                    = 9

};


// Enum  /Script/Engine.EClearSceneOptions
enum class EClearSceneOptions : uint8_t
{
    NoClear                                        = 0,
    HardwareClear                                  = 1,
    QuadAtMaxZ                                     = 2,
    EClearSceneOptions_MAX                         = 3

};


// Enum  /Script/Engine.EReporterLineStyle
enum class EReporterLineStyle : uint8_t
{
    Line                                           = 0,
    Dash                                           = 1,
    EReporterLineStyle_MAX                         = 2

};


// Enum  /Script/Engine.ELegendPosition
enum class ELegendPosition : uint8_t
{
    Outside                                        = 0,
    Inside                                         = 1,
    ELegendPosition_MAX                            = 2

};


// Enum  /Script/Engine.EGraphDataStyle
enum class EGraphDataStyle : uint8_t
{
    Lines                                          = 0,
    Filled                                         = 1,
    EGraphDataStyle_MAX                            = 2

};


// Enum  /Script/Engine.EGraphAxisStyle
enum class EGraphAxisStyle : uint8_t
{
    Lines                                          = 0,
    Notches                                        = 1,
    Grid                                           = 2,
    EGraphAxisStyle_MAX                            = 3

};


// Enum  /Script/Engine.ERichCurveKeyTimeCompressionFormat
enum class ERichCurveKeyTimeCompressionFormat : uint8_t
{
    RCKTCF_uint16                                  = 0,
    RCKTCF_float32                                 = 1,
    RCKTCF_MAX                                     = 2

};


// Enum  /Script/Engine.ERichCurveCompressionFormat
enum class ERichCurveCompressionFormat : uint8_t
{
    RCCF_Empty                                     = 0,
    RCCF_Constant                                  = 1,
    RCCF_Linear                                    = 2,
    RCCF_Cubic                                     = 3,
    RCCF_Mixed                                     = 4,
    RCCF_MAX                                       = 5

};


// Enum  /Script/Engine.ERichCurveTangentWeightMode
enum class ERichCurveTangentWeightMode : uint8_t
{
    RCTWM_WeightedNone                             = 0,
    RCTWM_WeightedArrive                           = 1,
    RCTWM_WeightedLeave                            = 2,
    RCTWM_WeightedBoth                             = 3,
    RCTWM_MAX                                      = 4

};


// Enum  /Script/Engine.ERichCurveTangentMode
enum class ERichCurveTangentMode : uint8_t
{
    RCTM_Auto                                      = 0,
    RCTM_User                                      = 1,
    RCTM_Break                                     = 2,
    RCTM_None                                      = 3,
    RCTM_MAX                                       = 4

};


// Enum  /Script/Engine.EConstraintTransform
enum class EConstraintTransform : uint8_t
{
    Absolute                                       = 0,
    Relative                                       = 1,
    EConstraintTransform_MAX                       = 2

};


// Enum  /Script/Engine.EControlConstraint
enum class EControlConstraint : uint8_t
{
    Orientation                                    = 0,
    Translation                                    = 1,
    MAX                                            = 2

};


// Enum  /Script/Engine.ERootMotionFinishVelocityMode
enum class ERootMotionFinishVelocityMode : uint8_t
{
    MaintainLastRootMotionVelocity                 = 0,
    SetVelocity                                    = 1,
    ClampVelocity                                  = 2,
    ERootMotionFinishVelocityMode_MAX              = 3

};


// Enum  /Script/Engine.ERootMotionSourceSettingsFlags
enum class ERootMotionSourceSettingsFlags : uint8_t
{
    UseSensitiveLiftoffCheck                       = 1,
    DisablePartialEndTick                          = 2,
    ERootMotionSourceSettingsFlags_MAX             = 3

};


// Enum  /Script/Engine.ERootMotionSourceStatusFlags
enum class ERootMotionSourceStatusFlags : uint8_t
{
    Prepared                                       = 1,
    Finished                                       = 2,
    MarkedForRemoval                               = 4,
    ERootMotionSourceStatusFlags_MAX               = 5

};


// Enum  /Script/Engine.ERootMotionAccumulateMode
enum class ERootMotionAccumulateMode : uint8_t
{
    Override                                       = 0,
    Additive                                       = 1,
    ERootMotionAccumulateMode_MAX                  = 2

};


// Enum  /Script/Engine.ERuntimeVirtualTextureMaterialType
enum class ERuntimeVirtualTextureMaterialType : uint8_t
{
    BaseColor                                      = 0,
    BaseColor_Normal                               = 1,
    BaseColor_Normal_Specular                      = 2,
    Count                                          = 3,
    ERuntimeVirtualTextureMaterialType_MAX         = 4

};


// Enum  /Script/Engine.EReflectedAndRefractedRayTracedShadows
enum class EReflectedAndRefractedRayTracedShadows : uint8_t
{
    Disabled                                       = 0,
    Hard_shadows                                   = 1,
    Area_shadows                                   = 2,
    EReflectedAndRefractedRayTracedShadows_MAX     = 3

};


// Enum  /Script/Engine.ETranslucencyType
enum class ETranslucencyType : uint8_t
{
    Raster                                         = 0,
    RayTracing                                     = 1,
    ETranslucencyType_MAX                          = 2

};


// Enum  /Script/Engine.EReflectionsType
enum class EReflectionsType : uint8_t
{
    ScreenSpace                                    = 0,
    RayTracing                                     = 1,
    EReflectionsType_MAX                           = 2

};


// Enum  /Script/Engine.ELightUnits
enum class ELightUnits : uint8_t
{
    Unitless                                       = 0,
    Candelas                                       = 1,
    Lumens                                         = 2,
    ELightUnits_MAX                                = 3

};


// Enum  /Script/Engine.EBloomMethod
enum class EBloomMethod : uint8_t
{
    BM_SOG                                         = 0,
    BM_FFT                                         = 1,
    BM_MAX                                         = 2

};


// Enum  /Script/Engine.EAutoExposureMethod
enum class EAutoExposureMethod : uint8_t
{
    AEM_Histogram                                  = 0,
    AEM_Basic                                      = 1,
    AEM_Manual                                     = 2,
    AEM_MAX                                        = 3

};


// Enum  /Script/Engine.EAntiAliasingMethod
enum class EAntiAliasingMethod : uint8_t
{
    AAM_None                                       = 0,
    AAM_FXAA                                       = 1,
    AAM_TemporalAA                                 = 2,
    AAM_MSAA                                       = 3,
    AAM_MAX                                        = 4

};


// Enum  /Script/Engine.EDepthOfFieldMethod
enum class EDepthOfFieldMethod : uint8_t
{
    DOFM_BokehDOF                                  = 0,
    DOFM_Gaussian                                  = 1,
    DOFM_CircleDOF                                 = 2,
    DOFM_MAX                                       = 3

};


// Enum  /Script/Engine.ESceneCapturePrimitiveRenderMode
enum class ESceneCapturePrimitiveRenderMode : uint8_t
{
    PRM_LegacySceneCapture                         = 0,
    PRM_RenderScenePrimitives                      = 1,
    PRM_UseShowOnlyList                            = 2,
    PRM_MAX                                        = 3

};


// Enum  /Script/Engine.EMaterialProperty
enum class EMaterialProperty : uint8_t
{
    MP_EmissiveColor                               = 0,
    MP_Opacity                                     = 1,
    MP_OpacityMask                                 = 2,
    MP_DiffuseColor                                = 3,
    MP_SpecularColor                               = 4,
    MP_BaseColor                                   = 5,
    MP_Metallic                                    = 6,
    MP_Specular                                    = 7,
    MP_Roughness                                   = 8,
    MP_Normal                                      = 9,
    MP_WorldPositionOffset                         = 10,
    MP_WorldDisplacement                           = 11,
    MP_TessellationMultiplier                      = 12,
    MP_SubsurfaceColor                             = 13,
    MP_CustomData0                                 = 14,
    MP_CustomData1                                 = 15,
    MP_AmbientOcclusion                            = 16,
    MP_Refraction                                  = 17,
    MP_CustomizedUVs0                              = 18,
    MP_CustomizedUVs1                              = 19,
    MP_CustomizedUVs2                              = 20,
    MP_CustomizedUVs3                              = 21,
    MP_CustomizedUVs4                              = 22,
    MP_CustomizedUVs5                              = 23,
    MP_CustomizedUVs6                              = 24,
    MP_CustomizedUVs7                              = 25,
    MP_PixelDepthOffset                            = 26,
    MP_ShadingModel                                = 27,
    MP_MaterialAttributes                          = 28,
    MP_CustomOutput                                = 29,
    MP_MAX                                         = 30

};


// Enum  /Script/Engine.EPhysicsTransformUpdateMode
enum class EPhysicsTransformUpdateMode : uint8_t
{
    SimulationUpatesComponentTransform             = 0,
    ComponentTransformIsKinematic                  = 1,
    EPhysicsTransformUpdateMode_MAX                = 2

};


// Enum  /Script/Engine.EAnimationMode
enum class EAnimationMode : uint8_t
{
    AnimationBlueprint                             = 0,
    AnimationSingleNode                            = 1,
    AnimationCustomMode                            = 2,
    EAnimationMode_MAX                             = 3

};


// Enum  /Script/Engine.EKinematicBonesUpdateToPhysics
enum class EKinematicBonesUpdateToPhysics : uint8_t
{
    SkipSimulatingBones                            = 0,
    SkipAllBones                                   = 1,
    EKinematicBonesUpdateToPhysics_MAX             = 2

};


// Enum  /Script/Engine.EAnimCurveType
enum class EAnimCurveType : uint8_t
{
    AttributeCurve                                 = 0,
    MaterialCurve                                  = 1,
    MorphTargetCurve                               = 2,
    MaxAnimCurveType                               = 3,
    EAnimCurveType_MAX                             = 4

};


// Enum  /Script/Engine.EBoneFilterActionOption
enum class EBoneFilterActionOption : uint8_t
{
    Remove                                         = 0,
    Keep                                           = 1,
    Invalid                                        = 2,
    EBoneFilterActionOption_MAX                    = 3

};


// Enum  /Script/Engine.SkeletalMeshOptimizationImportance
enum class SkeletalMeshOptimizationImportance : uint8_t
{
    SMOI_Off                                       = 0,
    SMOI_Lowest                                    = 1,
    SMOI_Low                                       = 2,
    SMOI_Normal                                    = 3,
    SMOI_High                                      = 4,
    SMOI_Highest                                   = 5,
    SMOI_MAX                                       = 6

};


// Enum  /Script/Engine.SkeletalMeshOptimizationType
enum class SkeletalMeshOptimizationType : uint8_t
{
    SMOT_NumOfTriangles                            = 0,
    SMOT_MaxDeviation                              = 1,
    SMOT_TriangleOrDeviation                       = 2,
    SMOT_MAX                                       = 3

};


// Enum  /Script/Engine.SkeletalMeshTerminationCriterion
enum class SkeletalMeshTerminationCriterion : uint8_t
{
    SMTC_NumOfTriangles                            = 0,
    SMTC_NumOfVerts                                = 1,
    SMTC_TriangleOrVert                            = 2,
    SMTC_AbsNumOfTriangles                         = 3,
    SMTC_AbsNumOfVerts                             = 4,
    SMTC_AbsTriangleOrVert                         = 5,
    SMTC_MAX                                       = 6

};


// Enum  /Script/Engine.EBoneTranslationRetargetingMode
enum class EBoneTranslationRetargetingMode : uint8_t
{
    Animation                                      = 0,
    Skeleton                                       = 1,
    AnimationScaled                                = 2,
    AnimationRelative                              = 3,
    OrientAndScale                                 = 4,
    EBoneTranslationRetargetingMode_MAX            = 5

};


// Enum  /Script/Engine.EBoneSpaces
enum class EBoneSpaces : uint8_t
{
    WorldSpace                                     = 0,
    ComponentSpace                                 = 1,
    EBoneSpaces_MAX                                = 2

};


// Enum  /Script/Engine.EVisibilityBasedAnimTickOption
enum class EVisibilityBasedAnimTickOption : uint8_t
{
    AlwaysTickPoseAndRefreshBones                  = 0,
    AlwaysTickPose                                 = 1,
    OnlyTickMontagesWhenNotRendered                = 2,
    OnlyTickPoseWhenRendered                       = 3,
    EVisibilityBasedAnimTickOption_MAX             = 4

};


// Enum  /Script/Engine.EPhysBodyOp
enum class EPhysBodyOp : uint8_t
{
    PBO_None                                       = 0,
    PBO_Term                                       = 1,
    PBO_MAX                                        = 2

};


// Enum  /Script/Engine.EBoneVisibilityStatus
enum class EBoneVisibilityStatus : uint8_t
{
    BVS_HiddenByParent                             = 0,
    BVS_Visible                                    = 1,
    BVS_ExplicitlyHidden                           = 2,
    BVS_MAX                                        = 3

};


// Enum  /Script/Engine.ESkyLightSourceType
enum class ESkyLightSourceType : uint8_t
{
    SLS_CapturedScene                              = 0,
    SLS_SpecifiedCubemap                           = 1,
    SLS_MAX                                        = 2

};


// Enum  /Script/Engine.EReverbSendMethod
enum class EReverbSendMethod : uint8_t
{
    Linear                                         = 0,
    CustomCurve                                    = 1,
    Manual                                         = 2,
    EReverbSendMethod_MAX                          = 3

};


// Enum  /Script/Engine.EAirAbsorptionMethod
enum class EAirAbsorptionMethod : uint8_t
{
    Linear                                         = 0,
    CustomCurve                                    = 1,
    EAirAbsorptionMethod_MAX                       = 2

};


// Enum  /Script/Engine.ESoundSpatializationAlgorithm
enum class ESoundSpatializationAlgorithm : uint8_t
{
    SPATIALIZATION_Default                         = 0,
    SPATIALIZATION_HRTF                            = 1,
    SPATIALIZATION_MAX                             = 2

};


// Enum  /Script/Engine.ESoundDistanceCalc
enum class ESoundDistanceCalc : uint8_t
{
    SOUNDDISTANCE_Normal                           = 0,
    SOUNDDISTANCE_InfiniteXYPlane                  = 1,
    SOUNDDISTANCE_InfiniteXZPlane                  = 2,
    SOUNDDISTANCE_InfiniteYZPlane                  = 3,
    SOUNDDISTANCE_MAX                              = 4

};


// Enum  /Script/Engine.EVirtualizationMode
enum class EVirtualizationMode : uint8_t
{
    Disabled                                       = 0,
    PlayWhenSilent                                 = 1,
    Restart                                        = 2,
    EVirtualizationMode_MAX                        = 3

};


// Enum  /Script/Engine.EAudioOutputTarget
enum class EAudioOutputTarget : uint8_t
{
    Speaker                                        = 0,
    Controller                                     = 1,
    ControllerFallbackToSpeaker                    = 2,
    EAudioOutputTarget_MAX                         = 3

};


// Enum  /Script/Engine.EMaxConcurrentResolutionRule
enum class EMaxConcurrentResolutionRule : uint8_t
{
    PreventNew                                     = 0,
    StopOldest                                     = 1,
    StopFarthestThenPreventNew                     = 2,
    StopFarthestThenOldest                         = 3,
    StopLowestPriority                             = 4,
    StopQuietest                                   = 5,
    StopLowestPriorityThenPreventNew               = 6,
    EMaxConcurrentResolutionRule_MAX               = 7

};


// Enum  /Script/Engine.ESoundGroup
enum class ESoundGroup : uint8_t
{
    SOUNDGROUP_Default                             = 0,
    SOUNDGROUP_Effects                             = 1,
    SOUNDGROUP_UI                                  = 2,
    SOUNDGROUP_Music                               = 3,
    SOUNDGROUP_Voice                               = 4,
    SOUNDGROUP_GameSoundGroup1                     = 5,
    SOUNDGROUP_GameSoundGroup2                     = 6,
    SOUNDGROUP_GameSoundGroup3                     = 7,
    SOUNDGROUP_GameSoundGroup4                     = 8,
    SOUNDGROUP_GameSoundGroup5                     = 9,
    SOUNDGROUP_GameSoundGroup6                     = 10,
    SOUNDGROUP_GameSoundGroup7                     = 11,
    SOUNDGROUP_GameSoundGroup8                     = 12,
    SOUNDGROUP_GameSoundGroup9                     = 13,
    SOUNDGROUP_GameSoundGroup10                    = 14,
    SOUNDGROUP_GameSoundGroup11                    = 15,
    SOUNDGROUP_GameSoundGroup12                    = 16,
    SOUNDGROUP_GameSoundGroup13                    = 17,
    SOUNDGROUP_GameSoundGroup14                    = 18,
    SOUNDGROUP_GameSoundGroup15                    = 19,
    SOUNDGROUP_GameSoundGroup16                    = 20,
    SOUNDGROUP_GameSoundGroup17                    = 21,
    SOUNDGROUP_GameSoundGroup18                    = 22,
    SOUNDGROUP_GameSoundGroup19                    = 23,
    SOUNDGROUP_GameSoundGroup20                    = 24,
    SOUNDGROUP_MAX                                 = 25

};


// Enum  /Script/Engine.ModulationParamMode
enum class ModulationParamMode : uint8_t
{
    MPM_Normal                                     = 0,
    MPM_Abs                                        = 1,
    MPM_Direct                                     = 2,
    MPM_MAX                                        = 3

};


// Enum  /Script/Engine.ESourceBusChannels
enum class ESourceBusChannels : uint8_t
{
    Mono                                           = 0,
    Stereo                                         = 1,
    ESourceBusChannels_MAX                         = 2

};


// Enum  /Script/Engine.ESourceBusSendLevelControlMethod
enum class ESourceBusSendLevelControlMethod : uint8_t
{
    Linear                                         = 0,
    CustomCurve                                    = 1,
    Manual                                         = 2,
    ESourceBusSendLevelControlMethod_MAX           = 3

};


// Enum  /Script/Engine.ESendLevelControlMethod
enum class ESendLevelControlMethod : uint8_t
{
    Linear                                         = 0,
    CustomCurve                                    = 1,
    Manual                                         = 2,
    ESendLevelControlMethod_MAX                    = 3

};


// Enum  /Script/Engine.EAudioRecordingExportType
enum class EAudioRecordingExportType : uint8_t
{
    SoundWave                                      = 0,
    WavFile                                        = 1,
    EAudioRecordingExportType_MAX                  = 2

};


// Enum  /Script/Engine.ESubmixChannelFormat
enum class ESubmixChannelFormat : uint8_t
{
    Device                                         = 0,
    Stereo                                         = 1,
    Quad                                           = 2,
    FiveDotOne                                     = 3,
    SevenDotOne                                    = 4,
    Ambisonics                                     = 5,
    Count                                          = 6,
    ESubmixChannelFormat_MAX                       = 7

};


// Enum  /Script/Engine.ESoundWaveFFTSize
enum class ESoundWaveFFTSize : uint8_t
{
    VerySmall                                      = 0,
    Small                                          = 1,
    Medium                                         = 2,
    Large                                          = 3,
    VeryLarge                                      = 4,
    ESoundWaveFFTSize_MAX                          = 5

};


// Enum  /Script/Engine.EDecompressionType
enum class EDecompressionType : uint8_t
{
    DTYPE_Setup                                    = 0,
    DTYPE_Invalid                                  = 1,
    DTYPE_Preview                                  = 2,
    DTYPE_Native                                   = 3,
    DTYPE_RealTime                                 = 4,
    DTYPE_Procedural                               = 5,
    DTYPE_Xenon                                    = 6,
    DTYPE_Streaming                                = 7,
    DTYPE_MAX                                      = 8

};


// Enum  /Script/Engine.ESplineCoordinateSpace
enum class ESplineCoordinateSpace : uint8_t
{
    Local                                          = 0,
    World                                          = 1,
    ESplineCoordinateSpace_MAX                     = 2

};


// Enum  /Script/Engine.ESplinePointType
enum class ESplinePointType : uint8_t
{
    Linear                                         = 0,
    Curve                                          = 1,
    Constant                                       = 2,
    CurveClamped                                   = 3,
    CurveCustomTangent                             = 4,
    ESplinePointType_MAX                           = 5

};


// Enum  /Script/Engine.ESplineMeshAxis
enum class ESplineMeshAxis : uint8_t
{
    X                                              = 0,
    Y                                              = 1,
    Z                                              = 2,
    ESplineMeshAxis_MAX                            = 3

};


// Enum  /Script/Engine.EOptimizationType
enum class EOptimizationType : uint8_t
{
    OT_NumOfTriangles                              = 0,
    OT_MaxDeviation                                = 1,
    OT_MAX                                         = 2

};


// Enum  /Script/Engine.EImportanceLevel
enum class EImportanceLevel : uint8_t
{
    IL_Off                                         = 0,
    IL_Lowest                                      = 1,
    IL_Low                                         = 2,
    IL_Normal                                      = 3,
    IL_High                                        = 4,
    IL_Highest                                     = 5,
    TEMP_BROKEN2                                   = 6,
    EImportanceLevel_MAX                           = 7

};


// Enum  /Script/Engine.ENormalMode
enum class ENormalMode : uint8_t
{
    NM_PreserveSmoothingGroups                     = 0,
    NM_RecalculateNormals                          = 1,
    NM_RecalculateNormalsSmooth                    = 2,
    NM_RecalculateNormalsHard                      = 3,
    TEMP_BROKEN                                    = 4,
    ENormalMode_MAX                                = 5

};


// Enum  /Script/Engine.EStereoLayerShape
enum class EStereoLayerShape : uint8_t
{
    SLSH_QuadLayer                                 = 0,
    SLSH_CylinderLayer                             = 1,
    SLSH_CubemapLayer                              = 2,
    SLSH_MAX                                       = 3

};


// Enum  /Script/Engine.EStereoLayerType
enum class EStereoLayerType : uint8_t
{
    SLT_WorldLocked                                = 0,
    SLT_TrackerLocked                              = 1,
    SLT_FaceLocked                                 = 2,
    SLT_MAX                                        = 3

};


// Enum  /Script/Engine.EOpacitySourceMode
enum class EOpacitySourceMode : uint8_t
{
    OSM_Alpha                                      = 0,
    OSM_ColorBrightness                            = 1,
    OSM_RedChannel                                 = 2,
    OSM_GreenChannel                               = 3,
    OSM_BlueChannel                                = 4,
    OSM_MAX                                        = 5

};


// Enum  /Script/Engine.ESubUVBoundingVertexCount
enum class ESubUVBoundingVertexCount : uint8_t
{
    BVC_FourVertices                               = 0,
    BVC_EightVertices                              = 1,
    BVC_MAX                                        = 2

};


// Enum  /Script/Engine.EVerticalTextAligment
enum class EVerticalTextAligment : uint8_t
{
    EVRTA_TextTop                                  = 0,
    EVRTA_TextCenter                               = 1,
    EVRTA_TextBottom                               = 2,
    EVRTA_QuadTop                                  = 3,
    EVRTA_MAX                                      = 4

};


// Enum  /Script/Engine.EHorizTextAligment
enum class EHorizTextAligment : uint8_t
{
    EHTA_Left                                      = 0,
    EHTA_Center                                    = 1,
    EHTA_Right                                     = 2,
    EHTA_MAX                                       = 3

};


// Enum  /Script/Engine.ETextureLossyCompressionAmount
enum class ETextureLossyCompressionAmount : uint8_t
{
    TLCA_Default                                   = 0,
    TLCA_None                                      = 1,
    TLCA_Lowest                                    = 2,
    TLCA_Low                                       = 3,
    TLCA_Medium                                    = 4,
    TLCA_High                                      = 5,
    TLCA_Highest                                   = 6,
    TLCA_MAX                                       = 7

};


// Enum  /Script/Engine.ETextureCompressionQuality
enum class ETextureCompressionQuality : uint8_t
{
    TCQ_Default                                    = 0,
    TCQ_Lowest                                     = 1,
    TCQ_Low                                        = 2,
    TCQ_Medium                                     = 3,
    TCQ_High                                       = 4,
    TCQ_Highest                                    = 5,
    TCQ_MAX                                        = 6

};


// Enum  /Script/Engine.ETextureSourceFormat
enum class ETextureSourceFormat : uint8_t
{
    TSF_Invalid                                    = 0,
    TSF_G8                                         = 1,
    TSF_BGRA8                                      = 2,
    TSF_BGRE8                                      = 3,
    TSF_RGBA16                                     = 4,
    TSF_RGBA16F                                    = 5,
    TSF_RGBA8                                      = 6,
    TSF_RGBE8                                      = 7,
    TSF_MAX                                        = 8

};


// Enum  /Script/Engine.ETextureSourceArtType
enum class ETextureSourceArtType : uint8_t
{
    TSAT_Uncompressed                              = 0,
    TSAT_PNGCompressed                             = 1,
    TSAT_DDSFile                                   = 2,
    TSAT_MAX                                       = 3

};


// Enum  /Script/Engine.ETextureMipCount
enum class ETextureMipCount : uint8_t
{
    TMC_ResidentMips                               = 0,
    TMC_AllMips                                    = 1,
    TMC_AllMipsBiased                              = 2,
    TMC_MAX                                        = 3

};


// Enum  /Script/Engine.ECompositeTextureMode
enum class ECompositeTextureMode : uint8_t
{
    CTM_Disabled                                   = 0,
    CTM_NormalRoughnessToRed                       = 1,
    CTM_NormalRoughnessToGreen                     = 2,
    CTM_NormalRoughnessToBlue                      = 3,
    CTM_NormalRoughnessToAlpha                     = 4,
    CTM_MAX                                        = 5

};


// Enum  /Script/Engine.TextureAddress
enum class TextureAddress : uint8_t
{
    TA_Wrap                                        = 0,
    TA_Clamp                                       = 1,
    TA_Mirror                                      = 2,
    TA_MAX                                         = 3

};


// Enum  /Script/Engine.TextureFilter
enum class TextureFilter : uint8_t
{
    TF_Nearest                                     = 0,
    TF_Bilinear                                    = 1,
    TF_Trilinear                                   = 2,
    TF_Default                                     = 3,
    TF_MAX                                         = 4

};


// Enum  /Script/Engine.TextureCompressionSettings
enum class TextureCompressionSettings : uint8_t
{
    TC_Default                                     = 0,
    TC_Normalmap                                   = 1,
    TC_Masks                                       = 2,
    TC_Grayscale                                   = 3,
    TC_Displacementmap                             = 4,
    TC_VectorDisplacementmap                       = 5,
    TC_HDR                                         = 6,
    TC_EditorIcon                                  = 7,
    TC_Alpha                                       = 8,
    TC_DistanceFieldFont                           = 9,
    TC_HDR_Compressed                              = 10,
    TC_BC7                                         = 11,
    TC_R5G6B5                                      = 12,
    TC_MixedNormalmap                              = 13,
    TC_MAX                                         = 14

};


// Enum  /Script/Engine.ETexChannel
enum class ETexChannel : uint8_t
{
    AG_TC_R                                        = 0,
    AG_TC_G                                        = 1,
    AG_TC_B                                        = 2,
    AG_TC_A                                        = 3,
    AG_TC_MAX                                      = 4

};


// Enum  /Script/Engine.ETextureMipLoadOptions
enum class ETextureMipLoadOptions : uint8_t
{
    Default                                        = 0,
    AllMips                                        = 1,
    OnlyFirstMip                                   = 2,
    ETextureMipLoadOptions_MAX                     = 3

};


// Enum  /Script/Engine.ETextureSamplerFilter
enum class ETextureSamplerFilter : uint8_t
{
    Point                                          = 0,
    Bilinear                                       = 1,
    Trilinear                                      = 2,
    AnisotropicPoint                               = 3,
    AnisotropicLinear                              = 4,
    ETextureSamplerFilter_MAX                      = 5

};


// Enum  /Script/Engine.ETexturePowerOfTwoSetting
enum class ETexturePowerOfTwoSetting : uint8_t
{
    None                                           = 0,
    PadToPowerOfTwo                                = 1,
    PadToSquarePowerOfTwo                          = 2,
    StretchToPowerOfTwo                            = 3,
    StretchToSquarePowerOfTwo                      = 4,
    ETexturePowerOfTwoSetting_MAX                  = 5

};


// Enum  /Script/Engine.TextureMipGenSettings
enum class TextureMipGenSettings : uint8_t
{
    TMGS_FromTextureGroup                          = 0,
    TMGS_SimpleAverage                             = 1,
    TMGS_Sharpen0                                  = 2,
    TMGS_Sharpen1                                  = 3,
    TMGS_Sharpen2                                  = 4,
    TMGS_Sharpen3                                  = 5,
    TMGS_Sharpen4                                  = 6,
    TMGS_Sharpen5                                  = 7,
    TMGS_Sharpen6                                  = 8,
    TMGS_Sharpen7                                  = 9,
    TMGS_Sharpen8                                  = 10,
    TMGS_Sharpen9                                  = 11,
    TMGS_Sharpen10                                 = 12,
    TMGS_NoMipmaps                                 = 13,
    TMGS_LeaveExistingMips                         = 14,
    TMGS_Blur1                                     = 15,
    TMGS_Blur2                                     = 16,
    TMGS_Blur3                                     = 17,
    TMGS_Blur4                                     = 18,
    TMGS_Blur5                                     = 19,
    TMGS_Unfiltered                                = 20,
    TMGS_MAX                                       = 21

};


// Enum  /Script/Engine.TextureGroup
enum class TextureGroup : uint8_t
{
    TEXTUREGROUP_World                             = 0,
    TEXTUREGROUP_WorldNormalMap                    = 1,
    TEXTUREGROUP_WorldSpecular                     = 2,
    TEXTUREGROUP_Character                         = 3,
    TEXTUREGROUP_CharacterNormalMap                = 4,
    TEXTUREGROUP_CharacterSpecular                 = 5,
    TEXTUREGROUP_Weapon                            = 6,
    TEXTUREGROUP_WeaponNormalMap                   = 7,
    TEXTUREGROUP_WeaponSpecular                    = 8,
    TEXTUREGROUP_Vehicle                           = 9,
    TEXTUREGROUP_VehicleNormalMap                  = 10,
    TEXTUREGROUP_VehicleSpecular                   = 11,
    TEXTUREGROUP_Cinematic                         = 12,
    TEXTUREGROUP_Effects                           = 13,
    TEXTUREGROUP_EffectsNotFiltered                = 14,
    TEXTUREGROUP_Skybox                            = 15,
    TEXTUREGROUP_UI                                = 16,
    TEXTUREGROUP_Lightmap                          = 17,
    TEXTUREGROUP_RenderTarget                      = 18,
    TEXTUREGROUP_MobileFlattened                   = 19,
    TEXTUREGROUP_ProcBuilding_Face                 = 20,
    TEXTUREGROUP_ProcBuilding_LightMap             = 21,
    TEXTUREGROUP_Shadowmap                         = 22,
    TEXTUREGROUP_ColorLookupTable                  = 23,
    TEXTUREGROUP_Terrain_Heightmap                 = 24,
    TEXTUREGROUP_Terrain_Weightmap                 = 25,
    TEXTUREGROUP_Bokeh                             = 26,
    TEXTUREGROUP_IESLightProfile                   = 27,
    TEXTUREGROUP_Pixels2D                          = 28,
    TEXTUREGROUP_HierarchicalLOD                   = 29,
    TEXTUREGROUP_Impostor                          = 30,
    TEXTUREGROUP_ImpostorNormalDepth               = 31,
    TEXTUREGROUP_8BitData                          = 32,
    TEXTUREGROUP_16BitData                         = 33,
    TEXTUREGROUP_Project01                         = 34,
    TEXTUREGROUP_Project02                         = 35,
    TEXTUREGROUP_Project03                         = 36,
    TEXTUREGROUP_Project04                         = 37,
    TEXTUREGROUP_Project05                         = 38,
    TEXTUREGROUP_Project06                         = 39,
    TEXTUREGROUP_Project07                         = 40,
    TEXTUREGROUP_Project08                         = 41,
    TEXTUREGROUP_Project09                         = 42,
    TEXTUREGROUP_Project10                         = 43,
    TEXTUREGROUP_Lightmap_SH                       = 44,
    TEXTUREGROUP_MAX                               = 45

};


// Enum  /Script/Engine.ETextureRenderTargetFormat
enum class ETextureRenderTargetFormat : uint8_t
{
    RTF_R8                                         = 0,
    RTF_RG8                                        = 1,
    RTF_RGBA8                                      = 2,
    RTF_R16f                                       = 3,
    RTF_RG16f                                      = 4,
    RTF_RGBA16f                                    = 5,
    RTF_R32f                                       = 6,
    RTF_RG32f                                      = 7,
    RTF_RGBA32f                                    = 8,
    RTF_RGB10A2                                    = 9,
    RTF_MAX                                        = 10

};


// Enum  /Script/Engine.ETimecodeProviderSynchronizationState
enum class ETimecodeProviderSynchronizationState : uint8_t
{
    Closed                                         = 0,
    Error                                          = 1,
    Synchronized                                   = 2,
    Synchronizing                                  = 3,
    ETimecodeProviderSynchronizationState_MAX      = 4

};


// Enum  /Script/Engine.ETimelineDirection
enum class ETimelineDirection : uint8_t
{
    Forward                                        = 0,
    Backward                                       = 1,
    ETimelineDirection_MAX                         = 2

};


// Enum  /Script/Engine.ETimelineLengthMode
enum class ETimelineLengthMode : uint8_t
{
    TL_TimelineLength                              = 0,
    TL_LastKeyFrame                                = 1,
    TL_MAX                                         = 2

};


// Enum  /Script/Engine.ETimeStretchCurveMapping
enum class ETimeStretchCurveMapping : uint8_t
{
    T_Original                                     = 0,
    T_TargetMin                                    = 1,
    T_TargetMax                                    = 2,
    MAX                                            = 3

};


// Enum  /Script/Engine.ETwitterIntegrationDelegate
enum class ETwitterIntegrationDelegate : uint8_t
{
    TID_AuthorizeComplete                          = 0,
    TID_TweetUIComplete                            = 1,
    TID_RequestComplete                            = 2,
    TID_MAX                                        = 3

};


// Enum  /Script/Engine.ETwitterRequestMethod
enum class ETwitterRequestMethod : uint8_t
{
    TRM_Get                                        = 0,
    TRM_Post                                       = 1,
    TRM_Delete                                     = 2,
    TRM_MAX                                        = 3

};


// Enum  /Script/Engine.EUserDefinedStructureStatus
enum class EUserDefinedStructureStatus : uint8_t
{
    UDSS_UpToDate                                  = 0,
    UDSS_Dirty                                     = 1,
    UDSS_Error                                     = 2,
    UDSS_Duplicate                                 = 3,
    UDSS_MAX                                       = 4

};


// Enum  /Script/Engine.EUIScalingRule
enum class EUIScalingRule : uint8_t
{
    ShortestSide                                   = 0,
    LongestSide                                    = 1,
    Horizontal                                     = 2,
    Vertical                                       = 3,
    Custom                                         = 4,
    EUIScalingRule_MAX                             = 5

};


// Enum  /Script/Engine.ERenderFocusRule
enum class ERenderFocusRule : uint8_t
{
    Always                                         = 0,
    NonPointer                                     = 1,
    NavigationOnly                                 = 2,
    Never                                          = 3,
    ERenderFocusRule_MAX                           = 4

};


// Enum  /Script/Engine.EVectorFieldConstructionOp
enum class EVectorFieldConstructionOp : uint8_t
{
    VFCO_Extrude                                   = 0,
    VFCO_Revolve                                   = 1,
    VFCO_MAX                                       = 2

};


// Enum  /Script/Engine.EWindSourceType
enum class EWindSourceType : uint8_t
{
    Directional                                    = 0,
    Point                                          = 1,
    EWindSourceType_MAX                            = 2

};


// Enum  /Script/Engine.EPSCPoolMethod
enum class EPSCPoolMethod : uint8_t
{
    None                                           = 0,
    AutoRelease                                    = 1,
    ManualRelease                                  = 2,
    ManualRelease_OnComplete                       = 3,
    FreeInPool                                     = 4,
    EPSCPoolMethod_MAX                             = 5

};


// Enum  /Script/Engine.EStaticInstancingType
enum class EStaticInstancingType : uint8_t
{
    ISM                                            = 0,
    HISM                                           = 1,
    EStaticInstancingType_MAX                      = 2

};


// Enum  /Script/Engine.EIdeaBakingLayout
enum class EIdeaBakingLayout : uint8_t
{
    Sun3Sky                                        = 0,
    Sun1SkyLocal1                                  = 1,
    Sun3SkyLocal3                                  = 2,
    Sun2SkyLocal1                                  = 3,
    Local3Sky                                      = 4,
    Sun1PortalSkyLocal1                            = 5,
    Sun1OccLocal1                                  = 6,
    Sun1SkyLocal1Occ                               = 7,
    Sun3SkyLocal3Occ                               = 8,
    EIdeaBakingLayout_MAX                          = 9

};


// Enum  /Script/Engine.EIdeaBakingMode
enum class EIdeaBakingMode : uint8_t
{
    BruteForce                                     = 0,
    TwoPass                                        = 1,
    EIdeaBakingMode_MAX                            = 2

};


// Enum  /Script/Engine.EVolumeLightingMethod
enum class EVolumeLightingMethod : uint8_t
{
    VLM_VolumetricLightmap                         = 0,
    VLM_SparseVolumeLightingSamples                = 1,
    VLM_MAX                                        = 2

};


// Enum  /Script/Engine.EVisibilityAggressiveness
enum class EVisibilityAggressiveness : uint8_t
{
    VIS_LeastAggressive                            = 0,
    VIS_ModeratelyAggressive                       = 1,
    VIS_MostAggressive                             = 2,
    VIS_Max                                        = 3

};


// Enum  /Script/MediaUtils.EMediaPlayerOptionBooleanOverride
enum class EMediaPlayerOptionBooleanOverride : uint8_t
{
    UseMediaPlayerSetting                          = 0,
    Enabled                                        = 1,
    Disabled                                       = 2,
    EMediaPlayerOptionBooleanOverride_MAX          = 3

};


// Enum  /Script/ClothingSystemRuntime.EClothingWindMethod
enum class EClothingWindMethod : uint8_t
{
    Legacy                                         = 0,
    Accurate                                       = 1,
    EClothingWindMethod_MAX                        = 2

};


// Enum  /Script/ClothingSystemRuntime.MaskTarget_PhysMesh
enum class MaskTarget_PhysMesh : uint8_t
{
    None                                           = 0,
    MaxDistance                                    = 1,
    BackstopDistance                               = 2,
    BackstopRadius                                 = 3,
    AnimDriveMultiplier                            = 4,
    MaskTarget_MAX                                 = 5

};


// Enum  /Script/MediaAssets.EMediaWebcamCaptureDeviceFilter
enum class EMediaWebcamCaptureDeviceFilter : uint8_t
{
    DepthSensor                                    = 1,
    Front                                          = 2,
    Rear                                           = 4,
    Unknown                                        = 8,
    EMediaWebcamCaptureDeviceFilter_MAX            = 9

};


// Enum  /Script/MediaAssets.EMediaVideoCaptureDeviceFilter
enum class EMediaVideoCaptureDeviceFilter : uint8_t
{
    Card                                           = 1,
    Software                                       = 2,
    Unknown                                        = 4,
    Webcam                                         = 8,
    EMediaVideoCaptureDeviceFilter_MAX             = 9

};


// Enum  /Script/MediaAssets.EMediaAudioCaptureDeviceFilter
enum class EMediaAudioCaptureDeviceFilter : uint8_t
{
    Card                                           = 1,
    Microphone                                     = 2,
    Software                                       = 4,
    Unknown                                        = 8,
    EMediaAudioCaptureDeviceFilter_MAX             = 9

};


// Enum  /Script/MediaAssets.EMediaPlayerTrack
enum class EMediaPlayerTrack : uint8_t
{
    Audio                                          = 0,
    Caption                                        = 1,
    Metadata                                       = 2,
    Script                                         = 3,
    Subtitle                                       = 4,
    Text                                           = 5,
    Video                                          = 6,
    EMediaPlayerTrack_MAX                          = 7

};


// Enum  /Script/MediaAssets.EMediaSoundComponentFFTSize
enum class EMediaSoundComponentFFTSize : uint8_t
{
    Min                                            = 0,
    Small                                          = 1,
    Medium                                         = 2,
    Large                                          = 3,
    EMediaSoundComponentFFTSize_MAX                = 4

};


// Enum  /Script/MediaAssets.EMediaSoundChannels
enum class EMediaSoundChannels : uint8_t
{
    Mono                                           = 0,
    Stereo                                         = 1,
    Surround                                       = 2,
    EMediaSoundChannels_MAX                        = 3

};


// Enum  /Script/GameplayTasks.EGameplayTaskState
enum class EGameplayTaskState : uint8_t
{
    Uninitialized                                  = 0,
    AwaitingActivation                             = 1,
    Paused                                         = 2,
    Active                                         = 3,
    Finished                                       = 4,
    EGameplayTaskState_MAX                         = 5

};


// Enum  /Script/GameplayTasks.EGameplayTaskRunResult
enum class EGameplayTaskRunResult : uint8_t
{
    Error                                          = 0,
    Failed                                         = 1,
    Success_Paused                                 = 2,
    Success_Active                                 = 3,
    Success_Finished                               = 4,
    EGameplayTaskRunResult_MAX                     = 5

};


// Enum  /Script/NavigationSystem.ERuntimeGenerationType
enum class ERuntimeGenerationType : uint8_t
{
    Static                                         = 0,
    DynamicModifiersOnly                           = 1,
    Dynamic                                        = 2,
    LegacyGeneration                               = 3,
    ERuntimeGenerationType_MAX                     = 4

};


// Enum  /Script/NavigationSystem.ENavCostDisplay
enum class ENavCostDisplay : uint8_t
{
    TotalCost                                      = 0,
    HeuristicOnly                                  = 1,
    RealCostOnly                                   = 2,
    ENavCostDisplay_MAX                            = 3

};


// Enum  /Script/NavigationSystem.ERecastPartitioning
enum class ERecastPartitioning : uint8_t
{
    Monotone                                       = 0,
    Watershed                                      = 1,
    ChunkyMonotone                                 = 2,
    ERecastPartitioning_MAX                        = 3

};


// Enum  /Script/AIModule.EAISenseNotifyType
enum class EAISenseNotifyType : uint8_t
{
    OnEveryPerception                              = 0,
    OnPerceptionChange                             = 1,
    EAISenseNotifyType_MAX                         = 2

};


// Enum  /Script/AIModule.EAITaskPriority
enum class EAITaskPriority : uint8_t
{
    Lowest                                         = 0,
    Low                                            = 64,
    AutonomousAI                                   = 127,
    High                                           = 192,
    Ultimate                                       = 254,
    EAITaskPriority_MAX                            = 255

};


// Enum  /Script/AIModule.EGenericAICheck
enum class EGenericAICheck : uint8_t
{
    Less                                           = 0,
    LessOrEqual                                    = 1,
    Equal                                          = 2,
    NotEqual                                       = 3,
    GreaterOrEqual                                 = 4,
    Greater                                        = 5,
    IsTrue                                         = 6,
    MAX                                            = 7

};


// Enum  /Script/AIModule.EAILockSource
enum class EAILockSource : uint8_t
{
    Animation                                      = 0,
    Logic                                          = 1,
    Script                                         = 2,
    Gameplay                                       = 3,
    MAX                                            = 4

};


// Enum  /Script/AIModule.EAIRequestPriority
enum class EAIRequestPriority : uint8_t
{
    SoftScript                                     = 0,
    Logic                                          = 1,
    HardScript                                     = 2,
    Reaction                                       = 3,
    Ultimate                                       = 4,
    MAX                                            = 5

};


// Enum  /Script/AIModule.EPawnActionEventType
enum class EPawnActionEventType : uint8_t
{
    Invalid                                        = 0,
    FailedToStart                                  = 1,
    InstantAbort                                   = 2,
    FinishedAborting                               = 3,
    FinishedExecution                              = 4,
    Push                                           = 5,
    EPawnActionEventType_MAX                       = 6

};


// Enum  /Script/AIModule.EPawnActionResult
enum class EPawnActionResult : uint8_t
{
    NotStarted                                     = 0,
    InProgress                                     = 1,
    Success                                        = 2,
    Failed                                         = 3,
    Aborted                                        = 4,
    EPawnActionResult_MAX                          = 5

};


// Enum  /Script/AIModule.EPawnActionAbortState
enum class EPawnActionAbortState : uint8_t
{
    NeverStarted                                   = 0,
    NotBeingAborted                                = 1,
    MarkPendingAbort                               = 2,
    LatentAbortInProgress                          = 3,
    AbortDone                                      = 4,
    MAX                                            = 5

};


// Enum  /Script/AIModule.FAIDistanceType
enum class FAIDistanceType : uint8_t
{
    Distance3D                                     = 0,
    Distance2D                                     = 1,
    DistanceZ                                      = 2,
    MAX                                            = 3

};


// Enum  /Script/AIModule.EAIOptionFlag
enum class EAIOptionFlag : uint8_t
{
    Default                                        = 0,
    Enable                                         = 1,
    Disable                                        = 2,
    MAX                                            = 3

};


// Enum  /Script/AIModule.EBTFlowAbortMode
enum class EBTFlowAbortMode : uint8_t
{
    None                                           = 0,
    LowerPriority                                  = 1,
    Self                                           = 2,
    Both                                           = 3,
    EBTFlowAbortMode_MAX                           = 4

};


// Enum  /Script/AIModule.EBTNodeResult
enum class EBTNodeResult : uint8_t
{
    Succeeded                                      = 0,
    Failed                                         = 1,
    Aborted                                        = 2,
    InProgress                                     = 3,
    EBTNodeResult_MAX                              = 4

};


// Enum  /Script/AIModule.ETextKeyOperation
enum class ETextKeyOperation : uint8_t
{
    Equal                                          = 0,
    NotEqual                                       = 1,
    Contain                                        = 2,
    NotContain                                     = 3,
    ETextKeyOperation_MAX                          = 4

};


// Enum  /Script/AIModule.EArithmeticKeyOperation
enum class EArithmeticKeyOperation : uint8_t
{
    Equal                                          = 0,
    NotEqual                                       = 1,
    Less                                           = 2,
    LessOrEqual                                    = 3,
    Greater                                        = 4,
    GreaterOrEqual                                 = 5,
    EArithmeticKeyOperation_MAX                    = 6

};


// Enum  /Script/AIModule.EBasicKeyOperation
enum class EBasicKeyOperation : uint8_t
{
    Set                                            = 0,
    NotSet                                         = 1,
    EBasicKeyOperation_MAX                         = 2

};


// Enum  /Script/AIModule.EBTParallelMode
enum class EBTParallelMode : uint8_t
{
    AbortBackground                                = 0,
    WaitForBackground                              = 1,
    EBTParallelMode_MAX                            = 2

};


// Enum  /Script/AIModule.EBTDecoratorLogic
enum class EBTDecoratorLogic : uint8_t
{
    Invalid                                        = 0,
    Test                                           = 1,
    And                                            = 2,
    Or                                             = 3,
    Not                                            = 4,
    AbortableStart                                 = 5,
    AbortableEnd                                   = 6,
    EBTDecoratorLogic_MAX                          = 7

};


// Enum  /Script/AIModule.EBTChildIndex
enum class EBTChildIndex : uint8_t
{
    FirstNode                                      = 0,
    TaskNode                                       = 1,
    EBTChildIndex_MAX                              = 2

};


// Enum  /Script/AIModule.EBTBlackboardRestart
enum class EBTBlackboardRestart : uint8_t
{
    ValueChange                                    = 0,
    ResultChange                                   = 1,
    EBTBlackboardRestart_MAX                       = 2

};


// Enum  /Script/AIModule.EBlackBoardEntryComparison
enum class EBlackBoardEntryComparison : uint8_t
{
    Equal                                          = 0,
    NotEqual                                       = 1,
    EBlackBoardEntryComparison_MAX                 = 2

};


// Enum  /Script/AIModule.EPathExistanceQueryType
enum class EPathExistanceQueryType : uint8_t
{
    NavmeshRaycast2D                               = 0,
    HierarchicalQuery                              = 1,
    RegularPathFinding                             = 2,
    EPathExistanceQueryType_MAX                    = 3

};


// Enum  /Script/AIModule.EPointOnCircleSpacingMethod
enum class EPointOnCircleSpacingMethod : uint8_t
{
    BySpaceBetween                                 = 0,
    ByNumberOfPoints                               = 1,
    EPointOnCircleSpacingMethod_MAX                = 2

};


// Enum  /Script/AIModule.EEQSNormalizationType
enum class EEQSNormalizationType : uint8_t
{
    Absolute                                       = 0,
    RelativeToScores                               = 1,
    EEQSNormalizationType_MAX                      = 2

};


// Enum  /Script/AIModule.EEnvTestDistance
enum class EEnvTestDistance : uint8_t
{
    Distance3D                                     = 0,
    Distance2D                                     = 1,
    DistanceZ                                      = 2,
    DistanceAbsoluteZ                              = 3,
    EEnvTestDistance_MAX                           = 4

};


// Enum  /Script/AIModule.EEnvTestDot
enum class EEnvTestDot : uint8_t
{
    Dot3D                                          = 0,
    Dot2D                                          = 1,
    EEnvTestDot_MAX                                = 2

};


// Enum  /Script/AIModule.EEnvTestPathfinding
enum class EEnvTestPathfinding : uint8_t
{
    PathExist                                      = 0,
    PathCost                                       = 1,
    PathLength                                     = 2,
    EEnvTestPathfinding_MAX                        = 3

};


// Enum  /Script/AIModule.EEnvQueryTestClamping
enum class EEnvQueryTestClamping : uint8_t
{
    None                                           = 0,
    SpecifiedValue                                 = 1,
    FilterThreshold                                = 2,
    EEnvQueryTestClamping_MAX                      = 3

};


// Enum  /Script/AIModule.EEnvDirection
enum class EEnvDirection : uint8_t
{
    TwoPoints                                      = 0,
    Rotation                                       = 1,
    EEnvDirection_MAX                              = 2

};


// Enum  /Script/AIModule.EEnvOverlapShape
enum class EEnvOverlapShape : uint8_t
{
    Box                                            = 0,
    Sphere                                         = 1,
    Capsule                                        = 2,
    EEnvOverlapShape_MAX                           = 3

};


// Enum  /Script/AIModule.EEnvTraceShape
enum class EEnvTraceShape : uint8_t
{
    Line                                           = 0,
    Box                                            = 1,
    Sphere                                         = 2,
    Capsule                                        = 3,
    EEnvTraceShape_MAX                             = 4

};


// Enum  /Script/AIModule.EEnvQueryTrace
enum class EEnvQueryTrace : uint8_t
{
    None                                           = 0,
    Navigation                                     = 1,
    Geometry                                       = 2,
    NavigationOverLedges                           = 3,
    EEnvQueryTrace_MAX                             = 4

};


// Enum  /Script/AIModule.EAIParamType
enum class EAIParamType : uint8_t
{
    Float                                          = 0,
    Int                                            = 1,
    Bool                                           = 2,
    BBKey                                          = 3,
    MAX                                            = 4

};


// Enum  /Script/AIModule.EEnvQueryParam
enum class EEnvQueryParam : uint8_t
{
    Float                                          = 0,
    Int                                            = 1,
    Bool                                           = 2,
    BBKey                                          = 3,
    EEnvQueryParam_MAX                             = 4

};


// Enum  /Script/AIModule.EEnvQueryRunMode
enum class EEnvQueryRunMode : uint8_t
{
    SingleResult                                   = 0,
    RandomBest5Pct                                 = 1,
    RandomBest25Pct                                = 2,
    AllMatching                                    = 3,
    EEnvQueryRunMode_MAX                           = 4

};


// Enum  /Script/AIModule.EEnvTestScoreOperator
enum class EEnvTestScoreOperator : uint8_t
{
    AverageScore                                   = 0,
    MinScore                                       = 1,
    MaxScore                                       = 2,
    EEnvTestScoreOperator_MAX                      = 3

};


// Enum  /Script/AIModule.EEnvTestFilterOperator
enum class EEnvTestFilterOperator : uint8_t
{
    AllPass                                        = 0,
    AnyPass                                        = 1,
    EEnvTestFilterOperator_MAX                     = 2

};


// Enum  /Script/AIModule.EEnvTestCost
enum class EEnvTestCost : uint8_t
{
    Low                                            = 0,
    Medium                                         = 1,
    High                                           = 2,
    EEnvTestCost_MAX                               = 3

};


// Enum  /Script/AIModule.EEnvTestWeight
enum class EEnvTestWeight : uint8_t
{
    None                                           = 0,
    Square                                         = 1,
    Inverse                                        = 2,
    Unused                                         = 3,
    Constant                                       = 4,
    Skip                                           = 5,
    EEnvTestWeight_MAX                             = 6

};


// Enum  /Script/AIModule.EEnvTestScoreEquation
enum class EEnvTestScoreEquation : uint8_t
{
    Linear                                         = 0,
    Square                                         = 1,
    InverseLinear                                  = 2,
    SquareRoot                                     = 3,
    Constant                                       = 4,
    Curve                                          = 5,
    EEnvTestScoreEquation_MAX                      = 6

};


// Enum  /Script/AIModule.EEnvTestFilterType
enum class EEnvTestFilterType : uint8_t
{
    Minimum                                        = 0,
    Maximum                                        = 1,
    Range                                          = 2,
    Match                                          = 3,
    EEnvTestFilterType_MAX                         = 4

};


// Enum  /Script/AIModule.EEnvTestPurpose
enum class EEnvTestPurpose : uint8_t
{
    Filter                                         = 0,
    Score                                          = 1,
    FilterAndScore                                 = 2,
    EEnvTestPurpose_MAX                            = 3

};


// Enum  /Script/AIModule.EEnvQueryHightlightMode
enum class EEnvQueryHightlightMode : uint8_t
{
    All                                            = 0,
    Best5Pct                                       = 1,
    Best25Pct                                      = 2,
    EEnvQueryHightlightMode_MAX                    = 3

};


// Enum  /Script/AIModule.ETeamAttitude
enum class ETeamAttitude : uint8_t
{
    Friendly                                       = 0,
    Neutral                                        = 1,
    Hostile                                        = 2,
    ETeamAttitude_MAX                              = 3

};


// Enum  /Script/AIModule.EPathFollowingRequestResult
enum class EPathFollowingRequestResult : uint8_t
{
    Failed                                         = 0,
    AlreadyAtGoal                                  = 1,
    RequestSuccessful                              = 2,
    EPathFollowingRequestResult_MAX                = 3

};


// Enum  /Script/AIModule.EPathFollowingAction
enum class EPathFollowingAction : uint8_t
{
    Error                                          = 0,
    NoMove                                         = 1,
    DirectMove                                     = 2,
    PartialPath                                    = 3,
    PathToGoal                                     = 4,
    EPathFollowingAction_MAX                       = 5

};


// Enum  /Script/AIModule.EPathFollowingStatus
enum class EPathFollowingStatus : uint8_t
{
    Idle                                           = 0,
    Waiting                                        = 1,
    Paused                                         = 2,
    Moving                                         = 3,
    EPathFollowingStatus_MAX                       = 4

};


// Enum  /Script/AIModule.EPawnActionFailHandling
enum class EPawnActionFailHandling : uint8_t
{
    RequireSuccess                                 = 0,
    IgnoreFailure                                  = 1,
    EPawnActionFailHandling_MAX                    = 2

};


// Enum  /Script/AIModule.EPawnSubActionTriggeringPolicy
enum class EPawnSubActionTriggeringPolicy : uint8_t
{
    CopyBeforeTriggering                           = 0,
    ReuseInstances                                 = 1,
    EPawnSubActionTriggeringPolicy_MAX             = 2

};


// Enum  /Script/AIModule.EPawnActionMoveMode
enum class EPawnActionMoveMode : uint8_t
{
    UsePathfinding                                 = 0,
    StraightLine                                   = 1,
    EPawnActionMoveMode_MAX                        = 2

};


// Enum  /Script/ActorSequence.EActorSequenceObjectReferenceType
enum class EActorSequenceObjectReferenceType : uint8_t
{
    ContextActor                                   = 0,
    ExternalActor                                  = 1,
    Component                                      = 2,
    EActorSequenceObjectReferenceType_MAX          = 3

};


// UserDefinedEnum  /Script/Engine.Default__UserDefinedEnum
enum class Default__UserDefinedEnum : uint8_t
{

};


